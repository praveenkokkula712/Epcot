//
//  PosAppConfigurationForceHeader.swift
//  Wrapper
//
//  Created by Vinod Kumar Muppala on 06/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

public class PosAppConfigurationHeader: NSObject {
    
    public private(set) var showBack: Bool?
    public private(set) var showHeader: Bool?
    public private(set) var url: String?

    public init(json : Dictionary<String, Any>) {
        super.init()
        if let showBack = json["showBack"] as? Bool {
            self.showBack = showBack
        }
        if let showHeader = json["showHeader"] as? Bool {
            self.showHeader = showHeader
        }
        self.url = self.getStringValueWithJson(json, key: "url")
        
    }
    
    public func getStringValueWithJson(_ json : Dictionary<String, Any> , key : String) -> String {
        var valueInString = String()
        if let keyIntegerValue = json[key] as? NSNumber {
            valueInString = keyIntegerValue.stringValue
        }else if let keyStringValue = json[key] as? String{
            valueInString = keyStringValue
        }
        return valueInString
    }
}

public class PosAppConfigurationForceHeader: NSObject {

    public private(set) var knownHost:Array<PosAppConfigurationHeader>?
    public private(set) var unknownHost:Array<PosAppConfigurationHeader>?
    
    public init(feature: DynaconFeature) {
        super.init()
        var knownHosts = [PosAppConfigurationHeader]()
        var unKnownHosts = [PosAppConfigurationHeader]()

        if let knownHostArray = feature.arrayFieldWithName(fieldName: "knownHost")?.value {
            for knownHostJson in knownHostArray {
                let header = PosAppConfigurationHeader(json:knownHostJson as! Dictionary<String, Any>)
                knownHosts.append(header)
                
            }
            self.knownHost = knownHosts
        }
        
        if let unknownHostArray = feature.arrayFieldWithName(fieldName: "unknownHost")?.value {
            for unKnownHostJson in unknownHostArray {
                let header = PosAppConfigurationHeader(json:unKnownHostJson as! Dictionary<String, Any>)
                unKnownHosts.append(header)
                
            }
            self.unknownHost = unKnownHosts

        }
    }
}
