//
//  OpenMapsModel.swift
//  ConfigModule
//
//  Created by Shubham Kumar on 20/09/24.
//

import Foundation

// MARK: -  Open Maps
public struct OpenMapsModel: Codable {
    public let appStoreUrl: String?
    public let playStoreUrl: String?
}
