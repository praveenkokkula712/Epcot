//
//  PosAppConfigurationGeneral.swift
//  Wrapper
//
//  Created by Vinod Kumar Muppala on 06/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import Foundation

public class PosAppConfigurationGeneral: NSObject {
    public private(set) var maintenanceEnabled:Bool?
    public private(set) var appEnabled:Bool?
    public private(set) var mandatoryUpdateEnabled:Bool?
    public private(set) var copyright:String?
    public private(set) var customerServiceEmail:String?
    public private(set) var updateUrl:String?
    public private(set) var latestVersion:String?
    public private(set) var lastSupportedVersion: String?
    public private(set) var knownHosts:Array<Any>?
    public private(set) var iTunesDefaultCountry:String?
    public private(set) var iTunesDefaultLanguage:String?
    public private(set) var operationsTeamEmail = ""
    public private(set) var themeColors: [String: Any]?
    public private(set) var deepLinkUrlHosts: [String]?
    public private(set) var onfidoCountryCode: [String : String]?
    public private(set) var locationSpoofList: [LocationSpoofModel] = []
    public private(set) var lastLoginTimeZone: String?
    public private(set) var lastLoginTimeFormate: String?
    public private(set) var enableNewSoftUpdateScreen: Bool = false
    public private(set) var noOfLoginAttempts: Int = -1
    public private(set) var crossSellApps: [String: CrossSellAppsValues]?
    public private(set) var enableKeyChainSharing: Bool = false
    public private(set) var enableAlternateAppIcon: Bool = false
    public private(set) var alternateAppIconName: String = ""
    public private(set) var forceUpdateScreenVersion: ForceUpdateViewVersion = ForceUpdateViewVersion.one
    public private(set) var maintenanceScreenVersion: MaintenanceScreenVersion = MaintenanceScreenVersion.one
    public private(set) var openMapsConfig: OpenMapsModel?
    
    public init(feature: DynaconFeature) {
        super.init()

        self.appEnabled = feature.boolFieldWithName(fieldName: "enableApp")?.value
        self.maintenanceEnabled = feature.boolFieldWithName(fieldName: "enableMaintenance")?.value
        self.mandatoryUpdateEnabled = feature.boolFieldWithName(fieldName: "enableMandatoryUpdate")?.value
        if let forceUpdateVersion = feature.numberFieldWithName(fieldName: "forceUpdateScreenVersion")?.value?.intValue {
            self.forceUpdateScreenVersion =  ForceUpdateViewVersion(rawValue: forceUpdateVersion) ?? .one
        }
        if let maintenanceScreenVersion = feature.numberFieldWithName(fieldName: "maintenanceScreenVersion")?.value?.intValue {
            self.maintenanceScreenVersion =  MaintenanceScreenVersion(rawValue: maintenanceScreenVersion) ?? .one
        }
        self.operationsTeamEmail = feature.stringFieldWithName(fieldName: "operationsTeamEmail")?.value ?? ""
        self.customerServiceEmail = feature.stringFieldWithName(fieldName: "customerServiceEmail")?.value
        self.updateUrl = feature.stringFieldWithName(fieldName: "updateUrl")?.value
        self.latestVersion = feature.stringFieldWithName(fieldName: "latestVersion")?.value
        self.lastSupportedVersion = feature.stringFieldWithName(fieldName: "lastSupportedVersion")?.value
        self.knownHosts = feature.arrayFieldWithName(fieldName: "knownHosts")?.value
        self.copyright = feature.stringFieldWithName(fieldName: "copyright")?.value
        if let itunesParams = feature.dictionaryFieldWithName(fieldName: "iTunesUpdateParams")?.value {
            self.iTunesDefaultLanguage = itunesParams["iTunesDefaultLanguage"] as? String
            self.iTunesDefaultCountry = itunesParams["iTunesDefaultCountry"] as? String
        }
        self.themeColors = feature.dictionaryFieldWithName(fieldName: "themeColors")?.value
        self.deepLinkUrlHosts = feature.arrayFieldWithName(fieldName: "deepLinkUrlHosts")?.value as? [String]
        self.onfidoCountryCode = feature.dictionaryFieldWithName(fieldName: "onfidoCountryCodeMapping")?.value as? [String : String]
        if let lists = feature.arrayFieldWithName(fieldName: "locationSpoofList")?.value {
            for list in lists {
                if let json = list as? [String: Any]{
                    let name = json["name"] as? String
                    let latitude = json["latitude"] as? Double
                    let longitude = json["longitude"] as? Double
                    let model = LocationSpoofModel(name: name, latitude: latitude, longitude: longitude)
                    locationSpoofList.append(model)
                }
            }
        }
        if let response = feature.dictionaryFieldWithName(fieldName: "CrossSellApps")?.value as? [String: Any] {
            let refreshJson = try? JSONSerialization.data(withJSONObject: response, options: [])
            if let result = try? refreshJson?.jsonDecoder([String: CrossSellAppsValues].self).get() {
                self.crossSellApps = result
            }
        }
        if let lastLoginFormate = feature.dictionaryFieldWithName(fieldName: "lastLoginFormate")?.value {
            self.lastLoginTimeZone = lastLoginFormate["lastLoginTimeZone"] as? String
            self.lastLoginTimeFormate = lastLoginFormate["lastLoginTimeFormate"] as? String
        }
        if let config = feature.dictionaryFieldWithName(fieldName: "newSoftUpdateConfig")?.value {
            self.enableNewSoftUpdateScreen = config["enableNewSoftUpdateScreen"] as? Bool ?? false
            if let count = config["noOfLoginAttempts"] as? NSNumber {
                self.noOfLoginAttempts = count.intValue
            }
        }
        self.enableKeyChainSharing = feature.boolFieldWithName(fieldName: "enableKeyChainSharing")?.value ?? false
        if let appIcon = feature.dictionaryFieldWithName(fieldName: "alternateAppIcon")?.value {
            if let enable = appIcon["enable"] as? Bool {
                self.enableAlternateAppIcon = enable
            }
            if let iconName = appIcon["iconName"] as? String {
                self.alternateAppIconName = iconName
            }
        }
        if let openMapsConfig = feature.dictionaryFieldWithName(fieldName: "openMapsConfig")?.value {
            let configData = try? JSONSerialization.data(withJSONObject: openMapsConfig)
            let result = configData?.jsonDecoder(OpenMapsModel.self)
            switch result {
            case .success(let config):
                self.openMapsConfig = config
            default: break
            }
        }
    }

    public func update(siblingData:PosAppConfigurationSibling) {
        let apiConfig = DynaconAPIConfiguration.shared
        if let countryCode = apiConfig?.appConfigs?.countryCode {
            if let enabled = siblingData.appEnabled, let countryAllow = siblingData.allowedCountries?.contains(countryCode) {
                self.appEnabled = enabled && countryAllow
            }
        }
        
        if let maintenanceEnable = siblingData.maintenanceEnabled {
            self.maintenanceEnabled = maintenanceEnable
        }
        if let mandatoryUpdateEnable = siblingData.mandatoryUpdateEnabled {
            self.mandatoryUpdateEnabled = mandatoryUpdateEnable
        }
        if let url = siblingData.updateUrl {
            self.updateUrl = url
        }
        if let version = siblingData.latestVersion {
            self.latestVersion = version
        }
        if let country = siblingData.iTunesDefaultCountry {
            self.iTunesDefaultCountry = country
        }
        if let language = siblingData.iTunesDefaultLanguage {
            self.iTunesDefaultLanguage = language
        }
    }

}
