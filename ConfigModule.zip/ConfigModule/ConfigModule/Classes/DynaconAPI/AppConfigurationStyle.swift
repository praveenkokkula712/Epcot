//
//  AppConfigurationStyle.swift
//  Wrapper
//
//  Created by Uday Kiran Veginati on 18/06/22.
//  Copyright © 2022 bwin.com. All rights reserved.
//

import Foundation
import Utility

public struct AppConfigurationStyle {
    public private(set) var theme: [String: Any] = [String: Any]()
    public private(set) var dynamicHeader: DynamicHeaderModel?
    public private(set) var instantInteraction: InstantInteractionModel?

    public init(feature: DynaconFeature) {
        var _theme = [String: Any]()
        if let applicationTheme = feature.dictionaryFieldWithName(fieldName: "applicationTheme")?.value,
           !applicationTheme.isEmpty {
            _theme.merge(applicationTheme) { $1 }
        }
        if let epcotTheme = feature.dictionaryFieldWithName(fieldName: "epcotTheme")?.value,
           !epcotTheme.isEmpty {
            _theme.merge(epcotTheme) { $1 }
        }
        if let genericTheme = feature.dictionaryFieldWithName(fieldName: "genericTheme")?.value,
           !genericTheme.isEmpty {
            _theme.merge(genericTheme) { $1 }
        }
        if let lobbyCss = feature.dictionaryFieldWithName(fieldName: "lobbyCss")?.value,
           !lobbyCss.isEmpty {
            _theme.merge(lobbyCss) { $1 }
        }
        if let loginPageTheme = feature.dictionaryFieldWithName(fieldName: "loginPageTheme")?.value,
           !loginPageTheme.isEmpty {
            _theme.merge(loginPageTheme) { $1 }
        }
        if let menuTheme = feature.dictionaryFieldWithName(fieldName: "menuTheme")?.value,
           !menuTheme.isEmpty {
            _theme.merge(menuTheme) { $1 }
        }
        if let regulatoryPopupTheme = feature.dictionaryFieldWithName(fieldName: "regulatoryPopupTheme")?.value,
           !regulatoryPopupTheme.isEmpty {
            _theme.merge(regulatoryPopupTheme) { $1 }
        }
        if let featuresTheme = feature.dictionaryFieldWithName(fieldName: "featuresTheme")?.value,
           !featuresTheme.isEmpty {
            _theme.merge(featuresTheme) { $1 }
        }
        self.theme = _theme
        
        do {
            if let headerCss = feature.dictionaryFieldWithName(fieldName: "dynamicHeaderStyle")?.value {
                let json = try JSONSerialization.data(withJSONObject: headerCss)
                if let _dynamicHeader = try? JSONDecoder().decode(DynamicHeaderModel.self, from: json) {
                    self.dynamicHeader = _dynamicHeader
                }
            }

            if let instantInteraction = feature.dictionaryFieldWithName(fieldName: "instantInteraction")?.value {
                let json = try JSONSerialization.data(withJSONObject: instantInteraction)
                if let _instantInteraction = try? JSONDecoder().decode(InstantInteractionModel.self, from: json) {
                    self.instantInteraction = _instantInteraction
                }
            }

        } catch { }
    }
}
