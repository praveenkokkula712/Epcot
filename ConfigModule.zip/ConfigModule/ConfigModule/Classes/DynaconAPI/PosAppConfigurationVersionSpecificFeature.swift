//
//  PosAppConfigurationVersionSpecificFeature.swift
//  Wrapper
//
//  Created by Uday Kiran Veginati on 12/12/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

public class PosAppConfigurationVersionSpecificFeature: NSObject {

    public private(set) var noGeoblockAppVersions: [String]?
    public private(set) var hideMoreGamesAppVersions: [String]?
    public private(set) var OdrChannel: [String: Any]?
    public private(set) var webUrl: [String: String]?
    public private(set) var hideGoToMobileWeb: [String]?
    public private(set) var appendVersion: [String]?
    public private(set) var hideLiveCasinoAppVersions: [String]?
    public private(set) var betaEnvAppVersions: [String]?

    public init(feature: DynaconFeature) {
        super.init()
        
        if let noGeoblock = feature.dictionaryFieldWithName(fieldName: "noGeoblock")?.value,
           noGeoblock.keys.count > 0 {
            self.noGeoblockAppVersions = noGeoblock["appVersions"] as? [String]
        }
        if let hideMoreOption = feature.dictionaryFieldWithName(fieldName: "hideMoreGamesInNativeLobby")?.value,
           hideMoreOption.keys.count > 0 {
            self.hideMoreGamesAppVersions = hideMoreOption["appVersions"] as? [String]
        }
        if let _odrChannel = feature.dictionaryFieldWithName(fieldName: "OdrChannel")?.value {
            self.OdrChannel = _odrChannel
        }
        if let _webUrl = feature.dictionaryFieldWithName(fieldName: "webUrl")?.value as? [String: String] {
            self.webUrl = _webUrl
        }
        if let hideGoToMwebButton = feature.dictionaryFieldWithName(fieldName: "noGoToMobileSiteButton")?.value as? [String: Any] {
            self.hideGoToMobileWeb = hideGoToMwebButton["appVersions"] as? [String]
        }
        if let version = feature.arrayFieldWithName(fieldName: "appendVersion")?.value as? [String] {
            self.appendVersion = version
        }
        if let hideLiveCasino = feature.dictionaryFieldWithName(fieldName: "hideLiveCasino")?.value,
           !hideLiveCasino.keys.isEmpty {
            self.hideLiveCasinoAppVersions = hideLiveCasino["appVersions"] as? [String]
        }
        if let appVersions = feature.dictionaryFieldWithName(fieldName: "betaEnvAppVersions")?.value,
           appVersions.keys.count > 0 {
            self.betaEnvAppVersions = appVersions["appVersions"] as? [String]
        }
    }
}
