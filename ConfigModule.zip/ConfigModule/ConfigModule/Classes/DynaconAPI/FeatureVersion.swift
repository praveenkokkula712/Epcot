//
//  FeatureVersion.swift
//  ConfigModule
//
//  Created by Yemireddi Sateesh on 09/08/23.
//

import Foundation

public enum FeatureVersion: Int {
    case v1 = 1
    case v2
}
