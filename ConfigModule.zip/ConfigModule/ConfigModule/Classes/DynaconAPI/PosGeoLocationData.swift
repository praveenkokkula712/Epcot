//
//  PosGeoLocationData.swift
//  Wrapper
//
//  Created by Vinod Kumar Muppala on 09/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

@objcMembers
public class PosGeoLocationData: NSObject {
    
    public private(set) var countryCode: String?
    public private(set) var resolvedIP: String?
    public private(set) var regionCode: String?
    public private(set) var region: String?
    public private(set) var longitude: String?
    public private(set) var latitude: String?
    public private(set) var countryName: String?
    

    public init(json : Dictionary<String, Any>) {
        self.countryCode = json["countryCode"] as? String
        self.resolvedIP = json["resolvedIP"] as? String
        self.regionCode = json["regionCode"] as? String
        self.region = json["region"] as? String
        self.longitude = json["longitude"] as? String
        self.latitude = json["latitude"] as? String
        self.countryName = json["countryName"] as? String
    }

    public init(CountryCode : String, ResolvedIP : String) {
        self.countryCode = CountryCode
        self.resolvedIP = ResolvedIP
    }

}