//
//  DynaconAPIConfiguration.swift
//  CasinoAPI
//
//  Created by Yemireddi Sateesh on 09/06/23.
//

import Foundation
import Utility

public enum ProductType {
    case casino
    case sports
    case bingo
}

public class DynaconAPIConfiguration {

    // MARK: - Properties
    private static var instance: DynaconAPIConfiguration?
    // singleton
    public class weak var shared: DynaconAPIConfiguration? {
        self.instance = self.instance ?? DynaconAPIConfiguration()
        return self.instance
    }
    
    
    public var posAppConfig: PosAppConfiguration?
    public var geoLocationData: PosGeoLocationData?
    
    // MARK: - Init
    private init() { }
    
    public private(set) var appConfigs: AppConfigurations?
    var dynaconConfigs: DynaconConfigurations?
    var delegate: DefaultConfigurationsDelegate?
    internal var serviceLayer: SiteCoreServiceLayer?

    public class func disposeShared() {
        instance = nil
    }
    
    public func setupConfigs(with configs: AppConfigurations,
                             dynconConfigs: DynaconConfigurations,
                             defaultConfigs: DefaultConfigurationsDelegate?,
                             shouldFetchDynacon: Bool = false,
                             configDelegate: DynaconAPIConfigurationDelegate? = nil,
                             completion:(() -> Void)?  = nil) {
        self.appConfigs = configs
        self.dynaconConfigs = dynconConfigs
        self.delegate = defaultConfigs
        
        if shouldFetchDynacon && posAppConfig == nil {
            let entries = [DynaconBatchEntry(type: .appConfiguration), DynaconBatchEntry(type: .geoLocation)]
            Task {
                let apiResponse = try await DynaconBatchService().fetchBatchData(with: entries)
                if let response = apiResponse as? [Any],
                   !response.isEmpty {
                    DynaconAPIConfiguration.shared?.setupConfigurations()
                    
                    let posConfigs = POSConfigs(baseUrl: self.dynaconConfigs?.environmentPOSURL ?? "",
                                                accessId: self.dynaconConfigs?.accessID ?? "",
                                                language: self.appConfigs?.language ?? "en")
                    let sitecoreEntries = SiteCoreOtherEntries(spotLightSearchEnabled: false,
                                                               threeDTouchEnabled: false,
                                                               showHeaderRegulatory: false)
                    DynaconAPIConfiguration.shared?.callSiteCoreServices(with: posConfigs,
                                                                         sitecoreEntries: sitecoreEntries,
                                                                         delegate: configDelegate)
                }
                completion?()
            }
        } else {
            completion?()
         }
    }
}
