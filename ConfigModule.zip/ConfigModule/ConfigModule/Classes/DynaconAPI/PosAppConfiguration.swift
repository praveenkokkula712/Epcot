//
//  PosAppConfiguration.swift
//  Wrapper
//
//  Created by Harshita Sai Adagarla on 04/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

@objcMembers
public class PosAppConfiguration: NSObject {
    
    public private(set) var features: PosAppConfigurationFeatures?
    public private(set) var feedback: PosAppConfigurationFeedback?
    public private(set) var general : PosAppConfigurationGeneral?
    public private(set) var sibling: PosAppConfigurationSibling?
    public private(set) var chromeTab: PosAppConfigurationChromeTab?
    public private(set) var portal: PosAppConfigurationPortal?
    public private(set) var sensitivePages: PosAppConfigurationSensitivePages?
    public private(set) var sliderGameSensitivePages: PosAppConfigurationSliderGameSensitivePages?
    public private(set) var services: PosAppConfigurationServices?
    public private(set) var sliderGames: PosAppConfigurationSliderGames?
    public private(set) var tracker: PosAppConfigurationTracker?
    public private(set) var forceHeader: PosAppConfigurationForceHeader?
    public private(set) var sitecore: PosAppConfigurationSiteCore?
    public private(set) var casino: PosAppConfigurationCasino?
    public private(set) var cashier: PosAppConfigurationCashier?
    public private(set) var versionSpecificFeature: PosAppConfigurationVersionSpecificFeature?
    public private(set) var odrAws: AppConfigurationODRAWS?
    public private(set) var betmgmConfiguration: PosAppConfigurationUnifiedLabel?
    public private(set) var style: AppConfigurationStyle?
    public private(set) var environment: String?
    public private(set) var rnConfig: PosAppConfigurationRNConfig?
    
    private let channel = DynaconAPIConfiguration.shared?.appConfigs?.channel ?? "CNH"

    public init(json: Dictionary<String,Any>, environment: String) {
        let featureSet = DynaconFeatureSet(json)
        if let features = featureSet.featureWithName(featureName: "\(channel)Features") {
            self.features = PosAppConfigurationFeatures(feature: features)
        }
        if let casino = featureSet.featureWithName(featureName: "\(channel)Casino") {
            self.casino = PosAppConfigurationCasino(feature: casino)
        }
        if let cashier = featureSet.featureWithName(featureName: "\(channel)Cashier") {
            self.cashier = PosAppConfigurationCashier(feature: cashier)
        }
        if let feedback = featureSet.featureWithName(featureName: "\(channel)Feedback") {
            self.feedback = PosAppConfigurationFeedback(feature: feedback)
        }
        if let general = featureSet.featureWithName(featureName: "\(channel)General") {
            self.general = PosAppConfigurationGeneral(feature: general)
        }
        if let sibling = featureSet.featureWithName(featureName: "\(channel)Siblings") {
            self.sibling = PosAppConfigurationSibling(feature: sibling)
        }
        if let chromeTab = featureSet.featureWithName(featureName: "\(channel)CustomChromeTabs") {
            self.chromeTab = PosAppConfigurationChromeTab(feature: chromeTab)
        }
        if let portal = featureSet.featureWithName(featureName: "\(channel)Portal") {
            self.portal = PosAppConfigurationPortal(feature: portal)
        }
        if let senstitivePages = featureSet.featureWithName(featureName: "\(channel)SensitivePages") {
            self.sensitivePages = PosAppConfigurationSensitivePages(feature: senstitivePages)
        }
        if let sliderGameSensitivePages = featureSet.featureWithName(featureName: "\(channel)SensitiveForSliderGames") {
            self.sliderGameSensitivePages = PosAppConfigurationSliderGameSensitivePages(feature: sliderGameSensitivePages)
        }
        if let services = featureSet.featureWithName(featureName: "\(channel)Services"){
            self.services = PosAppConfigurationServices(feature: services)
        }
        if let sliderGames = featureSet.featureWithName(featureName: "\(channel)SliderGames") {
            self.sliderGames = PosAppConfigurationSliderGames(feature: sliderGames)
        }
        if let tracker = featureSet.featureWithName(featureName: "\(channel)Trackers") {
            self.tracker = PosAppConfigurationTracker(feature: tracker)
        }
        if let forceHeader = featureSet.featureWithName(featureName: "\(channel)ForceHeader") {
            self.forceHeader = PosAppConfigurationForceHeader(feature: forceHeader)
        }
        if let sitecore = featureSet.featureWithName(featureName: "\(channel)SiteCore"){
            self.sitecore = PosAppConfigurationSiteCore(feature: sitecore)
        }
        if let versionFeature = featureSet.featureWithName(featureName: "\(channel)VersionSpecificFeature"){
            self.versionSpecificFeature = PosAppConfigurationVersionSpecificFeature(feature: versionFeature)
        }
        if let odrFeature = featureSet.featureWithName(featureName: "\(channel)ODR") {
            self.odrAws = AppConfigurationODRAWS(feature: odrFeature)
        }
        if let config = featureSet.featureWithName(featureName: "\(channel)Style") {
            self.style = AppConfigurationStyle(feature: config)
        }
        if let config = featureSet.featureWithName(featureName: "UnifiedAppConfiguration") {
            self.betmgmConfiguration = PosAppConfigurationUnifiedLabel(feature: config)
        }
        if let rnConfig = featureSet.featureWithName(featureName: "\(channel)RNConfig") {
            self.rnConfig = PosAppConfigurationRNConfig(feature: rnConfig)
        }
        self.environment = environment
    }
}
