//
//  FeedbackRatingViewType.swift
//  Wrapper
//
//  Created by Rajani Bhimanadham on 08/03/23.
//  Copyright © 2023 bwin.com. All rights reserved.
//

import Foundation

public enum FeedbackRatingViewType: Int {
    case versionOne = 1
    case versionTwo = 2
    case versionThree = 3
    case versionFour = 4
}

public enum ForceUpdateViewVersion: Int {
    case one = 1
    case two = 2
    case three = 3
    case four = 4
}

public enum MaintenanceScreenVersion: Int {
    case one = 1
    case two = 2
}
