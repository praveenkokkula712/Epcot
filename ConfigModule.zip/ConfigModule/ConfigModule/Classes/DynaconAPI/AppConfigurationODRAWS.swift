//
//  AppConfigurationODRAWS.swift
//  Wrapper
//
//  Created by Sateesh Yemireddi on 2/6/20.
//  Copyright © 2020 bwin.com. All rights reserved.
//

import Foundation
import Utility
import CasinoAPI

fileprivate let commonKey = "common"

public struct AppConfigurationODRAWS {
    
    public private(set) var AWSAccessID = ""
    public private(set) var AWSBucketName = ""
    public private(set) var AWSPoolID = ""
    public private(set) var AWSSecretKey = ""
    public private(set) var defaultCurrency = ""
    public private(set) var enableODR = false
    public private(set) var region = 3 // Default US
    public private(set) var gameControllerFileName = ""
    public private(set) var gameControllerPath = ""
    public private(set) var gameControllerVersion = ""
    public private(set) var channelId = ""
    public private(set) var geoVariant = ""
    public private(set) var localServerPort: UInt = 9899
    public private(set) var liveGameProviders = [String]()
    public private(set) var liveGames = [String]()
    public private(set) var demoUsers = [String]()
    public private(set) var gameServerIp = "real.partygaming.com"
    public private(set) var gameServerPort = "2147"
    public private(set) var showPlayMode = false
    public private(set) var shouldReloadLobbyPostLogin = false
    public private(set) var gameResourceeMappingFileName = ""
    public private(set) var gameResourceeMappingPath = ""
    public private(set) var gameResourceeMappingVersion = ""
    public private(set) var gameLaunchQueryParams = ""
    public private(set) var htmlGameLaunchQueryParams = ""
    public private(set) var launchWebGameQueryParams = ""
    public private(set) var htmlQueryValues:[String: Any]?
    public private(set) var launchType = ""
    public private(set) var invokerProduct = "CASINO"
    public private(set) var lobbyType = "Native"
    public private(set) var brandDNS = ""
    public private(set) var lobbyView = 1
    public private(set) var lobbyHeaderViewType = 0
    public private(set) var rtmsServerUrl = ""
    public private(set) var sSUrl = ""
    public private(set) var sSFeatureid = ""
    public private(set) var ssMaxTime = ""
    public private(set) var ssFrequencyTime = ""
    public private(set) var downloadFromAWSPrefixUrl = true
    public private(set) var gamesCacheCount: Int = 5
    public private(set) var isScreenLogsEnabled = false
    public private(set) var idealTimeForOneHourPopup = 1
    public private(set) var sessionTimeForOneHourPopup = 1
    public private(set) var versionForEasyNav = 2
    public private(set) var unifiedProviders = [String]()
    public private(set) var shouldDisplayBottomSearch = false
    public private(set) var isHomePillNeeded = false
    public private(set) var shouldDisplaySearchMoreTile = false
    public private(set) var shouldDisplayRecentlyPlayedGames = false
    public private(set) var shouldDisplayPlayerStatsGames = false
    public private(set) var shouldDisplayBetmgmOriginalsView = false
    public private(set) var shouldDisplayFavouriteGames = false
    public private(set) var gridSearchTilePosition = 12
    public private(set) var shouldIncludeRefreshControl = true
    public private(set) var supportedGameLang: [String]?
    public private(set) var recentlyPlayedGamesLimit:Int?
    public private(set) var isAutoLogoutFeatureEnabled = false
    public private(set) var gameImageFolder: [String: Any]?
    public private(set) var enableVoiceSearch = false
    public private(set) var isDemoMode: Bool = false
    public private(set) var allowJailBrokenDevice: Bool = false
    public private(set) var rtmsServerUrlForPlayBreak = ""
    public private(set) var teasersConfigurations: TeaserDynaconConfig?
    public private(set) var embeddedBannersConfigurations: EmbeddBannerDynaconConfig?
    public private(set) var gameFolderAWSPath: [String:String]?
    public private(set) var gameDownloadMode: GameDownloadMode?
    public private(set) var isLightWeightEnabled: Bool = false
    public private(set) var cloudFrontBasePath: String?
    public private(set) var gameResourceInfoMappingVersionId: String?
    public private(set) var gameControllerCloudFrontPath: String?
    public private(set) var gameControllerVersionId: String?
    public private(set) var gameResourceInfoMappingCloudFrontPath: String?
    public private(set) var gameResourceInfoMappingFileName: String?
    public private(set) var shouldUseDefaultConfigurationDualMode: Bool = false
    public private(set) var immersiveGameImageFolder:[String: Any]?
    public private(set) var immersiveSectionLayoutOrder: [Int]?
    public private(set) var localLMTResponse: [String: Any]?
    public private(set) var isCustomThemeEnabled: Bool = false
    public private(set) var isJackpotAutoScrollEnabled: Bool = false
    public private(set) var horizontalScrollLimitForImmersive: Int = 12
    public private(set) var cloudFrontQueryString: String?
    public private(set) var gameMediaAssetVersionId: String?
    public private(set) var gameMediaAssetCloudFrontPath: String?
    public private(set) var gameMediaAssetFileName: String?
    public private(set) var enableIdleTimeToaster: Bool = false
    public private(set) var isFeedLogNeeded: Bool = false
    public private(set) var favouriteButtonIcon: [String: Any]?
    public private(set) var favoriteToastConfigurations: FavoriteToastConfig?
    public private(set) var toastersDisplayTime: Int?
    public private(set) var overlaysDisplayTime: Int?
    public private(set) var shouldDisplayRegulatoryAlerts: Bool?
    public private(set) var mobileHtmlConfiguration: MobileHtmlConfiguration?
    public private(set) var htmlGameDownloadConfigurations: HtmlGameDownloadConfigurations?
    public private(set) var gameDirectoryVendorsPath = [String]()
    public private(set) var imageCacheExpirationConfig: ImageCacheExpirationConfig?
    public private(set) var overlaysConfigurations: OverlaysAndToasterConfigurations?
    public private(set) var gameTileItemsConfiguration: GameTileItemsConfiguration?
    public private(set) var ezNavHtmlUrl: String?
    public private(set) var playtechConfig: AppConfigurationPlayTechODR?
    public private(set) var gameStoriesConfigurations: GameStoriesConfig?
    public private(set) var isOntarioLabel: Bool?
    public private(set) var searchConfig: SearchConfiguration?
    public private(set) var bingoWidgetDNS: BingoWidgetDNS?
    public private(set) var gamePremiereConfigurations: GamePremiereConfig?
    public private(set) var playerStatsConfigurations: PlayerStatsConfig?
    public private(set) var textAlignmentForJackpot: JackpotTitleAlignment?

    //Bingo Widget
    public private(set) var bingoWidget: BingoWidget?
    public private(set) var isExtendedCategoriesFetchEnabled: Bool? = false
    public private(set) var memoryAvailableToUse: Int?
    public private(set) var appUsedMemory: Int?
    public private(set) var memoryToBeCleared: Int?
    public private(set) var liveCasinoLMTConfig: LiveCasinoConfig?
    public private(set) var categoryDisplayConfiguration: CategoryDisplayConfiguration?
    public private(set) var prominentFreeSpinsConfig: ProminentFreeSpinsConfig?
    public private(set) var sessionLimitsConfig: SessionLimitsConfigurations?
    public private(set) var liveFeedCasinoConfiguration: LiveFeedCasinoConfiguration?
    
    public private(set) var engagementToolsConfig: EngagementToolsConfig?
    public private(set) var engagementToolsOrderConfig: EngagementToolsOrderConfig?

    private let apiConfig = DynaconAPIConfiguration.shared

    //jackpotFireIconName for displaying icon
    public private(set) var jackpotFireIconName: String?
    public private(set) var jackpotTileType: JackpotTileType?

    public init(feature: DynaconFeature) {
        self.lobbyView = feature.numberFieldWithName(fieldName: "lobbyView")?.value?.intValue ?? 1
        self.lobbyHeaderViewType = feature.numberFieldWithName(fieldName: "lobbyheaderViewType")?.value?.intValue ?? 0
        
        self.invokerProduct = feature.stringFieldWithName(fieldName: "invokerProduct")?.value ?? "CASINO"
        if let lobbyVersions = feature.dictionaryFieldWithName(fieldName: "lobbyVersions")?.value as? [String: String],
           let bundleVersion = apiConfig?.appConfigs?.bundleShortVersion {
            self.lobbyType = lobbyVersions[bundleVersion] ?? feature.stringFieldWithName(fieldName: "lobbyType")?.value ?? "Native"
        } else {
            self.lobbyType = feature.stringFieldWithName(fieldName: "lobbyType")?.value ?? "Native"
        }
        self.brandDNS = feature.stringFieldWithName(fieldName: "brandDNS")?.value ?? ""
        if let liveCasinoConfig = feature.dictionaryFieldWithName(fieldName: "liveCasinoLMTConfiguration")?.value as? [String: Any] {
            self.liveCasinoLMTConfig = try? liveCasinoConfig.data()?.jsonDecoder(LiveCasinoConfig.self).get()
        }
        self.ezNavHtmlUrl = feature.stringFieldWithName(fieldName: "ezNavHtmlUrl")?.value ?? ""
        if let demoVersions = feature.dictionaryFieldWithName(fieldName: "demoVersion")?.value as? [String: Bool],
           let bundleVersion = apiConfig?.appConfigs?.bundleShortVersion {
            self.isDemoMode = demoVersions[bundleVersion] ?? false
        }
        
        if let demoVersions = feature.dictionaryFieldWithName(fieldName: "demoUser")?.value as? [String: [String]],
           let bundleVersion = apiConfig?.appConfigs?.bundleShortVersion {
            self.demoUsers = demoVersions[bundleVersion] ?? [""]
        }
        
        if let enableODRVersion = feature.dictionaryFieldWithName(fieldName: "enableODRBasedOnVersion")?.value as? [String: Bool],
           let bundleVersion = apiConfig?.appConfigs?.bundleShortVersion {
            self.enableODR = enableODRVersion[bundleVersion] ?? false
        } else {
            self.enableODR = feature.boolFieldWithName(fieldName: "enableODR")?.value ?? false
        }
        
        self.launchType = feature.stringFieldWithName(fieldName: "launchType")?.value ?? ""
        self.gameLaunchQueryParams = feature.stringFieldWithName(fieldName: "gameLaunchQueryParams")?.value ?? ""
        self.htmlGameLaunchQueryParams = feature.stringFieldWithName(fieldName: "htmlGameLaunchQueryParams")?.value ?? ""
        self.launchWebGameQueryParams = feature.stringFieldWithName(fieldName: "launchWebGameQueryParams")?.value ?? ""
        self.htmlQueryValues = feature.dictionaryFieldWithName(fieldName: "htmlQueryValues")?.value ?? [:]
        self.gameLaunchQueryParams += "&isIpad=\(UIDevice.isIPad())"
        self.AWSPoolID = feature.stringFieldWithName(fieldName: "AWSPoolID")?.value ?? ""
        self.defaultCurrency = feature.stringFieldWithName(fieldName: "defaultCurrency")?.value ?? ""
        self.enableVoiceSearch = feature.boolFieldWithName(fieldName: "enableVoiceSearch")?.value ?? false
        
        if let gameController = (apiConfig?.appConfigs?.isInternalBuild ?? true) ?
            feature.dictionaryFieldWithName(fieldName: "gameController")?.value : feature.dictionaryFieldWithName(fieldName: "appstoreGameController")?.value {
            self.gameControllerFileName = gameController["filename"] as? String ?? ""
            self.gameControllerPath = gameController["path"] as? String ?? ""
            if let version = apiConfig?.appConfigs?.gameControllerVersion,
               version.count > 0 {
                self.gameControllerVersion = version
            } else {
                self.gameControllerVersion = gameController["version"] as? String ?? ""
            }
            
        }
        self.channelId = feature.stringFieldWithName(fieldName: "gameChannel")?.value ?? ""
        self.geoVariant = feature.stringFieldWithName(fieldName: "geoVariant")?.value ?? ""
        self.isFeedLogNeeded = feature.boolFieldWithName(fieldName: "isFeedLogNeeded")?.value ?? false
        
        self.localServerPort = feature.numberFieldWithName(fieldName: "localServerPort")?.value?.uintValue ?? 9899
        if let liveGamesInfo = feature.dictionaryFieldWithName(fieldName: "liveGamesInfo")?.value {
            self.liveGameProviders = liveGamesInfo["provider"] as? [String] ?? []
            self.liveGames = liveGamesInfo["games"] as? [String] ?? []
        }
        if let gameServer = feature.dictionaryFieldWithName(fieldName: "gameServer")?.value {
            self.gameServerIp = gameServer["ip"] as? String ?? "real.partygaming.com"
            self.gameServerPort = gameServer["port"] as? String ?? "2147"
        }
        self.showPlayMode = feature.boolFieldWithName(fieldName: "showPlayMode")?.value ?? false
        self.shouldReloadLobbyPostLogin = feature.boolFieldWithName(fieldName: "shouldReloadLobbyPostLogin")?.value ?? false
        if let gameResourceMapping = feature.dictionaryFieldWithName(fieldName: "gameResourceInfoMapping")?.value {
            self.gameResourceeMappingFileName = gameResourceMapping["filename"] as? String ?? ""
            self.gameResourceeMappingPath = gameResourceMapping["path"] as? String ?? ""
            self.gameResourceeMappingVersion = gameResourceMapping["version"] as? String ?? ""
        }
        self.rtmsServerUrl = feature.stringFieldWithName(fieldName: "RTMSServerUrl")?.value ?? ""
        self.rtmsServerUrlForPlayBreak = feature.stringFieldWithName(fieldName: "RTMSServerUrlForARCPlayBreak")?.value ?? ""
        
        self.sSUrl = feature.stringFieldWithName(fieldName: "SlotSessionUrl")?.value ?? ""
        self.sSFeatureid = feature.stringFieldWithName(fieldName: "SlotSessionFeatureId")?.value ?? ""
        
        self.ssMaxTime = feature.stringFieldWithName(fieldName: "SlotSessionMaxTime")?.value ?? ""
        self.ssFrequencyTime = feature.stringFieldWithName(fieldName: "SlotSessionFrequencyTime")?.value ?? ""
        self.downloadFromAWSPrefixUrl = feature.boolFieldWithName(fieldName: "downloadFromAWSPrefixUrl")?.value ?? true
        self.gamesCacheCount = feature.numberFieldWithName(fieldName: "gamesCacheCount")?.value?.intValue ?? 5
        self.isScreenLogsEnabled = feature.boolFieldWithName(fieldName: "isScreenLogsEnabled")?.value ?? false
        self.idealTimeForOneHourPopup = feature.numberFieldWithName(fieldName: "IdealTimeForOneHourPopup")?.value?.intValue ?? 1
        self.sessionTimeForOneHourPopup = feature.numberFieldWithName(fieldName: "SessionTimeForOneHourPopup")?.value?.intValue ?? 1
        self.horizontalScrollLimitForImmersive = feature.numberFieldWithName(fieldName: "horizontalScrollLimitForImmersive")?.value?.intValue ?? 12
        self.shouldDisplaySearchMoreTile = feature.boolFieldWithName(fieldName: "shouldDisplaySearchMoreTile")?.value ?? false
        self.shouldDisplayRecentlyPlayedGames = feature.boolFieldWithName(fieldName: "shouldDisplayRecentlyPlayedGames")?.value ?? false
        self.shouldDisplayPlayerStatsGames = feature.boolFieldWithName(fieldName: "shouldDisplayPlayerStatsGames")?.value ?? false
        self.shouldDisplayBetmgmOriginalsView = feature.boolFieldWithName(fieldName: "shouldDisplayBetmgmOriginalsView")?.value ?? false
        self.shouldDisplayFavouriteGames = feature.boolFieldWithName(fieldName: "shouldDisplayFavouriteGames")?.value ?? false
        if let mobileConfig = feature.dictionaryFieldWithName(fieldName: "mobileHtmlConfiguration")?.value as? [String: Any] {
            self.mobileHtmlConfiguration = self.prepareMobileHtmlConfiguration(from: mobileConfig)
        }
        
        if let htmlDownloadConfig = feature.dictionaryFieldWithName(fieldName: "htmlGameDownloadConfigurations")?.value as? [String: Any] {
            self.htmlGameDownloadConfigurations = self.prepareHtmlGameDownloadConfiguration(from: htmlDownloadConfig)
        }
        self.shouldDisplayBottomSearch = feature.boolFieldWithName(fieldName: "shouldDisplayBottomSearch")?.value ?? false
        self.isHomePillNeeded = feature.boolFieldWithName(fieldName: "isHomePillNeeded")?.value ?? false
        self.toastersDisplayTime = feature.numberFieldWithName(fieldName: "rtmsToasterDisplayTimeDuration")?.value?.intValue ?? 1
        self.overlaysDisplayTime = feature.numberFieldWithName(fieldName: "overlaysDisplayTimeDuration")?.value?.intValue ?? 1
        self.versionForEasyNav = feature.numberFieldWithName(fieldName: "versionForEasyNav")?.value?.intValue ?? 2
        self.gridSearchTilePosition = feature.numberFieldWithName(fieldName: "gridSearchTilePosition")?.value?.intValue ?? 12
        if let list = feature.dictionaryFieldWithName(fieldName: "AWSCasinoGames")?.value {
            if let value = list["iOSEncryptedValue"] as? String,
               let json = AESDecryption.decryptedData(with: value, key: apiConfig?.appConfigs?.kinesisEncryptedKey ?? "") {
                self.AWSAccessID = json["AWSAccessID"] as? String ?? ""
                self.AWSBucketName = json["AWSBucketName"] as? String ?? ""
                self.AWSSecretKey = json["AWSSecretKey"] as? String ?? ""
                self.region = json["region"] as? Int ?? 3
            }
        }
        if let _unifiedVendors = feature.arrayFieldWithName(fieldName: "unifiedProviders")?.value as? [String] {
            self.unifiedProviders = _unifiedVendors
        }
        
        if let gameDirectoryVendorsPath = feature.arrayFieldWithName(fieldName: "gameDirectoryVendorsPath")?.value as? [String] {
            self.gameDirectoryVendorsPath = gameDirectoryVendorsPath
        }
        
        if let overlayToasters = feature.dictionaryFieldWithName(fieldName: "shouldDisplayOverlayToaster")?.value {
            self.overlaysConfigurations = self.prepareOverlaysAndToastersConfigFromJson(overlayToasters: overlayToasters)
        }
        
        self.shouldIncludeRefreshControl = feature.boolFieldWithName(fieldName: "shouldIncludeRefreshControl")?.value ?? true
        self.supportedGameLang = feature.arrayFieldWithName(fieldName: "supportedLanguages")?.value as? [String]
        self.recentlyPlayedGamesLimit = feature.numberFieldWithName(fieldName: "recentlyPlayedGamesLimit")?.value?.intValue
        self.isAutoLogoutFeatureEnabled = feature.boolFieldWithName(fieldName: "isAutoLogoutFeatureEnabled")?.value ?? false
        self.isCustomThemeEnabled = feature.boolFieldWithName(fieldName: "isCustomThemeEnabled")?.value ?? false
        self.isJackpotAutoScrollEnabled = feature.boolFieldWithName(fieldName: "isJackpotAutoScrollEnabled")?.value ?? false
        self.enableIdleTimeToaster = feature.boolFieldWithName(fieldName: "enableIdleTimeToaster")?.value ?? false
        self.gameImageFolder = feature.dictionaryFieldWithName(fieldName: "gameImageFolder")?.value
        self.allowJailBrokenDevice = feature.boolFieldWithName(fieldName: "allowJailBrokenDevice")?.value ?? true
        self.shouldDisplayRegulatoryAlerts = feature.boolFieldWithName(fieldName: "shouldDisplayRegulatoryAlerts")?.value ?? false
        self.isExtendedCategoriesFetchEnabled = feature.boolFieldWithName(fieldName: "isExtendedCategoriesFetchEnabled")?.value ?? false
        
        let textAlignment = feature.numberFieldWithName(fieldName: "textAlignmentForJackpot")?.value?.intValue ?? 0
        self.textAlignmentForJackpot = JackpotTitleAlignment(rawValue: textAlignment) ?? .left
        
        
        // Fetches game folder aws path for beta and appstore from dynacon. For example,
        /*
         {
         "common": {
         "igt": "nj",
         "konami": "nj"
         },
         "23.04.12": {
         "igt": "us"
         }
         }
         */
        // Read `common` data from dynacon.
        // Read `appVersion` specific data from dynacon.
        // Merge `common` data, if available, with `appVersion` specific data, else use `appVersion` specific data.
        // Final data for game folder aws path would be, for example,
        /*
         {
         "igt": "us",
         "konami": "nj"
         }
         */
        let gameFolderAwsPathKey = (apiConfig?.appConfigs?.isInternalBuild ?? false) ? "betaGameFolderAWSPath" : "appstoreGameFolderAWSPath"
        if let gameFolderAwsPathDataFrame = feature.dictionaryFieldWithName(fieldName: gameFolderAwsPathKey)?.value as? [String: Any] {
            if let commonDataFrame = gameFolderAwsPathDataFrame[commonKey] as? [String: String] {
                self.gameFolderAWSPath = commonDataFrame
            }
            if let currentAppVersion = Bundle.main.version,
               let appVersionSpecificDataFrame = gameFolderAwsPathDataFrame.first(where: { $0.key == currentAppVersion })?.value as? [String: String] {
                if self.gameFolderAWSPath != nil {
                    for (key, value) in appVersionSpecificDataFrame {
                        self.gameFolderAWSPath?[key] = value
                    }
                } else {
                    self.gameFolderAWSPath = appVersionSpecificDataFrame
                }
            }
        }
        
        // Fetches lru cache thresholds for beta and appstore from dynacon. For example,
        /*
         {
         "common": {
         "memoryAvailableToUse": 25,
         "appUsedMemory": 10,
         "memoryToBeCleared": 25
         },
         "23.04.12": {
         "memoryAvailableToUse": 50
         }
         }
         */
        // Read `common` data from dynacon.
        // Read `appVersion` specific data from dynacon.
        // Merge `common` data, if available, with `appVersion` specific data, else use `appVersion` specific data.
        // Final data for lru cache thresholds would be with version specific, for example,
        /*
         {
         "memoryAvailableToUse": 50,
         "appUsedMemory": 10,
         "memoryToBeCleared": 25
         }
         */
        let lruThresholdsKey = (apiConfig?.appConfigs?.isInternalBuild ?? false) ? "betaLruThresholds" : "appstoreLruThresholds"
        if let lruThresholdsDataFrame = feature.dictionaryFieldWithName(fieldName: lruThresholdsKey)?.value as? [String: Any] {
            if let commonDataFrame = lruThresholdsDataFrame[commonKey] as? [String: String] {
                self.memoryAvailableToUse = commonDataFrame["memoryAvailableToUse"] as? Int
                self.appUsedMemory = commonDataFrame["appUsedMemory"] as? Int
                self.memoryToBeCleared = commonDataFrame["memoryToBeCleared"] as? Int
            }
            if let currentAppVersion = Bundle.main.version,
               let appVersionSpecificDataFrame = lruThresholdsDataFrame.first(where: { $0.key == currentAppVersion })?.value as? [String: String] {
                if let memoryAvailableToUse = appVersionSpecificDataFrame["memoryAvailableToUse"] as? Int {
                    self.memoryAvailableToUse = memoryAvailableToUse
                }
                if let appUsedMemory = appVersionSpecificDataFrame["appUsedMemory"] as? Int {
                    self.appUsedMemory = appUsedMemory
                }
                if let memoryToBeCleared = appVersionSpecificDataFrame["memoryToBeCleared"] as? Int {
                    self.memoryToBeCleared = memoryToBeCleared
                }
            }
        }
        
        // Dual mode related flags
        // Fetches dual mode configuration for beta and appstore from dynacon. For example,
        /*
         {
         "common": {
         "cloudFront": "http://d144cxtlabhsuj.cloudfront.net/",
         "gameControllerPath": "resources",
         "gameControllerVersion": "1234567890",
         "grimPath": "resources/${dynacon:label}",
         "cloudFrontQueryString": "versionId"
         },
         "23.04.12": {
         "gameControllerVersion": "asdfghjkl"
         }
         }
         */
        // Read `common` data from dynacon.
        // Read `appVersion` specific data from dynacon.
        // Merge `common` data, if available, with `appVersion` specific data, else use `appVersion` specific data.
        // Final data for dual mode configuration would be, for example,
        /*
         {
         "cloudFront": "http://d144cxtlabhsuj.cloudfront.net/",
         "gameControllerPath": "resources",
         "gameControllerVersion": "asdfghjkl",
         "grimPath": "resources/${dynacon:label}",
         "cloudFrontQueryString": "versionId"
         }
         */
        let dualModeConfigKey = (apiConfig?.appConfigs?.isInternalBuild ?? true) ? "betaDualModeConfigurationV2" : "appstoreDualModeConfigurationV2"
        if let dualModeConfigDataFrame = feature.dictionaryFieldWithName(fieldName: dualModeConfigKey)?.value as? [String: Any] {
            if let dualModeConfigCommonData = dualModeConfigDataFrame[commonKey] as? [String: Any] {
                self.gameResourceInfoMappingCloudFrontPath = dualModeConfigCommonData["grimPath"] as? String
                self.cloudFrontBasePath = dualModeConfigCommonData["cloudFront"] as? String
                self.gameControllerCloudFrontPath = dualModeConfigCommonData["gameControllerPath"] as? String
                self.gameControllerVersionId = dualModeConfigCommonData["gameControllerVersion"] as? String
                self.cloudFrontQueryString = dualModeConfigCommonData["cloudFrontQueryString"] as? String
            }
            if let currentAppVersion = Bundle.main.version,
               let dualModeConfigAppVersionSpecificData = dualModeConfigDataFrame.first(where: { $0.key == currentAppVersion })?.value as? [String: Any] {
                if let gameResourceInfoMappingCloudFrontPath = dualModeConfigAppVersionSpecificData["grimPath"] as? String {
                    self.gameResourceInfoMappingCloudFrontPath = gameResourceInfoMappingCloudFrontPath
                }
                if let cloudFrontBasePath = dualModeConfigAppVersionSpecificData["cloudFront"] as? String {
                    self.cloudFrontBasePath = cloudFrontBasePath
                }
                if let gameControllerCloudFrontPath = dualModeConfigAppVersionSpecificData["gameControllerPath"] as? String {
                    self.gameControllerCloudFrontPath = gameControllerCloudFrontPath
                }
                if let gameControllerVersionId = dualModeConfigAppVersionSpecificData["gameControllerVersion"] as? String {
                    self.gameControllerVersionId = gameControllerVersionId
                }
                if let cloudFrontQueryString = dualModeConfigAppVersionSpecificData["cloudFrontQueryString"] as? String {
                    self.cloudFrontQueryString = cloudFrontQueryString
                }
            }
        }
        
        let resourceVersionKey = (apiConfig?.appConfigs?.isInternalBuild ?? true) ? "betaResourcesVersionV2" : "appstoreResourceVersionV2"
        if let resourcesInfo = feature.dictionaryFieldWithName(fieldName: resourceVersionKey)?.value {
            // If `common` is found in Dynacon data then use it
            if let resourcesInfoCommonData = resourcesInfo[commonKey] as? [String: Any] {
                if let gameDownloadModeRawValue = resourcesInfoCommonData["gameDownloadMode"] as? Int {
                    self.gameDownloadMode = GameDownloadMode(rawValue: gameDownloadModeRawValue)
                }
                self.isLightWeightEnabled = resourcesInfoCommonData["isLightWeight"] as? Bool ?? false
                self.gameResourceInfoMappingVersionId = resourcesInfoCommonData["grimVersionId"] as? String
                self.shouldUseDefaultConfigurationDualMode = false
            }
            // If `appVersion` is found in Dynacon data, merge with `common` then use it or else use default configuration
            if let currentAppVersion = Bundle.main.version,
               let resourceInfo = resourcesInfo.first(where: { $0.key == currentAppVersion })?.value as? [String: Any] {
                if let gameDownloadModeRawValue = resourceInfo["gameDownloadMode"] as? Int {
                    self.gameDownloadMode = GameDownloadMode(rawValue: gameDownloadModeRawValue)
                }
                if let isLightWeightEnabled = resourceInfo["isLightWeight"] as? Bool {
                    self.isLightWeightEnabled = isLightWeightEnabled
                }
                if let gameResourceInfoMappingVersionId = resourceInfo["grimVersionId"] as? String {
                    self.gameResourceInfoMappingVersionId = gameResourceInfoMappingVersionId
                }
                self.shouldUseDefaultConfigurationDualMode = false
            } else if let isInternalBuild = apiConfig?.appConfigs?.isInternalBuild, isInternalBuild,
                      let gameResourceMapping = feature.dictionaryFieldWithName(fieldName: "grim_gma_digital_dev")?.value {
                // Default to AWS mode if not found in resourcesVersion Dynacon
                self.gameDownloadMode = .aws
                self.isLightWeightEnabled = false
                self.gameResourceInfoMappingVersionId = gameResourceMapping["version"] as? String
                self.gameResourceInfoMappingCloudFrontPath = gameResourceMapping["path"] as? String
                self.gameResourceInfoMappingFileName = gameResourceMapping["filename"] as? String
                self.gameMediaAssetVersionId = gameResourceMapping["gmaVersionId"] as? String
                self.gameMediaAssetCloudFrontPath = self.gameResourceInfoMappingCloudFrontPath
                if let gmaPath = gameResourceMapping["gmaPath"] as? String {
                    self.gameMediaAssetCloudFrontPath = gmaPath
                }
                self.gameMediaAssetFileName = gameResourceMapping["gmaFilename"] as? String
                self.shouldUseDefaultConfigurationDualMode = true
            }
        }
        
        self.immersiveGameImageFolder = feature.dictionaryFieldWithName(fieldName: "immersiveGameImageFolder")?.value as? [String: Any]
        if let priorityDict = feature.dictionaryFieldWithName(fieldName: "immersiveSectionLayoutOrder")?.value as? [String: Any] {
            if let values = priorityDict["layoutPriority"] as? [Int] {
                self.immersiveSectionLayoutOrder = values
            }
        }
        if let teasersInfo = feature.dictionaryFieldWithName(fieldName: "teasersConfigurations")?.value {
            self.teasersConfigurations = self.prepareTeasersConfigModelFromJson(teasersData: teasersInfo)
        }
        
        if let imageCacheExpirationConfig = feature.dictionaryFieldWithName(fieldName: "imageCacheExpirationConfig")?.value {
            self.imageCacheExpirationConfig = self.prepareImageCacheExpirationConfig(config: imageCacheExpirationConfig)
        }
        
        if let bannersInfo = feature.dictionaryFieldWithName(fieldName: "embeddBannerConfiguration")?.value {
            self.embeddedBannersConfigurations = self.prepareBannersConfigModelFromJson(bannersData: bannersInfo)
        }
        self.localLMTResponse = feature.dictionaryFieldWithName(fieldName: "localLMTResponse")?.value as? [String: Any]
        self.favouriteButtonIcon = feature.dictionaryFieldWithName(fieldName: "favouriteButtonIcon")?.value
        if let configData = feature.dictionaryFieldWithName(fieldName: "favoriteToastConfigurations")?.value {
            self.favoriteToastConfigurations = self.prepareFavoriteToastConfigModelFromJson(configData: configData)
        }
        if let itemPositions = feature.arrayFieldWithName(fieldName: "gameTileItemPositions")?.value as? [Int] {
            let config = GameTileItemsConfiguration(
                gameTileItemsPositions: itemPositions
            )
            gameTileItemsConfiguration = config
        }
        if let configuration = feature.dictionaryFieldWithName(
            fieldName: "SearchOptimization"
        )?.value {
            let showCategories = configuration["showCategories"] as? Bool ?? false
            let sections = configuration["sections"] as? [[String: Any]] ?? []
            let layoutType = configuration["resultsLayoutType"] as? Int ?? 1
            let favouriteEnabled = configuration["favouriteEnabled"] as? Bool ?? false
            let downloadIconEnabled = configuration["downloadIconEnabled"] as? Bool ?? false
            let playButtonEnabled = configuration["playButtonEnabled"] as? Bool ?? false
            let stickerEnabled = configuration["stickerEnabled"] as? Bool ?? false
            let jackpotAmountEnabled = configuration["jackpotAmountEnabled"] as? Bool ?? false
            self.searchConfig = SearchConfiguration(
                showCategories: showCategories,
                sections: sections,
                resultsLayout: layoutType,
                favouriteEnabled: favouriteEnabled,
                downloadIconEnabled: downloadIconEnabled,
                playButtonEnabled: playButtonEnabled,
                stickerEnabled: stickerEnabled,
                jackpotEnabled: jackpotAmountEnabled
            )
        }
        
        let playtechConfigKey = (apiConfig?.appConfigs?.isInternalBuild ?? true) ? "betaPlaytechConfiguration" : "appStorePlaytechConfiguration"
        if let configs = feature.dictionaryFieldWithName(fieldName: playtechConfigKey)?.value as? [String: Any] {
            if let commonConfigs = configs["common"] as? [String: Any] {
                var configsData: Data?
                if let bundleVersion = apiConfig?.appConfigs?.bundleShortVersion, let versionBasedConfigs = configs[bundleVersion] as? [String: Any] {
                    let updatedConfigs = commonConfigs.merging(versionBasedConfigs) { $1 }
                    configsData =  try? updatedConfigs.data()
                } else {
                    configsData = try? commonConfigs.data()
                }
                self.playtechConfig = try? configsData?.jsonDecoder(AppConfigurationPlayTechODR.self).get()
            }
        }
        self.isOntarioLabel = feature.boolFieldWithName(fieldName: "isOntarioLabel")?.value
        if let configData = feature.dictionaryFieldWithName(fieldName: "gameStoriesConfigurations")?.value {
            self.gameStoriesConfigurations = self.prepareGameStoriesConfigModelFromJson(configData: configData)
        }
        /*
         if let bingoDNS = feature.dictionaryFieldWithName(fieldName: "bingoWidgetDNS")?.value as? [String: Any] {
         self.bingoWidgetDNS = try? bingoDNS.data()?.jsonDecoder(BingoWidgetDNS.self).get()
         }
         
         if let prominentFreeSpins = feature.dictionaryFieldWithName(fieldName: "prominentFreeSpins")?.value as? [String: Any] {
         if let data = prominentFreeSpins.data() {
         self.prominentFreeSpinsConfig = try? data.jsonDecoder(ProminentFreeSpinsConfig.self).get()
         }
         }
         
         if let bingoWidget = feature.dictionaryFieldWithName(fieldName: "bingoWidget")?.value as? [String: Any] {
         if let data = bingoWidget.data() {
         self.bingoWidget = try? data.jsonDecoder(BingoWidget.self).get()
         }
         }
         */

        if let engagementTools = feature.dictionaryFieldWithName(fieldName: "engagementTools")?.value as? [String: Any] {
            if let data = engagementTools.data() {
                self.engagementToolsConfig = try? data.jsonDecoder(EngagementToolsConfig.self).get()
            }
        }

        if let engagementToolsOrder = feature.dictionaryFieldWithName(
            fieldName: "engagementToolsOrder"
        )?.value as? [String: Any] {
            self.engagementToolsOrderConfig = try? engagementToolsOrder
                .data()?
                .jsonDecoder(EngagementToolsOrderConfig.self)
                .get()
        }

        //gamePremiere configurations
        if let gamePremiereInfo = feature.dictionaryFieldWithName(fieldName: "GamePremiereConfigurations")?.value {
            self.gamePremiereConfigurations = try? gamePremiereInfo
                .data()?
                .jsonDecoder(GamePremiereConfig.self)
                .get()
        }
        
        //jackpotFireIconName for displaying icon
        self.jackpotFireIconName = feature.stringFieldWithName(fieldName: "jackpotFireIconName")?.value
        
        if let categoryDisplayConfiguration = feature.dictionaryFieldWithName(fieldName: "categoryDisplayConfiguration")?.value as? [String: Any] {
            let config = self.prepareCategoryDisplayConfig(with: categoryDisplayConfiguration)
            self.categoryDisplayConfiguration = config
        }
        
        if let playerStatsInfo = feature.dictionaryFieldWithName(fieldName: "PlayerStatsWidgetConfigurations")?.value {
            self.playerStatsConfigurations = try? playerStatsInfo
                .data()?
                .jsonDecoder(PlayerStatsConfig.self)
                .get()
        }
        if let jpTileType = feature.dictionaryFieldWithName(fieldName: "jackpotTileType")?.value as? [String: Any] {
            if let data = jpTileType.data() {
                self.jackpotTileType = try? data.jsonDecoder(JackpotTileType.self).get()
            }
        }

        if let sessionLimits = feature.dictionaryFieldWithName(fieldName: "sessionLimitsConfiguration")?.value as? [String: Any] {
            if let data = sessionLimits.data() {
                self.sessionLimitsConfig = try? data.jsonDecoder(SessionLimitsConfigurations.self).get()
            }
        }
        
        if let liveCasinoConfig = feature.dictionaryFieldWithName(fieldName: "liveFeedCasinoConfiguration")?.value as? [String: Any], 
            let data = liveCasinoConfig.data(),
            let liveFeedCasinoConfiguration = try? data.jsonDecoder(LiveFeedCasinoConfiguration.self).get()  {
            self.liveFeedCasinoConfiguration = liveFeedCasinoConfiguration
        }
    }
    
    private func prepareTeasersConfigModelFromJson(teasersData: [String : Any]?) -> TeaserDynaconConfig? {
        guard let teasersInfo = teasersData, let isTeaserEnbled = teasersInfo["isTeasersEnabled"] as? Bool else {
            return TeaserDynaconConfig(isTeaserEnabled: false)
        }
        guard let teasersMaxCount = teasersInfo["teasersMaxCount"] as? Int,
                let pageControlEnabled = teasersInfo["isTeasersPageControlEnabled"] as? Bool,
                let autoscrollEnabled = teasersInfo["isAutoscrollEnabled"] as? Bool,
                let autoScrollDuration = teasersInfo["teaserAutoScrollDuration"] as? Int else {
            return TeaserDynaconConfig(isTeaserEnabled: isTeaserEnbled)
        }
        let isIpadAutoScrollEnabled = teasersInfo["iPadAutoscrollEnabled"] as? Bool ?? false
       return TeaserDynaconConfig(isTeaserEnabled: isTeaserEnbled,
                                  teasersDisplayLimit: teasersMaxCount,
                                  shouldDisplayPageControl: pageControlEnabled,
                                  isPageControlAutoScrolEnabled: autoscrollEnabled,
                                  durationforAutoScroll: Double(autoScrollDuration),
                                  iPadAutoscrollEnabled: isIpadAutoScrollEnabled)
    }
        
    private func prepareBannersConfigModelFromJson(bannersData: [String : Any]?) -> EmbeddBannerDynaconConfig? {
        guard let bannersInfo = bannersData, let isBannerEnbled = bannersInfo["isBannerEnabled"] as? Bool else {
            return EmbeddBannerDynaconConfig(isEnabled: false)
        }
       guard let bannerPosition = bannersInfo["bannerPosition"] as? Int else {
                 return EmbeddBannerDynaconConfig(isEnabled: isBannerEnbled)
       }
        return EmbeddBannerDynaconConfig(isEnabled: isBannerEnbled,
                                          position: bannerPosition)
    }

    private func prepareFavoriteToastConfigModelFromJson(configData: [String : Any]?) -> FavoriteToastConfig? {
        guard let toastInfo = configData, let isToastEnabled = toastInfo["isFavoriteToastEnabled"] as? Bool else {
            return FavoriteToastConfig(isFavoriteToastEnabled: false)
        }
        guard let favoriteToastTimeout = toastInfo["favoriteToastTimeout"] as? Int,
              let isCTAEnabled = toastInfo["isCTAEnabled"] as? Bool else {
            return FavoriteToastConfig(isFavoriteToastEnabled: isToastEnabled)
        }
        
       return FavoriteToastConfig(isFavoriteToastEnabled: isToastEnabled,
                                  favoriteToastTimeout: favoriteToastTimeout,
                                  isCTAEnabled: isCTAEnabled)
    }
    
    private func prepareOverlaysAndToastersConfigFromJson(overlayToasters: [String : Any]) -> OverlaysAndToasterConfigurations {
        let enableOverlays = overlayToasters["enableOverlays"] as? Bool ?? false
        let enableToasters = overlayToasters["enableToasters"] as? Bool ?? false
        let isOverlaysCTAFullWidth = overlayToasters["isCTAFullWidth"] as? Int ?? 0
        
        return OverlaysAndToasterConfigurations(isOverlaysEnabled: enableOverlays, isToastersEnabled: enableToasters ,isOverlaysCTAFullWidth: String(isOverlaysCTAFullWidth).bool ?? false)
    }
    
    private func prepareMobileHtmlConfiguration(from response: [String: Any]) -> MobileHtmlConfiguration {
        let isEnabled = response["isEnabled"] as? Bool ?? false
        let vendors = response["vendors"] as? [String] ?? [""]
        let ezNavPath = response["ezNavPath"] as? String ?? ""
        return MobileHtmlConfiguration(isEnabled: isEnabled,
                                       vendors: vendors,
                                       ezNavPath: ezNavPath)
    }
    
    private func prepareHtmlGameDownloadConfiguration(from response: [String: Any]) -> HtmlGameDownloadConfigurations {
        let progressEnabled = response["progressEnabled"] as? Bool ?? false
        let htmlPath = response["htmlPath"] as? String ?? ""
        let casinoPath = response["casinoPath"] as? String ?? ""
        return HtmlGameDownloadConfigurations(progressEnabled: progressEnabled, htmlPath: htmlPath, casinoPath: casinoPath)
    }

    private func prepareImageCacheExpirationConfig(config: [String: Any]?) -> ImageCacheExpirationConfig {
        guard let config, let isEnabled = config["isEnabled"] as? Bool else {
            return ImageCacheExpirationConfig(isEnabled: false,
                                              expirationDuration: 30)
        }
        let duration = (config["expirationDuration"] as? Int) ?? 30
        return ImageCacheExpirationConfig(isEnabled: isEnabled,
                                          expirationDuration: duration)
    }
        
    private func prepareGameStoriesConfigModelFromJson(configData: [String: Any]?) -> GameStoriesConfig? {
        guard
            let gameStoriesInfo = configData,
            let isGameStoriesEnabled = gameStoriesInfo["isGameStoriesEnabled"] as? Bool else {
            return GameStoriesConfig(isGameStoriesEnabled: false)
        }
        guard let isHeaderTitleShown = gameStoriesInfo["isHeaderTitleShown"] as? Bool else {
            return GameStoriesConfig(isGameStoriesEnabled: isGameStoriesEnabled)
        }
        guard let subStoryDisplayTime = gameStoriesInfo["subStoryDisplayTime"] as? Int else {
            return GameStoriesConfig(
                isGameStoriesEnabled: isGameStoriesEnabled,
                showHeaderTitle: isHeaderTitleShown
            )
        }
        guard let subStoryCompletionSpeed = gameStoriesInfo["subStoryCompletionSpeed"] as? Double else {
            return GameStoriesConfig(
                isGameStoriesEnabled: isGameStoriesEnabled,
                showHeaderTitle: isHeaderTitleShown,
                subStoryDisplayTime: Double(subStoryDisplayTime)
            )
        }

        let config = GameStoriesConfig(
            isGameStoriesEnabled: isGameStoriesEnabled,
            showHeaderTitle: isHeaderTitleShown,
            subStoryDisplayTime: Double(subStoryDisplayTime),
            subStoryCompletionSpeed: subStoryCompletionSpeed
        )
        return config
    }
    
    private func prepareCategoryDisplayConfig(with json: [String: Any]) -> CategoryDisplayConfiguration {
        let categoryType = json["category"] as? Int
        let subCategoryType = json["subCategory"] as? Int
        let categoryCase = NamingConfiguration(rawValue: categoryType)
        let subCategoryCase = NamingConfiguration(rawValue: subCategoryType)
        return CategoryDisplayConfiguration(category: categoryCase,
                                            subCategory: subCategoryCase)
    }
}

extension AppConfigurationODRAWS {
    var getLanguage: String {
        let supportedLang = self.supportedGameLang ?? supportedGameLanguages
        var lang = DynaconAPIConfiguration.shared?.appConfigs?.language ?? "en_US"
        if supportedLang.contains(lang) {
            return lang
        }
        for gameLang in supportedLang {
            if gameLang.hasPrefix(lang) {
                lang = gameLang
                break
            }
        }
        return lang
    }
}
    
