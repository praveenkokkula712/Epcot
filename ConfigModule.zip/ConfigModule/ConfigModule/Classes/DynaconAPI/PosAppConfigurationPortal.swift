//
//  PosAppConfigurationPortal.swift
//  Wrapper
//
//  Created by Vinod Kumar Muppala on 06/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

@objcMembers
public class PosAppConfigurationPortal: NSObject {
    
    public private(set) var webUrl:String?
    public private(set) var baseUrl:String?
    public private(set) var redirectUrlOnGeoBlock:String?
    public private(set) var postLoginPath:String?
    public private(set) var workflowPath:String?
    public private(set) var contactPath = ""
    public private(set) var registrationPath:String?
    public private(set) var registrationBonusPath:String?
    public private(set) var forgotPasswordPath:String?
    public private(set) var helpPath:String?
    public private(set) var helpResponsibleGamingPath:String?
    public private(set) var isHelpResponsibleGamingPathAvailable = false
    public private(set) var helpSliderBlackjackPath:String?
    public private(set) var helpSliderEuroRoulettePath:String?
    public private(set) var helpSliderPerfectBlackJackProPath:String?
    public private(set) var helpSliderRoulettePath:String?
    public private(set) var forgotUsernamePath: String?
    public private(set) var kycPath: String?
    public private(set) var myAccountPath: String?
    public private(set) var myBonusesPath: String?
    public private(set) var myFreeSpinsPath: String?
    public private(set) var myInboxPath: String?
    public private(set) var menuUrl: String?
    public private(set) var promotionsUrl: String?
    public private(set) var logoutRegex = [String]()
    public private(set) var cookie: String?
    public private(set) var helpBaseUrl: String?
    public private(set) var anyProductUrl: String?
    public private(set) var hasPostLogin = false
    public private(set) var trackingPlaceholders:String?
    public private(set) var nativeCookieSSOParameter: String?
    public private(set) var nativeCookieSSOParameterExceptionList = [String]()
    public private(set) var singleAppUrlHost:String?
    public private(set) var genericUrlHosts: [String]?
    public private(set) var stateSwitcherQueryUrl: String?
    public private(set) var authadaKYCPath:String?
    public private(set) var authadaConfigPath:String?
    public private(set) var authadaChangePinStagingUrl:String?
    public private(set) var idnowKYCPath:String?
    public private(set) var hideHeaderQueryParams: String?
    public private(set) var kycVerificationpath:String?
    public private(set) var hideRGPageQueryParams: String?
    public private(set) var totpMigrationUrl:String?
    public private(set) var skipKycStatus = false
    public private(set) var idnowAutoKycPath: String?
    public private(set) var iOSAuthadaCerHash: [String]?
    public private(set) var rgLogoImagePath: String?
    public private(set) var govtLogoURL: String?
    public private(set) var appendAppVersion = false
    public private(set) var wipeCookies: Bool = false
    public private(set) var appVersionParam: String?
    public private(set) var headerLogoPath: String?
    public private(set) var loginUrl: String?
    public private(set) var loginCancelUrlKey: String?
    public private(set) var shouldReplaceParent = false
    public private(set) var parentRegex: [String]?
    public private(set) var replaceParentPair: [String: String]?
    public private(set) var allowExitLoginFromKyc = false
    public private(set) var addressBarUrls: [String]?
    public private(set) var winNotificationTracking: [String: Any]?
    public private(set) var kycDocumentsPendingPath: String?
    public private(set) var webViewOpaque: Bool = false
    public private(set) var sessionLimitsUpdateUrl: String?
    public private(set) var promoBaseUrl: String?
    public private(set) var geoRestrictedUrls: [String]?

    private let apiConfig = DynaconAPIConfiguration.shared

    public init(feature: DynaconFeature) {
        super.init()

        let webUrlKey = (apiConfig?.appConfigs?.isUnifiedApp ?? false) ? "webUrl" : "newWebUrl"
        self.webUrl = feature.stringFieldWithName(fieldName: webUrlKey)?.value
        self.rgLogoImagePath = feature.stringFieldWithName(fieldName: "rgLogoImagePath")?.value
        self.baseUrl = feature.stringFieldWithName(fieldName: "portalUrl")?.value
        self.redirectUrlOnGeoBlock = feature.stringFieldWithName(fieldName: "redirectOnGeoBlock")?.value
        self.postLoginPath = feature.stringFieldWithName(fieldName: "postLoginPath")?.value
        self.workflowPath = feature.stringFieldWithName(fieldName: "workflowPath")?.value
        self.registrationPath = feature.stringFieldWithName(fieldName: "registrationPath")?.value
        self.registrationBonusPath = feature.stringFieldWithName(fieldName: "registrationBonusPath")?.value
        self.forgotPasswordPath = feature.stringFieldWithName(fieldName: "forgotPasswordPath")?.value
        self.forgotUsernamePath = feature.stringFieldWithName(fieldName: "forgotUsernamePath")?.value
        self.appVersionParam = feature.stringFieldWithName(fieldName: "appVersionParam")?.value
        self.appendAppVersion = feature.boolFieldWithName(fieldName: "appendAppVersion")?.value ?? false
        self.wipeCookies = feature.boolFieldWithName(fieldName: "wipeCookies")?.value ?? false
        self.addressBarUrls = feature.arrayFieldWithName(fieldName: "addressBarUrls")?.value as? [String]
        self.helpSliderBlackjackPath = feature.stringFieldWithName(fieldName: "helpSliderBlackjackPath")?.value
        self.helpSliderEuroRoulettePath = feature.stringFieldWithName(fieldName: "helpSliderEuroRoulettePath")?.value
        self.helpSliderPerfectBlackJackProPath = feature.stringFieldWithName(fieldName: "helpSliderPerfectBlackJackProPath")?.value
        self.helpSliderRoulettePath = feature.stringFieldWithName(fieldName: "helpSliderRoulettePath")?.value
        self.helpPath = feature.stringFieldWithName(fieldName: "helpPath")?.value
        self.helpResponsibleGamingPath = feature.stringFieldWithName(fieldName: "helpResponsibleGamingPath")?.value
        self.isHelpResponsibleGamingPathAvailable = feature.boolFieldWithName(fieldName: "isHelpResponsibleGamingPathAvailable")?.value ?? false
        self.kycPath = feature.stringFieldWithName(fieldName: "kycPath")?.value
        self.myAccountPath = feature.stringFieldWithName(fieldName: "myAccountPath")?.value
        self.myBonusesPath = feature.stringFieldWithName(fieldName: "myBonusesPath")?.value
        self.myFreeSpinsPath = feature.stringFieldWithName(fieldName: "myFreeSpinsPath")?.value
        self.myInboxPath = feature.stringFieldWithName(fieldName: "myInboxPath")?.value
        self.helpSliderBlackjackPath = feature.stringFieldWithName(fieldName: "helpSliderBlackjackPath")?.value
        self.helpSliderEuroRoulettePath = feature.stringFieldWithName(fieldName: "helpSliderEuroRoulettePath")?.value
        self.helpSliderPerfectBlackJackProPath = feature.stringFieldWithName(fieldName: "helpSliderPerfectBlackJackProPath")?.value
        self.helpSliderRoulettePath = feature.stringFieldWithName(fieldName: "helpSliderRoulettePath")?.value
        self.menuUrl = feature.stringFieldWithName(fieldName: "menuUrl")?.value
        self.logoutRegex = feature.arrayFieldWithName(fieldName: "logoutRegex")?.value as? [String] ?? []
        self.promotionsUrl = feature.stringFieldWithName(fieldName: "promotionsUrl")?.value
        self.contactPath = feature.stringFieldWithName(fieldName: "contactPath")?.value ?? ""
        self.cookie = feature.stringFieldWithName(fieldName: "nativeCookie")?.value ?? ""
        self.helpBaseUrl = feature.stringFieldWithName(fieldName: "helpBaseUrl")?.value ?? ""
        self.anyProductUrl = feature.stringFieldWithName(fieldName: "anyProductUrl")?.value ?? ""
        self.hasPostLogin = feature.boolFieldWithName(fieldName: "hasPostLogin")?.value ?? false
        self.trackingPlaceholders = feature.stringFieldWithName(fieldName: "trackingPlaceholders")?.value
        self.nativeCookieSSOParameter = feature.stringFieldWithName(fieldName: "nativeCookieSSOParameter")?.value
        self.nativeCookieSSOParameterExceptionList = feature.arrayFieldWithName(fieldName: "nativeCookieSSOParameterExceptionList")?.value as? [String] ?? []
        self.singleAppUrlHost = feature.stringFieldWithName(fieldName: "singleAppUrlHost")?.value
        self.genericUrlHosts = feature.arrayFieldWithName(fieldName: "genericUrlHosts")?.value as? [String]
        self.stateSwitcherQueryUrl = feature.stringFieldWithName(fieldName: "stateSwitcherQueryUrl")?.value
        self.hideHeaderQueryParams = feature.stringFieldWithName(fieldName: "hideHeaderQueryParams")?.value
        self.authadaKYCPath = feature.stringFieldWithName(fieldName: "authadaKYCPath")?.value
        self.authadaConfigPath = feature.stringFieldWithName(fieldName: "authadaConfigPath")?.value
        self.authadaChangePinStagingUrl = feature.stringFieldWithName(fieldName: "authadaChangePinStagingUrl")?.value
        self.idnowKYCPath = feature.stringFieldWithName(fieldName: "idnowKYCPath")?.value
        self.kycVerificationpath = feature.stringFieldWithName(fieldName: "kycVerificationpath")?.value
        self.kycDocumentsPendingPath = feature.stringFieldWithName(fieldName: "kycDocumentsPendingPath")?.value
        self.hideRGPageQueryParams = feature.stringFieldWithName(fieldName: "hideRGPageQueryParams")?.value
        self.totpMigrationUrl = feature.stringFieldWithName(fieldName: "totpMigrationUrl")?.value
        self.skipKycStatus = feature.boolFieldWithName(fieldName: "skipKycStatus")?.value ?? false
        self.idnowAutoKycPath = feature.stringFieldWithName(fieldName: "idnowAutoKycPath")?.value
        self.iOSAuthadaCerHash = feature.arrayFieldWithName(fieldName: "iOSAuthadaCerHash")?.value as? [String]
        self.govtLogoURL = feature.stringFieldWithName(fieldName: "govtLogoURL")?.value
        self.appVersionParam = feature.stringFieldWithName(fieldName: "appVersionParam")?.value
        self.appendAppVersion = feature.boolFieldWithName(fieldName: "appendAppVersion")?.value ?? false
        self.headerLogoPath = feature.stringFieldWithName(fieldName: "headerLogoPath")?.value
        self.loginUrl = feature.stringFieldWithName(fieldName: "loginUrl")?.value
        self.loginCancelUrlKey = feature.stringFieldWithName(fieldName: "loginCancelUrlKey")?.value
        self.geoRestrictedUrls = feature.arrayFieldWithName(fieldName: "geoRestrictedUrls")?.value as? [String]
        if let parentDsl = feature.dictionaryFieldWithName(fieldName: "parentDSL")?.value {
            self.shouldReplaceParent = parentDsl["replaceParent"] as? Bool ?? false
            self.parentRegex = parentDsl["regex"] as? [String]
            self.replaceParentPair = parentDsl["replaceParentPair"] as? [String: String]
        }
        self.allowExitLoginFromKyc = feature.boolFieldWithName(fieldName: "allowExitLoginFromKyc")?.value ?? false
        if let winNotificationTracking = feature.dictionaryFieldWithName(fieldName: "winNotificationTracking")?.value {
            self.winNotificationTracking = winNotificationTracking
        }
        self.webViewOpaque = feature.boolFieldWithName(fieldName: "webViewOpaque")?.value ?? false
        
        self.sessionLimitsUpdateUrl = feature.stringFieldWithName(fieldName: "sessionLimitsUpdateUrl")?.value
        self.promoBaseUrl = feature.stringFieldWithName(fieldName: "promobaseUrl")?.value
    }
    
    public func update(siblingData:PosAppConfigurationSibling) {
        
        if let url = siblingData.webURL {
            self.webUrl = url
        }
        if let url = siblingData.redirectUrlOnGeoBlock {
            self.redirectUrlOnGeoBlock = url
        }
        if let url = siblingData.portalBaseURL {
            self.baseUrl = url
        }
    }
}
