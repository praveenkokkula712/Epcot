//
//  CrossSellAppsValues.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 11/07/23.
//

import Foundation

public struct CrossSellAppsValues: Codable {
    public let urlScheme: String?
    public let deepLinkPlaceholder: String?
    public let appstoreLink: String?
    public let description: String?
    public let buttonTitle: String?
    public let iconUrl: String?
    public let enablePopup: Bool?
    public let eventDetails: String?
    public let eventDetailsCTA: String?
}
