//
//  DynaconFeatureSet.swift
//  Wrapper
//
//  Created by Harshita Sai Adagarla on 03/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import SwiftyJSON

public enum DynaconFieldType: String {
    
    case DynaconFieldTypeUnknown = "unknown field type"
    case DynaconFieldTypeString = "string"
    case DynaconFieldTypeMultilineString = "string [multiline]"
    case DynaconFieldTypeBool = "bool"
    case DynaconFieldTypeInteger = "int"
    case DynaconFieldTypeJson = "json"
    case DynaconFieldTypeDecimal = "decimal"
    case DynaconFieldTypeDateTime = "datetime"
    case DynaconFieldTypeTimeSpan = "timespan"
    case DynaconFieldTypeUri = "uri"
    case DynaconFieldTypePassword = "password"
    
    static let dynaconFieldTypes = [DynaconFieldTypeUnknown, DynaconFieldTypeString, DynaconFieldTypeMultilineString, DynaconFieldTypeBool, DynaconFieldTypeInteger, DynaconFieldTypeJson, DynaconFieldTypeDecimal, DynaconFieldTypeDateTime, DynaconFieldTypeTimeSpan, DynaconFieldTypeUri, DynaconFieldTypePassword]
    
    static func getField(ofString: String) -> DynaconFieldType {
        for fieldtype in dynaconFieldTypes {
            if fieldtype.rawValue == ofString {
                return fieldtype
            }
        }
        return DynaconFieldType.DynaconFieldTypeUnknown
    }
}

@objc
public class DynaconField: NSObject {
    var type: DynaconFieldType?
    var name: String?
    var rawValues: [Dictionary<String,Any>]?
    var rawValue: String?
    
    init(json: JSON) {
        let strType = json["dataType"].stringValue
        self.type = DynaconFieldType.getField(ofString: strType)
        self.name = json["name"].stringValue
        self.rawValues = json["values"].arrayObject as? [[String:Any]]
        if let rawValues = rawValues, rawValues.count > 0 {
            self.rawValue = self.rawValues?.first!["value"] as? String
        }
    }
    
    func dynaconFieldWithJson(json: JSON) -> DynaconField {
        var field = DynaconField(json: json)
        if let strType = json["dataType"].string {
            let type: DynaconFieldType = DynaconFieldType.getField(ofString: strType)
            switch type {
            case .DynaconFieldTypeString, .DynaconFieldTypeMultilineString, .DynaconFieldTypeTimeSpan, .DynaconFieldTypeUri, .DynaconFieldTypePassword :
                field = DynaconStringField(json: json)
                
            case .DynaconFieldTypeBool:
                field = DynaconBoolField(json: json)
            case .DynaconFieldTypeInteger, .DynaconFieldTypeDecimal:
                field = DynaconNumberField(json: json)
                
            case .DynaconFieldTypeJson:

                if let valuesJson = json["values"].array, valuesJson.count > 0 {
                    if let valueJson:String = json["values"][0]["value"].string, valueJson.count > 0, let data = valueJson.data(using: .utf8) {
                        do {
                                if let _ = try JSON(data: data).dictionaryObject {
                                    field = DynaconDictionaryField(json: json)
                                }
                            
                                else if let _ = try JSON(data: data).arrayObject {
                                    field = DynaconArrayField(json: json)
                            }
    
                        } catch {
                            
                        }
                    }
                }
                
            case .DynaconFieldTypeDateTime :
                field = DynaconDateField(json: json)
                
            case .DynaconFieldTypeUnknown :
                break
            }
        }
        return field
    }
}
/////////

public class DynaconStringField: DynaconField {
    var value: String?
    
    override init(json: JSON) {
        super.init(json: json)
        self.value = self.rawValue
    }
}

public class DynaconBoolField: DynaconField {
    var value: Bool?
    
    override init(json: JSON) {
        super.init(json: json)
        self.value = self.rawValue?.lowercased() == "true"
    }
}

public class DynaconNumberField: DynaconField {
    var value: NSNumber?
    
    override init(json: JSON) {
        super.init(json: json)
        let formatter = NumberFormatter()
        formatter.decimalSeparator = "."
        if let rawValue = self.rawValue {
            self.value = formatter.number(from: rawValue)
        }
    }
}

public class DynaconArrayField: DynaconField {
    var value: [Any]?

    override init(json: JSON) {
        super.init(json: json)
        do {
            if let rawValueData = rawValue?.data(using: .utf8) {
                if let jsonDataArray = try JSON(data: rawValueData).arrayObject {
                    self.value = jsonDataArray
                }
            }
        } catch {
            
        }
    }
}

public class DynaconDateField: DynaconField {
    
    var value: Date?

    override init(json: JSON) {
        super.init(json: json)
        let formatter = DateFormatter()
        formatter.timeZone = TimeZone(abbreviation: "UTC")
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        if var rawVal = self.rawValue {
            if rawVal.hasPrefix("\"") && rawVal.hasSuffix("\"") {
                let startIndex = rawVal.firstIndex(of: "\"")
                let endIndex = rawVal.firstIndex(of: "\"")
                rawVal = String(rawVal[startIndex!...endIndex!])
            }
            self.value = formatter.date(from: rawVal)
        }
    }
}

public class DynaconDictionaryField: DynaconField {
    
    var value: Dictionary<String,Any>?

    override init(json: JSON) {
        super.init(json: json)
        do {
            if let rawValueData = rawValue?.data(using: .utf8) {
                if let jsonDict = try JSON(data: rawValueData).dictionaryObject {
                    self.value = jsonDict
                }
            }
        }
        catch {
            
        }
    }
}


////////

@objc
public class DynaconFeatureSet: NSObject {
    var features: [String: DynaconFeature]?
    @objc init(_ dictionary: Dictionary<String,Any>) {
        //self.init()
        let json = JSON(dictionary)
        
        var featuresDictionary = [String:DynaconFeature]()
        if let rawFeatures = json["features"].arrayObject as? [[String : Any]] {
            for rawFeature in rawFeatures {
                if let featureName = rawFeature["name"] as? String {
                    featuresDictionary[featureName] = DynaconFeature(rawFeature)
                }
            }
            self.features = featuresDictionary
        }
    }
    
    func featureWithName(featureName: String) -> DynaconFeature? {
        if let features = self.features, let feature = features[featureName] {
            return feature
        }
        return nil
    }
}

@objc
public class DynaconFeature: NSObject {
    
    @objc var name: String?
    @objc var fields: Dictionary<String,DynaconField>?
    
    @objc convenience init(_ dictionary: Dictionary<String,Any>) {
        self.init()
        let json = JSON(dictionary)
        name = json["name"].stringValue
        if json["keys"].exists() {
            let keysJson = json["keys"].arrayValue
            var fieldsDictionary = Dictionary<String,DynaconField>()
            for (_, element) in keysJson.enumerated() {
                if let fieldName = element["name"].string {
                    var field = DynaconField(json: element)
                    field = field.dynaconFieldWithJson(json: element)
                    fieldsDictionary[fieldName] = field
                }
            }
            self.fields = fieldsDictionary
        }
    }
    func fieldWithName(fieldName: String) -> DynaconField? {
        if let fields = fields, let field = fields[fieldName] {
            return field
        }
        return nil
    }
    
    func stringFieldWithName(fieldName: String) -> DynaconStringField? {
        if let field: DynaconField = self.fieldWithName(fieldName: fieldName) {
            if field.isKind(of: DynaconStringField.self) {
                return field as? DynaconStringField
            }
        }
        return nil
    }
    
    func boolFieldWithName(fieldName: String) -> DynaconBoolField? {
        if let field: DynaconField = self.fieldWithName(fieldName: fieldName) {
            if field.isKind(of: DynaconBoolField.self) {
                return field as? DynaconBoolField
            }
        }
        return nil
    }
    
    func numberFieldWithName(fieldName: String) -> DynaconNumberField? {
        if let field: DynaconField = self.fieldWithName(fieldName: fieldName) {
            if field.isKind(of: DynaconNumberField.self) {
                return field as? DynaconNumberField
            }
        }
        return nil
    }
    
    func arrayFieldWithName(fieldName: String) -> DynaconArrayField? {
        if let field: DynaconField = self.fieldWithName(fieldName: fieldName) {
            if field.isKind(of: DynaconArrayField.self) {
                return field as? DynaconArrayField
            }
        }
        return nil
    }
    
    func dictionaryFieldWithName(fieldName: String) -> DynaconDictionaryField? {
        if let field: DynaconField = self.fieldWithName(fieldName: fieldName) {
            if field.isKind(of: DynaconDictionaryField.self) {
                return field as? DynaconDictionaryField
            }
        }
        return nil
    }
    
    func dateFieldWithName(fieldName: String) -> DynaconDateField? {
        if let field: DynaconField = self.fieldWithName(fieldName: fieldName) {
            if field.isKind(of: DynaconDateField.self) {
                return field as? DynaconDateField
            }
        }
        return nil
    }
}
