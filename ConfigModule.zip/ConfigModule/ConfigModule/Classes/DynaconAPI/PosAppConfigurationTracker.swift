//
//  PosAppConfigurationTracker.swift
//  Wrapper
//
//  Created by Harshita Sai Adagarla on 09/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit
import AWSCore

fileprivate let kCommonKey = "common"
fileprivate let kinesisEncryptedKey = "89238762187679485519111246897781"
fileprivate let optimoveEncryptedKey = "89238762187679480919881246897782"

@objcMembers
public class PosAppConfigurationTracker: NSObject, NSSecureCoding {
    
    public private(set) var internalOlUrl: String?
    public private(set) var tracker: [String:Any]?
    public private(set) var minSyncCount: Int?
    public private(set) var enableDeviceIdTrackingToGTM: Bool?
    public private(set) var playMetricsFrontEndKey = ""
    public private(set) var kinesisStream: String?
    public private(set) var kinesisregion: Int?
    public private(set) var isKinesisLoggerEnabled:Bool?
    public private(set) var kinesisEncryptedValue: String?
    public private(set) var enabledCrashlyticsLogs: Bool?
    public static var supportsSecureCoding: Bool = true
    public private(set) var iosKinesisEncryptedValue: String?
    public private(set) var kinesisCognitoPoolId: String?
    public private(set) var kinesisCognitoRegion: Int?
    public private(set) var firebaseTrackingKeys: [String: String]?
    public private(set) var enableAppsflyerBonusPopup: Bool?
    public private(set) var enablefirebaseOnDeviceConversion: Bool?
    public private(set) var enableHashedCredentials: Bool?
    public private(set) var enableResetAnalyticsData: Bool?
    public private(set) var optimoveCredentials: String?
    public private(set) var mobileCredentials: String?
    public private(set) var enableOptimoveSDK: Bool?
    public private(set) var enableOptimoveDeferredDeeplink: Bool?
    public private(set) var enableOptimoveLocationTracking: Bool?
    
    private let apiConfig = DynaconAPIConfiguration.shared

    public init(feature: DynaconFeature) {
        super.init()

        self.internalOlUrl = feature.stringFieldWithName(fieldName: "internalOlUrl")?.value
        self.tracker = feature.dictionaryFieldWithName(fieldName: "tracker")?.value

        if let appLogger = feature.dictionaryFieldWithName(fieldName: "appLogger")?.value {
            if let kinesisDict = appLogger["kinesis"] as? [String: Any] {
                self.isKinesisLoggerEnabled = kinesisDict["enabled"] as? Bool
            }
            // `AWSKinesis` dynacon key is deprecated
            // Use `betaAwsKinesis` dynacon key for appcenter/dev builds
            // Use `appstoreAwsKinesis` dynacon key for appstore/testflight builds
            // Read `common` data from dynacon.
            // Read `appVersion` specific data from dynacon.
            // Use `appVersion` specific data, if available, else use `common` data.
            /*
             - Sample dynacon data,
                 {
                     "common": {
                         "iOSEncryptedValue": "xxxx"
                     },
                     "23.04.12": {
                         "iOSEncryptedValue": "xxxx"
                     }
                 }
             - Final encryypted data will be, considering app version,
                 {
                    "iOSEncryptedValue": "xxxx"
                 }
            */
            let awsKinesisDynaconKey = (DynaconAPIConfiguration.shared?.appConfigs?.isInternalBuild ?? true) ? "betaAwsKinesis" : "appstoreAwsKinesis"
            if let awsKinesisDataFrame = feature.dictionaryFieldWithName(fieldName: awsKinesisDynaconKey)?.value as? [String: Any] {
                var iOSEncryptedValue: String?
                if let commonAwsKinesisDataFrame = awsKinesisDataFrame[kCommonKey] as? [String: Any] {
                    iOSEncryptedValue = commonAwsKinesisDataFrame["iOSEncryptedValue"] as? String
                }
                if let currentAppVersion = Bundle.main.version,
                   let appVersionAwsKinesisData = awsKinesisDataFrame.first(where: { $0.key == currentAppVersion })?.value as? [String: Any] {
                    iOSEncryptedValue = appVersionAwsKinesisData["iOSEncryptedValue"] as? String
                }
                // regionCode should be in string format, for example, ap-south-1, eu-west-2 etc..
                /*
                 - Sample encryption data,
                     {
                       "stream" : "xxxx",
                       "regionCode": "ap-south-1",
                       "cognitoPoolId": "xxxx",
                       "cognitoRegionCode": "ap-south-1"
                     }
                */
                if let value = iOSEncryptedValue,
                   let json = AESDecryption.decryptedData(with: value, key: kinesisEncryptedKey) {
                    self.iosKinesisEncryptedValue = value
                    self.kinesisStream = json["stream"] as? String ?? ""
                    // Use cognito pool id to authenticate with AWS
                    self.kinesisCognitoPoolId = json["cognitoPoolId"] as? String ?? ""
                    // Use regionCode with String format
                    // For example, `ap-south-1` will be converted to AWS region type (Enum, rawValue integer) using AWS SDK API
                    if let region = json["regionCode"] as? NSString {
                        self.kinesisregion = region.aws_regionTypeValue().rawValue
                        self.kinesisCognitoRegion = self.kinesisregion
                    }
                    if let cognitoRegion = json["cognitoRegionCode"] as? NSString {
                        self.kinesisCognitoRegion = cognitoRegion.aws_regionTypeValue().rawValue
                    }
                }
            }
            
            if let firebaseDict = appLogger["firebase"] as? [String: Any] {
                self.enabledCrashlyticsLogs = firebaseDict["enabledCrashlyticsLogs"] as? Bool
            }
            self.minSyncCount = appLogger["minSyncCount"] as? Int
        }
        let optimoveDynaconKey = (DynaconAPIConfiguration.shared?.appConfigs?.isInternalBuild ?? true) ? "betaOptimove" : "storeOptimove"
        if let optimoveDataFrame = feature.dictionaryFieldWithName(fieldName: optimoveDynaconKey)?.value as? [String: Any] {
            
            if let enable = optimoveDataFrame["enabled"] as? Bool {
                self.enableOptimoveSDK = enable
            }
            if let enable = optimoveDataFrame["enableLocationTracking"] as? Bool {
                self.enableOptimoveLocationTracking = enable
            }
            if let enable = optimoveDataFrame["enableDeferredDeeplink"] as? Bool {
                self.enableOptimoveDeferredDeeplink = enable
            }
            /*
             - Sample encryption data,
             {
                "optimoveCredentials" : "xxxx",
                "mobileCredentials": "xxxx",
             }
             */
            if let value = optimoveDataFrame["encryptedValue"] as? String,
               let json = AESDecryption.decryptedData(with: value, key: optimoveEncryptedKey) {
                self.optimoveCredentials = json["optimoveCredentials"] as? String ?? ""
                self.mobileCredentials = json["mobileCredentials"] as? String ?? ""
            }
        }
        if let firebaseOnDeviceConversion = feature.dictionaryFieldWithName(fieldName: "firebaseOnDeviceConversion")?.value as? [String: Any] {
            if let enable = firebaseOnDeviceConversion["enable"] as? Bool {
                self.enablefirebaseOnDeviceConversion = enable
            }
            if let enableHashed = firebaseOnDeviceConversion["enableHashedCredentials"] as? Bool {
                self.enableHashedCredentials = enableHashed
            }
            if let resetData = firebaseOnDeviceConversion["enableResetAnalyticsData"] as? Bool {
                self.enableResetAnalyticsData = resetData
            }
        }
        self.firebaseTrackingKeys = feature.dictionaryFieldWithName(fieldName: "firebaseTrackingKeys")?.value as? [String: String]
        self.enableDeviceIdTrackingToGTM = feature.boolFieldWithName(fieldName: "enableGTMTrackingForDeviceId")?.value
        self.enableAppsflyerBonusPopup = feature.boolFieldWithName(fieldName: "enableAppsflyerBonusPopup")?.value
        let key = (apiConfig?.appConfigs?.isUnifiedApp ?? false) ? "indigoFrontEndKey" : "playMetricsFrontEndKey"
        self.playMetricsFrontEndKey = feature.stringFieldWithName(fieldName: key)?.value ?? ""
        let dynaconUpdateNotification = "kDynaconUpdateNotification"
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: dynaconUpdateNotification), object: nil)
        }
    }

    override init() {
         super.init()
    }

    public func encode(with coder: NSCoder) {
        //Encode properties, other class variables, etc
        coder.encode(internalOlUrl, forKey: "internalOlUrl")
        coder.encode(tracker, forKey: "tracker")
        coder.encode(minSyncCount, forKey: "minSyncCount")
        coder.encode(enableDeviceIdTrackingToGTM, forKey: "enableDeviceIdTrackingToGTM")
        coder.encode(playMetricsFrontEndKey, forKey: "playMetricsFrontEndKey")
        coder.encode(kinesisStream, forKey: "kinesisStream")
        coder.encode(kinesisregion, forKey: "kinesisregion")
        coder.encode(isKinesisLoggerEnabled, forKey: "isKinesisLoggerEnabled")
        coder.encode(enabledCrashlyticsLogs, forKey: "enabledCrashlyticsLogs")
        coder.encode(kinesisEncryptedValue, forKey: "kinesisEncryptedValue")
    }

    required convenience public init(coder aDecoder: NSCoder) {
        self.init()
        //Decode properties, other class vars
        self.internalOlUrl = aDecoder.decodeObject(forKey: "internalOlUrl") as? String
        self.tracker = aDecoder.decodeObject(forKey: "tracker") as? [String: Any]
        self.minSyncCount     = aDecoder.decodeObject(forKey: "minSyncCount") as? Int
        self.enableDeviceIdTrackingToGTM     = aDecoder.decodeObject(forKey: "enableDeviceIdTrackingToGTM") as? Bool
        self.playMetricsFrontEndKey = aDecoder.decodeObject(forKey: "playMetricsFrontEndKey") as? String ?? ""
        self.kinesisStream = aDecoder.decodeObject(forKey: "kinesisStream") as? String ?? ""
        self.kinesisregion = aDecoder.decodeObject(forKey: "kinesisregion") as? Int ?? 12
        self.isKinesisLoggerEnabled = aDecoder.decodeObject(forKey: "isKinesisLoggerEnabled") as? Bool ?? false
        self.enabledCrashlyticsLogs = aDecoder.decodeObject(forKey: "enabledCrashlyticsLogs") as? Bool ?? false
        self.kinesisEncryptedValue = aDecoder.decodeObject(forKey: "kinesisEncryptedValue") as? String ?? ""
    }
 
    @objc public func shouldLogDeviceIdToGTM() -> Bool {
        if let deviceId = self.enableDeviceIdTrackingToGTM {
            return deviceId
        }
        return false
    }
    
    @objc public func isEnabledAppsflyerBonusPopup() -> Bool {
        if let isEnable = self.enableAppsflyerBonusPopup {
            return isEnable
        }
        return false
    }
    
    public class func getDefaultKinesisSetupValues(with value: String) -> [String: Any] {
        if let json = AESDecryption.decryptedData(with: value, key: kinesisEncryptedKey) {
            return json
        }
        return [:]
    }
}

public func ==(lhs: [String: Any]?, rhs: [String: Any]?) -> Bool {
    guard let aLhs = lhs, let aRhs = rhs else {
        return false
    }
    return NSDictionary(dictionary: aLhs).isEqual(to: aRhs)
}
