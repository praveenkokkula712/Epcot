//
//  CategoryDisplayConfiguration.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 08/07/24.
//

import Foundation

public struct CategoryDisplayConfiguration {
    public private(set) var category: NamingConfiguration = .lmtBased
    public private(set) var subCategory: NamingConfiguration = .lmtBased
    
    init(category: NamingConfiguration, subCategory: NamingConfiguration) {
        self.category = category
        self.subCategory = subCategory
    }
}

public enum NamingConfiguration: Int {
    case lmtBased
    case upperCased
    case lowerCased
    case capitalized
    
    public init(rawValue: Int?) {
        switch rawValue {
        case .none:
            self = .lmtBased
        case .some(let value):
            switch value {
            case 1:
                self = .upperCased
            case 2:
                self = .lowerCased
            case 3:
                self = .capitalized
            default:
                self = .lmtBased
            }
        }
    }
}
