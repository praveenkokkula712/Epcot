//
//  AppConfigurationPlayTechODR.swift
//  Wrapper
//
//  Created by Uday Kiran Veginati on 6/23/20.
//  Copyright © 2020 bwin.com. All rights reserved.
//

import Foundation

public struct AppConfigurationPlayTechODR: Codable {
    public private(set) var sdkKey = ""
    public private(set) var pasURL = ""
    public private(set) var casinoName = ""
    public private(set) var host = ""
    public private(set) var port = "4805"
    public private(set) var sslEnabled = true
    public private(set) var clientVersion = "89"
    public private(set) var gamePlaySystemID = "194"
    public private(set) var popSystemID = "55"
    public private(set) var live2SystemID = "498"
    public private(set) var liveLoaderUrl = ""
    public private(set) var liveEndpoints = [String]()
    public private(set) var initialCDNPath = ""
    public private(set) var localWebServerPort: UInt = 0
    public private(set) var odrPrefix = ""
    public private(set) var odrPostfix = ""
    public private(set) var liveConfigurationKey = ""
    public private(set) var clientType = 1
    public private(set) var isDemoModeEnabled: Bool = false
}
