//
//  PosClientInformation.swift
//  Wrapper
//
//  Created by Harshita Sai Adagarla on 06/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit
import SwiftyJSON

public class PosClientInformation: NSObject {
    
    public var brandId: String?
    public var channelId: String?
    public var frontendId: String?
    public var productId: String?
    
    public init(json: JSON) {
        super.init()

        self.brandId = json["brandId"].string
        self.channelId = json["channelId"].string
        self.frontendId = json["frontendId"].string
        self.productId = json["productId"].string
    }
}
