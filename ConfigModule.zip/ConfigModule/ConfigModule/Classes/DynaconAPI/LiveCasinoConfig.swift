//
//  LiveCasinoConfig.swift
//  ConfigModule
//
//  Created by Rajani Bhimanadham on 04/12/23.
//

import Foundation

public struct LiveCasinoConfig: Codable {
    public var lobbyTemplate: String?
    public var isFetchEnabled,
               isAvailableUnderSearch,
               isAvailableUnderCategoryTab,
               isHTMLGamesEnabled: Bool?,
               launchWebGameUrl: Bool?
    
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.lobbyTemplate = try container.decodeIfPresent(String.self, forKey: .lobbyTemplate)
        self.isFetchEnabled = try? container.decodeIfPresent(Bool.self, forKey: .isFetchEnabled) ?? false
        self.isAvailableUnderSearch = try? container.decodeIfPresent(Bool.self, forKey: .isAvailableUnderSearch) ?? false
        self.isAvailableUnderCategoryTab = try? container.decodeIfPresent(Bool.self, forKey: .isAvailableUnderCategoryTab) ?? false
        self.isHTMLGamesEnabled = try? container.decodeIfPresent(Bool.self, forKey: .isHTMLGamesEnabled) ?? false
        self.launchWebGameUrl = try? container.decodeIfPresent(Bool.self, forKey: .launchWebGameUrl) ?? false
    }
}
