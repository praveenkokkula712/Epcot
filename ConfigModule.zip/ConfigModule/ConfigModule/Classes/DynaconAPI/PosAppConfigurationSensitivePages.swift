//
//  PosAppConfigurationSensitivePages.swift
//  Wrapper
//
//  Created by Harshita Sai Adagarla on 06/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

public class PosAppConfigurationSensitivePages: NSObject {
    public private(set) var regexUrls: [Any]?
    public private(set) var fullUrls: [Any]?
    
    public init(feature: DynaconFeature) {
        super.init()

        self.regexUrls = feature.arrayFieldWithName(fieldName: "regex")?.value
        self.fullUrls = feature.arrayFieldWithName(fieldName: "fullUrls")?.value
    }
}
