//
//  PosAppConfigurationFeatures.swift
//  Wrapper
//
//  Created by Vinod Kumar Muppala on 05/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit
import CasinoAPI

@objcMembers
public class PosAppConfigurationFeatures: NSObject {
    
    public private(set) var autologinEnabled: Bool?
    public private(set) var touchIdEnabled: Bool?
    public private(set) var enableTouchIdPopUp: Bool?
    public private(set) var enableBiometricAlert: Bool?
    public private(set) var nativeFooterEnabled = false
    public private(set) var sessionTimeout: Int = 0
    public private(set) var idleTimeout: Int = 0
    public private(set) var warnBeforeIdleTimeout: Int = 0
    public private(set) var autoClearCredentialsTimeout: Int = 0
    public private(set) var noThanksFastLoginTimer: Int = 0
    public private(set) var applePayEnabled: Bool = false
    public private(set) var applePayCashierUrls: [String]?
    public private(set) var applePayExcludeUrls: [String]?
    public private(set) var applePayOnlyUrls: [String]?
    public private(set) var geocomplyEnabled: Bool = false
    public private(set) var savePassword: Bool = false
    public private(set) var sessionExpireTime: Int = 0
    public private(set) var productMenuEnabled = false
    public private(set) var cnsSubLabel: String?
    public private(set) var defaultInAppPush: Bool = false
    public private(set) var enableRetrievePostLogin: Bool = false
    public private(set) var brandId = ""
    public private(set) var frontEndId = ""
    public private(set) var enableGoogleAnalytics: Bool?
    public private(set) var enableFirebaseCrashlytics: Bool?
    public private(set) var enableIDnowSDK: Bool?
    public private(set) var enableGoogleTagManager: Bool?
    public private(set) var enableHeaderRegulatory = false
    public private(set) var showMonthlySummary = false
    public private(set) var appMode: String?
    public private(set) var appChannel: String?
    public private(set) var showStateSwitcher = false
    public private(set) var enableProductSwitchCoolOff = false
    public private(set) var productSwitchCookie: [String: String]?
    public private(set) var preLoginLocationFetch = true
    public private(set) var locationPollingUpdateInterval = 0
    public private(set) var ignoreIDNowCompanyID: Bool?
    public private(set) var idNowCompanyID: String?
    public private(set) var iPChangeGeoComplyPoll = false
    public private(set) var enableEntainIPDetection = false
    public private(set) var saveSafariCredentails = false
    public private(set) var allowPasscodeLogin = false
    public private(set) var enableUserAgent: Bool = false
    public private(set) var userAgentValue: String?
    public private(set) var onlyEmailLogin = false
    public private(set) var singleAccountEnabled = false
    public private(set) var ignoreKillCommand: Bool = false
    public private(set) var retryTimeForKillCommand: Int = 0
    public private(set) var enableAppUpdateNewUI = false
    public private(set) var enableBeacons = false
    public private(set) var supportedLanguages = [String]()
    public private(set) var enableLexisNexisSDK: Bool?
    public private(set) var enabledStateSwitchConfirmationPopUp: Bool = false
    public private(set) var enabledNonLegalStateSwitchPopUp: Bool = false
    public private(set) var enabledLegalStateSwitchPopUp: Bool = false
    public private(set) var enableManualStateSwitchPopUp: Bool = false
    public private(set) var enabledLogInPopUp: Bool = false
    public private(set) var enabledLogOutPopUp: Bool = false
    public private(set) var nativeFooterItems = [Int]()
    public private(set) var handleLogoPosition = false
    public private(set) var isGermanLabel = false
    public private(set) var showHeaderRGLogo = false
    public private(set) var checkKycStatus = false
    public private(set) var isKycVerificationNeeded = false
    public private(set) var showLoginSession = false
    public private(set) var passLoginSessionTime = false
    public private(set) var hideLogoOnSessionTime = false
    public private(set) var sessionTimeAlignment = 0
    public private(set) var showHeaderonGameController = false
    public private(set) var headerType = -1
    public private(set) var rcpuQuitOnLogout = false
    public private(set) var enableEpcotFeature = false
    public private(set) var enableDynamicHeader = false
    public private(set) var enableFirebaseEvents = false
    public private(set) var launchLastKnownProduct: LastKnownProduct?
    public private(set) var hideLeftLogo = false
    public private(set) var showNetBalance = false
    public private(set) var clearCredentialsOnManualLogout: Bool = false
    public private(set) var showArcSession = false
    public private(set) var rateMyAppVersion:FeedbackRatingViewType = .versionOne
    public private(set) var rateMyAppDismissTimeInterval = 5
    public private(set) var webCachePolicy: Int = 0
    //OS Primers
    public private(set) var enableAppOSPrimers: Bool = false
    public private(set) var firstAttemptDurationDays: Int = 0
    public private(set) var secondAttemptDurationDays: Int = 0
    public private(set) var displaySettingsPage: String?
    // Precise location
    public private(set) var enablePreciseLocationBanner: Bool = false
    public private(set) var enablePreciseLocationView: Bool = false
    //Onfido SDK
    public private(set) var enableOnfidoSDK: Bool?
    //Universal Loader
    public private(set) var enableUniversalLoader = false
    public private(set) var enableSplashDismissCCB = false
    public private(set) var autoSplashTimeout: Int = 5
    public private(set) var removeLoaderEvents: [String: Any]?
    public private(set) var removeSplashOnLaunch = false
    //Welcome screen
    public private(set) var enableWelcomePage = false
    public private(set) var refreshWebView: RefreshWebView?
    //Gaming Stories
    public private(set) var savedGamingStoiresHoldingDays = 0
    public private(set) var searchVersion = FeatureVersion.v1

    //UserOnboarding
    public private(set) var userOnboardingJourneys: UserOnboardingJourneys?
    //Biometric
    public private(set) var enableRegistrationBiometricAlert: Bool = false
    public private(set) var enableLoginBiometricAlert: Bool = false
    public private(set) var displayMessageCount: Bool = false
    public private(set) var enableInboxUnreadCount: Bool = false
    // Inactive Session
    public private(set) var touchIdEnabledForInactiveSession: Bool = false
    public private(set) var showCloseButtonForInactiveSession: Bool = false
    public private(set) var showNewInactiveSessionpopUp: Bool = false
    // Location Service
    public private(set) var isLocationPopupMandatory: Bool?
    public private(set) var locationPopupFirstAttemptDuration: Int?
    public private(set) var locationPopupSecondAttemptDuration: Int?
    
    public init(feature: DynaconFeature) {
        super.init()
        if let rateMyAppVersion = feature.numberFieldWithName(fieldName: "rateMyAppVersion")?.value?.intValue {
            self.rateMyAppVersion = FeedbackRatingViewType(rawValue: rateMyAppVersion) ?? .versionOne
        }
        self.rateMyAppDismissTimeInterval = feature.numberFieldWithName(fieldName: "rateMyAppDismissTimeInterval")?.value?.intValue ?? 5
        self.enableTouchIdPopUp = feature.boolFieldWithName(fieldName: "enableTouchIdPopUp")?.value
        self.enableBiometricAlert = feature.boolFieldWithName(fieldName: "enableBiometricAlert")?.value
        self.autologinEnabled = feature.boolFieldWithName(fieldName: "enableAutoLogin")?.value
        self.touchIdEnabled = feature.boolFieldWithName(fieldName: "enableTouchID")?.value
        self.geocomplyEnabled = feature.boolFieldWithName(fieldName: "enableGeocomply")?.value ?? false
        self.enableFirebaseEvents = feature.boolFieldWithName(fieldName: "enableFirebaseEvents")?.value ?? false
        self.savePassword = feature.boolFieldWithName(fieldName: "enableSavePassword")?.value ?? false
        self.saveSafariCredentails = feature.boolFieldWithName(fieldName: "saveSafariCredentails")?.value ?? false
        self.defaultInAppPush = feature.boolFieldWithName(fieldName: "defaultInAppPush")?.value ?? false
        self.enableRetrievePostLogin = feature.boolFieldWithName(fieldName: "enableRetrievePostLogin")?.value ?? false
        let isUnifiedApp = DynaconAPIConfiguration.shared?.appConfigs?.isUnifiedApp ?? false
        let field = isUnifiedApp ? "cnsSubLabel1" : "cnsSubLabel"
        self.cnsSubLabel = feature.stringFieldWithName(fieldName: field)?.value
        self.brandId = feature.stringFieldWithName(fieldName: "brandId")?.value ?? ""
        self.frontEndId = feature.stringFieldWithName(fieldName: "frontEndId")?.value ?? ""
        self.ignoreKillCommand = feature.boolFieldWithName(fieldName:"ignoreKillCommand")?.value ?? false
        self.retryTimeForKillCommand = feature.numberFieldWithName(fieldName: "retryTimeForKillCommand")?.value?.intValue ?? 0
        if let sessionExpire = feature.numberFieldWithName(fieldName: "sessionExpireTime")?.value {
            sessionExpireTime = sessionExpire.intValue
        }
        self.nativeFooterEnabled = feature.boolFieldWithName(fieldName: "enableNativeFooter")?.value ?? false
        if let sessionTime = feature.numberFieldWithName(fieldName: "sessionTimeout")?.value {
            sessionTimeout = sessionTime.intValue
        }
        
        if let logoutSessionTimeout = feature.numberFieldWithName(fieldName: "autoClearCredentialsTimeout")?.value {
            autoClearCredentialsTimeout = logoutSessionTimeout.intValue
        }
        
        if let fastLoginPopupDays = feature.numberFieldWithName(fieldName: "noThanksFastLoginTimer")?.value {
            noThanksFastLoginTimer = fastLoginPopupDays.intValue
        }
        if let idleTime = feature.dictionaryFieldWithName(fieldName: "idleTimeout")?.value {
            if let idleTO = idleTime["idleTimeout"] as? NSNumber {
                idleTimeout = idleTO.intValue
            }
            if let warnIdleTO = idleTime["warnBefore"] as? NSNumber {
                warnBeforeIdleTimeout = warnIdleTO.intValue
            }
        }
        if let applePayInfo = feature.dictionaryFieldWithName(fieldName: "applePay")?.value {
            if let applePayEnable = applePayInfo["enabledApplePay"] as? Bool {
                applePayEnabled = applePayEnable
            }
            if let cashierUrls = applePayInfo["urls"] as? [String] {
                applePayCashierUrls = cashierUrls
            }
            if let cashierUrls = applePayInfo["excludeUrls"] as? [String] {
                applePayExcludeUrls = cashierUrls
            }
            if let cashierUrls = applePayInfo["applePayOnlyUrls"] as? [String] {
                applePayOnlyUrls = cashierUrls
            }
        }
        if let customUserAgent = feature.dictionaryFieldWithName(fieldName: "customUserAgent")?.value {
            if let userAgentEnable = customUserAgent["enableUserAgent"] as? Bool {
                enableUserAgent = userAgentEnable
            }
            if let value = customUserAgent["userAgentValue"] as? String {
                userAgentValue = value
            }
        }

        self.productMenuEnabled = feature.boolFieldWithName(fieldName: "enableProductMenu")?.value ?? false
        self.enableGoogleAnalytics = feature.boolFieldWithName(fieldName: "enableGoogleAnalytics")?.value
        self.enableFirebaseCrashlytics = feature.boolFieldWithName(fieldName: "enableFirebaseCrashlytics")?.value
        self.enableIDnowSDK = feature.boolFieldWithName(fieldName: "enableIDnowSDK")?.value
        self.enableGoogleTagManager = feature.boolFieldWithName(fieldName: "enableGoogleTagManager")?.value
        self.appMode = feature.stringFieldWithName(fieldName: "appMode")?.value
        self.appChannel = feature.stringFieldWithName(fieldName: "appChannel")?.value
        self.showStateSwitcher = feature.boolFieldWithName(fieldName: "showStateSwitcher")?.value ?? false
        self.enableEntainIPDetection = feature.boolFieldWithName(fieldName: "enableEntainIPDetection")?.value ?? false
        if let config = feature.dictionaryFieldWithName(fieldName: "productSwitchCoolOff")?.value as? [String: Any] {
            self.enableProductSwitchCoolOff = (config["enableProductSwitchCoolOff"] as? Bool) ?? false
            self.productSwitchCookie = config["cookie"] as? [String: String]
        }
        self.preLoginLocationFetch = feature.boolFieldWithName(fieldName: "preLoginLocationFetch")?.value ?? true
        self.clearCredentialsOnManualLogout = feature.boolFieldWithName(fieldName: "clearCredentialsOnManualLogout")?.value ?? false
        self.locationPollingUpdateInterval = feature.numberFieldWithName(fieldName: "locationPollingUpdateInterval")?.value?.intValue ?? 0
        self.ignoreIDNowCompanyID = feature.boolFieldWithName(fieldName: "ignoreIDNowCompanyID")?.value
        self.idNowCompanyID = feature.stringFieldWithName(fieldName: "idNowCompanyID")?.value
        self.iPChangeGeoComplyPoll = feature.boolFieldWithName(fieldName: "iPChangeGeoComplyPoll")?.value ?? false
        self.allowPasscodeLogin = feature.boolFieldWithName(fieldName: "allowPasscodeLogin")?.value ?? false
        self.onlyEmailLogin = feature.boolFieldWithName(fieldName: "onlyEmailLoginAllowed")?.value ?? false
        self.singleAccountEnabled = feature.boolFieldWithName(fieldName: "enableSingleAccount")?.value ?? false
        self.enableAppUpdateNewUI = feature.boolFieldWithName(fieldName: "enableAppUpdateNewUI")?.value ?? false
        self.enableLexisNexisSDK = feature.boolFieldWithName(fieldName: "enableLexisNexisSDK")?.value
        self.enableOnfidoSDK = feature.boolFieldWithName(fieldName: "enableOnfidoSDK")?.value
        self.enableEpcotFeature = feature.boolFieldWithName(fieldName: "enableEpcotFeature")?.value ?? false
        self.enableDynamicHeader = feature.boolFieldWithName(fieldName: "enableDynamicHeader")?.value ?? false
        self.enableBeacons = feature.boolFieldWithName(fieldName: "enableBeacons")?.value ?? false
        if let urls = feature.arrayFieldWithName(fieldName: "supportedLanguages")?.value as? [String] {
            self.supportedLanguages = urls
        }
        if let usComplianceInfo = feature.dictionaryFieldWithName(fieldName: "usCompliance")?.value {
            if let enabledStateSwitchConfirmationPopUp = usComplianceInfo["enabledStateSwitchConfirmationPopUp"] as? Bool {
                self.enabledStateSwitchConfirmationPopUp = enabledStateSwitchConfirmationPopUp
            }
            if let enabledNonLegalStateSwitchPopUp = usComplianceInfo["enabledNonLegalStateSwitchPopUp"] as? Bool {
                self.enabledNonLegalStateSwitchPopUp = enabledNonLegalStateSwitchPopUp
            }
            if let enabledLegalStateSwitchPopUp = usComplianceInfo["enabledLegalStateSwitchPopUp"] as? Bool {
                self.enabledLegalStateSwitchPopUp = enabledLegalStateSwitchPopUp
            }
            if let enableManualStateSwitchPopUp = usComplianceInfo["enableManualStateSwitchPopUp"] as? Bool {
                self.enableManualStateSwitchPopUp = enableManualStateSwitchPopUp
            }
            if let enabledLogInPopUp = usComplianceInfo["enabledLogInPopUp"] as? Bool {
                self.enabledLogInPopUp = enabledLogInPopUp
            }
            if let enabledLogOutPopUp = usComplianceInfo["enabledLogOutPopUp"] as? Bool {
                self.enabledLogOutPopUp = enabledLogOutPopUp
            }
        }
        if let osPrimers = feature.dictionaryFieldWithName(fieldName: "osPrimers")?.value {
            if let enableAppOSPrimers = osPrimers["enableAppOSPrimers"] as? Bool {
                self.enableAppOSPrimers = enableAppOSPrimers
            }
            if let firstAttemptDurationDays = osPrimers["firstAttemptDurationDays"] as? Int {
                self.firstAttemptDurationDays = firstAttemptDurationDays
            }
            if let secondAttemptDurationDays = osPrimers["secondAttemptDurationDays"] as? Int {
                self.secondAttemptDurationDays = secondAttemptDurationDays
            }
            if let displaySettingsPage = osPrimers["displaySettingsPage"] as? String {
                self.displaySettingsPage = displaySettingsPage
            }
        }
        if let locationDisabledPopup = feature.dictionaryFieldWithName(fieldName: "locationDisabledPopup")?.value {
            if let enabled = locationDisabledPopup["isMandatory"] as? Bool {
                self.isLocationPopupMandatory = enabled
            }
            if let firstAttemptDurationDays = locationDisabledPopup["firstAttemptDurationDays"] as? Int {
                self.locationPopupFirstAttemptDuration = firstAttemptDurationDays
            }
            if let secondAttemptDurationDays = locationDisabledPopup["secondAttemptDurationDays"] as? Int {
                self.locationPopupSecondAttemptDuration = secondAttemptDurationDays
            }
        }
        self.nativeFooterItems = feature.arrayFieldWithName(fieldName: "nativeFooterItems")?.value as? [Int] ?? [Int]()
        
        if let headerRegulatory = feature.dictionaryFieldWithName(fieldName: "headerRegulatory")?.value {
            self.handleLogoPosition = headerRegulatory["handleLogoPosition"] as? Bool ?? false
            self.showHeaderRGLogo = headerRegulatory["showHeaderRGLogo"] as? Bool ?? false
            self.showLoginSession = headerRegulatory["showLoginSession"] as? Bool ?? false
            self.passLoginSessionTime = headerRegulatory["passLoginSessionTime"] as? Bool ?? false
            self.enableHeaderRegulatory = headerRegulatory["enableHeaderRegulatory"] as? Bool ?? false
            self.showMonthlySummary = headerRegulatory["showMonthlySummary"] as? Bool ?? false
            self.hideLogoOnSessionTime = headerRegulatory["hideLogoOnSessionTime"] as? Bool ?? false
            self.sessionTimeAlignment = headerRegulatory["sessionTimeAlignment"] as? Int ?? 0
            self.showHeaderonGameController = headerRegulatory["showHeaderonGameController"] as? Bool ?? false
            self.headerType = headerRegulatory["headerType"] as? Int ?? -1
            self.showNetBalance = headerRegulatory["showNetBalance"] as? Bool ?? false
            self.hideLeftLogo = headerRegulatory["hideLeftLogo"] as? Bool ?? false
            self.showArcSession = headerRegulatory["showArcSession"] as? Bool ?? false
            
        }
        if let lastUsedProduct = feature.dictionaryFieldWithName(fieldName: "launchLastKnownProduct")?.value as? [String: Any] {
            let lastUsedProductJson = try? JSONSerialization.data(withJSONObject: lastUsedProduct, options: [])
            let result = lastUsedProductJson?.jsonDecoder(LastKnownProduct.self)
            switch result {
            case .success(let lastKnownProd):
                self.launchLastKnownProduct = lastKnownProd
            default: break
            }
        }
        self.isGermanLabel = feature.boolFieldWithName(fieldName: "isGermanLabel")?.value ?? false
        self.checkKycStatus = feature.boolFieldWithName(fieldName: "checkKycStatus")?.value ?? false
        self.isKycVerificationNeeded = feature.boolFieldWithName(fieldName: "isKycVerificationNeeded")?.value ?? false
        self.rcpuQuitOnLogout = feature.boolFieldWithName(fieldName: "rcpuQuitOnLogout")?.value ?? false
        if let preciseLocation = feature.dictionaryFieldWithName(fieldName: "preciseLocation")?.value {
            if let enablePreciseLocationView = preciseLocation["enablePreciseLocationView"] as? Bool {
                self.enablePreciseLocationView = enablePreciseLocationView
            }
            if let enablePreciseLocationBanner = preciseLocation["enablePreciseLocationBanner"] as? Bool {
                self.enablePreciseLocationBanner = enablePreciseLocationBanner
            }
        }
        self.enableUniversalLoader = feature.boolFieldWithName(fieldName: "enableUniversalLoader")?.value ?? false
        self.removeLoaderEvents = feature.dictionaryFieldWithName(fieldName: "removeLoaderEvents")?.value as? [String: Any]
        self.removeSplashOnLaunch = feature.boolFieldWithName(fieldName: "removeSplashOnLaunch")?.value ?? false
        self.enableSplashDismissCCB = self.removeLoaderEvents?["enableSplashDismissCCB"] as? Bool ?? false
        if let loaderEvents = self.removeLoaderEvents,
            let autoSplashTimeout = loaderEvents["autoTimeout"] as? Int {
            self.autoSplashTimeout = autoSplashTimeout
        }
        self.enableWelcomePage = feature.boolFieldWithName(fieldName: "enableWelcomePage")?.value ?? false
        if let response = feature.dictionaryFieldWithName(fieldName: "refreshWebView")?.value as? [String: Any] {
            let refreshJson = try? JSONSerialization.data(withJSONObject: response, options: [])
            let result = refreshJson?.jsonDecoder(RefreshWebView.self)
            switch result {
            case .success(let refresh):
                self.refreshWebView = refresh
            default: break
            }
        }
        self.webCachePolicy = feature.numberFieldWithName(fieldName: "webCachePolicy")?.value?.intValue ?? 0
        //for Casino Stories
        self.savedGamingStoiresHoldingDays = feature.numberFieldWithName(fieldName: "saveGameStory")?.value?.intValue ?? 0
        // Search Optimization
        let version = feature.numberFieldWithName(fieldName: "searchVersion")?.value?.intValue ?? 1
        self.searchVersion = FeatureVersion(rawValue: version) ?? .v1
        if let biometric = feature.dictionaryFieldWithName(fieldName: "biometric")?.value {
            if let enableRegistrationBiometricAlert = biometric["enableRegistrationBiometricAlert"] as? Bool {
                self.enableRegistrationBiometricAlert = enableRegistrationBiometricAlert
            }
            if let enableLoginBiometricAlert = biometric["enableLoginBiometricAlert"] as? Bool {
                self.enableLoginBiometricAlert = enableLoginBiometricAlert
            }
        }
        if let inboxUnreadMessages = feature.dictionaryFieldWithName(fieldName: "inboxUnreadMessages")?.value as? [String: Any] {
            self.displayMessageCount = inboxUnreadMessages["displayMessageCount"] as? Bool ?? false
            self.enableInboxUnreadCount = inboxUnreadMessages["enableInboxUnreadCount"] as? Bool ?? false
        }
        if let userJourneys = feature.dictionaryFieldWithName(fieldName: "newUserJourneyJson")?.value as? [String: Any] {
            if let data = userJourneys.data() {
                self.userOnboardingJourneys = try? data.jsonDecoder(UserOnboardingJourneys.self).get()
            }
        }  
        if let inactiveSession = feature.dictionaryFieldWithName(fieldName: "inactiveSession")?.value as? [String: Any] {
            if let touchIdEnabled = inactiveSession["touchIdEnabled"] as? Bool {
                touchIdEnabledForInactiveSession = touchIdEnabled
            }
            if let showCloseButton = inactiveSession["showCloseButton"] as? Bool {
                showCloseButtonForInactiveSession = showCloseButton
            }
            if let showInactiveSession = inactiveSession["showNewInActiveSessionPopUp"] as? Bool {
                showNewInactiveSessionpopUp = showInactiveSession
            }
        }
    }
}



public struct RefreshWebView: Codable {
    public let userLevelData: UserLevelData
    public let oSLevelData: OSLevelData
    public let refreshLevel: Int
    public let count: Int
    enum CodingKeys: String, CodingKey {
        case userLevelData = "resetUserLevelData"
        case oSLevelData = "refreshWebView"
        case refreshLevel, count
    }
}
public struct UserLevelData: Codable {
    public let enable: Bool
    public let userList: [String]
    
    enum CodingKeys: String, CodingKey {
        case enable, userList
    }
}
public struct OSLevelData: Codable {
    public let enable: Bool
    public let osVersions: [String]
    
    enum CodingKeys: String, CodingKey {
        case enable, osVersions
    }
}

public struct CookieValues: Codable {
    public let name: String
    public let products: [String]
    public let jsonNameKey, jsonURLKey: String
    
    enum CodingKeys: String, CodingKey {
        case name, products, jsonNameKey
        case jsonURLKey = "jsonUrlKey"
    }
}

public struct LastKnownProduct: Codable {
    public let enable: Bool
    public let cookieValues: CookieValues
}
