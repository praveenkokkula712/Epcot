//
//  PosAppConfigurationCasino.swift
//  Wrapper
//
//  Created by Uday Kiran Veginati on 27/09/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

@objcMembers
public class PosAppConfigurationCasino: NSObject {
    
    public private(set) var baseUrl:String?
    public private(set) var externalBrowserPath:String?
    public private(set) var showInterstitialToExternalBrowser = false
    public private(set) var pokerUrl = ""
    public private(set) var liveUrl = ""
    public private(set) var sportsUrl = ""
    public private(set) var closeWebOnLogout: Bool = false
    public private(set) var enableWebFullPage: Bool = false
    public private(set) var blockWebUrlsOnGameWindow = [String]()
    // enableNativeHeader: To show header with close on login, registration
    public private(set) var enableNativeHeader: Bool = false
    public private(set) var htmlGamesRegex1 = ""
    public private(set) var htmlGamesRegex = [String: Any]()
    public private(set) var excludeGameIdKey = [String]()
    public private(set) var livecasinoKeys = [String]()
    public private(set) var allowedCasinoRegex = [String]()
    public private(set) var casinoBaseUrl: String?
    public private(set) var casinoLobbyUrls = [String]()
    public private(set) var webHeaderUrls: [String] = [String]()
    public private(set) var webFooterUrls: [String] = [String]()
    public private(set) var fullWebUrls: [String] = [String]()
    public private(set) var ignoreEnvironmentUrls: [String] = [String]()
    public private(set) var bottomBarUrls: [String: Any]?
    public private(set) var unsupportedUniversalLoaderUrls = [String]()
    private var casinoGamesAvailable: Bool = false
    public private(set) var postLoginHeaderType: Int = 0
    public private(set) var handleBlankPageOnPromo: Bool = false

    private let apiConfig = DynaconAPIConfiguration.shared

    init(feature: DynaconFeature) {
        super.init()
        self.baseUrl = feature.stringFieldWithName(fieldName: "casinoUrl")?.value
        self.externalBrowserPath = feature.stringFieldWithName(fieldName: "externalBrowserPath")?.value
        self.showInterstitialToExternalBrowser = feature.boolFieldWithName(fieldName: "showInterstitialToExternalBrowser")?.value ?? false
        self.closeWebOnLogout = feature.boolFieldWithName(fieldName: "closeWebOnLogout")?.value ?? false
        self.enableWebFullPage = feature.boolFieldWithName(fieldName: "enableWebFullPage")?.value ?? false
        self.enableNativeHeader = feature.boolFieldWithName(fieldName: "enableNativeHeader")?.value ?? false
        self.blockWebUrlsOnGameWindow = feature.arrayFieldWithName(fieldName: "blockWebUrlsOnGameWindow")?.value as? [String] ?? []
        self.pokerUrl = feature.stringFieldWithName(fieldName: "pokerUrl")?.value ?? ""
        self.liveUrl = feature.stringFieldWithName(fieldName: "liveUrl")?.value ?? ""
        self.sportsUrl = feature.stringFieldWithName(fieldName: "sportsUrl")?.value ?? ""
        self.htmlGamesRegex1 = feature.stringFieldWithName(fieldName: "htmlGamesRegex1")?.value ?? ""
        self.htmlGamesRegex = feature.dictionaryFieldWithName(fieldName: "htmlGamesRegex")?.value ?? [String: Any]()
        self.handleBlankPageOnPromo = feature.boolFieldWithName(fieldName: "handleBlankPage")?.value ?? false
        if let excludeKeys = feature.arrayFieldWithName(fieldName: "excludeGameIdKey")?.value as? [String] {
            self.excludeGameIdKey = excludeKeys
        }
        if let liveKeys = feature.arrayFieldWithName(fieldName: "livecasinoKey")?.value as? [String] {
            self.livecasinoKeys = liveKeys
        }
        if let allowedUrls = feature.arrayFieldWithName(fieldName: "allowedCasinoRegex")?.value as? [String] {
            self.allowedCasinoRegex = allowedUrls
        }
        if let casinoLobbyUrls = feature.arrayFieldWithName(fieldName: "casinoLobbyUrls")?.value as? [String] {
            self.casinoLobbyUrls = casinoLobbyUrls
        }
        casinoBaseUrl = feature.stringFieldWithName(fieldName: "casinoBaseUrl")?.value ?? ""
        if let excludeEnvUrls = feature.arrayFieldWithName(fieldName: "ignoreEnvironmentUrls")?.value as? [String] {
            self.ignoreEnvironmentUrls = excludeEnvUrls
        }
        if let nativeControls = feature.dictionaryFieldWithName(fieldName: "nativeUIControls")?.value as? [String: Any] {
            self.webHeaderUrls = nativeControls["webHeader"] as? [String] ?? [String]()
            self.webFooterUrls = nativeControls["webFooter"] as? [String] ?? [String]()
            self.fullWebUrls = nativeControls["fullWebPage"] as? [String] ?? [String]()
        }
        self.bottomBarUrls = feature.dictionaryFieldWithName(fieldName: "bottomBarUrls")?.value as? [String: Any]
        self.unsupportedUniversalLoaderUrls = feature.arrayFieldWithName(fieldName: "unsupportedUniversalLoaderUrls")?.value as? [String] ?? [String]()
        self.casinoGamesAvailable = feature.boolFieldWithName(fieldName: "isCasinoAvailable")?.value ?? false
        if let postLoginHeaderType = feature.numberFieldWithName(fieldName: "postLoginHeaderType")?.value {
            self.postLoginHeaderType = postLoginHeaderType.intValue
        }
    }
    
    public var isCasinoAvailable: Bool {
        switch apiConfig?.appConfigs?.productType {
        case .casino, .bingo:
            return true
        case .sports:
            return self.casinoGamesAvailable
        case .none:
            return false
        }
    }
}
