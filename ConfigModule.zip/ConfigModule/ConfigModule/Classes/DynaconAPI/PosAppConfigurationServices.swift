//
//  PosAppConfigurationServices.swift
//  Wrapper
//
//  Created by Harshita Sai Adagarla on 09/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit
import CasinoAPI

public class PosAppConfigurationServices: NSObject {

    public private(set) var posApiBaseUrls: [String]?
    public private(set) var itunesLookupUrl: String?

    public private(set) var brandDNS = ""
    public private(set) var feedDNS: Data?
    public private(set) var casinoApiRoutes: [String: Any]?
    public private(set) var dynaconBrandDNS: DynaconBrandDNSContext?
    public private(set) var bingoWidgetRoute: BingoWidgetRoute?
    public private(set) var prominentFreeSpinsEndPoint: ProminentFreeSpinsEndPoint?
    public private(set) var prominentFreeSpinsDetails: ProminentFreeSpinsFullDetails?
    public private(set) var liveFeedDns: String?
    public private(set) var promoEngagementToolsEndPoints: PromoEngagementToolsEndPoint?
    
    public init(feature: DynaconFeature) {
        super.init()

        if let posApiUrls = feature.arrayFieldWithName(fieldName: "posApiUrl")?.value as? [String] {
            self.posApiBaseUrls = posApiUrls
        }
        self.itunesLookupUrl = feature.stringFieldWithName(fieldName: "itunesLookupUrl")?.value
        if let feed = feature.dictionaryFieldWithName(fieldName: "feedDNS")?.value {
            self.feedDNS = try? JSONSerialization.data(withJSONObject: feed, options: [])
        }
        if let apiRoute = feature.dictionaryFieldWithName(fieldName: "apiRoutes")?.value {
            self.casinoApiRoutes = apiRoute["casino"] as? [String: Any]
        }
        if let brandDNS = feature.stringFieldWithName(fieldName: "brandDNS")?.value {
            self.brandDNS = brandDNS
        }
        if let dns = feature.dictionaryFieldWithName(fieldName: "newBrandDNS")?.value {
            let gameTiledns = dns["gameTileDNS"] as? String
            let gameLaunchdns = dns["gameLaunchDNS"] as? String
            self.dynaconBrandDNS = DynaconBrandDNSContext(gameLaunchdns: gameLaunchdns, gameTiledns: gameTiledns)
        }
        
        if let liveDns = feature.stringFieldWithName(fieldName: "liveFeedDNS")?.value {
            self.liveFeedDns = liveDns
        }
        
        /*
        if let bingoWidget = feature.dictionaryFieldWithName(fieldName: "bingoWidget")?.value {
            if let data = try? JSONSerialization.data(withJSONObject: bingoWidget, options: []) {
                self.bingoWidgetRoute = try? data.jsonDecoder(BingoWidgetRoute.self).get()
            }
        }
        
        if let endPoints = feature.dictionaryFieldWithName(
            fieldName: "prominentFreeSpinsEndPoints"
        )?.value,
           let data = try? JSONSerialization.data(withJSONObject: endPoints, options: []) {
            let endPoint = try? data.jsonDecoder(ProminentFreeSpinsEndPoint.self).get()
            self.prominentFreeSpinsEndPoint = endPoint
        }
        if let prominentFreeSpins = feature.dictionaryFieldWithName(fieldName: "prominentFreeSpinsDetails")?.value as? [String: Any] {
            if let data = prominentFreeSpins.data() {
                self.prominentFreeSpinsDetails = try? data.jsonDecoder(ProminentFreeSpinsFullDetails.self).get()
            }
        }
        */

        if let promoEngagementTools = feature.dictionaryFieldWithName(
            fieldName: "promoEngagementTools"
        )?.value as? [String: Any] {
            if let data = promoEngagementTools.data() {
                let endPoints = try? data.jsonDecoder(
                    PromoEngagementToolsEndPoint.self
                ).get()
                self.promoEngagementToolsEndPoints = endPoints
            }
        }
    }
}
