//
//  HeaderCSSModel.swift
//  Wrapper
//
//  Created by Vineela Janjirala on 22/02/22.
//  Copyright © 2022 bwin.com. All rights reserved.
//

import Foundation

public enum ElementType: String, Codable {
    case none, menu, brandLogo, href, login, join, deposit, account, username, balance, bonus, coinBalance
}

extension ElementType: ExpressibleByStringLiteral {
    public init(stringLiteral value: String) {
        if let _ = ElementType(rawValue: value) {
            self.init(rawValue: value)!
        } else {
            self.init(rawValue: "none")!
        }
    }
}

public enum DisplayType: String, Codable {
    case always, prelogin, postlogin
}

extension DisplayType: ExpressibleByStringLiteral {
    public init(stringLiteral value: String) {
        if let _ = DisplayType(rawValue: value) {
            self.init(rawValue: value)!
        } else {
            self.init(rawValue: "always")!
        }
    }
}

public struct DynamicHeaderModel: Codable {
    public let left: [Element]?
    public let right: [Element]?
    public let bgColor: String?
    public let height: Double?
    
    enum CodingKeys: String, CodingKey {
        case left = "left"
        case right = "right"
        case bgColor = "bgColor"
        case height = "height"
    }
    
    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        left = try values.decodeIfPresent([Element].self, forKey: .left)
        right = try values.decodeIfPresent([Element].self, forKey: .right)
        bgColor = try values.decodeIfPresent(String.self, forKey: .bgColor)
        height = try values.decodeIfPresent(Double.self, forKey: .height)
    }
}

public struct Element: Codable, Equatable {
    public let type: ElementType?
    public let logoName: String?
    public let display: DisplayType?
    public let order: Int?
    public let imagePath: String?
    public let refLink: String?
    public let text: String?
    public let textColor: String?
    public let borderColor: String?
    public let bgColor: String?
    public let gradientColors: [String]?
    public let borderWidth: Double?
    public let cornerRadius: Double?
    public let rightInset: Double?
    public let leftInset: Double?
    public let width: Double?
    public let height: Double?
    public let top: Double?
    public let child : ChildElement?
    public let firstWidth: Double?
    public let firstHeight: Double?
    public let fontSize : Double?
    public let fontType: String?
    public let textAlignment: Int?
    public let horizontalAlignment: Int?
    public let verticalAlignment: Int?
    public let accessibilityId: String?
    
    enum CodingKeys: String, CodingKey {
        
        case type = "type"
        case logoName = "logoName"
        case display = "display"
        case order = "order"
        case text = "text"
        case textColor = "textColor"
        case borderColor = "borderColor"
        case borderWidth = "borderWidth"
        case cornerRadius = "cornerRadius"
        case rightInset = "rightInset"
        case leftInset = "leftInset"
        case width = "width"
        case height = "height"
        case imagePath = "imagePath"
        case refLink = "refLink"
        case bgColor = "bgColor"
        case gradientColors = "gradientColors"
        case top = "top"
        case child = "child"
        case firstWidth = "firstWidth"
        case firstHeight = "firstHeight"
        case fontSize = "fontSize"
        case fontType = "fontType"
        case textAlignment = "textAlignment"
        case horizontalAlignment = "horizontalAlignment"
        case verticalAlignment = "verticalAlignment"
        case accessibilityId = "accessibilityId"
    }
    
    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        if let _type = try values.decodeIfPresent(String.self, forKey: .type) {
            type = ElementType(rawValue: _type)
        } else {
            type = ElementType.none
        }
        if let _display = try values.decodeIfPresent(String.self, forKey: .display) {
            display = DisplayType(rawValue: _display)
        } else {
            display = .always
        }
        logoName = try values.decodeIfPresent(String.self, forKey: .logoName)
        order = try values.decodeIfPresent(Int.self, forKey: .order)
        text = try values.decodeIfPresent(String.self, forKey: .text)
        textColor = try values.decodeIfPresent(String.self, forKey: .textColor)
        borderColor = try values.decodeIfPresent(String.self, forKey: .borderColor)
        borderWidth = try values.decodeIfPresent(Double.self, forKey: .borderWidth)
        cornerRadius = try values.decodeIfPresent(Double.self, forKey: .cornerRadius)
        rightInset = try values.decodeIfPresent(Double.self, forKey: .rightInset)
        width = try values.decodeIfPresent(Double.self, forKey: .width)
        height = try values.decodeIfPresent(Double.self, forKey: .height)
        imagePath = try values.decodeIfPresent(String.self, forKey: .imagePath)
        refLink = try values.decodeIfPresent(String.self, forKey: .refLink)
        bgColor = try values.decodeIfPresent(String.self, forKey: .bgColor)
        gradientColors = try values.decodeIfPresent([String].self, forKey: .gradientColors)
        leftInset = try values.decodeIfPresent(Double.self, forKey: .leftInset)
        top = try values.decodeIfPresent(Double.self, forKey: .top)
        child = try values.decodeIfPresent(ChildElement.self, forKey: .child)
        firstWidth = try values.decodeIfPresent(Double.self, forKey: .firstWidth)
        firstHeight = try values.decodeIfPresent(Double.self, forKey: .firstHeight)
        fontSize = try values.decodeIfPresent(Double.self, forKey: .fontSize)
        fontType = try values.decodeIfPresent(String.self, forKey: .fontType)
        textAlignment = try values.decodeIfPresent(Int.self, forKey: .textAlignment)
        horizontalAlignment = try values.decodeIfPresent(Int.self, forKey: .horizontalAlignment)
        verticalAlignment = try values.decodeIfPresent(Int.self, forKey: .verticalAlignment)
        accessibilityId = try values.decodeIfPresent(String.self, forKey: .accessibilityId)
    }
}

public struct ChildElement : Codable, Equatable {
    public let type: ElementType?
    public let text : String?
    public let textColor : String?
    public let fontSize : Double?
    public let top : Double?
    public let height : Double?
    public let fontType: String?
    public let textAlignment: Int?
    public let accessibilityId: String?

    enum CodingKeys: String, CodingKey {

        case type = "type"
        case text = "text"
        case textColor = "textColor"
        case fontSize = "fontSize"
        case top = "top"
        case height = "height"
        case fontType = "fontType"
        case textAlignment = "textAlignment"
        case accessibilityId = "accessibilityId"
    }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        if let _type = try values.decodeIfPresent(String.self, forKey: .type) {
            type = ElementType(rawValue: _type)
        } else {
            type = ElementType.none
        }
        text = try values.decodeIfPresent(String.self, forKey: .text)
        textColor = try values.decodeIfPresent(String.self, forKey: .textColor)
        fontSize = try values.decodeIfPresent(Double.self, forKey: .fontSize)
        top = try values.decodeIfPresent(Double.self, forKey: .top)
        height = try values.decodeIfPresent(Double.self, forKey: .height)
        fontType = try values.decodeIfPresent(String.self, forKey: .fontType)
        textAlignment = try values.decodeIfPresent(Int.self, forKey: .textAlignment)
        accessibilityId = try values.decodeIfPresent(String.self, forKey: .accessibilityId)
    }

}
