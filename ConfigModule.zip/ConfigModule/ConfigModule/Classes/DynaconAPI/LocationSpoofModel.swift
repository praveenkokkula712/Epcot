//
//  LocationSpoofModel.swift
//  DynaconAPI
//
//  Created by Yemireddi Sateesh on 09/06/23.
//

import Foundation

@objcMembers
public class LocationSpoofModel: NSObject, NSSecureCoding {
    public static var supportsSecureCoding: Bool = true
    // MARK: - Properties
    public var name: String?
    public var latitude, longitude: Double?

    // MARK: - Init
    override init() {
        super.init()
    }

    public init(name: String?,
                latitude: Double?,
                longitude: Double?) {
        super.init()
        self.name = name
        self.latitude = latitude
        self.longitude = longitude
    }

    // MARK: - Coding
    required convenience public init(coder aDecoder: NSCoder) {
        self.init()
        name = aDecoder.decodeObject(forKey: "name") as? String
        latitude = aDecoder.decodeObject(forKey: "latitude") as? Double
        longitude = aDecoder.decodeObject(forKey: "longitude")  as? Double
    }

    public func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: "name")
        aCoder.encode(latitude, forKey: "latitude")
        aCoder.encode(longitude, forKey: "longitude")
    }
}
