//
//  PosAppConfigurationSliderGames.swift
//  Wrapper
//
//  Created by Harshita Sai Adagarla on 09/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

@objcMembers
public class PosAppConfigurationSliderGames: NSObject {
    public private(set) var enabled: Bool?
    public private(set) var baseUrl: String?
    public private(set) var defaultGameType: Int?
    public private(set) var isDefaultPositionLeft: Bool?
    public private(set) var minAge: Int?
    public private(set) var promotionEnabled: Bool?
    public private(set) var sliderConfig: [String:Any]?
    public private(set) var feedConfig: [String:Any]?
    public private(set) var countries: [String:Any]?
    
    public init(feature: DynaconFeature) {
        super.init()

        self.enabled = feature.boolFieldWithName(fieldName: "enable")?.value
        self.baseUrl = feature.stringFieldWithName(fieldName: "baseUrl")?.value
        self.defaultGameType = feature.numberFieldWithName(fieldName: "default")?.value as? Int
        self.isDefaultPositionLeft = feature.stringFieldWithName(fieldName: "defaultPosition")?.value == "left" ? true : false
        self.minAge = feature.numberFieldWithName(fieldName: "minAge")?.value as? Int
        self.promotionEnabled = feature.boolFieldWithName(fieldName: "enablePromotion")?.value
        self.sliderConfig = feature.dictionaryFieldWithName(fieldName: "slider_config")?.value
        self.feedConfig = feature.dictionaryFieldWithName(fieldName: "feed_config")?.value
        var countriesDict = [String:Any]()
        if let keys = feature.fields?.keys {
            for gameTypeString in keys {
                let gameType = Int(gameTypeString ) ?? 0
                let gameTypeString2 = String(describing: gameType)
                if gameType != 0 && gameTypeString == gameTypeString2 {
                    countriesDict["\(gameType)"] = feature.arrayFieldWithName(fieldName: gameTypeString)?.value
                }
            }
        }
        if countriesDict.count > 0 {
            self.countries = countriesDict
        }
    }

    @objc public func isEnabled() -> Bool {
        return self.enabled ?? false
    }
    
    @objc public func defaultGame() -> NSNumber {
        return NSNumber(value: self.defaultGameType ?? 0)
    }
    
    @objc public func isDefaultLeft() -> Bool {
        return self.isDefaultPositionLeft ?? false
    }
}
