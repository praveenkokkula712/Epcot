//
//  JackpotAllignment.swift
//  EpcotLobby
//
//  Created by Bandana Choudhury on 02/09/24.
//

import Foundation

public enum JackpotTitleAlignment: Int {
        case left
        case center
        case right
        
        public init?(rawValue: Int) {
            switch rawValue {
            case 1:
                self = .center
            case 2:
                self = .right
            default:
                self = .left
            }
        }
    }
