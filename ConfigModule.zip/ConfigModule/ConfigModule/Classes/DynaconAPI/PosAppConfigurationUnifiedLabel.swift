//
//  PosAppConfigurationUnifiedLabel.swift
//  Wrapper
//
//  Created by Uday Kiran Veginati on 5/6/20.
//  Copyright © 2020 bwin.com. All rights reserved.
//

import UIKit

public class PosAppConfigurationUnifiedLabel: NSObject {

    public private(set) var config: [String: Any]?
    public private(set) var stateSwitcherUrl: String?
    public private(set) var versionSpecificDefaultState: [String: Any]?
    public private(set) var odrConfig: [String: Any]?
    public private(set) var odrChannel: [String: Any]?
    public private(set) var regionCodeMap: [String: Any]?
    public private(set) var supportedLanguages: [String]?
    public private(set) var defaultLanguage: String?
    
    private let apiConfig = DynaconAPIConfiguration.shared

    public init(feature: DynaconFeature) {
        super.init()
        if apiConfig?.appConfigs?.productType == .sports {
            self.config = feature.dictionaryFieldWithName(fieldName: "sportsConfig")?.value
            self.stateSwitcherUrl = feature.stringFieldWithName(fieldName: "sportsStateSwitcherUrl")?.value
            self.odrConfig = feature.dictionaryFieldWithName(fieldName: "sportsODRConfig")?.value
        } else if apiConfig?.appConfigs?.productType == .casino {
            self.config = feature.dictionaryFieldWithName(fieldName: "casinoConfig")?.value
            self.stateSwitcherUrl = feature.stringFieldWithName(fieldName: "casinoStateSwitcherUrl")?.value
            self.odrConfig = feature.dictionaryFieldWithName(fieldName: "casinoODRConfig")?.value
        }
        if let version = apiConfig?.appConfigs?.bundleShortVersion {
            self.odrChannel = feature.dictionaryFieldWithName(fieldName: "OdrChannel")?.value?[version] as? [String : Any]
        }
        self.versionSpecificDefaultState = feature.dictionaryFieldWithName(fieldName: "versionSpecificDefaultState")?.value
        self.regionCodeMap = feature.dictionaryFieldWithName(fieldName: "regionCodeMap")?.value
        if let languages = feature.dictionaryFieldWithName(fieldName: "languages")?.value as? [String: Any] {
            self.defaultLanguage = languages["default"] as? String
            self.supportedLanguages = languages["supported"] as? [String]
        }
    }
}
