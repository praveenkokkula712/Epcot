//
//  PosAppConfigurationCashier.swift
//  Wrapper
//
//  Created by Uday Kiran Veginati on 21/03/2019.
//  Copyright © 2019 bwin.com. All rights reserved.
//

import UIKit

public class PosAppConfigurationCashier: NSObject {
    public private(set) var baseUrl: String?
    public private(set) var depositPath: String?
    public private(set) var withdrawPath: String?
    public private(set) var enabledOutOfStateDepositPopUP: Bool = false
    public private(set) var currencySymbol: [String: String]?
    public private(set) var fetchNetBalance: Bool = false
    public private(set) var isVenmoRequired: Bool = false
    public private(set) var fetchBonusBalance: Bool = false
    public private(set) var balanceBreakDownUrl: String?
    public private(set) var balanceFormat: String?
    public private(set) var enableDepositFlow: Bool = false
    public private(set) var fetchCoinBalance: Bool = false
    public private(set) var coinBalanceIconUrl: String?
    public private(set) var coinBalanceUrl: String?
    public private(set) var coinBalanceSilverIconUrl: String?

    public init(feature: DynaconFeature) {
        self.baseUrl = feature.stringFieldWithName(fieldName: "cashierUrl")?.value
        self.depositPath = feature.stringFieldWithName(fieldName: "depositPath")?.value
        self.withdrawPath = feature.stringFieldWithName(fieldName: "withdrawPath")?.value
        self.fetchNetBalance = feature.boolFieldWithName(fieldName: "fetchNetBalance")?.value ?? false
        self.fetchBonusBalance = feature.boolFieldWithName(fieldName: "fetchBonusBalance")?.value ?? false
        self.isVenmoRequired = feature.boolFieldWithName(fieldName: "isVenmoRequired")?.value ?? false
        self.balanceBreakDownUrl = feature.stringFieldWithName(fieldName: "balanceBreakDownUrl")?.value
        self.currencySymbol = feature.dictionaryFieldWithName(fieldName: "currencyToSymbolMapping")?.value as? [String : String]
        self.balanceFormat = feature.stringFieldWithName(fieldName: "balanceFormat")?.value
        self.enableDepositFlow = feature.boolFieldWithName(fieldName: "enableDepositFlow")?.value ?? false
        self.coinBalanceIconUrl = feature.stringFieldWithName(fieldName: "coinBalanceIconUrl")?.value
        if let usComplianceDepositInfo = feature.dictionaryFieldWithName(fieldName: "usComplianceDeposit")?.value {
            if let enabledOutOfStateDepositPopUP = usComplianceDepositInfo["enabledOutOfStateDepositPopUP"] as? Bool {
                self.enabledOutOfStateDepositPopUP = enabledOutOfStateDepositPopUP
            }
        }
        if let coinBalance = feature.dictionaryFieldWithName(fieldName: "coinBalance")?.value {
            self.coinBalanceIconUrl = coinBalance["coinBalanceIconUrl"] as? String ?? ""
            self.fetchCoinBalance = coinBalance["fetchCoinBalance"] as? Bool ?? false
            self.coinBalanceUrl = coinBalance["coinHomePageUrl"] as? String ?? ""
            self.coinBalanceSilverIconUrl = coinBalance["coinBalanceSilverIconUrl"] as? String ?? ""
        }
    }
}
