//
//  PosAppConfigurationSiteCore.swift
//  Wrapper
//
//  Created by Uday Kiran Veginati on 11/08/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

public class PosAppConfigurationSiteCore: NSObject {
    
    public private(set) var endpoint: String?
    public private(set) var environment: String?
    public private(set) var languageCulture: [String: String]?
    public private(set) var spotlightSearchItemsPath: String?
    public private(set) var touchIdPopupPath: String?
    public private(set) var threeDTouchItemsPath: String?
    public private(set) var bottomNavigationItems: String?
    public private(set) var nativeFooterAboutUsPath = ""
    public private(set) var nativeFooterContentMessagesPath = ""
    public private(set) var nativeFooterCopyRightPath = ""
    public private(set) var nativeFooterLogoItemsPath = ""
    public private(set) var productMenuPath = ""
    public private(set) var headerRegulatoryPath = ""
    public private(set) var nativeFooterSEOLinksPath = ""
    public private(set) var nativeFooterBrandLogoPath = ""
    public private(set) var realityCheckLoginSessionWidgetPath = ""
    public private(set) var popupContentPath: String?
    public private(set) var crossProductMinBreakWidgetPath = ""
    public private(set) var gameplayMinBreakWidgetPath = ""
    public private(set) var rtpBigWinWidgetPath = ""
    public private(set) var nativeLossLimitKeys = ""
    public private(set) var nativeSessionLimitKeys = ""
    public private(set) var nativeSessionLogoutKeys = ""
    public private(set) var nativeSingleSessionExpiryKeys = ""
    public private(set) var usCompliancePopUpContentPath = ""
    public private(set) var usRegulatoryPopUpContentPath = ""
    public private(set) var biometricPopUpContentPath: String?
    public private(set) var osPrimersPopUpContent = ""
    public private(set) var unverifiedKycPopUpContent: String?
    public private(set) var verificationPendingKycPopUpContent: String?
    public private(set) var nativeFooterLoginDurationTimerPath = ""
    public private(set) var nativeSubCategoriespath = ""
    public private(set) var nativeBurgerMenuPath = ""
    public private(set) var teasersPath = ""
    public private(set) var rcpUKItemsPath = ""
    public private(set) var playBreakStartedDurningGamePlay = ""
    public private(set) var playBreakAboutToStartDuringGamePlay = ""
    public private(set) var arcBreakCompliance = ""
    public private(set) var regulatoryStringsPath = ""
    public private(set) var lossLimitItemsPath = ""
    public private(set) var oneHourRCPContent = ""
    public private(set) var loadingScreenPath: String?
    public private(set) var updateAvailablePath: String?
    public private(set) var authadaPath: String?
    public private(set) var freeBetPath: String?
    public private(set) var alertViewPath: String?
    public private(set) var appFeedbackPath: String?
    public private(set) var appFlyerPath: String?
    public private(set) var commonPath: String?
    public private(set) var documentUploadPath: String?
    public private(set) var errorPath: String?
    public private(set) var gameInfoPath: String?
    public private(set) var lobbyPath: String?
    public private(set) var loginPath: String?
    public private(set) var miniGamesPath: String?
    public private(set) var sideMenuPath: String?
    public private(set) var usnjPath: String?
    public private(set) var rateMyApp: String?
    public private(set) var nativeWidgetPath: String?
    public private(set) var jackpotWidgetPath: String?
    public private(set) var jackpotFusionPath: String?
    public private(set) var arcPlayerBreak: String?
    public private(set) var arcRtmsGracePeriod: String?
    public private(set) var arcRtmsPlayerBreak: String?
    public private(set) var arcRtmsLSLPlayBreak: String?
    public private(set) var arcRtmsLSL24T1PlayBreak: String?
    public private(set) var arcRtmsLSL24PlayBreak: String?
    public private(set) var arcRtmsLSLContinuousPlayBreak: String?
    public private(set) var productSwitchCoolOff: String?
    public private(set) var enableSitecoreItemsFilter: Bool = false
    public private(set) var gameStoriesPath: String?
    public private(set) var newUserOnboardingJourneyPath: String?
    public private(set) var errorCodeHandlersPath: String?
    public private(set) var casinoStoriesPath: String?
    public private(set) var searchV2Path: String?
    public private(set) var touchIdLogoPath: String?
    public private(set) var faceIdLogoPath: String?
    public private(set) var bingoRoomImagesPath: String?
    public private(set) var bingoRoomIconsPath: String?
    public private(set) var bingoRoomTextsPath: String?
    public private(set) var bingoRoomNamesPath: String?
    public private(set) var bingoGameFeatureIconsPath: String?
    public private(set) var bingoRoomGlobalTextsPath: String?
    public private(set) var bingoRoomGlobalSEPTextsPath: String?
    public private(set) var bingoRoomSingleEntryPointPath: String?
    public private(set) var gamePremierePath: String?
    public private(set) var freeSpinsWidgetConfigurationTextsPath: String?
    public private(set) var freeSpinsWidgetBackroundImagePath: String?
    public private(set) var freeSpinsWidgetCtaBackgroundImagePath: String?
    public private(set) var freeSpinsStringsPath: String?
    public private(set) var playerStatsWidgetConfigurationsPath: String?
    public private(set) var playerStatsImagesPath: String?
    public private(set) var jackpotTilesPath: String?
    public private(set) var jackpotTilesOrderPath: String?
    public private(set) var sessionLimitsLocalizationStringsPath: String?
    public private(set) var originalsWidgetContentPath: String?
    public private(set) var liveCasinoAPIDataPath: String?
    public private(set) var engagementToolsPath: String?

    public init(feature: DynaconFeature) {
        super.init()
        
        self.endpoint = feature.stringFieldWithName(fieldName: "endpoint")?.value
        self.environment = feature.stringFieldWithName(fieldName: "environment")?.value
        self.languageCulture = feature.dictionaryFieldWithName(fieldName: "languageCulture")?.value as? [String : String]
        self.spotlightSearchItemsPath = feature.stringFieldWithName(fieldName: "spotlightSearchItems")?.value
        self.threeDTouchItemsPath = feature.stringFieldWithName(fieldName: "3DTouchItems")?.value
        self.touchIdPopupPath = feature.stringFieldWithName(fieldName: "touchIdPopUp")?.value
        self.bottomNavigationItems = feature.stringFieldWithName(fieldName: "bottomNavigationItems")?.value ?? ""
        self.nativeFooterLogoItemsPath = feature.stringFieldWithName(fieldName: "nativeFooterLogoItems")?.value ?? ""
        self.nativeFooterAboutUsPath = feature.stringFieldWithName(fieldName: "nativeFooterAboutUs")?.value ?? ""
        self.nativeFooterCopyRightPath = feature.stringFieldWithName(fieldName: "nativeFooterCopyRight")?.value ?? ""
        self.nativeFooterLoginDurationTimerPath = feature.stringFieldWithName(fieldName: "nativeFooterLoginDurationTimer")?.value ?? ""
        self.nativeFooterContentMessagesPath = feature.stringFieldWithName(fieldName: "nativeFooterContentMessages")?.value ?? ""
        self.productMenuPath = feature.stringFieldWithName(fieldName: "productMenu")?.value ?? ""
        self.headerRegulatoryPath = feature.stringFieldWithName(fieldName: "headerRegulatoryPath")?.value ?? ""
        self.nativeFooterSEOLinksPath = feature.stringFieldWithName(fieldName: "nativeFooterSEOLinksPath")?.value ?? ""
        self.nativeFooterBrandLogoPath = feature.stringFieldWithName(fieldName: "nativeFooterBrandLogoPath")?.value ?? ""
        self.realityCheckLoginSessionWidgetPath = feature.stringFieldWithName(fieldName: "realityCheckLoginSessionWidget")?.value ?? ""
        self.popupContentPath = feature.stringFieldWithName(fieldName: "UpdatePopUpContent")?.value
        self.biometricPopUpContentPath = feature.stringFieldWithName(fieldName: "touchFaceIdPopUpContent")?.value
        self.crossProductMinBreakWidgetPath = feature.stringFieldWithName(fieldName: "crossProductMinBreakWidget")?.value ?? ""
        self.gameplayMinBreakWidgetPath = feature.stringFieldWithName(fieldName: "gameplayMinBreakWidget")?.value ?? ""
        self.rtpBigWinWidgetPath = feature.stringFieldWithName(fieldName: "rtpBigWinWidget")?.value ?? ""
        self.nativeLossLimitKeys = feature.stringFieldWithName(fieldName: "nativeLossLimitKeys")?.value ?? ""
        self.nativeSessionLimitKeys = feature.stringFieldWithName(fieldName: "nativeSessionLimitKeys")?.value ?? ""
        self.nativeSessionLogoutKeys = feature.stringFieldWithName(fieldName: "nativeSessionLogoutKeys")?.value ?? ""
        self.nativeSingleSessionExpiryKeys = feature.stringFieldWithName(fieldName: "nativeSingleSessionExpiryKeys")?.value ?? ""
        self.usCompliancePopUpContentPath = feature.stringFieldWithName(fieldName: "usCompliancePopUpContentPath")?.value ?? ""
        self.usRegulatoryPopUpContentPath = feature.stringFieldWithName(fieldName: "usRegulatoryPopUpContentPath")?.value ?? ""
        self.osPrimersPopUpContent = feature.stringFieldWithName(fieldName: "osPrimersPopUpContent")?.value ?? ""
        if let arcPlayBreak = feature.dictionaryFieldWithName(fieldName: "arcPlayerBreak")?.value {
            self.arcPlayerBreak = arcPlayBreak["arcPlayerBreakPath"] as? String ?? ""
            self.arcRtmsGracePeriod = arcPlayBreak["arcRtmsGracePeriodPath"] as? String ?? ""
            self.arcRtmsPlayerBreak = arcPlayBreak["arcRtmsPlayerBreakPath"] as? String ?? ""
            self.arcRtmsLSLPlayBreak = arcPlayBreak["arcRtmsLSLPlayBreakPath"] as? String ?? ""
            self.arcRtmsLSL24T1PlayBreak = arcPlayBreak["arcRtmsLSL24T1PlayBreakPath"] as? String ?? ""
            self.arcRtmsLSL24PlayBreak = arcPlayBreak["arcRtmsLSL_24_PlayBreakPath"] as? String ?? ""
            self.arcRtmsLSLContinuousPlayBreak = arcPlayBreak["arcRtmsLSL_Continuous_PlayBreakPath"] as? String ?? ""
        }
        self.verificationPendingKycPopUpContent = feature.stringFieldWithName(fieldName: "verificationPendingKycPopUpContent")?.value ?? ""
        self.unverifiedKycPopUpContent = feature.stringFieldWithName(fieldName: "unverifiedKycPopUpContent")?.value ?? ""
        self.nativeSubCategoriespath = feature.stringFieldWithName(fieldName: "nativeSubCategoriespath")?.value ?? ""
        self.nativeBurgerMenuPath = feature.stringFieldWithName(fieldName: "nativeBurgerMenuPath")?.value ?? ""
        self.teasersPath = feature.stringFieldWithName(fieldName: "teasersPath")?.value ?? ""
        self.rcpUKItemsPath = feature.stringFieldWithName(fieldName: "rcpUKItemsPath")?.value ?? ""
        self.playBreakStartedDurningGamePlay = feature.stringFieldWithName(fieldName: "playBreakStartedDurningGamePlay")?.value ?? ""
        self.playBreakAboutToStartDuringGamePlay = feature.stringFieldWithName(fieldName: "playBreakAboutToStartDuringGamePlay")?.value ?? ""
        self.lossLimitItemsPath = feature.stringFieldWithName(fieldName: "lossLimitItemsPath")?.value ?? ""
        self.oneHourRCPContent = feature.stringFieldWithName(fieldName: "oneHourRCPContent")?.value ?? ""
        if let localizationStringsPath = feature.dictionaryFieldWithName(fieldName: "LocalizationStringsPath")?.value {
            self.loadingScreenPath =  localizationStringsPath["loadingScreenPath"] as? String ?? ""
            self.updateAvailablePath =  localizationStringsPath["updateAvailablePath"] as? String ?? ""
            self.authadaPath =  localizationStringsPath["authadaPath"] as? String ?? ""
            self.freeBetPath =  localizationStringsPath["freeBetPath"] as? String ?? ""
            self.alertViewPath =  localizationStringsPath["alertViewPath"] as? String ?? ""
            self.appFeedbackPath =  localizationStringsPath["appFeedbackPath"] as? String ?? ""
            self.appFlyerPath =  localizationStringsPath["appFlyerPath"] as? String ?? ""
            self.commonPath =  localizationStringsPath["commonPath"] as? String ?? ""
            self.documentUploadPath =  localizationStringsPath["documentUploadPath"] as? String ?? ""
            self.errorPath =  localizationStringsPath["errorPath"] as? String ?? ""
            self.gameInfoPath =  localizationStringsPath["gameInfoPath"] as? String ?? ""
            self.lobbyPath =  localizationStringsPath["lobbyPath"] as? String ?? ""
            self.loginPath =  localizationStringsPath["loginPath"] as? String ?? ""
            self.miniGamesPath =  localizationStringsPath["miniGamesPath"] as? String ?? ""
            self.sideMenuPath =  localizationStringsPath["sideMenuPath"] as? String ?? ""
            self.usnjPath =  localizationStringsPath["usnjPath"] as? String ?? ""
            self.arcBreakCompliance = localizationStringsPath["arcBreakCompliancePath"] as? String ?? ""
            self.regulatoryStringsPath = localizationStringsPath["regulatoryPath"] as? String ?? ""
            self.rateMyApp = localizationStringsPath["rateMyAppPath"] as? String ?? ""
            self.newUserOnboardingJourneyPath = localizationStringsPath["newUserOnboardingJourneyPath"] as? String ?? ""
            self.casinoStoriesPath = localizationStringsPath["casinoStoriesPath"] as? String ?? ""
            self.searchV2Path = localizationStringsPath["searchOptimizationPath"] as? String ?? ""
//            self.freeSpinsStringsPath = localizationStringsPath["freeSpinsStringsPath"] as? String ?? ""
            self.sessionLimitsLocalizationStringsPath = localizationStringsPath["sessionLimitsStringsPath"] as? String ?? ""
        }
        if let widgetPaths = feature.dictionaryFieldWithName(fieldName: "nativeWidgetPaths")?.value {
            self.nativeWidgetPath = widgetPaths["nativeWidgetPath"] as? String ?? ""
            self.jackpotWidgetPath = widgetPaths["jackpotWidgetPath"] as? String ?? ""
            self.jackpotTilesOrderPath = widgetPaths["jackpotTilesOrderPath"] as? String ?? ""
            self.jackpotTilesPath = widgetPaths["jackpotTilesPath"] as? String ?? ""
            self.originalsWidgetContentPath = widgetPaths["originalsWidgetPath"] as? String ?? ""
        }
        self.productSwitchCoolOff = feature.stringFieldWithName(fieldName: "productSwitchCoolOffPath")?.value
        self.enableSitecoreItemsFilter = feature.boolFieldWithName(fieldName: "enableSitecoreItemsFilter")?.value ?? false
        self.gameStoriesPath = feature.stringFieldWithName(fieldName: "casinoGameStoriesPath")?.value
        self.errorCodeHandlersPath = feature.stringFieldWithName(fieldName: "errorCodeHandlersPath")?.value ?? ""
        self.gamePremierePath = feature.stringFieldWithName(fieldName: "gamePremierePath")?.value ?? ""

        if let newBiometricPopUpLogoPath = feature.dictionaryFieldWithName(fieldName: "nativeNewBiometricPopUpLogoPath")?.value {
            self.touchIdLogoPath = newBiometricPopUpLogoPath["touchIdLogoPath"] as? String ?? ""
            self.faceIdLogoPath = newBiometricPopUpLogoPath["faceIdLogoPath"] as? String ?? ""
        }
        /*
        if let bingoWidget = feature.dictionaryFieldWithName(fieldName: "bingoWidget")?.value {
            bingoRoomImagesPath = bingoWidget["roomImagesPath"] as? String ?? ""
            bingoRoomIconsPath = bingoWidget["iconsPath"] as? String ?? ""
            bingoRoomTextsPath = bingoWidget["roomsTextsPath"] as? String ?? ""
            bingoRoomNamesPath = bingoWidget["roomNamesPath"] as? String ?? ""
            bingoGameFeatureIconsPath = bingoWidget["gameFeatureIconsPath"] as? String ?? ""
            bingoRoomGlobalTextsPath = bingoWidget["globalTextsPath"] as? String ?? ""
            bingoRoomGlobalSEPTextsPath = bingoWidget["globalSEPTextsPath"] as? String ?? ""
            bingoRoomSingleEntryPointPath = bingoWidget["singleEntryPoint"] as? String ?? ""
        }
        
        if let freeSpinsWidgetPath = feature.dictionaryFieldWithName(fieldName: "freespinswidget")?.value {
            freeSpinsWidgetConfigurationTextsPath = freeSpinsWidgetPath["configurations"] as? String ?? ""
            freeSpinsWidgetBackroundImagePath = freeSpinsWidgetPath["widgetBackgroundImage"] as? String ?? ""
            freeSpinsWidgetCtaBackgroundImagePath = freeSpinsWidgetPath["ctaBackgroundImage"] as? String ?? ""
        }
         */
        if let playerStatsWidgetPath = feature.dictionaryFieldWithName(fieldName: "playerStatsWidget")?.value {
            self.playerStatsWidgetConfigurationsPath = playerStatsWidgetPath["playerStatsTextsConfigurationsPath"] as? String
            self.playerStatsImagesPath = playerStatsWidgetPath["playerStatsBackGroundImagesPath"] as? String
        }
        if let liveCasinoApiData = feature.dictionaryFieldWithName(fieldName: "liveCasinoApiData")?.value {
            self.liveCasinoAPIDataPath = liveCasinoApiData["liveCasinoDataPath"] as? String
        }
        if let engagementTools = feature.dictionaryFieldWithName(fieldName: "engagementTools")?.value {
            self.engagementToolsPath = engagementTools["engagementToolsPath"] as? String
        }
    }
}
