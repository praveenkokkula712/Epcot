//
//  PosAppConfigurationSibling.swift
//  Wrapper
//
//  Created by Harshita Sai Adagarla on 09/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

public class PosAppConfigurationSibling: NSObject {
    
    public private(set) var siblingData: Dictionary<String,Any>?
    
    public private(set) var isSibling: Bool?
    public private(set) var appEnabled: Bool?
    public private(set) var maintenanceEnabled: Bool?
    public private(set) var mandatoryUpdateEnabled: Bool?
    public private(set) var updateUrl: String?
    public private(set) var latestVersion: String?
    public private(set) var minOsVersion: String?
    public private(set) var allowedCountries: [String]?
    public private(set) var webURL: String?
    public private(set) var portalBaseURL: String?
    public private(set) var redirectUrlOnGeoBlock: String?
    public private(set) var iTunesDefaultCountry:String?
    public private(set) var iTunesDefaultLanguage:String?
    
    private let apiConfig = DynaconAPIConfiguration.shared

    public init(feature: DynaconFeature) {
        super.init()

        if let siblingData = feature.dictionaryFieldWithName(fieldName: "siblingData")?.value {
            self.siblingData = siblingData
            if let itemIdentifier = apiConfig?.appConfigs?.iTunesAppItemIdentifier {
                if let sibling = siblingData[itemIdentifier] as? [String:Any] {
                    self.isSibling = true
                    self.maintenanceEnabled = sibling["enableMaintenance"] as? Bool
                    self.mandatoryUpdateEnabled = sibling["enableMandatoryUpdate"] as? Bool
                    self.updateUrl = sibling["updateUrl"] as? String
                    self.latestVersion = sibling["latestVersion"] as? String
                    self.minOsVersion = sibling["minOSVersion"] as? String
                    self.allowedCountries = sibling["countriesAllowed"] as? [String]
                    self.appEnabled = sibling["enableApp"] as? Bool
                    self.webURL = sibling["newWebURL"] as? String
                    self.portalBaseURL = sibling["portalUrl"] as? String
                    self.redirectUrlOnGeoBlock = sibling["redirectOnGeoBlock"] as? String
                    if let itunesParams = sibling["iTunesUpdateParams"] as? [String: String] {
                        self.iTunesDefaultLanguage = itunesParams["iTunesDefaultLanguage"]
                        self.iTunesDefaultCountry = itunesParams["iTunesDefaultCountry"]
                    }
                }
                else {
                    self.isSibling = false
                }
            }
        }
    }
}
