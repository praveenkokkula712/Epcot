//
//  PosAppConfigurationFeedback.swift
//  Wrapper
//
//  Created by Vinod Kumar Muppala on 06/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

public class PosAppConfigurationFeedbackInterval: NSObject {
    
    public private(set) var bets: Int?
    public private(set) var days: Int?
    
    public init(json : Dictionary<String, Any>) {
        super.init()

        if let bets = json["bets"] as? Int {
            self.bets = bets
        }
        if let days = json["days"] as? Int {
            self.days = days
        }
    }
}

public class PosAppConfigurationFeedback: NSObject {

    public private(set) var intervals:Array<PosAppConfigurationFeedbackInterval>?
    public private(set) var feedbackEmail:String?
    public private(set) var feedbackCCEmails:Array<Any>?
    public private(set) var enabled:Bool?
    public private(set) var maxCancelCount:Int?
    public private(set) var maxAppLaunchCount:Int?
    public private(set) var brandName = ""
    public private(set) var durationGap: Array<Int>?
    public private(set) var enableRTAJoy: Bool?
    public private(set) var maxLoginCount: Int?
    public private(set) var maxDurationDays: Int?

    private let apiConfig = DynaconAPIConfiguration.shared

    public init(feature: DynaconFeature) {
        super.init()

        self.enabled = feature.boolFieldWithName(fieldName: "enable")?.value
        self.feedbackCCEmails = feature.arrayFieldWithName(fieldName: "feedbackCCEmails")?.value
        self.brandName = feature.stringFieldWithName(fieldName: "brandName")?.value ?? ""
        if apiConfig?.appConfigs?.productType == .sports {
            var intervals = [PosAppConfigurationFeedbackInterval]()
            if let configArray = feature.arrayFieldWithName(fieldName: "cfg")?.value {
                for intervalJson in configArray {
                    let interval = PosAppConfigurationFeedbackInterval(json:intervalJson as! Dictionary<String, Any>)
                    intervals.append(interval)
                }
                if intervals.count > 0 {
                    self.intervals = intervals
                }
            }
            
            self.feedbackEmail = feature.stringFieldWithName(fieldName: "feedbackEmail")?.value
            self.maxCancelCount = feature.numberFieldWithName(fieldName: "maxCancelCount")?.value as? Int
            
        } else {
            
            if let configuration = feature.dictionaryFieldWithName(fieldName: "configuration")?.value {
                if let cancelCount = configuration["maxCancelCount"] {
                    self.maxCancelCount = cancelCount as? Int
                }
                
                if let appLaunchCount = configuration["maxAppLaunchCount"] {
                    self.maxAppLaunchCount = appLaunchCount as? Int
                }
                
                if let days = configuration["gapDuration"] as? Array<Int> {
                    self.durationGap = days
                }
                    
                self.enableRTAJoy = configuration["enableRTAJoy"] as? Bool ?? true
                
                if let maxLoginCount = configuration["maxLoginCount"] {
                    self.maxLoginCount = maxLoginCount as? Int
                }
                if let maxDurationDays = configuration["maxDurationDays"] {
                    self.maxDurationDays = maxDurationDays as? Int
                }
            }
            self.feedbackEmail = feature.stringFieldWithName(fieldName: "feedbackEmail")?.value
        }
        //if gap duration array in Dynacon is not configured then max cancel count should be set to 1
        if let days = self.durationGap, days.isEmpty {
            self.maxCancelCount = 1
        }
    }
}
