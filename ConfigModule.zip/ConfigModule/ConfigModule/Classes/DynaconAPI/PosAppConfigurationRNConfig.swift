//
//  PosAppConfigurationRNConfig.swift
//  ConfigModule
//
//  Created by Venkat Rao Sandhi on 27/10/23.
//

import UIKit
import CasinoAPI

@objcMembers
public class PosAppConfigurationRNConfig: NSObject {
    
    public private(set) var enableGoogleRecaptcha = false
    public private(set) var rnrecaptchaSiteKey: String = ""
    public private(set) var rnRecaptchaRetryCount: Int = 0
    public private(set) var rnApiRequestTimeout: Int = 0
    public private(set) var rnApiRetrycount: Int = 0
    public private(set) var rnEnableBiometric = false
    public private(set) var enableXceleratorNLogin = false
    public private(set) var isInterceptorRedirectionFromCCB = false
    public private(set) var isRNWebviewUsed = true
    public private(set) var loginErrorToasterTime = 0
    public private(set) var showCodepushPopUp = false
    public private(set) var enableRNLoginPopUp = true
    public private(set) var yahooLoginPath: String = ""
    
    public init(feature: DynaconFeature) {
        super.init()
        if let googleRecaptcha = feature.dictionaryFieldWithName(fieldName: "googleRecaptcha")?.value {
            self.enableGoogleRecaptcha = googleRecaptcha["enableGoogleRecaptcha"] as? Bool ?? false
            self.rnRecaptchaRetryCount = googleRecaptcha["recaptchaRetryCount"] as? Int ?? -1
            self.rnrecaptchaSiteKey =  googleRecaptcha["recaptchaSiteKey"] as? String ?? ""
        }
        if let rnApiConfig = feature.dictionaryFieldWithName(fieldName: "rnApiConfig")?.value {
            self.rnApiRequestTimeout = rnApiConfig["apiRequestTimeout"] as? Int ?? -1
            self.rnApiRetrycount = rnApiConfig["apiRetryCount"] as? Int ?? -1
        }
        if let rnFeatures = feature.dictionaryFieldWithName(fieldName: "rnFeatures")?.value {
            self.rnEnableBiometric = rnFeatures["enableBiometric"] as? Bool ?? false
            self.enableXceleratorNLogin =  rnFeatures["enableXceleratorNLogin"] as? Bool ?? false
            self.isInterceptorRedirectionFromCCB =  rnFeatures["isInterceptorRedirectionFromCCB"] as? Bool ?? false
            self.isRNWebviewUsed =  rnFeatures["isRNWebviewUsed"] as? Bool ?? true
            self.loginErrorToasterTime = rnFeatures["loginErrorToasterTime"] as? Int ?? -1
            self.showCodepushPopUp = rnFeatures["showCodepushPopUp"] as? Bool ?? false
            self.enableRNLoginPopUp = rnFeatures["enableRNLoginPopUp"] as? Bool ?? true
        }
        if let yahooLoginUrl = feature.stringFieldWithName(fieldName: "yahooLoginPath")?.value {
            self.yahooLoginPath = yahooLoginUrl
        }
    }
}
