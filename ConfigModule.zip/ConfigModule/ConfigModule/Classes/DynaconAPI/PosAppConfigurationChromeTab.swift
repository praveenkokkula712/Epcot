//
//  PosAppConfigurationChromeTab.swift
//  Wrapper
//
//  Created by Harshita Sai Adagarla on 09/07/2018.
//  Copyright © 2018 bwin.com. All rights reserved.
//

import UIKit

public class PosAppConfigurationChromeTab: NSObject {
    public private(set) var absoluteUrls: [Any]?
    public private(set) var externalBrowserUrls: [String]?
    
    public init(feature: DynaconFeature) {
        super.init()

        self.absoluteUrls = feature.arrayFieldWithName(fieldName: "absoluteUrls")?.value
        self.externalBrowserUrls = feature.arrayFieldWithName(fieldName: "externalBrowserUrls")?.value as? [String]
    }
}
