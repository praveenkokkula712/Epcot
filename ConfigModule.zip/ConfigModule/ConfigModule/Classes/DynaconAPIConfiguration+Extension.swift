//
//  DynaconAPIConfiguration+Extension.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 15/06/23.
//

import Foundation
import Utility
import CasinoAPI

extension DynaconAPIConfiguration {
    
    private var odrAws: AppConfigurationODRAWS? {
        self.posAppConfig?.odrAws
    }
    
    private var features: PosAppConfigurationFeatures? {
        self.posAppConfig?.features
    }
    
    private var feedBack: PosAppConfigurationFeedback? {
        self.posAppConfig?.feedback
    }
    
    private var cashier: PosAppConfigurationCashier? {
        self.posAppConfig?.cashier
    }
    
    public func setupConfigurations() {
        guard !(EntainContext.app?.isSlider ?? false) else {
            self.setupSliderTheming()
            return
        }
        self.setupTheming()
        guard let odrAws else {return}
        self.setupKinesisService(with: odrAws)
        self.setupDualModeContext(with: odrAws)
        self.setupCasinoContext(with: odrAws)
        self.setupGameControllerContext(with: odrAws)
        self.setupCasinoAPIRoutes()
        self.setupDepositContext()
        self.setupUsUnifiedContext()
        self.setupAppContext(with: odrAws)
        self.setupLruContext(with: odrAws)
    }
    
    public func callSiteCoreServices(with posConfigs: POSConfigs,
                                     sitecoreEntries: SiteCoreOtherEntries? = nil,
                                     delegate: DynaconAPIConfigurationDelegate?) {
        self.serviceLayer = SiteCoreServiceLayer(posConfigs: posConfigs,
                                                entries: sitecoreEntries,
                                                delegate: delegate)
        
        self.serviceLayer?.initialiseSitecoreServices()
    }
    
    public func refreshSitecoreServices() {
        if let serviceLayer = self.serviceLayer {
            serviceLayer.refreshSitecoreServices()
        }
    }
    
    public var isInternalBuild: Bool {
        return DynaconAPIConfiguration.shared?.appConfigs?.isInternalBuild ?? false
    }
    
    private func setupTheming() {
        CasinoCSS.lobby = CasinoLobbyCSS()
    }
    
    private func setupSliderTheming() {
        CasinoCSS.sliderLobby = SlidersLobbyCSS()
    }
    
    private func setupKinesisService(with odrAws: AppConfigurationODRAWS) {
        EntainContext.aws = AWSContext(bucketName: odrAws.AWSBucketName,
                                 region: odrAws.region,
                                 accessId: odrAws.AWSAccessID,
                                 secretKey: odrAws.AWSSecretKey)
    }
    
    public func setupDualModeContext(with odrAws: AppConfigurationODRAWS) {
        EntainContext.dualModeConfigContext = DualModeConfigContext(downloadMode: odrAws.gameDownloadMode,
                                                              isLightWeightEnabled: odrAws.isLightWeightEnabled,
                                                              cloudFrontBasePath: odrAws.cloudFrontBasePath,
                                                              gameResourceInfoMappingVersionId: odrAws.gameResourceInfoMappingVersionId,
                                                              gameControllerCloudFrontPath: odrAws.gameControllerCloudFrontPath,
                                                              gameControllerVersionId: odrAws.gameControllerVersionId,
                                                              gameResourceInfoMappingCloudFrontPath:  odrAws.gameResourceInfoMappingCloudFrontPath,
                                                              gameResourceInfoMappingFileName: odrAws.gameResourceeMappingFileName,
                                                              shouldUseDefaultConfiguration: odrAws.shouldUseDefaultConfigurationDualMode,
                                                              cloudFrontQueryString: odrAws.cloudFrontQueryString,
                                                              gameMediaAssetVersionId: odrAws.gameMediaAssetVersionId,
                                                              gameMediaAssetCloudFrontPath: odrAws.gameMediaAssetCloudFrontPath,
                                                              gameMediaAssetFileName: odrAws.gameMediaAssetFileName)
    }
    
    private func setupCasinoContext(with odrAws: AppConfigurationODRAWS) {
        let liveInfo = LiveInfo(providers: odrAws.liveGameProviders, games: odrAws.liveGames)
        let gameServer = CasinoContext.Server(ip: odrAws.gameServerIp, port: odrAws.gameServerPort)
        let rcpOneHour = CasinoContext.RCPUOnehour(idealTimeForOneHourPopup: odrAws.idealTimeForOneHourPopup, sessionTimeForOneHourPopup: odrAws.sessionTimeForOneHourPopup)
        EntainContext.casino = CasinoContext(gameResource: "GameResource",
                                       localServerPort: odrAws.localServerPort,
                                       liveInfo: liveInfo,
                                       server: gameServer,
                                       rCPUOnehour: rcpOneHour)
    }
    
    private func setupGameControllerContext(with odrAws: AppConfigurationODRAWS) {
        EntainContext.gameController = GameControllerContext(fileName: odrAws.gameControllerFileName,
                                                       path: odrAws.gameControllerPath,
                                                       version: odrAws.gameControllerVersion,
                                                       mobileHtmlConfiguration: odrAws.mobileHtmlConfiguration,
                                                       htmlGameDownloadConfig: odrAws.htmlGameDownloadConfigurations)
        EntainContext.gameResourceInfo = GameResourceInfoContext(fileName: odrAws.gameResourceeMappingFileName,
                                                           path: odrAws.gameResourceeMappingPath,
                                                           version: odrAws.gameResourceeMappingVersion)
    }
    
    private func setupDepositContext() {
        EntainContext.deposit = DepositContext(applePayEnabled: features?.applePayEnabled ?? false,
                                         applePayCashierUrls: features?.applePayCashierUrls,
                                         applePayExcludeUrls: features?.applePayExcludeUrls,
                                         urlScheme: self.appConfigs?.depostiUrlScheme)
    }
    
    private func setupUsUnifiedContext() {
        EntainContext.usUnified = USUnifiedContext(stateCode: self.appConfigs?.usStateCode,
                                             unifiedVendors: self.odrAws?.unifiedProviders,
                                                   brandDNS: self.odrAws?.brandDNS)
    }
    
    private func setupAppContext(with odrAws: AppConfigurationODRAWS) {
        let isInternalBuild = self.appConfigs?.isInternalBuild ?? true
        let isODR = isInternalBuild ? false : odrAws.enableODR
        let requiredSource = isInternalBuild ? "ODR Dev" : "ODR"
        
        var frontendId = self.appConfigs?.frontEndId
        if let fId = DynaconAPIConfiguration.shared?.posAppConfig?.features?.frontEndId,
           !fId.isEmpty {
            frontendId = fId
        }
        
        EntainContext.app = AppContext(brandId: self.features?.brandId,
                                 invokerProduct: odrAws.invokerProduct,
                                 channelId: odrAws.channelId,
                                 lang: odrAws.getLanguage.replacingOccurrences(of: "-", with: "_"),
                                 lobbyType: odrAws.lobbyType,
                                 frontendId: frontendId ?? "",
                                 defaultCurrency: odrAws.defaultCurrency,
                                 isODR: isODR,
                                 environment: appConfigs?.environment,
                                 geoVarient: odrAws.geoVariant,
                                 cacheCount: odrAws.gamesCacheCount,
                                 brandTitle: feedBack?.brandName,
                                 launchType: odrAws.launchType,
                                 reqSource: requiredSource,
                                 shouldDisplayScreenLogs: odrAws.isScreenLogsEnabled,
                                 usStateprefix: self.appConfigs?.usStateCode,
                                 userIP: self.geoLocationData?.resolvedIP,
                                 isDemoMode: isInternalBuild ? false : odrAws.isDemoMode,
                                 isCustomThemeEnabled: odrAws.isCustomThemeEnabled,
                                 isFeedLogNeeded: odrAws.isFeedLogNeeded,
                                 isVenmoRequired: cashier?.isVenmoRequired ?? false,
                                 shouldDisplayRegulatoryAlerts: odrAws.shouldDisplayRegulatoryAlerts ?? false,
                                 ezNavHtmlUrl: odrAws.ezNavHtmlUrl ?? "",
                                 overlaysToastersConfig: odrAws.overlaysConfigurations,
                                 liveCasino: odrAws.liveCasinoLMTConfig?.lobbyTemplate ?? "LiveCasino",
                                 deviceUniqueId: appConfigs?.deviceUniqueId ?? "",
                                 isExtendedCategoriesFetchEnabled: odrAws.isExtendedCategoriesFetchEnabled ?? false,
                                 isHomePillNeeded: odrAws.isHomePillNeeded ?? false,
                                 requestedDNS: self.posAppConfig?.services?.brandDNS ?? "")
    }
    
    private func setupCasinoAPIRoutes() {
        guard let services = self.posAppConfig?.services else { return }
        let result =  services.feedDNS?.jsonDecoder(FeedDNS.self)
        switch result {
        case .success(let feedDNS):
            ETCasinoAPI.feedDNS = feedDNS
        default: break
        }
        ETCasinoAPI.dynconConfiguredDNS = services.dynaconBrandDNS
        ETCasinoAPI.liveFeedCasinoUrl = services.liveFeedDns
        ETCasinoAPI.routes?[ETCasinoAPI.GenericLobby]         = services.casinoApiRoutes?[ETCasinoAPI.GenericLobby.stringValue] as? String
        ETCasinoAPI.routes?[ETCasinoAPI.FavoriteGames]        = services.casinoApiRoutes?[ETCasinoAPI.FavoriteGames.stringValue] as? String
        ETCasinoAPI.routes?[ETCasinoAPI.SetFavoriteGame]      = services.casinoApiRoutes?[ETCasinoAPI.SetFavoriteGame.stringValue] as? String
        ETCasinoAPI.routes?[ETCasinoAPI.RecenltyPlayedGames]  = services.casinoApiRoutes?[ETCasinoAPI.RecenltyPlayedGames.stringValue] as? String
        ETCasinoAPI.routes?[ETCasinoAPI.JackpotPoolInfo]      = services.casinoApiRoutes?[ETCasinoAPI.JackpotPoolInfo.stringValue] as? String
        ETCasinoAPI.routes?[ETCasinoAPI.ImagePath]            = services.casinoApiRoutes?[ETCasinoAPI.ImagePath.stringValue] as? String
        ETCasinoAPI.routes?[ETCasinoAPI.VendorImagePath]      = services.casinoApiRoutes?[ETCasinoAPI.VendorImagePath.stringValue] as? String
    }
    
    private func setupLruContext(with odrAws: AppConfigurationODRAWS) {
        EntainContext.lruContext = LruContext(memoryAvailableToUse: odrAws.memoryAvailableToUse,
                                        appUsedMemory: odrAws.appUsedMemory,
                                        memoryToBeCleared: odrAws.memoryToBeCleared)
    }
}
