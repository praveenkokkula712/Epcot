//
//  LobbyProtocolsExtension.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 18/07/23.
//

import Foundation
import Utility


fileprivate var config: PosAppConfiguration? {
    DynaconAPIConfiguration.shared?.posAppConfig
}

fileprivate var odrAws: AppConfigurationODRAWS? {
    config?.odrAws
}

fileprivate var portal: PosAppConfigurationPortal? {
    config?.portal
}


//MARK: - CasinoDatasource
public extension CasinoDatasource {
    
    func didRequestforRTMSServerURL(for type: RtmsServerUrlType) -> String? {
        switch type {
        case .playBreak:
            return odrAws?.rtmsServerUrlForPlayBreak
        case .winLoss:
            return odrAws?.rtmsServerUrl
        }
    }
        
    var didRequestResponsibleGamingImageUrl: String? {
        portal?.rgLogoImagePath
    }
    
    var vendorBasedGeoVariants: [String : String]? {
        odrAws?.gameFolderAWSPath
    }
    
    var dynaconFeed: [String : Any]? {
        odrAws?.localLMTResponse
    }
            
    var gameDirectoryVendorsPath: [String]? {
        odrAws?.gameDirectoryVendorsPath
    }
    
    var didRequestForCasinoCss: LobbyCSS? {
        CasinoLobbyCSS()
    }
        
    func didRequestSlotSessionTimer(for type: SlotSessionType) -> String? {
        guard let _odrAws = odrAws else { return nil}
        switch type {
        case .maxTime:
            return _odrAws.ssMaxTime
        case .frequencyTime:
            return _odrAws.ssFrequencyTime
        }
    }
        
    func didRequestVersionForEasyNav() -> Int? {
        odrAws?.versionForEasyNav ?? 2
    }
}


// MARK: - Lobby Datasource extension
public extension LobbyDatasource {
        
    var teasersDynaconConfig: TeaserDynaconConfig? {
        odrAws?.teasersConfigurations
    }
    
    var embeddBannerConfig: EmbeddBannerDynaconConfig? {
        odrAws?.embeddedBannersConfigurations
    }
    
    var favoriteToastConfig: FavoriteToastConfig? {
        odrAws?.favoriteToastConfigurations
    }
    
    var didRequestForInstantInteraction: InstantInteractionModel? {
        config?.style?.instantInteraction
    }
    
    var gameTileItemsConfiguration: GameTileItemsConfiguration? {
        odrAws?.gameTileItemsConfiguration
    }

    func didRequestForLastPlayedGamesDisplayLimit() -> Int? {
        odrAws?.recentlyPlayedGamesLimit
    }

    var searchConfiguration: SearchConfiguration? {
        odrAws?.searchConfig
    }
    
    func didRequestForIconVariant(with iconName: String, fontSize: CGFloat) ->  IconVariant {
        if let font = UIFont(name: "themeicons", size: fontSize) {
            if let icon = String.vanillaThemefontSymbolsMapping[iconName] as? String {
                return (icon, font)
            } else if let icon = String.vanillaThemefontSymbolsMapping["casino-games"] as? String {
                return (icon, font)
            }
        }
        return (iconName, UIFont.systemFont(ofSize: fontSize))
    }

}


// MARK: - Lobby Optionals Datasource Extension
public extension LobbyDataSourceOptionals {
    
    func shouldRefetchLobbyMetaData() -> Bool {
        odrAws?.shouldReloadLobbyPostLogin ?? false
    }
    
    func shouldAskPlayMode() -> Bool {
        odrAws?.showPlayMode ?? false
    }

    func shouldDisplayView(of type: CLCustomViewType) -> Bool {
        switch type {
        case .searchMoreTile:
            return odrAws?.shouldDisplaySearchMoreTile ?? false
        case .recentlyPlayedGamesView:
            return odrAws?.shouldDisplayRecentlyPlayedGames ?? false
        case .searchBarWithMenu:
            return config?.features?.enableEpcotFeature ?? false
        case .favouriteGamesView:
            return odrAws?.shouldDisplayFavouriteGames ?? false
        case .searchButtonEnabled:
            return odrAws?.shouldDisplayBottomSearch ?? false
        case .playerStatsView:
            return odrAWS?.shouldDisplayPlayerStatsGames ?? false
        case .exploreLobbyView:
            return false
        case .originalsWidgetView:
            return odrAWS?.shouldDisplayBetmgmOriginalsView ?? false
        }
    }
    
    func didRequestForSearchTilePosition() -> Int {
        odrAws?.gridSearchTilePosition ?? 12
    }

    func shouldIncludeRefreshControl() -> Bool {
        odrAws?.shouldIncludeRefreshControl ?? true
    }

    func enableVoiceSearch() -> Bool {
        odrAws?.enableVoiceSearch ?? false
    }

}


extension String {
    static var vanillaThemefontSymbolsMapping: [String: Any] {
        var mapping = [String: Any]()
        if let path = Bundle.main.path(forResource: "themeicons", ofType: "json") {
            if let fontData = try? Data(contentsOf: URL(fileURLWithPath: path)) {
                if let fontsList = try? JSONSerialization.jsonObject(with: fontData, options: .mutableLeaves) as? [[String: Any]] {
                    for dict in fontsList {
                        if let unicodeList = dict["unicode"] as? [Any],
                            let keyName = dict["name"] as? String,
                            let dictValue = unicodeList.first {
                            mapping[keyName] = dictValue
                        }
                    }
                }
            }
        }
        return mapping
    }

}
