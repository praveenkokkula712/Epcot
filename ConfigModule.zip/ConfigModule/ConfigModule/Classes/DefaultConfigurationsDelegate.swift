//
//  DefaultConfigurationsDelegate.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 11/07/23.
//

import Foundation

public protocol DefaultConfigurationsDelegate {
    
    var launchBackgroundColor: String? { get }
    
    var loadingActivityIndicator: String? { get }
}
