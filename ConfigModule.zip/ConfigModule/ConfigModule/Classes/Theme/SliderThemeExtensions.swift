//
//  SliderThemeExtensions.swift
//  ConfigModule
//
//  Created by Gostu Bhargavi on 01/03/24.
//

import Foundation
import Utility

extension CGFloat {
    
    static func BWSSliderFloat(className: String, propertyName: String) -> CGFloat {
        if let theme = EntainContext.slider?.sliderThemeCSS,
           let cName = theme[className] as? [String: Any] {
            if let pName = cName[propertyName] as? Double {
                return CGFloat(pName)
            }
        }
        return 4.0
    }
    
    static func sliderCornerRadius(className: String, propertyName: String) -> CGFloat? {
        if let theme = EntainContext.slider?.sliderThemeCSS,
           let cName = theme[className] as? [String: Any] {
            if let pName = cName[propertyName] as? Double {
                return CGFloat(pName)
            }
        }
        return nil
    }
}

@objc extension UIColor {
    
    @objc class func BWSSliderColor(className: String, propertyName: String) -> UIColor {
        if let theme = EntainContext.slider?.sliderThemeCSS,
           let cName = theme[className] as? [String: Any] {
            if let pName = cName[propertyName] as? String {
                return UIColor.hexStringToUIColor(hex: pName)
            } else if let pName = cName[propertyName] as? [String: Any],
                      let colorCode = pName["color"] as? String {
                return UIColor.hexStringToUIColor(hex: colorCode,
                                                  withAlpha: pName["alpha"] as? Double ?? 1.0)
            }
        }
        return .clear
    }
}

@objc extension UIFont {
    
    @objc class func BWSSliderFont(className: String, propertyName: String) -> UIFont {
        if let theme = EntainContext.slider?.sliderThemeCSS,
           let cName = theme[className] as? [String: Any] {
            if let pName = cName[propertyName] as? [String: Any] {
                let fontKey = pName["name"] as? String ?? "regularFontName"
                let fontName = (theme[fontKey] as? String) ?? "Roboto-Regular"
                return UIFont(name: fontName, size: pName["size"] as? Double ?? 10.0) ?? UIFont.systemFont(ofSize: 10)
            }
        }
        return UIFont.systemFont(ofSize: 10)
    }
}
