//
//  ThemeExtensions.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 10/07/23.
//

import Foundation

extension CGFloat {
    
    public static func BWSFloat(className: String, propertyName: String) -> CGFloat {
        if let theme = DynaconAPIConfiguration.shared?.posAppConfig?.style?.theme,
           let cName = theme[className] as? [String: Any] {
            if let pName = cName[propertyName] as? Double {
                return CGFloat(pName)
            }
        }
        return 12.0
    }
    
    public static func cornerRadius(className: String, propertyName: String) -> CGFloat? {
        if let theme = DynaconAPIConfiguration.shared?.posAppConfig?.style?.theme,
           let cName = theme[className] as? [String: Any] {
            if let pName = cName[propertyName] as? Double {
                return CGFloat(pName)
            }
        }
        return nil
    }
}

@objc public extension UIColor {
    
    @objc class func BWSColor(className: String, propertyName: String) -> UIColor {
        if let theme = DynaconAPIConfiguration.shared?.posAppConfig?.style?.theme,
           let cName = theme[className] as? [String: Any] {
            if let pName = cName[propertyName] as? String {
                return UIColor.hexStringToUIColor(hex: pName)
            } else if let pName = cName[propertyName] as? [String: Any],
                      let colorCode = pName["color"] as? String {
                return UIColor.hexStringToUIColor(hex: colorCode,
                                                  withAlpha: pName["alpha"] as? Double ?? 1.0)
            }
        }
        
        let configDelegate = DynaconAPIConfiguration.shared?.delegate
        if propertyName == "statusBarBackgroundColor" || propertyName == "webFooterColor" {
            return UIColor.hexStringToUIColor(hex: configDelegate?.launchBackgroundColor ?? "#000000")
        } else if propertyName == "loadingActivityIndicatorColor" {
            return UIColor.hexStringToUIColor(hex: configDelegate?.loadingActivityIndicator ?? "#ffffff")
        }
        return .clear
    }
}

@objc public extension UIFont {
    
    @objc class func BWSFont(className: String, propertyName: String) -> UIFont {
        if let theme = DynaconAPIConfiguration.shared?.posAppConfig?.style?.theme,
           let cName = theme[className] as? [String: Any] {
            if let pName = cName[propertyName] as? [String: Any] {
                let fontKey = pName["name"] as? String ?? "regularFontName"
                let fontName = (theme[fontKey] as? String) ?? "Roboto-Regular"
                return UIFont(name: fontName, size: pName["size"] as? Double ?? 10.0) ?? UIFont.systemFont(ofSize: 10)
            }
        }
        return UIFont.systemFont(ofSize: 10)
    }
    
    class func myFont(name: String?, ofSize size: CGFloat) -> UIFont {
        return UIFont(name: name ?? "Roboto-Regular", size: size) ?? UIFont.systemFont(ofSize: size)
    }
}

@objc public extension NSNumber {
    @objc class func Boolean(className: String, propertyName: String) -> Bool {
        if let theme = DynaconAPIConfiguration.shared?.posAppConfig?.style?.theme,
           let cName = theme[className] as? [String: Any],
           let pName = cName[propertyName] as? Int {
            return pName == 1
        }
        return false
    }
}

extension String {
    public static func BWString(className: String, propertyName: String) -> String {
        if let theme = DynaconAPIConfiguration.shared?.posAppConfig?.style?.theme,
           let cName = theme[className] as? [String: Any] {
            if let pName = cName[propertyName] as? String {
                return pName
            }
        }
        return ""
    }
}
