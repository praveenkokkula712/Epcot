//
//  PlayerStatsWidgetsCSS.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 02/07/24.
//

import Foundation
import Utility

public struct PlayerStatsWidgetsCSS: PlayerStatsWidgetCSS {
    
    public var playerStatsWidgetCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWPlayerStatsWidget, propertyName: "playerStatsWidgetCornerRadius")
    }()
    
    public var statsPeriodSelectedBgColor: UIColor = {
        UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "statsPeriodSelectedBgColor")
    }()
    
    public var statsPeriodSelectedCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWPlayerStatsWidget, propertyName: "statsPeriodSelectedCornerRadius")
    }()
    
    public var statsPeriodSelectedTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "statsPeriodSelectedTitleColor"),
                       font: UIFont.BWSFont(className: BWPlayerStatsWidget, propertyName: "statsPeriodSelectedTitleFont"))
    }()
    
    public var statsPeriodUnSelected: PlayerStatsWidgetPeriodCSS? = {
        struct StatsPeriodUnSelected: PlayerStatsWidgetPeriodCSS {
            var title: TextCSS? = {
                DefaultTextCSS(color: UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "statsPeriodUnSelectedTitleColor"),
                               font: UIFont.BWSFont(className: BWPlayerStatsWidget, propertyName: "statsPeriodUnSelectedTitleFont"))
            }()
            
            var gradientColors: [UIColor]? = {
                [
                    UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "statsPeriodUnSelectedGradientColor1"),
                    UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "statsPeriodUnSelectedGradientColor2")
                ]
            }()
            
            var cornerRadius: CGFloat? = {
                CGFloat.BWSFloat(className: BWPlayerStatsWidget, propertyName: "statsPeriodUnSelectedCornerRadius")
            }()
            
            var borderColor: UIColor? = {
                UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "statsPeriodUnSelectedBorderColor")
            }()
            
            var borderWidth: CGFloat? = {
                CGFloat.BWSFloat(className: BWPlayerStatsWidget, propertyName: "statsPeriodUnSelectedBorderWidth")
            }()
        }
        return StatsPeriodUnSelected()
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "titleColor"),
                       font: UIFont.BWSFont(className: BWPlayerStatsWidget, propertyName: "titleFont"))
    }()
    
    public var titleCta: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "titleCtaColor"),
                       font: UIFont.BWSFont(className: BWPlayerStatsWidget, propertyName: "titleCtaFont"))
    }()
    
    public var message: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "messageColor"),
                       font: UIFont.BWSFont(className: BWPlayerStatsWidget, propertyName: "messageFont"))
    }()
    
    public var messageTextOpacity: CGFloat? = {
        CGFloat.BWSFloat(className: BWPlayerStatsWidget, propertyName: "messageOpacity")
    }()
    
    public var gameTileCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWPlayerStatsWidget, propertyName: "gameTileCornerRadius")
    }()
    
    public var multiplierViewBgColor: UIColor? = {
        UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "multiplierViewBgColor")
    }()
    
    public var multiplierViewBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "multiplierViewBorderColor")
    }()
    
    public var multiplierViewBorderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWPlayerStatsWidget, propertyName: "multiplierViewBorderWidth")
    }()
    
    public var multiplierViewCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWPlayerStatsWidget, propertyName: "multiplierViewCornerRadius")
    }()
    
    public var multiplierDigitViewBgColor: UIColor? = {
        UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "multiplierDigitViewBgColor")
    }()
    
    public var multiplierDigit: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "multiplierDigitTextColor"),
                       font: UIFont.BWSFont(className: BWPlayerStatsWidget, propertyName: "multiplierDigitTextFont"))
    }()
    
    public var multiplierDigitViewCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWPlayerStatsWidget, propertyName: "multiplierDigitViewCornerRadius")
    }()
    
    public var jpPriceBgColor: UIColor? = {
        UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "jpPriceBgColor")
    }()
    
    public var jpPrice: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "jpPriceTextColor"),
                       font: UIFont.BWSFont(className: BWPlayerStatsWidget, propertyName: "jpPriceTextFont"))
    }()
    
    public var jpPriceTwo: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWPlayerStatsWidget, propertyName: "jpSecondPriceTextColor"),
                       font: UIFont.BWSFont(className: BWPlayerStatsWidget, propertyName: "jpSecondPriceTextFont"))
    }()
}
