//
//  ViewsCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

struct CasinoTextCss:TextCSS {

     var color: UIColor?

     var font: UIFont?
}


struct CasinoButtonCSS: ButtonCSS {
    
    var title: TextCSS?
    
    var selected: UIColor?

    var normal: UIColor?
}


public struct LimitsTextCSS: TextCSS {
    
    public var color: UIColor?
    
    public var font: UIFont?
}


public struct LobbyLimitsTextCSS: TextCSS {
    
    public var color: UIColor?
    
    public var font: UIFont?
}


public struct LobbyLimitsButtonCSS: LimitsButtonCSS {
    
    public var selected: UIColor?
    
    public var normal: UIColor?
    
    public var title: TextCSS?
    
    public var disabled: UIColor?
}
