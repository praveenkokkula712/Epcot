//
//  ColorsModel.swift
//  ConfigModule
//
//  Created by Sindhuja Vedire on 12/06/24.
//

import Foundation
import SwiftUI

public struct ColorsModel: Codable {
    var color: String?
    var alpha: Double?
    
    public var gradientColor: Color?
    
    enum CodingKeys: String, CodingKey {
        case color
        case alpha
    }
    
    public init(from decoder: Decoder) throws {
        let container = try? decoder.container(keyedBy: CodingKeys.self)
        self.color = try? container?.decodeIfPresent(String.self, forKey: .color)
        self.alpha = try? container?.decodeIfPresent(Double.self, forKey: .alpha)
        if let color {
            self.gradientColor =  UIColor.hexStringToUIColor(hex: color,
                                                             withAlpha: alpha ?? 1.0).swiftUIColor
        }
    }
}

