//
//  LobbyViewCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

fileprivate var recentlyPlayedCSSClassName: String {
    return isEpcotEnabled ? BWEpcotFeature : BWLobbyCSSStyle
}

struct CasinoLobbyHeader: HeaderCell {
    
    var color: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyHeaderViewTitleColor")
    }()
    
    var font: UIFont? = {
         UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyHeaderViewTitleFont")
    }()
    
    var backgroundColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyHeaderViewBGColor")
    }()
}


struct CasinoLobbyTitleView: LobbyTitleCSS {
    
    var searchBarBGColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchTitleFieldBGColor")
    }()

    var searchBarLayerColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchTitleLayerColor")
    }()
    
    var backgroundColor: UIColor? = {
          UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyTitleViewBGColor")
    }()
    
    var searchIconColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchIconColor")
    }()
    
     var title: TextCSS = {
         CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyTitleFont"))
    } ()
    
     var searchPlacehoder: TextCSS = {
         CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchFontColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbySearchFont"))
    }()
    
    var searchText: TextCSS = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchTextColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbySearchTextFont"))
   }()
}


struct CasinoLobbyRecentlyPlayedView: RecentlyPlayedViewCSS {
    
    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "rpViewTitleColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "rpViewTitleFont"))
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "rpViewBackgroundColor")
    }()
    
    var shadowColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "lobbyNavigationShadowColor")
    }()
    
    var seeMoreTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "seeMoreTitleColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "seeMoreTitleFont"))
    }()
    
    var infoButtonTintColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderInfoTintColor")
    }()
    
    var descriptionTextColor: Utility.TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderDescriptionColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderDescriptionFont"))
    }()    
}


struct CasinoGameContainerView: ViewCSS {
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: UIDevice.isIPad() ? "lobbyGameContainerBG1" : "lobbyGameContainerBG")
    }()
}


struct CasinoLobbyGamesTableViewCell: LobbyGameCellCSS {
    
    var favouriteButtonIconSelected: String? = {
        odrAWS?.favouriteButtonIcon?["kFavouriteSelected"] as? String
    }()
    
    var favouriteButtonIconUnselected: String? = {
        odrAWS?.favouriteButtonIcon?["kFavouriteUnselected"] as? String
    }()
    
    var favouriteButtonTintColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyFavouriteButtonTintColor")
    }()
        
    var favouriteButtonBackgroundColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyFavouriteButtonBackgroundColor")
    }()
    
    var sticker: TextCSS? = {
         CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellStickerColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyCellStickerFont"))
    }()
    
    var cellSkinColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellSkinColor")
    }()
    
    var gameTitle: TextCSS? = {
         CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellGameTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyCellGameTitleFont"))
    }()
    
    var favouriteButton: ButtonCSS? = {
         CasinoButtonCSS(title: nil, selected: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellFavouriteSelectedColor"), normal: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellFavouriteNormalColor"))
    }()
    
    var priceTag: TextCSS? = {
         CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPriceTagColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyCellPriceTagFont"))
    }()    
    
    var playButton: ButtonCSS? = {
        let textCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonTitleFont"))
         return CasinoButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonSelectedColor"), normal:  UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonNormalColor"))
    }()
    
    var downloadButton: ButtonCSS? = {
        let textCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellDownloadButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonTitleFont"))
         return CasinoButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellDownloadSelectedColor"), normal:  UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellDownloadNormalColor"))
    }()
    
    var downloadButtonBorderColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellDownloadButtonBorderColor")
    }()
    
    var speakerButtonTintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "speakerButtonTintColor")
    }()
    
    var speakerButtonBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "speakerButtonBackgroundColor")
    }()
    
    var speakerButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "speakerButtonCornerRadius")
    }()
}


struct CasinoLobbyNavigationView : LobbyNavigationCSS  {
    
    var backgroundColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyNavigationBGColor")
    }()
    
    var buttonCSS: ButtonCSS? = {
        let defaultTitleCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyNavigagtionButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyNavigagtionButtonTitleFont"))
        return CasinoButtonCSS(title: defaultTitleCSS, selected: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyNavigationButtonSelectedColor"), normal: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyNavigationButtonNormalColor"))
    }()
    
    var shadowColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyNavigationShadowColor")
    }()
}


struct CasinoLobbySwitcherPopupViewCSS: LobbySwitcherPopupViewCSS {
    
    var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "explorePopUpContainerCornerRadius")
    }()
        
    var tintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "explorePopUpBackgroundColor")
    }()
    
    var itemContainerCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "explorePopUpCornerRadius")
    }()
    
    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "explorePopUpTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "explorePopUpTitleFont"))
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "explorePopUpBackgroundColor")
    }()
    
    var itemContainerBGColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "explorePopUpContainerColor")
    }()
}


struct CasinoLobbySwitcherItemCSS: LobbySwitcherItemCSS {
    
    var itemCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "explorePopUpItemCornerRadius")
    }()
    
    var titleNormal: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "explorePopUpItemNormalColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "explorePopupItemNormalFont"))
    }()
    
    var titleSelected: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "explorePopUpItemSelectedColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "explorePopUpItemSelectedFont"))
    }()
    
    var backgroundColor: UIColor? = {
        .clear
    }()
    
    var contentHightedBGColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "explorePopUpHightedBGColor")
    }()
    
    var tintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "explorePopUpItemTintColor")
    }()
}


struct CasinoExploreLobbyCSS: ExploreLobbyViewCSS {
    
    var categoriesTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreHeaderCategoryTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "exploreHeaderCategoryTitleFont"))
    }()
        
    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreHeaderTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "exploreHeaderTitleFont"))
    }()
    
    var contentBGColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreHeaderBackgroundColor")
    }()
    
    var tintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreHeaderTintColor")
    }()
    
    var switcherTintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreSwitcherTintColor")
    }()

    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreHeaderBackgroundColor")
    }()
    
    var shadowColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreHeaderShadowColor")
    }()
}


struct CasinoExploreCategoriesPopUpCSS: ExploreLobbyCategeroiesPopUpCSS {
    
    var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpCornerRadius")
    }()
    
    var applyButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesApplyButtonCornerRadius")
    }()
    
    var tintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpTintColor")
    }()
    
    var itemCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpCornerRadius")
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpBGColor")
    }()
    
    var cellSeperatorColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpCellSeparatorColor")
    }()

    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopupTitleFont"))
    }()
    
    var categoryTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpCategoryColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpCategoryFont"))
    }()
    
    var cellTitleNormal: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpCellNormalColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpCellNormalFont"))
    }()
    
    var cellTitleSelected: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpCellHightedColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpCellHightedFont"))
    }()
    
    var applyButton: ButtonCSS? = {
        let textCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpApplyColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpApplyFont"))
        return CasinoButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpApplyBGSelectedColor"), normal: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "exploreCategoriesPopUpApplyBGNormalColor"))
    }()
}
