//
//  CasinoGamesCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

public struct GameDownloadingViewCSS: DownloadingViewCSS {

    public var cancelButton: ButtonCSS? = {
        let color = UIColor.BWSColor(className: BWGameDownloadCSSStyle, propertyName: "downloadingViewCancelButtonTitleColor")
        return CasinoButtonCSS(title: CasinoTextCss(color: color, font: UIFont.BWSFont(className: BWGameDownloadCSSStyle, propertyName: "downloadingViewCancelButtonFont")), selected: color, normal: color)
    }()

    public var gametitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWGameDownloadCSSStyle, propertyName: "downloadingViewGameTitleColor"), font: UIFont.BWSFont(className: BWGameDownloadCSSStyle, propertyName: "downloadingViewGameTitleFont"))
    }()

    public var progressTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWGameDownloadCSSStyle, propertyName: "downloadingViewProgressTitleColor"), font: UIFont.BWSFont(className: BWGameDownloadCSSStyle, propertyName: "downloadingViewProgressTitleFont"))
    }()

    public var progressTintColor: UIColor? = {
        UIColor.BWSColor(className: BWGameDownloadCSSStyle, propertyName: "downloadingViewProgressTintColor")
    }()

    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWGameDownloadCSSStyle, propertyName: "downloadingViewBackgroundColor")
    }()
}


struct RCPUKAlertCSS: RcpUKCSS {
   
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "backgroundColor")
    }()
    
    var containerBG: UIColor? = {
        UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "containerBG")
    }()
    
    var title: TextCSS? = {
        return CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWLobbyRCPUStyle, propertyName: "titleFont"))
        
    }()
    
    var body: TextCSS? = {
        return CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "bodyColor"), font: UIFont.BWSFont(className: BWLobbyRCPUStyle, propertyName: "bodyFont"))
    }()
    
    var bodyAttribute: TextCSS? = {
        return CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "bodyColor"), font: UIFont.BWSFont(className: BWLobbyRCPUStyle, propertyName: "bodyFontAttribute"))
    }()
    
    var continuebutton: ButtonCSS? = {
        
        let textCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "continuebuttonTitleColor"), font: UIFont.BWSFont(className: BWLobbyRCPUStyle, propertyName: "continuebuttonTitleFont"))
        
         return CasinoButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "continuebuttonBG"), normal:  UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "continuebuttonBG"))
        
    }()
    
    var border: UIColor? = {
        UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "border")
    }()
    
    var leave: ButtonCSS? = {
        let textCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "leavebuttonTitleColor"), font: UIFont.BWSFont(className: BWLobbyRCPUStyle, propertyName: "leavebuttonTitleFont"))
        
         return CasinoButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "leaverbuttonBG"), normal:  UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "leaverbuttonBG"))
    }()
    
    var linkTextColor: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "linkTextColor")
    }()
   
    var infoIconTintColor: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyRCPUStyle, propertyName: "infoIconTintColor")
    }()
    
    var buttonCornerRadius: CGFloat? 

}
