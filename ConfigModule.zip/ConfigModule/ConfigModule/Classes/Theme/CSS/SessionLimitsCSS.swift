//
//  SessionLimitsCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 03/06/24.
//

import Foundation
import Utility

struct SessionLimitsCSS: SessionLimitCSS {
    //overlay bg color
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWSessionLimit, propertyName: "viewBackgroundColor")
    }()

    var popupBgColor: UIColor? = {
        UIColor.BWSColor(className: BWSessionLimit, propertyName: "popupBackgroundColor")
    }()
    
    var popupCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWSessionLimit, propertyName: "popupCornerRadius")
    }()
    
    var headerBgColor: UIColor? = {
        UIColor.BWSColor(className: BWSessionLimit, propertyName: "headerBackgroundColor")
    }()
    
    var headerTitle: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(className: BWSessionLimit, propertyName: "headerTitleColor"),
            font: UIFont.BWSFont(className: BWSessionLimit, propertyName: "headerTitleFont")
        )
    }()
    
    var timeLimitText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(className: BWSessionLimit, propertyName: "timeLimitTextColor"),
            font: UIFont.BWSFont(className: BWSessionLimit, propertyName: "timeLimitTextFont")
        )
    }()
    
    var timeLimitTextNotation: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(className: BWSessionLimit, propertyName: "timeLimitTextNotationColor"),
            font: UIFont.BWSFont(className: BWSessionLimit, propertyName: "timeLimitTextNotationFont")
        )
    }()

    var timeLimitTextView: RoundedViewCSS? = {
       DefaultRoundedViewCSS(
        cornerRadius: .BWSFloat(className: BWSessionLimit, propertyName: "timeLimitTextViewCornerRadius"),
        borderColor: UIColor.BWSColor(className: BWSessionLimit, propertyName: "timeLimitTextViewBorderColor"),
        borderWidth: .BWSFloat(className: BWSessionLimit, propertyName: "timeLimitTextViewBorderWidth")
       )
    }()
    
    var bodyText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(className: BWSessionLimit, propertyName: "bodyTextColor"),
            font: UIFont.BWSFont(className: BWSessionLimit, propertyName: "bodyTextFont")
        )
    }()
    
    var showAdjustLimitsButton: Bool = {
        NSNumber.Boolean(className: BWSessionLimit, propertyName: "showAdjustLimitsButton")
    }()
    
    var adjustLimitsButton: RoundedButtonCSS? = {
      DefaultRoundedButtonCSS(
        title: DefaultTextCSS(
            color: UIColor.BWSColor(className: BWSessionLimit, propertyName: "adjustLimitsButtonTitleColor"),
            font: UIFont.BWSFont(className: BWSessionLimit, propertyName: "adjustLimitsButtonTitleFont")
        ),
        cornerRadius: .BWSFloat(className: BWSessionLimit, propertyName: "adjustLimitsButtonCornerRadius"),
        borderColor: UIColor.BWSColor(className: BWSessionLimit, propertyName: "adjustLimitsButtonBorderColor"),
        borderWidth: .BWSFloat(className: BWSessionLimit, propertyName: "adjustLimitsButtonBorderWidth")
      )
    }()

    var continueButton: RoundedButtonCSS? = {
        DefaultRoundedButtonCSS(
          title: DefaultTextCSS(
              color: UIColor.BWSColor(className: BWSessionLimit, propertyName: "continueButtonTitleColor"),
              font: UIFont.BWSFont(className: BWSessionLimit, propertyName: "continueButtonTitleFont")
          ),
          cornerRadius: .BWSFloat(className: BWSessionLimit, propertyName: "continueButtonCornerRadius"),
          backgroundColor: UIColor.BWSColor(className: BWSessionLimit, propertyName: "continueButtonBackgroundColor")
        )
      }()
}

public struct DefaultRoundedViewCSS: RoundedViewCSS {
    
    public var cornerRadius: CGFloat?
    
    public var borderColor: UIColor?
    
    public var borderWidth: CGFloat?
    
    init(cornerRadius: CGFloat? = nil, 
         borderColor: UIColor? = nil,
         borderWidth: CGFloat? = nil) {
        self.cornerRadius = cornerRadius
        self.borderColor = borderColor
        self.borderWidth = borderWidth
    }
}

public struct DefaultRoundedButtonCSS: RoundedButtonCSS {
    public var selected: UIColor?
    
    public var normal: UIColor?
    
    public var title: TextCSS?
    
    public var cornerRadius: CGFloat?
    
    public var borderColor: UIColor?
    
    public var borderWidth: CGFloat?
    
    public var backgroundColor: UIColor?
    
    public init(selected: UIColor? = nil,
                normal: UIColor? = nil,
                title: TextCSS? = nil,
                cornerRadius: CGFloat? = nil,
                borderColor: UIColor? = nil,
                borderWidth: CGFloat? = nil,
                backgroundColor: UIColor? = nil) {
        self.selected = selected
        self.normal = normal
        self.title = title
        self.cornerRadius = cornerRadius
        self.borderColor = borderColor
        self.borderWidth = borderWidth
        self.backgroundColor = backgroundColor
    }
}
