//
//  LobbyNoDataViewCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

struct CasinoLobbyNoDataView: NoDataView {

    var iconColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyNoDataIconColor")
    }()
    
    var color: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyNoDataViewContentColor")
    }()
    
    var font: UIFont? = {
         UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyNoDataViewContentFont")
    }()
    
    var backgroundColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyNoDataViewBGColor")
    }()    
}
