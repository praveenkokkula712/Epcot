//
//  JackpotTilesCSS.swift
//  ConfigModule
//
//  Created by Naresh Banavath on 01/07/24.
//

import Foundation
import Utility

/// This struct will all the css data fron dynacon
struct JackpotTilesCSS: JackpotTilesViewCSS {
   
    var cornerRadius: CGFloat = {
        CGFloat.BWSFloat(className: BWJackpotTilesView, propertyName: "cornerRadius")
    }()
    
    var badgeTitle: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "badgeTitleColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "badgeTitleFont")
        )
    }()
    
    var badgeTitleBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWJackpotTilesView , propertyName: "badgeTitleBackgroundColor")
    }()
    
    var badgeTitleCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWJackpotTilesView, propertyName: "badgeTitleCornerRadius")
    }()
    
    var title: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "titleColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "titleFont")
        )
    }()
    
    var description: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "descriptionColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "descriptionFont")
        )
    }()
    
    var lastWin: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "lastWinTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "lastWinTextFont")
        )
    }()
    
    var gameImageCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWJackpotTilesView, propertyName: "gameImageCornerRadius")
    }()
    var viewGameBtn: ButtonCSS? = {
        CasinoButtonCSS(title: CasinoTextCss(color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "viewGamesButtonTextColor"), font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "viewGamesButtonTextFont") ), selected: .clear, normal: .clear)
    }()
    var bottomViewBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "bottomViewBackgroundColor")
    }()
    /// DailyBottomView
    var dailyBottomViewTitle: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "dailyBottomViewTitleTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "dailyBottomViewTitleFont")
        )
    }()
    
    var dailyBottomViewAmount: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "dailyBottomViewAmountTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "dailyBottomViewAmountTextFont")
        )
    }()
    
    var dailyBottomViewTimeLeftLabel: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "dailyBottomViewTimeLeftTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "dailyBottomViewTimeLeftTextFont")
        )
    }()
    
    var dailyBottomViewHourAndMinuteTitleLabel: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "dailyBottomViewHourAndMinuteTitleTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "dailyBottomViewHourAndMinuteTitleTextFont")
        )
    }()
    
    var dailyBottomViewHourAndMinuteValues: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "dailyBottomViewHourAndMinuteValuesTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "dailyBottomViewHourAndMinuteValuesTextFont")
        )
    }()
    
    var dailyBottomViewHourAndMinuteValuesBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "dailyBottomViewHourAndMinuteValuesBackgroundColor")
    }()
    
    var dailyBottomViewBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "dailyBottomViewBackgroundColor")
    }()
    var dailyBottomViewStrokeColor: UIColor? = {
        UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "dailyBottomViewStrokeColor")
    }()
    var dailyStartingAtText: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "dailyStartingAtTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "dailyStartingAtTextFont")
        )
    }()
    var dailyStartingAtTime: TextCSS? = {
        CasinoTextCss(
             color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "dailyStartingAtTimeColor"),
             font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "dailyStartingAtTimeFont")
        )
    }()
    /// ValueBottomView
    var valueBottomViewTitle: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "valueBottomViewTitleTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "valueBottomViewTitleTextFont")
        )
    }()
    
    var valueBottomViewAmount: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "valueBottomViewAmountTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "valueBottomViewAmountTextFont")
        )
    }()
    
    var valueBottomViewProgressColor: UIColor? = {
        UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "valueBottomViewProgressColor")
    }()
    
    var valueBottomViewProgressColorWhen90Percent: UIColor? = {
        UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "valueBottomViewProgressColorWhen90Percent")
    }()
    
    var valueBottomViewMaxAmount: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "valueBottomViewMaxAmountTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "valueBottomViewMaxAmountTextFont")
        )
    }()
    var valueBottomViewBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "valueBottomViewBackgroundColor")
    }()
    var valueBottomViewStrokeColor: UIColor? = {
        UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "valueBottomViewStrokeColor")
    }()
    
    /// ProgressiveBottomView
    var progressiveBottomViewTitle: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "progressiveBottomViewTitleTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "progressiveBottomViewTitleTextFont")
        )
    }()
    
    var progressiveBottomViewAmountText: TextCSS? = {
        CasinoTextCss(
            color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "progressiveBottomViewAmountTextColor"),
            font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "progressiveBottomViewAmountTextFont")
        )
    }()
    
    var progressiveBottomView_ViewGamesButton: ButtonCSS? = {
        CasinoButtonCSS(
            title: CasinoTextCss(
                color: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "progressiveBottomViewGameButtonTextColor"),
                font: UIFont.BWSFont(className: BWJackpotTilesView, propertyName: "progressiveBottomViewGameButtonTextFont")
            ),
            selected: .clear,
            normal: UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "progressiveBottomViewGameButtonBackgroundColor")
        )
    }()
    
    var progressiveBottomView_ViewGamesButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWJackpotTilesView, propertyName: "progressiveBottomViewGameButtonCornerRadius")
    }()
    var progressiveBottomViewBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "progressiveBottomViewBackgroundColor")
    }()
    var progressiveBottomViewStrokeColor: UIColor? = {
        UIColor.BWSColor(className: BWJackpotTilesView, propertyName: "progressiveBottomViewStrokeColor")
    }()
    
    
}
