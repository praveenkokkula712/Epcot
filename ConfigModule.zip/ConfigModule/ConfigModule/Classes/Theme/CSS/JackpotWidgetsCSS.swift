//
//  JackpotWidgetsCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

fileprivate var recentlyPlayedCSSClassName: String {
    return isEpcotEnabled ? BWEpcotFeature : BWLobbyCSSStyle
}

public struct JackpotWidgetsCss: JackpotWidgetsCSS {
    
    public var singleJackpot: JackpotTextCSS? = {
        SingleJackpotWidgetsCss()
    }()
    
    public var mustGoJackpot: MustGoJackpotWidgetsCSS? = {
       MustGoJackpotWidgetsCss()
    }()
    
    public var singleJackpotHeaderCss: RecentlyPlayedViewCSS? = {
        if isEpcotEnabled {
            return CasinoLobbyRecentlyPlayedView()
        }
        return SingleJackpotHeaderView()
    }()
    
    public var multipleJackpotsHeaderCss: RecentlyPlayedViewCSS? = {
        if isEpcotEnabled {
            return CasinoLobbyRecentlyPlayedView()
        }
        return MultipleJackpotsHeaderView()
    }()
    
    public var mustGoJackpotHeaderCss: RecentlyPlayedViewCSS? = {
        if isEpcotEnabled {
            return CasinoLobbyRecentlyPlayedView()
        }
        return MustGoJackpotHeaderView()
    }()
    
    public var widgetNormalColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "widgetNormalColor")
    }()

    public var widgetSelectedColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "widgetSelectedColor")
    }()
    
    public var navigationArrowTintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "navigationArrowTintColor")
    }()
    
    public var widgetDecoratorBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "widgetDecoratorBackgroundColor")
    }()
    
    public var multipleWidgetsDecoratorBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "multipleWidgetsDecoratorBackgroundColor")
    }()
    
    public var mustGoWidgetDecoratorBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "mustGoWidgetDecoratorBackgroundColor")
    }()
}


public struct MustGoJackpotWidgetsCss: MustGoJackpotWidgetsCSS {
    
    public var borderColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "mustGoJackpotBorderColor")
    }()
    
    public var borderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "mustGoJackpotBorderWidth")
    }()
    
    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "mustGoJackpotBorderCornerRadius")
    }()
    
    public var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "mustGoJackpotTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "mustGoJackpotTitleFont"))
    }()
    
    public var price: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "mustGoJackpotPriceColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "mustGoJackpotPriceFont"))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "mustGoJackpotBGColor")
    }()
}


public struct SingleJackpotWidgetsCss: JackpotTextCSS {
    
    public var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "singleJackpotTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "singleJackpotTitleFont"))
    }()
    
    public var price: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "singleJackpotPriceColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "singleJackpotPriceFont"))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "singleJackpotBGColor")
    }()
}


struct SingleJackpotHeaderView: RecentlyPlayedViewCSS {
    
    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "singleJackpotHeaderTitleColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "singleJackpotHeaderTitleFont"))
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "singleJackpotHeaderViewBackgroundColor")
    }()
    
    var shadowColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "lobbyNavigationShadowColor")
    }()
    
    var seeMoreTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "singleJackpotHeaderSeeMoreTitleColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "singleJackpotHeaderSeeMoreTitleFont"))
    }()
    
    var infoButtonTintColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderInfoTintColor")
    }()
    
    var descriptionTextColor: Utility.TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderDescriptionColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderDescriptionFont"))
    }()
}


struct MultipleJackpotsHeaderView: RecentlyPlayedViewCSS {

    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "multipleJackpotsHeaderViewTitleColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "multipleJackpotsHeaderViewTitleFont"))
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "multipleJackpotsHeaderViewBackgroundColor")
    }()
    
    var shadowColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "lobbyNavigationShadowColor")
    }()
    
    var seeMoreTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "multipleJackpotsHeaderSeeMoreTitleColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "multipleJackpotsHeaderSeeMoreTitleFont"))
    }()
    
    var infoButtonTintColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderInfoTintColor")
    }()
    
    var descriptionTextColor: Utility.TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderDescriptionColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderDescriptionFont"))
    }()
}


struct MustGoJackpotHeaderView: RecentlyPlayedViewCSS {
    
    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "mustGoJackpotHeaderViewTitleColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "mustGoJackpotHeaderViewTitleFont"))
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "mustGoJackpotHeaderViewBackgroundColor")
    }()
    
    var shadowColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "lobbyNavigationShadowColor")
    }()
    
    var seeMoreTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "mustGoJackpotHeaderSeeMoreTitleColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "mustGoJackpotHeaderSeeMoreTitleFont"))
    }()
    
    var infoButtonTintColor: UIColor? = {
        UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderInfoTintColor")
    }()
    
    var descriptionTextColor: Utility.TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderDescriptionColor"), font: UIFont.BWSFont(className: recentlyPlayedCSSClassName, propertyName: "sectionHeaderDescriptionFont"))
    }()
}

public struct JackpotFusionInfoPopUpCSS: JackpotFusionInfoViewCSS {
    
    public var jackpotFusionInfoViewBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewBackgroundColor")
    }()
    
    public var jackpotFusionInfoViewContentBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewContentBackgroundColor")
    }()
    
    public var jackpotFusionInfoViewHeaderBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewHeaderBackgroundColor")
    }()
    
    public var jackpotFusionInfoViewHeaderTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewHeaderTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewHeaderTitleFont"))
    }()
    
    public var jackpotFusionInfoViewCloseButtonCSS: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoCloseTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoCloseTitleFont")),
                         selected: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewCloseBackgroundColor"),
                         normal: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewCloseBackgroundColor"))
    }()
    
    public var jackpotFusionInfoViewCloseButtonBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewCloseBorderColor")
    }()
    
    public var jackpotFusionInfoViewCloseButtonBorderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewCloseBorderWidth")
    }()
    
    public var jackpotFusionInfoViewCloseButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewCloseCornerRadius")
    }()
    
    public var jackpotFusionInfoViewSeeallButtonCSS: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoSeeAllButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoSeeAllButtonTitleFont")),
                         selected: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoSeeAllButtonBackgroundColor"),
                         normal: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoSeeAllButtonBackgroundColor"))
    }()
    
    public var jackpotFusionInfoViewSeeallButtonBorderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewSeeAllBorderWidth")
    }()
    
    public var jackpotFusionInfoViewSeeallButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewSeeAllCornerRadius")
    }()
    
    public var jackpotFusionInfoViewBadgeTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoBadgeTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoBadgeTitleFont"))
    }()
    
    public var jackpotFusionInfoViewBadgeBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoBadgeBackgroundColor")
    }()
    
    public var jackpotFusionInfoViewBadgeButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewBadgeCornerRadius")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoViewBackgroundColor")
    }()
    
    public var jackpotFusionInfoViewContentViewCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoContentViewCornerRadius")
    }()
    
    public var jackpotFusionInfoViewContentFontSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoContentFontSize")
    }()
    
    public var jackpotFusionInfoViewContentFontName: String? = {
        String.BWString(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoContentFontName")
    }()
    
    public var jackpotFusionInfoViewContentFontFileName: String? = {
        String.BWString(className: BWLobbyCSSStyle, propertyName: "jackpotFusionInfoContentFontFileName")
    }()
}
