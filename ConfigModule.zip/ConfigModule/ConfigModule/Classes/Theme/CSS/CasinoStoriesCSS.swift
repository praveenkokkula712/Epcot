//
//  CasinoStoriesCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 27/07/23.
//

import Foundation
import Utility

struct DefaultGameStoriesCSS: GameStoriesCSS {
    
    public var title: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGameStoriesCSS, propertyName: "gameStoryTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWGameStoriesCSS, propertyName: "gameStoryTitleFont"
            )
        )
    }()

    public var headerTitle: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGameStoriesCSS, propertyName: "gameStoryHeaderTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWGameStoriesCSS, propertyName: "gameStoryHeaderTitleFont"
            )
        )
    }()

    public var selectedColor: UIColor? = {
        .BWSColor(
            className: BWGameStoriesCSS, propertyName: "gameStorySelectedColor"
        )
    }()

    public var unselectedColor: UIColor? = {
        .BWSColor(
            className: BWGameStoriesCSS, propertyName: "gameStoryUnselectedColor"
        )
    }()

    public var selectedTextColor: UIColor? = {
        .BWSColor(
            className: BWGameStoriesCSS, propertyName: "gameStorySelectedTextColor"
        )
    }()

    public var unselectedTextColor: UIColor? = {
        .BWSColor(
            className: BWGameStoriesCSS, propertyName: "gameStoryUnselectedTextColor"
        )
    }()

    public var unselectedViewAlpha: Double? = {
        Double(CGFloat.BWSFloat(
            className: BWGameStoriesCSS, propertyName: "gameStoryUnselectedViewAlpha"
        ))
    }()

    public var lineWidth: CGFloat? = {
        .BWSFloat(
            className: BWGameStoriesCSS, propertyName: "gameStoryLineWidth"
        )
    }()

    public var cornerRadius: CGFloat? = {
        .BWSFloat(
            className: BWGameStoriesCSS, propertyName: "gameStoryCornerRadius"
        )
    }()
    
    var daysToHoldSavedData: Int? = {
        DynaconAPIConfiguration.shared?.posAppConfig?.features?.savedGamingStoiresHoldingDays ?? 0
    }()
}

struct DefaultGameStoryItemsCSS: GameStoryItemsCSS {
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWGameStoryItemsCSS, propertyName: "backgroundColor")
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGameStoryItemsCSS, propertyName: "titleColor"
            ),
            font: UIFont.BWSFont(
                className: BWGameStoryItemsCSS, propertyName: "titleFont"
            )
        )
    }()

    public var subTitle: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGameStoryItemsCSS, propertyName: "subTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWGameStoryItemsCSS, propertyName: "subTitleFont"
            )
        )
    }()
    
    var paragraph: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGameStoryItemsCSS, propertyName: "paragraphColor"
            ),
            font: UIFont.BWSFont(
                className: BWGameStoryItemsCSS, propertyName: "paragraphFont"
            )
        )
    }()
    
    var progressBarColor: UIColor? = {
        .BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "progressBarColor"
        )
    }()
    
    var progressFillColor: UIColor? = {
        .BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "progressFillColor"
        )
    }()
    
    var closeButtonColor: UIColor? = {
        .BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "closeButtonColor"
        )
    }()
    
    var ctaButton: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGameStoryItemsCSS, propertyName: "ctaButtonColor"
            ),
            font: UIFont.BWSFont(
                className: BWGameStoryItemsCSS, propertyName: "ctaButtonFont"
            )
        )
    }()
    
    var ctaButtonBackgroundColor: UIColor? = {
        .BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "ctaButtonBackgroundColor"
        )
    }()
    
    var ctaButtonHighlightColor: UIColor? = {
        .BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "ctaButtonHighlightColor"
        )
    }()
    
    var ctaButtonCornerRadius: CGFloat? = {
        .BWSFloat(
            className: BWGameStoryItemsCSS, propertyName: "ctaButtonCornerRadius"
        )
    }()
    
    var legalTermsText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGameStoryItemsCSS, propertyName: "legalTermsColor"
            ),
            font: UIFont.BWSFont(
                className: BWGameStoryItemsCSS, propertyName: "legalTermsFont"
            )
        )
    }()
    
    var legalTermsBackgroundColor: UIColor? = {
        .BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "legalTermsBackgroundColor"
        )
    }()
    
    var seeMoreButton: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGameStoryItemsCSS, propertyName: "seeMoreButtonColor"
            ),
            font: UIFont.BWSFont(
                className: BWGameStoryItemsCSS, propertyName: "seeMoreButtonFont"
            )
        )
    }()
    
    var seeMoreHandleColor: UIColor? = {
        .BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "seeMoreHandleColor"
        )
    }()
    
    var scrollButtonBackgroundColor: UIColor? = {
        .BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "scrollButtonBackgroundColor"
        )
    }()
    
    var scrollButtonColor: UIColor? = {
        .BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "scrollButtonColor"
        )
    }()

    var touchHandBackgroundColor: UIColor? = {
        UIColor.BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "onboardingTouchHandBackgroundColor"
        )
    }()
    
    var touchHandCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(
            className: BWGameStoryItemsCSS, propertyName: "onboardingTouchHandCornerRadius"
        )
    }()
    
    var touchTitle: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGameStoryItemsCSS, propertyName: "onboardingTouchHintTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWGameStoryItemsCSS, propertyName: "onboardingTouchHintTextFont"
            )
        )
    }()
    
    public var closeOffset: Double? = {
        Double(CGFloat.BWSFloat(
            className: BWGameStoryItemsCSS, propertyName: "gameStoryCloseOffset"
        ))
    }()

    public var logoColor: UIColor? = {
        UIColor.BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "onboardingLogoColor"
        )
    }()

    public var logoBorderWidth: CGFloat? = {
        CGFloat.BWSFloat(
            className: BWGameStoryItemsCSS, propertyName: "onboardingLogoBorderWidth"
        )
    }()

    public var logoBorderColor: UIColor? = {
        UIColor.BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "onboardingLogoBorderColor"
        )
    }()

    public var logoRingColor: UIColor? = {
        UIColor.BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "onboardingLogoRingColor"
        )
    }()

    public var logoRingWidth: CGFloat? = {
        CGFloat.BWSFloat(
            className: BWGameStoryItemsCSS, propertyName: "onboardingLogoRingWidth"
        )
    }()

    public var logoHairlineColor: UIColor? = {
        UIColor.BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "onboardingLogoHairlineColor"
        )
    }()

    public var rippleColor: UIColor? = {
        UIColor.BWSColor(
            className: BWGameStoryItemsCSS, propertyName: "onboardingRippleColor"
        )
    }()
}
