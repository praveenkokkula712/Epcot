//
//  SearchViewCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

struct CasinoSearchView:LobbySearchContentCSS  {
    
    var searchMicIcon: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchMicIcon")
    }()

    var layerColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchLayerColor")
    }()
    
    var backIconColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchBackIcon")
    }()
    
    var clearIconColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchClearIcon")
    }()
    
    var backgroundColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchFieldBGColor")
    }()
    
    var searchContainerBGColor: UIColor? = {
        return ((DynaconAPIConfiguration.shared?.posAppConfig?.features?.enableEpcotFeature) ?? false) ?
                    UIColor.BWSColor(className: BWEpcotFeature, propertyName: "searchContainerBgColor") :
                            UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "newLobbySearchFieldBGColor")
    }()
    
    var searchContainerTitleColor: UIColor? = {
        return ((DynaconAPIConfiguration.shared?.posAppConfig?.features?.enableEpcotFeature) ?? false) ?
                    UIColor.BWSColor(className: BWEpcotFeature, propertyName: "searchTitleColor") :
                        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "newLobbySearchFieldTitleColor")

   }()
    
    var searchParentContainerBGColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "newLobbySearchFieldParentBGColor")
    }()
    
    var searchPlaceHolderFont: TextCSS? = {
        return ((DynaconAPIConfiguration.shared?.posAppConfig?.features?.enableEpcotFeature) ?? false) ?
                        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotFeature, propertyName: "searchTitleColor"), font: UIFont.BWSFont(className: BWEpcotFeature, propertyName: "searchFieldPlaceHolderFont"))  :
                                CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "newLobbySearchFieldTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "newLobbySearchFieldPlaceHolderFont"))
    }()

    var menuButtonFont: ButtonCSS? = {
        let defaultTitleCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotFeature, propertyName: "menuButtonTitleColor"), font: UIFont.BWSFont(className: BWEpcotFeature, propertyName: "menuButtonFont"))
        return CasinoButtonCSS(title: defaultTitleCSS, selected: UIColor.BWSColor(className: BWEpcotFeature, propertyName: "menuButtonFont"), normal: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "menuButtonFont"))
    }()
    
    var menuButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWEpcotFeature, propertyName: "menuButtonCornerRadius")
    }()
    
    var menuButtonBgColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotFeature, propertyName: "menuButtonBGColor")
    }()
    
    var menuButtonContainerBgColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "menuButtonContainerBGColor")
    }()
}


struct DefaultSearchInputAccessoryViewCSS: SearchInputAccessoryViewCSS {
    
    var micButtonHightedTintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputMicHightedTintColor")
    }()
    
    var bottomSearchButtonBgColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "bottomSearchButtonBgColor")
    }()
    
    var bottomSearchButtonTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "bottomSearchButtonTextColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "bottomSearchButtonTextFont"))
    }()
    
    var bottomSearchIconTintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "bottomSearchIconTintColor")
    }()
    
    var searchInputHeaderBgColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputHeaderBgColor")
    }()
    
    var searchInputHeaderBackButtonTintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputHeaderBackButtonTintColor")
    }()
    
    var searchInputHeaderTitleColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputHeaderTitleColor")
    }()
    
    var searchInputContainerViewBgColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputContainerViewBgColor")
    }()
    
    var searchInputHeaderTitleFont: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputHeaderTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "searchInputHeaderTitleFont"))
    }()
    
    var searchInputTextFieldFont: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputTextFieldColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "searchInputTextFieldFont"))
    }()
    
    var searchButtonTintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputSearchButtonTintColor")
    }()
    
    var micButtonTintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputMicButtonTintColor")
    }()
    
    var searchFieldCornerRadius: CGFloat? = {
        16
    }()
    
    var searchInputTextfieldBgColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputTextfieldBgColor")
    }()
    
    var searchInputPlaceHolderTextColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputPlaceHolderTextColor")
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "searchInputContainerViewBgColor")
    }()
}


struct CasinoLobbySuggestionView : LobbySuggestionCSS {
    
    var shadowColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySuggestionShadowColor")
    }()
    
    var searchIconColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySuggestionSearchIconColor")
    } ()
    
    var resultTitle: TextCSS? = {
         CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySuggestionsColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbySuggestionsFont"))
    }()
    
    var hintTitle: TextCSS? = {
         CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchSuggestionHintColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbySearchSuggestionHintFont"))
    }()
    
    var contentBGColor: UIColor? = {
          UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchSuggestionContentBGColor")
    }()
    
    var title: TextCSS? = {
         CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchSuggestionTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbySearchSuggestionTitleFont"))
    }()

    var backgroundColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbySearchViewBGColor")
    }()
    
    var resultViewBgColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "resultViewBgColor")
    }()
}
