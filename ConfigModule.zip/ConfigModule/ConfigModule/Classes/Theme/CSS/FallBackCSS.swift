//
//  FallBackCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

struct CasinoFallbackSolutionCSS: FallbackCSS {
    
    var fallbackDecription: TextCSS? = {
        let color = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "fallbackDescriptionColor")
        let font = UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "fallbackDescriptionFont")
        return CasinoTextCss(color:color, font: font)
    }()
    
    var playButton: ButtonCSS? = {
        let titleColor = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonTitleColor")
        let bgColor = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonNormalColor")
        let font = UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "fallbackPlayBtnFont")
        let textCSS = CasinoTextCss(color: titleColor, font: font)
        return CasinoButtonCSS(title: textCSS, selected: .clear, normal: bgColor)
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "fallbackViewBGColor")
    }()
    
    var headerTitle: TextCSS? = {
        let color = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewTitleColor")
        let boldfont = UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "filterViewBoldFont16Pix")
        return CasinoTextCss(color: color, font: boldfont)
    }()
    
    var headerClose: ButtonCSS? = {
        let color = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewTitleColor")
        let font = UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "filterViewRegularFont14Pix")
        let textCSS = CasinoTextCss(color: color, font: font)
        return CasinoButtonCSS(title: textCSS, selected: .clear, normal: .clear)
    }()
    
    var playMode: PlayModeCSS? = {
       return CasinoPlayModeCSS()
    }()
    
    var gameImagePath: String? = {
        return DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.gameImageFolder?["fallback"] as? String
    }()
}


struct CasinoPlayModeCSS: PlayModeCSS {
   
    var cellSkinColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellSkinColor")
    }()
    
    var gameTitle: TextCSS? = {
         CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellGameTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyCellGameTitleFont"))
    }()
    
    var playButton: ButtonCSS? = {
        let textCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonTitleFont"))
         return CasinoButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonSelectedColor"), normal:  UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonNormalColor"))
    }()
}
