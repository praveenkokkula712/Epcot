//
//  LobbyLimitsCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

public struct LobbyLimitsCSS: LimitsCSS {
    
    public var limitsCell: LimitsCellCSS? = {
        CasinoLimitsCellCSS()
    }()

    public var sessionClearCSS: SessionClearCSS? = {
        CasinoSessionClearCSS()
    }()
    
    public var lossLimitReachedCSS: LossLimitReachedCSS? = {
        LossLimitReachedAlertCSS()
    }()
    
    public var lossLimitInterceptorCSS: LossLimitInterceptorCSS? = {
        LossLimitInterceptorAlertCSS()
    }()

    public var headerBG: UIColor? = {
        UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "headerBG")
    }()
    
    public var headerDescription: TextCSS? = {
        LobbyLimitsTextCSS(color:
                            UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "headerDescriptionTextColor"),
                           font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "headerDescriptionFont"))
        
    }()
    
    public var subHeaderDescription: TextCSS? = {
        LobbyLimitsTextCSS(color:
                            UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "subHeaderDescriptionTextColor"),
                           font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "subHeaderDescriptionFont"))
    }()
    
    public  var sectionHeader: TextCSS? = {
        LobbyLimitsTextCSS(color:
                            UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "sectionHeaderTextColor"),
                            font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "sectionHeaderFont"))
    }()
        
    public var toaster: UIColor? = {
        UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "toasterBG")
    }()
    
    public var toasetDescription: TextCSS? = {
        LobbyLimitsTextCSS(color:
                            UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "subHeaderDescriptionTextColor"),
                           font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "toasetDescriptionFont"))
    }()
    
    public var close: LimitsButtonCSS? = {
        LobbyLimitsButtonCSS(
            selected: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "closeButtonBG"),
            normal: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "closeButtonBG"),
            title: LobbyLimitsTextCSS(
                color:  UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "closeButtonTittleColor"),
                font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "closeButtonFont")),
            disabled: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "closeButtonBG").withAlphaComponent(0.5))
    }()
    
    public var update: LimitsButtonCSS? = {
        LobbyLimitsButtonCSS(
            selected: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "updateMyLimitBG"),
            normal: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "updateMyLimitBG"),
            title: LobbyLimitsTextCSS(
                color:  UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "closeButtonTittleColor"),
                font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "closeButtonFont")),
            disabled: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "updateMyLimitBG").withAlphaComponent(0.5))
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "headerDescriptionTextColor")
    }()
}


public struct CasinoLimitsCellCSS: LimitsCellCSS {
    
    public var rowHeader: TextCSS? = {
        LobbyLimitsTextCSS(color: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "rowHeaderTextColor"), font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "rowHeaderFont"))
    }()
    
    public var progressBarFinished: UIColor? = {
        UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "progressBarFinishedBG")
    }()
    
    public var progressBarleft: UIColor? = {
        UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "progressBarleftBG")
    }()
    
    public var rowSubHeader: TextCSS? = {
        LobbyLimitsTextCSS(color: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "rowHeaderTextColor"), font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "rowSubHeaderFont"))
    }()
    
    public var rowValues: TextCSS? = {
        LobbyLimitsTextCSS(color: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "subHeaderDescriptionTextColor"), font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "rowValuesFont"))
    }()
}


public struct CasinoSessionClearCSS: SessionClearCSS {
        
    public var headerBG: UIColor? = {
        UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "sessionClearheaderBG")
    }()
    
    public var headerTitle: TextCSS? = {
        LimitsTextCSS(color:UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "sessionClearheaderTitleColor"), font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "sessionClearheaderTitleFont"))
                
    }()
    
    public var description: TextCSS? = {
        LimitsTextCSS(color: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "sessionClearheaderDescriptionColor"), font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "sessionClearDescriptionFont"))
    }()
    
    public var containerBG: UIColor? = {
        UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "sessionClearContainerBG")
    }()
    
    public var underStandBtn: ButtonCSS? = {
        let defaultTitleCSS = CasinoTextCss(color:UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "sessionClearUnderStandBtnTittleColor"), font:UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "sessionClearUnderStandBtnFont"))
        return CasinoButtonCSS(title: defaultTitleCSS, selected: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "sessionClearUnderStandBtnBG"), normal: UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "sessionClearUnderStandBtnBG"))
    }()
    
    public var buttonLayer: UIColor? = {
        return UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "sessionClearUnderStandBtnLayerColor")
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "sessionClearBackgroundColor")
    }()
    
    public var backIconColor: UIColor? = {
        return UIColor.BWSColor(className: BWLimitsGreecePage, propertyName: "sessionClearUnderStandBtnBG")
    }()
}


struct LossLimitReachedAlertCSS: LossLimitReachedCSS {
   
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "backgroundColor")
    }()
    
    var containerBG: UIColor? = {
        UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "containerBG")
    }()
    
    var title: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWLobbyLossLimitReached, propertyName: "titleFont"))
        
    }()
    
    var body: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "bodyColor"), font: UIFont.BWSFont(className: BWLobbyLossLimitReached, propertyName: "bodyFont"))
    }()
    
    var bodyAttribute: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "bodyColor"), font: UIFont.BWSFont(className: BWLobbyLossLimitReached, propertyName: "bodyFontAttribute"))
    }()
    
    var lobbyButton: ButtonCSS? = {
        
        let textCSS = DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "lobbybuttonTitleColor"), font: UIFont.BWSFont(className: BWLobbyLossLimitReached, propertyName: "lobbybuttonTitleFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "lobbybuttonBG"), normal:  UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "lobbybuttonBG"))
        
    }()
    
    var border: UIColor? = {
        UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "border")
    }()
    
    var rgButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "rgbuttonTitleColor"), font: UIFont.BWSFont(className: BWLobbyLossLimitReached, propertyName: "rgbuttonTitleFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "rgbuttonBG"), normal:  UIColor.BWSColor(className: BWLobbyLossLimitReached, propertyName: "rgbuttonBG"))
    }()
}


struct LossLimitInterceptorAlertCSS: LossLimitInterceptorCSS {
   
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyLossLimitInterceptor, propertyName: "backgroundColor")
    }()
    
    var containerBG: UIColor? = {
        UIColor.BWSColor(className: BWLobbyLossLimitInterceptor, propertyName: "containerBG")
    }()
    
    var title: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyLossLimitInterceptor, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWLobbyLossLimitInterceptor, propertyName: "titleFont"))
    }()
    
    var body: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyLossLimitInterceptor, propertyName: "bodyColor"), font: UIFont.BWSFont(className: BWLobbyLossLimitInterceptor, propertyName: "bodyFont"))
    }()
    
    var bodyAttribute: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyLossLimitInterceptor, propertyName: "bodyColor"), font: UIFont.BWSFont(className: BWLobbyLossLimitInterceptor, propertyName: "bodyFontAttribute"))
    }()
    
    var continueButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyLossLimitInterceptor, propertyName: "continuebuttonTitleColor"), font: UIFont.BWSFont(className: BWLobbyLossLimitInterceptor, propertyName: "continuebuttonTitleFont"))
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyLossLimitInterceptor, propertyName: "continuebuttonBG"), normal:  UIColor.BWSColor(className: BWLobbyLossLimitInterceptor, propertyName: "continuebuttonBG"))
    }()

    var closeButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyLossLimitInterceptor, propertyName: "closebuttonTitleColor"), font: UIFont.BWSFont(className: BWLobbyLossLimitInterceptor, propertyName: "closebuttonTitleFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyLossLimitInterceptor, propertyName: "closebuttonBG"), normal:  UIColor.BWSColor(className: BWLobbyLossLimitInterceptor, propertyName: "closebuttonBG"))
    }()
}
