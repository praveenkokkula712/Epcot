//
//  Top10GamesStyles.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 01/07/24.
//

import Foundation
import Utility

struct Top10GamesStyles: Top10GamesCSS {
    var rankFont: UIFont? = {
        .BWSFont(
            className: BWTop10Games, propertyName: "rankFont"
        )
    }()

    var rankOpacity: CGFloat? = {
        .BWSFloat(
            className: BWTop10Games, propertyName: "rankOpacity"
        )
    }()

    var rankHeight: CGFloat? = {
        .BWSFloat(
            className: BWTop10Games, propertyName: "rankHeight"
        )
    }()

    var rankWidth: CGFloat? = {
        .BWSFloat(
            className: BWTop10Games, propertyName: "rankWidth"
        )
    }()

    var tengthRankWidth: CGFloat? = {
        .BWSFloat(
            className: BWTop10Games, propertyName: "tengthRankWidth"
        )
    }()

    var rankGradientTopColor: UIColor? = {
        .BWSColor(
            className: BWTop10Games, propertyName: "rankGradientTopColor"
        )
    }()

    var rankGradientBottomColor: UIColor? = {
        .BWSColor(
            className: BWTop10Games, propertyName: "rankGradientBottomColor"
        )
    }()
}
