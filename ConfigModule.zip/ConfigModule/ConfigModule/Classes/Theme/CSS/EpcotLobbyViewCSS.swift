//
//  EpcotLobbyViewCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

var teasersCSSClassName: String {
    return isEpcotEnabled ? BWEpcotLobbyCSS : BWLobbyCSSStyle
}

public struct EpcotLobbyViewCSS: EpcotLobbyCSS {
    
    public var categoryGameCountCSS: CategoryGameCountCSS? = {
        return EpcotcategoryGameCountCss()
    }()
    
    public var teasersViewCSS: EpcotTeasersCSS? = {
        return  EpcotTeasersViewCSS()
    }()
    
    public var shimmerGradients: ShimmerGradients? = {
        let start = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "startShimmerGradients").cgColor
        let middle = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "middleShimmerGradients").cgColor
        let end = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "endShimmerGradients").cgColor
        return ShimmerGradients(colors: [start, middle, end])
    }()
    
    public var menuViewCSS: EpcotMenuViewCSS? = {
        return EpcotViewMenuCSS()
    }()
    
    public var menuViewTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewTitleColor"), font: UIFont.BWSFont(className: BWEpcotLobbyCSS, propertyName: "menuViewTitleFont"))
    }()
    
    public var menuViewBGColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewBackgroundColor")
    }()
    
    public var searchViewTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "searchViewTitleColor"), font: UIFont.BWSFont(className: BWEpcotLobbyCSS, propertyName: "searchViewTitleFont"))
    }()
    
    public var searchViewBGColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "searchViewBackgroundColor")
    }()
    
    public var searchMenuContainerViewBGColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "searchMenuContainerViewBGColor")
    }()
    
    public var categoriesPillTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "categoriesPillTitleColor"), font: UIFont.BWSFont(className: BWEpcotLobbyCSS, propertyName: "categoriesPillTitleFont"))
    }()
    
    public var categoriesPillBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "categoriesPillBorderColor")
    }()
    
    public var categoriesViewBGColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "categoriesViewBGColor")
    }()
    
    public var gameCollectionViewBGColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "gameCollectionViewBGColor")
    }()
    
    public var backgroundColor: UIColor? = {
        .white
    }()
    
    public var categoriesSelectedPillTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "categoriesSelectedPillTitleColor"), font: UIFont.BWSFont(className: BWEpcotLobbyCSS, propertyName: "categoriesSelectedPillTitleFont"))
    }()
    
    public var categoriesSelectedViewBGColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "categoriesSelectedViewBGColor")
    }()
    
    public var jackpotViewBackgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "jackpotViewBackgroundColor")
    }()
    
    public var jackpotViewLayerBackgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "jackpotViewLayerBackgroundColor")
    }()
    
    public var pageControllerDotsColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "pageControllerDotsColor")
    }()
    
    public var pageControllerDotSelectedColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "pageControllerDotSelectedColor")
    }()
    
    public var epcotSearchViewCSS: EpcotSearchContentCSS? = {
        return EpcotSearchViewCSS()
    }()
        
    public var realityCheckAlertTextColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "realityCheckAlertTextColor")
    }()
    
    public var fallbackPopOverTextColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "fallbackPopOverTextColor")
    }()
    
    public var fallbackPopOverCloseButtonColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "fallbackPopOverCloseButtonColor")
    }()
    
    public var customAlertTitleColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "customAlertTitleColor")
    }()
    
    public var epcotGradientButtonColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "epcotGradientButtonColor")
    }()
    
    public var epcotButtonTitleFont: UIFont? = {
        return UIFont.BWSFont(className: BWEpcotFeature, propertyName: "buttonTitleFont")
    }()
    
    public var epcotViewBorderColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "viewBorderColor")
    }()
        
    public var epcotSecondaryButtonTitleColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "secondaryButtonTextColor")
    }()
    
    public var epcotMenuButtonBorderColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "menuButtonBorderColor")
    }()
    
    public var epcotMandortyUpdateButtonColors1: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "mandortyUpdateButtonColors1")
    }()
    
    public var epcotMandortyUpdateButtonColors2: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "mandortyUpdateButtonColors2")
    }()
    
    public var epcotPopUpBgColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "popUpBgColor")
    }()
    
    public var epcotPopUpHeaderBgColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "popUpHeaderBgColor")
    }()
    
    public var epcotCloseButtonColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "closeButtonColor")
    }()
    
    public var categoryHeaderCloseIconColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "categoryHeaderCloseIconColor")
    }()
    
    public var epcotBodyTextColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "bodyTextColor")
    }()
    
    public var epcotTitleFont: UIFont? = {
        return UIFont.BWSFont(className: BWEpcotFeature, propertyName: "headerTitleFont")
    }()
    
    public var epcotBodyFont: UIFont? = {
        return UIFont.BWSFont(className: BWEpcotFeature, propertyName: "bodyFont")
    }()
    
    public var epcotPopupMessageFont: UIFont? = {
        return UIFont.BWSFont(className: BWEpcotFeature, propertyName: "popupMessageFont")
    }()
    
    public var isEpcotFeatureEnabled: Bool? = {
        return isEpcotEnabled
    }()
    
    public var menuIconFontSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWEpcotFeature, propertyName: "menuPillsIconFontSize")
    }()
    
    public var searchMenuIconFontSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWEpcotFeature, propertyName: "searchMenuIconFontSize")
    }()
    
    public var categoriesPillsIconFontSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWEpcotFeature, propertyName: "categoriesPillsIconFontSize")
    }()
    
    public var immersiveCSS: ImmersiveCSS? = {
        DefaultImmersiveCss()
    }()
    
    public var epcotTextColor: UIColor? = {
        return UIColor.BWSColor(className: BWEpcotFeature, propertyName: "bodyTextColor")
    }()
    public var liveFeedCSS: LiveFeedCSS? = {
       return LiveFeedCss()
    }()
    public init() { }
}


public struct EpcotcategoryGameCountCss: CategoryGameCountCSS {
    
    public var categoryGamesCountTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWCategoryGamesCountCSS, propertyName: "categoryGamesCountTitleColor"), font: UIFont.BWSFont(className: BWCategoryGamesCountCSS, propertyName: "categoryGamesCountTitleFont"))
    }()
    
    public var categoryGamesCountCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWCategoryGamesCountCSS, propertyName: "categoryGamesCountCornerRadius")
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWCategoryGamesCountCSS, propertyName: "categoryGamesCountBgColor")
    }()
}


public struct EpcotTeasersViewCSS: EpcotTeasersCSS {
    
    public var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: teasersCSSClassName, propertyName: "teasersTitleColor"), font: UIFont.BWSFont(className: teasersCSSClassName, propertyName: "teasersTitleFont"))
    }()
    
    public var ipadTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: teasersCSSClassName, propertyName: "teasersTitleColor"), font: UIFont.BWSFont(className: teasersCSSClassName, propertyName: "teasersiPadTitleFont"))
    }()
    
    public var iPadtitleRegularFont: UIFont? = {
        UIFont.BWSFont(className: teasersCSSClassName, propertyName: "teasersiPadTitleRegularFont")
    }()
    
    public var subTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: teasersCSSClassName, propertyName: "teasersSubTitleColor"), font: UIFont.BWSFont(className: teasersCSSClassName, propertyName: "teasersSubTitleFont"))
    }()
    
    public var titleRegularFont: UIFont? = {
        UIFont.BWSFont(className: teasersCSSClassName, propertyName: "teasersTitleRegularFont")
    }()
    
    public var ctaButton: ButtonCSS? = {
        
        let textCSS = CasinoTextCss(
            color: UIColor.BWSColor(className: teasersCSSClassName, propertyName: "teasersCtaButtonTitleColor"), font: UIFont.BWSFont(className: teasersCSSClassName, propertyName: "teasersCtaButtonTitleFont"))
        return CasinoButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: teasersCSSClassName, propertyName: "teasersCtaButtonBGColor"), normal: UIColor.BWSColor(className: teasersCSSClassName, propertyName: "teasersCtaButtonBGColor"))
    }()
    
    public var teaserBGColor: UIColor? = {
        UIColor.BWSColor(className: teasersCSSClassName, propertyName: "teasersBGColor")
    }()
    
    public var teaserCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: teasersCSSClassName, propertyName: "teaserCornerRadius")
    }()
    
    public var embeddedBannerBGColor: UIColor? = {
        UIColor.BWSColor(className: teasersCSSClassName, propertyName: "embeddedBannerBGColor")
    }()
    
    public var termsBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: teasersCSSClassName, propertyName: "termsBGColor")
    }()
    
    public var termsTextColor: UIColor? = {
        UIColor.BWSColor(className: teasersCSSClassName, propertyName: "teaserTermsTextColor")
    }()

    public var termsTextFont: UIFont? = {
        UIFont.BWSFont(className: teasersCSSClassName, propertyName: "teaserTermsTextFont")
    }()
}


public struct EpcotViewMenuCSS: EpcotMenuViewCSS {
    
    public var headerBGColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewHeaderBGColor")
    }()
    
    public var headerCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWEpcotLobbyCSS, propertyName: "menuViewHeaderCornerRadius")
    }()
    
    public var headerTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewHeaderTitleColor"), font: UIFont.BWSFont(className: BWEpcotLobbyCSS, propertyName: "menuViewHeaderTitleFont"))
    }()
    
    public var doneTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewDoneTitleColor"), font: UIFont.BWSFont(className: BWEpcotLobbyCSS, propertyName: "menuViewDoneTitleFont"))
    }()
    
    public var sectionHeaderTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewSectionHeaderTitleColor"), font: UIFont.BWSFont(className: BWEpcotLobbyCSS, propertyName: "menuViewSectionHeaderTitleFont"))
    }()
    
    public var categoriesListTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewCategoriesListTitleColor"), font: UIFont.BWSFont(className: BWEpcotLobbyCSS, propertyName: "menuViewCategoriesListTitleFont"))
    }()
    
    public var seperatorLineColour: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewSeperatorLineColour")
    }()
    
    public var arrowColour: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewArrowColour")
    }()
    
    public var appAdsBGColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewAppAdsBGColor")
    }()
    
    public var appAdsTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewAppAdsTitleColor"), font: UIFont.BWSFont(className: BWEpcotLobbyCSS, propertyName: "menuViewAppAdsTitleFont"))
    }()
    
    public var appAdsDescription: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbyCSS, propertyName: "menuViewAppAdsDescriptionColor"), font: UIFont.BWSFont(className: BWEpcotLobbyCSS, propertyName: "menuViewAppAdsDescriptionFont"))
    }()
    
    public var backgroundColor: UIColor? = {
        .white
    }()
}


public struct EpcotSearchViewCSS: EpcotSearchContentCSS {
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbySearchContent, propertyName: "backgroundColor")
    }()
    
    public var headerTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbySearchContent, propertyName: "headerTitleColor"), font: UIFont.BWSFont(className: BWEpcotLobbySearchContent, propertyName: "headerTitleFont"))
    }()

    public var headerButtonCSS: ButtonCSS? = {
        let color = UIColor.BWSColor(className: BWEpcotLobbySearchContent, propertyName: "headerButtonColor")
        return CasinoButtonCSS(title: CasinoTextCss(color: color, font: UIFont.BWSFont(className: BWEpcotLobbySearchContent, propertyName: "headerButtonFont")), selected: color, normal: color)
    }()
    
    public var headerBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbySearchContent, propertyName: "headerBackgroundColor")
    }()
    
    public var searchText: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbySearchContent, propertyName: "searchTextColor"), font: UIFont.BWSFont(className: BWEpcotLobbySearchContent, propertyName: "searchTextFont"))
    }()
        
    public var clearIconColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbySearchContent, propertyName: "clearIconColor")
    }()
    
    public var micIconColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbySearchContent, propertyName: "micIconColor")
    }()
    
    public var nodataTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWEpcotLobbySearchContent, propertyName: "nodataTitleColor"), font: UIFont.BWSFont(className: BWEpcotLobbySearchContent, propertyName: "nodataTitleFont"))
    }()
    
    public var nodataBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbySearchContent, propertyName: "nodataBackgroundColor")
    }()
    
    public var suggestionsBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWEpcotLobbySearchContent, propertyName: "suggestionsBackgroundColor")
    }()
}


public struct DefaultImmersiveCss: ImmersiveCSS {
    
    public var portraitSectionCSS: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "immersivePortraitSectionTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "immersivePortraitSectionTitleFont"))
    }()
    
    public var downloadIconBGColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "immersiveDownloadIconBGColor")
    }()
    
    public var downloadIconCornerRdius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "immersiveDownloadIconConerRadius")
    }()
}

public struct LiveFeedCss: LiveFeedCSS {

    public var lastResultsTextFont: UIFont? = {
        UIFont.BWSFont(className: BWLiveFeedCSS, propertyName: "lastResultsTextFont")
    }()
    public var availableSeatsTextFont: UIFont? = {
        UIFont.BWSFont(className: BWLiveFeedCSS, propertyName: "availableSeatsTextFont")
    }()
    
    public var lastResultsValuesFont: UIFont? = {
        UIFont.BWSFont(className: BWLiveFeedCSS, propertyName: "lastResultsValuesFont")
    }()
    
    public var availableSeatsAvatarSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWLiveFeedCSS, propertyName: "availableSeatsAvatarSize")
    }()
    
    public var minBetText: Utility.TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLiveFeedCSS, propertyName: "minBetTextColor"), font: UIFont.BWSFont(className: BWLiveFeedCSS, propertyName: "minBetTextFont"))
    }()
    
    public var viewBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLiveFeedCSS, propertyName: "viewBackgroundColor")
    }()
    
    public var viewLayerBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLiveFeedCSS, propertyName: "viewLayerBackgroundColor")
    }()
    
    public var viewOpaqueColor: UIColor? = {
        UIColor.BWSColor(className: BWLiveFeedCSS, propertyName: "viewOpaqueColor")
    }()

    
}

