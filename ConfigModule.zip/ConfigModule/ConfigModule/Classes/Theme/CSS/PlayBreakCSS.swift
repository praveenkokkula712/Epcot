//
//  PlayBreakCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

public struct DialogViewPlayBreakCSS: DialogViewCSS {
    
    public var continueButton: DialogButtonCSS? = {
        PlayBreakContinueButtonCSS()
    }()
    
    public var leaveButton: DialogButtonCSS? = {
        PlayBreakLeaveButtonCSS()
    }()
    
    public var okButton: DialogButtonCSS? = {
        PlayBreakOKButtonCSS()
    }()
        
    public var timerLabelCSS: LabelCSS? = {
        PlayBreakTimerLabelCSS()
    }()
    
    public var progressBarCSS: ProgressBarCSS? = {
        PlayBreakProgressBarCSS()
    }()

    public var title: TextCSS? = {
        return CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWLobbyDialogViewPlayBreak, propertyName: "titleFont"))
    }()
    
    public var body: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "bodyTitleColor"), font: UIFont.BWSFont(className: BWLobbyDialogViewPlayBreak, propertyName: "bodyTitleFont"))
    }()
    
    public var bodyAttribute: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "bodyAttributeColor"), font: UIFont.BWSFont(className: BWLobbyDialogViewPlayBreak, propertyName: "bodyAttributeFont"))
    }()
    
    public var takeBreakButtonBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "takeBreakButtonBackgroundColor")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "backgroundColor")
    }()

    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyDialogViewPlayBreak, propertyName: "cornerRadius")
    }()
}


struct PlayBreakContinueButtonCSS: DialogButtonCSS {
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "continueButtonBGColor")
    }()
    
    var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyDialogViewPlayBreak, propertyName: "continueButtonCornerRadius")
    }()
    
    var borderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyDialogViewPlayBreak, propertyName: "continueButtonBorderWidth")
    }()
    
    var borderColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "continueButtonBorderColor")
    }()
    
    var selected: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "continueButtonSelectedColor")
    }()
    
    var normal: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "continueButtonNormalColor")
    }()
    
    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "continueButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyDialogViewPlayBreak, propertyName: "continueButtonTitleFont"))
    }()
}


struct PlayBreakLeaveButtonCSS: DialogButtonCSS {
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "leaveButtonBGColor")
    }()
    
    var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyDialogViewPlayBreak, propertyName: "leaveButtonCornerRadius")
    }()
    
    var borderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyDialogViewPlayBreak, propertyName: "leaveButtonBorderWidth")
    }()
    
    var borderColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "leaveButtonBorderColor")
    }()
    
    var selected: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "leaveButtonSelectedColor")
    }()
    
    var normal: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "leaveButtonNormalColor")
    }()
    
    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "leaveButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyDialogViewPlayBreak, propertyName: "leaveButtonTitleFont"))
    }()
}


struct PlayBreakOKButtonCSS: DialogButtonCSS {
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "okButtonBGColor")
    }()
    
    var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyDialogViewPlayBreak, propertyName: "okButtonCornerRadius")
    }()
    
    var borderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyDialogViewPlayBreak, propertyName: "okButtonBorderWidth")
    }()
    
    var borderColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "okButtonBorderColor")
    }()
    
    var selected: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "okButtonSelectedColor")
    }()
    
    var normal: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "okButtonNormalColor")
    }()
    
    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "okButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyDialogViewPlayBreak, propertyName: "okButtonTitleFont"))
    }()
}


struct PlayBreakTimerLabelCSS: LabelCSS {
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "timerLabelBGColor")
    }()
    
    var color: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "timerLabelTitleColor")
    }()
    
    var font: UIFont? = {
        UIFont.BWSFont(className: BWLobbyDialogViewPlayBreak, propertyName: "timerLabelTitleFont")
    }()
}


struct PlayBreakProgressBarCSS: ProgressBarCSS {
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "progressBarBackgroundColor")
    }()
    
    var trackTintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "progressBarTrackTintColor")
    }()
    
    var progressTintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyDialogViewPlayBreak, propertyName: "progressBarTintColor")
    }()
}

struct PlayBreakCSS : PlayBreakViewCSS {
    
    var lslCloseButtonColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "lslCloseButtonColor")
    }()
    
    var lslContentViewBGColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "lslContentViewBGColor")
    }()
    
    var lslButtonTextColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "lslButtonTextColor")
    }()
    
    var overlayBgColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "overlayBgColor")
    }()
    
    var contentBgColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "contentBgColor")
    }()
    
    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "titleColor"),font: UIFont.BWSFont(className: BWLobbyPlayBreak, propertyName: "titleFont"))
    }()
    
    var titleHeaderBgColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "titleHeaderBgColor")
    }()
    
    var description: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "descriptionTextColor"),font: UIFont.BWSFont(className: BWLobbyPlayBreak, propertyName: "descriptionTextFont"))
    }()
    
    var moreInfoButton: ButtonCSS? = {
        CasinoButtonCSS(title: CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "moreInfoButtonTextColor"),font: UIFont.BWSFont(className: BWLobbyPlayBreak, propertyName: "moreInfoButtonTextFont")), selected: .clear, normal: .clear)
    }()
    
    var okButton: ButtonCSS? = {
        CasinoButtonCSS(title: CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "okButtonTextColor"),font: UIFont.BWSFont(className: BWLobbyPlayBreak, propertyName: "okButtonTextFont")), selected: UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "okButtonBgColor"), normal: UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "okButtonBgColor"))
    }()
    
    var okButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyPlayBreak , propertyName: "okButtonCornerRadius")
    }()
    
    var toasterText: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "toasterTitleColor"), font: UIFont.BWSFont(className: BWLobbyPlayBreak, propertyName: "toasterTitleFont"))
    }()
    
    var timerText: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "timerTitleColor"), font: UIFont.BWSFont(className: BWLobbyPlayBreak, propertyName: "timerTitleFont"))
    }()
    
    var timerBgColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "timerBgColor")
    }()
    
    var hardInterceptorMoreInfo: ButtonCSS? = {
        CasinoButtonCSS(title: CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "hardInterceptorMoreInfoTextColor"),font: UIFont.BWSFont(className: BWLobbyPlayBreak, propertyName: "hardInterceptorMoreInfoTextFont")), selected: UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "hardInterceptorMoreInfoButtonBgColor"), normal: UIColor.BWSColor(className: BWLobbyPlayBreak, propertyName: "hardInterceptorMoreInfoButtonBgColor"))
    }()
    
    public var fontName: String? = {
        String.BWString(className: BWLobbyPlayBreak, propertyName: "playBreakViewContentFontName")
    }()
    
    public var fontSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyPlayBreak, propertyName: "playBreakViewContentFontSize")
    }()
    
}
