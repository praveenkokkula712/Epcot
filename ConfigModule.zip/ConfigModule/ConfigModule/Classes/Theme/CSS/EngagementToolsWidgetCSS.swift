//
//  EngagementToolsWidgetCSS.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 28/08/24.
//

import Foundation
import Utility

struct EngagementToolsWidgetCSS: EngagementToolsCSS {
    var freeBadgeText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWEngagementTools, propertyName: "freeBadgeTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWEngagementTools, propertyName: "freeBadgeTextFont"
            )
        )
    }()
    
    var freeBadgeBackgroundColor: UIColor? = {
        .BWSColor(
            className: BWEngagementTools, propertyName: "freeBadgeBackgroundColor"
        )
    }()
    
    var freeBadgeCornerRadius: CGFloat? = {
        .BWSFloat(
            className: BWEngagementTools, propertyName: "freeBadgeCornerRadius"
        )
    }()
    
    var titleText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWEngagementTools, propertyName: "titleTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWEngagementTools, propertyName: "titleTextFont"
            )
        )
    }()
    
    var expiryText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWEngagementTools, propertyName: "expiryTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWEngagementTools, propertyName: "expiryTextFont"
            )
        )
    }()
    
    var spinsLeftText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWEngagementTools, propertyName: "spinsLeftTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWEngagementTools, propertyName: "spinsLeftTextFont"
            )
        )
    }()
    
    var backgroundGradientFirstColor: UIColor? = {
        .BWSColor(
            className: BWEngagementTools, propertyName: "backgroundGradientFirstColor"
        )
    }()
    
    var backgroundGradientSecondColor: UIColor? = {
        .BWSColor(
            className: BWEngagementTools, propertyName: "backgroundGradientSecondColor"
        )
    }()
    
    var ctaSize: CGFloat? = {
        .BWSFloat(
            className: BWEngagementTools, propertyName: "ctaSize"
        )
    }()
    
    var height: CGFloat? = {
        .BWSFloat(
            className: BWEngagementTools, propertyName: "height"
        )
    }()
    
    var cornerRadius: CGFloat? = {
        .BWSFloat(
            className: BWEngagementTools, propertyName: "cornerRadius"
        )
    }()
    
    var padding: CGFloat? = {
        .BWSFloat(
            className: BWEngagementTools, propertyName: "padding"
        )
    }()
    
    var backgroundColor: UIColor? = {
        .BWSColor(
            className: BWEngagementTools, propertyName: "backgroundColor"
        )
    }()
    
}
