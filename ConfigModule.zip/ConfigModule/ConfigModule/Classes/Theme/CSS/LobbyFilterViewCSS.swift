//
//  LobbyFilterViewCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

struct CasinoLobbyFilterViewCSS: LobbyFilterView {
    
    var showBtn: LobbyFilterButtonCSS? = {
        CasinoLobbyFilterShowButtonCSS()
    }()
    
    var clearBtnIn: LobbyFilterButtonCSS? = {
        CasinoLobbyFilterClearInButtonCSS()
    }()
    
    var filterBtn: LobbyFilterButtonCSS? = {
        CasinoLobbyFilterOutButtonCSS()
    }()
    
    var clearBtnOut: LobbyFilterButtonCSS? = {
        CasinoLobbyFilterClearOutButtonCSS()
    }()
        
    var headerView: LobbyFilterHeaderView? = {
        CasinoLobbyFilterHeaderView()
    }()
    
    var filterItem: TextCSS? = {
        let color = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewTitleColor")
        let font = UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "filterViewRegularFont16Pix")
        return CasinoTextCss(color:color, font: font)
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBorderColor")
    }()
    
    var checkmarkColor: UIColor? = {
       return nil
    }()
}


struct CasinoLobbyFilterShowButtonCSS: LobbyFilterButtonCSS {
    
    var buttonBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBackgroundColorClear")
    }()
    
    var selected: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonNormalColor")
    }()
    
    var normal: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonNormalColor")
    }()
    
    var title: TextCSS? = {
        let color = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonTitleColor")
        let boldfont = UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "filterViewShowBtnFont")
        return CasinoTextCss(color: color, font: boldfont)
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonNormalColor")
    }()
}


struct CasinoLobbyFilterClearInButtonCSS: LobbyFilterButtonCSS {
    
    var buttonBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewClearInBtnBorderColor")
    }()
    
    var selected: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBackgroundColorClear")
    }()
    
    var normal: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBackgroundColorClear")
    }()
    
    var title: TextCSS? = {
        let color = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewClearInBtnTitleColor")
        let boldfont = UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "filterViewClearInBtnTitleFont")
        return CasinoTextCss(color: color, font: boldfont)
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBackgroundColorClear")
    }()
}


struct CasinoLobbyFilterOutButtonCSS: LobbyFilterButtonCSS {
    
    var buttonBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBackgroundColorClear")
    }()
    
    var selected: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBackgroundColorClear")
    }()
    
    var normal: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBackgroundColorClear")
    }()
    
    var title: TextCSS? = {
        let color = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonTitleColor")
        let boldfont = UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "filterTitleButtonFont")
        return CasinoTextCss(color: color, font: boldfont)
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyCellPlayButtonNormalColor")
    }()
}


struct CasinoLobbyFilterClearOutButtonCSS: LobbyFilterButtonCSS {
    
    var buttonBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewClearOutBtnBorderColor")
    }()
    
    var selected: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBackgroundColorClear")
    }()
    
    var normal: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBackgroundColorClear")
    }()
    
    var title: TextCSS? = {
        let color = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewClearOutBtnTitleColor")
        let boldfont = UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "filterViewClearOutBtnTitleFont")
        return CasinoTextCss(color: color, font: boldfont)
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBackgroundColorClear")
    }()
}


struct CasinoLobbyFilterHeaderView: LobbyFilterHeaderView {
    
    var filterHeaderTitle: TextCSS? = {
        let color = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewTitleColor")
        let boldfont = UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "filterViewBoldFont16Pix")
        return CasinoTextCss(color: color, font: boldfont)
    }()
    
    var filterHeaderClose: ButtonCSS? = {
        let color = UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewTitleColor")
        let font = UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "filterViewRegularFont14Pix")
        let textCSS = CasinoTextCss(color: color, font: font)
        return CasinoButtonCSS(title: textCSS, selected: .clear, normal: .clear)
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "filterViewBackgroundColorClear")
    }()
}
