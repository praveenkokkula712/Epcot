//
//  OnboardingViewCSS.swift
//  ConfigModule
//
//  Created by Rajani Bhimanadham on 27/07/23.
//

import Foundation
import Utility

public struct LobbyOnboardingCSS : OnbordingViewCSS {
    
    public var welcomeScreenCSS: OnbordingWelcomeScreenCSS = {
        return lobbyWelcomeScreenCSS()
    }()
    
    public var journeyViewCSS: OnbordingJourneyViewCSS = {
        return lobbyOnboardingJourneyViewCSS()
    }()
}

public struct lobbyWelcomeScreenCSS : OnbordingWelcomeScreenCSS {
    
    public var getStartedButton: ButtonCSS? = {
        let defaultTitleCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingGetStartedTextColor"), font: UIFont.BWSFont(className: BWOnboardingCSS, propertyName: "onboardingGetStartedFont"))
        return CasinoButtonCSS(title: defaultTitleCSS, selected: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingGetStartedBgColor"), normal: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingGetStartedBgColor"))
    }()
    
    public var skipButton: ButtonCSS? = {
        let defaultTitleCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingSkipNowTextColor"), font: UIFont.BWSFont(className: BWOnboardingCSS, propertyName: "onboardingSkipNowTextFont"))
        return CasinoButtonCSS(title: defaultTitleCSS, selected: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingSkipNowBgColor"), normal: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingSkipNowBgColor"))
    }()
    
    public var getStartedButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOnboardingCSS, propertyName: "onboardingGetStartedCornerRadius")
    }()
    
    public var skipButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOnboardingCSS, propertyName: "onboardingSkipNowCornerRadius")
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOnboardingCSS,
                                               propertyName: "onboardingWelcomeScreenTitleColor"), font: UIFont.BWSFont(className: BWOnboardingCSS, propertyName: "onboardingWelcomeScreenTitleFont"))
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOnboardingCSS,
                                               propertyName: "onboardingWelcomeScreenDescriptionColor"), font: UIFont.BWSFont(className: BWOnboardingCSS, propertyName: "onboardingWelcomeScreenDescriptionFont"))
    }()
    
    public var closeButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.BWSColor(className: BWOnboardingCSS,
                                                                   propertyName: "onboardingWelcomeScreenCloseBtnColor"), font: UIFont.BWSFont(className: BWOnboardingCSS, propertyName: "onboardingWelcomeScreenCloseBtnFont")),
                         selected: UIColor.BWSColor(className: BWOnboardingCSS,
                                                    propertyName: "onboardingWelcomeScreenCloseBtnBgColor"),
                         normal: UIColor.BWSColor(className: BWOnboardingCSS,
                                                  propertyName: "onboardingWelcomeScreenCloseBtnBgColor"))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingWelcomeScreenBgColor")
    }()
    
    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOnboardingCSS, propertyName: "onboardingWelcomeScreenCornerRadius")
    }()
    
    public var overlayBgColor: UIColor? = {
        UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingWelcomeScreenOverlayColor")
    }()
}

public struct lobbyOnboardingJourneyViewCSS : OnbordingJourneyViewCSS {
    
    public var backBtn: ButtonCSS? = {
        let defaultTitleCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewBackBtnColor"), font: UIFont.BWSFont(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewBackBtnFont"))
        return CasinoButtonCSS(title: defaultTitleCSS, selected: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewBackBtnBGColor"), normal: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewBackBtnBGColor"))
    }()
    
    public var nextBtn: ButtonCSS? = {
        let defaultTitleCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewNextBtnColor"), font: UIFont.BWSFont(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewNextBtnFont"))
        return CasinoButtonCSS(title: defaultTitleCSS, selected: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewNextBtnBGColor"), normal: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewNextBtnBGColor"))
    }()
    
    public var closeButton: ButtonCSS? = {
        let defaultTitleCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewCloseBtnColor"), font: UIFont.BWSFont(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewCloseBtnFont"))
        return CasinoButtonCSS(title: defaultTitleCSS, selected: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewCloseBtnBGColor"), normal: UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewCloseBtnBGColor"))
    }()
    
    public var journeyCount: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOnboardingCSS,
                                               propertyName: "onboardingJourneyViewPageCountTextColor"), font: UIFont.BWSFont(className: BWOnboardingCSS, propertyName: "onboardingJourneyPageCountTextFont"))
    }()
    
    public var dividerColor: UIColor? = {
        UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyDividerColor")
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOnboardingCSS,
                                               propertyName: "onboardingJourneyViewTitleColor"), font: UIFont.BWSFont(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewTitleFont"))
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOnboardingCSS,
                                               propertyName: "onboardingJourneyViewDescriptionColor"), font: UIFont.BWSFont(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewDescriptionFont"))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewBgColor")
    }()
    
    public var overlayBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWOnboardingCSS, propertyName: "onboardingJourneyOverlayColor")
    }()
    
    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOnboardingCSS, propertyName: "onboardingJourneyViewCornerRadius")
    }()
}

