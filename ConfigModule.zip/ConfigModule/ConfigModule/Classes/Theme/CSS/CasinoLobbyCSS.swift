//
//  CasinoLobbyCSS.swift
//  NativeCasino
//
//  Created by Bhanuja Tirumareddy on 2/13/20.
//  Copyright © 2020 GVC. All rights reserved.
//

import Foundation
import Utility

var isEpcotEnabled: Bool {
    DynaconAPIConfiguration.shared?.posAppConfig?.features?.enableEpcotFeature ?? false
}

var odrAWS: AppConfigurationODRAWS? {
    DynaconAPIConfiguration.shared?.posAppConfig?.odrAws
}

public struct CasinoLobbyCSS: LobbyCSS {
    public var bingoWidgetViewCss: BingoWidgetCSS? = {
       BingoWidgetView()
   } ()
        
    public var lobbyheaderViewType: LobbyHeaderType? = {
        if let lobbyHeaderView = odrAWS?.lobbyHeaderViewType {
            switch lobbyHeaderView {
            case 0:
                return .gamesCategories
            case 1:
                return .lobbyExploreSwitcher
            case 2:
                return .wheelOfFortuneCategories
            case 3:
                return .epcotCategoryPills
            default:
                return .gamesCategories
            }
        }
        return .gamesCategories
    }()
   
    public var type : LobbyType! = {
        if let lobbyView = DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.lobbyView {
            switch lobbyView {
            case 1:
                return .gridView
            case 2:
                return .gridLayoutV3
            case 3:
                return .listView
            case 4:
                return .listLayoutV2
            case 5:
                return .epcotLobby
            default:
                return .gridLayoutV3
            }
        }
        return .listView
    }()

    public var shimmerViewCSS: ShimmerViewCSS? = {
        LobbyShimmerViewCSS()
    }()
    
    public var epcotLobbyCSS: EpcotLobbyCSS? = {
        return EpcotLobbyViewCSS()
    }()
    
    public var headerCell: HeaderCell? = {
         CasinoLobbyHeader()
    }()
    
    public var titleView: LobbyTitleCSS? = {
         CasinoLobbyTitleView()
    } ()

    public var filterView: LobbyFilterView? = {
        CasinoLobbyFilterViewCSS()
    }()
        
    public var recentlyPlayedView: RecentlyPlayedViewCSS? = {
        CasinoLobbyRecentlyPlayedView()
    }()
            
    public var gamesContainerView: ViewCSS? = {
         CasinoGameContainerView()
    }()

    public var gamesCell: LobbyGameCellCSS? = {
         CasinoLobbyGamesTableViewCell()
    }()
            
    public var navigationView: LobbyNavigationCSS? = {
         CasinoLobbyNavigationView()
    }()
    
    public var lobbySwitcherPopupView: LobbySwitcherPopupViewCSS? = {
        CasinoLobbySwitcherPopupViewCSS()
    }()
    
    public var lobbySwitcherItemView: LobbySwitcherItemCSS? = {
        CasinoLobbySwitcherItemCSS()
    }()
    
    public var exploreLobbyView: ExploreLobbyViewCSS? = {
        CasinoExploreLobbyCSS()
    }()
    
    public var exploreCategoriesPoppUpView: ExploreLobbyCategeroiesPopUpCSS? = {
        CasinoExploreCategoriesPopUpCSS()
    }()
        
    public var lobbyCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "lobbyCornerRadius")
    }()
    
    public var buttonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "buttonCornerRadius")
    }()
    
    public var imageCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "imageCornerRadius")
    }()
    
    public var categoriesIconFontSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "categoriesIconFontSize")
    }()
    
    public var imageFolderPathJson: [String: Any]? = {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.gameImageFolder
    }()
    
    public var immersiveImagePathJson: [String : Any]? = {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.immersiveGameImageFolder
    }()

    public var favouritesIconFontSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "favouritesIconFontSize")
    }()

    public var jackpotFusionPopUpViewCSS: JackpotFusionInfoViewCSS?
    = {
        JackpotFusionInfoPopUpCSS()
    }()
    
    public var gridView: LobbyGridView? = {
        CasinoLobbyGridViewCSS()
    }()
                                        
    public var jackpotWidgets: JackpotWidgetsCSS? = {
       JackpotWidgetsCss()
    }()
          
    public var bingoButtonCSS: BingoButtonCSS? = {
        LobbyBingoButtonCSS()
    }()
    
    public var favoriteToasterViewCSS: FavoriteToasterViewCSS? = {
        CasinoFavoriteToasterViewCSS()
    }()

    public var toasterViewCSS: ToastersViewCSS? = {
        DefaultToasterViewCss()
    }()
    
    public var overlaysViewCSS: OverlaysViewCSS? = {
        DefaultOverlaysViewCss()
    }()
    
    public var stickerCSS: StickerCSS? = {
        CasinoStickerCSS()
    }()
    
    ///Lobby See More
    public var utilView: LobbyUtilCSS? = {
         CasinoLobbyUtilView()
    }()
    
    ///Lobby Footer
    public var nativeFooterViewCSS: NativeFooterCSS? = {
        CasinoNativeCSS()
    }()
    
    public var footerDownArrowIconFontSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "footerDownArrowIconFontSize")
    }()
    
    public var footerRadioButtonIconFontSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "footerRadioButtonIconFontSize")
    }()

    public var noDataView: NoDataView? = {
         CasinoLobbyNoDataView()
    }()
    
    public var noGameDataCell: TextCSS? = {
         CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyNoGameCellTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyNoGameCellTitleFont"))
    }()

    public var fallback: FallbackCSS? = {
        CasinoFallbackSolutionCSS()
    }()
        
    ///See More Screen
    public var seeMoreSectionView: SeeMoreSectionViewCss? = {
        ImmersiveSeeMoreSectionViewCss()
    }()

    ///Search screen
    public var searchView: LobbySearchContentCSS? = {
         CasinoSearchView()
    }()

    public var searchInputAccessoryViewCSS: SearchInputAccessoryViewCSS? = {
         DefaultSearchInputAccessoryViewCSS()
    }()
    
    public var suggestionView: LobbySuggestionCSS? = {
         CasinoLobbySuggestionView()
    }()

    
    ///Casino Games
    public var downloadingView: DownloadingViewCSS? = {
        GameDownloadingViewCSS()
    }()

    public var rcpUK: RcpUKCSS? = {
        RCPUKAlertCSS()
    }()
    
    public var germanRegulatory: GermanRegulatoryCSS? = {
        CasinoGermanRegulatoryCSS()
    }()
    
    public var greeceLimits: LimitsCSS? = {
        LobbyLimitsCSS()
    }()

    public var dialogViewCSS: DialogViewCSS? = {
        DialogViewPlayBreakCSS()
    }()

    public var easyNavigation: EasyNavigationCSS? = {
        LobbyEasyNavigationCSS()
    }()

    public var longSessionBreakToastViewCSS: TakeAPlayBreakToastViewCSS? = {
        LongSessionToastViewCSS()
    }()
    
    public var longSessionBreakSetUpViewCSS: LongSessionBreakSetUpViewCSS? = {
        LongSessionPlayBreakSetUpViewCSS()
    }()
    
    public var longSessionBreakConfirmationViewCSS: LongSessionBreakConfirmationViewCSS? = {
        LongSessionPlayBreakConfirmationViewCSS()
    }()
    
    //Casino Stories
    public var gameStoriesCSS: GameStoriesCSS? = {
        DefaultGameStoriesCSS()
    }()
    
    public var gameStoryItemsCSS: GameStoryItemsCSS? = {
        DefaultGameStoryItemsCSS()
    }()
    //UserOnboarding
    public var onboardingViewCSS: OnbordingViewCSS? = {
        LobbyOnboardingCSS()
    }()
    
    // PlayBreakView
    public var playBreakViewCSS: PlayBreakViewCSS? = {
         PlayBreakCSS()
    }()
    
    public var jackpotTilesViewCSS: JackpotTilesViewCSS? = {
       JackpotTilesCSS()
    }()
    
    //Search V2
    public var searchV2CSS: SearchV2CSS? = {
        SearchV2POSCSS()
    }()
    
    //gamePremiere
    public var gamePremiereCSS: GamePremiereCSS? = {
        GamePremiereOverlayCSS()
    }()
    //Prominent Free Spins
    public var freeSpinsCSS: FreeSpinsCSS? = {
        FreeSpinsWidgetCSS()
    }()

    //Top 10 Games
    public var top10GamesCSS: Top10GamesCSS? = {
        Top10GamesStyles()
    }()
    
    public var playerStatsWidgetCSS: PlayerStatsWidgetCSS? = {
        PlayerStatsWidgetsCSS()
    }()
    
    public var originalsWidgetCSS: OriginalsWidgetCSS? = {
        OriginalsWidgetCss()
    }()

    public var sessionLimitCss: SessionLimitCSS? = {
        SessionLimitsCSS()
    }()

    // Engagement Tools
    public var engagementToolsCSS: EngagementToolsCSS? = {
        EngagementToolsWidgetCSS()
    }()

    public init() { }
}
