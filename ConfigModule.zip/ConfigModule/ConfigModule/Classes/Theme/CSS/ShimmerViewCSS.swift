//
//  ShimmerViewCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

public struct LobbyShimmerViewCSS: ShimmerViewCSS {
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyShimmerView, propertyName: "backgroundColor")
    }()
    
    public var borderColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyShimmerView, propertyName: "borderColor")
    }()

    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyShimmerView, propertyName: "cornerRadius")
    }()
    
    public var gradients: ShimmerGradients? = {
        let startColor = UIColor.BWSColor(className: BWLobbyShimmerView, propertyName: "gradientColorStart").cgColor
        let middleColor = UIColor.BWSColor(className: BWLobbyShimmerView, propertyName: "gradientColorMiddle").cgColor
        let endColor = UIColor.BWSColor(className: BWLobbyShimmerView, propertyName: "gradientColorEnd").cgColor
        return ShimmerGradients(colors: [startColor, middleColor, endColor])
    }()
}
