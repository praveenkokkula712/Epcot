//
//  FreeSpinsPOSCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 02/05/24.
//

import Foundation
import Utility

struct FreeSpinsWidgetCSS: FreeSpinsCSS {
    var remainingSpinsText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWProminentFreeSpins, propertyName: "remainingSpinsTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWProminentFreeSpins, propertyName: "remainingSpinsTextFont"
            )
        )
    }()

    var expiryText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWProminentFreeSpins, propertyName: "expiryTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWProminentFreeSpins, propertyName: "expiryTextFont"
            )
        )
    }()

    var spinText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWProminentFreeSpins, propertyName: "spinTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWProminentFreeSpins, propertyName: "spinTextFont"
            )
        )
    }()

    var spinButtonTopColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "spinButtonTopColor"
        )
    }()
    
    var spinButtonBottomColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "spinButtonBottomColor"
        )
    }()
    
    var spinButtonBackgroundColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "spinButtonBackgroundColor"
        )
    }()

    var backgroundColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "backgroundColor"
        )
    }()

    var cornerRadius: CGFloat? = {
        .BWSFloat(
            className: BWProminentFreeSpins, propertyName: "cornerRadius"
        )
    }()

    var height: CGFloat? = {
        .BWSFloat(
            className: BWProminentFreeSpins, propertyName: "height"
        )
    }()

    var gradientLeftColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "gradientLeftColor"
        )
    }()

    var gradientMiddleColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "gradientMiddleColor"
        )
    }()

    var gradientRightColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "gradientRightColor"
        )
    }()

    var gradientOpacity: CGFloat? = {
        .BWSFloat(
            className: BWProminentFreeSpins, propertyName: "gradientOpacity"
        )
    }()

    var overlayCSS: FreeSpinsOverlayCSS? = {
        FreeSpinsWidgetOverlayCSS()
    }()

    var pageControlCSS: FreeSpinsPageControlCSS? = {
        FreeSpinsWidgetPageControlCSS()
    }()
}

struct FreeSpinsWidgetOverlayCSS: FreeSpinsOverlayCSS {
    
    var backgroundColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "overlayBackgroundColor"
        )
    }()
    
    var overlayCornerRadius: CGFloat? = {
        .BWSFloat(className: BWProminentFreeSpins, propertyName: "overlayCornerRadius")
    }()
    
    var headerBgColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "overlayHeaderBackgroundColor"
        )
    }()
    
    var headerTitle: TextCSS? = {
        let color = UIColor.BWSColor(className: BWProminentFreeSpins, propertyName: "overlayHeaderTitleColor")
        let font = UIFont.BWSFont(className: BWProminentFreeSpins, propertyName: "overlayHeaderTitleFont")
        return DefaultTextCSS(color: color, font: font)
    }()
    
    var headerSubTitle: TextCSS? = {
        let color = UIColor.BWSColor(className: BWProminentFreeSpins, propertyName: "overlayHeaderSubTitleColor")
        let font = UIFont.BWSFont(className: BWProminentFreeSpins, propertyName: "overlayHeaderSubTitleFont")
        return DefaultTextCSS(color: color, font: font)
     }()
    
    var headerButton: ButtonCSS? = {
        let titleColor = UIColor.BWSColor(className: BWProminentFreeSpins, propertyName: "overlayHeaderButtonTitleColor")
        let font = UIFont.BWSFont(className: BWProminentFreeSpins, propertyName: "overlayHeaderButtonTitleFont")
        let textCSS = CasinoTextCss(color: titleColor, font: font)
        return CasinoButtonCSS(title: textCSS, selected: .clear, normal: .clear)
    }()
    
    var headerButtonCornerRadius: CGFloat? = {
        .BWSFloat(className: BWProminentFreeSpins, propertyName: "overlayHeaderButtonCornerRadius")
    }()

    var headerButtonBorderColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "overlayHeaderButtonBorderColor"
        )
    }()
    
    var headerButtonBorderWidth: CGFloat? = {
        .BWSFloat(className: BWProminentFreeSpins, propertyName: "overlayHeaderButtonBorderWidth")
    }()
    
    var winningsImageCornerRadius: CGFloat? = {
        .BWSFloat(className: BWProminentFreeSpins, propertyName: "overlayWinningsImageCornerRadius")
    }()

    var winningsTitle: TextCSS? = {
        let color = UIColor.BWSColor(className: BWProminentFreeSpins, propertyName: "overlayWinningsTitleColor")
        let font = UIFont.BWSFont(className: BWProminentFreeSpins, propertyName: "overlayWinningsTitleFont")
        return DefaultTextCSS(color: color, font: font)
     }()
    
    var winningsAmountTitle: TextCSS? = {
        let color = UIColor.BWSColor(className: BWProminentFreeSpins, propertyName: "overlayWinningsAmountTitleColor")
        let font = UIFont.BWSFont(className: BWProminentFreeSpins, propertyName: "overlayWinningsAmountTitleFont")
        return DefaultTextCSS(color: color, font: font)
     }()
    
    var spinsProgressBgColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "overlaySpinsProgressBgColor"
        )
    }()
    
    var spinsProgressFillColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "overlaySpinsProgressFillColor"
        )
    }()
    
    var totalSpinsTitle: TextCSS? = {
        let color = UIColor.BWSColor(className: BWProminentFreeSpins, propertyName: "overlayTotalSpinsTitleColor")
        let font = UIFont.BWSFont(className: BWProminentFreeSpins, propertyName: "overlayTotalSpinsTitleFont")
        return DefaultTextCSS(color: color, font: font)
     }()
    
    var spinsLeftTitle: TextCSS? = {
        let color = UIColor.BWSColor(className: BWProminentFreeSpins, propertyName: "overlaySpinsLeftTitleColor")
        let font = UIFont.BWSFont(className: BWProminentFreeSpins, propertyName: "overlaySpinsLeftTitleFont")
        return DefaultTextCSS(color: color, font: font)
     }()
    
    var eligibleGamesTitle: TextCSS? = {
        let color = UIColor.BWSColor(className: BWProminentFreeSpins, propertyName: "overlayEligibleGamesTitleColor")
        let font = UIFont.BWSFont(className: BWProminentFreeSpins, propertyName: "overlayEligibleGamesTitleFont")
        return DefaultTextCSS(color: color, font: font)
     }()
    
    var footerDividerColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "overlayFooterDividerColor"
        )
    }()
    
    var ctaTitle: ButtonCSS? = {
        let titleColor = UIColor.BWSColor(className: BWProminentFreeSpins, propertyName: "overlayCTATitleColor")
        let font = UIFont.BWSFont(className: BWProminentFreeSpins, propertyName: "overlayCTATitleFont")
        let textCSS = CasinoTextCss(color: titleColor, font: font)
        return CasinoButtonCSS(title: textCSS, selected: .clear, normal: .clear)
    }()
}

struct FreeSpinsWidgetPageControlCSS: FreeSpinsPageControlCSS {
    var dotsColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "pageControlColor"
        )
    }()
    
    var selectedDotColor: UIColor? = {
        .BWSColor(
            className: BWProminentFreeSpins, propertyName: "activePageColor"
        )
    }()
}
