//
//  LobbyFooterCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

var nativeFooterCSSClassName: String {
    return isEpcotEnabled ? BWEpcotFooterView : BWLobbyCSSStyle
}

struct CasinoNativeCSS:NativeFooterCSS  {
    
    var brandLogoBGColor: UIColor? = {
        .clear
    }()
    
    var logosBGColor: UIColor? = {
        .clear
    }()
    
    var aboutUs: NFViewCSS? = {
        CasinoAboutCSS()
    }()
    
    var content: NFContentCSS? = {
        CasinoContentCSS()
    }()
    
    var copyRight: NFCopyrightCSS? = {
         CasinoCopyRightCSS()
    }()
    
    var seolinks: NFViewCSS? = {
         CasinoSEOLinksCSS()
    }()
        
    var backgroundColor: UIColor? = {
         UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerNativeViewBackgroundColor")
    }()
    
    var stateView: NFStateChangerViewCSS? = {
        CasinoNFStateView()
    }()
    
    var lineColor: UIColor? = {
        return isEpcotEnabled ? UIColor(red: 1, green: 1, blue: 1, alpha: 0.28) : .clear
    }()
    
    var footerTimerTextColor: UIColor? = {
        UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerStateSwitcherTimerTextColor")
    }()
    
    var footerTitleColor: UIColor? = {
        UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerStateSwitcherTitleColor")
    }()
}


struct CasinoAboutCSS: NFViewCSS {

    var header: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerNativeHeaderTextColor"), font: UIFont.BWSFont(className: nativeFooterCSSClassName, propertyName: "footerNativeHeaderFont"))
    }()

    var item: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerNativeItemTextColor"), font: UIFont.BWSFont(className: nativeFooterCSSClassName, propertyName: "footerNativeItemFont"))
    }()

    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerSEOLinksBackGroundColor")
    }()
}


struct  CasinoContentCSS: NFContentCSS {
    
    var color: UIColor? = {
        let propertyName = isEpcotEnabled ? "footerNativeContentTextColor" : "footerNativeItemTextColor"
        return UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: propertyName)
    }()
    
    var font: UIFont? = {
        let propertyName = isEpcotEnabled ? "footerNativeContentFont" : "footerNativeItemFont"
        return UIFont.BWSFont(className: nativeFooterCSSClassName, propertyName: propertyName)
    }()
    
    var backgroundColor: UIColor? = {
         .clear
    }()
}


struct  CasinoCopyRightCSS: NFCopyrightCSS {
    
    var color: UIColor? = {
        let propertyName = isEpcotEnabled ? "footerNativeCopyrightTextColor" : "footerNativeItemTextColor"
        return UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: propertyName)
    }()
    
    var font: UIFont? = {
        let propertyName = isEpcotEnabled ? "footerNativeCopyrightFont" : "footerNativeHeaderFont"
        return UIFont.BWSFont(className: nativeFooterCSSClassName, propertyName: propertyName)
    }()
    
    var backgroundColor: UIColor? = {
         .clear
    }()
}


struct  CasinoSEOLinksCSS: NFViewCSS {

    var header: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerNativeHeaderTextColor"), font: UIFont.BWSFont(className: nativeFooterCSSClassName, propertyName: "footerNativeHeaderFont"))
    }()

    var item: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerNativeItemTextColor"), font: UIFont.BWSFont(className: nativeFooterCSSClassName, propertyName: "footerNativeItemFont"))
    }()

    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerSEOLinksBackGroundColor")
    }()
}


struct CasinoNFStateView: NFStateChangerViewCSS {
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerSEOLinksBackGroundColor")
    }()
    
    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerNativeItemTextColor"), font: UIFont.BWSFont(className: nativeFooterCSSClassName, propertyName: "footerNativeItemFont"))
    }()
    
    var stateChangeBtnBorderColor: UIColor? = {
        UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "stateSwitcherBtnBorderColor")
    }()
    
    var stateChangerBtn: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerNativeItemTextColor"), font: UIFont.BWSFont(className: nativeFooterCSSClassName, propertyName: isEpcotEnabled ? "footerStateSelectionFont" : "footerNativeItemFont"))
    }()
    
    var stateListViewBorderColor: UIColor? = {
        UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "footerNativeItemTextColor")
    }()
    
    var stateChangeBtnSelectedBackgroundColor: UIColor? = {
        isEpcotEnabled ? UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "stateSwitcherBtnSelectedBackgroundColor") : .clear
    }()

    var stateChangeIconColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#79BFFF")
    }()
    
    var stateListIconColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#475EEC")
    }()

    var stateSwitcherDropDownColor: UIColor? = {
        UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "stateSwitcherDropDownColor")
    }()

    var stateSwitcherRadioButtonColor: UIColor? = {
        UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "stateSwitcherRadioButtonColor")
    }()

    var stateListTitleColor: UIColor? = {
        UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "stateSwitcherListTitleColor")
    }()

    var stateListBgColor: UIColor? = {
        UIColor.BWSColor(className: nativeFooterCSSClassName, propertyName: "stateListBgColor")
    }()
}
