//
//  LongSessionCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

public struct LongSessionToastViewCSS: TakeAPlayBreakToastViewCSS {
    
    public var descriptionCSS: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionToastView, propertyName: "descriptionLabelColor"), font: UIFont.BWSFont(className: BWLongSessionToastView, propertyName: "descriptionLabelFont"))
    }()

    public var titleCSS: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionToastView, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWLongSessionToastView, propertyName: "titleFont"))
    }()

    public var showLaterButtonCSS: ButtonCSS? = {
        let color = UIColor.BWSColor(className: BWLongSessionToastView, propertyName: "showLaterBackgroundColor")
        return CasinoButtonCSS(title: CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionToastView, propertyName: "showLaterButtonTitleColor"), font: UIFont.BWSFont(className: BWLongSessionToastView, propertyName: "showLaterButtonTitleFont")), selected: color, normal: color)
    }()

    public var takeABreakButtonCSS: ButtonCSS? = {
        let color = UIColor.BWSColor(className: BWLongSessionToastView, propertyName: "takeABreakBackgroundColor")
        return CasinoButtonCSS(title: CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionToastView, propertyName: "takeABreakButtonTitleColor"), font: UIFont.BWSFont(className: BWLongSessionToastView, propertyName: "takeABreakButtonTitleFont")), selected: color, normal: color)
    }()

    public var backgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWLongSessionToastView, propertyName: "backgroundColor")
    }()

    public var containerViewCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLongSessionToastView, propertyName: "containerViewCornerRadius")
    }()
}


public struct LongSessionPlayBreakSetUpViewCSS: LongSessionBreakSetUpViewCSS {

    public var descriptionCSS: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionBreakSetUpView, propertyName: "descriptionLabelColor"), font: UIFont.BWSFont(className: BWLongSessionBreakSetUpView, propertyName: "descriptionLabelFont"))
    }()

    public var titleCSS: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionBreakSetUpView, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWLongSessionBreakSetUpView, propertyName: "titleFont"))
    }()

    public var durationButtonCSS: ButtonCSS? = {
        let color = UIColor.BWSColor(className: BWLongSessionBreakSetUpView, propertyName: "durationDropDownColor")
        return CasinoButtonCSS(title: CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionBreakSetUpView, propertyName: "durationDropDownColor"), font: UIFont.BWSFont(className: BWLongSessionBreakSetUpView, propertyName: "durationDropDownFont")), selected: color, normal: color)
    }()

    public var continueButtonCSS: ButtonCSS? = {
        let color = UIColor.BWSColor(className: BWLongSessionBreakSetUpView, propertyName: "continueBackgroundColor")
        return CasinoButtonCSS(title: CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionBreakSetUpView, propertyName: "continueButtonTitleColor"), font: UIFont.BWSFont(className: BWLongSessionBreakSetUpView, propertyName: "continueButtonTitleFont")), selected: color, normal: color)
    }()

    public var backgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWLongSessionBreakSetUpView, propertyName: "backgroundColor")
    }()

    public var containerViewCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLongSessionBreakSetUpView, propertyName: "containerViewCornerRadius")
    }()
    
    public var dropDownBorderSelectedColor: UIColor? = {
        return UIColor.BWSColor(className: BWLongSessionBreakSetUpView, propertyName: "dropDownBorderSelectedColor")
    }()
    
    public var dropDownBorderUnSelectedColor: UIColor? = {
        return UIColor.BWSColor(className: BWLongSessionBreakSetUpView, propertyName: "dropDownBorderUnSelectedColor")
    }()
}


public struct LongSessionPlayBreakConfirmationViewCSS: LongSessionBreakConfirmationViewCSS {
    
    public var titleCSS: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionConfirmationView, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWLongSessionConfirmationView, propertyName: "titleFont"))
    }()
    
    public var descriptionCSS: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionConfirmationView, propertyName: "descriptionLabelColor"), font: UIFont.BWSFont(className: BWLongSessionConfirmationView, propertyName: "descriptionLabelFont"))
    }()

    public var changeSettingsButtonCSS: ButtonCSS? = {
        let color = UIColor.BWSColor(className: BWLongSessionConfirmationView, propertyName: "changeSettingsBackgroundColor")
        return CasinoButtonCSS(title: CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionConfirmationView, propertyName: "changeSettingsButtonTitleColor"), font: UIFont.BWSFont(className: BWLongSessionConfirmationView, propertyName: "changeSettingsButtonTitleFont")), selected: color, normal: color)
    }()

    public var confirmButtonCSS: ButtonCSS? = {
        let color = UIColor.BWSColor(className: BWLongSessionConfirmationView, propertyName: "confirmationBackgroundColor")
        return CasinoButtonCSS(title: CasinoTextCss(color: UIColor.BWSColor(className: BWLongSessionConfirmationView, propertyName: "confirmationButtonTitleColor"), font: UIFont.BWSFont(className: BWLongSessionConfirmationView, propertyName: "confirmationButtonTitleFont")), selected: color, normal: color)
    }()

    public var backgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWLongSessionConfirmationView, propertyName: "backgroundColor")
    }()

    public var containerViewCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLongSessionConfirmationView, propertyName: "containerViewCornerRadius")
    }()
}
