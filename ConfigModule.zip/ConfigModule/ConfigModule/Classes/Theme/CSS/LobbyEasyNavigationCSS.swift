//
//  LobbyEasyNavigationCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

public struct LobbyEasyNavigationCSS: EasyNavigationCSS {
    public var seperatorColor: UIColor?
    
    public var gamePillBGColorSelected: UIColor?
    
    public var gamePillBGColorUnselected: UIColor?
    
    public var gamePillTextColorSelected: UIColor?
    
    public var gamePillTextColorUnselected: UIColor?
    
    public var gamePillTextFont: UIFont?
    
    public var buttonCornerRadius: CGFloat?
    
    public var buttonTitleColor: UIColor?
    
    public var buttonTitleFont: UIFont?
    
    public var borderColor: UIColor?
    
    public var borderWidth: CGFloat?
    
    
    public var sessionTimerCSS: SessionTimerCSS? = {
      return LobbyEzSessionTimerCSS()
    }()
    
    public var sessionWinLossCSS: SessionWinLossCSS? = {
       return LobbyEzSessionWinLossCSS()
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyEasyNavigation, propertyName: "backgroundColor")
    }()
    
    public var subBrandColor: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyEasyNavigation, propertyName: "subBrandColor")
    }()
}


public struct LobbyEzSessionTimerCSS: SessionTimerCSS {
    
    public var gamePlayDuration: TextCSS? = {
        return CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyEasyNavigation, propertyName: "gamePlayDurationTitleColor"), font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "gamePlayDurationTitlefont"))
    }()
    
    public var currentTime: TextCSS? = {
        return CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyEasyNavigation, propertyName: "currentTimeTitleColor"), font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "currentTimeTitleFont"))
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyEasyNavigation, propertyName: "timerBGColor")
    }()
}


public struct LobbyEzSessionWinLossCSS: SessionWinLossCSS {
    
    public var session: TextCSS? = {
        return CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyEasyNavigation, propertyName: "sessionTitleColor"), font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "sessionTitleFont"))
    }()
    
    public var amount: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyEasyNavigation, propertyName: "winLossTitleColor"), font: UIFont.BWSFont(className: BWLimitsGreecePage, propertyName: "winLossTitleFont"))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyEasyNavigation, propertyName: "winLossBGColor")
    }()
}
