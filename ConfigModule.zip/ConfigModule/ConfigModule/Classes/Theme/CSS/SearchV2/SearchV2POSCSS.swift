//
//  SearchV2POSCSS.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 10/08/23.
//

import Foundation
import Utility

public struct SearchV2POSCSS: SearchV2CSS {
    public var backgroundColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "screenBackgroundColor"
        )
    }()
    
    public var searchBarV2CSS: SearchBarV2CSS? = {
        SearchBarV2POSCSS()
    }()
    
    public var searchHeaderV2CSS: SearchHeaderV2CSS? = {
        SearchHeaderV2POSCSS()
    }()
    
    public var searchSectionsV2CSS: SearchSectionsV2CSS? = {
        SearchSectionsV2POSCSS()
    }()
    
    public var searchResultsV2CSS: SearchResultsV2CSS? = {
        SearchResultsV2POSCSS()
    }()
}
