//
//  SearchResultsV2POSCSS.swift
//  ConfigModule
//
//  Created by Sindhuja Vedire on 15/09/23.
//

import Foundation
import Utility

public struct SearchResultsV2POSCSS: SearchResultsV2CSS {

    public var searchResultsBackgroundColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "searchResultsBackgroundColor"
        )
    }()
    
    public var header: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWSearchV2CSS, propertyName: "searchResultsHeaderColor"
            ),
            font: UIFont.BWSFont(
                className: BWSearchV2CSS, propertyName: "searchResultsHeaderFont"
            )
        )
    }()
    
    public var listItemImageCornerRadius: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "listItemImageCornerRadius"
        )
    }()
    
    public var listItemTitle: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWSearchV2CSS, propertyName: "listItemTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWSearchV2CSS, propertyName: "listItemTitleFont"
            )
        )
    }()
    
    public var listItemArrowIcon: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "listItemArrowIconSize"
        )
    }()
    
    public var listItemArrowIconColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "listItemArrowIconColor"
        )
    }()
    
    public var iconSize: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "noSearchResultsIconSize"
        )
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWSearchV2CSS, propertyName: "noSearchResultsTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWSearchV2CSS, propertyName: "noSearchResultsTitleFont"
            )
        )
    }()
    
    public var subtitle: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWSearchV2CSS, propertyName: "noSearchResultsDetailsColor"
            ),
            font: UIFont.BWSFont(
                className: BWSearchV2CSS, propertyName: "noSearchResultsDetailsFont"
            )
        )
    }()
    
    public var selectedTabTextColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "selectedTabTextColor"
        )
    }()
    
    public var unselectedTabTexColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "unselectedTabTextColor"
        )
    }()
    
    public var categoryTabViewBgColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "categoryTabsViewBgColor"
        )
    }()
    
    public var selectedTabTextFont: UIFont? = {
        .BWSFont(className: BWSearchV2CSS, propertyName: "selectedTabTextFont")
    }()
    
    public var unSelectedTabTextFont: UIFont? = {
        .BWSFont(className: BWSearchV2CSS, propertyName: "unSelectedTabTextFont")
    }()
    
    public var dividerColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "listItemDividerColor"
        )
    }()
    
    public var hairLineHeight: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "hairLineHeight"
        )
    }()
    
    public var hairLineColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "hairLineColor"
        )
    }()
    
    public var highlightedSearchTextColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "highlightedSearchTextColor"
        )
    }()
    
    public var noResultsFoundBackgroundColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "noResultsFoundBackgroundColor"
        )
    }()
}
