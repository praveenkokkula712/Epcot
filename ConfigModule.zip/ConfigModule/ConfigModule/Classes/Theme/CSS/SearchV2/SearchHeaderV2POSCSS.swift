//
//  SearchHeaderV2POSCSS.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 10/08/23.
//

import Foundation
import Utility

public struct SearchHeaderV2POSCSS: SearchHeaderV2CSS {
    public var backgroundColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS,
            propertyName: "searchHeaderBackgroundColor"
        )
    }()
    
    public var height: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "searchHeaderHeight"
        )
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWSearchV2CSS, propertyName: "searchHeaderTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWSearchV2CSS, propertyName: "searchHeaderTitleFont"
            )
        )
    }()
    
    public var backIconSize: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "searchHeaderBackIconSize"
        )
    }()
}
