//
//  SearchBarV2POSCSS.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 10/08/23.
//

import Foundation
import Utility

public struct SearchBarV2POSCSS: SearchBarV2CSS {
    public var backgroundColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "searchBarBackgroundColor"
        )
    }()

    public var height: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "searchBarHeight"
        )
    }()
    
    public var cornerRadius: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "searchBarCornerRadius"
        )
    }()
    
    public var iconSize: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "searchBarIconSize"
        )
    }()
    
    public var placeholderColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "searchBarPlaceholderColor"
        )
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWSearchV2CSS, propertyName: "searchBarTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWSearchV2CSS, propertyName: "searchBarTitleFont"
            )
        )
    }()
    
    public var clearBackgroundColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "searchBarClearBackgroundColor"
        )
    }()
    
    public var clearSize: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "searchBarClearSize"
        )
    }()
    
    public var audioButtonSize: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "searchBarAudioButtonSize"
        )
    }()
    
    public var cancelText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWSearchV2CSS, propertyName: "searchBarCancelColor"
            ),
            font: UIFont.BWSFont(
                className: BWSearchV2CSS, propertyName: "searchBarCancelFont"
            )
        )
    }()
    
    public var shadowColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "searchBarShadowColor"
        )
    }()
    
    public var shadowRadius: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "searchBarShadowRadius"
        )
    }()
    
    public var micActiveColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "activeMicTintColor"
        )
    }()
    
    public var micInactiveColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "inActiveMicTintColor"
        )
    }()
}
