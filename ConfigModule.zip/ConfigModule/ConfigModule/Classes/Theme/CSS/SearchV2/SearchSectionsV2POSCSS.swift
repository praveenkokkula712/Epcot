//
//  SearchSectionsV2POSCSS.swift
//  ConfigModule
//
//  Created by Sindhuja Vedire on 25/08/23.
//

import Foundation
import Utility

public struct SearchSectionsV2POSCSS: SearchSectionsV2CSS {
    
    public var backgroundColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "containerBackgroundColor"
        )
    }()
    
    public var pillsBackgroundColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "pillsBackgroundColor"
        )
    }()
    
    public var sectionHeaderTitle: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWSearchV2CSS, propertyName: "sectionHeaderTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWSearchV2CSS, propertyName: "sectionHeaderTitleFont"
            )
        )
    }()
    
    public var clearAllTitle: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWSearchV2CSS, propertyName: "clearAllTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWSearchV2CSS, propertyName: "clearAllTitleFont"
            )
        )
    }()
    
    public var clearAllIconSize: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "clearAllIconSize"
        )
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWSearchV2CSS, propertyName: "gameTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWSearchV2CSS, propertyName: "gameTitleFont"
            )
        )
    }()
    
    public var listTitle: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWSearchV2CSS, propertyName: "listTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWSearchV2CSS, propertyName: "listTitleFont"
            )
        )
    }()
    
    public var pillsCornerRadius: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "pillsCornerRadius"
        )
    }()
    
    public var recentSearchBackgroundColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "recentSearchBackgroundColor"
        )
    }()
    
    public var height: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "recentSearchDividerHeight"
        )
    }()
    
    public var dividerColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "recentSearchDividercolor"
        )
    }()
    
    public var closeIconSize: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "recentSearchCloseIconSize"
        )
    }()
    
    public var searchHistoryIconSize: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "recentSearchHistoryIconSize"
        )
    }()
    
    public var arrowIconSize: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "recentSearchArrowIconSize"
        )
    }()
    
    public var stickerBackGroundColor: UIColor? = {
        .BWSColor(
            className: BWStickerCSS, propertyName: "stickerViewBgColor"
        )
    }()
    
    public var stickerText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWStickerCSS, propertyName: "stickerTitleColor"),
            font: UIFont.BWSFont(
                className: BWStickerCSS, propertyName: "stickerTitleFont")
        )
    }()
    
    public var stickerCornerRadius: CGFloat? = {
        .BWSFloat(
            className: BWStickerCSS, propertyName: "stickerViewCornerRadius"
        )
    }()
    
    public var gameTileCss: SearchGameTileCSS? = {
        GameTileCSS()
    }()
}

public struct GameTileCSS: SearchGameTileCSS {
    
    static var odrAWS: AppConfigurationODRAWS? {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws
    }
    
    public var gameTileCornerRadius: CGFloat? = {
        .BWSFloat(
            className: BWSearchV2CSS, propertyName: "gameTilesCornerRadius"
        )
    }()
    
    public var shadowColor: UIColor? = {
        .BWSColor(
            className: BWSearchV2CSS, propertyName: "gameTilesShadowColor"
        )
    }()
    
    public var favouriteButtonIconSelected: String? = {
        Self.odrAWS?.favouriteButtonIcon?["kFavouriteSelected"] as? String
    }()
    
    public var favouriteButtonIconUnselected: String? = {
        Self.odrAWS?.favouriteButtonIcon?["kFavouriteUnselected"] as? String
    }()
    
    public var favouriteButtonTintColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyFavouriteButtonTintColor")
    }()
    
    public var favouriteButtonBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyFavouriteButtonBackgroundColor")
    }()
    
    public var favouriteIconFontSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "favouritesIconFontSize")
    }()
    
    public var jpView: JPView? = {
        CasinoJPView()
    }()
}
