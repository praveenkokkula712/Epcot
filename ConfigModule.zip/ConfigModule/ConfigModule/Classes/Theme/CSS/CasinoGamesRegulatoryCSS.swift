//
//  CasinoGamesRegulatoryCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

public struct CasinoGermanRegulatoryCSS: GermanRegulatoryCSS {
    
    public var gameExclusionViewCSS: GameExclusionViewCSS? = {
        DefaultGameExclusionViewCSS()
    }()
    
    public var monthlySummaryPopUpViewCSS: MonthlySummaryPopUpViewCSS? = {
        MonthlySummaryAlertCSS()
    }()
    
    public var rtpBigWinWidgetCSS: RtpBigWinWidgetCSS? = {
        RtpBigWinWidgetAlertCSS()
    }()
    
    public var germanRegulatoryAlertCSS: RegulatoryAlertCSS? = {
        DefaultRegulatoryAlertCSS()
    }()
    
    public var gameplayTimerAlertCSS: GamePlayCoolOffTimerAlertCSS? = {
        DefaultGamePlayCoolOffTimerAlertCSS()
    }()
    
    public var rcpSessionCoolOffAlertCSS: SessionCoolOffAlertCSS? = {
        DefaultSessionCoolOffAlertCSS()
    }()
    
    public var germanSessionCoolOffTimerAlertCSS: GermanSessionCoolOffTimerAlertCSS? = {
        DefaultSessionCoolOffTimerAlertCSS()
    }()
    
    public var germanResponsibleGamingCSS: GermanResponsibleGamingCSS? = {
        GermanResponsibleGamingAlertCSS()
    }()

    public init() { }
}


public struct DefaultGameExclusionViewCSS: GameExclusionViewCSS {
    
    public var title: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWSelfExclusionView, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWSelfExclusionView, propertyName: "titleFont"))
    }()
    
    public var hyperLinkCSS: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWSelfExclusionView, propertyName: "linkColor"), font: UIFont.BWSFont(className: BWSelfExclusionView, propertyName: "linkFont"))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWSelfExclusionView, propertyName: "backgroundColor")
    }()
}


struct MonthlySummaryAlertCSS: MonthlySummaryPopUpViewCSS {
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyMonthlySummaryPopUpView, propertyName: "backgroundColor")
    }()
    
    var containerBG: UIColor? = {
        UIColor.BWSColor(className: BWLobbyMonthlySummaryPopUpView, propertyName: "containerBG")
    }()
    
    var title: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyMonthlySummaryPopUpView, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWLobbyMonthlySummaryPopUpView, propertyName: "titleFont"))
        
    }()
    
    var body: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyMonthlySummaryPopUpView, propertyName: "bodyColor"), font: UIFont.BWSFont(className: BWLobbyMonthlySummaryPopUpView, propertyName: "bodyFont"))
    }()
   
    var okButton: ButtonCSS? = {
        
        let textCSS = DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyMonthlySummaryPopUpView, propertyName: "okButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyMonthlySummaryPopUpView, propertyName: "okButtonTitleFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyMonthlySummaryPopUpView, propertyName: "okButtonBG"), normal:  UIColor.BWSColor(className: BWLobbyMonthlySummaryPopUpView, propertyName: "okButtonBG"))
        
    }()
}


struct RtpBigWinWidgetAlertCSS: RtpBigWinWidgetCSS {
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyRtpBigWinWidgetView, propertyName: "backgroundColor")
    }()
   
    var title: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyRtpBigWinWidgetView, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWLobbyRtpBigWinWidgetView, propertyName: "titleFont"))
        
    }()
    
    var link: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyRtpBigWinWidgetView, propertyName: "linkColor"), font: UIFont.BWSFont(className: BWLobbyRtpBigWinWidgetView, propertyName: "linkFont"))
    }()
    
    var body: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyRtpBigWinWidgetView, propertyName: "bodyColor"), font: UIFont.BWSFont(className: BWLobbyRtpBigWinWidgetView, propertyName: "bodyFont"))
    }()
   
    var continueButton: ButtonCSS? = {
        
        let textCSS = DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyRtpBigWinWidgetView, propertyName: "continueButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyRtpBigWinWidgetView, propertyName: "continueButtonTitleFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyRtpBigWinWidgetView, propertyName: "continueButtonBG"), normal:  UIColor.BWSColor(className: BWLobbyRtpBigWinWidgetView, propertyName: "continueButtonBG"))
        
    }()
}


public struct DefaultRegulatoryAlertCSS: RegulatoryAlertCSS {
    
    public var backgroundColor: UIColor?
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryBanerAlertTitleColor"), font: UIFont.BWSFont(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryAlert16PixBoldTitleFont"))
    }()
    
    public var body: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryAlertDescriptionColor"), font: UIFont.BWSFont(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryAlertDescriptionFont"))
    }()
    
    public var btn: ButtonCSS? = {
        let titleColor = UIColor.BWSColor(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryAlertBtnTextColor")
        let bgColor = UIColor.BWSColor(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryAlertBtnBgColor")
        let font = UIFont.BWSFont(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryAlert14PixBoldTextFont")
        let textCSS = DefaultTextCSS(color: titleColor, font: font)
        return DefaultButtonCSS(title: textCSS, selected: .clear, normal: bgColor)
    }()
}


public struct DefaultGamePlayCoolOffTimerAlertCSS:  GamePlayCoolOffTimerAlertCSS{
    
    public var bannerTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryBanerAlertTitleColor"), font: UIFont.BWSFont(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryAlert16PixBoldTitleFont"))
    }()
    
    public var bannerBody: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryBanerAlertDescriptionColor"), font: UIFont.BWSFont(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryAlertDescriptionFont"))
    }()
    
    public var bannerBtn: ButtonCSS? = {
        let titleColor = UIColor.BWSColor(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryBanerAlertBtnTextColor")
        let bgColor = UIColor.clear
        let font = UIFont.BWSFont(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryAlert12PixBoldTextFont")
        let textCSS = DefaultTextCSS(color: titleColor, font: font)
        return DefaultButtonCSS(title: textCSS, selected: .clear, normal: bgColor)
    }()
    
    public var progressTimerText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryBanerAlertProgressTextColor"), font: UIFont.BWSFont(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryAlert12PixBoldTextFont"))
    }()
    
    public var progressTimerTextBGViewColor: UIColor? = {
        UIColor.BWSColor(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryBanerAlertProgressBgColor")
    }()
    
    public var pragrassBarColor: UIColor? = {
        UIColor.BWSColor(className: RegulatoryAlertCSSStyle, propertyName: "regulatoryBanerAlertProgressColor")
    }()
}


public struct DefaultSessionCoolOffAlertCSS: SessionCoolOffAlertCSS {
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWSessionCoolOffAlertView, propertyName: "descriptionLabelColor"), font: UIFont.BWSFont(className: BWSessionCoolOffAlertView, propertyName: "descriptionLabelFont"))
    }()
    
    public var okBtn: ButtonCSS? = {
        let titleColor = UIColor.BWSColor(className: BWSessionCoolOffAlertView, propertyName: "okButtonTitleColor")
        let bgColor = UIColor.BWSColor(className: BWSessionCoolOffAlertView, propertyName: "okBackgroundColor")
        let font = UIFont.BWSFont(className: BWSessionCoolOffAlertView, propertyName: "okButtonTitleFont")
        let textCSS = DefaultTextCSS(color: titleColor, font: font)
        return DefaultButtonCSS(title: textCSS, selected: .clear, normal: bgColor)
    }()
    
    public var leaveBtn: ButtonCSS? = {
        let titleColor = UIColor.BWSColor(className: BWSessionCoolOffAlertView, propertyName: "leaveButtonTitleColor")
        let bgColor = UIColor.BWSColor(className: BWSessionCoolOffAlertView, propertyName: "leaveBackgroundColor")
        let font = UIFont.BWSFont(className: BWSessionCoolOffAlertView, propertyName: "leaveButtonTitleFont")
        let textCSS = DefaultTextCSS(color: titleColor, font: font)
        return DefaultButtonCSS(title: textCSS, selected: .clear, normal: bgColor)
    }()
    
    public var containerBgColor: UIColor? = {
        UIColor.BWSColor(className: BWSessionCoolOffAlertView, propertyName: "backgroundColor")
    }()
    
    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWSessionCoolOffAlertView, propertyName: "containerViewCornerRadius")
    }()
    
    public var leaveButtonBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWSessionCoolOffAlertView, propertyName: "leaveButtonBorderColor")
    }()
}


public struct DefaultSessionCoolOffTimerAlertCSS:  GermanSessionCoolOffTimerAlertCSS {
    
    public var bannerTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWSessionCoolOffTimerView, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWSessionCoolOffTimerView, propertyName: "titleFont"))
    }()
    
    public var bannerBody: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWSessionCoolOffTimerView, propertyName: "descriptionLabelColor"), font: UIFont.BWSFont(className: BWSessionCoolOffTimerView, propertyName: "descriptionLabelFont"))
    }()
    
    public var bannerBtn: ButtonCSS? = {
        let titleColor = UIColor.BWSColor(className: BWSessionCoolOffTimerView, propertyName: "leaveButtonTitleColor")
        let bgColor = UIColor.BWSColor(className: BWSessionCoolOffAlertView, propertyName: "leaveButtonBackgroundColor")
        let font = UIFont.BWSFont(className: BWSessionCoolOffTimerView, propertyName: "leaveButtonTitleFont")
        let textCSS = DefaultTextCSS(color: titleColor, font: font)
        return DefaultButtonCSS(title: textCSS, selected: .clear, normal: bgColor)
    }()
    
    public var progressTimerText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWSessionCoolOffTimerView, propertyName: "progressTimerTextColor"), font: UIFont.BWSFont(className: BWSessionCoolOffTimerView, propertyName: "progressTimerTextFont"))
    }()
    
    public var progressTimerTextBgViewColor: UIColor? = {
        UIColor.BWSColor(className: BWSessionCoolOffTimerView, propertyName: "progressTimerBackgroundColor")
    }()
    
    public var progressBarColor: UIColor? = {
        UIColor.BWSColor(className: BWSessionCoolOffTimerView, propertyName: "progressBarColor")
    }()
    
    public var progressBarTrackColor: UIColor? = {
        UIColor.BWSColor(className: BWSessionCoolOffTimerView, propertyName: "progressBarTrackColor")
    }()
}


public struct GermanResponsibleGamingAlertCSS: GermanResponsibleGamingCSS {
   
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWResponsibleGamingPopUpView, propertyName: "backgroundColor")
    }()
    
    public var containerBG: UIColor? = {
        UIColor.BWSColor(className: BWResponsibleGamingPopUpView, propertyName: "containerBG")
    }()
    
    public var title: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWResponsibleGamingPopUpView, propertyName: "titleColor"), font: UIFont.BWSFont(className: BWResponsibleGamingPopUpView, propertyName: "titleFont"))
        
    }()
    
    public var body: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSColor(className: BWResponsibleGamingPopUpView, propertyName: "bodyColor"), font: UIFont.BWSFont(className: BWResponsibleGamingPopUpView, propertyName: "bodyFont"))
    }()
   
    public var continueButton: ButtonCSS? = {
        
        let textCSS = DefaultTextCSS(color: UIColor.BWSColor(className: BWResponsibleGamingPopUpView, propertyName: "continueButtonTitleColor"), font: UIFont.BWSFont(className: BWResponsibleGamingPopUpView, propertyName: "continueButtonTitleFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWResponsibleGamingPopUpView, propertyName: "continueButtonBG"), normal:  UIColor.BWSColor(className: BWResponsibleGamingPopUpView, propertyName: "continueButtonBG"))
        
    }()
    
    public var linkColor: UIColor? = {
        UIColor.BWSColor(className: BWResponsibleGamingPopUpView, propertyName: "linkColor")
    }()
}
