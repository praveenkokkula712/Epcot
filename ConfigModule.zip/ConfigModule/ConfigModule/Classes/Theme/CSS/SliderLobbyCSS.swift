//
//  SliderLobbyCSS.swift
//  ConfigModule
//
//  Created by Gostu Bhargavi on 04/03/24.
//

import Foundation
import Utility

public struct SlidersLobbyCSS: SliderLobbyCSS {
    
    public init() {
        
    }
    
    public var rcpViewCSS: RcpUKCSS? = {
        SliderRCPUKAlertCSS()
   }()
    
    public var easyNavigation: EasyNavigationCSS? = {
        SliderEasyNavigationCSS()
   }()
    
    public var sessionSettingViewCSS: SessionSettingCSS? = {
        SessionSettingViewCSS()
   }()
    
    public var sessionSettingsPopupCSS: SessionSettingsPopupCSS? = {
        SessionSettingsPopViewCSS()
    }()

    public var sessionRemainderPopupCSS: SessionRemainderPopupCSS? = {
        SessionReminderPopUpViewCSS()
    }()

    public var quickGamesPopupCSS: QuickGamesPopupCSS? = {
        QuickGamesPopupViewCSS()
    }()
}

public struct SliderRCPUKAlertCSS: RcpUKCSS {
    
    public init() {
        
    }
    
    public var infoIconTintColor: UIColor? = {
        UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "infoIconTintColor")
    }()
    
    public var bodyAttribute: TextCSS? = {
        
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "titleColor"), font: UIFont.BWSSliderFont(className: BWSlidersRCPUStyle, propertyName: "titleFont"))
    }()
    
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "backgroundColor")
    }()
    
    
    public var containerBG: UIColor? = {
        UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "containerColor")
    }()
    
    public var title: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "titleColor"), font: UIFont.BWSSliderFont(className: BWSlidersRCPUStyle, propertyName: "titleFont"))
    }()
    
    public var body: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "descriptionColor"), font: UIFont.BWSSliderFont(className: BWSlidersRCPUStyle, propertyName: "descriptionFont"))
    }()
    
    public var continuebutton: ButtonCSS? = {
        
        let textCSS = DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "continueBtnTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersRCPUStyle, propertyName: "continueBtnTitleFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "continueBtnBGColor"), normal:  UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "continueBtnBGColor"))
    }()
    
    public var border: UIColor? = {
        UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "border")
    }()
    
    public var leave: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "leaveBtnTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersRCPUStyle, propertyName: "leaveBtnTitleFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "leaveBtnBGColor"), normal:  UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "leaveBtnBGColor"))
    }()
    
    public var linkTextColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersRCPUStyle, propertyName: "linkTextColor")
    }()
    
    public var buttonCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersRCPUStyle, propertyName: "buttonCornerRadius")
    }()

}

public struct SliderEasyNavigationCSS: EasyNavigationCSS {
    public var seperatorColor: UIColor?  = {
        return UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "seperatorBGColor")
    }()
    
    
    public var gamePillBGColorSelected: UIColor?  = {
        return UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "gamePillBGColorSelected")
    }()
    
    public var gamePillBGColorUnselected: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "gamePillBGColorUnselected")
    }()
    
    public var gamePillTextColorSelected: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "gamePillTextColorSelected")
    }()
    
    public var gamePillTextColorUnselected: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "gamePillTextColorUnselected")
    }()
    
    public var gamePillTextFont: UIFont? = {
        UIFont.BWSSliderFont(className: BWSlidersEasyNavigation, propertyName: "gamePillTextFont")
    }()
    
    public var buttonCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersEasyNavigation, propertyName: "buttonCornerRadius")
    }()
    
    public var buttonTitleColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "buttonTitleColor")
    }()
    
    public var buttonTitleFont: UIFont? = {
        UIFont.BWSSliderFont(className: BWSlidersEasyNavigation, propertyName: "buttonTitleFont")
    }()
    
    public var borderColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "borderColor")
    }()
    
    public var borderWidth: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersEasyNavigation, propertyName: "borderWidth")
    }()
    
    public var sessionTimerCSS: SessionTimerCSS? = {
      return SliderLobbyEzSessionTimerCSS()
    }()
    
    public var sessionWinLossCSS: SessionWinLossCSS? = {
       return SliderLobbyEzSessionWinLossCSS()
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "backgroundColor")
    }()
    
    public var subBrandColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "subBrandColor")
    }()
    
}

public struct SliderLobbyEzSessionTimerCSS: SessionTimerCSS {
    
    public var gamePlayDuration: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "gamePlayDurationTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersEasyNavigation, propertyName: "gamePlayDurationTitlefont"))
    }()
    
    public var currentTime: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "currentTimeTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersEasyNavigation, propertyName: "currentTimeTitleFont"))
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "timerBGColor")
    }()
    
}

public struct SliderLobbyEzSessionWinLossCSS: SessionWinLossCSS {
    
    public var session: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "sessionTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersEasyNavigation, propertyName: "sessionTitleFont"))
    }()
    
    public var amount: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "winLossTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersEasyNavigation, propertyName: "winLossTitleFont"))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSSliderColor(className: BWSlidersEasyNavigation, propertyName: "winLossBGColor")
    }()
}

struct SessionSettingViewCSS: SessionSettingCSS {
    
    var headerBgColor: UIColor? = {
        UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "headerViewBGColor")
    }()
    
    var headerIconInfoColor: UIColor? = {
        UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "headerIconTintColor")
    }()
    
    var header: TextCSS?  = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "headerTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "headerTitleFont"))
    }()
    
    var rgButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "rgBtnTextColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "rgBtnTextFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "rgBtnBGColor"), normal:  UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "rgBtnBGColor"))
    }()
    
    var playNowButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "playNowBtnTextColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "playNowBtnTextFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "playNowBtnBGColor"), normal:  UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "playNowBtnBGColor"))
    }()
    
    var buttonsCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionSettingCSS, propertyName: "buttonCornerRadius")
    }()
    
    var rgButtonBorderColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "rgBtnBorderColor")
    }()
    
    var rgButtonTintColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "rgBtnIconTintColor")
    }()
    
    var rgButtonBorderWidth: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionSettingCSS, propertyName: "rgBtnBorderWidth")
    }()
    
    var viewBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "containerBGColor")
    }()
    
    var question: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "limitsQuestionColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "limitsQuestionFont"))
    }()
    
    var infoIconTintColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "iconTintColor")
    }()
    
    var subviewBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "subViewBGColor")
    }()
    
    var subviewCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionSettingCSS, propertyName: "subViewCornerRadius")
    }()
    
    var subviewBorderWidth: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionSettingCSS, propertyName: "subViewBorderWidth")
    }()
    
    var subviewErrorColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "errorColor")
    }()
    
    var subviewErrorTextColor: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "errorColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "errorTextFont"))
    }()
    
    
    var subViewHeaderTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "maxSessionHeaderTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "maxSessionHeaderTitleFont"))
    }()
    
    var subViewSectionCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionSettingCSS, propertyName: "sectionCornerRadius")
    }()
    
    var subviewSectionBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "sectionBGColor")
    }()
    
    var subViewSectionBorderColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "sectionBorderColor")
    }()
    
    var accountBalanceCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionSettingCSS, propertyName: "balanceCornerRadius")
    }()
    
    var accountBalanceBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "balanceBGColor")
    }()
    
    var accountBalanceHeaderTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "balnceHeaderColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "balanceHeaderFont"))
    }()
    
    var accountBalanceValueTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "balanceValueColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "balanceValueFont"))
    }()
    
    var bonusSpinsTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "bonusFreeSpinsTextColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "bonusFreeSpinsTextFont"))
    }()
    
    var subViewValueCellCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionSettingCSS, propertyName: "cellCornerRadius")
    }()
    
    var subViewValueCellSelectedColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "cellSelectedColor")
    }()
    
    var subViewValueCellUnSelectedColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "cellUnselectedColor")
    }()
    
    var cellTextSelectedColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "cellTextSelectedColor")
    }()
    
    var maxLossCellTextCSS: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "cellTextColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "maxLossCellTextFont"))
    }()
    
    var maxTimeCellTextCSS: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "cellTextColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "maxTimeCellTextFont"))
    }()
    
    var maxLossCellSeperationColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "maxLossValueSeperationLineColor")
    }()
    
    var maxLossCellSeperationLineHeight: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionSettingCSS, propertyName: "maxLossValueSeperationLineHeight")
    }()
    
    var sessionBreakCellSelectedColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "sessionBreakHeaderSelectedColor")
    }()
    
    var sessionBreakHeaderCellTextCSS: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "sessionBreakHeaderUnselectedColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "sessionBreakHeaderFont"))
    }()
    
    var breakTimeHeaderTextCSS: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "breakTimeHeaderColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "breakTimeHeaderFont"))
    }()
    
    var breakTimeDescriptionTextCSS: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "breakTimeDescriptionColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingCSS, propertyName: "breakTimeDescriptionFont"))
    }()
    
    var switchSelectedColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "switchSelectedColor")
    }()
    
    var switchUnSelectedColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "switchUnselectedColor")
    }()
    
    var backgroundColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingCSS, propertyName: "containerBGColor")
    }()
    
}

struct SessionSettingsPopViewCSS: SessionSettingsPopupCSS {
    var containerViewBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "containerBGColor")
    }()
    
    var containerCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionSettingsPopupCSS, propertyName: "cornerRadius")
    }()
    
    var headerTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "headerTextColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingsPopupCSS, propertyName: "headerTextFont"))
    }()
    
    var description: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "descriptionColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingsPopupCSS, propertyName: "descriptionFont"))
    }()
    
    var okButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "okayBtnTextColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingsPopupCSS, propertyName: "okayBtnTextFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "okayBtnBGColor"), normal:  UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "okayBtnBGColor"))
    }()
    
    var okButtonCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionSettingCSS, propertyName: "buttonCornerRadius")
    }()
    
    var iconTintColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "iconTintColor")
    }()
    
    var subViewBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "subViewBGColor")
    }()
    
    var subCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionSettingCSS, propertyName: "subViewCornerRadius")
    }()
    
    var subViewHeaderTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "subViewHeaderTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingsPopupCSS, propertyName: "subViewHeaderTitleFont"))
    }()
    
    var subViewDescriptionTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "subViewDescriptionColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionSettingsPopupCSS, propertyName: "subViewDescriptionFont"))
    }()
    
    var subViewIconTintColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "subViewIconTintColor")
    }()
    
    var subViewIconBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "subViewIconBGColor")
    }()
    
    var backgroundColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionSettingsPopupCSS, propertyName: "backgroundColor")
    }()
    
}

struct SessionReminderPopUpViewCSS: SessionRemainderPopupCSS {
    
    var containerViewBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "containerBGColor")
    }()
    
    var containerCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "cornerRadius")
    }()
    
    var headerViewBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "headerBGColor")
    }()
    
    var headerTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "titleTextColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "titleTextFont"))
    }()
    
    var description: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "descriptionColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "descriptionFont"))
    }()
    
    var linkTextColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "linkTextColor")
    }()
    
    var closeIconTintColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "crossIconTintColor")
    }()
    
    var okButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "okayBtnTextColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "okayBtnTextFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "okayBtnBGColor"), normal:  UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "okayBtnBGColor"))
    }()
    
    var cancelButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "cancelBtnTextColor"), font: UIFont.BWSSliderFont(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "cancelBtnTextFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "cancelBtnBGColor"), normal:  UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "cancelBtnBGColor"))
    }()
    
    var cancelButtonBorderColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "cancelBtnBorderColor")
    }()
    
    
    var cancelButtonBorderWidth: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "cancelBtnBorderWidth")
    }()
    
    var buttonCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "buttonCornerRadius")
    }()
    
    var backgroundColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersSessionRemaindersPopupCSS, propertyName: "backgroundColor")
    }()
}

struct QuickGamesPopupViewCSS: QuickGamesPopupCSS {
    var containerViewBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "containerBGColor")
    }()
    
    var containerCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersQuickGamesPopupCSS, propertyName: "containerCornerRadius")
    }()
    
    var headerBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "headerBGColor")
    }()
    
    var headerTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "headerTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersQuickGamesPopupCSS, propertyName: "headerTitleFont"))
    }()
    
    var closeButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "closeButtonTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersQuickGamesPopupCSS, propertyName: "closeButtonTitleFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "closeButtonBGColor"), normal:  UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "closeButtonBGColor"))
    }()
    
    var closeButtonCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersQuickGamesPopupCSS, propertyName: "closeButtonCornerRadius")
    }()
    
    var description: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "descriptionTextColor"), font: UIFont.BWSSliderFont(className: BWSlidersQuickGamesPopupCSS, propertyName: "descriptionTextFont"))
    }()
    
    var buttonCornerRadius: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersQuickGamesPopupCSS, propertyName: "buttonConerRadius")
    }()
    
    var buttonBorderColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "buttonBorderColor")
    }()
    
    var buttonBorderWidth: CGFloat? = {
        CGFloat.BWSSliderFloat(className: BWSlidersQuickGamesPopupCSS, propertyName: "buttonBorderWidth")
    }()
    
    var iconTintColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "iconTintColor")
    }()
    
    var iconBGColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "iconBGColor")
    }()
    
    var gameTypeTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "gameTypeLabelColor"), font: UIFont.BWSSliderFont(className: BWSlidersQuickGamesPopupCSS, propertyName: "gameTypeLabelFont"))
    }()
    
    var addQuickGamesButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "addQuickGamesButtonTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersQuickGamesPopupCSS, propertyName: "addQuickGamesButtonTitleFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "addQuickGamesButtonBGColor1"), normal:  UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "addQuickGamesButtonBGColor1"))
    }()
    
    var addQuickGamesButtonBGColor1: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "addQuickGamesButtonBGColor1")
    }()
    
    var addQuickGamesButtonBGColor2: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "addQuickGamesButtonBGColor2")
    }()
    
    var mayBeLaterButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "mayBeLaterButtonTitleColor"), font: UIFont.BWSSliderFont(className: BWSlidersQuickGamesPopupCSS, propertyName: "mayBeLaterButtonTitleFont"))
        
         return DefaultButtonCSS(title: textCSS, selected: UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "mayBeLaterButtonBGColor"), normal:  UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "mayBeLaterButtonBGColor"))
    }()
    
    var backgroundColor: UIColor? = {
        return UIColor.BWSSliderColor(className: BWSlidersQuickGamesPopupCSS, propertyName: "backgroundColor")
    }()
}
