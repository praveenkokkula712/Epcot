//
//  SeeMoreViewCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

public struct ImmersiveSeeMoreSectionViewCss: SeeMoreSectionViewCss {
    
    public var backButtontint: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "seeMoreSectionBackButtonTintColor")
    }()
    
    public var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "seeMoreSectionTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "seeMoreSectionTitleFont"))
    }()
    
    public var switcherSelectedColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "seeMoreSectionSwitcherTintColor")
    }()
    
    public var switcherUnselectedColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "seeMoreSectionSwitcherDisabledColor")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "seeMoreSectionBackgroundColor")
    }()
    
    public var collectionViewBGColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "seeMoreSectionCollectionViewBackgroundColor")
    }()
    
    public var shadowColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "seeMoreSectionShadowColor")
    }()
    
    public var titleViewBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "seeMoreSectionTitleViewBackgroundColor")
    }()
    
    public var headerTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "seeMoreHeaderTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "seeMoreHeaderTitleFont"))
    }()

    public var headerPrice: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "seeMoreHeaderPriceColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "seeMoreHeaderPriceFont"))
    }()
}
