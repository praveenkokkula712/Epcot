//
//  CasinoGridViewCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

var jackpotCSSClassName: String {
    return isEpcotEnabled ? BWEpcotFeature : BWLobbyGridCSSStyle
}

public struct CasinoLobbyGridViewCSS: LobbyGridView {
    
    public var header: GridHeader? = {
         CasinoGridHeader()
    }()
    
    public var categoryView: CategoryView? = {
        CasinoCategoryView()
    }()
    
    public var jpView: JPView? = {
        CasinoJPView()
    }()
    
    public var myGames: MyGamesView? = {
        CasinoMyGamesView()
    }()
    
    public var backgroundColor: UIColor? = {
        return  UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "viewbackgroundColor")
    }()
    
    public var categoryViewbackgroundColor: UIColor? = {
        return  UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "categoryViewbackgroundColor")
    }()
    
    public var gridViewbackgroundColor: UIColor? = {
        return  UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "gridViewbackgroundColor")
    }()
    
    public var searchBanner: GridSearchBanner? = {
        return CasinoGridSearchBanner()
    }()
}


public struct CasinoGridHeader: GridHeader {
    
    public var title: TextCSS? = {
        let font = UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "titleFont")
        let tittleColor = UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "titleColor")
       return CasinoTextCss(color: tittleColor, font: font)
        
    }()
    
    public var readyToPlay: TextCSS? = {
        let readyToPlayFont = UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "readyToPlayFont")
        let readyToPlayColor = UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "titleColor")
        return CasinoTextCss(color: readyToPlayColor, font: readyToPlayFont)
    }()
  
    public var myGames: ButtonCSS? = {
        let myGamesFont = UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "readyToPlayFont")
        let myGamesColour = UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "myGamesButtonTitleColor")
        let textCSS = CasinoTextCss(color: myGamesColour, font: myGamesFont)
        return CasinoButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "exploreGamesColor"), normal: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "myGamesBGColor"))
        
    }()
    
    public var searchIconColor: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "titleColor")
    }()
    
    public var backgroundColor: UIColor? = {
        return  UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "viewbackgroundColor")
    }()
    
    public var mygamesBorderColor: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "mygamesBorderColor")
    }()
}


public struct CasinoCategoryView: CategoryView {
    
    public var selected: TextCSS? = {
        return CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "myGameColor"), font: UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "selectedFont"))
    }()
    
    public var normal: TextCSS? = {
        return CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "normalColor"), font: UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "categoryNormalFont"))
    }()

    public var titleNormalColor: UIColor? = {
        return  UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "titleNormalColor")
    }()
    
    public var separatorLineColor: UIColor? = {
        return  UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "separatorLineColor")
    }()
    
    public var backgroundColor: UIColor? = {
        return  UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "viewbackgroundColor")
    }()
}


public struct CasinoJPView: JPView {
    
    public var priceAmount: TextCSS? = {
        return CasinoTextCss(color: UIColor.BWSColor(className: jackpotCSSClassName, propertyName: "priceAmountColor"), font: UIFont.BWSFont(className: jackpotCSSClassName, propertyName: "priceAmountFont"))
    }()
    
    public var listPriceAmount: UIFont? = {
        return UIFont.BWSFont(className: jackpotCSSClassName, propertyName: "listPriceAmountFont")
    }()
    
    public var jpBGColor: UIColor? = {
        return  UIColor.BWSColor(className: jackpotCSSClassName, propertyName: "jpBGColor")
    }()
}


public struct CasinoMyGamesView: MyGamesView {
    
    public var mygames: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "closeButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "selectedFont"))
    }()
     
    public var close: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "closeButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "readyToPlayFont"))
    }()
    
    public var pullView: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "pullViewColor")
    }()
    
    public var noGames: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "noGameColor"), font: UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "readyToPlayFont"))
    }()
    
    public var exploreGames: ButtonCSS? = { //exploreGamesFont
        let textCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "viewbackgroundColor"), font: UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "exploreGamesFont"))
        return CasinoButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "exploreGamesColor"), normal: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "myGameColor"))
    }()
    
    public var pickGames: TextCSS? = {
        return CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "noGameColor"), font: UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "readyToPlayFont"))
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "titleColor")
    }()
    
    public var containerViewColor: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "containerViewColor")
    }()
}


public struct CasinoGridSearchBanner: GridSearchBanner {
    
    public var findText: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "searchTileTitleColor"), font: UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "exploreGamesFont"))
    }()
    
    public var noSuccess: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "searchTileTitleColor"), font: UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "readyToPlayFont"))
    }()
    
    public var searchNow: ButtonCSS? = {
        let textCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "searchNowTitleColor"), font: UIFont.BWSFont(className: BWLobbyGridCSSStyle, propertyName: "exploreGamesFont"))
        return CasinoButtonCSS(title: textCSS, selected: UIColor.clear, normal: UIColor.clear)
    }()
    
    public var searchBorder: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "searchNowTitleColor")
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWLobbyGridCSSStyle, propertyName: "searchTileBackgroundColor")
    }()
}
