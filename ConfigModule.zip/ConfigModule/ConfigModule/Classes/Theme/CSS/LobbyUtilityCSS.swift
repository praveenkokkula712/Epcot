//
//  LobbyUtilityCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 14/07/23.
//

import Foundation
import Utility

struct LobbyBingoButtonCSS: BingoButtonCSS {
    
    var titleCss: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "bingoButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "bingoButtonTitleFont"))
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "bingoButtonBackgroundColor")
    }()

    var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "bingoButtonCornerRadius")
    }()
}


struct CasinoFavoriteToasterViewCSS: FavoriteToasterViewCSS  {
   
    var shadowColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "favoriteToasterViewShdowColor")
    }()
    
    var backgroundColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "favoriteToasterViewBackgroundColor")
    }()
    
    public var viewCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWLobbyCSSStyle, propertyName: "favoriteToasterViewCornerRadius")
    }()
    
    var title: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "favoriteToasterViewTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "favoriteToasterViewTitleFont"))
    }()
    
    var titleAttributed: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "favoriteToasterViewTitleAttributedColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "favoriteToasterViewTitleAttributedFont"))
    }()
    
    var seeBtn: ButtonCSS? = {
        let textCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "favoriteToasterViewSeeButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "favoriteToasterViewSeeButtonTitleFont"))
        
         return CasinoButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "favoriteToasterViewSeeBtnSelectedColor"), normal: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "favoriteToasterViewSeeBtnNormalColor"))
    }()
}


struct DefaultToasterViewCss: ToastersViewCSS {
   
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWToastersCSS,
                                               propertyName: "titleColor"), font: UIFont.BWSFont(className: BWToastersCSS, propertyName: "titleFont"))
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWToastersCSS,
                                                propertyName: "descTextColor"), font: UIFont.BWSFont(className: BWToastersCSS, propertyName: "descFont"))
    }()
        
    public var ctaButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.BWSColor(className: BWToastersCSS,
                                                                   propertyName: "ctaBtnTitleColor"), font: UIFont.BWSFont(className: BWToastersCSS, propertyName: "ctaButtonFont")),
                         selected: UIColor.BWSColor(className: BWToastersCSS,
                                                    propertyName: "ctaBtnTitleColor"),
                         normal: UIColor.BWSColor(className: BWToastersCSS,
                                                  propertyName: "ctaBtnTitleColor"))
    }()
    
    public var containerBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWToastersCSS, propertyName: "popupBgColor")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWToastersCSS, propertyName: "popupBgColor")
    }()
    
    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWToastersCSS, propertyName: "cornerRadius")
    }()
    
    public var borderColor: UIColor? = {
        UIColor.BWSColor(className: BWToastersCSS, propertyName: "containerBorderColor")
    }()

    public var borderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWToastersCSS, propertyName: "containerBorderWidth")
    }()
    
    public var titleBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWToastersCSS, propertyName: "titleBgColor")
    }()
    
    public var descriptionBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWToastersCSS, propertyName: "descriptionBgColor")
    }()

    public var imageCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWToastersCSS, propertyName: "imageCornerRadius")
    }()
    
    public var imageShadowRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWToastersCSS, propertyName: "imageShadowRadius")
    }()
    
    public var imageShadowColor: UIColor? = {
        UIColor.BWSColor(className: BWToastersCSS, propertyName: "imageShadowColor")
    }()
    
    public var ctaButtonBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWToastersCSS, propertyName: "toasterctaButtonBorderColor")
    }()
    
    public var ctaButtonBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWToastersCSS, propertyName: "toasterctaButtonBgColor")
    }()
    
    public var ctaButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWToastersCSS, propertyName: "ctaCornerRadius")
    }()
    
    public var containerShadowColor: UIColor? = {
        //Drop Shadow
        UIColor.BWSColor(className: BWToastersCSS, propertyName: "containerShadowColor")
    }()
    
    public var containerShadowRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWToastersCSS, propertyName: "containerShadowRadius")
    }()
}


struct DefaultOverlaysViewCss: OverlaysViewCSS {
    var cancelButtonBorderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWOverlaysCSS, propertyName: "cancelBtnBorderWidth")
    }()
    
    var cancelButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOverlaysCSS, propertyName: "cancelBtnCornerRadius")
    }()
    
    var cancelButtonBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWOverlaysCSS, propertyName: "cancelBorderColor")
    }()
    
    var cancelButton: Utility.ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.BWSColor(className: BWOverlaysCSS,
                                                                   propertyName: "cancelBtnTitleColor"), font: UIFont.BWSFont(className: BWOverlaysCSS, propertyName: "cancelButtonFont")),
                         selected: UIColor.BWSColor(className: BWOverlaysCSS,
                                                    propertyName: "cancelBtnSelectedColor"),
                         normal: UIColor.BWSColor(className: BWOverlaysCSS,
                                                  propertyName: "cancelBtnNormalColor"))
    }()
   
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOverlaysCSS,
                                               propertyName: "titleColor"), font: UIFont.BWSFont(className: BWOverlaysCSS, propertyName: "titleFont"))
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOverlaysCSS,
                                                propertyName: "descTextColor"), font: UIFont.BWSFont(className: BWOverlaysCSS, propertyName: "descFont"))
    }()
        
    public var ctaButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.BWSColor(className: BWOverlaysCSS,
                                                                   propertyName: "ctaBtnTitleColor"), font: UIFont.BWSFont(className: BWOverlaysCSS, propertyName: "ctaButtonFont")),
                         selected: UIColor.BWSColor(className: BWOverlaysCSS,
                                                    propertyName: "ctaBtnTitleColor"),
                         normal: UIColor.BWSColor(className: BWOverlaysCSS,
                                                  propertyName: "ctaBtnTitleColor"))
    }()
    
    public var containerBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWOverlaysCSS, propertyName: "popupBgColor")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWOverlaysCSS, propertyName: "popupBgColor")
    }()
    
    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOverlaysCSS, propertyName: "cornerRadius")
    }()
    
    public var borderColor: UIColor? = {
        UIColor.BWSColor(className: BWOverlaysCSS, propertyName: "containerBorderColor")
    }()

    public var borderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWOverlaysCSS, propertyName: "containerBorderWidth")
    }()
    
    public var titleBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWOverlaysCSS, propertyName: "titleBgColor")
    }()
    
    public var descriptionBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWOverlaysCSS, propertyName: "descriptionBgColor")
    }()

    public var imageCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOverlaysCSS, propertyName: "imageCornerRadius")
    }()
    
    public var imageShadowRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOverlaysCSS, propertyName: "imageShadowRadius")
    }()
    
    public var imageShadowColor: UIColor? = {
        UIColor.BWSColor(className: BWOverlaysCSS, propertyName: "imageShadowColor")
    }()
    
    public var ctaButtonBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWOverlaysCSS, propertyName: "overlatCTAButtonBorderColor")
    }()
    
    public var ctaButtonBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWOverlaysCSS, propertyName: "toasterctaButtonBgColor")
    }()
    
    public var ctaButtonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOverlaysCSS, propertyName: "ctaCornerRadius")
    }()
    
    public var containerShadowColor: UIColor? = {
        //Drop Shadow
        UIColor.BWSColor(className: BWOverlaysCSS, propertyName: "containerShadowColor")
    }()
    
    public var containerShadowRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOverlaysCSS, propertyName: "containerShadowRadius")
    }()
    
    public var overlayBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWOverlaysCSS, propertyName: "overlayBgColor")
    }()
}


public struct CasinoStickerCSS: StickerCSS {
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWStickerCSS,
                                               propertyName: "stickerTitleColor"), font: UIFont.BWSFont(className: BWStickerCSS, propertyName: "stickerTitleFont"))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWStickerCSS, propertyName: "stickerViewBgColor")
    }()
    
    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWStickerCSS, propertyName: "stickerViewCornerRadius")
    }()
}


struct CasinoLobbyUtilView: LobbyUtilCSS {
    
    var exploreButton: ButtonCSS = {
        let textCSS = CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyExploreButtonTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyExploreButtonTitleFont"))
        return CasinoButtonCSS(title: textCSS, selected: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyExploreButtonBGColor"), normal: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyExploreButtonBGColor"))
    }()
    
    var moreGamesTitle: TextCSS? = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyExploreViewMoreTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyExploreViewMoreTitleFont"))
    }()
    
    var backgroundColor: UIColor? = {
         UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyExploreViewContentBGColor")
    }()

    var moreGamesTitleCSS: TextCSS? = {
         CasinoTextCss(color: UIColor.BWSColor(className: BWLobbyCSSStyle, propertyName: "lobbyExploreViewMoreTitleColor"), font: UIFont.BWSFont(className: BWLobbyCSSStyle, propertyName: "lobbyExploreViewMoreTitleFont"))
    }()
}
