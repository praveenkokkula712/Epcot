//
//  BingoWidgetViewCSS.swift
//  ConfigModule
//
//  Created by Bandaru Priyanka on 04/01/24.
//

import Foundation
import Utility

struct BingoWidgetView: BingoWidgetCSS {
    
    var widgetHeaderTextCss: TextCSS = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "widgetHeaderTitleColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "widgetHeaderTitlefont")
        )
    }()
    
    var widgetHeaderSeeAllCss: TextCSS = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "widgetHeaderSeeAllTextColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "widgetHeaderSeeAllTextFont")
        )
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "backgroundColor")
    }()
    
    var widgetViewcornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "widgetViewcornerRadius")
    }()
    
    var widgetTitleCss: TextCSS = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "widgetTitleColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "widgetTitleFont"))
    }()
    
    var widgetAmountTextCss: TextCSS = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "widgetAmountTitleColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "widgetAmountTitleFont"))
    }()
    
    var jackpotIconColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "jackpotIconColor")
    }()
    
    var widgetProgressBarHeight: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "widgetProgressBarHeight")
    }()
    
    var widgetProgressBarColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "widgetProgressBarColor")
    }()
    
    var widgetProgressBarTrackColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "widgetProgressBarTrackColor")
    }()
    
    var playTitleColor: TextCSS = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "playTitleColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "playTitleFont"))
    }()
    
    var infoIconColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "infoIconColor")
    }()
    
    var favoriteIconColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "favoriteIconColor")
    }()
    
    var linkIconColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "linkIconColor")
    }()
    
    var ribbonViewBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "ribbonViewBackgroundColor")
    }()
    
    var ribbonTitleCSS: TextCSS = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "ribbonTitleColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "ribbonTitleFont"))
    }()
    
    var dividerColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "dividerColor")
    }()
    
    var progressBarTimerCount: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "progressBarTimerCount")
    }()
    
    var infoTitleCss: TextCSS = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "infoTitleColor"), font: UIFont.BWSFont(className: BWBingoWidgetView, propertyName: "infoTitleFont"))
    }()
    
    var infoDescriptionCss: TextCSS = {
        CasinoTextCss(color: UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "infoDescriptionColor"), font: UIFont.BWSFont(className: BWBingoWidgetView, propertyName: "infoDescriptionFont"))
    }()
    
    var infoFavoriteColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "infoFavoriteColor")
    }()
    
    var infoCloseColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "infoCloseColor")
    }()
    
    public var infoFavoriteIconSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "infoFavoriteIconSize")
    }()
    
    public var infoCloseIconSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "infoCloseIconSize")
    }()
    
    public var infoCardColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "infoBackgroundColor")
    }()
    
    public var infoAnimationDuration: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "infoAnimationDuration")
    }()
    
    public var infoBlurRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "infoBlurRadius")
    }()
    
    var inactiveBingoWidgetRoomColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "inactiveBingoWidgetRoomColor")
    }()
    
    var jackpotIconSize: CGFloat? = {
            CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "jackpotIconSize")
        }()
        
    var detailsIconSize: CGFloat? = {
            CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "detailsIconSize")
        }()
        
    var combinedRoomsText: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "combinedRoomsTextColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "combinedRoomsTextFont")
        )
    }()
    
    var preBuyWidgetCSS: BingoWidgetButtonCSS? = {
        BingoWidgetPreBuyButtonCSS()
    }()
    
    var playWidgetCSS: BingoWidgetButtonCSS? = {
        BingoWidgetPlayButtonCSS()
    }()
    
    var winDetails: BingoIconDetailsCSS? = {
        BingoWinIconDetailsCSS()
    }()
    
    var cardDetails: BingoIconDetailsCSS? = {
        BingoCardIconDetailsCSS()
    }()
    
    var playerDetails: BingoIconDetailsCSS? = {
        BingoPlayerIconDetailsCSS()
    }()
    
    var timerCss: BingoWidgetTimerCSS? = {
        BingoTimerCSS()
    }()
    
    var featureBadgeCss: BingoFeatureBadgesCSS? = {
        BingoWidgetFeatureBadgeCSS()
    }()
}

public struct BingoWidgetPlayButtonCSS: BingoWidgetButtonCSS {
    
    public var textCSS: TextCSS = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "playTitleColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "playTitleFont")
        )
    }()
    
    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "playCornerRadius")
    }()
    
    public var borderColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "playBorderColor")
   }()
    
    public var borderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "playBorderWidth")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "playBackgroundColor")
   }()
    
    public var height:  CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "playHeight")
    }()

    public var highlightTextColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "playHighlightTextColor")
    }()

    public var highlightBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "playHighlightBackgroundColor")
    }()
}


public struct BingoWidgetPreBuyButtonCSS: BingoWidgetButtonCSS {
    
    public var textCSS: TextCSS = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "prebuyTitleColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "prebuyTitleFont"))
    }()
    
    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "prebuyCornerRadius")
    }()
    
    public var borderColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "prebuyBorderColor")
    }()
    
    public var borderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "preBuyBorderWidth")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "prebuyBackgroundColor")
    }()
    
    public var height:  CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "prebuyHeight")
    }()

    public var highlightTextColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "prebuyHighlightTextColor")
    }()

    public var highlightBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "prebuyHighlightBackgroundColor")
    }()
}

public struct BingoTimerCSS: BingoWidgetTimerCSS {
    
    public var thresholdCount: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "timerThresholdCount")
    }()
    
    public var thresholdColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "timerThresholdColor")
    }()
    
    public var timerBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "timerBgColor")
    }()
    
    public var alertTimerBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "updatedTimerBgColor")
    }()
    
    public var timerIconColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "timerIconColor")
    }()
    
    public var updatedTimerIconColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "updatedtimerIconColor")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "timerThresholdBGColor")
    }()
    
    public var timerIconSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "timerIconSize")
    }()
    
    public var textCSS: TextCSS = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "timerTextColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "timerFont")
        )
    }()
    
    public var cornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "timerCornerRadius")
    }()
    
    public var updatedtimerCSS: TextCSS = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "updatedtimerTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "updatedtimerTextFont"
            )
        )
    }()
}

public struct BingoPlayerIconDetailsCSS: BingoIconDetailsCSS {
    public var iconColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "playerIconColor")
    }()
    
    public var iconTextCSS: TextCSS = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "playerTitleColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "playerTitleFont")
        )
    }()
    
    public var combinedRoomsFont: UIFont? = {
        UIFont.BWSFont(className: BWBingoWidgetView, propertyName: "playerTitleFont")
    }()
}

public struct BingoCardIconDetailsCSS: BingoIconDetailsCSS {
    public var iconColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "cardPriceIconColor")
    }()
    
    public var iconTextCSS: TextCSS = {
        CasinoTextCss(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "cardPriceTitleColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "cardPriceTitleFont")
        )
    }()
    
    public var combinedRoomsFont: UIFont? = {
        UIFont.BWSFont(className: BWBingoWidgetView, propertyName: "combinedRoomsCardPriceTitleFont")
    }()
}

public struct BingoWinIconDetailsCSS: BingoIconDetailsCSS {
    public var iconColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "winIconColor")
    }()
    
    public var iconTextCSS: TextCSS = {
        CasinoTextCss(
            color: UIColor.BWSColor(
                className: BWBingoWidgetView, propertyName: "winTitleColor"),
            font: UIFont.BWSFont(
                className: BWBingoWidgetView, propertyName: "winTitleFont")
        )
    }()
    
    public var combinedRoomsFont: UIFont? = {
        UIFont.BWSFont(className: BWBingoWidgetView, propertyName: "combinedRoomsWinTitleFont")
    }()

}
