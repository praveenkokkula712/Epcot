//
//  BingoWidgetFeatureBadgeCSS.swift
//  ConfigModule
//
//  Created by Sindhuja Vedire on 23/02/24.
//

import Foundation
import Utility

public struct BingoWidgetFeatureBadgeCSS: BingoFeatureBadgesCSS {
    
    public var badgeSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "badgeSize")
    }()
    
    public var backgroundBadgeSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "backgroundBadgeSize")
    }()
    
    public var everyOneWinsColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "everyOneWinsBadgeColor")
    }()
    
    public var everyOneWinsBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "everyOneWinsBadgeBackgroundColor")
    }()
    
    public var hotBallColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "hotBallBadgeColor")
    }()
    
    public var hotBallBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "hotBallBadgeBackgroundColor")
    }()
    
    public var rollOnColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "rollOnBadgeColor")
    }()
    
    public var rollOnBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "rollOnBadgeBackgroundColor")
    }()
    
    public var cashOutColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "cashOutBadgeColor")
    }()
    
    public var cashOutBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "cashOutBadgeBackgroundColor")
    }()
    
    public var physicalPrizeColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "physicalPrizeBadgeColor")
    }()
    
    public var physicalPrizeBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "physicalPrizeBadgeBackgroundColor")
    }()
    
    public var multiPriceColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "multiPriceBadgeColor")
    }()
    
    public var multiPriceBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "multiPriceBadgeBackgroundColor")
    }()
    
    public var freeTicketsColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "freeTicketsBadgeColor")
    }()
    
    public var freeTicketsBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "freeTicketsBadgeBackgroundColor")
    }()
    
    public var cashPotColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "cashPotBadgeColor")
    }()
    
    public var cashPotBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "cashPotBadgeBackgroundColor")
    }()
    
    public var timedJackpotColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "timedJackpotBadgeColor")
    }()
    
    public var timedJackpotBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "timedJackpotBadgeBackgroundColor")
    }()
    
    public var dealColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "dealBadgeColor")
    }()
    
    public var dealBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "dealBadgeBackgroundColor")
    }()
    
    public var beatChaserColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "beatChaserBadgeColor")
    }()
    
    public var beatChaserBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "beatChaserbadgeBackgroundColor")
    }()
    
    public var scratchCardColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "scratchCardBadgeColor")
    }()
    
    public var scratchCardBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "scratchCardBadgeBackgroundColor")
    }()
    
    public var sessionBingoColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "sessionBingoBadgeColor")
    }()
    
    public var sessionBingoBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "sessionBingoBadgeBackgroundColor")
    }()
    
    public var superBooksColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "superBooksBadgeColor")
    }()
    
    public var superBooksBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "superBooksBadgeBackgroundColor")
    }()
    
    public var countryMilesColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "countryMilesBadgeColor")
    }()
    
    public var countryMilesBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "countryMilesBadgeBackgroundColor")
    }()
    
    public var countryMiles2Color: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "countryMiles2BadgeColor")
    }()
    
    public var countryMiles2BackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "countryMiles2BadgeBackgroundColor")
    }()
    
    public var sideBetsColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "sideBetsBadgeColor")
    }()
    
    public var sideBetsBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "sideBetsBadgeBackgroundColor")
    }()
    
    public var liveStreamingColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "liveStreamingBadgeColor")
    }()
    
    public var liveStreamingBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "liveStreamingBadgeBackgroundColor")
    }()
    
    public var bonusSpinsColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "bonusSpinsBadgeColor")
    }()
    
    public var bonusSpinsBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "bonusSpinsBadgeBackgroundColor")
    }()
    
    public var bonusCashColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "bonusCashbadgeColor")
    }()
    
    public var bonusCashBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "bonusCashBadgeBackgroundColor")
    }()
    
    public var bonusTicketsColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "bonusTicketsBadgeColor")
    }()
    
    public var bonusTicketsBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "bonusTicketsBadgeBackgroundColor")
    }()
    
    public var slotsRacePodiumColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "slotsRacePodiumBadgeColor")
    }()
    
    public var slotsRacePodiumBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "slotsRacePodiumBackgroundColor")
    }()
    
    public var bingoInsuranceColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "bingoInsuranceBadgeColor")
    }()
    
    public var bingoInsuranceBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "bingoInsuranceBadgeBackgroundColor")
    }()
    
    public var slidingPotColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "slidingPotBadgeColor")
    }()
    
    public var slidingPotBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "slidingPotBadgeBackgroundColor")
    }()
    
    public var jumpingPotColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "jumpingPotBadgeColor")
    }()
    
    public var jumpingPotBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "jumpingPotBackgroundColor")
    }()
    
    public var superLinkColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "superLinkBadgeColor")
    }()
    
    public var superLinkBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "superLinkBadgeBackgroundColor")
    }()
    
    public var extraSpinColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "extraSpinBadgeColor")
    }()
    
    public var extraSpinColor2: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "extraSpinBadgeColor2")
    }()
    
    public var extraSpinBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "extraSpinBadgeBackgroundColor")
    }()
    
    public var whackBingoColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "whackBingoBadgeColor")
    }()
    
    public var whackBingoBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "whackBingoBadgeBackgroundColor")
    }()
    
    public var prizeDropColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "prizeDropBadgeColor")
    }()
    
    public var prizeDropBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "prizeDropBadgeBackgroundColor")
    }()
    
    public var prizeWheelColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "prizeWheelBadgeColor")
    }()
    
    public var prizeWheelBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "prizeWheelBackgroundBadgeColor")
    }()
    
    public var prizeWheelBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "prizeWheelBorderBadgeColor")
    }()
    
    public var prizeWheelBorderThickness: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "prizeWheelBorderThickness")
    }()
    
    public var prizeWheelBorderRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "prizeWheelBorderRadius")
    }()
    
    public var ntgColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "ntgBadgeColor")
    }()
    
    public var ntgBackgroundColor: UIColor? = {
        UIColor.BWSColor(className: BWBingoWidgetView, propertyName: "ntgBadgeBackgroundColor")
    }()
    
    public var ntgTransform: CGFloat? = {
        CGFloat.BWSFloat(className: BWBingoWidgetView, propertyName: "ntgTransform")
    }()
}
