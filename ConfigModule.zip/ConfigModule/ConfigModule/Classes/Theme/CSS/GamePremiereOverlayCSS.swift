//
//  GamePremiereOverlayCSS.swift
//  ConfigModule
//
//  Created by Sindhuja Vedire on 02/05/24.
//

import Foundation
import Utility
import SwiftUI

public struct GamePremiereOverlayCSS: GamePremiereCSS {
    
    public var overlayBackGroundColor: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "overlayBackGroundColor")
    }()
    
    public var overlayGradientBgColor1: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "overlayGradientBgColor1")
    }()
    
    public var overlayGradientBgColor2: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "overlayGradientBgColor2")
    }()
    
    public var overlayGradientBgColor3: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "overlayGradientBgColor3")
    }()
    
    public var closeIconColor: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "closeIconColor")
    }()
    
    public var subTitle1Css: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "subTitle1TextColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "subTitle1TextFont"
            )
        )
    }()
    
    public var subTitle2Css: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "subTitle2TextColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "subTitle2TextFont"
            )
        )
    }()
    
    public var stickerViewBgColor1: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "stickerViewBgColor1")
    }()
    
    public var stickerViewBgColor2: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "stickerViewBgColor2")
    }()
    
    public var stickerTitleCss: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "stickerTitleColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "stickerTitleFont"
            )
        )
    }()
    
    public var stickerViewCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "stickerViewCornerRadius")
    }()
    
    public var mainTitleCss: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "mainTitleTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "mainTitleTextFont"
            )
        )
    }()
    
    public var stepsTitleCss: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "stepsTitleTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "stepsTitleTextFont"
            )
        )
    }()
    
    public var stepCircleColor: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "stepCircleColor")
    }()
    
    public var stepNumberCss: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "stepNumberColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "stepNumberFont"
            )
        )
    }()
    
    public var stepsVerticalLineColor: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "stepsVerticalLineColor")
    }()
    
    public var stepsTextCss: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "stepsTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "stepsTextFont"
            )
        )
    }()
    
    public var optInButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "optInButtonTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "optInButtonTextFont"
            )
        )
        return CasinoButtonCSS(
            title: textCSS,
            selected: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "playNowButtonBgColor"
            ),
            normal:  UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "optInButtonBgColor"
            )
        )
    }()
    
    public var playNowButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "playNowButtonTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "playNowButtonTextFont"
            )
        )
        return CasinoButtonCSS(
            title: textCSS,
            selected: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "playNowButtonBgColor"
            ),
            normal:  UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "optInButtonBgColor"
            )
        )
    }()
    
    
    public var additionalInfoCss: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "additionalInfoColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "additionalInfoFont"
            )
        )
    }()
    
    public var moreInfoTextCss: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "moreInfoTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "moreInfoTextFont"
            )
        )
    }()
    
    public var moreInfoDownArrowColor: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "moreInfoDownArrowColor")
    }()
    
    public var dividerColor: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "dividerColor")
    }()
    
    public var viewFullDetailsUnderLineColor: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "viewFullDetailsUnderLineColor")
    }()
    
    public var viewFullDetailsTextCss: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "viewFullDetailsTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "viewFullDetailsTextFont"
            )
        )
    }()
    
    public var optedInToasterBgColor: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "optedInToasterBgColor")
    }()
    
    public var optedInToasterCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "optedInToasterCornerRadius")
    }()
    
    public var optedInTextCss: TextCSS? = {
        DefaultTextCSS(
            color: UIColor.BWSColor(
                className: BWGamePremiereCSS, propertyName: "optedInTextColor"
            ),
            font: UIFont.BWSFont(
                className: BWGamePremiereCSS, propertyName: "optedInTextFont"
            )
        )
    }()
    
    public var toasterBarColor: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "toasterBarColor")
    }()
    
    public var toasterBarWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "toasterBarWidth")
    }()
    
    public var buttonBorderColor: UIColor? =  {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "buttonBorderColor")
    }()
    
    public var buttonBorderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "buttonBorderWidth")
    }()
    
    public var buttonCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "buttonCornerRadius")
    }()
    
    public var moreInfoContentBgColor: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "moreInfoContentBgColor")
    }()
    
    public var moreInfoContentTextColor: UIColor? = {
        UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "moreInfoContentTextColor")
    }()
    
    public var moreInfoContentFontName: String? = {
        return String.BWString(className: BWGamePremiereCSS, propertyName: "moreInfoContentFontName")
    }()
    
    public var moreInfoContentFontSize: CGFloat? = {
        return CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "moreInfoContentFontSize")
    }()
    
    public var offersIconName: String? = {
        return String.BWString(className: BWGamePremiereCSS, propertyName: "offerIconName")
    }()
    
    public var offersIconSize: CGFloat? = {
        return CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "offersIconFontSize")
    }()
    
    public var offersIconColor: UIColor? = {
        return UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "offersIconColor")
    }()
    
    public var speakerIconColor: UIColor? = {
       return UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "speakerIconColor")
    }()
    
    
    public var borderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "borderWidth")
        
    }()
    
    public var borderRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "borderRadius")
    }()
    
    public var borderBackgroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "borderBackgroundColor")
    }()
    
    public var borderForegroundColor: UIColor? = {
        return UIColor.BWSColor(className: BWGamePremiereCSS, propertyName: "borderForegroundColor")
    }()
    
    public var borderStripesAngle: CGFloat? = {
        CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "borderStripesAngle")
    }()
    
    public var borderBarWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "borderBarWidth")
    }()
    
    public var borderBarSpacing: CGFloat? = {
        CGFloat.BWSFloat(className: BWGamePremiereCSS, propertyName: "borderBarSpacing")
    }()
    
    public var isVideoFullScreenEnabled: String? = {
        String.BWString(className: BWGamePremiereCSS, propertyName: "isVideoFullScreenEnabled")
    }()
    
}


public struct GamePremiereButtonGradientColors {
   
   public static func getGradientColors(className: String, key: String) -> [[Color]]? {
       if let theme = DynaconAPIConfiguration.shared?.posAppConfig?.style?.theme,
          let cName = theme[className] as? [String: Any] {
           if let pName = cName[key] as? [[[String: Any]]] {
               var result = [[Color]]()
               pName.forEach { object in
                   if let data = try? JSONSerialization.data(withJSONObject: object), let model = try? data.jsonDecoder([ColorsModel].self).get().compactMap({$0.gradientColor}) {
                       result.append(model)
                   }
               }
               return result
           }
       }
       return nil
   }
}
