//
//  OriginalsWidgetCss.swift
//  ConfigModule
//
//  Created by Sindhuja Vedire on 05/09/24.
//

import Foundation
import Utility

public struct OriginalsWidgetCss: OriginalsWidgetCSS {

    // Widget CSS
    
    public var widgetTopViewBgColor1: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "widgetTopViewBgColor1")
    }()
    
    public var widgetTopViewBgColor2: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "widgetTopViewBgColor2")
    }()
    
    public var widgetBottomViewBgColor1: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "widgetBottomViewBgColor1")
    }()
    
    public var widgetBottomViewBgColor2: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "widgetBottomViewBgColor2")
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "titleColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "titleFont"))
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "descriptionColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "descriptionFont"))
    }()
    
    public var viewGamesCta: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "viewGamesCtaTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "viewGamesCtaTextFont"))
    }()
    
    public var rightArrowIconColor: UIColor = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "rightArrowIconColor")
    }()
    
    public var rightArrowIconSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "rightArrowIconSize")
    }()

    public var seeDetailsCta: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "seeDetailsCtaTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "seeDetailsCtaTextFont"))
    }()
    
    public var seeDetailsCtaCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "seeDetailsCtaCornerRadius")
    }()
    
    public var seeDetailsCtaBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "seeDetailsCtaBorderColor")
    }()
    
    public var seeDetailsCtaBorderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "seeDetailsCtaBorderWidth")
    }()
    
    public var optInCta: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "optInCtaTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "optInCtaTextFont"))
    }()
    
    public var optInCtaCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "optInCtaCornerRadius")
    }()
    
    public var optInCtaBgColor: [UIColor]? = {
        [
            UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "optInCtaGradientBgColor1"),
            UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "optInCtaGradientBgColor2")
        ]
    }()
    
    public var optedInCta: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "optedInCtaTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "optedInCtaTextFont"))
    }()
    
    public var maximumPrizeText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "maximumPrizeTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "maximumPrizeTextFont"))
    }()
    
    public var maximumPrizeValue: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "maximumPrizeValueColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "maximumPrizeValueFont"))
    }()
    
    public var timeLeftText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "timeLeftTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "timeLeftTextFont"))
    }()
    
    public var timerComponentsBgColor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "timerComponentsBgColor")
    }()
    
    public var timerComponents: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "timerComponentsColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "timerComponentsFont"))
    }()
    
    public var timerComponentsCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "timerComponentsCornerRadius")
    }()
    
    public var seperatorColor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "seperatorColor")
    }()
    
    public var seperatorSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "seperatorSize")
    }()

    public var durationText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "durationTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "durationTextFont"))
    }()
    
    public var originalsIconSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "originalsIconSize")
    }()
    
    public var greenTickIconSIze: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "greenTickIconSIze")
    }()

    public var greenTickIconColor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "greenTickIconColor")
    }()
    
    // Category Widget CSS
    
    public var widgetBackgoroundColor1: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "widgetBackgoroundColor1")
    }()
    
    public var widgetBackgoroundColor2: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "widgetBackgoroundColor2")
    }()
    
    public var mainTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "mainTitleTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "mainTitleTextFont"))
    }()
    
    public var subTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "subTitleTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "subTitleTextFont"))
    }()
    
    public var timerComponentsBackGroundColor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "timerComponentsBackGroundColor")
    }()
    
    public var timeComponentsCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "timeComponentsCornerRadius")
    }()
    
    public var timeComponents: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "timeComponentsTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "timeComponentsTextFont"))
    }()
    
    public var timeDurationText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "timeDurationTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "timeDurationTextFont"))
    }()
    
    public var widgetOveralyBGcolor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "widgetOveralyBGcolor")
    }()
    
    public var widgetOveralyCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "widgetOveralyCornerRadius")
    }()
    
    public var widgetOverlayHeaderText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "widgetOverlayHeaderTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "widgetOverlayHeaderTextFont"))
    }()
    
    public var widgetOverlayMaximumPrizeText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "widgetOverlayMaximumPrizeTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "widgetOverlayMaximumPrizeTextFont"))
    }()
    
    public var widgetOverlayMaximumPrizeValue: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "widgetOverlayMaximumPrizeValueColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "widgetOverlayMaximumPrizeValueFont"))
    }()
    
    public var widgetOverlayOptInChancesText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "widgetOverlayOptInChancesTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "widgetOverlayOptInChancesTextFont"))
    }()
    
    
    // Originals Overlay CSS
    
    public var overlayHeaderBgColor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "overlayHeaderBgColor")
    }()
    
    
    public var overlayHeaderCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "overlayHeaderCornerRadius")
    }()
    
    public var overlayBgColor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "overlayBgColor")
    }()
    
    public var headerTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "headerTitleColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "headerTitleFont"))
    }()
    
    public var closeBtnTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "closeBtnTitleColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "closeBtnTitleFont"))
    }()
    
    public var closeBtnBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "closeBtnBorderColor")
    }()
    
    public var closeBtnBorderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "closeBtnBorderWidth")
    }()
    
    public var closeBtnCornerRadius: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "closeBtnCornerRadius")
    }()
    
    public var ticketsIconSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "ticketsIconSize")
    }()
    
    public var ticketsText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "ticketsTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "ticketsTextFont"))
    }()
    
    public var timerIconSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "timerIconSize")
    }()
    
    public var expiresText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "expiresTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "expiresTextFont"))
    }()
    
    public var inDaysText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "inDaysTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "inDaysTextFont"))
    }()
    
    public var stepsTitleText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "stepsTitleTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "stepsTitleTextFont"))
    }()
    
    public var stepNumberBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "stepNumberBorderColor")
    }()
    
    public var stepNumberBorderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "stepNumberBorderWidth")
    }()
    
    public var verticalBarColor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "verticalBarColor")
    }()
    
    public var verticalBarWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "verticalBarWidth")
    }()
    
    public var dividerColor1: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "dividerColor1")
    }()
    
    public var dividerColor2: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "dividerColor2")
    }()
    
    public var stepNumber: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "stepNumberColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "stepNumberFont"))
    }()
    
    public var stepsDescription: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "stepsDescriptionColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "stepsDescriptionFont"))
    }()
    
    public var bonusIconSize: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "bonusIconSize")
    }()
    
    public var additionalInfoText: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "additionalInfoTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "additionalInfoTextFont"))
    }()
    
    public var viewFullDetailsCta: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "viewFullDetailsCtaColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "viewFullDetailsCtaFont"))
    }()
    
    public var viewFullDetailsCtaBorderColor: UIColor? = {
        UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "viewFullDetailsCtaBorderColor")
    }()
    
    public var viewFullDetailsCtaBorderWidth: CGFloat? = {
        CGFloat.BWSFloat(className: BWOriginalsWidget, propertyName: "viewFullDetailsCtaBorderWidth")
    }()
 
    public var overalyOptInCta: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "overalyOptInCtaTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "overalyOptInCtaTextFont"))
    }()
    
    public var overlayOptedInCta: TextCSS? = {
        DefaultTextCSS(color: UIColor.BWSColor(className: BWOriginalsWidget, propertyName: "overalyOptedtInCtaTextColor"),
                       font: UIFont.BWSFont(className: BWOriginalsWidget, propertyName: "overalyOptedtInCtaCtaTextFont"))
    }()
}
