//
//  LanguageConstants.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 14/07/23.
//

import Foundation

public let supportedGameLanguages = ["bg_BG",
                         "ca_ES",
                         "cs_CZ",
                         "cz",
                         "da_DK",
                         "de_DE",
                         "el_GR",
                         "en_US",
                         "es_ES",
                         "fi_FI",
                         "fr_FR",
                         "hr_HR",
                         "hu_HU",
                         "it_IT",
                         "ja_JP",
                         "ka_GE",
                         "nb_NO",
                         "nl_NL",
                         "no_NO",
                         "pl_PL",
                         "pt_BR",
                         "ro_RO",
                         "ru_RU",
                         "sk_SK",
                         "sl_SI",
                         "sv_SE",
                         "tr_TR",
                         "zh_CN"]

