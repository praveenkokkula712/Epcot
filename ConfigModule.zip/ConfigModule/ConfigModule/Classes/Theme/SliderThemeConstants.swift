//
//  SliderThemeConstants.swift
//  ConfigModule
//
//  Created by Gostu Bhargavi on 04/03/24.
//

import Foundation


let BWSlidersRCPUStyle = "RCPU"
let BWSlidersEasyNavigation = "easyNavCSS"
let BWSlidersSessionSettingCSS = "SessionSetting"
let BWSlidersSessionSettingsPopupCSS = "SessionSettingPopup"
let BWSlidersSessionRemaindersPopupCSS = "SessionRemainderPopup"
let BWSlidersQuickGamesPopupCSS = "quickGames"
