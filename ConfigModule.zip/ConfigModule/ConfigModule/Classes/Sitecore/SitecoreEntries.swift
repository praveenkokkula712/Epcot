//
//  SitecoreEntries.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 16/06/23.
//

import Foundation

public struct SiteCoreOtherEntries {
    var spotLightSearchEnabled: Bool = false
    var threeDTouchEnabled: Bool = false
    var showHeaderRegulatory: Bool = false
    
    public init(spotLightSearchEnabled: Bool = false,
         threeDTouchEnabled: Bool = false,
         showHeaderRegulatory: Bool = false) {
        self.spotLightSearchEnabled = spotLightSearchEnabled
        self.threeDTouchEnabled = threeDTouchEnabled
        self.showHeaderRegulatory = showHeaderRegulatory
    }
}
