//
//  DynaconAPIConfigurationDelegate.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 16/06/23.
//

import Foundation

public protocol DynaconAPIConfigurationDelegate {
    func didUpdateSitecoreModels(isReloadNeeded: Bool)
    func didUpdateUserSitecoreContent()
    func didUpdateLocalisedStrings()
}
