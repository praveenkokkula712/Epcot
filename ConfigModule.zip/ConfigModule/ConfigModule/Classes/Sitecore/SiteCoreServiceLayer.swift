//
//  SiteCoreServiceLayer.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 16/06/23.
//

import Foundation
import CasinoAPI
import Utility

class SiteCoreServiceLayer {
    
    private var posConfigs: POSConfigs
    private var sitecoreOtherEntries: SiteCoreOtherEntries?
    private var delegate: DynaconAPIConfigurationDelegate?
    
    private let sitecoreQueue = DispatchQueue(label: "SitecoreGroupApi")
    
    init(posConfigs: POSConfigs, entries: SiteCoreOtherEntries?, delegate: DynaconAPIConfigurationDelegate?) {
        self.posConfigs = posConfigs
        self.sitecoreOtherEntries = entries
        self.delegate = delegate
    }
    
    private var appConfigurations: PosAppConfiguration? {
        DynaconAPIConfiguration.shared?.posAppConfig
    }
    
    func initialiseSitecoreServices() {
        if let siteCore = appConfigurations?.sitecore {
            self.setupConfigurations(with: siteCore)
            self.fetchCachedData()
            self.onAppLaunchLoadSitecoreEntries(with: siteCore)
            self.afterAppLaunchLoadSitecoreEntries(with: siteCore)
            self.loadSitecoreEntries(with: siteCore)
        }
    }
    
    private func fetchCachedData() {
        if let localisation = POSAPI.shared?.cachedResponse {
            self.didUpdateLocalizationStrings(localisation)
        }
        let result = POSAPI.shared?.fetchCachedData() ?? false
        if result {
            self.delegate?.didUpdateSitecoreModels(isReloadNeeded: true)
        }
    }
    
    func refreshSitecoreServices() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
            if let siteCore = self.appConfigurations?.sitecore {
                self.sitecoreQueue.sync {
                    // refresh models
                    var dicSitecoreOthersEntries: [SiteCoreLiteralBatchEntryType: String?] = [
                        .bottomBar: siteCore.bottomNavigationItems,
                        .nativeWidget: siteCore.nativeWidgetPath,
                        .jackpotWidgets: siteCore.jackpotWidgetPath,
                        .jackpotTilesOrder: siteCore.jackpotTilesOrderPath,
                        .jackpotTiles: siteCore.jackpotTilesPath,
                        .burgerMenu: siteCore.nativeBurgerMenuPath,
                        .subNavigation: siteCore.nativeSubCategoriespath,
                    ]
                    if EntainContext.user?.isLoggedIn() ?? false {
                        dicSitecoreOthersEntries[.betMgmOriginals] = siteCore.originalsWidgetContentPath
                    }
                    let entries = self.getSitecoreEntries(with: [:],
                                                     dicOthersEntries: dicSitecoreOthersEntries)
                    self.refreshSitecoreService(with: entries, priority: .high)
                }
            }
        })
    }
    private func setupConfigurations(with siteCore: PosAppConfigurationSiteCore) {
        let appLanguage = self.posConfigs.language
        let posApiContext = POSAPIContext(api: APIContext(dns: self.posConfigs.baseUrl),
                                          accessID: self.posConfigs.accessId,
                                          lang: appLanguage,
                                          culture: siteCore.languageCulture?[appLanguage] ?? "en-US",
                                          depth: "10",
                                          siteCoreEnv: siteCore.environment,
                                          enableFilter: siteCore.enableSitecoreItemsFilter)
        POSAPI.shared?.updateContext(posApiContext, delegate: self)
        
        POSAPI.routes[POSAPI.SiteCoreBase] = siteCore.endpoint
        
        if !siteCore.teasersPath.isEmpty {
            POSAPI.routes[POSAPI.TeaserContent] = siteCore.teasersPath
        }
        if let path = siteCore.gameStoriesPath, !path.isEmpty {
            POSAPI.routes[POSAPI.StoryContent] = path
        }
    }
    
    private func onAppLaunchLoadSitecoreEntries(with sitecore: PosAppConfigurationSiteCore) {
        sitecoreQueue.sync {
            let dicSitecoreStringsEntries: [SiteCoreLiteralBatchEntryType: String?] = [.osPrimers: sitecore.osPrimersPopUpContent,
                                                                                       .loadingScreen: sitecore.loadingScreenPath,
                                                                                       .updateAvailable: sitecore.updateAvailablePath,
                                                                                       .common: sitecore.commonPath,
                                                                                       .error: sitecore.errorPath,
                                                                                       .biometric: sitecore.biometricPopUpContentPath,
                                                                                       .updateContent: sitecore.popupContentPath,
                                                                                       .touchIdPopup: sitecore.touchIdPopupPath,
                                                                                       .lobby: sitecore.lobbyPath,
                                                                                       .login: sitecore.loginPath,
                                                                                       .usCompliance: sitecore.usCompliancePopUpContentPath,
                                                                                       .rateMyApp: sitecore.rateMyApp,
                                                                                       .userOnboardingJourney: sitecore.newUserOnboardingJourneyPath,
                                                                                       .searchV2: sitecore.searchV2Path,
                                                                                       .casinoStories: sitecore.casinoStoriesPath,
                                                                                       .bingoRoomImages: sitecore.bingoRoomImagesPath,
                                                                                       .bingoRoomIcons: sitecore.bingoRoomIconsPath,
                                                                                       .bingoRoomTexts: sitecore.bingoRoomTextsPath,
                                                                                       .bingoRoomNames: sitecore.bingoRoomNamesPath,
                                                                                       .bingoRoomGameFeatureIcons: sitecore.bingoGameFeatureIconsPath,
                                                                                       .bingoRoomGlobalTexts: sitecore.bingoRoomGlobalTextsPath,
                                                                                       .bingoRoomGlobalSEPTexts: sitecore.bingoRoomGlobalSEPTextsPath,
                                                                                       .bingoWidgetSingleEntryPoint: sitecore.bingoRoomSingleEntryPointPath,
                                                                                       .freeSpinsConfigurationTexts: sitecore.freeSpinsWidgetConfigurationTextsPath,
                                                                                       .freeSpinsWidgetBackgroundImage: sitecore.freeSpinsWidgetBackroundImagePath,
                                                                                       .freeSpinsCtaBackgroundImage: sitecore.freeSpinsWidgetCtaBackgroundImagePath,
                                                                                       .freeSpinsStrings: sitecore.freeSpinsStringsPath]
            
            var dicSitecoreOthersEntries: [SiteCoreLiteralBatchEntryType: String?] = [.bottomBar: sitecore.bottomNavigationItems,
                                                                                      .nativeWidget: sitecore.nativeWidgetPath,
                                                                                      .jackpotWidgets: sitecore.jackpotWidgetPath,
                                                                                      .gamePremiere: sitecore.gamePremierePath,
                                                                                      .playerStatsConfigurationTexts: sitecore.playerStatsWidgetConfigurationsPath,
                                                                                      .playerStatsImages: sitecore.playerStatsImagesPath,
                                                                                      .jackpotTilesOrder: sitecore.jackpotTilesOrderPath,
                                                                                      .jackpotTiles: sitecore.jackpotTilesPath]
            if self.sitecoreOtherEntries?.spotLightSearchEnabled ?? false {
                dicSitecoreOthersEntries[.spotlightSearch] = sitecore.spotlightSearchItemsPath
            }
            if self.sitecoreOtherEntries?.threeDTouchEnabled ?? false {
                dicSitecoreOthersEntries[.threeDTouch] = sitecore.threeDTouchItemsPath
            }
            if self.sitecoreOtherEntries?.showHeaderRegulatory ?? false {
                dicSitecoreOthersEntries[.headerRegulatory] = sitecore.headerRegulatoryPath
            }
            
            if appConfigurations?.features?.nativeFooterEnabled == true {
                dicSitecoreOthersEntries[.footerLogo] = sitecore.nativeFooterLogoItemsPath
                dicSitecoreOthersEntries[.footerContent] = sitecore.nativeFooterContentMessagesPath
                dicSitecoreOthersEntries[.footerSeoLinks] = sitecore.nativeFooterSEOLinksPath
                dicSitecoreOthersEntries[.footerCopyRight] = sitecore.nativeFooterCopyRightPath
                dicSitecoreOthersEntries[.footerStateSwitcher] = sitecore.nativeFooterLoginDurationTimerPath
                dicSitecoreOthersEntries[.footerBrandLogo] = sitecore.nativeFooterBrandLogoPath
                dicSitecoreOthersEntries[.footerAboutUs] = sitecore.nativeFooterAboutUsPath
            }
            dicSitecoreOthersEntries[.burgerMenu] = sitecore.nativeBurgerMenuPath
            dicSitecoreOthersEntries[.subNavigation] = sitecore.nativeSubCategoriespath
            dicSitecoreOthersEntries[.errorCodeHandler] = sitecore.errorCodeHandlersPath
            dicSitecoreOthersEntries[.newBiometricPopUpTouchIdLogoPath] = sitecore.touchIdLogoPath
            dicSitecoreOthersEntries[.newBiometricPopUpFaceIdLogoPath] = sitecore.faceIdLogoPath
            
            let entries = self.getSitecoreEntries(with: dicSitecoreStringsEntries,
                                                  dicOthersEntries: dicSitecoreOthersEntries)
            self.callSitecoreService(with: entries, priority: .high)
        }
    }
    
    func afterAppLaunchLoadSitecoreEntries(with sitecore: PosAppConfigurationSiteCore) {
        sitecoreQueue.sync {
            let dicSitecoreStringsEntries: [SiteCoreLiteralBatchEntryType: String?] = [.authada: sitecore.authadaPath,
                                                                                       .alertView: sitecore.alertViewPath,
                                                                                       .appFlyer: sitecore.appFlyerPath,
                                                                                       .sideMenu: sitecore.sideMenuPath,
                                                                                       .usnj: sitecore.usnjPath,
                                                                                       .aRCBreakCompliance: sitecore.arcBreakCompliance,
                                                                                       .regulatoryStrings: sitecore.regulatoryStringsPath,
                                                                                       .sessionLimitStrings: sitecore.sessionLimitsLocalizationStringsPath]
            
            
            var dicSitecoreOthersEntries: [SiteCoreLiteralBatchEntryType: String?] = [.unverifiedKyc: sitecore.unverifiedKycPopUpContent,
                                                                                      .verificationPendingKyc: sitecore.verificationPendingKycPopUpContent,
                                                                                      .usRegulatory: sitecore.usRegulatoryPopUpContentPath,
                                                                                      .arcPlayerBreak: sitecore.arcPlayerBreak,
                                                                                      .arcRtmsGracePeriod : sitecore.arcRtmsGracePeriod,
                                                                                      .arcRtmsPlayerBreak: sitecore.arcRtmsPlayerBreak,  .arcRtmsLslPlayBreak: sitecore.arcRtmsLSLPlayBreak, .arcRtmsLsl24PlayBreak: sitecore.arcRtmsLSL24PlayBreak, .arcRtmsLslContinuousPlayBreak: sitecore.arcRtmsLSLContinuousPlayBreak, .arcRtmsLsl24T1PlayBreak: sitecore.arcRtmsLSL24T1PlayBreak,
                                                                                      .liveCasinoAPIContent: sitecore.liveCasinoAPIDataPath,
                                                                                      .engagementTools: sitecore.engagementToolsPath
            ]
            if appConfigurations?.features?.productMenuEnabled ?? false {
                dicSitecoreOthersEntries[.productMenu] = sitecore.productMenuPath
            }
            
            let entries = getSitecoreEntries(with: dicSitecoreStringsEntries,
                                             dicOthersEntries: dicSitecoreOthersEntries)
            
            self.callSitecoreService(with: entries, priority: .low)
        }
    }
    
    private func loadSitecoreEntries(with sitecore: PosAppConfigurationSiteCore) {
        DispatchQueue.global(qos: .default).asyncAfter(deadline: .now() + 10.0) { [weak self] in
            guard let self else { return }
            let dicSitecoreStringsEntries: [SiteCoreLiteralBatchEntryType: String?] = [.freeBet: sitecore.freeBetPath,
                                                                                       .appFeedback:sitecore.appFeedbackPath,
                                                                                       .documentUpload:sitecore.documentUploadPath,
                                                                                       .gameInfo: sitecore.gameInfoPath,
                                                                                       .miniGames: sitecore.miniGamesPath]

            var dicSitecoreOthersEntries: [SiteCoreLiteralBatchEntryType: String?] = [.rcpUK: sitecore.rcpUKItemsPath,
                                                                                      .greeceSessionLimit :sitecore.nativeSessionLimitKeys,
                                                                                      .sessionLogout: sitecore.nativeSessionLogoutKeys,
                                                                                      .sessionFullDayLogout: sitecore.nativeSingleSessionExpiryKeys,
                                                                                      .playBreakAboutToStart: sitecore.playBreakAboutToStartDuringGamePlay,
                                                                                      .playBreakStarted: sitecore.playBreakStartedDurningGamePlay,
                                                                                      .ontarioLossLimit: sitecore.lossLimitItemsPath,
                                                                                      .oneHourRCP: sitecore.oneHourRCPContent,
                                                                                      .germanRtpBigWin: sitecore.rtpBigWinWidgetPath,
                                                                                      .germanCrossProductMinBreakWidget: sitecore.crossProductMinBreakWidgetPath,
                                                                                      .germanGamePlayMinBreakWidget: sitecore.gameplayMinBreakWidgetPath,
                                                                                      .germanRealityCheckLoginWidget: sitecore.realityCheckLoginSessionWidgetPath]
            if self.appConfigurations?.features?.enableProductSwitchCoolOff ?? false {
                dicSitecoreOthersEntries[.germanProductSwitchCoolOff] = sitecore.productSwitchCoolOff
            }
            let entries = self.getSitecoreEntries(with: dicSitecoreStringsEntries,
                                                  dicOthersEntries: dicSitecoreOthersEntries)
            self.callSitecoreService(with: entries, priority: .low)
        }
    }
    
    private func getSitecoreEntries(with dicLocalizedString: [SiteCoreLiteralBatchEntryType: String?],
                                    dicOthersEntries: [SiteCoreLiteralBatchEntryType: String?]) -> [SiteCoreLiteralBatchEntry] {
        var entries: [SiteCoreLiteralBatchEntry] = []
        
        let arrSiteCoreStringsEntries = dicLocalizedString.filter( { !($0.value ?? "").isEmpty }).map{
            SiteCoreLiteralBatchEntry(type: $0.key, path: $0.value, sitecoreType: .strings) }
        entries = arrSiteCoreStringsEntries
        
        let arrSitecoreOthersEntries = dicOthersEntries.filter( { !($0.value ?? "").isEmpty }).map {
            SiteCoreLiteralBatchEntry(type: $0.key, path: $0.value, sitecoreType: .others) }
        entries += arrSitecoreOthersEntries
        
        return entries
    }
    
    private func callSitecoreService(with entries: [SiteCoreLiteralBatchEntry],
                                     priority: TaskPriority = .low) {
        Task(priority: priority, operation: {
            try? await POSAPI.shared?.fetchSiteCoreData(forEntries: entries)
            self.delegate?.didUpdateSitecoreModels(isReloadNeeded: priority == .high)
        })
    }
    
    private func refreshSitecoreService(with entries: [SiteCoreLiteralBatchEntry],
                                     priority: TaskPriority = .low) {
        Task(priority: priority, operation: {
            try? await POSAPI.shared?.fetchSiteCoreData(forEntries: entries)
            self.delegate?.didUpdateUserSitecoreContent()
        })
    }
}

extension SiteCoreServiceLayer: PosApiDelegate {
    
    func didUpdateLocalizationStrings(_ strings: [String : Any]) {
        LocalisedManager.shared.updateStrings(with: strings)
        self.delegate?.didUpdateLocalisedStrings()
    }
}
