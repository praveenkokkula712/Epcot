//
//  POSConfigs.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 16/06/23.
//

import Foundation

public struct POSConfigs {
    var baseUrl: String
    var accessId: String
    var language: String
    
    public init(baseUrl: String, accessId: String, language: String) {
        self.baseUrl = baseUrl
        self.accessId = accessId
        self.language = language
    }
}
