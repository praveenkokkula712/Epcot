//
//  URLRequest+Sitecore.swift
//  ConfigModule
//
//  Created by Yemireddi Sateesh on 16/06/23.
//

import Foundation

extension URLRequest {
    var isSiteCoreRequest: Bool {
        if let httpBody = self.httpBody {
            do {
                // TODO: Refactor this using Codable
                let json = try JSONSerialization.jsonObject(with: httpBody, options: []) as? [String : Any]
                if let entries = json?["Entries"] as? [[String: Any]] {
                    for entry in entries {
                        if let relativeURL = entry["relativeUri"] as? String,
                           relativeURL.contains("content.svc") {
                            return true
                        }
                    }
                }
            } catch { return false }
        }
        return false
    }
}
