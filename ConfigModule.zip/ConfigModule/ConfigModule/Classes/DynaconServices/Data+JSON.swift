//
//  Data+JSON.swift
//  ConfigModule
//
//  Created by Yemireddi Sateesh on 16/06/23.
//

import Foundation

extension Data {
    var convertJSON: (response: [String: AnyObject]? , error: NSError?) {
        do {
            return (try JSONSerialization.jsonObject(with: self, options: []) as? [String: AnyObject], nil)
        } catch let error {
            return (nil , error as NSError)
        }
    }
}
