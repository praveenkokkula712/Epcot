//
//  DynaconBatchService.swift
//  ConfigModule
//
//  Created by Yemireddi Sateesh on 15/06/23.
//

import Foundation

@objcMembers
public class DynaconBatchService {
    private let batchServicePath = "/V3/Batch.svc/"
    private let apiConfig = DynaconAPIConfiguration.shared?.dynaconConfigs

    public init() { }

    public func fetchBatchData(with entries: [DynaconBatchEntry],
                               defaultAccessId: String? = nil) async throws -> Any? {
        let postData = self.getPostDataFor(entries: entries)
        let networkService = POSNetworkService(
            accessID: apiConfig?.accessID ?? "",
            environmentName: apiConfig?.environment ?? "",
            baseURL: apiConfig?.environmentPOSURL ?? ""
        )
        do {
            let (_, data) = try await networkService.fetchData(
                urlPath: batchServicePath,
                httpMethod: .post,
                payload: postData,
                defaultAccessId: defaultAccessId,
                skipSessionToken: true
            )
            if let json = data?.convertJSON.response {
                var parsedResponse: Any? = data
                if let responseList = parseResponse(response: json, entries: entries) {
                    parsedResponse = responseList
                    return parsedResponse
                }
            } else {
                if let errorResponse = data?.convertJSON.error {
                    throw NetworkError(errorResponse)
                }
            }
        } catch {
            throw error
        }
        return nil
    }
    
    // TODO: Need to do more refactoring this with Codable/other patterns..
    private func parseResponse(response: Any, entries: [DynaconBatchEntry]) -> [Any]? {
        
        var responseList = [Any]()
        
        if let _response = response as? [String:Any] {
            
            if let jsonEntries = _response["Entries"] as? [[String:Any]] {
                
                for entryInfo in jsonEntries {
                    
                    if let _ = entryInfo["id"] as? String {
                        
                        for entry in entries {
                            
                            switch entry.type {
                            case .appConfiguration:
                                if let configurationInfo = entryInfo["Configuration"] as? [String:Any] {
                                    let posAppConfig = PosAppConfiguration(json: configurationInfo, environment: "prod")
                                    DynaconAPIConfiguration.shared?.posAppConfig = posAppConfig
                                    responseList.append(posAppConfig)
                                }
                                break
                            case .geoLocation:
                                if let locationInfo = entryInfo["GeoLocation"] as? [String:Any] {
                                    let geoLocationData = PosGeoLocationData(json: locationInfo)
                                    responseList.append(geoLocationData)
                                    DynaconAPIConfiguration.shared?.geoLocationData = geoLocationData
                                }
                                break
                            }
                            break
                        }
                    }
                }
            }
        }
        
        return responseList.count > 0 ? responseList : nil
    }
}

extension DynaconBatchService {
    private func getPostDataFor(entries: [DynaconBatchEntry]) -> [String: Any] {
        let entriesInfo = entries.compactMap { entry in
            if !entry.relativeURL.isEmpty {
                return [
                    "id":entry.id ,
                    "method": "GET",
                    "relativeUri": entry.relativeURL
                ]
            } else {
                return nil
            }
        }
        return ["Entries": entriesInfo]
    }
}

