//
//  DynaconConfigurations.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 26/06/23.
//

import Foundation


public struct DynaconConfigurations {
    var appConfiguration = ""
    var labelType: String? = ""
    var isMultiBrandLabel = false
    var environment = ""
    var environmentPOSURL = ""

    var accessID = ""

    var userToken: String? = ""
    var sessionToken: String? = ""
    var isLoginAuthorized = false
    
    public init(appConfiguration: String = "",
                labelType: String? = nil,
                isMultiBrandLabel: Bool = false,
                environment: String = "",
                environmentPOSURL: String = "",
                accessID: String = "",
                userToken: String? = nil,
                sessionToken: String? = nil,
                isLoginAuthorized: Bool = false) {
        self.appConfiguration = appConfiguration
        self.labelType = labelType
        self.isMultiBrandLabel = isMultiBrandLabel
        self.environment = environment
        self.environmentPOSURL = environmentPOSURL
        self.accessID = accessID
        self.userToken = userToken
        self.sessionToken = sessionToken
        self.isLoginAuthorized = isLoginAuthorized
    }
    
}
