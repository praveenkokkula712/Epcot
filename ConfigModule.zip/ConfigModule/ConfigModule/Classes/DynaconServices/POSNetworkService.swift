//
//  POSNetworkService.swift
//  ConfigModule
//
//  Created by Yemireddi Sateesh on 16/06/23.
//

import Foundation
import CasinoAPI

class POSNetworkService {
    // MARK: - Properties
    private var accessID = ""
    private var environmentName = ""
    private var baseURL = ""
    private let apiConfig: DynaconConfigurations? = DynaconAPIConfiguration.shared?.dynaconConfigs

    // MARK: - Init
    init(accessID: String = "", environmentName: String = "", baseURL: String = "") {
        self.accessID = accessID
        self.environmentName = environmentName
        self.baseURL = baseURL
    }
    
    var formattedBaseURL: String {
        return baseURL
    }

    func formatBaseURL(path: String) -> URL? {
        var urlString = path.isEmpty ? baseURL : baseURL + path
        if let encodedURL = urlString.addingPercentEncoding(
            withAllowedCharacters: .urlQueryAllowed
        ) {
            urlString = encodedURL
        }
        return URL(string: urlString)
    }

    private func getURLRequest(
        url: URL,
        method: HTTPMethod,
        defaultAccessId: String? = nil,
        skipSessionToken: Bool = false
    ) -> URLRequest {
        var urlRequest = URLRequest(url: url)
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.setValue("application/json", forHTTPHeaderField: "Accept")
        urlRequest.setValue(defaultAccessId ?? accessID, forHTTPHeaderField: "x-bwin-accessId")
        #if DEBUG
        urlRequest.setValue("207.8.224.29", forHTTPHeaderField: "x-bwin-client-ip")
        #endif
        if !skipSessionToken, apiConfig?.isLoginAuthorized ?? false {
            if let sessionToken = apiConfig?.sessionToken {
                urlRequest.setValue(sessionToken, forHTTPHeaderField: "x-bwin-session-token")
            }
            if let userToken = apiConfig?.userToken {
                urlRequest.setValue(userToken, forHTTPHeaderField: "x-bwin-user-token")
            }
        }
        urlRequest.httpMethod = method.rawValue
        return urlRequest
    }

    func fetchData(
        urlPath: String,
        httpMethod: HTTPMethod,
        payload: Any? = nil,
        defaultAccessId: String? = nil,
        skipSessionToken: Bool = false
    ) async throws -> (URLRequest?, Data?) {
        guard let url = self.formatBaseURL(path: urlPath) else {
            return (nil, nil)
        }
        var urlRequest: URLRequest!
        if httpMethod == .get {
            urlRequest = getURLRequest(url: url, method: .get)
        } else if httpMethod == .post {
            urlRequest = getURLRequest(
                url: url,
                method: .post,
                defaultAccessId: defaultAccessId,
                skipSessionToken: skipSessionToken
            )
            if let payloadData = payload {
                urlRequest.setHTTPBody(info: payloadData)
            }
        } else {
            fatalError("HTTP Method is not handled!")
        }
        let (data, response) = try await URLSession.shared.data(for: urlRequest)
        if let httpResponse = response as? HTTPURLResponse {
            switch httpResponse.statusCode {
            case 200..<300:
                return (urlRequest, data)
            case 400..<600:
                let error = try JSONDecoder().decode(NetworkError.self, from: data)
                throw error
            default:
                break
            }
        }
        return (urlRequest, nil)
    }
}
