//
//  DynaconBatchEntry.swift
//  Wrapper
//
//  Created by Sumeet Bajaj on 08/03/2018.
//  Copyright © 2018 Sumeet Bajaj. All rights reserved.
//

import Foundation

public enum DynaconBatchEntryType {
    case appConfiguration
    case geoLocation
}

extension DynaconBatchEntryType {
    
    var apiConfig: DynaconConfigurations? {
        DynaconAPIConfiguration.shared?.dynaconConfigs
    }
    
    var appConfig: AppConfigurations? {
        DynaconAPIConfiguration.shared?.appConfigs
    }
    
    var relativeURL: String {
        switch self {
            case .appConfiguration:
            let environment = apiConfig?.environment ?? "prod"
                var labelQuery = ""
                let channel = appConfig?.channel ?? "CNH"
                let appConfigVersion = apiConfig?.appConfiguration ?? ""
                if  let labelType = apiConfig?.labelType,
                    !labelType.isEmpty,
                    apiConfig?.isMultiBrandLabel ?? false {
                    labelQuery = "&label=\(labelType)"
                }
                return "Common.svc/configuration/\(channel):\(appConfigVersion)?env=\(environment)\(labelQuery)"
            case .geoLocation:
                return "GeoLocation.svc/IP/"
        }
    }
}

public class DynaconBatchEntry: NSObject {
    let id = UUID().uuidString
    var type: DynaconBatchEntryType
    var relativeURL: String

    public init(type: DynaconBatchEntryType) {
        self.type = type
        self.relativeURL = type.relativeURL
        super.init()
    }
}
