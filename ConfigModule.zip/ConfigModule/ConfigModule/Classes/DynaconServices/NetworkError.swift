//
//  NetworkError.swift
//  ConfigModule
//
//  Created by Yemireddi Sateesh on 16/06/23.
//

import Foundation

class NetworkError: Error, Codable {
    var code: Int? = 0
    var message: String? = ""

    init(_ error: Error? = nil) {
        if let error = error {
            self.message = error.localizedDescription
            self.code = (error as NSError).code
        }
    }
}
