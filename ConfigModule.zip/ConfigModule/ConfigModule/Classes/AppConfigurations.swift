//
//  AppConfigurations.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 16/06/23.
//

import Foundation

public struct AppConfigurations {
    var usStateCode: String?
    var depostiUrlScheme: String?
    var brandId: String?
    var frontEndId: String?
    var environment: String?
    var language: String?
    public private(set) var systemLanguage: String?
    var channel = "CNH"
    var iTunesAppItemIdentifier: String? = ""
    var gameControllerVersion: String? = ""
    var kinesisEncryptedKey = ""
    public private(set) var productType = ProductType.casino
    var bundleShortVersion: String? = ""
    var isUnifiedApp = false
    var countryCode: String? = ""
    var isInternalBuild = true
    var deviceUniqueId: String = ""
    
    public init(usStateCode: String? = nil,
         depostiUrlScheme: String? = nil,
         brandId: String? = nil,
         frontEndId: String? = nil,
         environment: String? = nil,
         language: String? = nil,
         systemLanguage: String? = nil,
         channel: String = "CNH",
         iTunesAppItemIdentifier: String? = nil,
         gameControllerVersion: String? = nil,
         kinesisEncryptedKey: String = "",
         productType: ProductType = ProductType.casino,
         bundleShortVersion: String? = nil,
         isUnifiedApp: Bool = false,
         countryCode: String? = nil,
         isInternalBuild: Bool = true,
         deviceUniqueId: String = "") {
        
        self.usStateCode = usStateCode
        self.depostiUrlScheme = depostiUrlScheme
        self.brandId = brandId
        self.frontEndId = frontEndId
        self.environment = environment
        self.language = language
        self.systemLanguage = systemLanguage
        self.channel = channel
        self.iTunesAppItemIdentifier = iTunesAppItemIdentifier
        self.gameControllerVersion = gameControllerVersion
        self.kinesisEncryptedKey = kinesisEncryptedKey
        self.productType = productType
        self.bundleShortVersion = bundleShortVersion
        self.isUnifiedApp = isUnifiedApp
        self.countryCode = countryCode
        self.isInternalBuild = isInternalBuild
        self.deviceUniqueId = deviceUniqueId
    }
}
