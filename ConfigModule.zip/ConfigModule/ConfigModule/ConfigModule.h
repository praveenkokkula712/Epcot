//
//  ConfigModule.h
//  ConfigModule
//
//  Created by Praveen Kokkula on 13/06/23.
//

#import <Foundation/Foundation.h>

//! Project version number for ConfigModule.
FOUNDATION_EXPORT double ConfigModuleVersionNumber;

//! Project version string for ConfigModule.
FOUNDATION_EXPORT const unsigned char ConfigModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConfigModule/PublicHeader.h>


