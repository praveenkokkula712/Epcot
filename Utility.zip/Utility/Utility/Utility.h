//
//  Utility.h
//  Utility
//
//  Created by Sumeet Bajaj on 13/01/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Utility.
FOUNDATION_EXPORT double UtilityVersionNumber;

//! Project version string for Utility.
FOUNDATION_EXPORT const unsigned char UtilityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Utility/PublicHeader.h>


