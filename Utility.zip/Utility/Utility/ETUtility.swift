//
//  Utility.swift
//  Utility
//
//  Created by Sumeet Bajaj on 14/01/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import Foundation

public class EntainContext {
    
    public static var app:AppContext?
    
    public static var casino: CasinoContext?
    
    public static var slider: SliderContext?
    
    public static var user: UserContext?
    
    public static var aws: AWSContext?
    
    public static var gameResourceInfo: GameResourceInfoContext?

    public static var gameController: GameControllerContext?
    
    public static var kibana: AWSContext?
    
    public static var usUnified: USUnifiedContext?

    public static var deposit: DepositContext?
    
    public static var dualModeConfigContext: DualModeConfigContext?
    
    public static var lruContext: LruContext?

    public static var codepushContext: CodepushVersionConfigurations?
    
    public static var regionContext: RegionContext?
}

public class CasinoCSS {
    
    public static var localisationDataSource:CasinoLocalisationDataSource?
    
    public static var lobby: LobbyCSS?
    
    public static var sliderLobby: SliderLobbyCSS?

}

public protocol CasinoLocalisationDataSource {
    
    func didRequestLocalised(key: String, comment: String) -> String
    
    func didRequestFont(key: String) -> UIFont
    
}
