//
//  LobbyDelegate.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 19/07/23.
//

import Foundation
import WebKit

public protocol LobbyDelegate: LobbyOptionalDelegates {
        /// This method will invoked when user clicks the play without logged in.
    func didRequestLogin(completionHandler: ((Bool) -> Void)?)
    
        /// This method will invoked if any game requested for force logout
    func didRequestLogout()
    
    func didSelectWOFCategory(_ selectedCategory: String)
    
        /// This methow will invoked for each game state change
        /// - Parameters:
        ///   - state: GameState i.e loading/loaded/unloading/unloaded
        ///   - of: String game id of game
    func didUpdateGame(state:GameState, of:String?)
    
    func showRCPOneHourAlertView()
    
    func showAlertViewWith(title : String , description : String , buttons: NSArray, attributedDescription: NSAttributedString? , completion : ((Int, String?)->())?)
    
    func didReceiveRtmsNotification(notification: RTMNotification)
}


public extension LobbyDelegate {
    
    func didSelectWOFCategory(_ selectedCategory: String) { }
    
    func didReceiveRtmsNotification(notification: RTMNotification) { }
}


/****************************************************************/
/* Delegate to send messages to client */
/****************************************************************/

@objc public protocol LobbyOptionalDelegates {
    
        /// This method will invoked when failed to load the game through game id
        /// - Parameters:
        ///   - game: String game id to be loaded
        ///   - error: Error
    @objc optional func didFailedLoading(game: String?, error: Error?)
    
    
        /// This method will invoked on each ping notification received from game
        /// - Parameter game: String - Game ID
    @objc optional func didReceivedPingFrom(game: String?)
    
    
        /// This method will pass the information about webView
        /// - Parameters:
        ///   - webView: loaded webView info
        ///   - navigation: Naviation aciton of webView
    @objc optional func clWebView(_ webView: WKWebView, didFinish navigation: WKNavigation!)
    
        /// This method will pass the information about webView
        /// - Parameters:
        ///   - webView: loaded webView info
        ///   - navigation: Naviation aciton of webView
        ///   - error : Error while loading the webView
    @objc optional func clWebView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error)
    
        /// This method will pass the information about webView
        /// - Parameters:
        ///   - webView: loaded webView info
        ///   - navigationAction: Naviation aciton of webView
    @objc optional func clWebView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction)
    
        /// This method will pass the information about webView
        /// - Parameters:
        ///   - webView: loaded webView info
        ///   - challenge: challenge in loading the autenticaton
    @objc optional func clWebView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge)
    
        /// This method will pass the information about Script message Handler
        /// - Parameters:
        ///   - userContentController: loaded webView info
        ///   - message: Passing the message information
    @objc optional func clUserContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage)
    
    ///This delegate method will get called when Overlays or toaster dismissed/removed
    @objc optional func didOverlaysAndToasterDismissed()
}
