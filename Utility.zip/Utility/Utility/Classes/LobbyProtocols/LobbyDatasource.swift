//
//  LobbyDatasource.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 19/07/23.
//

import Foundation

public protocol LobbyDatasource: LobbyDataSourceOptionals, CasinoDatasource {
    
        /// This method will invoked when lobby requires UIViewController to present game controller
    func controllerForLoadGame() -> UIViewController
    
        /// This method will invoked before loading to validate user screen name. On completion it will continue loading game for true.
        /// - Parameter completionHandler: CompletionHandler
    func validateUserScreenName(completionHandler: @escaping (Bool) -> Void)
            
    func didRequestForLastPlayedGamesDisplayLimit() -> Int?

    func didRequestForIconVariant(with iconName: String, fontSize: CGFloat) -> IconVariant
        
    var teasersDynaconConfig: TeaserDynaconConfig? { get }
    
    var embeddBannerConfig: EmbeddBannerDynaconConfig? { get }
    
    var favoriteToastConfig: FavoriteToastConfig? { get }
    
    var didRequestForInstantInteraction: InstantInteractionModel? { get }
    
    var gameTileItemsConfiguration: GameTileItemsConfiguration? { get }

    var searchConfiguration: SearchConfiguration? { get }
}

public protocol LobbyDataSourceOptionals {
    
        /// This method will invoked before calling reloading the lobby
        /// Expected Boolean value in return i.e. true to call feed api and refesh lobby and false to update views
    func shouldRefetchLobbyMetaData() -> Bool
    
    /// This method will invoked before loading the game to confirm play mode
    /// Valid for some labels such as Italy
    func shouldAskPlayMode() -> Bool
    
    func shouldFetchJackpotInfo() -> Bool
            
    func didRequestForODRTagSuffix(for provider: String) -> String?
        
    func shouldDisplayView(of type: CLCustomViewType) -> Bool
    
    func didRequestForSearchTilePosition() -> Int
    
    func shouldIncludeRefreshControl() -> Bool
    
    func enableVoiceSearch() -> Bool
}
