//
//  CasinoDatasource.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 19/07/23.
//

import Foundation

///Properties used by all frameworks
public protocol CasinoDatasource {

    var didRequestResponsibleGamingImageUrl: String? { get }
    
    var didRequestResponsibleGamingNavigationUrl: String? { get }
    
    var vendorBasedGeoVariants: [String : String]? { get }
    
    var dynaconFeed: [String : Any]? { get }
            
    var gameDirectoryVendorsPath: [String]? { get }
    
    var didRequestForCasinoCss: LobbyCSS? { get }

    func didRequestforRTMSServerURL(for type: RtmsServerUrlType) -> String?
    
    func didRequestForLoginSessionTime() -> Int?
    
    func didRequestCurrentStateCurrency() -> String?
        
    func didRequestSlotSessionTimer(for type: SlotSessionType) -> String?
    
    func didRequestVersionForEasyNav() -> Int?
}
