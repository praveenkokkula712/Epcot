//
//  LobbyProtocols.swift
//  Utility
//
//  Created by Praveen Kokkula on 26/07/22.
//

import Foundation
import UIKit

public protocol Lobby {
    
        /// This method will load the lobby with provided CSS and returns lobby view in completion handler
        /// - Parameters:
        ///   - game: Game variant name to be loaded.
        ///   - completion: CompletionHandler
    func load(game: String?, completion: ((UIView?) -> Void))
    
        /// This method will check and load game if available else shows error
    func load(game: String, additionalParams: AdditionalParameters?)
    
        /// This method will refresh the lobby
    func reload()
    
    func onLoggedIn()
    
        /// This method will unload the Lobby from superview added
    func unload()
    
        // This method will redirect the user directly to lobby. It will close the game if any loaded and redirect to lobby
    func navigateToLobby()
    
    func didUpdateWOFGamesSelectedFromMenu(with category: String)
    
    func closeGameWindowIfNeeded(completion: @escaping () -> Void)
    
        ///This method will get get called when Weblink category page has been closed
    func didCloseCategoryWeblinkView()
    
    //This method is used to handle the play and pause the video
    func videoPlayHandler(isWindowClosed: Bool)
    
    func scrollGamesViewToTop()
    
    func didUpdateLocalizaedStrings()
    
    func didUpdateSiteCoreModels()
    
    func loadDeepLinkUrl(url: String)
    
}
