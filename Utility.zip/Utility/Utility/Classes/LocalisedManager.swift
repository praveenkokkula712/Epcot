//
//  LocalisedManager.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 21/07/23.
//

import Foundation

public class LocalisedManager {
    
    public static let shared = LocalisedManager()
    
    private init() { }
    
    private let dispatchQueue = DispatchQueue(label: "com.entain.localisedStrings", attributes: .concurrent)
    
    private var localizationStrings: [String : Any] = [:]
    
    public func updateStrings(with strings: [String: Any]) {
        dispatchQueue.async(flags: .barrier) {
            self.localizationStrings.merge(strings) { _, value in
                value
            }
        }
    }
    
    public func getString(key: String) -> String? {
        var result: String?
        dispatchQueue.sync {
            result = self.localizationStrings[key] as? String ?? nil
        }
        return result
    }
    
}
