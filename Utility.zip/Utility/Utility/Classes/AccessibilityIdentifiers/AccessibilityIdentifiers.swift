//
//  AccessibilityIdentifiers.swift
//  Utility
//
//  Created by Santhosh Kodadi on 06/12/23.
//

import Foundation

public enum AccessibilityIdentifiers: String {
    
    //MARK: LobbyHeaderView
    case lobbyHeader_contentView                = "LobbyHeader_ContentView"
    case lobbyHeader_joinButton                 = "LobbyHeader_JoinButton"
    case lobbyHeader_loginButton                = "LobbyHeader_LoginButton"
    case lobbyHeader_depositButton              = "LobbyHeader_DepositButton"
    case lobbyHeader_logoImageView              = "LobbyHeader_LogoImageView"
    case lobbyHeader_pointsStackView            = "LobbyHeader_PointsStackView"
    case lobbyHeader_coinIconImage              = "LobbyHeader_CoinIconImage"
    case lobbyHeader_coinBalanceLabel           = "LobbyHeader_CoinBalanceLabel"
    case lobbyHeader_preLoginView               = "LobbyHeader_PreLoginView"
    case lobbyHeader_menuButton                 = "LobbyHeader_MenuButton"
    case lobbyHeader_notificationLabel          = "LobbyHeader_NotificationLabel"
    case lobbyHeader_userNameLabel              = "LobbyHeader_UserNameLabel"
    case lobbyHeader_balanceLabel               = "LobbyHeader_BalanceLabel"
    case lobbyHeader_postLoginView              = "LobbyHeader_PostLoginView"
    case lobbyHeader_rgLogoButton               = "LobbyHeader_RgLogoButton"
    case lobbyHeader_postLoginRgLogoButton      = "LobbyHeader_PostLoginRgLogoButton"
    case lobbyHeader_kycBannerView              = "LobbyHeader_KycBannerView"
    case lobbyHeader_dynamicHeaderView          = "LobbyHeader_DynamicHeaderView"
    case lobbyHeader_preLoginCoinIconImage      = "LobbyHeader_PreLoginCoinIconImage"
    case lobbyHeader_preLoginCoinStackView      = "LobbyHeader_PreLoginCoinStackView"
    
    //MARK: OSPrimers
    case osPrimers_contentView                  = "OSPrimers_ContentView"
    case osPrimers_popUpView                    = "OSPrimers_PopUpView"
    case osPrimers_lblTitle                     = "OSPrimers_TitleLabel"
    case osPrimers_btnClose                     = "OSPrimers_CloseButton"
    case osPrimers_imgViewLogo                  = "OSPrimers_LogoImageView"
    case osPrimers_lblDesc                      = "OSPrimers_DescLabel"
    case osPrimers_btnLater                     = "OSPrimers_LaterButton"
    case osPrimers_btnAllow                     = "OSPrimers_AllowButton"
    case osPrimers_viewTopHeader                = "OSPrimers_ViewTopHeader"
    
    //MARK: BiomtericAlertView
    case biometricAlert_headerView              = "BiometricAlert_HeaderView"
    case biometricAlert_checkView               = "BiometricAlert_CheckView"
    case biometricAlert_containerView           = "BiometricAlert_ContainerView"
    case biometricAlert_imageLabel              = "BiometricAlert_ImageLabel"
    case biometricAlert_titleLabel              = "BiometricAlert_TitleLabel"
    case biometricAlert_messageLabel            = "BiometricAlert_MessageLabel"
    case biometricAlert_closeIconLabel          = "BiometricAlert_CloseIconLabel"
    case biometricAlert_noThanksButton          = "BiometricAlert_NoThanksButton"
    case biometricAlert_useBiometricButton      = "BiometricAlert_UseBiometricButton"
    
    //MARK: RTA
    case rta_goodTimeView                       = "RTA_GoodTimeView"
    case rta_goodTimeHeaderLabel                = "RTA_GoodTimeHeaderLabel"
    case rta_goodTimeSubHeaderLabel1            = "RTA_GoodTimeSubHeaderLabel1"
    case rta_goodTimeSubHeaderLabel2            = "RTA_GoodTimeSubHeaderLabel2"
    case rta_needsImprovedButton                = "RTA_NeedsImprovedButton"
    case rta_goodTimeButton                     = "RTA_GoodTimeButton"
    case rta_feedbackSuccessView                = "RTA_FeedbackSuccessView"
    case rta_feedbackSuccessHeaderLabel         = "RTA_FeedbackSuccessHeaderLabel"
    case rta_feedbackSuccessSubHeaderLabel      = "RTA_FeedbackSuccessSubHeaderLabel"
    case rta_feedbackSuccessImageLabel          = "RTA_FeedbackSuccessImageLabel"
    case rta_feedbackRatingView                 = "RTA_FeedbackRatingView"
    case rta_starRatingView                     = "RTA_StarRatingView"
    case rta_feedbackRatingHeaderLabel          = "RTA_FeedbackRatingHeaderLabel"
    case rta_feedbackRatingSubHeaderLabel       = "RTA_FeedbackRatingSubHeaderLabel"
    case rta_feedbackRatingComment              = "RTA_FeedbackRatingComment"
    case rta_feedbackButton                     = "RTA_FeedbackButton"
    case rta_goodTimeSheetHandleLabel           = "RTA_GoodTimeSheetHandleLabel"
    case rta_feedbackSheetHandleLabel           = "RTA_FeedbackSheetHandleLabel"
    case rta_feedbackSuccessSheetHandleLabel    = "RTA_FeedbackSuccessSheetHandleLabel"
    
    //RTA 3
    case rta_rateTheAppView                     = "RTA_RateTheAppView"
    case rta_headerView                         = "RTA_HeaderView"
    case rta_headerCloseBtn                     = "RTA_HeaderCloseBtn"
    case rta_goodTimeImage                      = "RTA_GoodTimeImage"
    case rta_feedbackSuccessAnimationView       = "RTA_FeedbackSuccessAnimationView"
    
    //RTA 4
    case rta_feedbackSuccessImage               = "RTA_FeedbackSuccessImage"
    case rta_feedbackSuccessDoneButton          = "RTA_FeedbackSuccessDoneButton"
    
    //Feedback Like/Dislike View
    case rta_alertView                          = "RTA_AlertView"
    case rta_likesHeaderView                    = "RTA_LikesHeaderView"
    case rta_feedbackHeaderView                 = "RTA_FeedbackHeaderView"
    case rta_likesView                          = "RTA_LikesView"
    case rta_feedbackView                       = "RTA_FeedbackView"
    case rta_LVTitleLabel                       = "RTA_LVTitleLabel"
    case rta_LVMessageLabel                     = "RTA_LVMessageLabel"
    case rta_FVTitleLabel                       = "RTA_FVTitleLabel"
    case rta_FVMessageLabel                     = "RTA_FVMessageLabel"
    case rta_textView                           = "RTA_TextView"
    case rta_lv_feedbackButton                  = "RTA_LV_FeedbackButton"
    case rta_placeHolderLabel                   = "RTA_PlaceHolderLabel"
    case rta_likeButton                         = "RTA_LikeButton"
    case rta_dislikeButton                      = "RTA_DislikeButton"
    case rta_closeButton                        = "RTA_CloseButton"
    case rta_clearHeaderView                    = "RTA_ClearHeaderView"
    
    //PreciseLocationViewController
    case precise_vc_descriptionLabel            = "Precise_VC_DescriptionLabel"
    case precise_vc_enableButton                = "Precise_VC_EnableButton"
    case precise_vc_preciseLocationImageView    = "Precise_VC_PreciseLocationImageView"
    case precise_vc_closeButton                 = "Precise_VC_CloseButton"
    case precise_vc_preciseLocationLabel        = "Precise_VC_PreciseLocationLabel"
    case precise_vc_containerView               = "Precise_VC_ContainerView"
    case precise_vc_viewTopHeader               = "Precise_VC_ViewTopHeader"
    
    //PreciseLocationPopUp
    case precise_descriptionLabel               = "Precise_DescriptionLabel"
    case precise_preciseLocationLabel           = "Precise_PreciseLocationLabel"
    case precise_locationImage                  = "Precise_LocationImage"
    case precise_enableButton                   = "Precise_EnableButton"
    
    //Search
    case search_clearButton                     = "Search_ClearButton"
    case search_textField                       = "Search_TextField"
    case search_searchView                      = "Search_SearchView"
    case search_container                       = "Search_Container"
    case search_hintLabel                       = "Search_HintLabel"
    case search_resultLabel                     = "Search_ResultLabel"
    case search_noDataView                      = "Search_NoDataView"
    case search_noDataIcon                      = "Search_NoDataIcon"
    case search_noDataLabel                     = "Search_NoDataLabel"
    case search_backButton                      = "Search_BackButton"
    case search_shadowView                      = "Search_ShadowView"
    case search_headerTitleView                 = "Search_HeaderTitleView"
    case search_searchLabel                     = "Search_SearchLabel"
    case search_titleHeaderBackButton           = "Search_TitleHeaderBackButton"
    case search_resultsView                     = "Search_ResultsView"
    case search_favouriteToastView              = "Search_FavouriteToastView"
    
    //New Soft Update
    case new_softupdate_contentView             = "New_Soft_Update_ContentView"
    case new_softupdate_viewPopUp               = "New_Soft_Update_ViewPopUp"
    case new_softupdate_closeButton             = "New_Soft_Update_CloseButton"
    case new_softupdate_titleLabel              = "New_Soft_Update_TitleLabel"
    case new_softupdate_messageLabel            = "New_Soft_Update_MessageLabel"
    case new_softupdate_logoImageView           = "New_Soft_Update_LogoImageView"
    case new_softupdate_downloadButton          = "New_Soft_Update_DownloadButton"
    case new_softupdate_ignoreButton            = "New_Soft_Update_IgnoreButton"
    
    //Custom PopUp
    case custom_alert_contentView               = "Custom_Alert_ContentView"
    case custom_alert_closeButton               = "Custom_Alert_CloseButton"
    case custom_alert_titleLabel                = "Custom_Alert_TitleLabel"
    case custom_alert_subTitleLabel             = "Custom_Alert_ViewPopUp"
    case custom_alert_logoImageView             = "Custom_Alert_LogoImageView"
    case custom_alert_downloadButton            = "Custom_Alert_DownloadButton"
    case custom_alert_ignoreButton              = "Custom_Alert_IgnoreButton"
    
    //Maintenance
    case maintenance_logoView                   = "Maintenance_LogoView "
    case maintenance_titleLabel                 = "Maintenance_TitleLabel"
    case maintenance_messageLabel               = "Maintenance_MessageLabel"
    case maintenance_actionButton               = "Maintenance_ActionButton"
    case maintenance_copyrightLabel             = "Maintenance_CopyrightLabel"
    case maintenance_headerView                 = "Maintenance_HeaderView"
    case maintenance_contentView                = "Maintenance_ContentView"
    case maintenance_newForceUpdateView         = "Maintenance_NewForceUpdateView"
    case maintenance_forceUpdateView            = "Maintenance_ForceUpdateView "
    case maintenance_downloadUpdateButton       = "Maintenance_DownloadUpdateButton"
    case maintenance_updateTitleLabel           = "Maintenance_UpdateTitleLabel"
    case maintenance_updateInfoLabel            = "Maintenance_UpdateInfoLabel"
    case maintenance_versionTitleLabel          = "Maintenance_VersionTitleLabel"
    case maintenance_versionInfoLabel           = "Maintenance_VersionInfoLabel"
    case maintenance_forceUpdateImg             = "Maintenance_ForceUpdateImg"
    case maintenance_activityIndicator          = "Maintenance_ActivityIndicator"
    case maintenance_warningTypeLabel           = "Maintenance_WarningTypeLabel"
    case maintenance_maintenanceView            = "Maintenance_MaintenanceView"
    case maintenance_maintenanceBrandLogo       = "Maintenance_MaintenanceBrandLogo"
    case maintenance_maintenanceWarningLogo     = "Maintenance_MaintenanceWarningLogo"
    case maintenance_maintenanceTitleLabel      = "Maintenance_MaintenanceTitleLabel"
    case maintenance_maintenanceMessageLabel    = "Maintenance_MaintenanceMessageLabel"
    case maintenance_maintenanceCopyRightLabel  = "Maintenance_MaintenanceCopyRightLabel"
    case maintenance_forceUpdateAppIcon         = "Maintenance_ForceUpdateAppIcon "
    case maintenance_forceUpdateWarningView     = "Maintenance_ForceUpdateWarningView"
    case maintenance_forceUpdateWarningLabel    = "Maintenance_ForceUpdateWarningLabel"
    case maintenance_forceUpdateTitleLabel      = "Maintenance_ForceUpdateTitleLabel"
    case maintenance_forceUpdateDespLabel       = "Maintenance_ForceUpdateDespLabel"
    case maintenance_forceUpdateCopyRightLabel  = "Maintenance_ForceUpdateCopyRightLabel"
    case maintenance_forceUpdateDownloadButton  = "Maintenance_ForceUpdateDownloadButton"
    
    //Epcot Lobby View
    case epcotlobby_searchContainerView         = "EpcotLobbyVC_SearchContainerView"
    case epcotlobby_filterContainerView         = "EpcotLobbyVC_filterContainerView"
    case epcotlobby_mainContentView             = "EpcotLobbyVC_mainContentView"
    case epcotlobby_categoryContentView         = "EpcotLobbyVC_categoryContentView"
    case epcotlobby_favoriteToastView           = "EpcotLobbyVC_favoriteToastView"
    case epcotlobby_bottomSearchContainerView   = "EpcotLobbyVC_bottomSearchContainerView"
    case epcotlobby_searchBottomButton          = "EpcotLobbyVC_searchBottomButton"
    
    //Epcot Banner Cell
    case epcotBanner_backgroundImageView        = "EpcotBanner_BackgroundImageView"
    case epcotBanner_containerView              = "EpcotBanner_ContainerView"
    case epcotBanner_stackViewImageTextHolder   = "EpcotBanner_StackViewImageTextHolder"
    case epcotBanner_teaserImageView            = "EpcotBanner_TeaserImageView"
    case epcotBanner_viewTextHolder             = "EpcotBanner_ViewTextHolder"
    case epcotBanner_teaserTitleLabel           = "EpcotBanner_TeaserTitleLabel"
    case epcotBanner_teaserSubTitleLabel        = "EpcotBanner_TeaserSubTitleLabel"
    case epcotBanner_teaserCtaButton            = "EpcotBanner_TeaserCtaButton"
    case epcotBanner_labelTerms                 = "EpcotBanner_LabelTerms"
    case epcotBanner_stackViewTextContent       = "EpcotBanner_StackViewTextContent"
    
    //Epcot Embedded Banner
    case epcotEmbeddedBanner_containerView      = "EpcotEmbeddedBanner_ContainerView"
    case epcotEmbeddedBanner_imageView          = "EpcotEmbeddedBanner_ImageView"
    case epcotEmbeddedBanner_labelTitle         = "EpcotEmbeddedBanner_LabelTitle"
    case epcotEmbeddedBanner_labelSubTitle      = "EpcotEmbeddedBanner_LabelSubTitle"
    case epcotEmbeddedBanner_buttonBanner       = "EpcotEmbeddedBanner_ButtonBanner"
    
    
    //Epcot Banner Video Cell
    case epcotBannerVideo_containerView      = "EpcotBannerVideo_containerView"
    case epcotBannerVideo_imageView          = "EpcotBannerVideo_imageView"
    case epcotBannerVideo_speakerButton      = "EpcotBannerVideo_speakerButton"
    case epcotBannerVideo_playVideoButton    = "EpcotBannerVideo_playVideoButton"
    case epcotBannerVideo_videoPlayerView    = "EpcotBannerVideo_videoPlayerView"
    
    //Switcher Category PopUp
    case switcherCategoryPopUp_tableViewCategories   = "SwitcherCategoryPopUp_TableViewCategories"
    case switcherCategoryPopUp_labelHeaderTitle      = "SwitcherCategoryPopUp_LabelHeaderTitle"
    case switcherCategoryPopUp_labelCategoriesTitle  = "SwitcherCategoryPopUp_LabelCategoriesTitle"
    case switcherCategoryPopUp_buttonApply           = "SwitcherCategoryPopUp_ButtonApply"
    case switcherCategoryPopUp_categoriesContainerView = "SwitcherCategoryPopUp_CategoriesContainerView"
    
    //Switcher Categpry Header
    case switcherCategoryHeader_labelHeaderTitle = "SwitcherCategoryHeader_LabelHeaderTitle"
    case switcherCategoryHeader_lobbySwitcherButton = "SwitcherCategoryHeader_LobbySwitcherButton"
    case switcherCategoryHeader_buttonCategoryTitle = "SwitcherCategoryHeader_ButtonCategoryTitle"
    
    //Switcher Category PopUp TableViewCell
    case switcherCategoryTable_labelTitle               = "SwitcherCategoryTable_LabelTitle"
    case switcherCategoryTable_categorySelectionImage   = "SwitcherCategoryTable_CategorySelectionImage"
    
    //Epcot Game Cell
    case epcotGameCell_priceHolderView                  = "EpcotGameCell_PriceHolderView"
    case epcotGameCell_imageViewGameDownloaded          = "EpcotGameCell_ImageViewGameDownloaded"
    case epcotGameCell_priceLabel                       = "EpcotGameCell_PriceLabel"
    case epcotGameCell_gameImage                        = "EpcotGameCell_GameImage"
    case epcotGameCell_priceImage                       = "EpcotGameCell_PriceImage"
    case epcotGameCell_viewOpaque                       = "EpcotGameCell_ViewOpaque"
    case epcotGameCell_favouriteButton                  = "EpcotGameCell_FavouriteButton"
    case epcotGameCell_stickerLabel                     = "EpcotGameCell_StickerLabel"
    case epcotGameCell_priceRangeLabel                  = "EpcotGameCell_PriceRangeLabel"
    case epcotGameCell_footerTitleLabel                 = "EpcotGameCell_FooterTitleLabel"
    case epcotGameCell_footerOpaqueView                 = "EpcotGameCell_FooterOpaqueView"
    case epcotGameCell_footerStackView                  = "EpcotGameCell_FooterStackView"
    //Game List View
    case gamelistView_gameBlurImageView                 = "GamelistView_GameBlurImageView"
    case gamelistView_gameSquareImageView               = "GamelistView_GameSquareImageView"
    case gamelistView_gameImageContainerView            = "GamelistView_GameImageContainerView"
    case gamelistView_buttonGameDownload                = "GamelistView_ButtonGameDownload"
    case gamelistView_favouriteButton                   = "GamelistView_FavouriteButton"
    case gamelistView_labelGameTitle                    = "GamelistView_LabelGameTitle"
    case gamelistView_labelJackpotAmount                = "GamelistView_LabelJackpotAmount"
    case gamelistView_stickerLabel                      = "GamelistView_StickerLabel"
    
    //See More CollectionView
    case seemoreCollection_titleLabel                   = "SeemoreCollection_TitleLabel"
    case seemoreCollection_descriptionLabel             = "SeemoreCollection_descriptionLabel"
    case seemoreCollection_infoButton                   = "SeemoreCollection_infoButton"
    case seemoreCollection_seeMoreButton                = "SeemoreCollection_SeeMoreButton"
    case seemoreCollection_seeMoreArrowButton           = "SeemoreCollection_SeeMoreArrowButton"
    case seemoreCollection_buttonView                   = "SeemoreCollection_ButtonView"
    
    //See More Section
    case seemoreSection_collectionHolderView            = "SeemoreSection_CollectionHolderView"
    case seemoreSection_tiltleView                      = "SeemoreSection_TiltleView"
    case seemoreSection_headerView                      = "SeemoreSection_HeaderView"
    case seemoreSection_titleLabel                      = "SeemoreSection_TitleLabel"
    case seemoreSection_gridButton                      = "SeemoreSection_GridButton"
    case seemoreSection_listButton                      = "SeemoreSection_ListButton"
    case seemoreSection_backButton                      = "SeemoreSection_BackButton"
    case seemoreSection_priceLabel                      = "SeemoreSection_PriceLabel"
    case seemoreSection_jpGamesTitleLabel               = "SeemoreSection_JpGamesTitleLabel"
    case seemoreSection_favouriteToastView              = "SeemoreSection_FavouriteToastView"
    
    //Jackpot Widget Collection
    case jackpotwidgetcollection_backgroundImageView    = "Jackpotwidgetcollection_BackgroundImageView"
    case jackpotwidgetcollection_jackpotImageView       = "Jackpotwidgetcollection_JackpotImageView"
    case jackpotwidgetcollection_labelJackpotTitle      = "Jackpotwidgetcollection_LabelJackpotTitle"
    case jackpotwidgetcollection_labelJackpotPrice      = "Jackpotwidgetcollection_LabelJackpotPrice"
    
    //Must Go Collection
    case mustgocollection_backgroundImageView           = "Mustgocollection_BackgroundImageView"
    case mustgocollection_jackpotImageView              = "Mustgocollection_JackpotImageView"
    case mustgocollection_viewMega                      = "Mustgocollection_ViewMega"
    case mustgocollection_viewDaily                     = "Mustgocollection_ViewDaily"
    case mustgocollection_viewHourly                    = "Mustgocollection_ViewHourly"
    case mustgocollection_labelMega                     = "Mustgocollection_LabelMega"
    case mustgocollection_labelDaily                    = "Mustgocollection_LabelDaily"
    case mustgocollection_labelHourly                   = "Mustgocollection_LabelHourly"
    case mustgocollection_labelMegaPrice                = "Mustgocollection_LabelMegaPrice"
    case mustgocollection_labelDailyPrice               = "Mustgocollection_LabelDailyPrice"
    case mustgocollection_labelHourlyPrice              = "Mustgocollection_LabelHourlyPrice"
    
    //Epcot Menu
    case epcotmenu_collectionView                       = "Epcotmenu_CollectionView"
    case epcotmenu_buttonDone                           = "Epcotmenu_ButtonDone"
    case epcotmenu_menuHeaderView                       = "Epcotmenu_MenuHeaderView"
    case epcotmenu_casinoLbl                            = "Epcotmenu_CasinoLbl"
    case epcotmenu_headerSeperatorView                  = "Epcotmenu_HeaderSeperatorView"
    case epcotmenu_dismissButton                        = "Epcotmenu_DismissButton"
    
    //App Promotion Collection
    case apppromotion_imageViewIcon                     = "Apppromotion_ImageViewIcon"
    case apppromotion_labelTitle                        = "Apppromotion_LabelTitle"
    case apppromotion_labelDescription                  = "Apppromotion_LabelDescription"
    
    //Epcot Menu Custom Cell
    case epcotmenucustom_titleLabel                     = "Epcotmenucustom_TitleLabel"
    case epcotmenucustom_viewSeparator                  = "Epcotmenucustom_TiewSeparator"
    case epcotmenucustom_arrowIcon                      = "Epcotmenucustom_ArrowIcon"
    case epcotmenucustom_svgImageView                   = "Epcotmenucustom_SvgImageView"
    case epcotmenucustom_labelIcon                      = "Epcotmenucustom_LabelIcon"
    
    //Epcot Recommendation Collection
    case epcotrecommendation_labelTitle                 = "Epcotrecommendation_LabelTitle"
    case epcotrecommendation_imageViewArrow             = "Epcotrecommendation_ImageViewArrow"
    case epcotrecommendation_viewSeparator              = "Epcotrecommendation_ViewSeparator"
    
    //Epcot Search
    case epcotsearch_viewTitle                          = "EpcotSearch_ViewTitle"
    case epcotsearch_labelTitle                         = "EpcotSearch_LabelTitle"
    case epcotsearch_buttonDone                         = "EpcotSearch_ButtonDone"
    case epcotsearch_clearButton                        = "EpcotSearch_ClearButton"
    case epcotsearch_textField                          = "EpcotSearch_TextField"
    case epcotsearch_searchView                         = "EpcotSearch_SearchView"
    case epcotsearch_container                          = "EpcotSearch_Container"
    case epcotsearch_noDataView                         = "EpcotSearch_NoDataView"
    case epcotsearch_noDataIcon                         = "EpcotSearch_NoDataIcon"
    case epcotsearch_noDataLabel                        = "EpcotSearch_NoDataLabel"
    case epcotsearch_iconSearch                         = "EpcotSearch_IconSearch"
    case epcotsearch_headerSeperatorView                = "EpcotSearch_HeaderSeperatorView"
    case epcotsearch_topContainerView                   = "EpcotSearch_TopContainerView"
    case epcotsearch_searchResultLabel                  = "EpcotSearch_SearchResultLabel"
    case epcotsearch_favouriteToastView                 = "EpcotSearch_FavouriteToastView"
    
    //Epcot Lobby Search
    case epcotlobbysearch_viewContainer                 = "Epcotlobbysearch_ViewContainer"
    case epcotlobbysearch_stackViewContainer            = "Epcotlobbysearch_StackViewContainer"
    case epcotlobbysearch_buttonSearch                  = "Epcotlobbysearch_ButtonSearch"
    case epcotlobbysearch_buttonMenu                    = "Epcotlobbysearch_ButtonMenu"
    case epcotlobbysearch_buttonMic                     = "Epcotlobbysearch_ButtonMic"
    
    //Lobby Search
    case lobbysearch_viewContainer                      = "Lobbysearch_ViewContainer"
    case lobbysearch_buttonMic                          = "Lobbysearch_ButtonMic"
    case lobbysearch_viewSearchContainer                = "Lobbysearch_ViewSearchContainer"
    case lobbysearch_buttonSearchHolder                 = "Lobbysearch_ButtonSearchHolder"
    case lobbysearch_menuButton                         = "Lobbysearch_MenuButton"
    case lobbysearch_menuViewContainer                  = "Lobbysearch_MenuViewContainer"

    //New Search Input Header
    case newsearchinput_searchTextField                 = "Newsearchinput_SearchTextField"
    case newsearchinput_buttonMic                       = "Newsearchinput_ButtonMic"
    case newsearchinput_searchButton                    = "Newsearchinput_SearchButton"
    case newsearchinput_viewSearchContainer             = "Newsearchinput_ViewSearchContainer"

    //Suggestion Cell
    case suggestioncell_suggestionLabel                 = "Suggestioncell_SuggestionLabel"
    case suggestioncell_searchButton                    = "Suggestioncell_SearchButton"
    
    //Teaser Video
    case teaservideo_containerView                      = "Teaservideo_ContainerView"
    case teaservideo_speakerButton                      = "Teaservideo_SpeakerButton"
    case teaservideo_playNowButton                      = "Teaservideo_PlayNowButton"
    case teaservideo_imageView                          = "Teaservideo_ImageView"
    case teaservideo_playVideoButton                    = "Teaservideo_VideoPlayButton"

    //Force Update V2
    case forceUpdateV2_headerView                       = "ForceUpdateV2_HeaderView"
    case forceUpdateV2_logoView                         = "ForceUpdateV2_LogoView"
    case forceUpdateV2_forceUpdateView                  = "ForceUpdateV2_ForceUpdateView"
    case forceUpdateV2_forceUpdateAppIcon               = "ForceUpdateV2_ForceUpdateAppIcon"
    case forceUpdateV2_forceUpdateWarningView           = "ForceUpdateV2_ForceUpdateWarningView"
    case forceUpdateV2_forceUpdateWarningLabel          = "ForceUpdateV2_ForceUpdateWarningLabel"
    case forceUpdateV2_forceUpdateTitleLabel            = "ForceUpdateV2_ForceUpdateTitleLabel"
    case forceUpdateV2_forceUpdateDespLabel             = "ForceUpdateV2_ForceUpdateDespLabel"
    case forceUpdateV2_forceUpdateCopyRightLabel        = "ForceUpdateV2_ForceUpdateCopyRightLabel"
    case forceUpdateV2_forceUpdateDownloadButton        = "ForceUpdateV2_ForceUpdateDownloadButton"
    
    //Force Update V3
    case forceUpdateV3_newForceUpdateView               = "ForceUpdateV3_NewForceUpdateView"
    case forceUpdateV3_downloadUpdateButton             = "ForceUpdateV3_DownloadUpdateButton"
    case forceUpdateV3_updateTitleLabel                 = "ForceUpdateV3_UpdateTitleLabel"
    case forceUpdateV3_updateInfoLabel                  = "ForceUpdateV3_UpdateInfoLabel"
    case forceUpdateV3_versionTitleLabel                = "ForceUpdateV3_VersionTitleLabel"
    case forceUpdateV3_versionInfoLabel                 = "ForceUpdateV3_VersionInfoLabel"
    case forceUpdateV3_forceUpdateImg                   = "ForceUpdateV3_ForceUpdateImg"
    
    //Force Update V4
    case forceUpdateV4_bgImageView                      = "ForceUpdateV4_BgImageView"
    case forceUpdateV4_bottomSafeAreaView               = "ForceUpdateV4_BottomSafeAreaView"
    case forceUpdateV4_forceUpdateTitleLabel            = "ForceUpdateV4_ForceUpdateTitleLabel"
    case forceUpdateV4_forceUpdateDespLabel             = "ForceUpdateV4_ForceUpdateDespLabel"
    case forceUpdateV4_forceUpdateDownloadButton        = "ForceUpdateV4_ForceUpdateDownloadButton"
    case forceUpdateV4_copyrightLabel                   = "ForceUpdateV4_CopyrightLabel"
}
