//
//  CasinoStoriesAccessibilityIdentifiers .swift
//  Utility
//
//  Created by Sindhuja Vedire on 16/01/24.
//

import Foundation

public struct CasinoStoriesAccessibilityIdentifiers  {
    
    public let gameStoriesView           = "CasinoStoriesView"
    
    public let casinoStoriesHeader       = "CasinoStories_HeaderTitle"
    public let mainStoryImage            = "CasinoStories_MainStoryImage"
    public let mainStoryTitle            = "CasinoStories_MainStoryTitle"
    public let arrowButton               = "CasinoStories_ArrowButton"
    public let progressBar               = "CasinoStories_ProgressBar"
    public let progressFillBar           = "CasinoStories_ProgressFillBar"
    public let storyCloseButton          = "CasinoStories_CloseButton"
    public let storyImage                = "CasinoStories_StoryImage"
    public let storyTitle                = "CasinoStories_StoryTitle"
    public let storyDescription          = "CasinoStories_StoryDescription"
    public let playNowButton             = "CasinoStories_PlayNowButton"
    public let optInButton               = "CasinoStories_OptInButton"
    public let seeMoreButton             = "CasinoStories_SeeMoreButton"
    public let seeMoreText               = "CasinoStories_SeeMoreText"
    public let legalTermsView            = "CasinoStories_LegalTermsView"
    public let legalTermsText            = "CasinoStories_LegalTermsText"
    
    //casinoStoryOnboarding
    public let onboardingLogo            = "CasinoStories_OnboardingLogo"
    public let onboardingTitle           = "CasinoStories_OnboardingTitle"
    public let onboardingSubTitle        = "CasinoStories_OnboardingSubTitle"
    public let swipeLeftGestureHintIcon  = "CasinoStories_SwipeLeftGestureHintIcon"
    public let swipeRightGestureHintIcon = "CasinoStories_SwipeRightGestureHintIcon"
    public let touchHoldGestureHintIcon  = "CasinoStories_TouchHoldGestureHintIcon"
    public let swipeLeftGestureHintText  = "CasinoStories_SwipeLeftGestureHintText"
    public let swipeRightGestureHintText = "CasinoStories_SwipeRightGestureHintText"
    public let touchHoldGestureHintText  = "CasinoStories_TouchHoldGestureHintText"
    
    public init() {
        
    }
}
