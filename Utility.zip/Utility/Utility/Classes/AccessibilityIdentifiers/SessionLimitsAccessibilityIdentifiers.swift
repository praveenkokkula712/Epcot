//
//  SessionLimitsAccessibilityIdentifiers.swift
//  CasinoCore
//
//  Created by Sreekanth Reddy Tadi on 12/06/24.
//

import Foundation

public struct SessionLimitsAccessibilityIdentifiers {
    
    public let backgroundTouchArea  = "session_limits_background_touch_area"
    public let headerTitle          = "session_limits_header_title"
    public let time                 = "session_limits_time"
    public let timeNotation         = "session_limits_time_notation"
    public let message              = "session_limits_message"
    public let adjustLimitsText     = "session_limits_adjust_limits_text"
    public let adjustLimitsButton   = "session_limits_adjust_limits_button"
    public let continuePlayText     = "session_limits_continue_text"
    public let continuePlayButton   = "session_limits_continue_button"
    
    public init() { }
}
