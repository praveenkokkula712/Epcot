//
//  UserDefaults+Shortcut.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 21/08/23.
//

import Foundation

@propertyWrapper
public struct UserDefaultStandard<Value> {
    let key: String
    let userDefaults: UserDefaults
    let defaultValue: Value

    public var wrappedValue: Value {
        get { userDefaults.value(forKey: key) as? Value ?? defaultValue }
        set { userDefaults.set(newValue, forKey: key) }
    }

    fileprivate init(
        wrappedValue: Value,
        key: String,
        userDefaults: UserDefaults
    ) {
        self.key = key
        self.userDefaults = userDefaults
        self.defaultValue = wrappedValue
    }
}

extension UserDefaultStandard where Value: ExpressibleByNilLiteral {
    public init(key: String, storage: UserDefaults = .standard) {
        self.init(wrappedValue: nil, key: key, userDefaults: storage)
    }
}
