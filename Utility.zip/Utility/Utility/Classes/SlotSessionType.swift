//
//  SlotSessionType.swift
//  Utility
//
//  Created by Praveen Kokkula on 26/07/22.
//

import Foundation

@objc public enum SlotSessionType: Int {
    case maxTime
    case frequencyTime
}
