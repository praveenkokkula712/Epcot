//
//  LobbyCustomViewType.swift
//  Utility
//
//  Created by Praveen Kokkula on 26/07/22.
//

import Foundation


@objc public enum CLCustomViewType: Int {
    case searchMoreTile
    case exploreLobbyView
    case recentlyPlayedGamesView
    case searchBarWithMenu
    case favouriteGamesView
    case searchButtonEnabled
    case playerStatsView
    case originalsWidgetView
}
