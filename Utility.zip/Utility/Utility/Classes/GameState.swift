//
//  GameState.swift
//  Utility
//
//  Created by Praveen Kokkula on 26/07/22.
//

import Foundation

public enum GameState: Int {
    
    case loading    // game starts loading
    case loaded     // game is loaded and displayed
    case active     // game play is active
    case idle       // game is loaded but not active
    case unloading  // game starts unloading
    case unloaded   // game unloaded successfully
    case progress   // game play is in progress
    case completed  // game play is completed
}
