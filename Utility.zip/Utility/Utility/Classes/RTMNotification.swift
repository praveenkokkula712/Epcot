//
//  RTMNotification.swift
//  Utility
//
//  Created by Praveen Kokkula on 27/10/22.
//

import Foundation

@objcMembers public class RTMNotification: NSObject {
     public var eventId: String = ""
     public var type: String = ""
     public var payload: String = ""
    
}

