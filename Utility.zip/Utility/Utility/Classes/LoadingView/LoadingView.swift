
//
//  LoadingView.swift
//  CasinoGames
//
//  Created by Sumeet Bajaj on 24/08/2019.
//  Copyright © 2019 Ivy Comptech. All rights reserved.
//

import UIKit

class LoadingView: UIView {
    
    @IBOutlet weak var activity:UIActivityIndicatorView!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var progressView:UIProgressView!
    @IBOutlet weak var label:UILabel!
    
    var didClickedCanceButton: (() -> Void)? {
      
        didSet {
            self.cancelButton.isHidden = false
        }
    }

    class func initialise(canceOption: Bool = false) -> LoadingView? {
        
        guard let aView = LoadingView.loadFromNib("Loading", Bundle(for: LoadingView.self)) else {
            
            return nil
        }
        
        aView.update(message: "Loading...".localized(), progress: 0)
        aView.cancelButton.isHidden = true
        return aView
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // setup css
        let tintColor = Loader.css?.tint ?? .white
        
        self.activity.color = tintColor
        
        self.label.textColor = tintColor
        self.label.font = Loader.css?.font ?? self.label.font
       
        self.progressView.progressTintColor = tintColor
        self.progressView.trackTintColor = Loader.css?.track ?? self.progressView.trackTintColor
        
        self.cancelButton.setTitle("Cancel_Button_Title".localized(), for: .normal)
        self.cancelButton.setTitleColor(tintColor, for: .normal)
        self.cancelButton.titleLabel?.font = Loader.css?.font ?? self.cancelButton.titleLabel?.font
        
        self.backgroundColor = Loader.css?.backgroundColor ?? self.backgroundColor
    }
    
    func update(message:String, progress value:Float = 0) {
    
        self.label.isHidden = message.count <= 0
        self.progressView.isHidden = value <= 0
        
        if self.progressView.isHidden == true {
            self.activity.startAnimating()
        }
        else {
            self.activity.stopAnimating()
        }
        
        self.label.text = message + (value > 0 ? " \(Int(value*100)) %" : "")
        
        self.progressView.setProgress(value, animated: true)
    }
    
    @IBAction func didClickedCancelButton(sender: UIButton) {
        
        self.didClickedCanceButton?()
        
        LoadingView.postNotification(notification: .DidClickedCancelButton, object: sender, userInfo: nil)
    }
}

extension LoadingView:Notifier {
    enum Notification:String {
        case DidClickedCancelButton
    }
}
