//
//  Loader.swift
//  Utility
//
//  Created by Sumeet Bajaj on 06/02/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import UIKit

public protocol LoaderCSS:ViewCSS {
    
    var tint: UIColor? { get set }
    var track: UIColor? { get set }
    var font: UIFont? { get set }
}

public struct Loader {
    
    private init() { /* Restrict intialiser */ }
    
    public static var css: LoaderCSS?

    public static func show(on aView:UIView, safeAreaEnabled:Bool = true) {
        
        DispatchQueue.main.async {
            
            guard self.loadingView(of: aView) == nil else {
                ETLogger.debug("Loading view already available")
                return
            }
            
            guard let loadingView = LoadingView.initialise()  else {
                ETLogger.debug("Failed initialising loading view")
                return
            }
                
            loadingView.translatesAutoresizingMaskIntoConstraints = false
            
            aView.addSubview(loadingView)
            
            if safeAreaEnabled == true {

                loadingView.safeAreaLayoutGuide.leadingAnchor.constraint(equalTo: aView.safeAreaLayoutGuide.leadingAnchor).isActive     = true
                loadingView.safeAreaLayoutGuide.bottomAnchor.constraint(equalTo: aView.safeAreaLayoutGuide.bottomAnchor).isActive       = true
                loadingView.safeAreaLayoutGuide.topAnchor.constraint(equalTo: aView.safeAreaLayoutGuide.topAnchor).isActive             = true
                loadingView.safeAreaLayoutGuide.trailingAnchor.constraint(equalTo: aView.safeAreaLayoutGuide.trailingAnchor).isActive   = true
            }
            else {
                loadingView.leadingAnchor.constraint(equalTo: aView.leadingAnchor).isActive     = true
                loadingView.bottomAnchor.constraint(equalTo: aView.bottomAnchor).isActive       = true
                loadingView.topAnchor.constraint(equalTo: aView.topAnchor).isActive             = true
                loadingView.trailingAnchor.constraint(equalTo: aView.trailingAnchor).isActive   = true
            }
            
            aView.bringSubviewToFront(loadingView)
        }
    }
    
    
    public static func showDownloadView(on aView:UIView, safeAreaEnabled:Bool = true, isCanceOptionAvailabel : Bool = true) {
        DispatchQueue.main.async {
            guard self.loadingDownloadingView(of: aView) == nil else {
                ETLogger.debug("Loading view already available")
                return
            }
            guard let loadingView = DownloadingView.initialise(canceOption: isCanceOptionAvailabel)  else {
                ETLogger.debug("Failed initialising loading view")
                return
            }
            loadingView.translatesAutoresizingMaskIntoConstraints = false
            aView.addSubview(loadingView)
                loadingView.leadingAnchor.constraint(equalTo: aView.leadingAnchor).isActive     = true
                loadingView.bottomAnchor.constraint(equalTo: aView.bottomAnchor).isActive       = true
                loadingView.topAnchor.constraint(equalTo: aView.topAnchor).isActive             = true
                loadingView.trailingAnchor.constraint(equalTo: aView.trailingAnchor).isActive   = true
            aView.bringSubviewToFront(loadingView)
        }
    }
    
    public static func update(message:String,of aView: UIView) {
        DispatchQueue.main.async {
            self.loadingView(of: aView)?.update(message: message, progress: 0)
        }
    }
    
    
    public static func updateDownloadView(value:Float,gameName: String,gameImagePath: String, of aView: UIView){
        DispatchQueue.main.async {
            self.loadingDownloadingView(of: aView)?.update(gameName: gameName, gameImagePath: gameImagePath)
        }
    }
    
    public static func updateDownloadView(of aView: UIView, progress: Float = 0){
        DispatchQueue.main.async {
            self.loadingDownloadingView(of: aView)?.progress = progress
        }
    }
    
    public static func update(value:Float, of aView:UIView, message:String = "Downloading...".localized()) {
        DispatchQueue.main.async {
            self.loadingView(of: aView)?.update(message: message, progress: value)
        }
    }
    
    public static func addCancelHandler(of aView:UIView, onClick: (() ->Void)?) {
        DispatchQueue.main.async {
            self.loadingView(of: aView)?.didClickedCanceButton = onClick
        }
    }
    
    public static func remove(from aView:UIView) {
        DispatchQueue.main.async {
            self.loadingView(of: aView)?.removeFromSuperview()
            self.loadingDownloadingView(of: aView)?.removeFromSuperview()
        }
    }
    
    public static func removeDownloadView(from aView:UIView) {
        DispatchQueue.main.async {
            self.loadingDownloadingView(of: aView)?.removeFromSuperview()
        }
    }
    
    private static func loadingView(of aView:UIView) -> LoadingView? {
        return aView.subviews.first(where: {$0.isKind(of: LoadingView.self)}) as? LoadingView
    }
    
    private static func loadingDownloadingView(of aView:UIView) -> DownloadingView? {
        return aView.subviews.first(where: {$0.isKind(of: DownloadingView.self)}) as? DownloadingView
    }
}




