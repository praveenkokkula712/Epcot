//
//  DownloadingView.swift
//  Utility
//
//  Created by Bandana Choudhury on 22/11/22.
//

import UIKit
import Foundation
import Kingfisher
fileprivate let kSuperSquare = "supersquare"
fileprivate let kPortrait = "portrait"
fileprivate let kSquare = "square"


class DownloadingView: UIView {
    
    @IBOutlet private weak var backgroundImageView: UIImageView!
    @IBOutlet private weak var iconImageView: UIImageView!
    @IBOutlet private weak var cancelButton: UIButton!
    @IBOutlet private weak var progressView:UIProgressView!
    @IBOutlet private weak var gameName:UILabel!
    @IBOutlet private weak var progressLabel:UILabel!
    private var isCancelOptionAvailable: Bool = true
    
    private var css: DownloadingViewCSS = {
        CasinoCSS.lobby?.downloadingView ?? DefaultDownloadingViewCSS()
    }()
    
    var progress: Float = 0 {
        didSet {
            self.progressView.isHidden = false
            self.progressLabel.text = " \(Int(progress*100)) %"
            self.progressView.setProgress(progress, animated: true)
        }
    }
    
    class func initialise(canceOption: Bool = true) -> DownloadingView? {
        
        guard let aView = DownloadingView.loadFromNib("DownloadingView", Bundle(for: DownloadingView.self)) else {
            
            return nil
        }
        aView.isCancelOptionAvailable = canceOption
        aView.update(gameName: "", gameImagePath: "")
        return aView
    }
    
    
    func update(gameName: String,gameImagePath: String) {
        ETLogger.debug(gameImagePath)
        self.gameName.text = gameName
        if !gameImagePath.isEmpty {
            let backgroundImageString = gameImagePath.replacingOccurrences(of: kSuperSquare, with: kPortrait)
            self.backgroundImageView.loadImage(withUrl: backgroundImageString) { result in
                guard let result = try? result?.get() else {
                    self.backgroundImageView.image = nil
                    self.backgroundImageView.backgroundColor = .black
                    return
                }
            }
            if ImageCache.default.isCached(forKey: gameImagePath) {
                self.iconImageView.loadImage(withUrl: gameImagePath)
            } else {
                let gamePath = gameImagePath.replacingOccurrences(of: kSuperSquare, with: kSquare)
                self.iconImageView.loadImage(withUrl: gamePath)
            }
        }
        self.progress = 0
        self.cancelButton.isHidden = !self.isCancelOptionAvailable
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // setup css
        self.gameName.textColor = css.gametitle?.color
        self.gameName.font = css.gametitle?.font
        
        self.cancelButton.setTitle("Cancel_Button_Title".localized(), for: .normal)
        self.cancelButton.setTitleColor(css.cancelButton?.selected, for: .normal)
        self.cancelButton.titleLabel?.font = css.cancelButton?.title?.font
        
        self.backgroundColor = css.backgroundColor ?? .black
        self.progressLabel.textColor = css.progressTitle?.color
        self.progressLabel.font = css.progressTitle?.font
        
        let blurEffect = UIBlurEffect(style: .dark)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = self.backgroundImageView.frame
        blurEffectView.alpha = 0.75
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.backgroundImageView.addSubview(blurEffectView)
        
        self.progressView.progressTintColor = css.progressTintColor ?? .white
        self.progressView.getRoundedCorners(OfRadius: 2.0)
        self.iconImageView.getRoundedCorners(OfRadius: 8.0)
        self.backgroundImageView.contentMode = UIDevice.isIPad() ? .scaleAspectFit : .scaleAspectFill
    }
    
    @IBAction private func didClickedCancelButton(sender: UIButton) {
        self.removeFromSuperview()
        NotificationCenter.default.post(name: NSNotification.Name(rawValue:"DidClickedCancelButton"),
                                        object: sender,
                                        userInfo: ["percentage": self.progressLabel.text])
        
    }
}

