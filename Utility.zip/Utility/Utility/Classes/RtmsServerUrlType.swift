//
//  RtmsServerUrlType.swift
//  Utility
//
//  Created by Praveen Kokkula on 26/07/22.
//

import Foundation

public enum RtmsServerUrlType: String {
    case playBreak
    case winLoss
}
