//
//  GamePremiereAccessibilityIdentifiers.swift
//  Utility
//
//  Created by Sindhuja Vedire on 10/06/24.
//

import Foundation

public struct GamePremiereAccessibilityIdentifiers  {
    
    public static let animation                         = "gamePremiere_animation"
    public static let overlay                           = "gamePremiere_overlay"
    public static let closeIcon                         = "gamePremiere_closeIcon"
    public static let mainTitle                         = "gamePremiere_MainTitle"
    public static let subTitleOne                       = "gamePremiere_subTitleOne"
    public static let subTitleTwo                       = "gamePremiere_subTitleTwo"
    public static let borderStripes                     = "gamePremiere_borderStripes"
    public static let sticker                           = "gamePremiere_sticker"
    public static let promoImage                        = "gamePremiere_promoImage"
    public static let promovideo                        = "gamePremiere_promovideo"
    public static let playIcon                          = "gamePremiere_playIcon"
    public static let pauseIcon                         = "gamePremiere_pauseIcon"
    public static let speakerIcon                       = "gamePremiere_speakerIcon"
    public static let fullScreenIcon                    = "gamePremiere_fullScreenIcon"
    public static let stepsTitle                        = "gamePremiere_stepsTitle"
    public static let offerIcon                         = "gamePremiere_offersIcon"
    public static let additionalInfo                    = "gamePremiere_additionalInfo"
    public static let dropDownIcon                      = "gamePremiere_dropDownIcon"
    public static let moreInfo                          = "gamePremiere_moreInfo"
    public static let lessInfo                          = "gamePremiere_lessInfo"
    public static let optInButton                       = "gamePremiere_optInButton"
    public static let playNowButton                     = "gamePremiere_playNowButton"
    public static let moreInfoContent                   = "gamePremiere_moreInfoContent"
    public static let viewDetailsCTA                    = "gamePremiere_viewDetailsCTA"
    public static let steps                             = "gamePremiere_steps"
}
