//
//  AtomicProperty.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 05/07/24.
//

import Foundation

@propertyWrapper
public class Atomic<T> {
    private var _property: T?
    
    public var wrappedValue: T? {
        get {
            var retVal: T?
            lock.sync {
                retVal = _property
            }
            return retVal
        }
        set {
            lock.async(flags: DispatchWorkItemFlags.barrier) {
                self._property = newValue
            }
        }
    }

    private let lock: DispatchQueue = {
        var name = "AtomicProperty" + String(Int.random(in: 0...100_000))
        let className = String(describing: T.self)
        name += className
        return DispatchQueue(label: name, attributes: .concurrent)
    }()

    init(property: T) {
        self.wrappedValue = property
    }

    public init() { }

    // perform an atomic operation on the atomic property
    // the operation will not run if the property is nil.
    public func performAtomic(atomicOperation:((_ prop:inout T) -> Void)) {
        lock.sync(flags: .barrier) {
            if var prop = _property {
                atomicOperation(&prop)
                _property = prop
            }
        }
    }
}
