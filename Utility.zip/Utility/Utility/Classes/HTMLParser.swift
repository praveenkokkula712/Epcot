//
//  HTMLParser.swift
//  Utility
//
//  Created by Raviraju Vysyaraju on 10/8/20.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import Foundation
import WebKit

public struct HTMLParser {
    
    let string: String?
    
    public init(value: String?) {
        self.string = value
    }
    public func getValues(tag:String) -> [Substring] {
        
        return string?.slices(from: "\(tag)=\"", to: "\"") ?? [Substring]()
    }
    public func getTitleOfhref() -> [Substring] {
        return string?.slices(from: ">", to: "<") ?? [Substring]()
    }
    
    public func getBody(tag:String) -> [Substring] {
        return string?.slices(from: "<\(tag)", to: "/\(tag)>") ?? [Substring]()
    }
}

extension Array where Element == Substring {
    public var nativeActionCategory: Int? {
        for types in self {
            if types.contains("native_action_category") {
                if let actionCategory = HTMLParser(value: types.description).getTitleOfhref().first, !actionCategory.isEmpty {
                    return Int(actionCategory.description)
                }
            }
        }
        return nil
    }
}

public class ProcessPool: NSObject {
    public static let shared = WKProcessPool()
}
