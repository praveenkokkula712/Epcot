//
//  SearchV2AccessibilityIdentifiers.swift
//  Utility
//
//  Created by Sindhuja Vedire on 16/01/24.
//

import Foundation

public struct SearchV2AccessibilityIdentifiers {
    
    //searchDashBoardView
    public let dashboardView                  = "SearchV2_DashboardView"
    
    //searchDashBoardHeader
    public let headerTitle                    = "SearchV2_HeaderTitle"
    public let headerBackButton               = "SearchV2_HeaderBackButton"
    public let headerCloseButton              = "SearchV2_HeaderCloseButton"

    //searchBar
    public let searchButton                   = "SearchBar_SearchButton"
    public let textField                      = "SearchBar_TextField"
    public let placeHolderText                = "SearchBar_PlaceHolderText"
    public let activeMicButton                = "SearchBar_ActiveMicButton"
    public let inActiveMicButton              = "SearchBar_InActiveMicButton"
    public let clearButton                    = "SearchBar_ClearButton"
    public let epcotCancelText                = "SearchBar_Epcot_CancelText"
    public let epcotCancelButton              = "SearchBar_Epcot_CancelButton"
    
    //containerView
    public let containerView                  = "SearchV2_Container"
    
    //categories
    public let categoryTitle                  = "Search_CategoryTitle"
    public let trashIcon                      = "Search_TrashIcon"
    public let clearAllText                   = "Search_ClearAllText"
    public let hideText                       = "Search_HideText"
    public let viewAllText                    = "Search_ViewAllText"
    
    //pillView
    public let pillViewTitle                  = "Pill_View_Title"
    public let pillViewRemoveButton           = "Pill_View_RemoveButton"
    public let pillViewRemoveButtonImage      = "Pill_View_RemoveButtonImage"
    
    //listView
    public let listViewHistoryIcon            = "List_View_HistoryIcon"
    public let listViewTitle                  = "List_View_Title"
    public let listViewArrow                  = "List_View_ArrowIcon"
    public let listViewRemoveButton           = "List_View_RemoveButton"
    public let listViewPlayButton             = "List_View_PlayButton"
    
    //rectangleGameTileView
    public let rectangle_gameTileViewTitle     = "Rectangle_GameTileViewTitle"
    public let rectangle_gameTileJackpotAmount = "Rectangle_GameTileJackpotAmount"
    
    //gameTileView
    public let gameTileImage                   = "SearchV2_GameTileImage"
    
    public let playButton                      = "SearchV2_PlayButton"
    public let downloadButton                  = "SearchV2_DownloadButton"
    public let downloadIcon                    = "SearchV2_DownloadIcon"
    public let favouriteIcon                   = "SearchV2_FavouriteButton"
    public let jackpotImage                    = "SearchV2_JackpotImage"
    public let jackpotAmount                   = "SearchV2_JackpotAmount"
    public let stickerLabel                    = "SearchV2_Sticker_Label"
    public let playIcon                        = "SearchV2_PlayIcon"
    
    //vendorView
    public let vendorGamesCount                = "SearchV2_VendorGamesCount"
    
    //noSearchResultsFound
    public let title                           = "SearchV2_NoResultsFoundTitle"
    public let subTitle                        = "SearchV2_NoResultsFoundSubTitle"
    
    //searchResults
    public let highlightedText                 = "SearchResults_HighlightedText"
    public let normalText                      = "SearchResults_NormalText"
    public let jackpot                         = "SearchResults_JackpotAmount"
    public let rightArrow                      = "SearchResults_RightArrow"
    
    public init() {
        
    }
}
