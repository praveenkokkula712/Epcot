//
//  BooleanCheck.swift
//  Utility
//
//  Created by Bandana Choudhury on 12/11/21.
//

import Foundation

public enum BooleanCheck {
     case enabled
     case disabled
     case noValue
}
