//
//  ButtonView.swift
//  Utility
//
//  Created by Praveen Kokkula on 10/05/24.
//

import Foundation
import SwiftUI

public struct HapticsButton<Content: View>: View {
    
    var content: Content
    let action: () -> Void
    @State var scaleValue = 1.0
    
    public init(
        @ViewBuilder content: () -> Content,
        action: @escaping () -> Void
    ) {
        self.content = content()
        self.action = action
    }
    
    public var body: some View {
        Button {
            Haptics.play(.light)
            self.scaleValue = 0.95
            withAnimation(Animation.linear.delay(0.2)) {
                self.scaleValue = 1.0
                self.action()
            }
        } label: {
            content
        }.scaleEffect(scaleValue)
    }
}
