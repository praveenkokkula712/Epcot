//
//  GameTileImageView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 31/08/23.
//

import SwiftUI
import Kingfisher

public struct GameTileImageView: View {
    
    // MARK: Properties
    private let path: String
    private let width: Double
    private let height: Double
    private let cornerRadius: Double
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()

    // MARK: Init
    public init(path: String, width: Double, height: Double, cornerRadius: Double) {
        self.path = path
        self.width = width
        self.height = height
        self.cornerRadius = cornerRadius
    }
    
    // MARK: Body
    public var body: some View {
        KFImage(URL(string: path))
            .placeholder {
                PlaceHolderImage()
            }
            .resizable()
            .setProcessor(
                ResizingImageProcessor(
                    referenceSize: CGSize(width: width, height: height),
                    mode: .aspectFit
                )
            )
            .frame(width: width, height: height)
            .cornerRadius(cornerRadius)
            .clipped()
            .accessibilityIdentifier(gameTileIdentifier)
    }
}

// MARK: - Accessibility Identifiers
extension GameTileImageView {
    
    private var gameTileIdentifier : String {
        accessibilityIdentifiers.gameTileImage
    }
}


// MARK: - Previews
struct GameTileImageView_Previews: PreviewProvider {
    static var previews: some View {
        GameTileImageView(
            path: "https://url.com",
            width: 100,
            height: 100,
            cornerRadius: 16
        )
    }
}
