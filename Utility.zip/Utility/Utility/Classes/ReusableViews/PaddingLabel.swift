//
//  PaddingLabel.swift
//  Utility
//
//  Created by Challa Venkata Narasimha Karthik on 23/03/22.
//  Copyright © 2022 Ivy Comptech. All rights reserved.
//

import UIKit

open class PaddingLabel: UILabel {
    open var contentInset = UIEdgeInsets.zero {
        didSet {
            invalidateIntrinsicContentSize()
        }
    }
    
    public override var intrinsicContentSize: CGSize {
        var originalSize = super.intrinsicContentSize
        originalSize.width += contentInset.left + contentInset.right
        originalSize.height += contentInset.top + contentInset.bottom
        return originalSize
    }
    
    public override func drawText(in rect: CGRect) {
        super.drawText(in: rect.inset(by: contentInset))
    }
    
    public override func textRect(forBounds bounds: CGRect, limitedToNumberOfLines numberOfLines: Int) -> CGRect {
        let insetRect = bounds.inset(by: contentInset)
        let textRect = super.textRect(forBounds: insetRect, limitedToNumberOfLines: numberOfLines)
        let invertedInsets = UIEdgeInsets(top: -contentInset.top,
                                          left: -contentInset.left,
                                          bottom: -contentInset.bottom,
                                          right: -contentInset.right)
        return textRect.inset(by: invertedInsets)
    }
}
