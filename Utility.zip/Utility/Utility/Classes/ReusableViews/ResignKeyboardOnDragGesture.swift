//
//  ResignKeyboardOnDragGesture.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 07/12/23.
//

import SwiftUI

public extension View {
    public func resignKeyboardOnDragGesture() -> some View {
        return modifier(ResignKeyboardOnDragGesture())
    }
}

private struct ResignKeyboardOnDragGesture: ViewModifier {
    func body(content: Content) -> some View {
        content
            .simultaneousGesture(
                DragGesture()
                    .onChanged { _ in withAnimation { hideKeyboard() } }
            )
            .onTapGesture { withAnimation { hideKeyboard() } }
    }
}

private extension ViewModifier {
    fileprivate func hideKeyboard() {
        let resign = #selector(UIResponder.resignFirstResponder)
        UIApplication.shared.sendAction(resign, to: nil, from: nil, for: nil)
    }
}
