//
//  SVGImageView.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 09/06/23.
//

import Foundation
import SwiftUI
import SVGKit

public struct SVGImageView: UIViewRepresentable {
    var url:URL
    var size:CGSize
    
    public init(url: URL, size: CGSize) {
        self.url = url
        self.size = size
    }
    
    public func updateUIView(_ uiView: SVGKFastImageView, context: UIViewRepresentableContext<Self>) {
        uiView.contentMode = .scaleAspectFit
        uiView.image.size = size
    }
    
    public func makeUIView(context: UIViewRepresentableContext<Self>) -> SVGKFastImageView {
        let svgImage = SVGKImage(contentsOf: url)
        return SVGKFastImageView(svgkImage: svgImage ?? SVGKImage())
    }
}

