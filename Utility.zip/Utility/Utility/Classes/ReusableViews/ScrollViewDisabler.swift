//
//  ScrollViewDisabler.swift
//  Utility
//
//  Created by Praveen Kokkula on 24/05/24.
//

import Foundation
import SwiftUI

struct DisableScrollingModifier: ViewModifier {
     var disabled: Bool
    
    func body(content: Content) -> some View {
    
        if disabled {
            content
                .simultaneousGesture(DragGesture(minimumDistance: 0))
        } else {
            content
        }
        
    }
}

public extension View {
    func scrollingDisabled(_ disabled: Bool) -> some View {
        modifier(DisableScrollingModifier(disabled: disabled))
    }
}
