//
//  HighlightedText.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 27/09/23.
//

import SwiftUI

public struct HighlightedText: View {
    let text: String
    let matching: String
    let caseInsensitive: Bool
    let color: Color
    let highlightTextColor: Color

    public init(
        _ text: String,
        matching: String,
        caseInsensitive: Bool = false,
        color: Color = .black,
        highlightTextColor: Color = .blue
    ) {
        self.text = text
        self.matching = matching
        self.caseInsensitive = caseInsensitive
        self.color = color
        self.highlightTextColor = highlightTextColor
    }

    public var body: some View {
        guard  let regex = try? NSRegularExpression(
            pattern: NSRegularExpression.escapedPattern(for: matching)
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .folding(options: .regularExpression, locale: .current),
            options: caseInsensitive ? .caseInsensitive : .init()
        ) else {
            return Text(text)
                .foregroundColor(color)
        }

        let range = NSRange(location: 0, length: text.count)
        let matches = regex.matches(
            in: text,
            options: .withTransparentBounds,
            range: range
        )

        return text.enumerated()
            .map { (char) -> Text in
                guard matches.filter({
                    $0.range.contains(char.offset)
                }).count == 0 else {
                    return Text(String(char.element))
                        .foregroundColor(highlightTextColor)
                }
                return Text(String(char.element))
                    .foregroundColor(color)
            }
            .reduce(Text("")) { (a, b) -> Text in
                return a + b
            }
    }
}

struct HighlightedText_Previews: PreviewProvider {
    static var previews: some View {
        HighlightedText("Hello", matching: "he")
    }
}
