//
//  RightSidedCarouselView.swift
//  InfiniteCarousalView
//
//  Created by Yemireddi Sateesh on 22/04/24.
//

import SwiftUI

public struct RightSidedCarouselView<Content: View, Items: RandomAccessCollection>: View where Items.Element: Identifiable {
    
    // MARK: Properties
    let width: CGFloat
    let spacing: CGFloat
    let items: Items
    let getScrollIndex: (Int) -> Void
    @ViewBuilder let content: (Items.Element) -> Content
    
    public init(width: CGFloat, spacing: CGFloat, items: Items, getScrollIndex: @escaping (Int) -> Void, @ViewBuilder content: @escaping (Items.Element) -> Content) {
        self.width = width
        self.spacing = spacing
        self.items = items
        self.getScrollIndex = getScrollIndex
        self.content = content
    }
    
    // MARK: Body
    public var body: some View {
        GeometryReader { geometry in
            let size = geometry.size
            let repeatingCount = width > 0 ? Int((size.width / width).rounded()) + 1 : 1

            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: spacing) {
                    ForEach(items) { item in
                        content(item)
                            .frame(width: width)
                    }
                    ForEach(0..<repeatingCount, id: \.self) { index in
                        let item = Array(items)[index % items.count]
                        content(item)
                            .frame(width: width)
                    }
                }
                .background(
                    ScrollViewHelper(
                        width: width,
                        spacing: spacing,
                        itemCount: items.count,
                        repeatingCount: repeatingCount,
                        getScrollIndex: getScrollIndex
                    )
                )
            }
        }
    }
}

// MARK: - ScrollViewHelper
fileprivate struct ScrollViewHelper: UIViewRepresentable {
    
    var width: CGFloat
    var spacing: CGFloat
    var itemCount: Int
    var repeatingCount: Int
    var getScrollIndex: (Int) -> Void

    func makeCoordinator() -> Coordinator {
        return Coordinator(width: width,
                           spacing: spacing,
                           itemCount: itemCount,
                           repeatingCount: repeatingCount,
                           getScrollIndex: getScrollIndex
        )
    }

    func makeUIView(context: UIViewRepresentableContext<Self>) -> some UIView {
        return .init()
    }

    func updateUIView(_ uiView: UIViewType, context: UIViewRepresentableContext<Self>) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) {
            if let scrollview = uiView.superview?.superview?.superview as? UIScrollView,
               !context.coordinator.isAdded {
                scrollview.delegate = context.coordinator
                context.coordinator.isAdded = true
            }
        }
        context.coordinator.width = width
        context.coordinator.spacing = spacing
        context.coordinator.itemCount = itemCount
        context.coordinator.repeatingCount = repeatingCount
    }
    
    class Coordinator: NSObject, UIScrollViewDelegate {
        var width: CGFloat
        var spacing: CGFloat
        var itemCount: Int
        var repeatingCount: Int
        var isAdded: Bool = false
        var getScrollIndex: (Int) -> Void

        init(width: CGFloat, spacing: CGFloat, itemCount: Int, repeatingCount: Int, getScrollIndex: @escaping (Int) -> Void) {
            self.width = width
            self.spacing = spacing
            self.itemCount = itemCount
            self.repeatingCount = repeatingCount
            self.getScrollIndex = getScrollIndex
        }
        
        func scrollViewDidScroll(_ scrollView: UIScrollView) {
            guard itemCount > 0 else { return }
            let minX = scrollView.contentOffset.x
            let mainContentSize = CGFloat(itemCount) * width
            let spacingSize = CGFloat(itemCount) * spacing
            
            if minX > (mainContentSize + spacingSize) {
                scrollView.contentOffset.x -= (mainContentSize + spacingSize)
            }
            
            // Uncomment the code if the scroll wants to be looping around both directions.
//            if minX < 0 {
//                scrollView.contentOffset.x += (mainContentSize + spacingSize)
//            }
            
            let currentIndex = Int(round(Double(scrollView.contentOffset.x) / Double(width))) % itemCount
            getScrollIndex(currentIndex)
        }
    }
}

fileprivate struct Page: Identifiable, Hashable {
    var id: UUID = .init()
    var color: Color
}

fileprivate var previewItems: [Page] = [.red, .blue, .green, .yellow, .black].compactMap { color in
        .init(color: color)
}
