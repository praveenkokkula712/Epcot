//
//  ScalableButton.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 17/05/24.
//

import SwiftUI

public struct ScalableButton<Content: View>: View {
    
    // MARK: Properties
    private let action: () -> Void
    @ViewBuilder private let label: () -> Content

    public init(action: @escaping () -> Void, label: @escaping () -> Content) {
        self.action = action
        self.label = label
    }

    // MARK: Body
    public var body: some View {
        Button(
            action: {
                Haptics.play(.light)
                action()
            },
            label: label
        )
        .buttonStyle(ScalableButtonStyle())
    }
}

// MARK: - Scale with Animation
struct ScalableButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .opacity(configuration.isPressed ? 0.7 : 1.0)
            .animation(
                .easeOut(duration: 0.2),
                value: configuration.isPressed
            )
    }
}
