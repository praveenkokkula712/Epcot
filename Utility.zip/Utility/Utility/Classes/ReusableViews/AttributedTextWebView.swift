//
//  HTMLTextWebView.swift
//  Utility
//
//  Created by Praveen Kokkula on 22/04/24.
//

import Foundation
import SwiftUI
import WebKit

public struct AttributedTextWebView: UIViewRepresentable {
    let htmlContent: String
    @Binding var height: CGFloat
    private let webView = WKWebView()
    let fontName: String
    let fontSize: CGFloat
    let textColor: UIColor
    var navigationActionUrl: ((String) -> Void)? = nil
    
    public init(htmlContent: String, height: Binding<CGFloat> = Binding.constant(.zero), fontName: String = "PrimaryRegularFont", fontSize: CGFloat = 14, textColor: UIColor = .black, navigationActionUrl: ((String) -> Void)? = nil) {
        self.htmlContent = htmlContent
        self._height = height
        self.fontName = fontName
        self.fontSize = fontSize
        self.textColor = textColor
        self.navigationActionUrl = navigationActionUrl
    }
    
    public func makeUIView(context: UIViewRepresentableContext<Self>) -> WKWebView {
        webView.scrollView.isScrollEnabled = false
        webView.navigationDelegate = context.coordinator
        webView.backgroundColor = .clear
        webView.isOpaque = false
        return webView
    }
    
    public func updateUIView(_ uiView: WKWebView, context: UIViewRepresentableContext<Self>) {
        let styledHtmlContent = """
                <!doctype html>
                <meta charset="utf-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1 , maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
                <html>
                <style>
                @font-face {
                    font-family: '\(fontName)';
                    src: url("\(fontName).ttf") format('truetype');
                }
                body {
                    font-size: \(fontSize)px;
                    font-family: "\(fontName)";
                    color: #\(textColor.toHex() ?? "000000");
                }
                </style>
                <p>
                \(htmlContent)
                </p>
                <div style="height: 40px; display: block;"></div>
                </html>
                """
        let bundleURL = Bundle.main.bundleURL
        uiView.loadHTMLString(styledHtmlContent, baseURL: bundleURL)
    }
    
    public func makeCoordinator() -> Coordinator {
        Coordinator(webView: webView,
                    contentHeight: $height,
                    navigationActionUrl: self.navigationActionUrl)
    }
    
    public class Coordinator: NSObject, WKNavigationDelegate {
        let webView: WKWebView
        let contentHeight: Binding<CGFloat>
        var navigationActionUrl: ((String) -> Void)? = nil
        
        init(webView: WKWebView, contentHeight: Binding<CGFloat>, navigationActionUrl: ((String) -> Void)? = nil ) {
            self.webView = webView
            self.contentHeight = contentHeight
            self.navigationActionUrl = navigationActionUrl
            super.init()
        }
        
        public func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction) async -> WKNavigationActionPolicy {
            ETLogger.debug(webView)
            if let urlString = navigationAction.request.url?.absoluteString, urlString.contains("https://") {
                DispatchQueue.main.async {
                    self.webView.navigationDelegate = nil
                    self.webView.resignFirstResponder()
                    self.webView.stopLoading()
                    self.webView.removeFromSuperview()
                    self.navigationActionUrl?(urlString)
                }
                return await .cancel
            }
            return await .allow
        }
        public func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.evaluateJavaScript("document.body.scrollHeight") { [weak self] result, error in
                guard let self = self,
                      let height = result as? CGFloat,
                      error == nil else {
                    return
                }
                self.contentHeight.wrappedValue = height
            }
        }
    }
}
