//
//  ScreenContainer.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 08/08/23.
//

import SwiftUI

public struct ScreenContainer<Content: View>: View {
    let color: Color
    @ViewBuilder var content: () -> Content
    
    public init(color: Color, content: @escaping () -> Content) {
        self.color = color
        self.content = content
    }

    public var body: some View {
        ZStack {
            Rectangle()
                .fill(color)
                .ignoresSafeArea()

            content()
        }
    }
}

struct ScreenContainer_Previews: PreviewProvider {
    static var previews: some View {
        ScreenContainer(color: .black) {
            Text("Hello world")
                .foregroundColor(.white)
        }
    }
}
