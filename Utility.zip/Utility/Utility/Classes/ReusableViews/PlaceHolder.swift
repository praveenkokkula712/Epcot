//
//  PlaceHolder.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 08/08/23.
//

import SwiftUI

// From Stackoverflow: https://stackoverflow.com/a/62950092

struct PlaceHolder<T: View>: ViewModifier {
    var placeHolder: T
    var show: Bool
    func body(content: Content) -> some View {
        ZStack(alignment: .leading) {
            if show { placeHolder }
            content
        }
    }
}

extension View {
    public func placeHolder<T:View>(_ holder: T, show: Bool) -> some View {
        self.modifier(PlaceHolder(placeHolder:holder, show: show))
    }
}
