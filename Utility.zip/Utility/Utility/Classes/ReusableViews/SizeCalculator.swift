//
//  SizeCalculator.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 03/04/23.
//

import SwiftUI

public struct SizeCalculator: ViewModifier {
    @Binding public var size: CGSize
    public func body(content: Content) -> some View {
        content
            .background(
                GeometryReader { proxy in
                    Color.clear
                        .onAppear {
                            size = proxy.size
                        }
                }
            )
    }
}

extension View {
    public func saveSize(in size: Binding<CGSize>) -> some View {
        modifier(SizeCalculator(size: size))
    }
}
