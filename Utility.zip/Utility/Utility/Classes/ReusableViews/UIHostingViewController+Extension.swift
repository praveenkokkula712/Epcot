//
//  UIHostingViewController+Extension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 06/05/24.
//

import Foundation
import SwiftUI

public extension UIHostingController {
    func presentWithAnimation(transitionStyle: UIModalTransitionStyle = .crossDissolve,
                              presentationStyle: UIModalPresentationStyle = .overFullScreen,
                              layerSpeed: Float = 0.75,
                              backgroundColor: UIColor = .black ) {
        self.modalTransitionStyle = transitionStyle
        self.modalPresentationStyle = presentationStyle
        self.view.layer.speed = layerSpeed
        self.view.backgroundColor = backgroundColor
    }
}
