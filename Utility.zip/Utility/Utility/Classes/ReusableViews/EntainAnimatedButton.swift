//
//  EntainAnimatedButton.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 02/07/24.
//

import SwiftUI

public struct EntainAnimatedButton<Content: View>: View {

    // MARK: Properties
    private let type: EntainAnimatedButtonType
    private let action: () -> Void
    @ViewBuilder private let label: () -> Content

    // MARK: Init
    public init(
        type: EntainAnimatedButtonType,
        action: @escaping () -> Void,
        label: @escaping () -> Content
    ) {
        self.type = type
        self.action = action
        self.label = label
    }

    // MARK: Body
    public var body: some View {
        Button(
            action: {
                Haptics.play(.light)
                action()
            },
            label: label
        )
        .buttonStyle(
            ScaleOpacityButtonStyle(
                isScaling: type.attributes.scaling,
                isOpacity: type.attributes.opacity
            )
        )
    }
}

public extension EntainAnimatedButton {
    enum EntainAnimatedButtonType {
        case scale
        case opacity
        case scaleOpacity
        
        var attributes: (scaling: Bool, opacity: Bool) {
            switch self {
            case .scale:
                (true, false)
            case .opacity:
                (false, true)
            case .scaleOpacity:
                (true, true)
            }
        }
    }
}

// MARK: - Animation Styles
private struct ScaleOpacityButtonStyle: ButtonStyle {
    var isScaling = false
    var isOpacity = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(isScaling ? configuration.isPressed ? 0.95 : 1.0 : 1.0)
            .opacity(isOpacity ? configuration.isPressed ? 0.7 : 1.0 : 1.0)
            .animation(
                .easeOut(duration: 0.2),
                value: configuration.isPressed
            )
    }
}
