//
//  FrameCalculator.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 13/04/23.
//

import SwiftUI

public class FrameReference: ObservableObject {
    @Published public var frameRef: CGRect = .zero
    public init() { }
}

public struct ViewFrameKey: PreferenceKey {
    public static var defaultValue: CGRect = .zero
    public static func reduce(value: inout CGRect, nextValue: () -> CGRect) {
        value = nextValue()
    }
}

public struct FrameCalculator: ViewModifier {
    @Binding public var frame: FrameReference
    public func body(content: Content) -> some View {
        content
            .background(
                GeometryReader { geometry in
                    Color.clear.preference(key: ViewFrameKey.self, value: geometry.frame(in: .global))
                }
            )
            .onPreferenceChange (ViewFrameKey.self) {
                frame.frameRef = $0
            }
    }
}

public struct SecondaryViewFrameKey: PreferenceKey {
    public static var defaultValue: CGRect = .zero
    public static func reduce(value: inout CGRect, nextValue: () -> CGRect) {
        value = nextValue()
    }
}

public struct SecondaryViewFrameCalculator: ViewModifier {
    @Binding public var frame: FrameReference
    public func body(content: Content) -> some View {
        content
            .background(
                GeometryReader { geometry in
                    Color.clear.preference(key: SecondaryViewFrameKey.self, value: geometry.frame(in: .global))
                }
            )
            .onPreferenceChange (SecondaryViewFrameKey.self) {
                frame.frameRef = $0
            }
    }
}

extension View {
    public func savePrimaryViewFrame(in reference: Binding<FrameReference>) -> some View {
        modifier(FrameCalculator(frame: reference))
    }
    
    public func saveSecondaryViewFrame(in frame: Binding<FrameReference>) -> some View {
        modifier(SecondaryViewFrameCalculator(frame: frame))
    }
}

