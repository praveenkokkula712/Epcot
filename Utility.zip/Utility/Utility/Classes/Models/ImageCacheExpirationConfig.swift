//
//  ImageCacheExpirationConfig.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 11/07/23.
//

import Foundation

public struct ImageCacheExpirationConfig {
    public var isEnabled: Bool
    public var expirationDuration: Int
    
    public init(isEnabled: Bool, expirationDuration: Int) {
        self.isEnabled = isEnabled
        self.expirationDuration = expirationDuration
    }
}
