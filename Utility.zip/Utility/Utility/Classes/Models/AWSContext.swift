//
//  AWSContext.swift
//  Utility
//
//  Created by Sumeet Bajaj on 04/02/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import Foundation

public struct AWSContext {

    public var region: Int = 0
    public var bucketName:String!
    public var accessId : String!
    public var secretKey : String!
    public var stream: String?
    public var identityPoolId: String?
    public var downloadFromAWSPrefixUrl:Bool?
    public var iosKinesisEncryptedValue: String?
    public var cognitoPoolId: String
    public var cognitoRegion: Int

    public init(bucketName:String,
                region:Int,
                accessId: String,
                secretKey: String,
                stream: String? = nil,
                identityPoolId: String? = nil,
                downloadFromAWSPrefixUrl:Bool? = false,
                iosKinesisEncryptedValue: String? = nil,
                cognitoPoolId: String = "",
                cognitoRegion: Int = 0) {
        
        self.bucketName = bucketName
        self.region = region
        self.accessId = accessId
        self.secretKey = secretKey
        self.stream = stream
        self.identityPoolId = identityPoolId
        self.downloadFromAWSPrefixUrl = downloadFromAWSPrefixUrl
        self.iosKinesisEncryptedValue = iosKinesisEncryptedValue
        self.cognitoPoolId = cognitoPoolId
        self.cognitoRegion = cognitoRegion
    }
}
