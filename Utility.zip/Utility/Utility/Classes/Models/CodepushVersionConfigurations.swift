//
//  CodepushVersionConfigurations.swift
//  Utility
//
//  Created by Venkat Rao Sandhi on 31/01/24.
//

import Foundation

public struct CodepushVersionConfigurations {
    public var codePushVersion: String = ""
    
    public init(codePushVersion: String) {
        self.codePushVersion = codePushVersion
    }
}
