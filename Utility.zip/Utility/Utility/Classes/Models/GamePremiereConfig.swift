//
//  GamePremiereConfig.swift
//  Utility
//
//  Created by Naresh Banavath on 14/05/24.
//

import Foundation

public struct GamePremiereConfig: Codable {
    public private(set) var animationDuration,
                            optedInToasterDisplayDuration: Double?,
                            isToasterEnabled: Bool?
    
    public init(from decoder: Decoder) throws {
        let container = try? decoder.container(keyedBy: CodingKeys.self)
        self.animationDuration = try? container?.decodeIfPresent(Double.self, forKey: .animationDuration)
        self.optedInToasterDisplayDuration = try? container?.decodeIfPresent(Double.self, forKey: .optedInToasterDisplayDuration)
        self.isToasterEnabled = try? container?.decodeIfPresent(Bool.self, forKey: .isToasterEnabled)
    }
}
