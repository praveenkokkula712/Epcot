//
//  FavoriteToastConfig.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 04/04/23.
//

import Foundation

public struct FavoriteToastConfig {
    public let isFavoriteToastEnabled: Bool
    public let favoriteToastTimeout: Int
    public let isCTAEnabled: Bool

    public init(isFavoriteToastEnabled: Bool = true,
                favoriteToastTimeout: Int = 5,
                isCTAEnabled: Bool = true) {
        self.isFavoriteToastEnabled = isFavoriteToastEnabled
        self.favoriteToastTimeout = favoriteToastTimeout
        self.isCTAEnabled = isCTAEnabled
    }
}
