//
//  OverlaysAndToasterConfigurations.swift
//  Utility
//
//  Created by Gostu Bhargavi on 10/07/23.
//

import Foundation

public struct OverlaysAndToasterConfigurations {
    public private(set) var isOverlaysEnabled: Bool
    public private(set) var isToastersEnabled: Bool
    public private(set) var isOverlaysCTAFullWidth: Bool

    public init(isOverlaysEnabled: Bool = false,
                isToastersEnabled: Bool = false,
                isOverlaysCTAFullWidth: Bool = false) {
        self.isOverlaysEnabled = isOverlaysEnabled
        self.isToastersEnabled = isToastersEnabled
        self.isOverlaysCTAFullWidth = isOverlaysCTAFullWidth
    }
}
