//
//  GameResourceInfoContext.swift
//  APIClient
//
//  Created by Abhishek Verma on 3/18/20.
//

import Foundation

public struct GameResourceInfoContext {
    
    public var fileName:String!
    public var path:String!
    public var version:String!
    
    public init(fileName:String,
                path:String,
                version:String) {
        
        self.fileName = fileName
        self.path = path
        self.version = version
    }
}
