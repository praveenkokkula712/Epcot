//
//  LruContext.swift
//  Utility
//
//  Created by Challa Venkata Narasimha Karthik on 30/01/24.
//

import Foundation

public struct LruContext {
    
    public let memoryAvailableToUse: Int?
    public let appUsedMemory: Int?
    public let memoryToBeCleared: Int?
    
    public init(memoryAvailableToUse: Int?,
                appUsedMemory: Int?,
                memoryToBeCleared: Int?) {
        self.memoryAvailableToUse = memoryAvailableToUse
        self.appUsedMemory = appUsedMemory
        self.memoryToBeCleared = memoryToBeCleared
    }
}
