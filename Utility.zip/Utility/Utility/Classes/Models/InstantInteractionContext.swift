//
//  InstantInteractionContext.swift
//  EpcotLobby
//
//  Created by Bandana Choudhury on 26/04/23.
//

import Foundation

public struct InstantInteractionModel: Codable {
    public let opacity: CGFloat?
    public let transformSize: Double?
    public let overlay12Color: String?
    public let overlay40Color: String?
}

public enum InstantInteraction {
    case decreaseOpacity(CGFloat)
    case reduceSize(Double)
    case overlay12(UIColor)
    case overlay40(UIColor)
    case none
}
