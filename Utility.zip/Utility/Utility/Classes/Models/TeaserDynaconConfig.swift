//
//  TeaserDynaconConfig.swift
//  Utility
//
//  Created by Praveen Kokkula on 20/05/22.
//

import Foundation

public struct TeaserDynaconConfig {
    public let isTeaserEnabled: Bool
    public let teasersDisplayLimit: Int
    public let shouldDisplayPageControl: Bool
    public let isPageControlAutoScrolEnabled: Bool
    public let durationforAutoScroll: Double
    public let iPadAutoscrollEnabled: Bool
    
    public init(isTeaserEnabled: Bool,
                teasersDisplayLimit: Int = 10,
                shouldDisplayPageControl: Bool = false,
                isPageControlAutoScrolEnabled: Bool = false,
                durationforAutoScroll: Double = 3,
                iPadAutoscrollEnabled: Bool = false) {
        self.isTeaserEnabled = isTeaserEnabled
        self.teasersDisplayLimit = teasersDisplayLimit
        self.shouldDisplayPageControl = shouldDisplayPageControl
        self.isPageControlAutoScrolEnabled = isPageControlAutoScrolEnabled
        self.durationforAutoScroll = durationforAutoScroll
        self.iPadAutoscrollEnabled = iPadAutoscrollEnabled
    }
}

public struct EmbeddBannerDynaconConfig {
    public let isEnabled: Bool
    public let position: Int
    
    public init(isEnabled: Bool,
                position: Int = 12) {
        self.isEnabled = isEnabled
        self.position = position
    }
}

