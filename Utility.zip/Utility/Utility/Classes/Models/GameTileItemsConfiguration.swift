//
//  GameTileItemsConfiguration.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 10/07/23.
//

import Foundation

public struct GameTileItemsConfiguration {
    public let gameTileItemsPositions: [Int]

    public init(gameTileItemsPositions: [Int] = [0, 1, 2]) {
        self.gameTileItemsPositions = gameTileItemsPositions
    }
}
