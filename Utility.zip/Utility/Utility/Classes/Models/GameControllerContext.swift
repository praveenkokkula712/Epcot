//
//  GameControllerContext.swift
//  Utility
//
//  Created by Sumeet Bajaj on 04/02/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import Foundation

public struct GameControllerContext {
    
    public var fileName:String!
    public var path:String!
    public var version:String!
    public var mobileHtmlConfiguration: MobileHtmlConfiguration?
    public var htmlGameDownloadConfiguration: HtmlGameDownloadConfigurations?
    
    public init(fileName:String, path:String, version:String,
                mobileHtmlConfiguration: MobileHtmlConfiguration?,
                htmlGameDownloadConfig: HtmlGameDownloadConfigurations?) {
         self.fileName = fileName
         self.path = path
         self.version = version
        self.mobileHtmlConfiguration = mobileHtmlConfiguration
        self.htmlGameDownloadConfiguration = htmlGameDownloadConfig
     }
}

public struct MobileHtmlConfiguration {
    public var isEnabled: Bool
    public var vendors:[String]
    public var ezNavPath: String
    
    public init(isEnabled: Bool, vendors: [String], ezNavPath: String) {
        self.isEnabled = isEnabled
        self.vendors = vendors
        self.ezNavPath = ezNavPath
    }
}

public struct HtmlGameDownloadConfigurations {
    public var progressEnabled: Bool?
    public var htmlPath, casinoPath : String?
    
    public init(progressEnabled: Bool, htmlPath: String, casinoPath: String) {
        self.progressEnabled = progressEnabled
        self.htmlPath = htmlPath
        self.casinoPath = casinoPath
    }
}
