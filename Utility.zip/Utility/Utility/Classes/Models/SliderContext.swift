//
//  SliderContext.swift
//  Utility
//
//  Created by Sumeet Bajaj on 13/01/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import Foundation

public struct SliderContext {
    
    public var lobbyType: String?
    public var lastPlayedGame:String?
    public var gameList: [String]?
    public var sliderInvokerProduct: String?
    public var withdrawUrl: String?
    public var depositeUrl: URL?
    public var responsibleGamingURL: String?
    public var historyURL: String?
    public var gameInitErrorMessage: String?
    public var isEpcotEnabled: Bool?
    public var dynaconConfig: DynaconFeaturesConfigurations?
    public var timeIntervalforSliderIconAnimate: Int?
    public var stateName: String?
    public var lruGameBundleCount: Int?
    public var rcpuTimeFormat: Int?
    public var baseURL: String?
    public var accessID: String?
    public var gameNames: [String: Any]?
    public var cloudFrontURL: String?
    public var unitySGStringsPath: [String]?
    public var unitySGRulesPath: String?
    public var enableJackpotForSlotGames: Bool?
    public var rgLogoImagePath: String?
    public var cloudFrontVersonIDDetails: [String: CommonData]?
    public var buildVersion: String?
    public var serverConfig: SliderGameServerConfig?
    public var sliderIconPositionDetails: SliderIconPosition?
    public var sessionSettingsData: SessionSettingsData?
    public var sliderThemeCSS: [String: Any]?
    public var isInternalBuild: Bool?
    public var sitecoreMappingKey: String?
    public var isSensitivePageOpened = false
    public var betmgmStateFullName: String?
    public var slotSessionMinimumValue: Int?
    public var defaultErrorResponceTime: Int?
    public var geoLocationURL: String?
    public var unityGameRuleVersionDetails: [String: Any]?
    
    public init(lobbyType:String? = "slider",
                lastPlayedGame:String? = nil,
                gameList: [String]?,
                sliderInvokerProduct: String?,
                withdrawUrl: String?,
                depositeUrl: URL?,
                responsibleGamingURL: String?,
                historyURL: String?,
                gameInitErrorMessage: String? = nil,
                sliderThemeCSS: [String: Any]?,
                isEpcotEnabled: Bool?,
                dynaconConfig: DynaconFeaturesConfigurations?,
                timeIntervalforSliderIconAnimate: Int?,
                stateName: String?,
                lruGameBundleCount: Int?,
                rcpuTimeFormat: Int?,
                baseURL: String?,
                accessID: String?,
                gameNames: [String: Any]?,
                cloudFrontURL: String?,
                unitySGStringsPath: [String]?,
                unitySGRulesPath: String?,
                enableJackpotForSlotGames: Bool?,
                rgLogoImagePath: String?,
                cloudFrontVersonIDDetails: [String: CommonData]?,
                buildVersion: String?,
                serverConfig: SliderGameServerConfig?,
                sliderIconPositionDetails: SliderIconPosition?,
                sessionSettingsData: SessionSettingsData?,
                isInternalBuild: Bool?,
                sitecoreMappingKey: String?,
                betmgmStateFullName: String?,
                slotSessionMinimumValue: Int?,
                defaultErrorResponceTime: Int?,
                unityGameRuleVersionDetails: [String: Any]?) {
        self.lobbyType = lobbyType
        self.lastPlayedGame = lastPlayedGame
        self.gameList = gameList
        self.sliderInvokerProduct = sliderInvokerProduct
        self.withdrawUrl = withdrawUrl
        self.depositeUrl = depositeUrl
        self.responsibleGamingURL = responsibleGamingURL
        self.historyURL = historyURL
        self.gameInitErrorMessage = gameInitErrorMessage
        self.isEpcotEnabled = isEpcotEnabled
        self.dynaconConfig = dynaconConfig
        self.timeIntervalforSliderIconAnimate = timeIntervalforSliderIconAnimate
        self.stateName = stateName
        self.lruGameBundleCount = lruGameBundleCount
        self.baseURL = baseURL
        self.accessID = accessID
        self.gameNames = gameNames
        self.cloudFrontURL = cloudFrontURL
        self.unitySGStringsPath = unitySGStringsPath
        self.unitySGRulesPath = unitySGRulesPath
        self.enableJackpotForSlotGames = enableJackpotForSlotGames
        self.rgLogoImagePath = rgLogoImagePath
        self.cloudFrontVersonIDDetails = cloudFrontVersonIDDetails
        self.buildVersion = buildVersion
        self.serverConfig = serverConfig
        self.sliderIconPositionDetails = sliderIconPositionDetails
        self.sessionSettingsData = sessionSettingsData
        self.rcpuTimeFormat = rcpuTimeFormat
        self.sliderThemeCSS = sliderThemeCSS
        self.isInternalBuild = isInternalBuild
        self.sitecoreMappingKey = sitecoreMappingKey
        self.betmgmStateFullName = betmgmStateFullName
        self.slotSessionMinimumValue = slotSessionMinimumValue
        self.defaultErrorResponceTime = defaultErrorResponceTime
        self.unityGameRuleVersionDetails = unityGameRuleVersionDetails
    }
    
    mutating public func updateLastPlayedGame(gameName newValue: String?) {
        self.lastPlayedGame = newValue
    }
    
    mutating public func updateDepositURL(url: URL) {
        self.depositeUrl = url
    }
    
    mutating public func setgameInitErrorMessage(message: String) {
        self.gameInitErrorMessage = message
    }
    
    mutating public func updateResponsibleGamingURL(url: String) {
        self.responsibleGamingURL = url
    }
    
    mutating public func updateHistoryURL(url: String) {
        self.historyURL = url
    }
    
    mutating public func updateWithdrawURL(url: String) {
        self.withdrawUrl = url
    }
    
    mutating public func updateSliderGamesList(games: [String]) {
        self.gameList = games
    }
    
    mutating public func updateSesitivePageOpenStaus(status: Bool) {
        self.isSensitivePageOpened = status
    }
    
    mutating public func updateGeoLocationURL(url: String) {
        self.geoLocationURL = url
    }
}

public struct DynaconFeaturesConfigurations: Codable {
    public var autoRotationForLandscapeSupportedGames: Bool?
    public var checkPlayMGMUserVerification: Bool?
    public var isEnabledSliderBounceEffect: Bool?
    public var isEnableSliderIconHighlight: Bool?
    public var isContainerViewCanDraggable: Bool?
    public var isAccountBalanceValidation: Bool?
    public var enableQuickGamesContainerView: Bool?
    public var isEnabledSessionDuration: Bool?
    public var showLocationErrorPopup: Bool?
    public var isScreenNameValidation: Bool?
    public var enableKYCVerification: Bool?
    public var showWinLossSession: Bool?
    public var isEnableLandscape: Bool?
    public var showCurrentTime: Bool?
    public var isEnabledBFS: Bool?
    public var enableEzNav2: Bool?
    public var isEnableQuickGamesPopup: Bool?
    public var forceEnableQuickGamesPopup: Bool?
    public var gameNameTextStyle: String?
    public var enableHistoryURL: Bool?
    public var SliderWindowOpenAnimationDuration: CGFloat?
    public var charSizeLimit: Int?
    public var enableGamePillImage: Bool?
    public var socketConnectAndReconnectForAllGames: Bool?
    public var showAppLoginSessionDuration: Bool?
    public var enableNewGameDisplayIcons: Bool?
    public var displayPlayDurationTimeInSec: Bool?
    public var enableSessionSettingPage: Bool?
    public var isBypassingTechnicalError: Bool?
    public var hideUnfinishedPopupForRouletteOnlyGames: Bool?
    public var enablePlayDurationText: Bool?
}

public enum GameNameStyle: String {
    case truncated = "truncated"
    case singleLine = "singleLine"
    case doubleLine = "doubleLine"
}

public struct CloudFrontVersonIDDetailsWithBuildVersion: Codable {
    public let betaCloudFrontUrl: [String: CommonData]?
    public let prodCloudFrontUrl: [String: CommonData]?
}
public struct CommonData: Codable {
    public let unityGameResourcesFileName: String?
    public let jsonFileUrlExtension: String?
    public let unityGameResourcesFileVersionId: String?
    public let gameList: [GameList]?
    public let enableSliderGames: Bool?
}

public struct CloudFrontURLPath: Codable {
    public var urlPath: String
}

public struct GameList: Codable {
    public let gamename: String
    public let isEnable: Bool
}

public struct SliderGameServerConfig: Codable {
    
    public let gameServerIp: String?
    public let gameServerPort: String?
    public let rtmsServerURL: String?
    public let rtmsPlayBreakServerURL: String?
    public let responsibleGamingURL: String?
    public let gameLaunchkpiURL: String?
    public let awsResourceDownloadPath: String?
    
    enum CodingKeys: String, CodingKey {
        case gameServerIp = "game_server_ip"
        case gameServerPort = "game_server_port"
        case rtmsServerURL = "rtms_server_url"
        case rtmsPlayBreakServerURL = "rtms_playbreak_server_url"
        case responsibleGamingURL = "responsibleGamingURLWithLanguage"
        case gameLaunchkpiURL = "gameLaunchkpiURL"
        case awsResourceDownloadPath = "aws_resource_download_path"
    }
}

public struct SliderIconPosition: Codable {
    public let sidePosition: String?
    public let yValue: CGFloat?
    public let forceUpdate: Int?
    
    public var sliderIconLocation: CGPoint {
        CGPoint(x: 0.0, y: yValue ?? 0.0)
    }
    
    public var forceUpdatePosition: Bool {
        forceUpdate == 1 ? true : false
    }
}

public struct SessionSettingsData: Codable {
    public let maxSessionLoss: [Int]
    public let maxSessionTime: [Int]
    public let breakTime: [Int]
}
