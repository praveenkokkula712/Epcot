//
//  DualModeConfigContext.swift
//  Utility
//
//  Created by Challa Venkata Narasimha Karthik on 22/06/22.
//

import Foundation

public enum GameDownloadMode: Int, Codable {
    case html = -2
    case unknown = -1
    case aws = 0
    case odr
    case dual
    
    public var description: String {
        switch self {
        case .odr: return "ODR"
        case .aws: return "AWS"
        case .html: return "HTML"
        default: return "Unknown"
        }
    }
    
    public var urlType: URLType {
        switch self {
        case .aws:
            return .cloudFront
        case .odr:
            return .odr
        case .html: return .html
        default:
            return .unknown
        }
    }
}

public struct DualModeConfigContext {
    
    public var downloadMode: GameDownloadMode?
    public var isLightWeightEnabled: Bool
    public var cloudFrontBasePath: String?
    public var gameResourceInfoMappingVersionId: String?
    public var gameControllerCloudFrontPath: String?
    public var gameControllerVersionId: String?
    public var gameResourceInfoMappingCloudFrontPath: String?
    public var gameResourceInfoMappingFileName: String?
    public var shouldUseDefaultConfiguration: Bool
    public var cloudFrontQueryString: String?
    public var gameMediaAssetVersionId: String?
    public var gameMediaAssetCloudFrontPath: String?
    public var gameMediaAssetFileName: String?
    
    public init(downloadMode: GameDownloadMode?,
                isLightWeightEnabled: Bool,
                cloudFrontBasePath: String?,
                gameResourceInfoMappingVersionId: String?,
                gameControllerCloudFrontPath: String?,
                gameControllerVersionId: String?,
                gameResourceInfoMappingCloudFrontPath: String?,
                gameResourceInfoMappingFileName: String?,
                shouldUseDefaultConfiguration: Bool,
                cloudFrontQueryString: String?,
                gameMediaAssetVersionId: String?,
                gameMediaAssetCloudFrontPath: String?,
                gameMediaAssetFileName: String?) {
        
        self.downloadMode = downloadMode
        self.isLightWeightEnabled = isLightWeightEnabled
        self.cloudFrontBasePath = cloudFrontBasePath
        self.gameResourceInfoMappingVersionId = gameResourceInfoMappingVersionId
        self.gameControllerCloudFrontPath = gameControllerCloudFrontPath
        self.gameControllerVersionId = gameControllerVersionId
        self.gameResourceInfoMappingCloudFrontPath = gameResourceInfoMappingCloudFrontPath
        self.gameResourceInfoMappingFileName = gameResourceInfoMappingFileName
        self.shouldUseDefaultConfiguration = shouldUseDefaultConfiguration
        self.cloudFrontQueryString = cloudFrontQueryString
        self.gameMediaAssetVersionId = gameMediaAssetVersionId
        self.gameMediaAssetCloudFrontPath = gameMediaAssetCloudFrontPath
        self.gameMediaAssetFileName = gameMediaAssetFileName
    }
}
