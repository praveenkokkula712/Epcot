//
//  GameStoriesConfig.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 17/04/23.
//

import Foundation

public struct GameStoriesConfig {
    public let isGameStoriesEnabled: Bool
    public let showHeaderTitle: Bool
    public let subStoryDisplayTime: Double
    public let subStoryCompletionSpeed: Double

    public init(isGameStoriesEnabled: Bool = true,
                showHeaderTitle: Bool = true,
                subStoryDisplayTime: Double = 10.0,
                subStoryCompletionSpeed: Double = 0.2) {
        self.isGameStoriesEnabled = isGameStoriesEnabled
        self.showHeaderTitle = showHeaderTitle
        self.subStoryDisplayTime = subStoryDisplayTime
        self.subStoryCompletionSpeed = subStoryCompletionSpeed
    }
}
