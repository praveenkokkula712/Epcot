//
//  LMTKycModel.swift
//  Utility
//
//  Created by Praveen Kokkula on 20/03/24.
//

import Foundation

public struct LMTKycModel {
    public var isKycFetchNeeded: Bool = false
    public var status: Bool = false
    
    public init(isKycFetchNeeded: Bool, status: Bool) {
        self.isKycFetchNeeded = isKycFetchNeeded
        self.status = status
    }
}
