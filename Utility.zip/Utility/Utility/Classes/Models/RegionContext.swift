//
//  RegionContext.swift
//  Utility
//
//  Created by Praveen Kokkula on 13/03/24.
//

import Foundation

public struct RegionContext {
    public var region: String?
    public var countryName: String?
    public var coordinates: String?
    
    public init(region: String? = nil,
                countryName: String? = nil,
                coordinates: String? = nil) {
        self.region = region
        self.countryName = countryName
        self.coordinates = coordinates
    }
}
