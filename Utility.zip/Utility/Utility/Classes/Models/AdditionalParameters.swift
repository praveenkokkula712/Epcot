//
//  AdditionalParameters.swift
//  Utility
//
//  Created by Bandaru Priyanka on 19/02/24.
//

import Foundation

public struct AdditionalParameters {
    public var categoryID: String
    public var subCategoryID: String
    public var row: Int
    public var column: Int
    public var positionCount: Int
    public var iconSize: Int
    public var mode: String
    public var location: String
    public var webGameLaunchUrl: String

    public init(categoryID: String = "", subCategoryID:String = "", row: Int = 0, column: Int = 0, positionCount: Int = 0, iconSize:Int = 0, mode:String = "real", location:String = "", webGameLaunchUrl: String = "") {
        self.categoryID = categoryID
        self.subCategoryID = subCategoryID
        self.row = row
        self.column = column
        self.positionCount = positionCount
        self.iconSize = iconSize
        self.mode = mode
        self.location = location
        self.webGameLaunchUrl = webGameLaunchUrl
    }
}
