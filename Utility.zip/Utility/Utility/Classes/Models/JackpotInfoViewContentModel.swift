//
//  JackpotInfoViewContentModel.swift
//  Utility
//
//  Created by Santhosh Kodadi on 28/02/24.
//

import Foundation

//MARK: Font Family for Displaying JackpotInfoViewContent loaded on WebView
public struct JackpotInfoViewContentModel {
    let fontFileName: String
    let fontSize: Int
    let fontName: String
    
    public init(fontFileName: String = "", fontSize: Int = 0, fontName: String = "") {
        self.fontFileName = fontFileName
        self.fontSize = fontSize
        self.fontName = fontName
    }
}
