//
//  NativeFooterContext.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 13/12/22.
//

import Foundation

public struct NativeFooterContext {
    
    public enum NativeFooterType: Int, CaseIterable {
        case stateSelect = 0
        case seolinks   = 1
        case aboutUs    = 2
        case content    = 3
        case rgcontent  = 4
        case copyright  = 5
        case logos      = 6
        case brandlogo  = 7
        case rigtOldlogos = 8
    }
    
    public var types:[NativeFooterType]?
}

public struct NativeFooterItem {
    
    public let type: NativeFooterContext.NativeFooterType?
    public let referenceLink:String?
    public let nativeActionCategory:Int?
    public let selectedState: String?
    
    public init(type: NativeFooterContext.NativeFooterType,
                referenceLink: String? = nil,
                nativeActionCategory: Int? = nil,
                selectedState: String? = nil) {
        self.type = type
        self.referenceLink = referenceLink
        self.nativeActionCategory = nativeActionCategory
        self.selectedState = selectedState
    }
}
