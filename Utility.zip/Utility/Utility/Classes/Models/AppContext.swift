//
//  AppContext.swift
//  Utility
//
//  Created by Sumeet Bajaj on 13/01/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import Foundation

public struct AppContext {

    public var brandId: String?
    public var invokerProduct: String?
    public var productId: String?
    public var channelId: String?
    public var lang: String?
    public var lobbyType: String?
    public var frontendId: String?
    public var defaultCurrency: String?
    public var isODR: Bool?
    public var environment:String?
    public var cacheCount:Int?
    public var geoVarient : String?
    public var brandTitle: String?
    public var launchType:String?
    public var reqSource:String?
    public var shouldDisplayScreenLogs:Bool?
    public var usStateprefix:String?
    public var isSlider: Bool = false
    public var userIP: String?
    public var isDemoMode: Bool = false
    public var sitecoreCulture: String = "en-US"
    public var isCustomThemeEnabled: Bool = false
    public var rtmsProductId: String = "CASINO"
    public var isFeedLogNeeded: Bool = false
    public var isVenmoRequired: Bool = false
    public var shouldDisplayRegulatoryAlerts: Bool = false
    public var ezNavHtmlUrl: String = ""
    public var overelaysAndToastersConfig: OverlaysAndToasterConfigurations?
    public var appType: String?
    public var liveCasino: String?
    public var networkType: String?
    public private(set) var deviceUniqueId: String = ""
    public var isExtendedCategoriesFetchEnabled: Bool = false
    public var isHomePillNeeded: Bool? = false
    public var requestedDNS: String?
   
    public init(brandId: String? = nil,
                invokerProduct: String? = nil,
                productId: String? = nil,
                channelId: String? = nil,
                lang: String? = nil,
                lobbyType: String? = nil,
                frontendId: String? = nil,
                defaultCurrency: String? = nil,
                isODR: Bool = false,
                environment: String? = nil,
                geoVarient : String? = "common",
                cacheCount: Int? = nil,
                brandTitle: String? = nil,
                launchType:String?,
                reqSource: String?,
                shouldDisplayScreenLogs: Bool? = false,
                usStateprefix:String? = nil,
                isSlider: Bool = false,
                userIP: String?,
                isDemoMode: Bool = false,
                sitecoreCulture: String = "en-US",
                isCustomThemeEnabled: Bool = false,
                rtmsProductId: String = "CASINO",
                isFeedLogNeeded: Bool = false,
                isVenmoRequired: Bool = false,
                shouldDisplayRegulatoryAlerts: Bool = false,
                ezNavHtmlUrl: String,
                overlaysToastersConfig: OverlaysAndToasterConfigurations? = OverlaysAndToasterConfigurations(),
                appType: String? = nil,
                liveCasino: String = "LiveCasino",
                networkType: String? = nil,
                deviceUniqueId: String = "",
                isExtendedCategoriesFetchEnabled: Bool = false,
                isHomePillNeeded: Bool  = false,
                requestedDNS: String = "") {
        self.brandId = brandId
        self.channelId = channelId
        self.invokerProduct = invokerProduct
        self.productId = productId
        self.lang = lang
        self.lobbyType = lobbyType
        self.frontendId = frontendId
        self.defaultCurrency = defaultCurrency
        self.isODR = isODR
        self.environment = environment
        self.cacheCount = cacheCount
        self.geoVarient = geoVarient
        self.brandTitle = brandTitle
        self.launchType = launchType
        self.reqSource = reqSource
        self.shouldDisplayScreenLogs = shouldDisplayScreenLogs
        self.usStateprefix = usStateprefix
        self.isSlider = isSlider
        self.userIP = userIP
        self.isDemoMode = isDemoMode
        self.sitecoreCulture = sitecoreCulture
        self.isCustomThemeEnabled = isCustomThemeEnabled
        self.rtmsProductId = rtmsProductId
        self.isFeedLogNeeded = isFeedLogNeeded
        self.isVenmoRequired = isVenmoRequired
        self.shouldDisplayRegulatoryAlerts = shouldDisplayRegulatoryAlerts
        self.ezNavHtmlUrl = ezNavHtmlUrl
        self.overelaysAndToastersConfig = overlaysToastersConfig
        self.appType = appType
        self.liveCasino = liveCasino
        self.networkType = networkType
        self.deviceUniqueId = deviceUniqueId
        self.isExtendedCategoriesFetchEnabled = isExtendedCategoriesFetchEnabled
        self.isHomePillNeeded = isHomePillNeeded
        self.requestedDNS = requestedDNS
    }
    
    mutating public func updateLanguage(language value: String) {
        self.lang = value
    }
}
