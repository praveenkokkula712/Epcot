//
//  QuantumValue.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 15/05/24.
//

import Foundation

public enum QuantumValue: Codable {
    case int(Int), string(String), bool(Bool), double(Double)
}

public extension QuantumValue {
    init(from decoder: Decoder) throws {
        if let int = try? decoder.singleValueContainer().decode(Int.self) {
            self = .int(int)
            return
        }
        if let string = try? decoder.singleValueContainer().decode(String.self) {
            self = .string(string)
            return
        }
        if let bool = try? decoder.singleValueContainer().decode(Bool.self) {
            self = .bool(bool)
            return
        }
        if let double = try? decoder.singleValueContainer().decode(Double.self) {
            self = .double(double)
            return
        }
        throw QuantumError.missingValue
    }
}

public extension QuantumValue {
    var intValue: Int? {
        switch self {
        case .int(let int): return int
        case .string(let string): return Int(string)
        case .bool(let bool): return NSNumber(value: bool).intValue
        case .double(let double): return Int(double)
        }
    }
    var stringValue: String? {
        switch self {
        case .int(let int): return String(int)
        case .string(let string): return string
        case .bool(let bool): return String(bool)
        case .double(let double): return String(double)
        }
    }
}

//MARK: - QunatumError
public enum QuantumError: Error {
    case missingValue
}
