//
//  SearchConfiguration.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 16/08/23.
//

import Foundation

public struct SearchConfiguration {
    public let showCategories: Bool
    public private(set) var sections: [SearchSectionData] = []
    public let resultsLayoutType: Int
    public let favouriteEnabled: Bool
    public let downloadIconEnabled: Bool
    public let playButtonEnabled: Bool
    public let stickerEnabled: Bool
    public let jackpotEnabled: Bool
    
    public init(showCategories: Bool = false,
                sections: [[String: Any]] = [],
                resultsLayout: Int = 1,
                favouriteEnabled: Bool = false,
                downloadIconEnabled: Bool = false,
                playButtonEnabled: Bool = false,
                stickerEnabled: Bool = false,
                jackpotEnabled: Bool = false) {
        self.showCategories = showCategories
        self.sections = sections.compactMap { SearchSectionData(sectionData: $0) }
        self.resultsLayoutType = resultsLayout
        self.favouriteEnabled = favouriteEnabled
        self.downloadIconEnabled = downloadIconEnabled
        self.playButtonEnabled = playButtonEnabled
        self.stickerEnabled = stickerEnabled
        self.jackpotEnabled = jackpotEnabled
    }
}
