//
//  SearchV2Section.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 16/08/23.
//

import Foundation

public struct SearchSectionData {
    public let title: String
    public let layoutType: Int
    public let headerType: Int
    public let dataSourceType: Int
    public let limit: Int?
    public let stickers: [String]?

    public init(sectionData: [String: Any] = [:]) {
        self.title = sectionData["title"] as? String ?? ""
        self.layoutType = sectionData["layoutType"] as? Int ?? 0
        self.dataSourceType = sectionData["dataSourceType"] as? Int ?? 0
        self.limit = sectionData["limit"] as? Int ?? 0
        self.headerType = sectionData["headerType"] as? Int ?? 1
        self.stickers = sectionData["stickers"] as? [String] ?? []
    }
}
