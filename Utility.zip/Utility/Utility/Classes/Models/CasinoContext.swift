//
//  CasinoContext.swift
//  Utility
//
//  Created by Sumeet Bajaj on 13/01/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import Foundation

fileprivate var gameResourceFileName : String = "GameResource"

public enum ArbitaryTypeToInt: Codable, Equatable {
    case int(Int)
    
    public init(from decoder: Decoder) throws {
        if let int = try? decoder.singleValueContainer().decode(Int.self) {
            self = .int(int)
            return
        }
        
        if let string = try? decoder.singleValueContainer().decode(String.self) {
            let intValue = Int(string) ?? 0
            self = .int(intValue)
            return
        }
        
        if let double = try? decoder.singleValueContainer().decode(Double.self) {
            self = .int(Int(double))
            return
        }
        
        throw ArbitaryTypeError.missingValue
    }
    
    enum ArbitaryTypeError: Error {
        case missingValue
    }
}

public struct ResourceInfo: Codable {
        
    public let variantname: String?
    public let key: String?
    public let versionId: String?
    public let version: String?
    public let gameCode: String?
    public let fileName: String?
    public let filePath: String?
    private let fileSize: ArbitaryTypeToInt?
    private let gameVersion: ArbitaryTypeToInt?
    public let odrTag: String?
    public let lightWeightFilePath: String?
    public let lightWeightVersionId: String?
    private let lightFileSize: ArbitaryTypeToInt?
    public let bundleTag: String?
    public let isHtmlGameEnabled: Bool?
    
    public var fileSizeIntValue: Int? {
        switch fileSize {
        case .int(let value):
            return value
        case .none:
            return nil
        }
    }
    
    public var gameVersionIntValue: Int? {
        switch gameVersion {
        case .int(let value):
            return value
        case .none:
            return nil
        }
    }
    
    public var lightFileSizeIntValue: Int? {
        switch lightFileSize {
        case .int(let value):
            return value
        case .none:
            return nil
        }
    }
    
    public var isGroupedLightWeightBundle: Bool {
        return odrTag != bundleTag && !(bundleTag?.isEmpty ?? true)
    }
}

public struct MediaAssetMapping: Codable, Equatable {
    public var mediaPath: String
    public var versionId: String
    public var gameVersion: Int
    
    public var fileName: String {
        guard let fileName = mediaPath.split(separator: "/").last else {
            return ""
        }
        return String(fileName)
    }
    
    enum CodingKeys: String, CodingKey {
        case mediaPath = "media_path"
        case versionId
        case gameVersion
    }
}

public struct LiveInfo {

    public let providers: [String]?
    public let games: [String]?
    
    public init(providers:[String]?, games:[String]?) {
        self.providers = providers
        self.games = games
    }
}

public typealias GamesMediaAssetMapper = [String: MediaAssetMapping]

public struct CasinoContext {
    
    /// File name of game resource plist placed in main bundle
    let gameResource: String?
    
    /// Local server port to run local server and game launch
    public var localServerPort: UInt = 0
    
    /// All live games/provider info data
    public var liveInfo:LiveInfo?
    
    // Game server info for side connection
    public var server: Server?
    
    // slotSession info for regulatory pop-ups
    public var slotSession: SlotSession?
    
    // RCPU One hour for regulatory pop-ups
    public var rCPUOnehour: RCPUOnehour?
        
    public init(gameResource: String?,
                localServerPort port: UInt,
                liveInfo: LiveInfo? =  nil,
                server: Server? = nil,
                slotSession: SlotSession? = nil,
                rCPUOnehour: RCPUOnehour? = nil) {
        
        self.gameResource = gameResource
        self.localServerPort = port
        self.liveInfo = liveInfo
        self.server = server
        self.slotSession = slotSession
        self.rCPUOnehour = rCPUOnehour
        gameResourceFileName = gameResource ?? gameResourceFileName
    }
    
    // MARK: GR.plist
    
    private static var gameResourceData: [String: ResourceInfo]? = readGameResourceInfoFromPlist(gameResource: gameResourceFileName)
    private var _gameResourceInfo: [String: ResourceInfo]?  {
        get {
            return CasinoContext.gameResourceData
        }
    }
    
    public mutating func resourceInfo(key:String) -> ResourceInfo? {
        return _gameResourceInfo?[key]
    }
    
    public mutating func gameResourceInfo() -> [String: ResourceInfo]? {
        return _gameResourceInfo
    }
    
    public mutating func filterGameResource(by odrTag: String?) -> [ResourceInfo]? {
        return _gameResourceInfo?.filter({ $0.value.odrTag == odrTag }).map({ $0.value })
    }
    
    private static func readGameResourceInfoFromPlist(gameResource : String?) ->  [String: ResourceInfo]? {
        guard let resourceFileName = gameResource else {
            ETLogger.debug("Missing resource file name")
            return nil
        }
        guard let url = Bundle.main.url(forResource: resourceFileName, withExtension: "plist") else {
            ETLogger.debug("Unable to find \(resourceFileName).plist")
            return nil
        }
        do {
            let data = try Data(contentsOf: url)
            let dic = try PropertyListDecoder().decode(Dictionary<String, ResourceInfo>.self, from: data)
            return dic
        } catch {
            ETLogger.debug(error.localizedDescription)
            let gameLogs = GameLogs(message: "Failed to parse GR.plist data. Error: \(error.localizedDescription)")
            KibanaLogManager.sendLogs(of: .gameLogs, with: gameLogs)
            return nil
        }
    }
    
    // MARK: GRIM.json
    
    private var _gameResourceInfoMapping: [String: ResourceInfo]?  {
        get {
            return Self.readGameResourceInfoMapping()
        }
    }
    
    public mutating func gameResourceInfoMapping(key:String) -> ResourceInfo? {
        return _gameResourceInfoMapping?[key]
    }
    
    public mutating func gameResourceInfoMapping() -> [String: ResourceInfo]? {
        return _gameResourceInfoMapping
    }
    
    private static func readGameResourceInfoMapping() -> [String: ResourceInfo]? {
        guard let resourceFileName = EntainContext.gameResourceInfo?.fileName else {
            ETLogger.debug("Missing resource file name")
            return nil
        }
        let url = FileManager.default.documentsDirectory.appendingPathComponent(resourceFileName)
        do {
            let data = try Data(contentsOf: url)
            let dictionary = try JSONDecoder().decode(Dictionary<String, ResourceInfo>.self, from: data)
            return dictionary
        } catch {
            ETLogger.debug(error.localizedDescription)
            return nil
        }
    }
    
    public mutating func updateGameVersion() {
        guard let gameResourceInfoMapping = Self.readGameResourceInfoMapping() else { return }
        for (key, value) in gameResourceInfoMapping {
            CasinoContext.gameResourceData?[key] = value
        }
    }
    
    // MARK: GMA.json
    
    enum IntegrationType {
        case embedded
        case downloaded
    }
    
    private static var gameMediaAssetMappingEmbeddedData: GamesMediaAssetMapper? = readGameMediaAssetMappingData(source: .embedded)
    private static var gameMediaAssetMappingDownloadedData: GamesMediaAssetMapper? = readGameMediaAssetMappingData(source: .downloaded)
    private var gameMediaAssetMappingData: GamesMediaAssetMapper?  {
        get {
            return CasinoContext.gameMediaAssetMappingEmbeddedData
        }
    }
    
    public mutating func gameMediaAssetMapping() -> GamesMediaAssetMapper? {
        return gameMediaAssetMappingData
    }
    
    public mutating func resetMediaData() {
        CasinoContext.gameMediaAssetMappingEmbeddedData = nil
        CasinoContext.gameMediaAssetMappingDownloadedData = nil
    }
    
    private static func readGameMediaAssetMappingData(source: IntegrationType) -> GamesMediaAssetMapper? {
        
        var url: URL
        let resourceFileName = EntainContext.dualModeConfigContext?.gameMediaAssetFileName ?? "gamesMediaAssetMapping.json"
        
        switch source {
        case .embedded:
            let fileComponents = resourceFileName.split(separator: ".")
            guard let fileName = fileComponents.first,
                  let fileExtension = fileComponents.last,
                  let fileUrl = Bundle.main.url(forResource: String(fileName), withExtension: String(fileExtension)) else {
                ETLogger.debug("GameMediaAssetMapping file not found")
                return nil
            }
            url = fileUrl
        case .downloaded:
            url = FileManager.default.documentsDirectory.appendingPathComponent(resourceFileName)
        }
        
        do {
            let data = try Data(contentsOf: url)
            let dictionary = try JSONDecoder().decode(Dictionary<String, MediaAssetMapping>.self, from: data)
            return dictionary
        }
        catch {
            ETLogger.debug(error.localizedDescription)
            return nil
        }
    }
    
    public mutating func mergeLocalGmaWithDownloadedGma() {
        guard let gameMediaAssetMappingFromCache = CasinoContext.gameMediaAssetMappingDownloadedData else { return }
        for (key, value) in gameMediaAssetMappingFromCache {
            CasinoContext.gameMediaAssetMappingEmbeddedData?[key] = value
        }
    }
}

extension CasinoContext {
    
    public struct Server {
        
        public var ip: String?
        public var port: String?
        
        public init(ip:String? = nil, port:String? = nil) {
            self.ip = ip
            self.port = port
        }
    }
    public struct SlotSession {
        
        public var sessionUrl: String?
        public var featureid: String?
        
        public init(sessionUrl:String? = nil, featureid:String? = nil) {
            self.sessionUrl = sessionUrl
            self.featureid = featureid
        }
    }
    public struct RCPUOnehour {
        
        public var idealTimeForOneHourPopup: Int?
        public var sessionTimeForOneHourPopup: Int?
        
        public init(idealTimeForOneHourPopup:Int? = nil, sessionTimeForOneHourPopup:Int? = nil) {
            self.idealTimeForOneHourPopup = idealTimeForOneHourPopup
            self.sessionTimeForOneHourPopup = sessionTimeForOneHourPopup
        }
    }
}
