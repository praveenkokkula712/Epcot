//
//  PlayerStatsConfig.swift
//  Utility
//
//  Created by Sindhuja Vedire on 25/07/24.
//

import Foundation

public struct PlayerStatsConfig: Codable {
    public private(set) var minimumMuliplierBet: CGFloat?
    
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.minimumMuliplierBet = try container.decodeIfPresent(CGFloat.self, forKey: .minimumMuliplierBet)
    }
}
