//
//  USUnifiedContext.swift
//  Utility
//
//  Created by Praveen Kokkula on 08/12/21.
//

import Foundation

public struct USUnifiedContext {
    public var stateCode: String?
    public var unifiedVendors: [String]?
    public var brandDNS: String?
    
    public init(stateCode: String? = nil,unifiedVendors: [String]? = nil, brandDNS: String? = nil) {
        self.stateCode = stateCode
        self.unifiedVendors = unifiedVendors
        self.brandDNS = brandDNS
    }
}


public struct DepositContext {
    public var isApplePayEnabled: Bool = false
    public var applePayCashierUrls: [String]?
    public var applePayExcludeUrls: [String]?
    public var appUrlScheme: String?

    public init(applePayEnabled: Bool = false,
                applePayCashierUrls: [String]?,
                applePayExcludeUrls: [String]?,
                urlScheme: String?) {
        self.isApplePayEnabled = applePayEnabled
        self.applePayCashierUrls = applePayCashierUrls
        self.applePayExcludeUrls = applePayExcludeUrls
        self.appUrlScheme = urlScheme
    }
}
