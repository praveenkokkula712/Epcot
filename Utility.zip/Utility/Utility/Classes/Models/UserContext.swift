//
//  UserContext.swift
//  Utility
//
//  Created by Sumeet Bajaj on 13/01/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import Foundation

public struct UserContext {
    
    public var availableMemory:String?
    public var countryCode:String?
    public var accountId: String?
    public var accountName: String?
    public var ssoKey: String?
    public var ip: String?
    public var currency: String?
    public var name:String?
    public var userToken:String?
    public var sessionToken:String?
    public var screenName:String?
    public var accountBalance: String?
    public var kycVerificationStatus: Bool?
    public var isDemoUser: Bool?
    public var lmtKycModel: LMTKycModel?
    
    public init (accountName: String? = nil,
                 ssoKey: String? = nil,
                 ip: String? = nil,
                 currency: String? = nil,
                 name: String? = nil,
                 accountId:String? = nil,
                 countryCode: String? = nil,
                 userToken: String? = nil,
                 sessionToken: String? = nil,
                 screenName: String? = nil,
                 accountBalance:String? = nil,
                 kycVerificationStatus: Bool? = nil,
                 isDemoUser: Bool = false,
                 availableMemory: String? = nil) {
        
        self.accountName = accountName
        self.ssoKey = ssoKey
        self.ip = ip
        self.currency = currency
        self.name = name
        self.accountId = accountId
        self.countryCode = countryCode
        self.userToken = userToken
        self.sessionToken = sessionToken
        self.screenName = screenName
        self.accountBalance = accountBalance
        self.kycVerificationStatus = kycVerificationStatus
        self.isDemoUser = isDemoUser
        self.availableMemory = availableMemory
    }
    
    public func isLoggedIn() -> Bool {
        return self.ssoKey != nil
    }
    
    public mutating func updateScreenName(newName: String) {
        self.screenName = newName
    }
    
    public mutating func updateAccountBalance(with balance: String) {
        self.accountBalance = balance
    }
    
    public mutating func updateKYCVerificationStatus(with status: Bool) {
        self.kycVerificationStatus = status
    }
    
    public mutating func updateAvailableMemory(with memory: String) {
        self.availableMemory = memory
    }
}

