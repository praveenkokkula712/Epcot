//
//  StringAttributes.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 04/04/24.
//

import Foundation

public struct StringAttributes {
    public let text: String
    public let color: UIColor
    public let font: UIFont
    public let linkURL: String

    public init(text: String, color: UIColor, font: UIFont, linkURL: String = "") {
        self.text = text
        self.color = color
        self.font = font
        self.linkURL = linkURL
    }
}

public class Attributed {
    public class func attributedString(with attributes: [StringAttributes]) -> NSMutableAttributedString {
        let str: String = attributes.compactMap({ $0.text }).joined()
        let attributedString = NSMutableAttributedString(string: str)
        
        for attribute in attributes {
            if let range = str.range(of: attribute.text.trimmed) {
                let nsRange = NSRange(range, in: str)
                if !attribute.linkURL.isEmpty {
                    attributedString.underLine(onRange: nsRange)
                    attributedString.apply(attribute: [.link: attribute.linkURL], onRange: nsRange)
                }
                attributedString.apply(color: attribute.color, onRange: nsRange)
                attributedString.apply(font: attribute.font, onRange: nsRange)
            }
        }
        return attributedString
    }
}
