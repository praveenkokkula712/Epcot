//
//  AlertCoordinator.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 27/07/23.
//

import Foundation
import UIKit

public final class AlertCoordinator {
    private var alertQueue = [Any]()
    private var currentDisplayingAlert: Any? = nil

    func show(_ view: Any) {
        alertQueue.append(view)
        if currentDisplayingAlert == nil {
            dequeueAlert()
        }
    }
    
    func remove(_ view: Any, completion: (() -> Void)? = nil) {
        // TODO: add call back here
        if let vc = view as? AlertPresenter, let _ = vc.vc.presentingViewController {
            vc.vc.dismiss(animated: vc.isAnimationRequired) {
                self.currentDisplayingAlert = nil
                self.dequeueAlert()
                if let completion {
                    completion()
                }
            }
        } else if let vc = view as? UIViewController, let _ = vc.presentingViewController {
            vc.dismiss(animated: true) {
                self.currentDisplayingAlert = nil
                self.dequeueAlert()
                if let completion {
                    completion()
                }
            }
        } else if let aView = view as? UIView, let _ = aView.superview {
            if let animated = aView as? AnimatedWindowView,
               animated.shouldAnimate() {
                UIView.animate(withDuration: 0.30) {
                    aView.frame = CGRect(x: 0, y: -(UIDevice.screenSize.height),
                                         width: (UIDevice.screenSize.width),
                                         height: UIDevice.screenSize.height)
                } completion: { _ in
                    aView.removeFromSuperview()
                }
            } else {
                aView.removeFromSuperview()
            }
            currentDisplayingAlert = nil
            dequeueAlert()
        }
    }
    
    /// Dismiss any actively displaying alert, remove all alerts from the queue and pause the coordinator
    public func reset() {
        alertQueue.removeAll()
    }
    
    private func nextAlert() -> Any? {
        if !alertQueue.isEmpty {
            return alertQueue.removeFirst()
        }
        return nil
    }
    
    private func dequeueAlert() {
        guard let alert = nextAlert() else {
            return
        }
        self.present(alert)
    }

        
    private func present(_ alert: Any) {
        currentDisplayingAlert = alert
        if let vc = alert as? AlertPresenter {
            let keyWindow = UIApplication.mainWindow
            if let topController = keyWindow.rootViewController {
                topController.present(vc.vc, animated: vc.isAnimationRequired, completion: nil)
            }
        } else if let vc = alert as? UIViewController {
            let keyWindow = UIApplication.mainWindow
            if let topController = keyWindow.rootViewController {
                topController.present(vc, animated: true, completion: nil)
            }
        } else if let aView = alert as? UIView {
            UIApplication.firstWindow.addSubview(aView)
            UIApplication.firstWindow.bringSubviewToFront(aView)
            if let animated = aView as? AnimatedWindowView,
               animated.shouldAnimate() {
                UIView.animate(withDuration: 0.30) {
                    aView.frame = CGRect(x: 0, y: 0,
                                         width: (UIDevice.screenSize.width),
                                         height: UIDevice.screenSize.height)
                }
            } else if aView.accessibilityIdentifier == kToasterAccessibility {
                let aWindow = UIApplication.firstWindow
                aView.topAnchor.constraint(equalTo: aWindow.topAnchor, constant: 20).isActive = true
                aView.heightAnchor.constraint(greaterThanOrEqualToConstant: 100).isActive = true
                
                if UIDevice.isIPad() {
                    aView.widthAnchor.constraint(equalTo: aWindow.widthAnchor, multiplier: 0.5).isActive = true
                    aView.centerXAnchor.constraint(equalTo: aWindow.centerXAnchor).isActive = true
                    
                } else {
                    aView.leadingAnchor.constraint(equalTo: aWindow.leadingAnchor, constant: 10).isActive = true
                    aView.trailingAnchor.constraint(equalTo: aWindow.trailingAnchor, constant: -10).isActive = true
                }
            }
        }
    }
}

public protocol AnimatedWindowView {
    func shouldAnimate() -> Bool
}

extension AlertCoordinator {
    
    public class func showView(_ view: Any) {
        ImmersiveInstance.shared.alertCoordinator.show(view)
    }
    
    public class func removeView(_ view: Any, completion: (() -> Void)? = nil) {
        ImmersiveInstance.shared.alertCoordinator.remove(view, completion: completion)
    }
    
    public class func removeCurrentAlertView() {
        ImmersiveInstance.shared.alertCoordinator.currentDisplayingAlert = nil
    }
}

// Use this AlertPresenter if any viewController to be presented without any animation
public struct AlertPresenter {
    var vc: UIViewController
    var isAnimationRequired: Bool
    
    public init(vc: UIViewController, isAnimationRequired: Bool = false) {
        self.vc = vc
        self.isAnimationRequired = isAnimationRequired
    }
}
