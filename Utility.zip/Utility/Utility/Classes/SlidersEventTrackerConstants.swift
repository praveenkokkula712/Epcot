//
//  SlidersEventTrackerConstants.swift
//  Utility
//
//  Created by Gunnala Divya on 08/08/23.
//

import Foundation

//MARK: - Slider Game Event Tracking Constans
public enum SlidersEventCategory: String {
    case unity_quick_games = "unity quick games"
    case navigation = "navigation"
    case casino = "casino"
    case reality_check = "reality check"
    case deposit_prompt = "deposit_prompt"
    case gambling_controls = "gambling controls"
}

public enum SlidersEventAction: String {
    case load = "load"
    case click = "click"
    case close = "close"
    case error = "error"
    case session_limits_submit = "limits submit"
}

public enum SlidersEventLabel: String {
    case quick_games_icon = "quick games icon"
    case quick_games = "quick games"
    case overlay_navigation = "overlay navigation"
    case sub_navigation = "sub navigation"
    case realityCheck_winning_popup = "reality check pop-up with winnings"
    case big_balance_prompt = "big balance prompt"
    case max_session_limits = "max session limits"
}

public enum SlidersEventPosition: String {
    case slider_icon = "slider icon"
    case quick_games_popup = "quick games popup"
    case header = "header"
    case post_high_bet_settlement = "post high bet settlement"
    case session_settings = "session settings"
    case session_limit_near = "session limits remainder"
    case session_limit_reached = "session limits exhausted"
    case session_break_remainder = "break time remainder"
    case responsible_gaming_remainder = "rg settings remainder"
    case safer_gaming_info_tool_tip = "safer gaming tool tip"
    case max_session_loss_info_tool_tip = "maximum session loss tool tip"
    case max_session_time_info_tool_tip = "maximum session time tool tip"
}

public enum SlidersEventDetails: String {
    case slots = "slots"
    case roulette = "roulette"
    case blackjack = "blackjack"
    case quickgame_popup_load = "quickgame popup load"
    case close = "close"
    case ok = "ok"
    case cancel = "cancel"
    case start = "start"
    case add_quick_games = "add quick games"
    case maybe_later = "maybe later"
    case deposit = "deposit"
    case history = "history"
    case responsible_gambling = "responsible gambling"
    case spin_button = "spin button"
    case deal_button = "deal button"
    case surrender_button = "surrender button"
    case hit_button_pressed = "hit button pressed"
    case stand_button = "stand button"
    case inhouse = "inhouse"
    case existing = "existing"
    case playing = "playing"
    
    case rcpu_display = "reality check pop-up with winnings - displayed"
    case rcpu_got_it = "got it"
    case big_balance_prompt_display = "big balance prompt"
    case big_win_keep_playing = "keep playing"
    case big_win_cashier = "cashier"
    
    case session_settings = "session settings"
    case session_settings_safer_gambling = "safer gambling"
    case session_settings_play_now = "play now"
    case session_settings_limits_question = "why do i need to set these limits"
    case session_settings_max_session_loss = "max session loss"
    case session_settings_max_session_loss_percentage = "max session loss percentage"
    case session_settings_max_session_time = "max session time"
    case session_settings_max_session_time_value = "max session time value"
    case session_settings_session_break_time_value = "session break time value"
    case session_settings_dismiss = "session settings dismiss"
    case session_settings_show_balance = "show balance"
    case session_settings_hide_balance = "hide balance"
    case session_settings_drop_down_enabled = "drop down enabled"
    case session_settings_drop_down_disabled = "drop down disabled"
    case session_settings_swicth_toggle_on = "switch toggle on"
    case session_settings_swicth_toggle_off = "switch toggle off"
    case session_settings_max_loss_error = "you must set up a loss limit"
    case session_settings_max_time_error = "you must set up a time limit"
    case session_settings_session_break_error = "if session break is set to on, you must select a time period"
    case session_settings_success = "success"
    
    case safer_gaming_info_tool_tip = "safer gaming tool tip"
    case max_session_loss_info_tool_tip = "maximum session loss tool tip"
    case max_session_time_info_tool_tip = "maximum session time tool tip"
    
    case session_limit_near = "session limits remainder"
    case session_limit_reached = "session limits exhausted"
    case session_break_remainder = "break time remainder"
    case responsible_gaming_remainder = "rg settings remainder"
}

public enum SlidersEventLocation: String {
    case unity_quick_games  = "unity quick games"
    case sports = "sports"
}
