//
//  UILabel+Extension.swift
//  Utility
//
//  Created by Praveen Kokkula on 28/04/22.
//

import Foundation


public extension UILabel {
    func setupLabel(with color: UIColor?,
                    font: UIFont?,
                    textAlignment alignment: NSTextAlignment = .left) {
        self.font = font
        self.textColor = color
        self.textAlignment = alignment
        self.backgroundColor = .clear
    }
    
}
