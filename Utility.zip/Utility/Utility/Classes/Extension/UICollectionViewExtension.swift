//
//  UICollectionViewExtension.swift
//  Utility
//
//  Created by Praveen Kokkula on 07/04/22.
//

import Foundation

public extension UICollectionView {
    func registerDefaultCell(with reuseIDs: String...) {
        for reuseID in reuseIDs {
            self.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseID)
        }
    }
    
    func registerNibCells(withCells cells: String..., bundle: Bundle) {
        for cell in cells {
            self.register(UINib( nibName: cell,
                                 bundle: bundle),
                          forCellWithReuseIdentifier: cell)
        }
    }
    
    func setupDefaultConfiguration() {
        self.showsHorizontalScrollIndicator = false
        self.showsVerticalScrollIndicator = false
        self.isMultipleTouchEnabled = false
        self.bounces = false
    }
}

public extension UIScrollView {
    var scrollPercentage: Int {
        let currentOffset = self.contentOffset.y
        let contentSize = self.contentSize.height
        let scrollPercentage = Int((currentOffset/contentSize)*100)
        if scrollPercentage > 90 {
            return 100
        } else if scrollPercentage >= 75 {
            return 75
        } else if scrollPercentage >= 50 {
            return 50
        } else if scrollPercentage >= 25 {
            return 25
        }
        return 0
    }
}
