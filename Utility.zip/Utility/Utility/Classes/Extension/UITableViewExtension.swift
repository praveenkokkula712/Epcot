//
//  UITableViewExtension.swift
//  Utility
//
//  Created by Praveen Kokkula on 12/04/22.
//

import Foundation

public extension UITableView {
    
    func registerNibCells(withCells cells: String..., bundle: Bundle) {
        for cell in cells {
            let nib = UINib(nibName: cell, bundle: bundle)
            self.register(nib, forCellReuseIdentifier: cell)
        }
    }
    
    func registerDefaultCell(with reuseIDs: String...) {
        for reuseID in reuseIDs {
            self.register(UITableViewCell.self, forCellReuseIdentifier: reuseID)
        }
    }
}
