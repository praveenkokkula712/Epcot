//
//  DateExtension.swift
//  Pods
//
//  Created by Sumeet Bajaj on 10/06/2020.
//

import Foundation

// MARK:- DotNet Ticks constants
private let CTicks : Double = 62_135_596_800
private let CTicksPerSecond : Double = 10_000_000
private let CTicksMinValue : UInt64 = 0
private let CTicksMaxValue : UInt64 = 3_155_378_975_999_999_999

//MARK:- DotNet Ticks Implementation
public extension Date {
    
    var ticks: UInt64 {
        
        if self == Date.distantPast {
            return CTicksMinValue
        }
        
        if self == Date.distantFuture {
            return CTicksMaxValue
        }
        
        return UInt64((self.timeIntervalSince1970 + CTicks) * CTicksPerSecond)
    }
    
    /// Returns the amount of hours from another date
    func minute(from date: Date) -> Int {
        return Calendar.current.dateComponents([.minute], from: date, to: self).minute ?? 0
    }
    
    func toCurrentTimezone() -> Date {
        let timeZoneDifference =
        TimeInterval(TimeZone.current.secondsFromGMT())
        return self.addingTimeInterval(timeZoneDifference)
   }
}
public extension Date {
    var currentDateAndTime: String {
        let date = Date()
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let dateString = formatter.string(from: date)
        return dateString
    }
    
    static var currentddMMYYYY: String {
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        let dateString = formatter.string(from: date)
        return dateString
    }
    
    func getTimeDiff(start: Date, end: Date) -> Int  {
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([Calendar.Component.second], from: start, to: end)

        let seconds = dateComponents.second ?? 0
        return Int(seconds)
    }
}

public extension Date {
    
    /// Returns the amount of years from another date
    func years(from date: Date) -> Int {
        return Calendar.current.dateComponents([.year], from: date, to: self).year ?? 0
    }
    /// Returns the amount of months from another date
    func months(from date: Date) -> Int {
        return Calendar.current.dateComponents([.month], from: date, to: self).month ?? 0
    }
    /// Returns the amount of weeks from another date
    func weeks(from date: Date) -> Int {
        return Calendar.current.dateComponents([.weekOfMonth], from: date, to: self).weekOfMonth ?? 0
    }
    /// Returns the amount of days from another date
    func days(from date: Date) -> Int {
        return Calendar.current.dateComponents([.day], from: date, to: self).day ?? 0
    }
    /// Returns the amount of hours from another date
    func hours(from date: Date) -> Int {
        return Calendar.current.dateComponents([.hour], from: date, to: self).hour ?? 0
    }
    /// Returns the amount of minutes from another date
    func minutes(from date: Date) -> Int {
        return Calendar.current.dateComponents([.minute], from: date, to: self).minute ?? 0
    }
    /// Returns the amount of seconds from another date
    func seconds(from date: Date) -> Int {
        return Calendar.current.dateComponents([.second], from: date, to: self).second ?? 0
    }
    /// Returns the time components from another date
    func time(from date: Date) -> DateComponents {
        return Calendar.current.dateComponents([.day, .hour, .minute, .second], from: date, to: self)
    }
    
    /// Returns the a custom time interval description from another date
    func offset(from date: Date) -> String {
        if years(from: date)   > 0 { return "\(years(from: date))y"   }
        if months(from: date)  > 0 { return "\(months(from: date))M"  }
        if weeks(from: date)   > 0 { return "\(weeks(from: date))w"   }
        if days(from: date)    > 0 { return "\(days(from: date))d"    }
        if hours(from: date)   > 0 { return "\(hours(from: date))h"   }
        if minutes(from: date) > 0 { return "\(minutes(from: date))m" }
        if seconds(from: date) > 0 { return "\(seconds(from: date))s" }
        return ""
    }
}
public extension Date {
    func withTimeZone(_ timeZone: TimeZone? = TimeZone(abbreviation: "GMT")) -> Date {
        var calender = Calendar.current
        calender.timeZone = timeZone ?? .current
        let components = calender.dateComponents([.year,.month,.day,.hour,.minute,.second], from: self)
        return calender.date(from: components) ?? .now
    }
}

// MARK: - Extension  For Doble
extension Float {
    var clean: String {
        return self.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", self) : String(self)
    }
}

public extension Date {
    var unixTimestampInMicroseconds: String {
        // Get the Unix timestamp in seconds
        let unixTimestampInSeconds = self.timeIntervalSince1970
        // Convert to microseconds (1 second = 1,000,000 microseconds)
        let unixTimestampInMicroseconds = Int(unixTimestampInSeconds * 1000000)
        
        return String(unixTimestampInMicroseconds)
    }
}
