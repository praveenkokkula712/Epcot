//
//  Haptics.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 22/02/23.
//

import UIKit

public class Haptics {
    
    private init() { }

    public static func play(_ feedbackStyle: UIImpactFeedbackGenerator.FeedbackStyle) {
        UIImpactFeedbackGenerator(style: feedbackStyle).impactOccurred()
    }
}
