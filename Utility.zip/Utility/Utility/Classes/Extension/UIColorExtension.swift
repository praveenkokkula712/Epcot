//
//  UIColorExtension.swift
//  Utility
//
//  Created by Praveen Kokkula on 22/07/21.
//

import Foundation
import UIKit

public extension UIColor {
    static func hexStringToUIColor (hex:String,withAlpha alpha:CGFloat = 1.0) -> UIColor {
        
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }

        if ((cString.count) != 6) {
            return UIColor.gray
        }

        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)

        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: alpha
        )
    }
    
    static func convertFrom(hex: String, alpha: CGFloat = 1.0) -> UIColor {
        hexStringToUIColor(hex: hex, withAlpha: alpha)
    }
}
/// Apply some haptic effect with color animation 
extension UIColor {

    func addColorEffect(by percentage: CGFloat = 20.0) -> UIColor? {
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0, alpha: CGFloat = 0
        if self.getRed(&red, green: &green, blue: &blue, alpha: &alpha) {
            return UIColor(red: min(red + percentage/100, 1.0),
                           green: min(green + percentage/100, 1.0),
                           blue: min(blue + percentage/100, 1.0),
                           alpha: alpha)
        }
        return nil
    }
}

/// Converts the UIColor  to hexadecimal  color code
extension UIColor {

    func toHex() -> String? {
        guard let components = self.cgColor.components, components.count >= 3 else { return nil }
        let red = Float(components[0])
        let green = Float(components[1])
        let blue = Float(components[2])
        let hexCode = String(format: "%02lX%02lX%02lX", lroundf(red * 255), lroundf(green * 255), lroundf(blue * 255))
        return hexCode
    }
    
}
