//
//  UIApplicationExtension.swift
//  Pods
//
//  Created by Sumeet Bajaj on 19/08/2020.
//

import UIKit

public extension UIApplication {
    
    class func topViewController(controller: UIViewController? = UIApplication.mainWindow.rootViewController) -> UIViewController? {
        
        // If the app embedded with Navigation Controller
        if let navigationController = controller as? UINavigationController {
            return topViewController(controller: navigationController.visibleViewController)
        }
        // If the app using TabBar based controller
        if let tabController = controller as? UITabBarController {
            if let selected = tabController.selectedViewController {
                return topViewController(controller: selected)
            }
        }
        // Fetching presented controller from root view controller
        if let presented = controller?.presentedViewController {
            return topViewController(controller: presented)
        }
        // If nothing found then returning the UIApplication's root view Controller.
        return controller
    }

    static var screenSize: CGSize {
        let windowSize = Self.mainWindow.screen.bounds.size
        return windowSize 
    }
}

public extension UIApplication {
    
    class var safeAreaInsets: UIEdgeInsets {
        self.mainWindow.safeAreaInsets 
    }
    
    private var appWindows: [UIWindow]? {
        return self.connectedScenes
        // Keep only the first `UIWindowScene`
            .first(where: { $0 is UIWindowScene })
        // Get its associated windows
            .flatMap({ $0 as? UIWindowScene })?.windows
            .filter({ !$0.isHidden })
    }
    
    private var appWindow: UIWindow {
        // Get connected scenes
        guard let windowScene = self.appWindows?
        // Finally, keep only the key window
            .first(where: \.isKeyWindow) else {
            return (UIApplication.shared.delegate?.window as? UIWindow) ?? UIWindow() // TODO: fix here
        }
        return windowScene
    }
    
    class var mainWindow: UIWindow {
        self.shared.appWindow
    }
    
    class var mainWindows: [UIWindow]? {
        return self.shared.appWindows
    }
    
    class var firstWindow: UIWindow {
        return self.mainWindows?.first ?? self.mainWindow
    }
}
