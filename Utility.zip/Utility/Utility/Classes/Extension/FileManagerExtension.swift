//
//  FileManagerExtension.swift
//  MiniGames
//
//  Created by Sumeet Bajaj on 05/07/2018.
//  Copyright © 2018 Ivy Comptech. All rights reserved.
//

import Foundation

// Directory Name Constants

public extension FileManager {
    
    enum ActionType { case move, copy }
    enum ConflictResolution { case keepSource, keepDestination }
    
    var documentsDirectory: URL {
        return self.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    func isDir(atPath: String) -> Bool {
        var isDir: ObjCBool = false
        let exist = self.fileExists(atPath: atPath, isDirectory: &isDir)
        return exist && isDir.boolValue
    }
    
    func isFile(atPath: String) -> Bool {
        var isDir: ObjCBool = false
        let exist = self.fileExists(atPath: atPath, isDirectory: &isDir)
        return exist && !isDir.boolValue
    }
    
    func sizeOfItemInBytes(forPath path:String, completion:@escaping ((Int64) -> Void)) {
        
        let queue = DispatchQueue(label: "ItemSizeCalculationQueue", qos: .background)

        queue.async {

            do {
                var total:Int64 = 0
                
                let attributes = try self.attributesOfItem(atPath: path)

                if  let fileTye = attributes[FileAttributeKey.type] as? FileAttributeType, fileTye == .typeRegular  {
                    total = attributes[FileAttributeKey.size] as? Int64 ?? 0
                }
                else {

                    if let dirEnum = FileManager.default.enumerator(at: URL(fileURLWithPath: path), includingPropertiesForKeys: [.fileSizeKey], options: [.skipsHiddenFiles], errorHandler: nil)  {
                        
                        for object in dirEnum {
                            
                            if let fileURL = object as? URL {
                                do {
                                    let fileSizeResource = try fileURL.resourceValues(forKeys: [.fileSizeKey])
                                    total += Int64(fileSizeResource.fileSize ?? 0)
                                }
                                catch {
                                    ETLogger.debug(error.localizedDescription)
                                }
                            }
                        }
                    }
                }
            
                completion(total)
            } catch {
                completion(0)
                ETLogger.debug(error.localizedDescription)
            }
        }
    }
}
