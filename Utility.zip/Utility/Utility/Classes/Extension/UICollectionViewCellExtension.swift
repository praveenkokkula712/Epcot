//
//  UICollectionViewCellExtension.swift
//  CasinoLobby
//
//  Created by Praveen Kokkula on 13/01/22.
//

import Foundation
import UIKit

public extension UICollectionViewCell {
    func dropShadowEffect(cornerRadius: CGFloat = 8.0) {
        contentView.layer.cornerRadius = cornerRadius
        contentView.layer.borderWidth = 1
        contentView.layer.borderColor = UIColor.clear.cgColor
        contentView.layer.masksToBounds = true
    
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 2)
        layer.shadowRadius = 3
        layer.shadowOpacity = 0.5
        layer.masksToBounds = false
        layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: 0).cgPath
        layer.cornerRadius = cornerRadius
    }
}
