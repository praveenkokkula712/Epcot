//
//  UnitDurationExtension.swift
//  Utility
//
//  Created by Sathish Pullagura on 23/09/21.
//

import Foundation
public extension UnitDuration {
    static let msec: UnitDuration = { UnitDuration(symbol: "msec",
                                                   converter: UnitConverterLinear(coefficient: 0.001))
    }()
}
