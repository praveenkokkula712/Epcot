//
//  UIView+RippleEffect.swift
//  Utility
//
//  Created by Rajani Bhimanadham on 11/05/23.
//

import Foundation
import UIKit

let shapeForRipple = "ShapeForRipple"
let replicatorForRipple = "ReplicatorForRipple"
extension UIView {
    public func addRippleAnimation(color: UIColor, cornerRadius: CGFloat = 0, scaleValue: CGFloat = 10, padding: CGFloat = 0.0, isCircularView:Bool = false) {
        guard !isRippleAnimating else { return }
        let rippleAnimationAvatarSize = self.frame.size
        let rippleAnimationDuration: Double = 1.5
        var rippleAnimationExpandSizeValue = rippleAnimationAvatarSize.width / scaleValue
        
        ///setting the animation intial  bezier path
        var cornerRadiusVal = cornerRadius
        if cornerRadius != 0 {
            cornerRadiusVal = cornerRadius + (padding/2)
        }
        let initPath = UIBezierPath(roundedRect: CGRect(x: 0 - (padding/2),
                                                        y: 0,
                                                        width: rippleAnimationAvatarSize.width + padding,
                                                        height: rippleAnimationAvatarSize.height + padding),
                                                        cornerRadius: cornerRadiusVal)
        
        ///setting the animation final  bezier path after scaling effect
        var height = (rippleAnimationAvatarSize.height + rippleAnimationExpandSizeValue * 2)
        let width = rippleAnimationAvatarSize.width + rippleAnimationExpandSizeValue * 2
        if isCircularView {
            height = width
            cornerRadiusVal = width/2
        }
        let finalPath = UIBezierPath(roundedRect: CGRect(x: -rippleAnimationExpandSizeValue ,
                                                         y: -rippleAnimationExpandSizeValue,
                                                         width: width,
                                                         height: height),
                                                         cornerRadius: cornerRadiusVal)
        clipsToBounds = false
        
        let replicator = CAReplicatorLayer()
        replicator.instanceCount = 1
        replicator.instanceDelay = rippleAnimationDuration
        replicator.backgroundColor = UIColor.clear.cgColor
        replicator.name = replicatorForRipple
        self.layer.addSublayer(replicator)

        let shape = animationLayer(path: initPath,
                                   color: color,
                                   lineWidth: 3)
        shape.name = shapeForRipple
        shape.frame = CGRect(x: 0,
                             y: 0,
                             width: rippleAnimationAvatarSize.width + 10,
                             height: rippleAnimationAvatarSize.height + 10)
        replicator.addSublayer(shape)

        let pathAnimation = CABasicAnimation(keyPath: "path")
        pathAnimation.isRemovedOnCompletion = true
        pathAnimation.fromValue = initPath.cgPath
        pathAnimation.toValue = finalPath.cgPath

        let opacityAnimation = CABasicAnimation(keyPath: "opacity")
        opacityAnimation.fromValue = NSNumber(value: 1)
        opacityAnimation.toValue = NSNumber(value: 0)

        let groupAnimation = CAAnimationGroup()
        groupAnimation.animations = [pathAnimation,opacityAnimation]
        groupAnimation.duration = rippleAnimationDuration
        groupAnimation.repeatCount = Float.infinity
        groupAnimation.isRemovedOnCompletion = true
        groupAnimation.fillMode = .forwards
        shape.add(groupAnimation, forKey: "RippleGroupAnimation")
    }
    
    public func removeRippleAnimation() {
        var layers: [CALayer] = []
        layer.sublayers?.forEach({ (layer) in
            if let replicator = layer as? CAReplicatorLayer, replicator.name == replicatorForRipple {
                replicator.sublayers?.forEach({ (ly) in
                    if ly.name == shapeForRipple {
                        ly.isHidden = true
                        layers.append(ly)
                    }
                })
                replicator.isHidden = true
                layers.append(replicator)
            }
        })
        guard !layers.isEmpty else { return }
        for i in 0..<layers.count {
            layers[i].removeFromSuperlayer()
        }
        layers.removeAll()
    }

    private func animationLayer(path: UIBezierPath, color: UIColor, lineWidth: CGFloat) -> CAShapeLayer {
        let shape = CAShapeLayer()
        shape.path = path.cgPath
        shape.strokeColor = color.cgColor
        shape.fillColor = UIColor.clear.cgColor
        shape.lineWidth = lineWidth
        shape.strokeColor = color.cgColor
        shape.lineCap = .round
        return shape
    }
    
    private var isRippleAnimating: Bool {
        var animating = false
        layer.sublayers?.forEach({ (layer) in
        if let replicator = layer as? CAReplicatorLayer, replicator.name == replicatorForRipple {
                animating = true
            }
        })
        return animating
    }
}

