//
//  UIImageViewExtension.swift
//  Utility
//
//  Created by Praveen Kokkula on 23/02/22.
//

import Foundation
import Kingfisher
import SDWebImage
import SVGKit

fileprivate let kshimmerLayer = "shimmerLayer"
public let kPlaceHolder = "placeHolder"

public extension UIImageView {
    
    func loadImage(shimmer: ShimmerGradients = ShimmerGradients(),
                   withUrl urlString: String,
                   resizeValue: (width: CGFloat, offset: CGFloat)? = nil,
                   completionHandler: ((_ result: Result<Any?,Error>?) -> Void)? = nil) {
        if urlString.isGIF {
            self.loadSDImage(withUrl: urlString) { error in
                if let error {
                    let url = urlString.replacingOccurrences(of: ".gif", with: ".jpg")
                    self.loadImage(withUrl: url)
                }
            }
        }
        
        if urlString.isSVG, let url = URL(string: urlString), let svgImage = SVGKImage(contentsOf: url).uiImage {
            DispatchQueue.main.async {[weak self] in
                self?.image = svgImage
            }
        }
        
        guard let imageURL = URL(string: urlString) else { return }
        let placeHolderImage = UIImage.getImage(named: kPlaceHolder)
        let shimmerColor = CasinoCSS.lobby?.epcotLobbyCSS?.shimmerGradients ?? shimmer
        self.applyShimmerLayer(with: shimmerColor)
        let resizedPlaceHolderImage = placeHolderImage?.resizeImage(targetSize: self.bounds.size)        
        self.kf.setImage(with: imageURL,
                         placeholder: resizedPlaceHolderImage,
                         options: [.transition(.fade(0.2))]) { [weak self] (result) in
            self?.removeShimmerLayers()
            switch result {
            case .success(let value):
                if let resizeImage = resizeValue {
                    self?.image = value.image.resizeImage(width: resizeImage.width, offset: resizeImage.offset)
                } else {
                    self?.image = value.image
                }
                
            case .failure(let error) :
                ETLogger.debug(error.localizedDescription)
                completionHandler?(.failure(error))
            }
        }
    }
    
    private func applyShimmerLayer(with gradients : ShimmerGradients) {
        self.removeShimmerLayers()
        let shimmer = CAGradientLayer.applyShimmerGradient(with: gradients, on: self)
        shimmer.name = kshimmerLayer
    }
    
    private func removeShimmerLayers() {
        self.layer.sublayers?.forEach({
            if $0.name == kshimmerLayer {
                $0.removeFromSuperlayer()
            }
        })
    }
    
    func loadSDImage(shimmer:ShimmerGradients = ShimmerGradients(),
                   withUrl urlString: String, completionHandler:  ((_ error:Error?) -> Void)? = nil) {
        guard let imageURL = URL(string: urlString) else { return }
        let placeHolderImage = UIImage.getImage(named: kPlaceHolder)
        let shimmerColor = CasinoCSS.lobby?.epcotLobbyCSS?.shimmerGradients ?? shimmer
        self.applyShimmerLayer(with: shimmerColor)
        let resizedPlaceHolderImage = placeHolderImage?.resizeImage(targetSize: self.bounds.size)
        self.sd_setImage(with: imageURL, placeholderImage: resizedPlaceHolderImage) { [weak self] image, error , _, _ in
            self?.removeShimmerLayers()
            if let error {
                ETLogger.debug(error.localizedDescription)
                completionHandler?(error)
                return
            }
            if let image = image {
                self?.image = image
                completionHandler?(nil)
            }
        }
    }
    
    func loadImageWith(name: String,
                      defaultImageName: String,
                      resizeValue: (width: CGFloat, offset:CGFloat)? = nil,
                      bundle: AnyClass) {
        
        var aImage: UIImage?
        if let image  = UIImage(named: name,in: Bundle(for: bundle.self), compatibleWith: nil) {
            aImage = image
            
        } else {
            aImage = UIImage(named: defaultImageName,in: Bundle(for: bundle.self), compatibleWith: nil)
        }
        if let resizeImage = resizeValue {
            aImage = aImage?.resizeImage(width: resizeImage.width, offset: resizeImage.offset)
        }
        self.image = aImage
    }
}
