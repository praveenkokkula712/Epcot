//
//  PlaceHolderImage.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 06/04/23.
//

import SwiftUI

public struct PlaceHolderImage: View {

    public init() {}

    public var body: some View {
        if let image = UIImage.getImage(named: "placeHolder") {
            Image(uiImage: image)
                .resizable()
                .aspectRatio(contentMode: .fill)
        } else {
            EmptyView()
        }
    }
}

struct PlaceHolderImage_Previews: PreviewProvider {
    static var previews: some View {
        PlaceHolderImage()
    }
}
