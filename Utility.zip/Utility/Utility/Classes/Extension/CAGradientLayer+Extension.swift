//
//  CAGradientLayer+Extension.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 20/04/22.
//

import Foundation

public struct ShimmerGradients {
    
    let colors:[CGColor]
    
    public init(colors: [CGColor] = [UIColor(white: 0.85, alpha: 1.0).cgColor,
         UIColor(white: 0.95, alpha: 1.0).cgColor,
         UIColor(white: 0.85, alpha: 1.0).cgColor]) {
        self.colors = colors
    }
}

extension CAGradientLayer {
    
    @discardableResult
    public static func applyShimmerGradient(with shimmer: ShimmerGradients = ShimmerGradients(),
                                            on aView: UIView) -> CAGradientLayer {
        let gradient = CAGradientLayer()
        gradient.colors = shimmer.colors
        gradient.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradient.endPoint = CGPoint(x: 1.0, y: 0.525)
        gradient.locations = [0.4, 0.5, 0.6]
        
        gradient.frame = CGRect(x: -aView.bounds.width,
                                y: 0,
                                width: aView.bounds.width * 3,
                                height: aView.bounds.height * 3)
        
        let animation = CABasicAnimation(keyPath: "locations")
        animation.fromValue = [-1.0, -0.5, 0.0]
        animation.toValue = [1.0, 1.5, 2.0]
        
        animation.repeatCount = .infinity
        animation.duration = 0.9
        animation.isRemovedOnCompletion = false
        
        gradient.add(animation, forKey: "shimmer")
        aView.layer.addSublayer(gradient)
        return gradient
    }
    
}
