//
//  View+InstantInteraction.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 27/06/23.
//

import SwiftUI

extension View {
    public var instantInteractionAnimation: Animation {
        .easeInOut(duration: 0.2).delay(0.1)
    }
}
