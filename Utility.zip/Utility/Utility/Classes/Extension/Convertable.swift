//
//  Convertable.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 27/09/24.
//

import Foundation

public protocol Convertable: Codable { }

public extension Convertable {
    
    func convertToDict() -> Dictionary<String, Any>? {
        var dict: [String: Any]? = nil

        do {
            let data = try JSONEncoder().encode(self)
            if !data.isEmpty {
                dict = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String: Any]
            }
        } catch {
            ETLogger.log(error.localizedDescription)
        }

        return dict
    }
}
