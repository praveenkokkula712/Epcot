//
//  UIViewExtension.swift
//  MiniGames
//
//  Created by Sumeet Bajaj on 16/03/2018.
//  Copyright © 2018 Ivy Comptech. All rights reserved.
//

import UIKit

// Class Methods
public extension UIView {
    
    class func loadFromNib(_ nibName:String? = nil, _ bundle:Bundle) -> Self? {
        
        func instantiateFromNib<T: UIView>(_ nibName:String?,_ bundle:Bundle) -> T? {
            
            let _nibName = nibName ?? String(describing: T.self)
            
            return bundle.loadNibNamed(_nibName, owner: nil, options: nil)?.first as? T
        }
        
        return instantiateFromNib(nibName, bundle)
    }
}

// Instance Methods
public extension UIView {

    func removeAllSubViews() {
        self.subviews.forEach({
            $0.removeFromSuperview()
        })
    }
}

// Constraints
public extension UIView {
    
    func configure(on parent: UIView, insets: UIEdgeInsets = .zero, safe:Bool = false) {
        
        self.translatesAutoresizingMaskIntoConstraints = false
        
        // adding self on parent
        parent.addSubview(self)
        
        NSLayoutConstraint.activate(self.constraints(on: parent, insets: insets, safe: safe))
    }
    
    private func constraints(on parent:UIView, insets: UIEdgeInsets, safe:Bool = false) -> [NSLayoutConstraint] {
        
        guard safe == true else {
            
            return [self.leadingAnchor.constraint(equalTo: parent.leadingAnchor, constant: insets.left),
                    self.trailingAnchor.constraint(equalTo: parent.trailingAnchor, constant: insets.right),
                    self.topAnchor.constraint(equalTo: parent.topAnchor, constant: insets.top),
                    self.bottomAnchor.constraint(equalTo: parent.bottomAnchor, constant: insets.bottom)]
        }
        
        return [self.safeAreaLayoutGuide.leadingAnchor.constraint(equalTo: parent.safeAreaLayoutGuide.leadingAnchor, constant: insets.left),
                self.safeAreaLayoutGuide.bottomAnchor.constraint(equalTo: parent.safeAreaLayoutGuide.bottomAnchor, constant: insets.bottom),
                self.safeAreaLayoutGuide.topAnchor.constraint(equalTo: parent.safeAreaLayoutGuide.topAnchor, constant: insets.top),
                self.safeAreaLayoutGuide.trailingAnchor.constraint(equalTo: parent.safeAreaLayoutGuide.trailingAnchor, constant: insets.right)]
    }
}


// Loader Extension
public extension UIView {
    
    /// This method will add the loader view as subview
    /// - Parameter safeAreaEnabled: Bool
    func showLoader(safeAreaEnabled:Bool = true) {
        Loader.show(on: self, safeAreaEnabled: safeAreaEnabled)
    }
    
    /// This method will update the message on loader displayed on self
    /// - Parameter message: String
    func updateLoader(message:String) {
        Loader.update(message: message, of: self)
    }
    
    /// This method will update the value for progress view on loader
    /// - Parameters:
    ///   - value: CGFloat - 0 to 1
    ///   - message: String
    func updateLoader(value:Float, message:String = "Downloading...".localized()) {
        Loader.update(value: value, of: self, message: message)
    }
    
    func updateDownloadLoader(gameName: String,gameImagePath: String, progress value:Float = 0) {
        Loader.updateDownloadView(value: value, gameName: gameName, gameImagePath: gameImagePath, of: self)
    }
    
    func updateDownloadLoaderValue(progress value:Float = 0) {
        Loader.updateDownloadView(of: self, progress: value)
    }
    
    
    /// This method will subscribe the cancel button action and display action button
    /// - Parameter onClick: Clouser
    func subscribeLoaderCancelEvent(_ onClick: (() ->Void)?) {
        Loader.addCancelHandler(of: self, onClick: onClick)
    }
    
    /// This method will remover the loader from self
    func removeLoader() {
        Loader.remove(from: self)
    }
}

public extension UIView {
    
    func addBorder(width: CGFloat = 0, color: UIColor = UIColor.clear, with cornerRadius: CGFloat = 0) {
        self.layer.borderWidth = width
        self.layer.borderColor = color.cgColor
        if cornerRadius > 0 {
            self.getRoundedCorners(OfRadius: cornerRadius)
        }
    }
    
    func getRoundedCorners(OfRadius value: CGFloat = 0) {
        self.layer.cornerRadius = value
        self.layer.masksToBounds = true
        self.clipsToBounds = true
    }
    
    func addBorderColor(color: UIColor? = nil, errorColor: UIColor? = nil) {
        self.layer.masksToBounds = true
        self.layer.borderColor = errorColor?.cgColor ?? color?.cgColor
        self.layer.borderWidth = 1
    }
}

public extension UIView {
    func addFadeTransition(_ duration:CFTimeInterval) {
        let animation = CATransition()
        animation.timingFunction = CAMediaTimingFunction(name:
            CAMediaTimingFunctionName.easeInEaseOut)
        animation.type = CATransitionType.push
        animation.duration = duration
        layer.add(animation, forKey: CATransitionType.push.rawValue)
    }
}

public extension UIView {
    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }
}
public extension UIView {
    func dropShadow(color: UIColor, offSet: CGSize, shadowRadius: CGFloat = 3, opacity: Float = 0.4) {
        let shadowPath = UIBezierPath(rect: self.bounds)
        self.layer.masksToBounds = false
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = offSet
        self.layer.shadowOpacity = opacity
        self.layer.shadowPath = shadowPath.cgPath
        self.layer.shadowRadius = shadowRadius
    }
    
    func updateShadow(cornerRadius: CGFloat = 3.0) {
        self.layer.shadowPath = UIBezierPath(roundedRect: self.bounds, cornerRadius: cornerRadius).cgPath
    }
}

public protocol GradientLayerProtocol {
    static var layerClass: Swift.AnyClass { get }
    func addGradientLayer(colors:[UIColor])
}

public extension GradientLayerProtocol {
    func addGradientLayer(colors:[UIColor]) {
        guard let gradientLayer = (self as? UIView)?.layer as? CAGradientLayer else {
            return
        }
        var cgColors = [CGColor]()
        for color in colors {
            cgColors.append(color.cgColor)
        }
        gradientLayer.colors = cgColors
    }
}

public extension UIView {
    func constraintPinAllEdges(holderView: UIView, edgeInsets: UIEdgeInsets = .zero) {
        self.translatesAutoresizingMaskIntoConstraints = false
        self.leadingAnchor.constraint(equalTo: holderView.leadingAnchor, constant: edgeInsets.left).isActive = true
        self.trailingAnchor.constraint(equalTo: holderView.trailingAnchor, constant: edgeInsets.right).isActive = true
        self.topAnchor.constraint(equalTo: holderView.topAnchor, constant: edgeInsets.top).isActive = true
        self.bottomAnchor.constraint(equalTo: holderView.bottomAnchor, constant: edgeInsets.bottom).isActive = true
    }
}

public extension UIView {
    
    func tapAnimation(type: InstantInteraction = .reduceSize(0.95),completion: @escaping (() -> Void)) {
        var overlay: UIView?
        var overlayButtonClip: Bool?
        UIView.animate(withDuration: 0.2, delay: 0.1, animations: {
            switch type {
            case .decreaseOpacity(let opacity):
                self.alpha = opacity
            case .reduceSize(let size):
                self.transform = CGAffineTransform(scaleX: size, y: size)
                self.backgroundColor = self.backgroundColor?.addColorEffect(by: -20)
            case .overlay12(let color):
                overlay = self.addingOverLay(color: color, opacity: 0.12)
                overlayButtonClip = self.clipsToBounds
                self.clipsToBounds = true
            case .overlay40(let color):
                overlay = self.addingOverLay(color: color, opacity: 0.40)
                overlayButtonClip = self.clipsToBounds
                self.clipsToBounds = true
            case .none:
                self.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
                self.backgroundColor = self.backgroundColor?.addColorEffect(by: -20)
            }
        }, completion: { _ in
            switch type {
            case .decreaseOpacity(_):
                self.alpha = 1
            case .reduceSize(_):
                self.transform = CGAffineTransform(scaleX: 1, y: 1)
                self.backgroundColor = self.backgroundColor?.addColorEffect(by: 20)
            case .overlay12(_), .overlay40(_):
                self.clipsToBounds = overlayButtonClip ?? false
                overlay?.removeFromSuperview()
            case .none:
                self.transform = CGAffineTransform(scaleX: 1, y: 1)
                self.backgroundColor = self.backgroundColor?.addColorEffect(by: 20)
            }
            completion()
        })
    }
    
    func addingOverLay(color: UIColor, opacity: CGFloat) -> UIView {
        let overlay = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height))
        overlay.backgroundColor = color.withAlphaComponent(opacity)
        self.addSubview(overlay)
        self.bringSubviewToFront(overlay)
        return overlay
    }
}
public extension UIView {
    
    func configureCircularProgressAnimation(strokeColor: UIColor) -> CAShapeLayer {
        let circularPath = UIBezierPath(arcCenter: CGPoint(x: self.frame.size.width / 2.0, y: self.frame.size.height / 2.0), radius: self.frame.size.height / 2.0, startAngle: -.pi / 2, endAngle: 1.5 * .pi, clockwise: true)
        var circleLayer = CAShapeLayer()
        circleLayer.path = circularPath.cgPath
        circleLayer.fillColor = UIColor.clear.cgColor
        circleLayer.lineCap = .round
        circleLayer.lineWidth = 0
        circleLayer.strokeColor = UIColor.clear.cgColor
        var progressLayer = CAShapeLayer()
        progressLayer.path = circularPath.cgPath
        progressLayer.fillColor = UIColor.clear.cgColor
        progressLayer.lineCap = .round
        progressLayer.lineWidth = 2.0
        progressLayer.strokeEnd = 0
        progressLayer.strokeColor = strokeColor.cgColor
        self.layer.addSublayer(circleLayer)
        self.layer.addSublayer(progressLayer)
        return progressLayer
    }
}

public extension UIView {
    var globalFrame: CGRect? {
        let rootView = UIApplication.mainWindow.rootViewController?.view
        return self.superview?.convert(self.frame, to: rootView)
    }
}

public extension UIView {
    func removeViewWithAnimation() {
        UIView.transition(with: self, duration: 0.5, options: .transitionCrossDissolve, animations: {
            self.alpha = 0
        }) { _ in
            self.removeFromSuperview()
        }
    }
}
