//
//  StringExtension+HtmlToAttributedString.swift
//  Utility
//
//  Created by Santhosh Kodadi on 10/08/23.
//

import Foundation

public extension String {
    
    func convertHtmlInBackground(attrs: [NSAttributedString.Key:Any]? = nil, encoding: Encoding = .unicode, isFixedLineRequired: Bool = false) async throws -> NSAttributedString? {
        let result = try? await withCheckedThrowingContinuation {(continuation: CheckedContinuation<Any,Error>)  in
            self.convertHTMLInBackground(attrs: attrs, encoding: encoding, isFixedLineRequired: isFixedLineRequired) { resultString in
                continuation.resume(returning: resultString)
            }
        }
        return result as? NSAttributedString
    }
    
    func convertHTMLInBackground(attrs: [NSAttributedString.Key:Any]? = nil, encoding: Encoding = .unicode, isFixedLineRequired: Bool = false, completion: @escaping (NSAttributedString?) -> Void) {
        DispatchQueue.global(qos: .background).async {
            let result = self.convertToHTML(attrs: attrs, encoding: encoding, isFixedLineRequired: isFixedLineRequired)
            completion(result)
        }
    }
    
    func convertToHTML(attrs: [NSAttributedString.Key:Any]? = nil, encoding: Encoding = .unicode, isFixedLineRequired: Bool = false) -> NSAttributedString? {
        guard let htmlData = self.data(using: encoding) else {
            return nil
        }
        let attStr = try? NSMutableAttributedString(data: htmlData,
                                                    options: [.documentType: NSAttributedString.DocumentType.html],
                                                    documentAttributes: nil)
        if let _attrs = attrs {
            attStr?.addAttributes(_attrs, range: NSRange(location: 0, length: attStr?.length ?? 0))
        }
        
        if isFixedLineRequired {
           return attStr?.fixLineHeight
        }
        return attStr
    }
}
