//
//  View+TextHeightKey.swift
//  Utility
//
//  Created by Rajani Bhimanadham on 27/12/23.
//

import Foundation
import SwiftUI

public struct TextHeightKey: PreferenceKey {
    public static var defaultValue: CGFloat { 0 }
    
    public static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = max(value, nextValue())
    }
}

