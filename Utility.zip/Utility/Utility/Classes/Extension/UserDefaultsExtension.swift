//
//  UserDefaultsExtension.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 04/04/23.
//

extension UserDefaults {
    private enum DefaultKeys {
        static let lobbySwitcherType = "lobbySwitcherType"
        static let loggedInCount = "logged_in_count"
        static let userJourneyWelcomeAction = "user_journey_welcome_action"
        static let isJourneyClosed = "is_journey_closed"
    }
    ///variable stores number of times user has logged in
    @UserDefault(key: DefaultKeys.loggedInCount, defaultValue: 0)
    public static var userLoggedInCount: Int
    
    ///variable stores number of times user has logged in
    @UserDefault(key: DefaultKeys.isJourneyClosed, defaultValue: false)
    public static var isJourneyClosed: Bool
        
    ///variable stores user Onboarding journey action (start/skip)
    @UserDefault(key: DefaultKeys.userJourneyWelcomeAction, defaultValue: 0)
    public static var userJourneyWelcomeAction: Int
    
    ///variable stores switcher type (list/grid) based on user interaction
    @UserDefault(key: DefaultKeys.lobbySwitcherType, defaultValue: nil)
    public static var lobbySwitcherType: String?
}

extension UserDefaults {
    //Play break
    @UserDefault(key: "is_playBreak_Closed", defaultValue: false)
    public static var isPlaybreakClosed: Bool

    //Grace Period
    @UserDefault(key: "is_gracePeriod_Closed", defaultValue: false)
    public static var isGracePeriodClosed: Bool
}

extension UserDefaults {
    @UserDefault(key: "Game_Premiere_Overlay", defaultValue: "")
    public static var gamePremiereId: String
}
