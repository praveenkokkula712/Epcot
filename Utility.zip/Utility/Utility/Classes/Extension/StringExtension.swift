//
//  StringExtension.swift
//  CasinoCore
//
//  Created by Sumeet Bajaj on 27/06/2019.
//  Copyright © 2019 Ivy Comptech. All rights reserved.
//

import Foundation
import UIKit

public extension String {
    
    func jsonObject() -> Result<Any,Error> {
        
        guard let data = self.data(using: .utf8) else {
            
            return .failure("Failed to covert string in data.\(self)".localizedDescription)
        }
        
        return data.jsonObject()
    }
}

extension String: LocalizedError {
    public var errorDescription: String? { return self }
}

public extension String {
    
    func localized(comment:String = "") -> String {
        
        if let localizedString = LocalisedManager.shared.getString(key: self) as? String {
            
            return localizedString
        }
        
        if let s = CasinoCSS.localisationDataSource?.didRequestLocalised(key: self, comment: comment) {
            
            return s
        }
        
        return NSLocalizedString(self, comment: comment)
    }
    
    var localized: String {
        return self.localized()
    }
}


public extension String {
    
    func slice(from: String, to: String) -> String? {
        guard let rangeFrom = range(of: from)?.upperBound else { return nil }
        guard let rangeTo = self[rangeFrom...].range(of: to)?.lowerBound else { return nil }
        return String(self[rangeFrom..<rangeTo])
    }
    
    var isValidHtmlString: Bool {
        if self.isEmpty {
            return false
        }
        return (self.range(of: "<(\"[^\"]*\"|'[^']*'|[^'\">])*>", options: .regularExpression) != nil)
    }
}

public extension String {
    func ranges(of string: String, options: CompareOptions = .literal) -> [Range<Index>] {
        var result: [Range<Index>] = []
        var start = startIndex
        while let range = range(of: string, options: options, range: start..<endIndex) {
            result.append(range)
            start = range.lowerBound < range.upperBound ? range.upperBound : index(range.lowerBound, offsetBy: 1, limitedBy: endIndex) ?? endIndex
        }
        return result
    }
    
    func slices(from: String, to: String) -> [Substring] {
        let pattern = "(?<=" + from + ").*?(?=" + to + ")"
        return ranges(of: pattern, options: .regularExpression)
            .map{ self[$0] }
    }
}

public extension String {
    
    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: [NSAttributedString.Key.font: font], context: nil)
    
        return ceil(boundingBox.height)
    }

    func width(withConstrainedHeight height: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)

        return ceil(boundingBox.width)
    }
    
    func getWidth(width: CGFloat, font: UIFont) -> CGFloat {
        let rect = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
        let labelSize = self.boundingRect(with: rect, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)
        return labelSize.width
    }
}

public extension String {

    func createUnderlineInButton() -> NSAttributedString? {
        let attributeString = NSMutableAttributedString(string: self)
        attributeString.underLine(onRange: NSMakeRange(0, self.count))
        return attributeString
    }
}

public extension String {
    var BoolValue: Bool {
        self.lowercased() == "true"
    }
    
    var bool: Bool? {
        switch self.lowercased() {
        case "true", "t", "yes", "y", "1":
            return true
        case "false", "f", "no", "n", "0":
            return false
        default:
            return nil
        }
    }
}

public extension String {
    func matches(withRegexPattern pattern: String?) -> Bool {
        let regex = try? NSRegularExpression(pattern: pattern ?? "", options: .caseInsensitive)
        if regex?.firstMatch(in: self, options: [], range: NSRange(location: 0, length: self.count)) != nil {
            return true
        }
        return false
    }
}

public extension String {
    var hexColor: UIColor? {
        guard !self.isEmpty else { return nil }
        return  UIColor.hexStringToUIColor(hex: self)
    }
}

public extension String {
    var removeHtmlCharacters: String? {
        self.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
    }
}

// to get button description for player break
public extension String {
    var actionCategory: String {
        if let actionCategory = HTMLParser(value: self).getTitleOfhref().first,
           !actionCategory.isEmpty {
            return  actionCategory.description
        }
        return ""
    }
    
    var siteCoreContentValue: String {
        return self.actionCategory
            .replacingOccurrences(of: "&lt;b&gt;", with: "")
            .replacingOccurrences(of: "&lt;/b&gt;", with: "")
    }
}

public extension String {
    var nativeFont: UIFont {
        return CasinoCSS.localisationDataSource?.didRequestFont(key: self) ?? UIFont.systemFont(ofSize: 20)
    }
}

public extension String {
    var toInt: Int {
        Int(self) ?? 0
    }
    
    //Casino Stories Item Date
    var storyItemDate: Date {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = "yyyyMMdd'T'HHmmss"
        return dateFormatter.date(from: self) ?? Date()
    }
}

public extension String {
    var jackpotCounterAmount: String? {
        let components = self.components(separatedBy: " ")
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.locale = Locale(identifier: EntainContext.app?.lang ?? "en")
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        if let currency = components.first,
           let amountString = components.last,
           var amount = formatter.number(from: amountString)?.doubleValue {
            let randomNumber = Double.random(in: 0.01...0.10)
            amount += randomNumber
            if let formattedAmountNumber = amount as? NSNumber, let formattedAmount = formatter.string(from: formattedAmountNumber) {
                let jpAmount = "\(currency) \(formattedAmount)"
                return jpAmount
            }
        }
        return nil
    }
    
    var doubleValue: Double? {
        Double(self)
    }
}
public extension String {
    var url: URL? {
        URL(string: self)
    }
    
    init(withInt int: Int, leadingZeros: Int = 2) {
        self.init(format: "%0\(leadingZeros)d", int)
    }
    
    func leadingZeros(_ zeros: Int = 2) -> String {
        if let int = Int(self) {
            return String(withInt: int, leadingZeros: zeros)
        }
        ETLogger.debug("Warning: \(self) is not an Int")
        return ""
    }
    
    var trimmed: String {
        self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

public extension Int {
    var leadingZero: String {
        "\(self)".leadingZeros()
    }
    
    var trimmed: String {
        "\(self)".trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

public extension String {
    
    func limitString(_ maxLength: Int) -> String {
        if self.count > maxLength {
            let subStr = self.prefix(maxLength) + "..."
            return String(subStr)
        }
        return self
    }
    
    func dateFormat(currentFormat: String? = "dd MMM yyyy HH:mm:ss zzz", currentTimeZone: TimeZone? = nil , requiredFormat: String? = "MM/dd/yy", requiredTimeZone: TimeZone? = nil) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        if let currentTimeZone {
            dateFormatter.timeZone = currentTimeZone
        }
        dateFormatter.dateFormat = currentFormat
        
        if let date = dateFormatter.date(from: self) {
            dateFormatter.dateFormat = requiredFormat
            if let requiredTimeZone {
                dateFormatter.timeZone = requiredTimeZone
            }
            return dateFormatter.string(from: date)
        } else {
            return nil
        }
    }
    
    func getDate(formate: String? = "dd MMM yyyy HH:mm:ss zzz") -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = formate
        return dateFormatter.date(from: self)
    }
}

public extension String {
    
    func capitalizingFirstLetter() -> String {
        return prefix(1).uppercased() + self.lowercased().dropFirst()
    }
    
    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
    
    var isGIF: Bool {
        self.contains(".gif")
    }
    
    var isSVG: Bool {
        self.contains(".svg")
    }
    
    var firstCapitalized: String {
        prefix(1).capitalized + dropFirst()
    }
    
    func  getPromoExpiryDate(expiryDateFormat: String?) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = expiryDateFormat ?? "yyyy-MM-dd'T'HH:mm:ssXXXXX"
        return dateFormatter.date(from: self) ?? Date()
    }

}

public extension Optional where Wrapped == String {
    var isNilOrEmpty: Bool {
        self?.isEmpty ?? true
    }
}
