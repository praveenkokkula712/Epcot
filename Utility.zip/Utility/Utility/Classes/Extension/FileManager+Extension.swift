//
//  FileManager+Extension.swift
//  Utility
//
//  Created by Praveen Kokkula on 20/05/22.
//

import Foundation

public extension FileManager {
    class func removeIfExistsAsync(atURL url:URL, delay:TimeInterval = 0) {
        DispatchQueue.global(qos: .default).asyncAfter(deadline: .now() + delay) {
            self.removeIfExists(atURL: url)
        }
    }
    
    class func removeIfExists(atURL url:URL) {
        if FileManager.default.fileExists(atPath: url.path) {
            do {
                try FileManager.default.removeItem(atPath: url.path)
            }
            catch {
                ETLogger.debug(error.localizedDescription)
            }
        }
    }
}
