//
//  LoggerNotifier.swift
//  Utility
//
//  Created by Praveen Kokkula on 07/04/22.
//

import Foundation

public struct LobbyFooter: Notifier {
    public enum Notification: String {
        case DidUpdateFooterView
    }
}
