//
//  DictionaryExtension.swift
//  AppLogger
//
//  Created by Sumeet Bajaj on 31/08/2018.
//  Copyright © 2018 Ivy Comptech. All rights reserved.
//

import Foundation

public extension Dictionary {
    
    func data() -> Data? {
        
        if JSONSerialization.isValidJSONObject(self) {
            do {
                return try JSONSerialization.data(withJSONObject: self, options: .init(rawValue: 0))
            }
            catch {
                ETLogger.debug("Failed to convert in data: \(error.localizedDescription)")
            }
        }
        
        return nil
    }
    
    func jsonString() -> String? {
        
        guard let data = self.data() else {
            return nil
        }
        
        return String(data: data, encoding: .utf8)
    }
}

public extension Dictionary where Value: Equatable {
    func key(forValue val: Value) -> Key? {
        return first(where: { $0.value == val })?.key
    }
}
