//
//  NSMutableAttributedStringExtension.swift
//  CasinoAPI
//
//  Created by Praveen Kokkula on 14/07/22.
//

import Foundation
import UIKit

public extension NSMutableAttributedString {
    
    func apply(color: UIColor, subString: String) {
        if let range = self.string.range(of: subString) {
            self.apply(color: color, onRange: NSRange(range, in: self.string))
        }
    }
    
    /// Apply color on given range
    func apply(color: UIColor, onRange: NSRange) {
        self.addAttributes([NSAttributedString.Key.foregroundColor: color],
                           range: onRange)
    }
    
    func apply(attribute: [NSAttributedString.Key: Any], onRange range: NSRange) {
        if range.location != NSNotFound {
            self.setAttributes(attribute, range: range)
        }
    }
    
    /// Underline string on given range
    func underLine(onRange: NSRange) {
        self.addAttributes([NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue],
                           range: onRange)
    }
    
    func apply(font: UIFont, subString: String)  {
        
        if let range = self.string.range(of: subString) {
            self.apply(font: font, onRange: NSRange(range, in: self.string))
        }
    }
    
    /// Apply font on given range
    func apply(font: UIFont, onRange: NSRange) {
        self.addAttributes([NSAttributedString.Key.font: font], range: onRange)
    }
    
    func paragraph(with alignment: NSTextAlignment) {
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = alignment
        self.addAttribute(.paragraphStyle, value: paragraphStyle, range: NSRange(location: 0, length: self.length))
    }
}

public extension NSAttributedString {
    func stringWithString(stringToReplace: String, replacedWithString newStringPart: String) -> NSMutableAttributedString? {
        if let mutableAttributedString = mutableCopy() as? NSMutableAttributedString {
            let mutableString = mutableAttributedString.mutableString
            while mutableString.contains(stringToReplace) {
                let rangeOfStringToBeReplaced = mutableString.range(of: stringToReplace)
                mutableAttributedString.replaceCharacters(in: rangeOfStringToBeReplaced, with: newStringPart)
                break
            }
            return mutableAttributedString
        }
        return self.mutableCopy() as? NSMutableAttributedString
    }
}
