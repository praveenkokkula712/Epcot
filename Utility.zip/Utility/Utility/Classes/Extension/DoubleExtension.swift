//
//  DoubleExtension.swift
//  Utility
//
//  Created by Gostu Bhargavi on 22/06/23.
//

import Foundation

public extension Double {
    public func round(to places: Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded()/divisor
    }
    
    var currency_KM_Formatter: String {
        if self >= 1000, self <= 999999 {
            return String(format: "%.1fK", self/1000).replacingOccurrences(of: ".0", with: "")
        }
        
        if self > 999999 {
            return String(format: "%.1fM", self/1000000).replacingOccurrences(of: ".0", with: "")
        }
        
        return String(format: "%.0f", self)
    }

    var roundToTwoDigits: String {
        String(format: "%.2f", self)
    }
}
