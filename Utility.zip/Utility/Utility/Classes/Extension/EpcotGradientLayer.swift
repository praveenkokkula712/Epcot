//
//  EpcotGradientLayer.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 19/08/22.
//

import Foundation

public class EpcotGradientLayer: UIView {
    
    lazy var gradientLayer:CAGradientLayer = CAGradientLayer()
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        gradientLayer.frame = self.bounds
        gradientLayer.colors = [CasinoCSS.lobby?.epcotLobbyCSS?.epcotMandortyUpdateButtonColors1?.cgColor,
                                CasinoCSS.lobby?.epcotLobbyCSS?.epcotMandortyUpdateButtonColors2?.cgColor]
        self.layer.insertSublayer(gradientLayer, at: 0)
        let tapGesture = UITapGestureRecognizer(target: self,
                                                action: #selector(tapGesture(gesture:)))
        
        self.addGestureRecognizer(tapGesture)
    }

    @objc private func tapGesture(gesture: UIGestureRecognizer) {
        if gesture.state == .ended {
            if let button = self.superview as? UIButton {
                button.sendActions(for: .touchUpInside)
            }
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func layoutSubviews() {
      super.layoutSubviews()
        self.gradientLayer.frame = self.bounds
    }
}
