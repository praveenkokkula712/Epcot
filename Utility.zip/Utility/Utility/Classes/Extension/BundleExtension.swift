//
//  BundleExtension.swift
//  CasinoCore
//
//  Created by Sumeet Bajaj on 11/07/2019.
//  Copyright © 2019 Ivy Comptech. All rights reserved.
//

import Foundation

public extension Bundle {
    
    static func loadJSON(for aClass: AnyClass, fileName name:String) -> Any? {
        
        if let path = Bundle(for: aClass).path(forResource: name, ofType: "json") {
            
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                
                return try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
            }
            catch {
                ETLogger.debug(error.localizedDescription)
            }
        }
        
        return nil
    }
    
    static func loadZip(with fileName: String) -> URL? {
        Bundle.main.url(forResource: fileName, withExtension: "zip")
    }
    
    var version: String? {
        return infoDictionary?["CFBundleShortVersionString"] as? String
    }
    
    var buildVersion: String? {
        return infoDictionary?["CFBundleVersion"] as? String
    }
    
    var appVersion: String? {
        guard let version = self.version, let buildVersion = self.buildVersion else {
            return nil
        }
        
        return version + "." + buildVersion
    }
}
