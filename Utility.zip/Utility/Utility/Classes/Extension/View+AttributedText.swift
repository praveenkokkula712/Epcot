//
//  View+AttributedText.swift
//  Utility
//
//  Created by Rajani Bhimanadham on 27/12/23.
//

import Foundation
import SwiftUI
import WebKit

public struct AttributedText: UIViewRepresentable {
    let htmlContent: String
    @Binding var size: CGSize
    private let webView = WKWebView()
    var sizeObserver: NSKeyValueObservation?
    @Binding var isLoaded: Bool
    let jackpotInfoViewContentValues: JackpotInfoViewContentModel
    
    public init(htmlContent: String, size: Binding<CGSize> = Binding.constant(CGSize.zero), isLoaded: Binding<Bool> = Binding.constant(false), jackpotInfoViewContentValues: JackpotInfoViewContentModel) {
        self.htmlContent = htmlContent
        self._size = size
        self._isLoaded = isLoaded
        self.jackpotInfoViewContentValues = jackpotInfoViewContentValues
    }
    
    public func makeUIView(context: UIViewRepresentableContext<Self>) -> WKWebView {
        webView.scrollView.isScrollEnabled = false
        webView.navigationDelegate = context.coordinator
        let styledHtmlContent = """
                <!doctype html>
                <meta charset="utf-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1 , maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
                <html>
                <style>
                @font-face {
                    font-family: '\(jackpotInfoViewContentValues.fontName)';
                    src: url("\(jackpotInfoViewContentValues.fontFileName)") format('truetype');
                }
                body {
                    font-size: \(jackpotInfoViewContentValues.fontSize)px;
                    font-family: "\(jackpotInfoViewContentValues.fontName)";
                }
                </style> \(htmlContent)
                <div style="height: 40px; display: block;"></div>
                </html>
                """
        let bundleURL = Bundle.main.bundleURL
        webView.loadHTMLString(styledHtmlContent, baseURL: bundleURL)
        return webView
    }
    
    public func updateUIView(_ uiView: WKWebView, context: UIViewRepresentableContext<Self>) {
    }
    
    public func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    public class Coordinator: NSObject, WKNavigationDelegate {
        let parent: AttributedText
        var sizeObserver: NSKeyValueObservation?
        
        init(parent: AttributedText) {
            self.parent = parent
            sizeObserver = parent.webView.scrollView.observe(\.contentSize, options: [.new], changeHandler: { (object, change) in
                parent.size = change.newValue ?? .zero
            })
        }
        public func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                self.parent.isLoaded = true
            }
        }
        public func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async {
                self.parent.isLoaded = true
            }
        }
    }
}
