//
//  View+Extension.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 05/06/24.
//

import Foundation
import SwiftUI

public extension View {
    
    public var shouldApplyPadding: Bool {
        return false
    }
    
    public var anchor: UnitPoint {
        .center
    }
    
    @ViewBuilder public func `if`<Content: View>(_ condition: Bool, transform: (Self) -> Content) -> some View {
        if condition {
            transform(self)
        } else {
            self
        }
    }
    
    @ViewBuilder public func iflet<Content: View, T>(
        _ conditional: Optional<T>,
        transform: (Self, T) -> Content
    ) -> some View {
        if let condition = conditional {
            transform(self, condition)
        } else {
            self
        }
    }
    
    @ViewBuilder public func iflet<Content: View, T, U>(
        _ conditional: Optional<T>,
        _ conditional2: Optional<U>,
        transform: (Self, T, U) -> Content
    ) -> some View {
        if let condition = conditional, let condition2 = conditional2 {
            transform(self, condition, condition2)
        } else {
            self
        }
    }
}

public extension View {
    func applyEpcotGradientBgColor(backgroundColor: Color,
                                   font: Font,
                                   textColor: Color,
                                   cornerRadius: CGFloat,
                                   isEpcotEnabled: Bool) -> some View {
        if isEpcotEnabled {
            let color1 = Color(CasinoCSS.lobby?.epcotLobbyCSS?.epcotMandortyUpdateButtonColors1 ?? .black)
            let color2 = Color(CasinoCSS.lobby?.epcotLobbyCSS?.epcotMandortyUpdateButtonColors2 ?? .black)
            
            return self.modifier(GradientButtonModifier(colors: [color1, color2],
                            font: Font(CasinoCSS.lobby?.epcotLobbyCSS?.epcotButtonTitleFont ?? UIFont.systemFont(ofSize: 14)),
                            textColor: Color(CasinoCSS.lobby?.epcotLobbyCSS?.epcotGradientButtonColor ?? .black),
                            clipShape: CustomShape(shape: Capsule())))
            
        }
        return self.modifier(GradientButtonModifier(colors: [backgroundColor],
                                                    font: font,
                                                    textColor: textColor,
                                                    clipShape: CustomShape(shape: RoundedRectangle(cornerRadius: cornerRadius))))
    }
}

public extension View {
    func applyGradientBgColors(backgroundColors: [Color],
                               font: Font,
                               textColor: Color,
                               cornerRadius: CGFloat,
                               fromPlayerStatsWidget: Bool = false) -> some View {
        
        return self.modifier(GradientButtonModifier(colors: backgroundColors,
                                                    font: font,
                                                    textColor: textColor,
                                                    clipShape: CustomShape(shape: RoundedRectangle(cornerRadius: cornerRadius)),
                                                    fromPlayerStatsWidget: fromPlayerStatsWidget))
    }
}

struct GradientButtonModifier: ViewModifier {
    var colors: [Color]
    var font: Font
    var textColor: Color
    var clipShape: CustomShape
    var fromPlayerStatsWidget: Bool = false
    
    func body(content: Content) -> some View {
        content
            .background(LinearGradient(colors: colors, startPoint: fromPlayerStatsWidget ? .leading : .top, endPoint: fromPlayerStatsWidget ? .trailing : .bottom))
            .font(font)
            .foregroundColor(textColor)
            .clipShape(clipShape)
    }
}

public struct CustomShape: Shape {
    private var base: (CGRect) -> Path
    
    public init<S: Shape>(shape: S) {
        base = shape.path(in:)
    }
    
    public func path(in rect: CGRect) -> Path {
        base(rect)
    }
}

public extension View {
    public func onRotate(perform action: @escaping (UIDeviceOrientation) -> Void) -> some View {
        self.modifier(DeviceRotationViewModifier(action: action))
    }
}

public struct DeviceRotationViewModifier: ViewModifier {
    public let action: (UIDeviceOrientation) -> Void

    public func body(content: Content) -> some View {
        content
            .onAppear()
            .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
                action(UIDevice.current.orientation)
            }
    }
}
