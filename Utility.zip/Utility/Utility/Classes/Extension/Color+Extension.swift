//
//  Color+Extension.swift
//  Utility
//
//  Created by Rajani Bhimanadham on 04/04/23.
//

import Foundation
import SwiftUI

public extension Color {
    init(hex: UInt, alpha: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xff) / 255,
            green: Double((hex >> 08) & 0xff) / 255,
            blue: Double((hex >> 00) & 0xff) / 255,
            opacity: alpha
        )
    }

    public var uiColor: UIColor {
        UIColor(self)
    }
    
    public var instantInteractionOverlay40: Color {
        withAlphaComponent(0.4)
    }
    
    public func withAlphaComponent(_ alpha: CGFloat) -> Color {
        uiColor.withAlphaComponent(alpha).swiftUIColor
    }
    
    static public var overlay40Color: Color {
        .white.withAlphaComponent(0.4)
    }
}

public extension UIColor {

    public var swiftUIColor: Color {
        Color(self)
    }
}

