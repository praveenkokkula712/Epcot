//
//  UIImageExtension.swift
//  MiniGames
//
//  Created by Sumeet Bajaj on 07/05/2018.
//  Copyright © 2018 Ivy Comptech. All rights reserved.
//

import UIKit

public extension UIImage {
    
     func resizeImage(width: CGFloat, offset:CGFloat) -> UIImage? {
         guard width != 0 else {
             return self
         }
        let scale = width/self.size.width
        let height = self.size.height * scale
        
        let offsetSize = CGSize(width: width + offset, height: height + offset)
        
        UIGraphicsBeginImageContextWithOptions(offsetSize, false, 0.0)
        
        self.draw(in: CGRect(x: offset/2, y: offset/2, width: width, height: height))
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        return newImage;
    }
    
    func resizeImage(targetSize: CGSize) -> UIImage? {
        guard targetSize.width != 0, targetSize.height != 0 else {
            return self
        }
        let  newSize = CGSize(width: targetSize.width,  height: targetSize.height)
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        self.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage
    }
    
    static func getImage(named value:String, bundle: Bundle = Bundle(for: CasinoCSS.self) ) -> UIImage?  {
        return UIImage(named: value, in: bundle, compatibleWith: nil)
    }
    
    func image(withTintColor color: UIColor) -> UIImage? {
            UIGraphicsBeginImageContextWithOptions(size, false, scale)

            let context = UIGraphicsGetCurrentContext()
            context?.translateBy(x: 0, y: size.height)
            context?.scaleBy(x: 1.0, y: -1.0)
            context?.setBlendMode(.normal)

            let rect = CGRect(origin: .zero, size: size)
            context?.clip(to: rect, mask: cgImage!)
            color.setFill()
            context?.fill(rect)
            let image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()

            return image
        }
}
