//
//  UIViewControllerExtension.swift
//  Utility
//
//  Created by Sumeet Bajaj on 28/01/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import UIKit

public extension UIViewController {
    
    class func loadFromNib(_ bundle:Bundle? = nil) -> Self {
        
        func instantiateFromNib<T: UIViewController>(bundle:Bundle?) -> T {
            
            let _bundle = bundle ?? Bundle(for: T.self)
            
            return T.init(nibName: String(describing: T.self), bundle: _bundle)
        }
        
        return instantiateFromNib(bundle: bundle)
    }
    
    func configureChildViewController(childController: UIViewController, onView : UIView) {
        addChild(childController)
        onView.addSubview(childController.view)
        constrainViewEqual(holderView: onView, view: childController.view)
        childController.didMove(toParent: self)
        childController.willMove(toParent: self)
    }
    
    func constrainViewEqual(holderView: UIView, view: UIView) {
        
        view.translatesAutoresizingMaskIntoConstraints = false
        
        //pin 100 points from the top of the super
        view.leadingAnchor.constraint(equalTo: holderView.leadingAnchor).isActive = true
        view.trailingAnchor.constraint(equalTo: holderView.trailingAnchor).isActive = true
        view.topAnchor.constraint(equalTo: holderView.topAnchor).isActive = true
        view.bottomAnchor.constraint(equalTo: holderView.bottomAnchor).isActive = true
    }
}

// Loader Extension
public extension UIViewController {
    
    /// This method will show the loader on controller view
    /// - Parameter safeAreaEnabled: Bool
    func showLoader(safeAreaEnabled:Bool = true) {
        DispatchQueue.main.async {
            self.view.showLoader(safeAreaEnabled: safeAreaEnabled)
        }
    }
    
    /// This method will update the text in loader displayed on controller view
    /// - Parameter message: String
    func updateLoader(message:String) {
        DispatchQueue.main.async {
            self.view.updateLoader(message: message)
        }
    }
    
    /// This method will update the value of progress view in loader displayed on controller view
    /// - Parameters:
    ///   - value: CGFloat
    ///   - message: String
    func updateLoader(value:Float, message:String = "Downloading...".localized()) {
        DispatchQueue.main.async {
            self.view.updateLoader(value: value, message: message)
        }
    }
    
    func updateDownloadView(gameName: String,gameImagePath: String, progress value:Float = 0) {
        DispatchQueue.main.async {
            self.view.updateDownloadLoader(gameName: gameName, gameImagePath: gameImagePath, progress: value)
        }
    }
    
    func updateDownloadingViewValue(with value: Float = 0) {
        DispatchQueue.main.async {
            self.view.updateDownloadLoaderValue(progress: value)
        }
    }
    
    
    /// This method will subscribe and display cancel button of loader shown on controller view
    /// - Parameter onClick: Clouser
    func subscribeLoaderCancelEvent(_ onClick: (() ->Void)?) {
        DispatchQueue.main.async {
            self.view.subscribeLoaderCancelEvent(onClick)
        }
    }
    
    /// This method will remove the loader shown on controller view
    func removeLoader() {
        DispatchQueue.main.async {
            self.view.removeLoader()
        }
    }
}


// Alert 
public extension UIViewController {
    
    func showAlert(_ title: String?,
                   _ message: String?,
                   _ actions: [UIAlertAction]? = nil,
                   attributedMessage: NSAttributedString? = nil) {
        
        DispatchQueue.main.async {
            
            guard self.presentedViewController == nil else {
                ETLogger.debug("Already presented \(String(describing: self.presentedViewController))")
                return
            }
            let alertController = UIAlertController(title: title,
                                                    message: message,
                                                    preferredStyle: .alert)
            if let attributeText = attributedMessage {
                alertController.title = title
                alertController.setValue(attributeText, forKey: "attributedMessage")
            } else {
                alertController.title = title
                alertController.message = message
            }
            
            alertController.modalPresentationStyle = .fullScreen
            alertController.modalPresentationCapturesStatusBarAppearance = true
            actions?.forEach({ (action) in
                alertController.addAction(action)
            })
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func dismissAnyAlertControllerIfPresent() {
        guard let topVC = UIApplication.topViewController() else {
            return
        }
        if topVC.isKind(of: UIAlertController.self) {
            topVC.dismiss(animated: false, completion: nil)
        }
    }
}

public extension UIViewController {
    func removeChildrenView() {
        guard self.parent != nil else { return }
        self.willMove(toParent: nil)
        self.view.removeFromSuperview()
        self.removeFromParent()
    }
}


public extension UIViewController {
    
    func removeChild() {
        self.children.forEach {
            $0.willMove(toParent: nil)
            $0.view.removeFromSuperview()
            $0.removeFromParent()
        }
    }
    
    func cleanAll() {
        ETLogger.debug(self)
        (self as? CleanProtocol)?.clean()
        self.children.forEach { (controller) in
            ETLogger.debug(controller)
            controller.cleanAll()
        }
    }
}

public protocol CleanProtocol {
    func clean()
}

public extension UIViewController {
    
    func presentDetail(_ viewControllerToPresent: UIViewController, animated: Bool = false, transitionType: CATransitionType = CATransitionType.push, completion: (() -> Void)? = nil) {
        let transition = CATransition()
        transition.duration = 0.25
        transition.type = transitionType
        transition.subtype = CATransitionSubtype.fromRight
        self.view.window?.layer.add(transition, forKey: kCATransition)
        present(viewControllerToPresent, animated: animated, completion: completion)
    }

    func dismissDetail(animated: Bool = false, completion: (() -> Void)? = nil) {
        let transition = CATransition()
        transition.duration = 0.25
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromLeft
        self.view.window?.layer.add(transition, forKey: kCATransition)
        dismiss(animated: animated, completion: completion)
    }
}
