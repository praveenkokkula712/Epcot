//
//  IntExtension.swift
//  Utility
//
//  Created by Bandana Choudhury on 07/07/22.
//

import Foundation
public extension Int {
    var getTimeDifference: String {
        
        let components = (hour: self / 3600, minute: (self % 3600) / 60, second: (self % 3600) % 60)
        var timeDiff = ""
        if components.hour ?? 0 > 0 {
            timeDiff = "\(components.hour ?? 0)hour \(components.minute ?? 0)min \(components.second ?? 0)sec"
        } else if components.minute ?? 0 > 0 {
            timeDiff = "\(components.minute ?? 0)min \(components.second ?? 0)sec"
        }
        else if components.second ?? 0 > 0 {
            timeDiff = "\(components.second ?? 0)sec"
        }
        return timeDiff
    }
}

public extension Int {

    public func playerBreakFormattedTime(isColonNeeded: Bool = true, isFullTimeString: Bool = false) -> String {
        let hours = self / 3600
        let minutes = self / 60 % 60
        let seconds = self % 60
        
        let hoursNotationString = NHLoginTimerHeaderLocalisedString.hours(value: hours,
                                                                          isFullTimeString: isFullTimeString)
        let minutesNotationString = NHLoginTimerHeaderLocalisedString.minutes(value: minutes,
                                                                              isFullTimeString: isFullTimeString)
        let secondsNotationString = NHLoginTimerHeaderLocalisedString.seconds(value: seconds,
                                                                              isFullTimeString: isFullTimeString)
        
        let hoursText = String(format:"%i%@", hours, hoursNotationString)
        let minutesText = String(format:"%i%@", minutes, minutesNotationString)
        let secondsText = String(format:"%i%@", seconds, secondsNotationString)
        
        let colonString = isColonNeeded ? " : " : " "
        
        var str = "" //1h : 0m : 2s, 0m : 2s
        if hours > 0 {
            str = hoursText
            if minutes > 0 {
                str += colonString + minutesText
            }
            if seconds > 0 {
                if minutes == 0 {
                    str += colonString + minutesText
                }
                str += colonString + secondsText
            }
        } else if minutes > 0 {
            str = minutesText
            if seconds > 0 {
                str += colonString + secondsText
            }
        } else {
            str = secondsText
        }
        return str
    }
}

public struct NHLoginTimerHeaderLocalisedString {
    @LocalizedStrings static public private(set) var playBreakGraceTitle = "play_break_about_to_start_lobby"
    @LocalizedStrings static public private(set) var playBreakStartedTitle = "play_break_started_lobby"
    @LocalizedStrings static public private(set) var minutesShortKey = "minutes_short_key"
    @LocalizedStrings static public private(set) var secondsShortKey = "seconds_short_key"
    @LocalizedStrings static public private(set) var hoursShortKey = "hours_short_key"
    
    @LocalizedStrings static public private(set) var limits_hours = "limits_hours"
    @LocalizedStrings static public private(set) var limits_minutes = "limits_minutes"
    @LocalizedStrings static public private(set) var limits_hour = "limits_hour"
    @LocalizedStrings static public private(set) var limits_minute = "limits_minute"
    @LocalizedStrings static public private(set) var limits_seconds = "limits_seconds"
    
    public static func hours(value: Int, isFullTimeString: Bool = false) -> String {
        if isFullTimeString {
            return " " + (value > 1 ? limits_hours : limits_hour)
        }
        return hoursShortKey
    }
    static public func minutes(value: Int, isFullTimeString: Bool = false) -> String {
        if isFullTimeString {
            return " " + (value > 1 ? limits_minutes : limits_minute)
        }
        return minutesShortKey
    }
    static public func seconds(value: Int, isFullTimeString: Bool = false) -> String {
        if isFullTimeString {
            return " " + limits_seconds
        }
        return secondsShortKey
    }
}
