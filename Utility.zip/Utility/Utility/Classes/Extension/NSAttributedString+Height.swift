//
//  NSAttributedString+Height.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 03/04/23.
//

import Foundation

extension NSAttributedString {
    
    var fixLineHeight: NSAttributedString {
        let mutable = NSMutableAttributedString(attributedString: self)
        let range = NSRange(location: 0, length: mutable.string.count)
        mutable.enumerateAttribute(.paragraphStyle,
                                   in: range,
                                   options: [.longestEffectiveRangeNotRequired])
        { value, range, _ in
            if let style = value as? NSMutableParagraphStyle {
                style.maximumLineHeight = 0
                style.minimumLineHeight = 0
                style.lineHeightMultiple = 0
                mutable.addAttributes([NSAttributedString.Key.paragraphStyle: style], range: range)
            }
        }
        return mutable
    }
    
    public func height(constraintedWidth width: CGFloat) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, context: nil)
        return ceil(boundingBox.height)
     }
}
