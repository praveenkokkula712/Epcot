//
//  UIButtonExtension.swift
//  CasinoLobby
//
//  Created by Praveen Kokkula on 13/01/22.
//

import Foundation
import UIKit

public class ResizableButton: UIButton {
    public override var intrinsicContentSize: CGSize {
        let labelSize = titleLabel?.sizeThatFits(CGSize(width: frame.width, height: .greatestFiniteMagnitude)) ?? .zero
        let desiredButtonSize = CGSize(width: labelSize.width + titleEdgeInsets.left + titleEdgeInsets.right, height: labelSize.height + titleEdgeInsets.top + titleEdgeInsets.bottom)
        return desiredButtonSize
    }
}

public extension UIButton {
    func setImage(with image: String,
                  tintColor color: UIColor?,
                  bundle: Bundle,
                  renderingMode mode: UIImage.RenderingMode = .alwaysTemplate) {
        self.setImage(UIImage(named: image,
                              in: bundle,
                              compatibleWith: nil)?
            .withRenderingMode(mode),
                      for: .normal)
        self.tintColor = color
    }
}

public extension UIButton {
    
    var css: EpcotLobbyCSS? {
        CasinoCSS.lobby?.epcotLobbyCSS
    }
    
    public func applyEpcotGradientBgColor() {
        self.layer.borderWidth = 0.0
        self.layer.cornerRadius = self.frame.size.height / 2
        self.setTitleColor(css?.epcotGradientButtonColor,
                           for: .normal)
        self.titleLabel?.font = css?.epcotButtonTitleFont
        self.clipsToBounds = true
        let bgView = EpcotGradientLayer(frame: self.bounds)
        bgView.backgroundColor = .clear
        bgView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.addSubview(bgView)
        self.sendSubviewToBack(bgView)
        self.backgroundColor = .clear
    }
    
    public func applyEpcotButtonWithoutBgColor() {
        self.layer.cornerRadius = self.frame.size.height / 2
        self.layer.borderColor = css?.epcotViewBorderColor?.cgColor
        self.layer.borderWidth = 1
        self.setTitleColor(css?.epcotSecondaryButtonTitleColor,
                           for: .normal)
        self.titleLabel?.font = css?.epcotButtonTitleFont
    }
}
