//
//  LobbySwitcherType.swift
//  Utility
//
//  Created by Praveen Kokkula on 26/07/22.
//

import Foundation

public let kGridLayoutIcon = "grid_view"
public let kListLayoutIcon = "list_view"

public enum LobbySwitcherType: String {
    case list
    case grid
    
    public var swappedValue: LobbySwitcherType {
        switch self {
        case .list: return .grid
        case .grid: return .list
        }
    }
    
    public var lobbySwitcherlayoutIcon : String {
        switch self {
        case .list: return kListLayoutIcon
        case .grid: return kGridLayoutIcon
        }
    }
}
