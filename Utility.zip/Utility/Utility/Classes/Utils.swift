//
//  Utils.swift
//  Utility
//
//  Created by Naresh Banavath on 24/09/24.
//

import Foundation
public typealias IconVariant = (icon: String, font: UIFont)
