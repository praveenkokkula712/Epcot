//
//  LocalizedStrings.swift
//  Utility
//
//  Created by Praveen Kokkula on 26/04/22.
//

import Foundation

@propertyWrapper public struct LocalizedStrings {
    
    public var value: String
    
    public var wrappedValue: String {
        
        get { return value.localized }
        
        set { value = newValue }
    }

    public init(wrappedValue value: String) {
        self.value = value
    }
}
