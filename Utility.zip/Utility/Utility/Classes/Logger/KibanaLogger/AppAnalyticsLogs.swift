//
//  AppAnalytics.swift
//  CasinoGames
//
//  Created by Sathish Pullagura on 15/09/21.
//

import Foundation
//MARK:- AppAnalyticsLog -

public struct AppAnalyticsLogs: Codable {
    var screenViews: String?
    var clickActions: ClickAction?
}
public struct ClickAction: Codable {
    var feature: String?
    var userAction: String?
    var remarks: String?
}


public enum ButtonActionFeature: String {
    case lobbyURLAction
    case reloadURLAction
    case pingURLAction
    case logoutURLAction
    case webViewcloseAction
    case fallBackViewPopOver
    case suggestionPopOver
    case easyNavigation
    
    case lobbyView
    case searchView
    case favourite
    case myGames
}
