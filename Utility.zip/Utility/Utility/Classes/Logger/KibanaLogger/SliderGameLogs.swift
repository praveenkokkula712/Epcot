//
//  SliderGameLogs.swift
//  CasinoCore
//
//  Created by Sathish Pullagura on 23/09/21.
//

import Foundation

public struct SliderGamesLogs: Codable {
    var gameSocketStatus: String?
    var loginStatus: String?
    
    public init(gameSocketStatus: String? = nil,
                loginStatus: String? = nil) {
        self.gameSocketStatus = gameSocketStatus
        self.loginStatus = loginStatus
    }
}
