//
//  NativeFooterLogs.swift
//  NativeFooter
//
//  Created by Sathish Pullagura on 16/09/21.
//

import Foundation

public struct NativeFooterLogs: Codable {
    var browserType: String?
    var url: String?
    
    public init(browserType: BrowserType? = nil,
                url: String? = nil) {
        self.browserType = browserType?.stringValue
        self.url = url
    }
}
public enum BrowserType: Int {
    case none = 0, openNative, inAppBrowser, inAppBrowserFullScreen, openExternalBrowser
    var stringValue: String {
        switch self {
        case .none:
            return "none"
        case .openNative:
            return "nativeBrowser"
        case .inAppBrowser:
            return "inAppBrowser"
        case .inAppBrowserFullScreen:
            return "inAppBrowserFullScreen"
        case .openExternalBrowser:
            return "externalBrowser"
        }
    }
}
