//
//  ApiDetails.swift
//  Utility
//
//  Created by Praveen Kokkula on 03/10/23.
//

import Foundation

public struct ApiDetailLogs: Codable {
    public var requestType: String?
    public var requestUrl: String? {
        didSet {
            if self.requestType == nil {
                self.requestType = getRequestType(url: requestUrl ?? "")
            }
        }
    }
    public var errorMsg: String?
    public var responseStatus: String?//from boolean value
    public var responseCode: Int?
    public var apiCallDuration: Double?
    public var retriesCount: Int?
    public var response: String?//only for geocomply
    public var errorCode, errorCodeMessage :String?
    
    public init(requestType: String? = nil,
                requestUrl: String? = nil,
                errorMsg: String? = nil,
                responseStatus: String? = nil,
                responseCode: Int? = nil,
                apiCallDuration: Double? = nil,
                retriesCount: Int? = nil,
                response: String? = nil,
                errorCode: String? = nil,
                errorCodeMessage: String? = nil) {
        self.requestType = requestType
        self.requestUrl = requestUrl
        self.errorMsg = errorMsg
        self.responseStatus = responseStatus
        self.responseCode = responseCode
        self.apiCallDuration = apiCallDuration
        self.retriesCount = retriesCount
        self.response = response
        self.errorCode = errorCode
        self.errorCodeMessage = errorCodeMessage
    }
    
    public func getRequestType(url: String) -> String {
        for type in UrlRequestType.allCases {
            if url.contains(type.urlExtension) {
                return type.rawValue
            }
        }
        return "NA"
    }
   
}

public enum UrlRequestType: String, CaseIterable {
    case dynacon
    case geoComply
    case feedBack
    case siteCore
    case cns
    case uploadDocument
    case wallet
    case account
    case lmt = "LMT"
    case recentlyPlayed
    case getFavorite
    case setFavorite
    case jackpot
    case rcpu = "RCPU"
    case gameInit = "GIEAction"
    case endGame = "EndGameSession"
    case playerActiveStatus
    case casinoStories
    case mostSearch
    case rgService
    case arc
    // MARK: - React Native Requirement
    case rnAuthenticate
    
    public var urlExtension: String {
        switch self {
        case .dynacon:
            return "Batch.svc"
        case .geoComply:
            return "GeoLocation.svc"
        case .feedBack:
            return "Mailing.svc"
        case .siteCore:
            return "content.svc"
        case .cns:
            return "Notification.svc"
        case .uploadDocument:
            return "Upload.svc"
        case .wallet:
            return "Wallet.svc"
        case .account:
            return "Account.svc"
        case .lmt:
            return "fetchGenericLobbyData"
        case .recentlyPlayed:
            return "getRecentlyPlayedGames"
        case .getFavorite:
            return "getFavoriteGamesFeed"
        case .setFavorite:
            return "favoirteGames"
        case .jackpot:
            return "getJackpotPoolInfo"
        case .rcpu:
            return "FetchRegulatoryInfo.action"
        case .gameInit:
            return "GameInitEmbeddedLaunch.action"
        case .endGame:
            return "EndGameSessionEmbeddedLaunch.action"
        case .playerActiveStatus:
            return "getPlayerIdleTimeStatus.action"
        case .casinoStories:
            return "gamingstoriesphase"
        case .mostSearch:
            return "getMostSearchedGames"
        case .rgService:
            return "responsibleGamingProps"
        case .arc:
            return "TolerationRegime.action"
            // MARK: - React Native Requirement
        case .rnAuthenticate:
            return "Authenticate.svc"
        }
    }
}
