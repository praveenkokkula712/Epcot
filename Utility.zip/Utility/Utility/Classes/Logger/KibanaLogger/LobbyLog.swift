//
//  LobbyLog.swift
//  CasinoLobby
//
//  Created by Sathish Pullagura on 15/09/21.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import Foundation

public struct LobbyLog: Codable {
    var message: String?
    var errorMsg: String?
    var game: GameLog?
    var screen: String?
    
    public init(message: String? = nil,
                errorMsg: String? = nil,
                game: GameLog? = nil,
                screen: String? = nil) {
        self.message = message
        self.errorMsg = errorMsg
        self.game = game
        self.screen = screen
    }
}

public struct GameLog: Codable {
    var play: String?
    var favourite:String?
    var name: String?
    var provider: String?
    
    public init(play: String? = nil,
                favourite: String? = nil,
                name: String? = nil,
                provider: String? = nil) {
        self.play = play
        self.favourite = favourite
        self.name = name
        self.provider = provider
    }
}

//Mark: Download Canel Log
public struct DownloadCanelLogs: Codable {
    public var gameName: String?
    public var downloadStartTime: String?
    public var cancelledTime: String?
    public var percentageDownloaded: String?

    public init(gameName: String = "",
                downloadStartTime: String = "",
                cancelledTime: String = "",
                percentageDownloaded: String = "" ) {
        self.gameName = gameName
        self.downloadStartTime = downloadStartTime
        self.cancelledTime = cancelledTime
        self.percentageDownloaded = percentageDownloaded
    }
    
    enum CodingKeys: String, CodingKey {
        case gameName = "game_name"
        case downloadStartTime = "download_start_time"
        case cancelledTime = "cancelled_time"
        case percentageDownloaded = "percentage_downloaded"
    }
}

//Mark: Download Canel Log
public struct DownloadedGameLogs: Codable {
    public var gameName: String?
    public var downloadedTime: String?
    public var downloadStartTime: String?
    public var downloadEndTime: String?

    public init(gameName: String = "",
                downloadedTime: String = "",
                downloadStartTime: String = "",
                downloadEndTime: String = ""  ) {
        self.gameName = gameName
        self.downloadedTime = downloadedTime
        self.downloadStartTime = downloadStartTime
        self.downloadEndTime = downloadEndTime
    }
    
    enum CodingKeys: String, CodingKey {
        case gameName = "game_name"
        case downloadedTime = "downloaded_time"
        case downloadStartTime = "download_start_time"
        case downloadEndTime = "download_end_time"
    }
}

//Mark: Download Background Log
public struct GameBackgroundDownloadLogs: Codable {
    public var gameName: String?
    public var downloadStartTime: String?
    public var backgroundTime: String?
    
    public init(gameName: String = "",
                downloadStartTime: String = "",
                backgroundTime: String = "" ) {
        self.gameName = gameName
        self.downloadStartTime = downloadStartTime
        self.backgroundTime = backgroundTime
    }
    
    enum CodingKeys: String, CodingKey {
        case gameName = "game_name"
        case downloadStartTime = "download_start_time"
        case backgroundTime = "app_background_time"
    }
}
