//
//  GameLogs.swift
//  CasinoGames
//
//  Created by Sathish Pullagura on 15/09/21.
//

import Foundation

public struct DownloadMetrics: Codable {
    public var size: Double?
    public var time: Double?
    public var bandwidth: Double?
    public var isLowDataMode: String?
    
    public init(size: Double? = nil,
                time: Double? = nil,
                bandwidth: Double? = nil,
                isLowDataMode: String? = nil) {
        self.size = size
        self.time = time
        self.bandwidth = bandwidth
        self.isLowDataMode = isLowDataMode
    }
}

public struct GameLogs:Codable {
    
    public var gameName: String?
    public var urlType: String?
    public var url: String?
    public var message:String?
    public var tag:String?
    public var source:String?
    public var destination:String?
    public var bundlePath:String?
    public var errorMsg:String?
    public var navigation:String?
    public var dualMode:String?
    public var awsVersionId:String?
    public var gameVersion:Int?
    public var downloadStatus: String?
    public var networkSwitchStatus: String?
    public var errorCode: String?
    public var errorCodeMessage: String?
    public var isUserCancelled: String?
    public var userCancelledProgress: Float?
    public var isUpgraded: String?
    public var isNative: String?
    public var provider: String?
    public var bundleType: String?
    public var groupedOdrTag: String?
    public var downloadMetrics: DownloadMetrics?
    
    public init(gameName: String? = nil,
                urlType: URLType? = nil,
                url: String? = nil,
                message: String? = nil,
                tag: String? = nil,
                source: String? = nil,
                destination: String? = nil,
                bundlePath: String? = nil,
                errorMsg: String? = nil,
                navigation: String? = nil,
                dualMode: String? = nil,
                awsVersionId: String? = nil,
                gameVersion: Int? = nil,
                downloadStatus: String? = nil,
                networkSwitchStatus: String? = nil,
                errorCode: String? = nil,
                errorCodeMessage: String? = nil,
                isUserCancelled: String? = nil,
                userCancelledProgress: Float? = nil,
                isUpgraded: String? = nil,
                isNative: String? = nil,
                provider: String? = nil,
                bundleType: String? = nil,
                groupedOdrTag: String? = nil,
                downloadMetrics: DownloadMetrics? = nil) {
        
        self.gameName = gameName
        self.urlType = urlType?.stringValue
        self.url = url
        self.message = message
        self.tag = tag
        self.source = source
        self.destination = destination
        self.bundlePath = bundlePath
        self.errorMsg = errorMsg
        self.navigation = navigation
        self.dualMode = dualMode
        self.awsVersionId = awsVersionId
        self.gameVersion = gameVersion
        self.downloadStatus = downloadStatus
        self.networkSwitchStatus = networkSwitchStatus
        self.errorCode = errorCode
        self.errorCodeMessage = errorCodeMessage
        self.isUserCancelled = isUserCancelled
        self.userCancelledProgress = userCancelledProgress
        self.isUpgraded = isUpgraded
        self.isNative = isNative
        self.provider = provider
        self.bundleType = bundleType
        self.groupedOdrTag = groupedOdrTag
        self.downloadMetrics = downloadMetrics
    }
   
}

public enum URLType: Int {
    
   
    case deposit    // for cashier url
    case history    // for game logs/history url
    case unknown    // unkown
    case cloudFront // for cloudfront download
    case odr // for odr download
    case html // for HTML game load
    
    var stringValue: String {
        switch self {
        case .deposit:
            return "deposit"
        case .history:
            return "history"
        case .unknown:
            return "unknown"
        case .cloudFront:
            return "cloudfront"
        case .odr:
            return "odr"
        case .html:
            return "HTML"
        }
    }
}

