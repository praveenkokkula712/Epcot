//
//  WebViewErrorLogs.swift
//  Pods
//
//  Created by Sathish Pullagura on 16/09/21.
//

import Foundation

public struct WebViewErrorsLogs: Codable {
    public var isFromReactNative: String?
    public var url: String?
    public var errorCode: String?
    public var errorMsg: String?
    public var errorCodeMessage: String?
    
    public init(isFromReactNative: String? = nil,
                url: String? = nil,
                errorCode: String? = nil,
                errorMsg: String? = nil,
                errorCodeMessage: String? = nil) {
        self.url = url
        self.errorCode = errorCode
        self.errorMsg = errorMsg
        self.isFromReactNative = isFromReactNative
        self.errorCodeMessage = errorCodeMessage
    }
}
