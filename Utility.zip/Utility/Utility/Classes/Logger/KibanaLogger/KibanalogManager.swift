//
//  KibanalogManager.swift
//  Utility
//
//  Created by Sathish Pullagura on 28/09/21.
//

import Foundation

public enum EventDetailsType: String {
    case appAnalytics
    case webviewError
    case gameLogs
    case lobbyLogs
    case slidergames
    case nativeFooter
    case gameDownloadCancelTrack
    case gameDownloadedTrack
    case gameBackgroundDownloadTrack
    case apiDetails
}

public struct KibanaLogManager: Codable {
    public static func sendLogs(of type: EventDetailsType, with logData: Any) {
        switch type {
        case .appAnalytics:
            EventDetails(appAnalytics: logData as? AppAnalyticsLogs).send()
        case .webviewError:
            EventDetails(webViewErrors: logData as? WebViewErrorsLogs).send()
        case .gameLogs:
            EventDetails(gameLogs: logData as? GameLogs).send()
        case .lobbyLogs:
            EventDetails(nativeLobby: logData as? LobbyLog).send()
        case .slidergames:
            EventDetails(sliderGames: logData as? SliderGamesLogs).send()
        case .nativeFooter:
            EventDetails(nativeFooter: logData as? NativeFooterLogs).send()
        case .gameDownloadCancelTrack:
            EventDetails(gameDownloadCancelTrack: logData as? DownloadCanelLogs).send()
        case .gameDownloadedTrack:
            EventDetails(gameDownloadedTrack: logData as? DownloadedGameLogs).send()
        case .gameBackgroundDownloadTrack:
            EventDetails(gameBackgroundDownloadTrack: logData as? GameBackgroundDownloadLogs).send()
        case .apiDetails:
            EventDetails(apiDetails: logData as? ApiDetailLogs).send()
        }
    }
    
    public static func sendButtonAction(feature: ButtonActionFeature, function: String, fileName: String, remarks: String?) {
        let clickActionLog = ClickAction(feature: feature.rawValue, userAction: function, remarks: remarks)
        let analyticLogs = AppAnalyticsLogs(screenViews: fileName, clickActions: clickActionLog)
        KibanaLogManager.sendLogs(of: .appAnalytics, with: analyticLogs)
    }
}

public struct EventDetails: Codable {
    var appAnalytics: AppAnalyticsLogs?
    var gameLogs: GameLogs?
    var webViewErrors: WebViewErrorsLogs?
    var nativeLobby: LobbyLog?
    var sliderGames: SliderGamesLogs?
    var nativeFooter: NativeFooterLogs?
    var gameDownloadCancelTrack: DownloadCanelLogs?
    var gameDownloadedTrack: DownloadedGameLogs?
    var gameBackgroundDownloadTrack: GameBackgroundDownloadLogs?
    var apiDetails: ApiDetailLogs?
    
    public func send() {
        // convert to data
        guard let log = try? JSONEncoder().encode(self) else { return }
        // convert data to json object
        guard let jsonObject = try? log.jsonObject().get() else { return }
        // check error and create log type
        let type:ETLogger.LogType = isErrorLog ? .error : .normal
        // send logs
        
        ETLogger.log(jsonObject, Bundle(for: LoadingView.self).bundleIdentifier, type)
        ETLogger.debug("KibanaLog: \(jsonObject)")
        ETLogger.debug(jsonObject)
        ETLogger.debug(Bundle(for: LoadingView.self).bundleIdentifier)
        ETLogger.debug(type)
    }
    
    public var isErrorLog: Bool {
        get {
            if let gameLog = self.gameLogs  {
                return gameLog.errorMsg?.count ?? 0 > 0
            } else if let webviewErrorLogs = self.webViewErrors  {
                return webviewErrorLogs.errorMsg?.count ?? 0 > 0
            } else if let lobbyLog = self.nativeLobby  {
                return lobbyLog.errorMsg?.count ?? 0 > 0
            } else if let gameDownloadCancelTrackLog = self.gameDownloadCancelTrack  {
                return gameDownloadCancelTrackLog.gameName?.count ?? 0 > 0
            } else if let gameDownloadedTrackLog = self.gameDownloadedTrack  {
                return gameDownloadedTrackLog.gameName?.count ?? 0 > 0
            } else if let gameBackgroundDownloadTrack = self.gameBackgroundDownloadTrack  {
                return gameBackgroundDownloadTrack.gameName?.count ?? 0 > 0
            }
            return false
        }
    }
}

