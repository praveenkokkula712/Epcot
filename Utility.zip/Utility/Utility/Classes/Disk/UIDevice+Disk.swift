//
//  DiskManager.swift
//  Utility
//
//  Created by Sumeet Bajaj on 06/02/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import UIKit

public extension UIDevice {
    
    enum SizeType {
        
        case total, free, used
        
        var name : String {
            get {
                switch self {
                case .total: return "Total"
                case .free: return "Free"
                case .used: return "used"
                }
            }
        }
    }
    
    func diskSize(type:SizeType, units:ByteCountFormatter.Units = .useBytes) -> String {
        
        let sizeInBytes = self.diskSizeInBytes(type: type)
        
        return self.formatter(in: units).string(fromByteCount: sizeInBytes)
    }
    
    func diskSizeInBytes(type:SizeType, fileManager: FileManager = .default) -> Int64 {
        
        switch type {
            case .total: return self.totalDiskSpaceInBytes()
            case .free : return self.freeDiskSpaceInBytes(fileManager: fileManager)
            case .used : return self.usedDiskSpaceInBytes()
        }
    }
    
    private func formatter(in units: ByteCountFormatter.Units) -> ByteCountFormatter {
       
          let formatter = ByteCountFormatter()
          formatter.allowedUnits = units
          formatter.countStyle = units == .useBytes ?  .binary :.decimal
          formatter.includesUnit = false
          
          return formatter
      }
    
    private func totalDiskSpaceInBytes() -> Int64 {
        do {
            guard let totalDiskSpaceInBytes = try FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory())[FileAttributeKey.systemSize] as? Int64 else {
                return 0
            }
            return totalDiskSpaceInBytes
        } catch {
            return 0
        }
    }

    private func freeDiskSpaceInBytes(fileManager: FileManager = .default) -> Int64 {
        do {
            guard let totalDiskSpaceInBytes = try fileManager.attributesOfFileSystem(forPath: NSHomeDirectory())[FileAttributeKey.systemFreeSize] as? Int64 else {
                return 0
            }
            return totalDiskSpaceInBytes
        } catch {
            return 0
        }
    }

    private func usedDiskSpaceInBytes() -> Int64 {
        return totalDiskSpaceInBytes() - freeDiskSpaceInBytes()
    }
}

