//
//  PlayBreakType.swift
//  Utility
//
//  Created by Praveen Kokkula on 08/04/24.
//

import Foundation

public enum PlayBreakType {
    case gracePeriod
    case playBreakStarted
    case longSessionContinuous
    case longSession24
    case longSessionContinuousHard
    case longSession24Hard
}
