//
//  ImmersiveInstance.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 11/11/22.
//

import Foundation


public class ImmersiveInstance {
    
    public static let shared = ImmersiveInstance()
    
    let alertCoordinator = AlertCoordinator()

    public private(set) var isEnabled = true
    
    private init() {
        
    }
    
    public func updateState(with value: Bool) {
        self.isEnabled = value
    }
    
}
