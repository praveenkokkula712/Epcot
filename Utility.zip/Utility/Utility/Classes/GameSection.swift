//
//  GameSection.swift
//  Utility
//
//  Created by Praveen Kokkula on 09/09/22.
//

import Foundation

public enum GameSection: Int  {
    
    case lobby = 1
    case recent
    case favourite
    case search
    case promo
    case seeMore
    case freeSpins
    case jackptoTiles
    public var name: String {
        switch self {
        case .lobby: return "All Games"
        case .recent: return "Recently Played"
        case .favourite: return "Favourites"
        case .search: return "Search"
        case .promo: return "PromoPage"
        case .seeMore: return "See All Section"
        case .freeSpins: return "Free Spins Overlay"
        case .jackptoTiles: return "jackpot_tiles"
        }
    }
}

public enum GameContainer: String {
    case home = "Lobby"
}
