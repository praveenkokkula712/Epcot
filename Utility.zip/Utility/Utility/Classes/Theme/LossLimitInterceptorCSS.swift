//
//  LossLimitInterceptorCSS.swift
//  Utility
//
//  Created by Bandana Choudhury on 01/07/22.
//

import Foundation


public protocol LossLimitInterceptorCSS: LossLimitCSS {
    
    var continueButton: ButtonCSS? {get set}
    var closeButton: ButtonCSS? {get set}

}
