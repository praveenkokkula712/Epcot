//
//  QuickGamesPopupCSS.swift
//  Utility
//
//  Created by Gunnala Divya on 21/03/24.
//

import Foundation

public protocol QuickGamesPopupCSS: ViewCSS {
    var containerViewBGColor: UIColor? {get set}
    var containerCornerRadius: CGFloat? {get set}
    var headerBGColor: UIColor? {get set}
    var headerTitle: TextCSS? {get set}
    var closeButton: ButtonCSS? {get set}
    var closeButtonCornerRadius: CGFloat? {get set}
    var description: TextCSS? {get set}
    var buttonCornerRadius: CGFloat? {get set}
    var buttonBorderColor: UIColor? {get set}
    var buttonBorderWidth: CGFloat? {get set}
    var iconTintColor: UIColor? {get set}
    var iconBGColor: UIColor? {get set}
    var gameTypeTitle: TextCSS? {get set}
    var addQuickGamesButton: ButtonCSS? {get set}
    var addQuickGamesButtonBGColor1: UIColor? {get set}
    var addQuickGamesButtonBGColor2: UIColor? {get set}
    var mayBeLaterButton: ButtonCSS? {get set}
}

public struct DefaultQuickGamesPopupCSS: QuickGamesPopupCSS {
    public init() { }
    
    public var containerViewBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var containerCornerRadius: CGFloat? = {
        6.0
    }()
    
    public var headerBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F3F4F5")
    }()
    
    public var headerTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#050505"), font: UIFont.systemFont(ofSize: 17))
    }()
    
    public var closeButton: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#050505"), font: UIFont.boldSystemFont(ofSize: 13)),
                         selected: UIColor.hexStringToUIColor(hex: "#F3F4F5"), normal: UIColor.hexStringToUIColor(hex: "#F3F4F5"))
    }()
    
    public var closeButtonCornerRadius: CGFloat? = {
        16.0
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#2F3541"), font: UIFont.systemFont(ofSize: 13))
    }()
    
    public var buttonCornerRadius: CGFloat? = {
        22.0
    }()
    
    public var buttonBorderColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#303030", withAlpha: 0.28)
    }()
    
    public var buttonBorderWidth: CGFloat? = {
        1.0
    }()
    
    public var iconTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#212121")
    }()
    
    public var iconBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F3F4F5")
    }()
    
    public var gameTypeTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#050505"), font: UIFont.systemFont(ofSize: 9))
    }()
    
    public var addQuickGamesButton: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#050505"), font: UIFont.boldSystemFont(ofSize: 13)),
                         selected: UIColor.hexStringToUIColor(hex: "#E9D193"), normal: UIColor.hexStringToUIColor(hex: "#E9D193"))
    }()
    
    public var addQuickGamesButtonBGColor1: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#E9D193")
    }()
    
    public var addQuickGamesButtonBGColor2: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#D4B962")
    }()
    
    public var mayBeLaterButton: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#050505"), font: UIFont.boldSystemFont(ofSize: 13)),
                         selected: UIColor.hexStringToUIColor(hex: "#FFFFFF"), normal: UIColor.hexStringToUIColor(hex: "#FFFFFF"))
    }()

    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF").withAlphaComponent(0.4)
    }()
}

