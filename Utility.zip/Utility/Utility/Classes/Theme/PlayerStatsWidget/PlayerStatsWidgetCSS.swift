//
//  PlayerStasWidget.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 02/07/24.
//

import Foundation

public protocol PlayerStatsWidgetCSS {
    
    var playerStatsWidgetCornerRadius: CGFloat? { get set }

    var statsPeriodSelectedBgColor: UIColor { get set }
    var statsPeriodSelectedCornerRadius : CGFloat? { get set }
    var statsPeriodSelectedTitle : TextCSS? { get set }

    var statsPeriodUnSelected : PlayerStatsWidgetPeriodCSS? { get set }

    var title: TextCSS? { get set }
    var titleCta: TextCSS? { get set }
    
    var message: TextCSS? { get set }
    var messageTextOpacity: CGFloat? { get set }
    
    var gameTileCornerRadius:  CGFloat? { get set }
    
    var multiplierViewBgColor: UIColor? { get set }
    var multiplierViewBorderColor: UIColor? { get set }
    var multiplierViewBorderWidth: CGFloat? { get set }
    var multiplierViewCornerRadius: CGFloat? { get set }
    var multiplierDigitViewBgColor: UIColor? { get set }
    var multiplierDigit: TextCSS? { get set }
    var multiplierDigitViewCornerRadius: CGFloat? { get set }
    
    var jpPriceBgColor: UIColor? { get set }
    var jpPrice: TextCSS? { get set }
    var jpPriceTwo: TextCSS? { get set }
}

public protocol PlayerStatsWidgetPeriodCSS {
    var title: TextCSS? { get set }
    var gradientColors: [UIColor]? { get set }
    var cornerRadius : CGFloat? { get set }
    var borderColor : UIColor? { get set }
    var borderWidth : CGFloat? { get set }
}
