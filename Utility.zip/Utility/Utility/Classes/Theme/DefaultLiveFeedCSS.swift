//
//  DefaultLiveFeedCSS.swift
//  Utility
//
//  Created by Naresh Banavath on 10/09/24.
//

import Foundation
public struct DefaultLiveFeedCSS: LiveFeedCSS {
    
    public var lastResultsTextFont: UIFont? = .systemFont(ofSize: 10.0)
    
    public var availableSeatsTextFont: UIFont? =  .systemFont(ofSize: 10.0)
    
    public var lastResultsValuesFont: UIFont? = .systemFont(ofSize: 10.0)
    
    public var availableSeatsAvatarSize: CGFloat? = 8.0
    
    public var minBetText: TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 10.0))
   }()
    
    public var viewBackgroundColor: UIColor? = .clear
    
    public var viewLayerBackgroundColor: UIColor? = .clear
    
    public var viewOpaqueColor: UIColor? = .clear
    
    
}
