//
//  LimitsCSS.swift
//  DailyLimitDemo
//
//  Created by Praveen Kokkula on 07/06/21.
//

import Foundation
import UIKit

public protocol LimitsCSS: ViewCSS {
     
    var headerBG: UIColor? {get set}
    
    var headerDescription: TextCSS? {get set}
    
    var subHeaderDescription: TextCSS? {get set}
    
    var sectionHeader: TextCSS? {get set}
    
    var limitsCell: LimitsCellCSS? {get set}

    var toaster: UIColor? {get set}
    
    var toasetDescription: TextCSS? {get set}
    
    var close: LimitsButtonCSS? {get set}
    
    var update: LimitsButtonCSS? {get set}
    
    var sessionClearCSS : SessionClearCSS? {get set}
    
    var lossLimitReachedCSS: LossLimitReachedCSS? {get set}
    
    var lossLimitInterceptorCSS: LossLimitInterceptorCSS? {get set}
}

public protocol LimitsCellCSS {
    
    var rowHeader: TextCSS? {get set}
    
    var progressBarFinished: UIColor? {get set}
    
    var progressBarleft: UIColor? {get set}
    
    var rowSubHeader: TextCSS? {get set}
    
    var rowValues: TextCSS? {get set}
    
}

public protocol LimitsButtonCSS: ButtonCSS {
    var disabled: UIColor? {get set}
}

public protocol SessionClearCSS: ViewCSS {
    
    var headerBG: UIColor? {get set}
    
    var headerTitle: TextCSS? {get set}
    
    var description: TextCSS? {get set}
    
    var containerBG: UIColor? {get set}
    
    var underStandBtn: ButtonCSS? {get set}
    
    var buttonLayer: UIColor? {get set}
    
    var backIconColor: UIColor? {get set}
}


