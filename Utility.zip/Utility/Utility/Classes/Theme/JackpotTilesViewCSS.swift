//
//  JackpotTilesViewCSS.swift
//  EpcotLobby
//
//  Created by Naresh Banavath on 01/07/24.
//

import Foundation
import UIKit

public protocol JackpotTilesViewCSS {
    
    var cornerRadius              : CGFloat { get set }
    /// JackPotTile TopView
    var badgeTitle                : TextCSS? { get set }
    var badgeTitleBackgroundColor : UIColor? { get set }
    var badgeTitleCornerRadius    : CGFloat? { get set }
    var title                     : TextCSS? { get set }
    var description               : TextCSS? { get set }
    var lastWin                   : TextCSS? { get set }
    var gameImageCornerRadius     : CGFloat? { get set }
    var viewGameBtn               : ButtonCSS? { get set }
    var bottomViewBackgroundColor : UIColor? { get set }
    
    /// JackpotTile BottomViews
    
    /// DailyBottomView
    var dailyBottomViewTitle                              : TextCSS? { get set }
    var dailyBottomViewAmount                             : TextCSS? { get set }
    var dailyBottomViewTimeLeftLabel                      : TextCSS? { get set }
    var dailyBottomViewHourAndMinuteTitleLabel            : TextCSS? { get set }
    var dailyBottomViewHourAndMinuteValues                : TextCSS? { get set }
    var dailyBottomViewHourAndMinuteValuesBackgroundColor : UIColor? { get set }
    var dailyBottomViewBackgroundColor                    : UIColor? { get set }
    var dailyBottomViewStrokeColor                        : UIColor? { get set }
    var dailyStartingAtText                               : TextCSS? { get set }
    var dailyStartingAtTime                               : TextCSS? { get set }
    ///ValueBottomView
    
    var valueBottomViewTitle                              : TextCSS? { get set }
    var valueBottomViewAmount                             : TextCSS? { get set }
    var valueBottomViewProgressColor                      : UIColor? { get set }
    var valueBottomViewProgressColorWhen90Percent         : UIColor? { get set }
    var valueBottomViewMaxAmount                          : TextCSS? { get set }
    var valueBottomViewBackgroundColor                    : UIColor? { get set }
    var valueBottomViewStrokeColor                        : UIColor? { get set }
   
    ///ProgressiveBottomView
    
    var progressiveBottomViewTitle                        : TextCSS? { get set }
    var progressiveBottomViewAmountText                   : TextCSS? { get set }
    var progressiveBottomView_ViewGamesButton             : ButtonCSS? { get set }
    var progressiveBottomView_ViewGamesButtonCornerRadius : CGFloat? { get set }
    var progressiveBottomViewBackgroundColor              : UIColor? { get set }
    var progressiveBottomViewStrokeColor                  : UIColor? { get set }

}
