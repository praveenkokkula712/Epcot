//
//  EasyNavigationCSS.swift
//  Utility
//
//  Created by Praveen Kokkula on 13/10/21.
//

import Foundation
import UIKit

public protocol EasyNavigationCSS: ViewCSS {
    
    var sessionTimerCSS: SessionTimerCSS? {get set}
    
    var sessionWinLossCSS: SessionWinLossCSS? {get set}
    
    var subBrandColor: UIColor? {get set}
    
    var gamePillBGColorSelected: UIColor? {get set}
    
    var gamePillBGColorUnselected: UIColor? {get set}
    
    var gamePillTextColorSelected: UIColor? {get set}
    
    var gamePillTextColorUnselected: UIColor? {get set}
    
    var gamePillTextFont: UIFont? {get set}
    
    var buttonCornerRadius: CGFloat? {get set}
    
    var buttonTitleColor: UIColor? {get set}
    
    var buttonTitleFont: UIFont? {get set}
    
    var borderColor: UIColor? {get set}
    
    var borderWidth: CGFloat? {get set}
    
    var seperatorColor: UIColor? {get set}
}

public protocol SessionTimerCSS: ViewCSS {
    
    var gamePlayDuration: TextCSS? {get set}
    
    var currentTime: TextCSS? {get set}
    
}

public protocol SessionWinLossCSS: ViewCSS {
    
    var session: TextCSS? {get set}
    
    var amount: TextCSS? {get set}
    
}


public struct DefaultEasyNavigationCSS: EasyNavigationCSS  {
    
    public var seperatorColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "C3C4C7")
    }()
    
    
    public var gamePillBGColorSelected: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "FFFFFF")
    }()
    
    public var gamePillBGColorUnselected: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "101010")
    }()
    
    public var gamePillTextColorSelected: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "050505")
    }()
    
    public var gamePillTextColorUnselected: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "FFFFFF")
    }()
    
    public var gamePillTextFont: UIFont? = {
        return UIFont.systemFont(ofSize: 13)
    }()
    
    public var buttonCornerRadius: CGFloat? = {
        return 16.0
    }()
    
    public var buttonTitleColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "FFFFFF")
    }()
    
    public var buttonTitleFont: UIFont? = {
        return UIFont.systemFont(ofSize: 13)
    }()
    
    public var borderColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "FFFFFF").withAlphaComponent(0.28)
    }()
    
    public var borderWidth: CGFloat? = {
        return 1.0
    }()
    
    public var sessionTimerCSS: SessionTimerCSS? = {
      return DefaultSessionTimerCSS()
    }()
    
    public var sessionWinLossCSS: SessionWinLossCSS? = {
       return DefaultSessionWinLossCSS()
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "084d8d")
    }()
    
    public var subBrandColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "ffcd00")
    }()
    
    public init() {
        
    }
}

public struct DefaultSessionTimerCSS: SessionTimerCSS {
    
    public var gamePlayDuration: TextCSS? = {
        return DefaultTextCSS(color: UIColor.white, font: UIFont.systemFont(ofSize: 8))
    }()
    
    public var currentTime: TextCSS? = {
        return DefaultTextCSS(color: UIColor.white, font: UIFont.boldSystemFont(ofSize: 10))
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "07294b")
    }()
    
    public init() {
        
    }
}

public struct DefaultSessionWinLossCSS: SessionWinLossCSS {
    
    public var session: TextCSS? = {
        return DefaultTextCSS(color: UIColor.white, font: UIFont.systemFont(ofSize: 8))
    }()
    
    public var amount: TextCSS? = {
        DefaultTextCSS(color: UIColor.white, font: UIFont.boldSystemFont(ofSize: 8))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "ffffff", withAlpha: 0.2)
    }()
    
    public init() {
        
    }
}
