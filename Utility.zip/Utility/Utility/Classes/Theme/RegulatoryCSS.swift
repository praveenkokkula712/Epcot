//
//  RegulatoryCSS.swift
//  Utility
//
//  Created by Raviraju Vysyaraju on 11/2/20.
//

import Foundation
import UIKit

/// CSS Defination for the German Regulatory Alert view
public protocol RegulatoryAlertCSS {
    var title: TextCSS? {get set}
    var body: TextCSS? {get set}
    var btn: ButtonCSS? {get set}
}


public protocol GamePlayCoolOffTimerAlertCSS {
    
    var bannerTitle: TextCSS? {get set}
    var bannerBody: TextCSS? {get set}
    var bannerBtn: ButtonCSS? {get set}
    
    var progressTimerText: TextCSS? { get set}
    var progressTimerTextBGViewColor: UIColor? { get set}
    var pragrassBarColor: UIColor? { get set }
}


public protocol SessionCoolOffAlertCSS {
    
    var description: TextCSS? {get set}
    var okBtn: ButtonCSS? {get set}
    var leaveBtn: ButtonCSS? {get set}
    var containerBgColor: UIColor? { get set}
    var leaveButtonBorderColor: UIColor? { get set}
    var cornerRadius: CGFloat? { get set}
}

public protocol GermanSessionCoolOffTimerAlertCSS {
    
    var bannerTitle: TextCSS? {get set}
    var bannerBody: TextCSS? {get set}
    var bannerBtn: ButtonCSS? {get set}
    
    var progressTimerText: TextCSS? { get set}
    var progressTimerTextBgViewColor: UIColor? { get set}
    var progressBarColor: UIColor? { get set }
    var progressBarTrackColor: UIColor? { get set }

}

public protocol GermanRegulatoryCSS {
    var germanRegulatoryAlertCSS: RegulatoryAlertCSS? {set get}
    var gameplayTimerAlertCSS: GamePlayCoolOffTimerAlertCSS? {set get}
    var germanSessionCoolOffTimerAlertCSS: GermanSessionCoolOffTimerAlertCSS? {set get}
    var rcpSessionCoolOffAlertCSS: SessionCoolOffAlertCSS? {set get}
    var monthlySummaryPopUpViewCSS: MonthlySummaryPopUpViewCSS? {get set}
    var rtpBigWinWidgetCSS: RtpBigWinWidgetCSS? {get set}
    var gameExclusionViewCSS: GameExclusionViewCSS? {get set}
    
    var germanResponsibleGamingCSS: GermanResponsibleGamingCSS? {get set}
}


public protocol GameExclusionViewCSS {
    
    var title: TextCSS? {get set}
    var hyperLinkCSS: TextCSS? {get set}
    var backgroundColor: UIColor? {get set}
}
