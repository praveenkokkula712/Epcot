//
//  DefaultPlayBreakViewCSS.swift
//  Utility
//
//  Created by Naresh Banavath on 10/04/24.
//

import Foundation
import UIKit

public struct DefaultPlayBreakViewCSS : PlayBreakViewCSS {
    
    public var lslCloseButtonColor: UIColor? = {
        .white
    }()
    
    public var lslContentViewBGColor: UIColor? = {
        .white
    }()
    
    public var lslButtonTextColor: UIColor? = {
        .black
    }()
    

    public var overlayBgColor: UIColor? = {
         UIColor.hexStringToUIColor(hex: "#333333")
    }()
    
    public var contentBgColor: UIColor? = {
         UIColor.hexStringToUIColor(hex: "#141414")
    }()
    
    public var title: TextCSS? = {
         DefaultTextCSS(color: .white, font: .systemFont(ofSize: 14.0))
    }()
    
    public var titleHeaderBgColor: UIColor? = {
        UIColor.black
    }()
    
    public var description: TextCSS? = {
         DefaultTextCSS(color: .white, font: .systemFont(ofSize: 14.0))
    }()
    
    public var moreInfoButton: ButtonCSS? = {
         DefaultButtonCSS(title: DefaultTextCSS(color: .white, font: .systemFont(ofSize: 14.0)),
            selected: .white,
            normal: .white)
    }()
    
    public var okButton: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: .white, font: .systemFont(ofSize: 14.0, weight: .medium)),
            selected: .white,
            normal: .white)
    }()
    
    public var okButtonCornerRadius: CGFloat? = {
         5.0
    }()
    
    public var toasterText: TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 12.0))
    }()
    
    public var timerText: TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 12.0))
    }()
    
    public var timerBgColor: UIColor? = {
        UIColor.black
    }()
    
    public var hardInterceptorMoreInfo: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: .white, font: .systemFont(ofSize: 14.0)),
           selected: .white,
           normal: .white)
    }()
    
    public var fontName: String? = {
        "PrimaryRegularFont"
    }()
    
    public var fontSize: CGFloat? = {
        14.0
    }()
    
    public init () {
        
    }
}
