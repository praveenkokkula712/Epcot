//
//  SessionSettingsPopupCSS.swift
//  ConfigModule
//
//  Created by Gostu Bhargavi on 05/03/24.
//

import Foundation

public protocol SessionSettingsPopupCSS: ViewCSS {
    var containerViewBGColor: UIColor? {get set}
    var containerCornerRadius: CGFloat? {get set}
    var headerTitle: TextCSS? {get set}
    var description: TextCSS? {get set}
    var okButton: ButtonCSS? {get set}
    var okButtonCornerRadius: CGFloat? {get set}
    var iconTintColor: UIColor? {get set}
    var subViewBGColor: UIColor? {get set}
    var subCornerRadius: CGFloat? {get set}
    var subViewHeaderTitle: TextCSS? {get set}
    var subViewDescriptionTitle: TextCSS? {get set}
    var subViewIconTintColor: UIColor? {get set}
    var subViewIconBGColor: UIColor? {get set}
}

public struct DefaultSessionSettingPopupCSS: SessionSettingsPopupCSS {
    public init() { }
    
    public var containerViewBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var containerCornerRadius: CGFloat? = {
        3.0
    }()
    
    public var headerTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.systemFont(ofSize: 14))
    }()
    
    public var okButton: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFCC00"), font: UIFont.boldSystemFont(ofSize: 14)),
                         selected: UIColor.hexStringToUIColor(hex: "#333333"), normal: UIColor.hexStringToUIColor(hex: "#333333"))
    }()
    
    public var okButtonCornerRadius: CGFloat? = {
        3.0
    }()
    
    public var iconTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    public var subViewBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var subCornerRadius: CGFloat? = {
        3.0
    }()
    
    public var subViewHeaderTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var subViewDescriptionTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.systemFont(ofSize: 16))
    }()
    
    public var subViewIconTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#000000")
    }()
    
    public var subViewIconBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#333333").withAlphaComponent(0.8)
    }()
}
