//
//  CasinoGameStoriesCSS.swift
//  ConfigModule
//
//  Created by Sreekanth Reddy Tadi on 27/07/23.
//

import Foundation

public protocol GameStoriesCSS {
    var title: TextCSS? { get set }
    var headerTitle: TextCSS? { get set }
    var selectedColor: UIColor? { get set }
    var unselectedColor: UIColor? { get set }
    var selectedTextColor: UIColor? { get set }
    var unselectedTextColor: UIColor? { get set }
    var unselectedViewAlpha: Double? { get set }
    var lineWidth: CGFloat? { get set }
    var cornerRadius: CGFloat? { get set }
    var daysToHoldSavedData: Int? { get set }
}


public protocol GameStoryItemsCSS: ViewCSS {
    var title: TextCSS? { get set }
    var subTitle: TextCSS? { get set }
    var paragraph: TextCSS? { get set }
    var progressBarColor: UIColor? { get set }
    var progressFillColor: UIColor? { get set }
    var closeButtonColor: UIColor? { get set }
    var ctaButton: TextCSS? { get set }
    var ctaButtonBackgroundColor: UIColor? { get set }
    var ctaButtonHighlightColor: UIColor? { get set }
    var ctaButtonCornerRadius: CGFloat? { get set }
    var legalTermsText: TextCSS? { get set }
    var legalTermsBackgroundColor: UIColor? { get set }
    var seeMoreButton: TextCSS? { get set }
    var seeMoreHandleColor: UIColor? { get set }
    var scrollButtonColor: UIColor? { get set }
    var scrollButtonBackgroundColor: UIColor? { get set }
    var closeOffset: Double? { get set }

    ///for Onboarding
    var touchHandBackgroundColor: UIColor? { get set }
    var touchTitle: TextCSS? { get set }
    var logoColor: UIColor? { get set }
    var logoBorderWidth: CGFloat? { get set }
    var logoBorderColor: UIColor? { get set }
    var logoRingColor: UIColor? { get set }
    var logoRingWidth: CGFloat? { get set }
    var logoHairlineColor: UIColor? { get set }
    var rippleColor: UIColor? { get set }
}
