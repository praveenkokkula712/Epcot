//
//  DefaultRtpBigWinWidgetCSS.swift
//  Utility
//
//  Created by Bandana Choudhury on 21/09/22.
//

import Foundation
import UIKit


public struct DefaultRtpBigWinWidgetCSS: RtpBigWinWidgetCSS {
    
    public init() {
        
    }
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.black, font: UIFont.boldSystemFont(ofSize: 17))
    }()
    
    public var body: TextCSS? = {
        DefaultTextCSS(color: UIColor.black, font: UIFont.boldSystemFont(ofSize: 12))
    }()
    
    public var link: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "FAC031"), font: UIFont.systemFont(ofSize: 12))
    }()
    
    public var continueButton: ButtonCSS? = {
        DefaultButtonCSS(
            title: DefaultTextCSS(color: UIColor.white,
                                  font:  UIFont.boldSystemFont(ofSize: 13)),
            selected: UIColor.hexStringToUIColor(hex: "61B95A"),
            normal: UIColor.hexStringToUIColor(hex: "61B95A"))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.white
    }()
    
}
