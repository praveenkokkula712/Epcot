//
//  DefaultRcpUKCSS.swift
//  Utility
//
//  Created by Praveen Kokkula on 22/07/21.
//

import Foundation
import UIKit


public struct DefaultRcpUKCSS: RcpUKCSS {
    
    public init() {
        
    }
    
   public var containerBG: UIColor? = {
        return UIColor(red: 51/255, green: 51/255, blue: 51/255, alpha: 1.0)
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "FFFFFF"), font: UIFont.boldSystemFont(ofSize: 18))
    }()
    
    public var body: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "FFFFFF"), font: UIFont.systemFont(ofSize: 14))
    }()
    
    public var bodyAttribute: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "FFFFFF"), font: UIFont.boldSystemFont(ofSize: 14))
    }()
    
    public var continuebutton: ButtonCSS? = {
        DefaultButtonCSS(
            title: DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "000000"),
                                  font: UIFont.boldSystemFont(ofSize: 16)),
                         selected: UIColor(red: 247/255, green: 206/255, blue: 24/255, alpha: 1.0),
                         normal: UIColor(red: 247/255, green: 206/255, blue: 24/255, alpha: 1.0))
    }()
    
    public var border: UIColor? = {
        return nil
    }()
    
    public var leave: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "000000"), font: UIFont.boldSystemFont(ofSize: 16)),
                         selected: UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0),
                         normal: UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.black
    }()
    
    public var linkTextColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "FFFFFF")
    }()
    
    public var infoIconTintColor: UIColor? = {
        UIColor.blue
    }()
    
    public var buttonCornerRadius: CGFloat?
}
