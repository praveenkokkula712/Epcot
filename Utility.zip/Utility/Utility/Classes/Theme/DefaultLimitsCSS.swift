//
//  DefaultLimitsCSS.swift
//  DailyLimitDemo
//
//  Created by Praveen Kokkula on 07/06/21.
//

import Foundation
import UIKit

public struct DefaultLimitsCSS: LimitsCSS {
    

    public init() {
        
    }

    public var headerBG: UIColor? = {
        UIColor.init(red: 68/255, green: 81/255, blue: 90/255, alpha: 1)
    }()
    
    public var headerDescription: TextCSS? = {
        LimitsTextCSS(color: UIColor.white, font: UIFont.boldSystemFont(ofSize: 24))
    }()
    
    public var subHeaderDescription: TextCSS? = {
        LimitsTextCSS(color: UIColor(displayP3Red: 72/255, green: 72/255, blue: 72/255, alpha: 1), font: UIFont.systemFont(ofSize: 14))
    }()
    
    public  var sectionHeader: TextCSS? = {
        LimitsTextCSS(color: UIColor(displayP3Red: 58/255, green: 58/255, blue: 58/255, alpha: 1), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var limitsCell: LimitsCellCSS? = {
        DefaultLimitsCellCSS()
    }()
    
    public var toaster: UIColor? = {
        UIColor(displayP3Red: 237/255, green: 237/255, blue: 237/255, alpha: 1)
    }()
    
    public var toasetDescription: TextCSS? = {
        LimitsTextCSS(color: UIColor(displayP3Red: 72/255, green: 72/255, blue: 72/255, alpha: 1), font: UIFont.boldSystemFont(ofSize: 12))
    }()
    
    public var close: LimitsButtonCSS? = {
        DefaultLimitsButtonCSS(
            selected: UIColor(displayP3Red: 36/255, green: 237/255, blue: 226/255, alpha: 1),
            normal: UIColor(displayP3Red: 36/255, green: 237/255, blue: 226/255, alpha: 1),
            title: LimitsTextCSS(
                color: UIColor(displayP3Red: 51/255, green: 51/255, blue: 51/255, alpha: 1),
                font: UIFont.boldSystemFont(ofSize: 14)),
            disabled: UIColor(displayP3Red: 36/255, green: 237/255, blue: 226/255, alpha: 0.5))
    }()
    
    public var update: LimitsButtonCSS? = {
        DefaultLimitsButtonCSS(
            selected: UIColor(displayP3Red: 255/255, green: 179/255, blue: 71/255, alpha: 1),
            normal: UIColor(displayP3Red: 255/255, green: 179/255, blue: 71/255, alpha: 1),
            title: LimitsTextCSS(
                color: UIColor(displayP3Red: 51/255, green: 51/255, blue: 51/255, alpha: 1),
                font: UIFont.boldSystemFont(ofSize: 14)),
            disabled: UIColor(displayP3Red: 255/255, green: 179/255, blue: 71/255, alpha: 0.5))
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.white
    }()
    
    public var sessionClearCSS: SessionClearCSS? = {
        DefaultSessionClearCSS()
    }()
    
    public var lossLimitReachedCSS: LossLimitReachedCSS? = {
        DefaultLossLimitReachedCSS()
    }()
    
    public var lossLimitInterceptorCSS: LossLimitInterceptorCSS? = {
        DefaultLossLimitInterceptorCSS()
    }()
    
    
//    public var sessionLimitPopUpCSS: SessionClearCSS? = {
//        DefaultSessionLimitViewCSS()
//    }()
    
}

//public struct DefaultSessionLimitViewCSS: SessionClearCSS{
//    public var headerBG: UIColor?
//
//    public var underStandBtn: ButtonCSS?
//
//    public var buttonLayer: UIColor?
//
//    public var backIconColor: UIColor?
//
//
//    public init() {
//
//    }
//    public var backgroundColor: UIColor?
//
//
//    public var headerTitle: TextCSS? = {
//        let color = UIColor.white
//        let boldfont = UIFont.boldSystemFont(ofSize: 15)
//        return DefaultTextCSS(color: color, font: boldfont)
//    }()
//
//    public var description: TextCSS? = {
//        let color = UIColor.white
//        let boldfont = UIFont.systemFont(ofSize: 15)
//        return DefaultTextCSS(color: color, font: boldfont)
//    }()
//
//    public var containerBG: UIColor? = {
//     return  UIColor.darkGray
//    }()
//}

public struct DefaultSessionClearCSS: SessionClearCSS {
    
    public init() {
        
    }
    
    public var headerBG: UIColor? = {
        UIColor.black
    }()
    
    public var headerTitle: TextCSS? = {
        LimitsTextCSS(color: UIColor.white, font: UIFont.systemFont(ofSize: 17))
                
    }()
    
    public var description: TextCSS? = {
        LimitsTextCSS(color: UIColor.black, font: UIFont.systemFont(ofSize: 15))
    }()
    
    public var containerBG: UIColor? = {
        UIColor.white
    }()
    
    public var underStandBtn: ButtonCSS? = {
        let defaultTitleCSS = DefaultTextCSS(color: UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0), font: UIFont.boldSystemFont(ofSize: 15))
        return DefaultButtonCSS(title: defaultTitleCSS, selected: UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0), normal: UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0))
    }()
    
    public var buttonLayer: UIColor? = {
        UIColor.init(red: 170/255, green: 170/255, blue: 170/255, alpha: 1)
    }()
    
    
    public var backgroundColor: UIColor? = {
        UIColor.init(red: 170/255, green: 170/255, blue: 170/255, alpha: 0.6)
    }()
    
    public var backIconColor: UIColor? = {
       return UIColor(red: 0, green: 0, blue: 0, alpha: 1)
    }()
}

public struct LimitsTextCSS: TextCSS {
    
    public var color: UIColor?
    
    public var font: UIFont?
}

public struct DefaultLimitsButtonCSS: LimitsButtonCSS {
    
    public var selected: UIColor?
    
    public var normal: UIColor?
    
    public var title: TextCSS?
    
    public var disabled: UIColor?
}


public struct DefaultLimitsCellCSS: LimitsCellCSS {
    
    public var rowHeader: TextCSS? = {
        LimitsTextCSS(color: UIColor(displayP3Red: 58/255, green: 58/255, blue: 58/255, alpha: 1), font: UIFont.boldSystemFont(ofSize: 14))
    }()
    
    public var progressBarFinished: UIColor? = {
        UIColor(displayP3Red: 255/255, green: 59/255, blue: 48/255, alpha: 1)
    }()
    
    public var progressBarleft: UIColor? = {
        UIColor(displayP3Red: 234/255, green: 234/255, blue: 234/255, alpha: 1)
    }()
    
    public var rowSubHeader: TextCSS? = {
        LimitsTextCSS(color: UIColor(displayP3Red: 72/255, green: 72/255, blue: 72/255, alpha: 1), font: UIFont.boldSystemFont(ofSize: 12))
    }()
    
    public var rowValues: TextCSS? = {
        LimitsTextCSS(color: UIColor(displayP3Red: 72/255, green: 72/255, blue: 72/255, alpha: 1), font: UIFont.systemFont(ofSize: 12))
    }()
    
}
