//
//  ResponsibleGamingCSS.swift
//  Utility
//
//  Created by Bandana Choudhury on 26/09/22.
//

import Foundation
import UIKit

public protocol GermanResponsibleGamingCSS: ViewCSS {
    var containerBG: UIColor? {get set}
    var title: TextCSS? {get set}
    var body: TextCSS? {get set}
    var linkColor: UIColor? {get set}
    var continueButton: ButtonCSS? {get set}
    
}
