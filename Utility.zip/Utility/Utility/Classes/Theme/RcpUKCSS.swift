//
//  RcpUKCSS.swift
//  Utility
//
//  Created by Praveen Kokkula on 22/07/21.
//

import Foundation
import UIKit

public protocol RcpUKCSS: ViewCSS {
    
    var containerBG: UIColor? {get set}
    var title: TextCSS? {get set}
    var body: TextCSS? {get set}
    var bodyAttribute: TextCSS? {get set}
    var continuebutton: ButtonCSS? {get set}
    var leave: ButtonCSS? {get set}
    var border:UIColor? {get set}
    var linkTextColor: UIColor? {get set}
    var infoIconTintColor: UIColor? {get set}
    var buttonCornerRadius: CGFloat? {get set}
}
