//
//  MonthlySummaryPopUpViewCSS.swift
//  Utility
//
//  Created by Bandana Choudhury on 18/09/22.
//

import Foundation


public protocol MonthlySummaryPopUpViewCSS: ViewCSS {
    
    var containerBG: UIColor? {get set}
    var title: TextCSS? {get set}
    var body: TextCSS? {get set}
    var okButton: ButtonCSS? {get set}
   
}
