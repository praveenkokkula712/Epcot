//
//  DefaultOnboardingViewCSS.swift
//  Utility
//
//  Created by Rajani Bhimanadham on 26/04/23.
//

import Foundation

public struct DefaultOnboardingViewCss: OnbordingViewCSS {
    public var welcomeScreenCSS: OnbordingWelcomeScreenCSS = {
        return lobbyWelcomeScreenCSS()
    }()
    
    public var journeyViewCSS: OnbordingJourneyViewCSS = {
        return lobbyOnboardingJourneyViewCSS()
    }()
    
    public init() {
        
    }
}
public struct lobbyWelcomeScreenCSS : OnbordingWelcomeScreenCSS {
    public var getStartedButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.boldSystemFont(ofSize: 12)),
                         selected: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0),
                         normal: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0))
    }()
    
    public var skipButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.boldSystemFont(ofSize: 12)),
                         selected: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0),
                         normal: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0))
    }()
    
    public var getStartedButtonCornerRadius: CGFloat? = {
        4.0
    }()
    
    public var skipButtonCornerRadius: CGFloat? = {
        4.0
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#ADADAD"), font: UIFont.systemFont(ofSize: 12))
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#ADADAD"), font: UIFont.systemFont(ofSize: 12))
    }()
    
    public var closeButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.boldSystemFont(ofSize: 12)),
                         selected: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0),
                         normal: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#333333")
    }()
    
    public var cornerRadius: CGFloat? = {
        10.0
    }()
    
    public var overlayBgColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#141414", withAlpha: 0.8)
    }()

    public init() {
        
    }

}

public struct lobbyOnboardingJourneyViewCSS : OnbordingJourneyViewCSS {
    public var backBtn: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.boldSystemFont(ofSize: 12)),
                         selected: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0),
                         normal: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0))
    }()
    
    public var nextBtn: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.boldSystemFont(ofSize: 12)),
                         selected: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0),
                         normal: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0))
    }()
    
    public var closeButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.boldSystemFont(ofSize: 12)),
                         selected: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0),
                         normal: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0))
    }()
    
    public var journeyCount: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#ADADAD"), font: UIFont.systemFont(ofSize: 12))
    }()
    
    public var dividerColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#ADADAD"), font: UIFont.systemFont(ofSize: 12))
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#ADADAD"), font: UIFont.systemFont(ofSize: 12))
    }()
     
    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#333333")
    }()
    
    public var overlayBorderColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    public var cornerRadius: CGFloat? = {
        10.0
    }()
    
    public init() {
        
    }

}
