//
//  BingoWidgetFeatureBadgesCSS.swift
//  Utility
//
//  Created by Sindhuja Vedire on 23/02/24.
//

import Foundation

public protocol BingoFeatureBadgesCSS {
    var badgeSize : CGFloat? { get set }
    var backgroundBadgeSize: CGFloat? { get set }
    var everyOneWinsColor: UIColor? { get set }
    var everyOneWinsBackgroundColor: UIColor? { get set }
    var hotBallColor: UIColor? { get set }
    var hotBallBackgroundColor: UIColor? { get set }
    var rollOnColor: UIColor? { get set }
    var rollOnBackgroundColor: UIColor? { get set }
    var cashOutColor: UIColor? { get set }
    var cashOutBackgroundColor: UIColor? { get set }
    var physicalPrizeColor: UIColor? { get set }
    var physicalPrizeBackgroundColor: UIColor? { get set }
    var multiPriceColor: UIColor? { get set }
    var multiPriceBackgroundColor: UIColor? { get set }
    var freeTicketsColor: UIColor? { get set }
    var freeTicketsBackgroundColor: UIColor? { get set }
    var cashPotColor: UIColor? { get set }
    var cashPotBackgroundColor: UIColor? { get set }
    var timedJackpotColor: UIColor? { get set }
    var timedJackpotBackgroundColor: UIColor? { get set }
    var dealColor: UIColor? { get set }
    var dealBackgroundColor: UIColor? { get set }
    var beatChaserColor: UIColor? { get set }
    var beatChaserBackgroundColor: UIColor? { get set }
    var scratchCardColor: UIColor? { get set }
    var scratchCardBackgroundColor: UIColor? { get set }
    var sessionBingoColor: UIColor? { get set }
    var sessionBingoBackgroundColor: UIColor? { get set }
    var superBooksColor: UIColor? { get set }
    var superBooksBackgroundColor: UIColor? { get set }
    var countryMilesColor: UIColor? { get set }
    var countryMilesBackgroundColor: UIColor? { get set }
    var countryMiles2Color: UIColor? { get set }
    var countryMiles2BackgroundColor: UIColor? { get set }
    var sideBetsColor: UIColor? { get set }
    var sideBetsBackgroundColor: UIColor? { get set }
    var liveStreamingColor: UIColor? { get set }
    var liveStreamingBackgroundColor: UIColor? { get set }
    var bonusSpinsColor: UIColor? { get set }
    var bonusSpinsBackgroundColor: UIColor? { get set }
    var bonusCashColor: UIColor? { get set }
    var bonusCashBackgroundColor: UIColor? { get set }
    var bonusTicketsColor: UIColor? { get set }
    var bonusTicketsBackgroundColor: UIColor? { get set }
    var slotsRacePodiumColor: UIColor? { get set }
    var slotsRacePodiumBackgroundColor: UIColor? { get set }
    var bingoInsuranceColor: UIColor? { get set }
    var bingoInsuranceBackgroundColor: UIColor? { get set }
    var slidingPotColor: UIColor? { get set }
    var slidingPotBackgroundColor: UIColor? { get set }
    var jumpingPotColor: UIColor? { get set }
    var jumpingPotBackgroundColor: UIColor? { get set }
    var superLinkColor: UIColor? { get set }
    var superLinkBackgroundColor: UIColor? { get set }
    var extraSpinColor: UIColor? { get set }
    var extraSpinColor2: UIColor? { get set }
    var extraSpinBackgroundColor: UIColor? { get set }
    var whackBingoColor: UIColor? { get set }
    var whackBingoBackgroundColor: UIColor? { get set }
    var prizeDropColor: UIColor? { get set }
    var prizeDropBackgroundColor: UIColor? { get set }
    var prizeWheelColor: UIColor? { get set }
    var prizeWheelBackgroundColor: UIColor? { get set }
    var prizeWheelBorderColor: UIColor? { get set }
    var prizeWheelBorderThickness: CGFloat? { get set }
    var prizeWheelBorderRadius: CGFloat? { get set }
    var ntgColor: UIColor? { get set }
    var ntgBackgroundColor: UIColor? { get set }
    var ntgTransform: CGFloat? { get set }
}
