//
//  BingoWidgetCSS.swift
//  Alamofire
//
//  Created by Bandaru Priyanka on 04/01/24.
//

import Foundation

public protocol BingoWidgetCSS: ViewCSS {
    var widgetHeaderTextCss: TextCSS { get set }
    var widgetHeaderSeeAllCss: TextCSS { get set }
    var widgetViewcornerRadius: CGFloat? { get set }
    var widgetTitleCss: TextCSS { get set }
    var widgetAmountTextCss: TextCSS { get set }
    var jackpotIconColor: UIColor? { get set }
    var jackpotIconSize: CGFloat? { get set }
    var widgetProgressBarHeight: CGFloat? { get set }
    var widgetProgressBarColor:  UIColor? { get set }
    var widgetProgressBarTrackColor:  UIColor? { get set }
    var preBuyWidgetCSS: BingoWidgetButtonCSS? { get set }
    var playWidgetCSS: BingoWidgetButtonCSS? { get set }
    var infoIconColor: UIColor? { get set }
    var favoriteIconColor: UIColor? { get set }
    var winDetails: BingoIconDetailsCSS? { get set }
    var cardDetails: BingoIconDetailsCSS? { get set }
    var playerDetails: BingoIconDetailsCSS? { get set }
    var linkIconColor:  UIColor? { get set }
    var ribbonViewBackgroundColor:  UIColor? { get set }
    var ribbonTitleCSS:  TextCSS { get set }
    var dividerColor:  UIColor? { get set }
    var progressBarTimerCount: CGFloat? { get set }
    var timerCss: BingoWidgetTimerCSS? { get set }
    var infoTitleCss: TextCSS { get set }
    var infoDescriptionCss: TextCSS { get set }
    var infoFavoriteColor:  UIColor? { get set }
    var infoCloseColor:  UIColor? { get set }
    var infoFavoriteIconSize: CGFloat? { get set }
    var infoCloseIconSize: CGFloat? { get set }
    var infoCardColor:  UIColor? { get set }
    var infoBlurRadius: CGFloat? { get set }
    var infoAnimationDuration: CGFloat? { get set }
    var inactiveBingoWidgetRoomColor: UIColor? { get set }
    var featureBadgeCss: BingoFeatureBadgesCSS? { get set }
    var detailsIconSize: CGFloat? { get set }
    var combinedRoomsText: TextCSS? { get set }
}

public protocol BingoWidgetButtonCSS: ViewCSS {
    
    var textCSS:  TextCSS { get set }
    var cornerRadius: CGFloat? { get set }
    var borderColor:  UIColor? { get set }
    var borderWidth:  CGFloat? { get set }
    var height: CGFloat? { get set }
    var highlightTextColor: UIColor? { get set }
    var highlightBackgroundColor: UIColor? { get set }
}

public protocol BingoIconDetailsCSS {
    
    var iconColor: UIColor? { get set }
    var iconTextCSS: TextCSS { get set }
    var combinedRoomsFont: UIFont? { get set }
}

public protocol BingoWidgetTimerCSS: ViewCSS {
    
    var thresholdCount: CGFloat? { get set }
    var thresholdColor: UIColor? { get set }
    var timerBackgroundColor: UIColor? { get set }
    var alertTimerBackgroundColor: UIColor? { get set }
    var textCSS: TextCSS { get set }
    var updatedtimerCSS: TextCSS { get set}
    var cornerRadius: CGFloat? { get set }
    var timerIconColor: UIColor? { get set}
    var updatedTimerIconColor: UIColor? { get set }
    var timerIconSize: CGFloat? { get set }
}
