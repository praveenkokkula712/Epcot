//
//  CSS.swift
//  Utility
//
//  Created by Sumeet Bajaj on 13/03/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import UIKit

public protocol ViewCSS {
    
    var backgroundColor: UIColor? { get set}
}

public protocol TextCSS {
    
    var color: UIColor? { get set }
    
    var font: UIFont? { get set }
}

public protocol ButtonCSS {
    
    var selected:UIColor? { get set }
    
    var normal:UIColor? { get set }
    
    var title:TextCSS? { get set }
}
