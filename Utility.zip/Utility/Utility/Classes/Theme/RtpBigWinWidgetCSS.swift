//
//  RtpBigWinWidgetCSS.swift
//  Utility
//
//  Created by Bandana Choudhury on 21/09/22.
//

import Foundation

public protocol RtpBigWinWidgetCSS: ViewCSS {
    
    var title: TextCSS? {get set}
    var body: TextCSS? {get set}
    var link: TextCSS? {get set}
    var continueButton: ButtonCSS? {get set}
   
}
