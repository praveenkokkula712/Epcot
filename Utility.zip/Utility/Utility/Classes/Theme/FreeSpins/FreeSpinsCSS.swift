//
//  FreeSpinsCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 02/05/24.
//

import Foundation

public protocol FreeSpinsCSS: ViewCSS {
    var remainingSpinsText: TextCSS? { get set }
    var expiryText: TextCSS? { get set }
    var spinText: TextCSS? { get set }
    var spinButtonTopColor: UIColor? { get set }
    var spinButtonBottomColor: UIColor? { get set }
    var spinButtonBackgroundColor: UIColor? { get set }
    var backgroundColor: UIColor? { get set }
    var cornerRadius: CGFloat? { get set }
    var height: CGFloat? { get set }
    var overlayCSS: FreeSpinsOverlayCSS? { get set }
    var pageControlCSS: FreeSpinsPageControlCSS? { get set }
    var gradientLeftColor: UIColor? { get set }
    var gradientMiddleColor: UIColor? { get set }
    var gradientRightColor: UIColor? { get set }
    var gradientOpacity: CGFloat? { get set }
}

public protocol FreeSpinsOverlayCSS: ViewCSS {
    
    var overlayCornerRadius: CGFloat? { get set }
    
    var headerBgColor: UIColor? { get set }
    var headerTitle: TextCSS? { get set }
    var headerSubTitle: TextCSS? { get set }
    var headerButton: ButtonCSS? { get set }
    var headerButtonCornerRadius: CGFloat? { get set }
    var headerButtonBorderColor: UIColor? { get set }
    var headerButtonBorderWidth: CGFloat? { get set }

    var winningsImageCornerRadius: CGFloat? { get set }
    var winningsTitle: TextCSS? { get set }
    var winningsAmountTitle: TextCSS? { get set }
    var spinsProgressBgColor: UIColor? { get set }
    var spinsProgressFillColor: UIColor? { get set }
    var totalSpinsTitle: TextCSS? { get set }
    var spinsLeftTitle: TextCSS? { get set }

    var eligibleGamesTitle: TextCSS? { get set }
    var footerDividerColor: UIColor? { get set }
    var ctaTitle: ButtonCSS? { get set }
}

public protocol FreeSpinsPageControlCSS {
    var dotsColor: UIColor? { get set }
    var selectedDotColor: UIColor? { get set }
}
