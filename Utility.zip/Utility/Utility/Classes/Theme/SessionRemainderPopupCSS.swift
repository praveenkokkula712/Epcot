//
//  SessionRemainderPopupCSS.swift
//  ConfigModule
//
//  Created by Gostu Bhargavi on 05/03/24.
//

import Foundation

public protocol SessionRemainderPopupCSS: ViewCSS {
    var containerViewBGColor: UIColor? {get set}
    var containerCornerRadius: CGFloat? {get set}
    var headerViewBGColor: UIColor? {get set}
    var headerTitle: TextCSS? {get set}
    var description: TextCSS? {get set}
    var linkTextColor: UIColor? {get set}
    var closeIconTintColor: UIColor? {get set}
    var okButton: ButtonCSS? {get set}
    var cancelButton: ButtonCSS? {get set}
    var cancelButtonBorderColor: UIColor? {get set}
    var cancelButtonBorderWidth: CGFloat? {get set}
    var buttonCornerRadius: CGFloat? {get set}
}

public struct DefaultSessionRemainderPopupCSS: SessionRemainderPopupCSS {
    
    public init() { }
    
    public var containerViewBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#000000")
    }()
    
    public var containerCornerRadius: CGFloat? = {
        4.0
    }()
    
    public var headerTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.systemFont(ofSize: 16))
    }()
    
    public var headerViewBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#000000")
    }()
    
    public var linkTextColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    public var closeIconTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var cancelButton: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 14)),
                         selected: UIColor.hexStringToUIColor(hex: "#333333").withAlphaComponent(0), normal: UIColor.hexStringToUIColor(hex: "#333333").withAlphaComponent(0))
    }()
    
    public var cancelButtonBorderColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var cancelButtonBorderWidth: CGFloat? = {
        1.0
    }()
    
    public var buttonCornerRadius: CGFloat? = {
        22.0
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.systemFont(ofSize: 14))
    }()
    
    public var okButton: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 14)),
                         selected: UIColor.hexStringToUIColor(hex: "#FFCC00"), normal: UIColor.hexStringToUIColor(hex: "#FFCC00"))
    }()
    
    public var okButtonCornerRadius: CGFloat? = {
        3.0
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#000000").withAlphaComponent(0.4)
    }()
}
