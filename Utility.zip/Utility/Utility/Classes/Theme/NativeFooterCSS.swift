//
//  NativeFooterCSS.swift
//  NativeFooter
//
//  Created by Praveen Kokkula on 23/10/20.
//

import Foundation

public protocol NativeFooterCSS:ViewCSS {
    
    var content:NFContentCSS? { get set }
    
    var copyRight:NFCopyrightCSS? { get set }
    
    var aboutUs:NFViewCSS? { get set }
    
    var seolinks: NFViewCSS? {get set}
    
    var brandLogoBGColor: UIColor? {get set}
    
    var logosBGColor: UIColor? {get set}
    
    var stateView: NFStateChangerViewCSS? {get set}
    
    var lineColor: UIColor? {get set}
    
    var footerTimerTextColor: UIColor? {get set}
    
    var footerTitleColor: UIColor? {get set}
}

public protocol FavoriteToasterViewCSS: ViewCSS {
    
    var viewCornerRadius: CGFloat? {get set}
    
    var title:TextCSS? { get set }
    
    var titleAttributed: TextCSS? { get set }
    
    var seeBtn: ButtonCSS? {get set}
    
    var shadowColor: UIColor? {get set}
    
}

public protocol NFViewCSS:ViewCSS {
    
    var header:TextCSS? { get set }
    
    var item:TextCSS? { get set }
}

public protocol NFCopyrightCSS: TextCSS,ViewCSS {
    
}

public protocol NFContentCSS: TextCSS,ViewCSS {
    
}

public protocol NFStateChangerViewCSS: ViewCSS {
 
    var title: TextCSS? {get set}
    
    var stateChangeBtnBorderColor: UIColor? {get set}
    
    var stateChangerBtn: TextCSS? {get set}
    
    var stateListViewBorderColor: UIColor? {get set}
    
    var stateChangeBtnSelectedBackgroundColor: UIColor? {get set}

    var stateSwitcherDropDownColor: UIColor? {get set}
    
    var stateSwitcherRadioButtonColor: UIColor? {get set}
    
    var stateListTitleColor: UIColor? {get set}
    
    var stateListBgColor: UIColor? {get set}
}
