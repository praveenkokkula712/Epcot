//
//  DefaultJackpotTilesViewCSS.swift
//  EpcotLobby
//
//  Created by Naresh Banavath on 01/07/24.
//

import Foundation

public struct DefaultJackpotTilesViewCSS: JackpotTilesViewCSS {
    
    public init() { }
    public var cornerRadius: CGFloat = 8.0
    public var badgeTitle: TextCSS? = {
         DefaultTextCSS(color: .white, font: .systemFont(ofSize: 12.0))
    }()
    public var badgeTitleBackgroundColor: UIColor?  = {
         UIColor.white.withAlphaComponent(0.28)
    }()
    public var badgeTitleCornerRadius: CGFloat? = {
        4.0
    }()
    public var title: TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 17, weight: .bold))
    }()
    public var description: TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 11))
    }()
    public var lastWin: TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 9, weight: .medium))
    }()
    public var gameImageCornerRadius: CGFloat? = 6.0
    public var viewGameBtn: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: .blue, font: .systemFont(ofSize: 11)), selected: .clear, normal: .clear)
    }()
    public var bottomViewBackgroundColor: UIColor? = .black.withAlphaComponent(0.25)
    
    //MARK:  DailyBottomView
    
    public var dailyBottomViewTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor(red: 0.95, green: 0.96, blue: 0.96, alpha: 1.0), font: .systemFont(ofSize: 14, weight: .medium))
    }()
    public var dailyBottomViewAmount: TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 28))
    }()
    public var dailyBottomViewTimeLeftLabel: TextCSS? = {
        DefaultTextCSS(color: UIColor(red: 0.95, green: 0.96, blue: 0.96, alpha: 1.0), font: .systemFont(ofSize: 11))
    }()
    public var dailyBottomViewHourAndMinuteTitleLabel:  TextCSS? = {
        DefaultTextCSS(color: UIColor(red: 0.95, green: 0.96, blue: 0.96, alpha: 1.0), font: .systemFont(ofSize: 9, weight: .medium))
    }()
    public var dailyBottomViewHourAndMinuteValues:  TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 14, weight: .medium))
    }()
    public var dailyBottomViewHourAndMinuteValuesBackgroundColor: UIColor? = .black.withAlphaComponent(0.2)
    public var dailyBottomViewBackgroundColor: UIColor? = UIColor(red: 0.46, green: 0.08, blue: 0.64, alpha: 1.0)
    public var dailyBottomViewStrokeColor: UIColor? = UIColor(red: 0.67, green: 0.36, blue: 0.85, alpha: 1.0)
    public var dailyStartingAtText: TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 11, weight: .bold))
    }()
    public var dailyStartingAtTime: TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 28))
    }()
    //MARK: ValueBottomView
    
    public var valueBottomViewTitle:  TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 11, weight: .bold))
    }()
    public var valueBottomViewAmount:  TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 13))
    }()
    public var valueBottomViewProgressColor: UIColor? = .green
    public var valueBottomViewProgressColorWhen90Percent: UIColor? = .red
    public var valueBottomViewMaxAmount:  TextCSS? = {
        DefaultTextCSS(color: UIColor(red: 0.95, green: 0.96, blue: 0.96, alpha: 1.0), font: .systemFont(ofSize: 11))
    }()
    public var valueBottomViewBackgroundColor: UIColor? = UIColor(red: 0.17, green: 0.33, blue: 0.25, alpha: 1.0)
    public var valueBottomViewStrokeColor: UIColor? = UIColor(red: 0.24, green: 0.43, blue: 0.34, alpha: 1.0)
    
    //MARK: ProgressiveBottomView
    
    public var progressiveBottomViewTitle:  TextCSS? = {
        DefaultTextCSS(color: UIColor(red: 0.95, green: 0.96, blue: 0.96, alpha: 1.0), font: .systemFont(ofSize: 13))
    }()
    public var progressiveBottomViewAmountText:  TextCSS? = {
        DefaultTextCSS(color: .white, font: .systemFont(ofSize: 28))
    }()
    public var progressiveBottomView_ViewGamesButton:  ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: .white, font: .systemFont(ofSize: 13)), 
                         selected: .white,
                         normal: .white.withAlphaComponent(0.28))
    }()
    public var progressiveBottomView_ViewGamesButtonCornerRadius: CGFloat? = 16.0
    public var progressiveBottomViewBackgroundColor: UIColor? = UIColor(red: 0.48, green: 0.38, blue: 0.19, alpha: 1.0)
    public var progressiveBottomViewStrokeColor: UIColor? = UIColor(red: 0.57, green: 0.47, blue: 0.26, alpha: 1.0)
    
}
