//
//  LossLimitReachedCSS.swift
//  Utility
//
//  Created by Bandana Choudhury on 30/06/22.
//

import Foundation
import UIKit

public protocol LossLimitReachedCSS: LossLimitCSS {
    
    var lobbyButton: ButtonCSS? {get set}
    var rgButton: ButtonCSS? {get set}
    var border: UIColor? {get set}

}

public protocol LossLimitCSS: ViewCSS {
    var containerBG: UIColor? {get set}
    var title: TextCSS? {get set}
    var body: TextCSS? {get set}
    var bodyAttribute: TextCSS? {get set}
}
