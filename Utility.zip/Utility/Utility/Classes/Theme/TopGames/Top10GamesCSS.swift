//
//  Top10GamesCSS.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 01/07/24.
//

import Foundation

public protocol Top10GamesCSS {
    var rankFont: UIFont? { get set }
    var rankOpacity: CGFloat? { get set }
    var rankHeight: CGFloat? { get set }
    var rankWidth: CGFloat? { get set }
    var tengthRankWidth: CGFloat? { get set }
    var rankGradientTopColor: UIColor? { get set }
    var rankGradientBottomColor: UIColor? { get set }
}
