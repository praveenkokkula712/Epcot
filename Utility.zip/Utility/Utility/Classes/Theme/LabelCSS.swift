//
//  LabelCSS.swift
//  Utility
//
//  Created by Challa Venkata Narasimha Karthik on 25/03/22.
//  Copyright © 2022 Ivy Comptech. All rights reserved.
//

import Foundation
import UIKit

public protocol LabelCSS: TextCSS {
    
    var backgroundColor: UIColor? { get set }
}

public struct DefaultLabelCSS: LabelCSS {
    
    public init() { }
    
    public var backgroundColor: UIColor? = UIColor.hexStringToUIColor(hex: "2b2b2b")
    
    public var color: UIColor? = UIColor.hexStringToUIColor(hex: "e9e9e9")
    
    public var font: UIFont? = UIFont.systemFont(ofSize: 12)
}


