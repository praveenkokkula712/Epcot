//
//  StickerCSS.swift
//  Utility
//
//  Created by Rajani Bhimanadham on 15/05/23.
//

import Foundation

public protocol StickerCSS: ViewCSS {
    var title: TextCSS? {get set}
    var backgroundColor: UIColor? {get set}
    var cornerRadius: CGFloat? {get set}
}
