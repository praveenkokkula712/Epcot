//
//  SessionLimitCSS.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 03/06/24.
//

import Foundation

public protocol SessionLimitCSS: ViewCSS {
    
    var popupBgColor: UIColor? { get set }
    var popupCornerRadius: CGFloat? { get set }

    var headerBgColor: UIColor? { get set }
    var headerTitle: TextCSS? { get set }
    
    var timeLimitText: TextCSS? { get set } // time text ::: 4
    var timeLimitTextNotation: TextCSS? { get set } // time text notation ::: hours/minutes
    var timeLimitTextView: RoundedViewCSS? { get set }

    var bodyText: TextCSS? { get set }
    
    var showAdjustLimitsButton: Bool { get set }
    
    var adjustLimitsButton: RoundedButtonCSS? { get set }
    var continueButton: RoundedButtonCSS? { get set }
}

public protocol RoundedViewCSS {
    var cornerRadius: CGFloat? { get set }
    var borderColor: UIColor? { get set }
    var borderWidth: CGFloat? { get set }
}

public protocol RoundedButtonCSS: ButtonCSS, RoundedViewCSS, ViewCSS { }
