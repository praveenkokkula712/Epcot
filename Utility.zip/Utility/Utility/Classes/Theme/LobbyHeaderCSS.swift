//
//  LobbyHeaderCSS.swift
//  Utility
//
//  Created by Gostu Bhargavi on 10/02/22.
//

import Foundation
import UIKit

public enum LobbyHeaderType: Int  {
    
    case gamesCategories, lobbyExploreSwitcher, wheelOfFortuneCategories, epcotCategoryPills
}

public protocol ExploreLobbyViewCSS: ViewCSS {

    var title: TextCSS? { get set }
    
    var categoriesTitle: TextCSS? { get set }
        
    var tintColor: UIColor? {get set}
    
    var switcherTintColor: UIColor? {get set}

}

public protocol LobbySwitcherPopupViewCSS: ViewCSS {

    var title: TextCSS? { get set }
        
    var tintColor: UIColor? {get set}
    
    var itemContainerBGColor: UIColor? {get set}

    var itemContainerCornerRadius: CGFloat? {get set}
    
    var cornerRadius: CGFloat? {get set}
    
}

public protocol LobbySwitcherItemCSS: ViewCSS {

    var titleNormal: TextCSS? { get set }
    
    var titleSelected: TextCSS? { get set }

    var contentHightedBGColor: UIColor? {get set}
    
    var tintColor: UIColor? {get set}

    var itemCornerRadius: CGFloat? {get set}

}

public protocol ExploreLobbyCategeroiesPopUpCSS: ViewCSS {

    var title: TextCSS? { get set }
    
    var categoryTitle: TextCSS? { get set }

    var cellTitleNormal: TextCSS? { get set }
    
    var cellTitleSelected: TextCSS? { get set }
    
    var applyButton:ButtonCSS? {get set}
    
    var tintColor: UIColor? {get set}
    
    var cellSeperatorColor: UIColor? {get set}

    var cornerRadius: CGFloat? {get set}
    
    var applyButtonCornerRadius: CGFloat? {get set}

}
