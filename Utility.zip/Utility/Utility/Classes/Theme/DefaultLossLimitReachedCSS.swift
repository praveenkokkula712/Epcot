//
//  DefaultLossLimitReachedCSS.swift
//  Utility
//
//  Created by Bandana Choudhury on 30/06/22.
//

import Foundation
import UIKit


public struct DefaultLossLimitReachedCSS: LossLimitReachedCSS {
    
    public init() {
        
    }
    
   public var containerBG: UIColor? = {
        return UIColor(red: 51/255, green: 51/255, blue: 51/255, alpha: 1.0)
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.white, font: UIFont.boldSystemFont(ofSize: 18))
    }()
    
    public var body: TextCSS? = {
        DefaultTextCSS(color: UIColor.white, font: UIFont.systemFont(ofSize: 14))
    }()
    
    public var bodyAttribute: TextCSS? = {
        DefaultTextCSS(color: UIColor.white, font: UIFont.boldSystemFont(ofSize: 14))
    }()
    
    public var lobbyButton: ButtonCSS? = {
        DefaultButtonCSS(
            title: DefaultTextCSS(color: UIColor.black,
                                  font: UIFont.boldSystemFont(ofSize: 16)),
                         selected: UIColor(red: 247/255, green: 206/255, blue: 24/255, alpha: 1.0),
                         normal: UIColor(red: 247/255, green: 206/255, blue: 24/255, alpha: 1.0))
    }()
    
    public var border: UIColor? = {
        return nil
    }()
    
    public var rgButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.black, font: UIFont.boldSystemFont(ofSize: 16)),
                         selected: UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0),
                         normal: UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.black
    }()
    
}
