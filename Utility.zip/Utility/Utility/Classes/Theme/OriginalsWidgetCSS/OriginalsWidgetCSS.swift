//
//  OriginalsWidgetCSS.swift
//  Utility
//
//  Created by Sindhuja Vedire on 05/09/24.
//

import Foundation

public protocol OriginalsWidgetCSS {
    
    // widgetCss
    var widgetTopViewBgColor1:  UIColor? { get set }
    var widgetTopViewBgColor2:  UIColor? { get set }
    var widgetBottomViewBgColor1:  UIColor? { get set }
    var widgetBottomViewBgColor2:  UIColor? { get set }
    var title : TextCSS? { get set }
    var description: TextCSS? { get set }
    var viewGamesCta: TextCSS? { get set }
    var rightArrowIconColor: UIColor { get set }
    var rightArrowIconSize: CGFloat? { get set }
    var seeDetailsCta: TextCSS? { get set }
    var seeDetailsCtaCornerRadius: CGFloat? { get set }
    var seeDetailsCtaBorderColor: UIColor? { get set }
    var seeDetailsCtaBorderWidth: CGFloat? { get set }
    var optInCta: TextCSS? { get set }
    var optInCtaBgColor: [UIColor]? { get set }
    var optInCtaCornerRadius: CGFloat? { get set }
    var optedInCta: TextCSS? { get set }
    var maximumPrizeText: TextCSS? { get set }
    var maximumPrizeValue: TextCSS? { get set }
    var timeLeftText: TextCSS? { get set }
    var timerComponentsBgColor: UIColor? { get set }
    var timerComponents: TextCSS? { get set }
    var timerComponentsCornerRadius: CGFloat? { get set }
    var seperatorColor: UIColor? { get set }
    var seperatorSize: CGFloat? { get set }
    var durationText: TextCSS? { get set }
    var originalsIconSize: CGFloat? { get set }
    var greenTickIconSIze: CGFloat? { get set }
    var greenTickIconColor: UIColor? { get set }
    
    // categoryOriginalsWidgetCss
    var widgetBackgoroundColor1: UIColor? { get set }
    var widgetBackgoroundColor2: UIColor? { get set }
    var mainTitle: TextCSS? { get set }
    var subTitle: TextCSS? { get set }
    var timerComponentsBackGroundColor: UIColor? { get set }
    var timeComponents: TextCSS? { get set }
    var timeComponentsCornerRadius: CGFloat? { get set }
    var timeDurationText: TextCSS? { get set }
    var widgetOveralyBGcolor: UIColor? { get set }
    var widgetOveralyCornerRadius: CGFloat? { get set }
    var widgetOverlayHeaderText: TextCSS? { get set }
    var widgetOverlayMaximumPrizeText: TextCSS? { get set }
    var widgetOverlayMaximumPrizeValue: TextCSS? { get set }
    var widgetOverlayOptInChancesText: TextCSS? { get set }
    
    
    // OverlayCss
    var overlayHeaderBgColor: UIColor? { get set }
    var overlayHeaderCornerRadius: CGFloat? { get set }
    var overlayBgColor: UIColor? { get set }
    var headerTitle: TextCSS? { get set }
    var closeBtnTitle: TextCSS? { get set }
    var closeBtnBorderColor: UIColor? { get set }
    var closeBtnBorderWidth: CGFloat? { get set }
    var closeBtnCornerRadius: CGFloat? { get set }
    var ticketsIconSize: CGFloat? { get set }
    var ticketsText: TextCSS? { get set }
    var timerIconSize: CGFloat? { get set }
    var expiresText: TextCSS? { get set }
    var inDaysText: TextCSS? { get set }
    var stepsTitleText: TextCSS? { get set }
    var stepNumberBorderColor: UIColor? { get set }
    var stepNumberBorderWidth: CGFloat? { get set }
    var verticalBarColor: UIColor? { get set }
    var verticalBarWidth: CGFloat? { get set }
    var dividerColor1: UIColor? { get set }
    var dividerColor2: UIColor? { get set }
    var stepNumber: TextCSS? { get set }
    var stepsDescription: TextCSS? { get set }
    var bonusIconSize: CGFloat? { get set }
    var additionalInfoText: TextCSS? { get set }
    var viewFullDetailsCta: TextCSS? { get set }
    var viewFullDetailsCtaBorderColor: UIColor? { get set }
    var viewFullDetailsCtaBorderWidth: CGFloat? { get set }
    var overalyOptInCta: TextCSS? { get set }
    var overlayOptedInCta: TextCSS? { get set }
}
