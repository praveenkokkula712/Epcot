//
//  SessionSettingsCSS.swift
//  Utility
//
//  Created by Gunnala Divya on 29/12/23.
//

import Foundation

public protocol SessionSettingCSS: ViewCSS {
    var header: TextCSS? {get set}
    var headerBgColor: UIColor? {get set}
    var headerIconInfoColor: UIColor? {get set}
    var rgButton: ButtonCSS? {get set}
    var playNowButton: ButtonCSS? {get set}
    var buttonsCornerRadius: CGFloat? {get set}
    var rgButtonBorderColor: UIColor? {get set}
    var rgButtonTintColor: UIColor? {get set}
    var rgButtonBorderWidth: CGFloat? {get set}
    var viewBGColor: UIColor? {get set}
    var question: TextCSS? {get set}
    var infoIconTintColor: UIColor? {get set}
    var subviewBGColor: UIColor? {get set}
    var subviewCornerRadius: CGFloat? {get set}
    var subviewBorderWidth: CGFloat? {get set}
    var subviewErrorColor: UIColor? {get set}
    var subviewErrorTextColor: TextCSS? {get set}
    var subViewHeaderTitle: TextCSS? {get set}
    var subViewSectionCornerRadius: CGFloat? {get set}
    var subviewSectionBGColor: UIColor? {get set}
    var subViewSectionBorderColor: UIColor? {get set}
    var accountBalanceCornerRadius: CGFloat? {get set}
    var accountBalanceBGColor: UIColor? {get set}
    var accountBalanceHeaderTitle: TextCSS? {get set}
    var accountBalanceValueTitle: TextCSS? {get set}
    var bonusSpinsTitle: TextCSS? {get set}
    var subViewValueCellCornerRadius: CGFloat? {get set}
    var subViewValueCellSelectedColor: UIColor? {get set}
    var subViewValueCellUnSelectedColor: UIColor? {get set}
    var cellTextSelectedColor: UIColor? {get set}
    var maxLossCellTextCSS: TextCSS? {get set}
    var maxTimeCellTextCSS: TextCSS? {get set}
    var maxLossCellSeperationColor: UIColor? {get set}
    var maxLossCellSeperationLineHeight: CGFloat? {get set}
    var sessionBreakCellSelectedColor: UIColor? {get set}
    var sessionBreakHeaderCellTextCSS: TextCSS? {get set}
    var breakTimeHeaderTextCSS: TextCSS? {get set}
    var breakTimeDescriptionTextCSS: TextCSS? {get set}
    var switchSelectedColor: UIColor? {get set}
    var switchUnSelectedColor: UIColor? {get set}
}

public struct DefaultSessionSettingCSS: SessionSettingCSS {
    
    public var headerBgColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var headerIconInfoColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var subviewErrorTextColor: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var switchUnSelectedColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var header: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var rgButton: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 14)),
                         selected: UIColor.hexStringToUIColor(hex: "#FFCC00"), normal: UIColor.hexStringToUIColor(hex: "#FFCC00"))
    }()
    
    public var playNowButton: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 14)),
                         selected: UIColor.hexStringToUIColor(hex: "#FFCC00"), normal: UIColor.hexStringToUIColor(hex: "#FFCC00"))
    }()
    
    public var buttonsCornerRadius: CGFloat? = {
        3.0
    }()
    
    public var rgButtonBorderColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var rgButtonTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var rgButtonBorderWidth: CGFloat? = {
        3.0
    }()
    
    public var viewBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var question: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var infoIconTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var subviewBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var subviewCornerRadius: CGFloat? = {
        3.0
    }()
    
    public var subviewBorderWidth: CGFloat? = {
        3.0
    }()
    
    public var subviewErrorColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var subViewHeaderTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var subViewSectionCornerRadius: CGFloat? = {
        3.0
    }()
    
    public var subviewSectionBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var subViewSectionBorderColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var accountBalanceCornerRadius: CGFloat? = {
        3.0
    }()
    
    public var accountBalanceBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var accountBalanceHeaderTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var accountBalanceValueTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var bonusSpinsTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var subViewValueCellCornerRadius: CGFloat? = {
        3.0
    }()
    
    public var subViewValueCellSelectedColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var subViewValueCellUnSelectedColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var cellTextSelectedColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#333333")
    }()
    
    public var maxLossCellTextCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var maxTimeCellTextCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var maxLossCellSeperationColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var maxLossCellSeperationLineHeight: CGFloat? = {
        3.0
    }()
    
    public var sessionBreakCellSelectedColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var sessionBreakHeaderCellTextCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var breakTimeHeaderTextCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var breakTimeDescriptionTextCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#333333"), font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var switchSelectedColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F5F5F5")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.white
    }()
    
    public init() { }
}
