//
//  PlayModeCSS.swift
//  Utility
//
//  Created by Sumeet Bajaj on 26/10/2020.
//

import Foundation
import UIKit

public protocol PlayModeCSS {
    
    var cellSkinColor: UIColor? { get set }
    
    var playButton: ButtonCSS? { get set }
    
    var gameTitle: TextCSS? {get set}
}
