//
//  DefaultToastersAndOverlaysCSS.swift
//  Utility
//
//  Created by Gostu Bhargavi on 21/03/23.
//

import Foundation

public struct DefaultToasterViewCss: ToastersViewCSS {
    public var containerShadowRadius: CGFloat? = {
        8.0
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.boldSystemFont(ofSize: 14))
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#ADADAD"), font: UIFont.systemFont(ofSize: 12))
    }()
        
    public var ctaButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.boldSystemFont(ofSize: 12)),
                         selected: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0),
                         normal: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0))
    }()
    
    public var containerBackgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#333333")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#333333")
    }()
    
    public var cornerRadius: CGFloat? = {
        16.0
    }()
    
    public var borderColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#191919")
    }()

    public var borderWidth: CGFloat? = {
        0.0
    }()
    
    public var titleBackgroundColor: UIColor? = {
        UIColor.clear
    }()
    
    public var descriptionBackgroundColor: UIColor? = {
        UIColor.clear
    }()

    public var imageCornerRadius: CGFloat? = {
        8.0
    }()
    
    public var imageShadowRadius: CGFloat? = {
        16.0
    }()
    
    public var imageShadowColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#000000").withAlphaComponent(0.12)
    }()
    
    public var ctaButtonBorderColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var ctaButtonBackgroundColor: UIColor? = {
        .clear
    }()
    
    public var ctaButtonCornerRadius: CGFloat? = {
        3.0
    }()
   
    public var containerShadowColor: UIColor? = {
        //Drop Shadow
        UIColor.hexStringToUIColor(hex: "#000000").withAlphaComponent(0.8)
    }()
    
    public init() {
        
    }
}

public struct DefaultOverlayViewCss: OverlaysViewCSS {
    public var cancelButtonBorderWidth: CGFloat? = {
        1.0
    }()
    
    public var cancelButtonCornerRadius: CGFloat? = {
        4.0
    }()
    
    public var cancelButtonBorderColor: UIColor? = {
        .white
    }()
    
    public var cancelButton: ButtonCSS? = {
        DefaultButtonCSS(title: DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.systemFont(ofSize: 12)), selected: .clear, normal: .clear)
    }()
    
    public var containerShadowRadius: CGFloat? = {
        8.0
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.boldSystemFont(ofSize: 14))
    }()
    
    public var description: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#ADADAD"), font: UIFont.systemFont(ofSize: 12))
    }()
        
    public var ctaButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont.boldSystemFont(ofSize: 12)),
                         selected: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0),
                         normal: UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0))
    }()
    
    public var containerBackgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#333333")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#333333")
    }()
    
    public var cornerRadius: CGFloat? = {
        16.0
    }()
    
    public var borderColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#191919")
    }()

    public var borderWidth: CGFloat? = {
        0.0
    }()
    
    public var titleBackgroundColor: UIColor? = {
        UIColor.clear
    }()
    
    public var descriptionBackgroundColor: UIColor? = {
        UIColor.clear
    }()

    public var imageCornerRadius: CGFloat? = {
        8.0
    }()
    
    public var imageShadowRadius: CGFloat? = {
        16.0
    }()
    
    public var imageShadowColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#000000").withAlphaComponent(0.12)
    }()
    
    public var ctaButtonBorderColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var ctaButtonBackgroundColor: UIColor? = {
        .clear
    }()
    
    public var ctaButtonCornerRadius: CGFloat? = {
        3.0
    }()
   
    public var containerShadowColor: UIColor? = {
        //Drop Shadow
        UIColor.hexStringToUIColor(hex: "#000000").withAlphaComponent(0.8)
    }()
    
    public var overlayBackgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#000000").withAlphaComponent(0.5)
    }()
    
    public init() {
        
    }
}
