//
//  DefaultLossLimitInterceptorCSS.swift
//  Utility
//
//  Created by Bandana Choudhury on 01/07/22.
//

import Foundation
import UIKit


public struct DefaultLossLimitInterceptorCSS: LossLimitInterceptorCSS {
    
    public init() {
        
    }
    
   public var containerBG: UIColor? = {
       return UIColor.black
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.white, font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var body: TextCSS? = {
        DefaultTextCSS(color: UIColor.white, font: UIFont.systemFont(ofSize: 15))
    }()
    
    public var bodyAttribute: TextCSS? = {
        DefaultTextCSS(color: UIColor.white, font: UIFont.boldSystemFont(ofSize: 15))
    }()
    
    public var continueButton: ButtonCSS? = {
        DefaultButtonCSS(
            title: DefaultTextCSS(color: UIColor.white,
                                  font: UIFont.systemFont(ofSize: 15)),
            selected: UIColor.clear,
            normal: UIColor.clear)
    }()
    
    public var closeButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.white, font: UIFont.systemFont(ofSize: 15)),
                         selected: UIColor.clear,
                         normal: UIColor.clear)
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.black
    }()
    
}
