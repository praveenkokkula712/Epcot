//
//  DialogViewCSS.swift
//  Utility
//
//  Created by Challa Venkata Narasimha Karthik on 25/03/22.
//  Copyright © 2022 Ivy Comptech. All rights reserved.
//

import UIKit

public protocol DialogViewCSS: ViewCSS {
    
    var title: TextCSS? { get set }
    
    var body: TextCSS? { get set }
    
    var bodyAttribute: TextCSS? { get set }
    
    var continueButton: DialogButtonCSS? { get set }
    
    var leaveButton: DialogButtonCSS? { get set }
    
    var okButton: DialogButtonCSS? { get set }
    
    var cornerRadius: CGFloat? { get set }
    
    var timerLabelCSS: LabelCSS? { get set }
    
    var progressBarCSS: ProgressBarCSS? { get set }
    
    var takeBreakButtonBackgroundColor: UIColor? { get set }
}

public struct DefaultDialogViewCSS: DialogViewCSS {
    
    public init() { }
    
    public var backgroundColor: UIColor? = UIColor.hexStringToUIColor(hex: "ffffff")
    
    public var takeBreakButtonBackgroundColor: UIColor? = UIColor.hexStringToUIColor(hex: "#00ffff")
    
    public var title: TextCSS? = DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "2b2b2b"),
                                                font: UIFont.boldSystemFont(ofSize: 16))
    
    public var body: TextCSS? = DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "2b2b2b"),
                                               font: UIFont.systemFont(ofSize: 14))
    
    public var bodyAttribute: TextCSS? = DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "2b2b2b"),
                                               font: UIFont.boldSystemFont(ofSize: 14))
    
    public var continueButton: DialogButtonCSS? = DefaultDialogButtonCSS()
    
    public var leaveButton: DialogButtonCSS? = DefaultDialogButtonCSS()
    
    public var okButton: DialogButtonCSS? = DefaultDialogButtonCSS()
    
    public var cornerRadius: CGFloat? = 4.0
    
    public var timerLabelCSS: LabelCSS? = DefaultLabelCSS()
    
    public var progressBarCSS: ProgressBarCSS? = DefaultProgressBarCSS()
}
