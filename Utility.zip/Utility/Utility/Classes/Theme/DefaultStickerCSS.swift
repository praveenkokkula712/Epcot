//
//  DefaultStickerCSS.swift
//  Utility
//
//  Created by Rajani Bhimanadham on 15/05/23.
//

import Foundation

public struct DefaultStickerCSS: StickerCSS {
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#050505"), font: UIFont.boldSystemFont(ofSize: 11))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#D6BC68", withAlpha: 0.3)
    }()
    
    public var cornerRadius: CGFloat? = {
        4.0
    }()
    public init() {
        
    }
}
