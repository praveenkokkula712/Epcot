//
//  SubNavigationViewCss.swift
//  CasinoAPI
//
//  Created by Praveen Kokkula on 06/07/22.
//

import Foundation

public struct SubNavigationViewCss {
    public let selectedBgColor: UIColor?
    public let backgroundColor: UIColor?
    
    public init(selectedBgColor: UIColor? = nil,
         backgroundColor: UIColor? = nil) {
        self.selectedBgColor = selectedBgColor
        self.backgroundColor = backgroundColor
    }
}
