//
//  SubNavigationItemTextCss.swift
//  CasinoAPI
//
//  Created by Praveen Kokkula on 06/07/22.
//

import Foundation

public struct SubNavigationItemTextCss {
    public let titleNormalColor: UIColor?
    public let titleSelectedColor: UIColor?
    
    public init(titleNormalColor: UIColor? = nil,
         titleSelectedColor: UIColor? = nil) {
        self.titleNormalColor = titleNormalColor
        self.titleSelectedColor = titleSelectedColor
    }
}
