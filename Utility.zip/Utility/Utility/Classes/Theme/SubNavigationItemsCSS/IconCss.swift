//
//  IconCss.swift
//  CasinoAPI
//
//  Created by Praveen Kokkula on 06/07/22.
//

import Foundation

public struct IconCss {
    public let nativeIcon: String?
    public let selectedNativeIcon: String?
    public let nativeIconColor: UIColor?
    public let selectedNativeIconColor: UIColor?
    public let colouredIconUrl: String?
    public let selectedColouredIconUrl: String?
    public let searchPageIconUrl: String?

    public init(nativeIcon: String? = "",
                selectedNativeIcon: String? = "",
                nativeIconColor: UIColor? = nil,
                selectedNativeIconColor: UIColor? = nil,
                colouredIconUrl: String? = nil,
                selectedColouredIconUrl: String? = nil,
                searchPageIconUrl: String? = nil) {
        self.nativeIcon = nativeIcon
        self.selectedNativeIcon = selectedNativeIcon
        self.nativeIconColor = nativeIconColor
        self.selectedNativeIconColor = selectedNativeIconColor
        self.colouredIconUrl = colouredIconUrl
        self.selectedColouredIconUrl = selectedColouredIconUrl
        self.searchPageIconUrl = searchPageIconUrl
    }
}
