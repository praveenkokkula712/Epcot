//
//  DefaultMonthlySummaryPopUpViewCSS.swift
//  Utility
//
//  Created by Bandana Choudhury on 18/09/22.
//

import Foundation
import UIKit

public struct DefaultMonthlySummaryPopUpViewCSS: MonthlySummaryPopUpViewCSS {
    
    public init() {}
    
    public var containerBG: UIColor? = {
        return UIColor.black
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.white, font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var body: TextCSS? = {
        DefaultTextCSS(color: UIColor.white, font: UIFont.systemFont(ofSize: 13))
    }()
    
    public var okButton: ButtonCSS? = {
        DefaultButtonCSS(
            title: DefaultTextCSS(color: UIColor.black,
                                  font: UIFont.boldSystemFont(ofSize: 14)),
            selected: UIColor(red: 247/255, green: 206/255, blue: 24/255, alpha: 1.0),
            normal: UIColor(red: 247/255, green: 206/255, blue: 24/255, alpha: 1.0))
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.black
    }()
    
}
