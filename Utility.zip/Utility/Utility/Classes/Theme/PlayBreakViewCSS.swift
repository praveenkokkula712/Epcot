//
//  PlayBreakViewCSS.swift
//  Utility
//
//  Created by Naresh Banavath on 10/04/24.
//

import Foundation
public protocol PlayBreakViewCSS {
    
    /// - Background Colors
    var overlayBgColor: UIColor? { get set }
    var contentBgColor: UIColor? { get set }
    
    /// - Title & Description
    var title : TextCSS? { get set }
    var titleHeaderBgColor : UIColor? { get set }
    var description : TextCSS? { get set }
    
    /// - Buttons
    var moreInfoButton : ButtonCSS? { get set }
    var okButton : ButtonCSS? { get set }
    var okButtonCornerRadius : CGFloat? { get set }
    
    ///Toaster
    var toasterText: TextCSS? { get set }
    
    /// Timer
    var timerText: TextCSS? { get set }
    var timerBgColor: UIColor? { get set }
    
    /// LSL
    var lslCloseButtonColor: UIColor? {get set}
    var lslContentViewBGColor: UIColor? {get set}
    var lslButtonTextColor: UIColor? {get set}
    var hardInterceptorMoreInfo: ButtonCSS? {get set}
    var fontName: String? { get set }
    var fontSize: CGFloat? { get set }
}
