//
//  LobbyCSS.swift
//  CasinoLobby
//
//  Created by Sumeet Bajaj on 05/02/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import Foundation
import UIKit

public enum LobbyType: Int  {
    case listView, gridView, gridLayoutV3, listLayoutV2, epcotLobby
}

public protocol LobbyTitleCSS: ViewCSS {
    
    var searchIconColor: UIColor? {get set}
    
    var title: TextCSS { get set }

    var searchPlacehoder: TextCSS {get set}
    
    var searchText: TextCSS {get set}
    
    var searchBarLayerColor: UIColor? {get set}
    
    var searchBarBGColor: UIColor? {get set}
}

public protocol LobbyNavigationCSS: ViewCSS {
    
    var buttonCSS: ButtonCSS? { get set }
    
    var shadowColor: UIColor? { get set }
}

public protocol LobbyGameCellCSS {
    
    var cellSkinColor: UIColor? { get set }
    
    var playButton: ButtonCSS? { get set }
    
    var favouriteButton: ButtonCSS? {get set}
    
    var priceTag: TextCSS? { get set }
    
    var gameTitle: TextCSS? {get set}
    
    var sticker: TextCSS? {get set}
    
    var downloadButton: ButtonCSS? { get set }
    
    var downloadButtonBorderColor: UIColor? { get set }
   
    var favouriteButtonIconSelected: String? {get set}
    
    var favouriteButtonIconUnselected: String? {get set}
    
    var favouriteButtonTintColor: UIColor? { get set }
    
    var favouriteButtonBackgroundColor: UIColor? { get set }
    
    var speakerButtonTintColor: UIColor? { get set }
    
    var speakerButtonBackgroundColor: UIColor? { get set }
    
    var speakerButtonCornerRadius: CGFloat? {get set}
    
}

public protocol LobbyUtilCSS: ViewCSS {
    
    var moreGamesTitle: TextCSS? { get set }
    
    var exploreButton: ButtonCSS {get set}
}

public protocol LobbySuggestionCSS: ViewCSS {
    
    var contentBGColor: UIColor? {get set}
    
    var title: TextCSS? { get set }
    
    var resultTitle: TextCSS? {get set}
    
    var hintTitle: TextCSS? {get set}
    
    var searchIconColor: UIColor? {get set}
    
    var shadowColor: UIColor? {get set}
    
    var resultViewBgColor: UIColor? {get set}
    
}

public protocol LobbySearchContentCSS: ViewCSS {
    
    var layerColor: UIColor? {get set}
    
    var backIconColor: UIColor? {get set}
    
    var clearIconColor: UIColor? {get set}
    
    var searchMicIcon: UIColor? {get set}
    
    var searchContainerBGColor: UIColor? {get set}
    
    var searchContainerTitleColor: UIColor? {get set}
    
    var searchParentContainerBGColor: UIColor? {get set}
    
    var searchPlaceHolderFont: TextCSS? {get set}
    
    var menuButtonFont: ButtonCSS? {get set}
    
    var menuButtonCornerRadius: CGFloat? {get set}
    
    var menuButtonBgColor: UIColor? {get set}
    
    var menuButtonContainerBgColor: UIColor? {get set}
}

public protocol SearchInputAccessoryViewCSS: ViewCSS {
    
    var bottomSearchButtonBgColor: UIColor? {get set}
    
    var bottomSearchButtonTitle: TextCSS? {get set}
    
    var bottomSearchIconTintColor: UIColor? {get set}
    
    var searchInputHeaderBgColor: UIColor? {get set}
    
    var searchInputHeaderBackButtonTintColor: UIColor? {get set}
    
    var searchInputHeaderTitleColor: UIColor? {get set}
    
    var searchInputContainerViewBgColor: UIColor? {get set}
    
    var searchInputHeaderTitleFont: TextCSS? {get set}
    
    var searchInputTextFieldFont: TextCSS? {get set}
    
    var searchButtonTintColor: UIColor? {get set}
    
    var micButtonTintColor: UIColor? {get set}
    
    var micButtonHightedTintColor: UIColor? {get set}
    
    var searchFieldCornerRadius: CGFloat? {get set}
    
    var searchInputPlaceHolderTextColor: UIColor? {get set}
    
    var searchInputTextfieldBgColor: UIColor? {get set}
}

public protocol RecentlyPlayedViewCSS: ViewCSS {
    
    var title: TextCSS? {get set}
    
    var seeMoreTitle: TextCSS? {get set}
    
    var backgroundColor: UIColor? {get set}
    
    var shadowColor: UIColor? {get set}
    
    var infoButtonTintColor: UIColor? {get set}
    
    var descriptionTextColor: TextCSS? {get set}
}


public protocol HeaderCell: TextCSS, ViewCSS {
    
}

public protocol NoDataView: TextCSS,ViewCSS {
    var iconColor: UIColor? {get set}
}

public protocol LobbyFilterHeaderView: ViewCSS {
    
    var filterHeaderTitle: TextCSS? {get set}
    
    var filterHeaderClose: ButtonCSS? {get set}
    
}

public protocol LobbyFilterButtonCSS: ButtonCSS, ViewCSS {
    
    var buttonBorderColor: UIColor? {get set}
    
}

public protocol LobbyFilterView: ViewCSS {
    
    var showBtn: LobbyFilterButtonCSS? {get set}
    
    var clearBtnIn: LobbyFilterButtonCSS? {get set}

    var filterBtn: LobbyFilterButtonCSS? {get set}
    
    var clearBtnOut: LobbyFilterButtonCSS? {get set}
    
    var headerView: LobbyFilterHeaderView? {get set}
    
    var filterItem: TextCSS? {get set}
    
    var checkmarkColor: UIColor? {get set}
    
}


public protocol LobbyCSS {
    
    // CSS for search and title on lobby
    var titleView : LobbyTitleCSS? { get set }
    
    // CSS for search and title on lobby
    var bingoWidgetViewCss : BingoWidgetCSS? { get set }
    
    // CSS for user selection navigation bar e.g All Games, Recently/Favorite buttons.
    var navigationView : LobbyNavigationCSS? { get set }
    
    // CSS for main lobby games container view/ table View/ Page view
    var gamesContainerView : ViewCSS? { get set }
    
    // CSS for footer view on Recently/Fav screens having explore more games options
    var utilView : LobbyUtilCSS? { get set }
    
    // CSS for search suggestion view displaying categories
    var suggestionView: LobbySuggestionCSS? { get set }
    
    // CSS for game cell displays image and meta data of Game
    var gamesCell: LobbyGameCellCSS? { get set }
    
    var type : LobbyType! { get set }
    
    // Lobby HeaderView type for explore and categories header
    var lobbyheaderViewType : LobbyHeaderType? { get set }
    
    // CSS for exploreLobby switcher view title/togle icon
    var exploreLobbyView: ExploreLobbyViewCSS? {get set}
    
    //CSS for lobbySwitcher popupView title/backgroundColor
    var lobbySwitcherPopupView: LobbySwitcherPopupViewCSS? {get set}
    
    //CSS for lobbySwitcher popupViewItem grid/list
    var lobbySwitcherItemView: LobbySwitcherItemCSS? {get set}
    
    //CSS for lobby explore games popupViewItem grid/list
    var exploreCategoriesPoppUpView: ExploreLobbyCategeroiesPopUpCSS? {get set}
    
    // CSS for header view on Recently/Fav screens
    var headerCell: HeaderCell? { get set }
    
    // CSS for no fav/recently played cell
    var noGameDataCell: TextCSS? {get set}
    
    // CSS for not data available on search
    var noDataView: NoDataView? {get set}
    
    // CSS for search view displays textfield/ back icon / clear icon
    var searchView: LobbySearchContentCSS? {get set}
    
    // CSS for search input accessory View
    var searchInputAccessoryViewCSS: SearchInputAccessoryViewCSS? {get set}
    
    // CSS for recently played view
    var recentlyPlayedView: RecentlyPlayedViewCSS? {get set}
    
    // CSS for grid view header color
    var gridView: LobbyGridView? {get set}
    
    // CSS for filterview
    var filterView: LobbyFilterView? {get set}
    
    var lobbyCornerRadius: CGFloat? {get set}
    
    var buttonCornerRadius: CGFloat? {get set}
    
    var imageCornerRadius: CGFloat? {get set}
    
    var favouritesIconFontSize: CGFloat?  {get set}
    
    var footerDownArrowIconFontSize: CGFloat? {get set}
    
    var footerRadioButtonIconFontSize: CGFloat? {get set}
    
    var imageFolderPathJson: [String: Any]? { get set }
    
    var immersiveImagePathJson: [String: Any]? { get set }
    
    // CSS for EpcotLobby
    var epcotLobbyCSS: EpcotLobbyCSS? { get set }
    
    var shimmerViewCSS: ShimmerViewCSS? { get set }
    
    var fallback:FallbackCSS? { get set }
    
    var rcpUK: RcpUKCSS? { get set }
    
    var easyNavigation: EasyNavigationCSS? { get set }
    
    var dialogViewCSS: DialogViewCSS? { get set }
    
    var longSessionBreakToastViewCSS: TakeAPlayBreakToastViewCSS? { get set }
    
    var longSessionBreakSetUpViewCSS: LongSessionBreakSetUpViewCSS? { get set }
    
    var longSessionBreakConfirmationViewCSS: LongSessionBreakConfirmationViewCSS? { get set }
    
    var germanRegulatory: GermanRegulatoryCSS? {get set}
    
    var greeceLimits: LimitsCSS? {get set}
    
    //Jackpot Widgets
    var jackpotWidgets: JackpotWidgetsCSS? {set get}
    
    var seeMoreSectionView: SeeMoreSectionViewCss? {get set}
    
    var downloadingView: DownloadingViewCSS? {get set}
        
    var jackpotFusionPopUpViewCSS: JackpotFusionInfoViewCSS? {get set}
    
    //Native footer CSS
    var nativeFooterViewCSS: NativeFooterCSS? {get set}
    
    var categoriesIconFontSize: CGFloat? {get set}
    
    var bingoButtonCSS: BingoButtonCSS? {get set}
    
    var favoriteToasterViewCSS: FavoriteToasterViewCSS? {get set}
    //CSS for Toaster
    var toasterViewCSS: ToastersViewCSS? {get set}
    
    //CSS for Overlays
    var overlaysViewCSS: OverlaysViewCSS? {get set}
    
    //User Onboarding Journey CSS
    var onboardingViewCSS: OnbordingViewCSS? {get set}
    
    //PlayBreak CSS
    var playBreakViewCSS : PlayBreakViewCSS? {get set}
    
    //JackpotTiles CSS
    var jackpotTilesViewCSS: JackpotTilesViewCSS? { get set }
    
    //CSS for Sticker
    var stickerCSS: StickerCSS? {get set}
    
    var gameStoriesCSS: GameStoriesCSS? {get set}
        
    var gameStoryItemsCSS: GameStoryItemsCSS? { get set }
    
    // Search V2
    var searchV2CSS: SearchV2CSS? { get set }
    
    //CSS for gamePremiere
    var gamePremiereCSS: GamePremiereCSS? { get set }

    // Free Spins CSS
    var freeSpinsCSS: FreeSpinsCSS? { get set }

    // Top 10 Games CSS
    var top10GamesCSS: Top10GamesCSS? { get set }    
    
    // Player stats CSS
    var playerStatsWidgetCSS: PlayerStatsWidgetCSS? { get set }
    //session limit pop up css
    var sessionLimitCss: SessionLimitCSS? { get set }
    
    var originalsWidgetCSS: OriginalsWidgetCSS? { get set }
    // Engagement Tools CSS
    var engagementToolsCSS: EngagementToolsCSS? { get set }
}

public protocol SliderLobbyCSS {
    
    var rcpViewCSS: RcpUKCSS? { get set }
    
    var easyNavigation: EasyNavigationCSS? { get set }

    var sessionSettingViewCSS: SessionSettingCSS? { get set }
    
    var sessionSettingsPopupCSS: SessionSettingsPopupCSS? {get set}
    
    var sessionRemainderPopupCSS: SessionRemainderPopupCSS? {get set}
    
    var quickGamesPopupCSS: QuickGamesPopupCSS? {get set}
}
    
public protocol DownloadingViewCSS: ViewCSS {
    var cancelButton: ButtonCSS? {get set}
    var gametitle: TextCSS? {get set}
    var progressTitle: TextCSS? {get set}
    var progressTintColor: UIColor? {get set}
}

public protocol BingoButtonCSS: ViewCSS {
    var titleCss: TextCSS? {get set}
    var cornerRadius: CGFloat? {get set}
}

public protocol SeeMoreSectionViewCss: ViewCSS {
    var backButtontint: UIColor? {get set}
    var title: TextCSS? {get set}
    var headerTitle: TextCSS? {get set}
    var headerPrice: TextCSS? {get set}
    var switcherSelectedColor: UIColor? {get set}
    var collectionViewBGColor: UIColor? {get set}
    var shadowColor: UIColor? {get set}
    var titleViewBackgroundColor: UIColor? {get set}
    var switcherUnselectedColor: UIColor? {get set}
}

public protocol LobbyGridView: ViewCSS {
    
    var header: GridHeader? {get set}
    
    var categoryView: CategoryView? {get set}
    
    var jpView: JPView? {get set}
    
    var myGames: MyGamesView? {get set}
    
    var searchBanner: GridSearchBanner? {get set}
    
    var categoryViewbackgroundColor: UIColor? {get set}
    
    var gridViewbackgroundColor: UIColor? {get set}
    
}

public protocol GridSearchBanner: ViewCSS {
    
    var findText: TextCSS? {get set}
    
    var noSuccess: TextCSS? {get set}
    
    var searchNow: ButtonCSS? {get set}
    
    var searchBorder: UIColor? {get set}
    
}

public protocol GridHeader: ViewCSS {
    
    var title: TextCSS? {get set}
    
    var readyToPlay: TextCSS? {get set}
    
    var myGames:ButtonCSS? {get set}
    
    var searchIconColor: UIColor? {get set}
    
    var mygamesBorderColor: UIColor? {get set}
    
}

public protocol CategoryView: ViewCSS {
    
    var selected: TextCSS? {get set}
    
    var normal: TextCSS? {get set}
    
    var titleNormalColor: UIColor? {get set}
    
    var separatorLineColor: UIColor? {get set}
    
}

public protocol JPView {
    
    var priceAmount: TextCSS? {get set}
    
    var listPriceAmount: UIFont? {get set}
    
    var jpBGColor: UIColor? {get set}
    
}

public protocol MyGamesView: ViewCSS {
    
    var mygames: TextCSS? {get set}
    
    var close: TextCSS? {get set}
    
    var pullView: UIColor? {get set}
    
    var noGames: TextCSS? {get set}
    
    var exploreGames: ButtonCSS? {get set}
    
    var pickGames: TextCSS? {get set}
    
    var containerViewColor: UIColor? {get set}
    
}

public protocol EpcotLobbyCSS: ViewCSS {
    
    var menuViewCSS: EpcotMenuViewCSS? {get set}
    
    var teasersViewCSS: EpcotTeasersCSS? {get set}
    
    var menuViewTitle: TextCSS? {get set}
    
    var menuViewBGColor: UIColor? {get set}
    
    var menuIconFontSize: CGFloat? {get set}
    
    var searchViewTitle: TextCSS? {get set}
    
    var searchViewBGColor: UIColor? {get set}
    
    var searchMenuContainerViewBGColor: UIColor? {get set}
    
    var searchMenuIconFontSize: CGFloat? {get set}
    
    var categoriesPillTitle: TextCSS? {get set}
    
    var categoriesPillBorderColor: UIColor? {get set}
    
    var categoriesViewBGColor: UIColor? {get set}
    
    var gameCollectionViewBGColor: UIColor? {get set}
    
    var shimmerGradients: ShimmerGradients? {get set}
    
    var categoriesSelectedPillTitle: TextCSS? {get set}

    var categoriesSelectedViewBGColor: UIColor? {get set}
    
    var categoriesPillsIconFontSize: CGFloat? {get set}
    
    var jackpotViewBackgroundColor: UIColor? {get set}
    
    var jackpotViewLayerBackgroundColor: UIColor? {get set}
    
    var pageControllerDotsColor: UIColor? {get set}

    var pageControllerDotSelectedColor: UIColor? {get set}

    var epcotSearchViewCSS: EpcotSearchContentCSS? {get set}
        
    var realityCheckAlertTextColor: UIColor? {get set}

    var fallbackPopOverTextColor: UIColor? {get set}

    var fallbackPopOverCloseButtonColor: UIColor? {get set}

    var customAlertTitleColor: UIColor? {get set}

    var epcotGradientButtonColor: UIColor? {get set}
    
    var epcotSecondaryButtonTitleColor: UIColor? {get set}
    
    var epcotButtonTitleFont: UIFont? { get set }
    
    var epcotViewBorderColor: UIColor? {get set}
        
    var epcotMenuButtonBorderColor: UIColor? {get set}
    
    var epcotMandortyUpdateButtonColors1: UIColor? {get set}
    
    var epcotMandortyUpdateButtonColors2: UIColor? {get set}
    
    var epcotPopUpBgColor: UIColor? {get set}

    var epcotPopUpHeaderBgColor: UIColor? {get set}
    
    var epcotCloseButtonColor: UIColor? {get set}
    
    var epcotBodyTextColor: UIColor? {get set}
    
    var epcotTitleFont: UIFont? {get set}
    
    var epcotBodyFont: UIFont? {get set}
    
    var epcotPopupMessageFont: UIFont? {get set}
    
    var isEpcotFeatureEnabled: Bool? {set get}
    
    var immersiveCSS: ImmersiveCSS? {set get}
    
    var categoryGameCountCSS: CategoryGameCountCSS? {set get}
    
    var epcotTextColor: UIColor? {get set}

    var categoryHeaderCloseIconColor: UIColor? {get set}
    
    var liveFeedCSS: LiveFeedCSS? { get set }
}

public protocol CategoryGameCountCSS: ViewCSS {
    
    var categoryGamesCountTitle: TextCSS? {get set}
    
    var categoryGamesCountCornerRadius: CGFloat? {get set}
    
}

public protocol EpcotMenuViewCSS: ViewCSS {
    
    var headerBGColor: UIColor? {get set}
    
    var headerCornerRadius: CGFloat? {get set}
    
    var headerTitle: TextCSS? {get set}

    var doneTitle: TextCSS? {get set}
    
    var sectionHeaderTitle: TextCSS? {get set}
    
    var categoriesListTitle: TextCSS? {get set}
    
    var seperatorLineColour: UIColor? {get set}
    
    var arrowColour: UIColor? {get set}
    
    var appAdsBGColor: UIColor? {get set}
    
    var appAdsTitle: TextCSS? {get set}
    
    var appAdsDescription: TextCSS? {get set}
    
}

public protocol EpcotTeasersCSS {
    
    var title: TextCSS? {get set}
    
    var ipadTitle: TextCSS? {get set}

    var titleRegularFont: UIFont? { get set }
    
    var iPadtitleRegularFont: UIFont? { get set }

    var subTitle: TextCSS? {get set}
    
    var ctaButton: ButtonCSS? {get set}
    
    var teaserBGColor: UIColor? {get set}
    
    var embeddedBannerBGColor: UIColor? {get set}
    
    var teaserCornerRadius: CGFloat? {get set}
    
    var termsBackgroundColor: UIColor? {get set}

    var termsTextColor: UIColor? {get set}

    var termsTextFont: UIFont? {get set}
}


public protocol EpcotSearchContentCSS: ViewCSS {
    
    var headerTitle: TextCSS? { get set }

    var headerButtonCSS: ButtonCSS? { get set }
    
    var headerBackgroundColor: UIColor? { get set }
    
    var searchText: TextCSS? { get set }
        
    var clearIconColor: UIColor? {get set}
    
    var micIconColor: UIColor? {get set}
    
    var nodataTitle: TextCSS? {get set}
    
    var nodataBackgroundColor: UIColor? {get set}
    
    var suggestionsBackgroundColor: UIColor? {get set}
}

public protocol ShimmerViewCSS: ViewCSS {
    
    var borderColor: UIColor? {get set}
    
    var cornerRadius: CGFloat? {get set}

    var gradients: ShimmerGradients? {get set}
}

public protocol ImmersiveCSS {
    
    var portraitSectionCSS: TextCSS? {get set}

    var downloadIconBGColor: UIColor? {set get}
    
    var downloadIconCornerRdius: CGFloat? {set get}
}

public protocol FallbackCSS:ViewCSS {
    
    var fallbackDecription: TextCSS? {get set}
    
    var playButton: ButtonCSS? {get set}
    
    var headerTitle: TextCSS? {get set}
    
    var headerClose: ButtonCSS? {get set}
    
    var playMode: PlayModeCSS? {get set}

    var gameImagePath: String? {get set}
}

public protocol JackpotWidgetsCSS {
    
    var mustGoJackpot: MustGoJackpotWidgetsCSS? {get set}

    var singleJackpot: JackpotTextCSS? {get set}
    
    var widgetSelectedColor: UIColor? {get set}
    
    var widgetNormalColor: UIColor? {get set}
    
    var navigationArrowTintColor: UIColor? {get set}
    
    var widgetDecoratorBackgroundColor: UIColor? {get set}
    
    var multipleWidgetsDecoratorBackgroundColor: UIColor? {get set}

    var mustGoWidgetDecoratorBackgroundColor: UIColor? {get set}
    
    var singleJackpotHeaderCss: RecentlyPlayedViewCSS? {get set}
    
    var multipleJackpotsHeaderCss: RecentlyPlayedViewCSS? {get set}
    
    var mustGoJackpotHeaderCss: RecentlyPlayedViewCSS? {get set}
}

public protocol MustGoJackpotWidgetsCSS: JackpotTextCSS {
        
    var borderColor: UIColor? {set get}

    var borderWidth: CGFloat? {set get}

    var cornerRadius: CGFloat? {set get}
}

public protocol JackpotTextCSS: ViewCSS {
    
    var title: TextCSS? {get set}
    
    var price: TextCSS? {get set}
        
}

public protocol JackpotFusionInfoViewCSS: ViewCSS {
    
    var jackpotFusionInfoViewBackgroundColor: UIColor? { get set }
    
    var jackpotFusionInfoViewContentBackgroundColor: UIColor? { get set }

    var jackpotFusionInfoViewHeaderBackgroundColor: UIColor? { get set }

    var jackpotFusionInfoViewHeaderTitle: TextCSS? { get set }

    var jackpotFusionInfoViewCloseButtonCSS: ButtonCSS? { get set }
    
    var jackpotFusionInfoViewCloseButtonBorderColor: UIColor? { get set }
    
    var jackpotFusionInfoViewCloseButtonBorderWidth: CGFloat? {set get}
    
    var jackpotFusionInfoViewCloseButtonCornerRadius: CGFloat? {set get}
    
    var jackpotFusionInfoViewSeeallButtonCSS: ButtonCSS? { get set }
    
    var jackpotFusionInfoViewSeeallButtonBorderWidth: CGFloat? {set get}
    
    var jackpotFusionInfoViewSeeallButtonCornerRadius: CGFloat? {set get}

    var jackpotFusionInfoViewBadgeTitle: TextCSS? { get set }
        
    var jackpotFusionInfoViewBadgeBackgroundColor: UIColor? {get set}
    
    var jackpotFusionInfoViewBadgeButtonCornerRadius: CGFloat? {set get}
    
    var jackpotFusionInfoViewContentViewCornerRadius: CGFloat? {set get}
    
    var jackpotFusionInfoViewContentFontSize: CGFloat? {set get}
    
    var jackpotFusionInfoViewContentFontName: String? {set get}
    
    var jackpotFusionInfoViewContentFontFileName: String? {set get}
}
