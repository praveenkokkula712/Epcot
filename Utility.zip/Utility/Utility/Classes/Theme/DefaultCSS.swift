//
//  DefaultCSS.swift
//  CasinoLobby
//
//  Created by Praveen Kokkula on 11/02/20.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import Foundation
import UIKit

fileprivate let system10Font = UIFont.systemFont(ofSize: 10)
fileprivate let system12Font = UIFont.systemFont(ofSize: 12)
fileprivate let system13Font = UIFont.systemFont(ofSize: 13)
fileprivate let system14Font = UIFont.systemFont(ofSize: 14)
fileprivate let system12BoldFont = UIFont.boldSystemFont(ofSize: 12)
fileprivate let system14BoldFont = UIFont.boldSystemFont(ofSize: 14)
fileprivate let system16Font = UIFont.systemFont(ofSize: 16)
fileprivate let system16BoldFont = UIFont.boldSystemFont(ofSize: 16)
fileprivate let system20Font = UIFont.systemFont(ofSize: 20)
fileprivate let system20BoldFont = UIFont.boldSystemFont(ofSize: 20)
fileprivate let system24Font = UIFont.systemFont(ofSize: 24)
fileprivate let brandHexString = UIColor.hexStringToUIColor(hex: "ffcc00")
fileprivate let exploreHeaderDarkGrayColor = UIColor.hexStringToUIColor(hex: "191919")

public struct DefaultCSS: LobbyCSS {
    public var bingoWidgetViewCss: BingoWidgetCSS?
 
    public var jackpotTilesViewCSS: JackpotTilesViewCSS? = {
        DefaultJackpotTilesViewCSS()
    }()
    
    public var playBreakViewCSS: PlayBreakViewCSS? = {
        DefaultPlayBreakViewCSS()
    }()
    
    public var searchInputAccessoryViewCSS: SearchInputAccessoryViewCSS? = {
       DefaultSearchInputAccessoryViewCSS()
    }()
    
    public var epcotLobbyCSS: EpcotLobbyCSS? = {
        return DefaultEpcotLobbyCSS()
    }()
    
    public var lobbyheaderViewType: LobbyHeaderType? = {
        return .gamesCategories
    }()
    
    public var exploreLobbyView: ExploreLobbyViewCSS? = {
        return DefaultExploreLobbyViewCSS()
    }()
    
    public var lobbySwitcherPopupView: LobbySwitcherPopupViewCSS? = {
        return DefaultLobbySwitcherPopupViewCSS()
    }()
    
    public var lobbySwitcherItemView: LobbySwitcherItemCSS? = {
        return DefaultLobbySwitcherItemCSS()
    }()
    
    public var exploreCategoriesPoppUpView: ExploreLobbyCategeroiesPopUpCSS? = {
        DefaultExploreCategoriesPopUpCSS()
    }()
    public var filterView: LobbyFilterView? = {
        return DefaultLobbyFilterViewCSS()
    }()
    
    public var gamesContainerView: ViewCSS? = {
        return DefaultgamesContainerView()
    }()
    
    public var searchView: LobbySearchContentCSS? = {
        return DefaultSearchContentCSS()
    }()
    
    public var recentlyPlayedView: RecentlyPlayedViewCSS? = {
        return DefaultRecentlyPlayedViewCSS()
    }()
    
    public var noDataView: NoDataView? = {
        return DefaultNoDataView()
    }()
    
    public var noGameDataCell: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 133/255, green: 133/255, blue: 133/255, alpha: 1.0), font: system16Font)
    }()
    
    public var headerCell: HeaderCell? = {
        return DefaultHeader()
    }()
    
    public var utilView: LobbyUtilCSS? = {
        return DefaultLobbyUtilView()
    }()
    
    public var suggestionView: LobbySuggestionCSS? = {
        return DefaultLobbySuggestionView()
    }()
    
    public var gamesCell: LobbyGameCellCSS? = {
        return DefaultLobbyGamesTableViewCell()
    }()
    
    public var titleView: LobbyTitleCSS? = {
        return DefaultLobbyTitleView()
    } ()
    
    public var navigationView: LobbyNavigationCSS? = {
        return DefaultLobbyNavigationView()
    }()
    
    public var type : LobbyType! = {
        return .epcotLobby
    }()
    
    public var gridView: LobbyGridView? = {
        return DefaultLobbyGridViewCSS()
    }()
    
    public var imageFolderPathJson: [String: Any]? = {
        return [
            "0": [
                "iphone": "ios",
                "ipad-portrait": "ipad",
                "ipad-landscape": "ipad"
            ],
            "1": [
                "iphone": "square",
                "ipad-portrait": "square",
                "ipad-landscape": "square"
            ],
            "3": [
                "iphone": "square",
                "iphone-blur": "ios",
                "ipad-portrait-blur": "ios",
                "ipad-landscpae-blur": "ios",
                "ipad-portrait": "square",
                "ipad-landscape": "square"
            ],
            "2": [
                "iphone": "square",
                "ipad-portrait": "square",
                "ipad-landscape": "square"
            ],
            "recentlyPlayed": "square",
            "fallback": "square"
        ]
    }()
    
    public var immersiveImagePathJson: [String: Any]? = {
        return [
            "1": [
                "iphone": "square",
                "ipad" : "square"
            ],
            "2": [
                "iphone": "square",
                "ipad" : "square"
            ],
            "3": [
                "iphone": "portrait",
                "ipad" : "portrait"
            ],
            "4": [
                "iphone": "supersquare",
                "ipad" : "supersquare"
            ],
            "5": [
                "iphone": "supersquare",
                "ipad" : "supersquare"
            ],
            "6": [
                "iphone": "square",
                "ipad" : "square"
            ],
            "7": [
                "iphone": "square",
                "ipad" : "square"
            ],
            "11": [
                "iphone": "supersquare",
                "ipad" : "supersquare"
            ]
        ]
    }()
    
    public var lobbyCornerRadius: CGFloat? = {
        return 12.0
    }()
    public var buttonCornerRadius: CGFloat? = {
        return 3.0
    }()
    public var imageCornerRadius: CGFloat? = {
        return 8.0
    }()
    
    public var categoriesIconFontSize: CGFloat? = {
        16.0
    }()
    
    public var favouritesIconFontSize: CGFloat? = {
        16.0
    }()
    
    public var footerDownArrowIconFontSize: CGFloat? = {
        14.0
    }()
    
    public var footerRadioButtonIconFontSize: CGFloat? = {
        14.0
    }()
    
    public var shimmerViewCSS: ShimmerViewCSS? = {
        if CasinoCSS.lobby?.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false {
            return DefaultEpcotShimmerCSS()
        }
        return DefaultImmersiveShimmerCSS()        
    }()
    
    public var fallback: FallbackCSS? = {
        DefaultFallbackSolutionCSS()
    }()
    
    public var rcpUK: RcpUKCSS? = {
        DefaultRcpUKCSS()
    }()
    
    public var easyNavigation: EasyNavigationCSS? = {
        DefaultEasyNavigationCSS()
    }()
    
    public var dialogViewCSS: DialogViewCSS? = {
        DefaultDialogViewCSS()
    }()
    
    public var longSessionBreakToastViewCSS: TakeAPlayBreakToastViewCSS? = {
        DefaultLongSessionToastViewCSS()
    }()
    
    public var longSessionBreakSetUpViewCSS: LongSessionBreakSetUpViewCSS? = {
        DefaultLongSessionPlayBreakSetUpViewCSS()
    }()
    
    public var longSessionBreakConfirmationViewCSS: LongSessionBreakConfirmationViewCSS? = {
        DefaultLongSessionPlayBreakConfirmationViewCSS()
    }()
    
    public var jackpotWidgets: JackpotWidgetsCSS? = {
        DefaultJackpotWidgetCss()
    }()
    
    public var seeMoreSectionView: SeeMoreSectionViewCss? = {
        DefaultSeeMoreSectionViewCss()
    }()
    
    public var downloadingView: DownloadingViewCSS? = {
        DefaultDownloadingViewCSS()
    }()

    public var nativeFooterViewCSS: NativeFooterCSS?
    
    public var favoriteToasterViewCSS: FavoriteToasterViewCSS?
    
    public var germanRegulatory: GermanRegulatoryCSS?
    
    public var greeceLimits: LimitsCSS?
    
    public var bingoButtonCSS: BingoButtonCSS? = {
        DefaultBingoButtonCSS()
    }()
    
    public var toasterViewCSS: ToastersViewCSS? = {
        DefaultToasterViewCss()
    }()
    
    public var overlaysViewCSS: OverlaysViewCSS? = {
        DefaultOverlayViewCss()
    }()
    
    public var onboardingViewCSS: OnbordingViewCSS? = {
        DefaultOnboardingViewCss()
    }()
    
    public var jackpotFusionPopUpViewCSS: JackpotFusionInfoViewCSS? = {
        DefaultJackpotFusionInfoPopUpCSS()
    }()
    
    public var stickerCSS: StickerCSS? = {
        DefaultStickerCSS()
    }()
    
    public var gameStoriesCSS: GameStoriesCSS?

    public var gameStoryItemsCSS: GameStoryItemsCSS?

    public var searchV2CSS: SearchV2CSS?
    
    public var gamePremiereCSS: GamePremiereCSS?
    
    public var freeSpinsCSS: FreeSpinsCSS?
    
    public var top10GamesCSS: Top10GamesCSS?

    public var playerStatsWidgetCSS: PlayerStatsWidgetCSS?
    
    public var originalsWidgetCSS: OriginalsWidgetCSS?
    
    public var sessionLimitCss: SessionLimitCSS?
    
    public var engagementToolsCSS: EngagementToolsCSS?

    public init() {
        
    }
}

public struct DefaultDownloadingViewCSS: DownloadingViewCSS {
    
    public var cancelButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#000000"), font: system14Font)
        return DefaultButtonCSS(title: textCSS, selected: .clear, normal: .clear)
    }()
    public var gametitle: TextCSS? = {
       DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: system20BoldFont)
    }()
    
    public var progressTitle: TextCSS? = {
       DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: system16Font)
    }()

    public var progressTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()

    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()

  
}
public struct DefaultSeeMoreSectionViewCss: SeeMoreSectionViewCss {
    
    public var backButtontint: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var title: TextCSS? = {
       DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: system16BoldFont)
    }()
    
    public var switcherSelectedColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var switcherUnselectedColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#000000")
    }()
    
    public var collectionViewBGColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#191919")
    }()
    
    public var shadowColor: UIColor? = {
        return .clear
    }()
    
    public var titleViewBackgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#000000")
    }()
    
    public var headerTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#D6D6D6"), font: system24Font)
    }()
        
    public var headerPrice: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFCC00"), font: system14Font)
    }()
}

public struct DefaultTextCSS:TextCSS {
    
    public var color: UIColor?
    
    public var font: UIFont?
    
    public init(color: UIColor?,
                font: UIFont?) {
        self.color = color
        self.font = font
    }
}

public struct DefaultButtonCSS: ButtonCSS {
    
    public var title: TextCSS?
    
    public var selected: UIColor?
    
    public var normal: UIColor?
    
    public init(title: TextCSS?,
                selected: UIColor?,
                normal: UIColor?) {
        self.title = title
        self.selected = selected
        self.normal = normal
    }
    
}

struct DefaultNoDataView: NoDataView {
    
    var iconColor: UIColor? = {
        return .red
    }()
    
    
    var color: UIColor? = {
        return UIColor(displayP3Red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    }()
    
    var font: UIFont? = {
        return system16BoldFont
    }()
    
    var backgroundColor: UIColor? = {
        return UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 1.0)
    }()
    
}

struct DefaultHeader: HeaderCell {
    
    var color: UIColor? = {
        return UIColor(displayP3Red: 51/255, green: 51/255, blue: 51/255, alpha: 1.0)
    }()
    
    var font: UIFont? = {
        return system20BoldFont
    }()
    
    var backgroundColor: UIColor? = {
        return UIColor(displayP3Red: 1, green: 1, blue: 1, alpha: 1)
    }()
}


struct DefaultgamesContainerView: ViewCSS  {
    var backgroundColor: UIColor? = {
        return UIColor(red: 1, green: 1, blue: 1, alpha: 1)
    }()
}


struct DefaultLobbyTitleView: LobbyTitleCSS {
    var searchBarBGColor: UIColor? = {
        return UIColor(red: 1, green: 1, blue: 1, alpha: 1)
    }()
    
    var searchBarLayerColor: UIColor? = {
        return UIColor(red: 193/255, green: 193/255, blue: 193/255, alpha: 1.0)
    }()
    
    
    var backgroundColor: UIColor? = {
        return UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 1.0)
    }()
    
    var searchIconColor: UIColor? = {
        return UIColor(displayP3Red: 106/255, green: 106/255, blue: 106/255, alpha: 1.0)
    }()
    
    var title: TextCSS = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 1, green: 1, blue: 1, alpha: 1), font: system20BoldFont)
    } ()
    
    var searchPlacehoder: TextCSS = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 153/255, green: 153/255, blue: 153/255, alpha: 1), font: system16Font)
    }()
    
    var searchText: TextCSS = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 153/255, green: 153/255, blue: 153/255, alpha: 1), font: system16Font)
    }()
    
    var buttonCSS: ButtonCSS = {
        let color = UIColor.hexStringToUIColor(hex: "#475EEC")
        return DefaultButtonCSS(title: DefaultTextCSS(color: color, font: system14BoldFont),
                                selected: color,
                                normal: color)
    }()
}

struct DefaultLobbyNavigationView : LobbyNavigationCSS  {
    
    var backgroundColor: UIColor? = {
        return UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 1.0)
    }()
    
    var buttonCSS: ButtonCSS? = {
        let defaultTitleCSS = DefaultTextCSS(color: UIColor(displayP3Red: 255/255, green: 204/255, blue: 0, alpha: 1.0), font: system20BoldFont)
        return DefaultButtonCSS(title: defaultTitleCSS, selected: UIColor(displayP3Red: 255/255, green: 204/255, blue: 0, alpha: 1.0), normal: UIColor(displayP3Red: 1, green: 1, blue: 1, alpha: 1))
    }()
    
    var shadowColor: UIColor? = {
        return .clear
    }()
}

struct DefaultLobbyTableView:ViewCSS {
    
    var backgroundColor: UIColor? = {
        return .clear
    }()
}

struct DefaultLobbyUtilView: LobbyUtilCSS {
    
    var exploreButton: ButtonCSS = {
        let textCSS = DefaultTextCSS(color: UIColor(displayP3Red: 3/255, green: 3/255, blue: 3/255, alpha: 1.0), font: system14BoldFont)
        return DefaultButtonCSS(title: textCSS, selected: nil , normal: UIColor(displayP3Red: 255/255, green: 204/255, blue: 0, alpha: 1.0))
    }()
    
    var moreGamesTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 133/255, green: 133/255, blue: 133/255, alpha: 1.0), font: system16Font)
    }()
    
    var backgroundColor: UIColor? = {
        return UIColor(displayP3Red: 239/255, green: 239/255, blue: 239/255, alpha: 1.0)
    }()
}

struct DefaultLobbySuggestionView : LobbySuggestionCSS {
    var shadowColor: UIColor? = {
        return .clear
    }()
    
    
    var searchIconColor: UIColor? = {
        return UIColor(red: 1, green: 1, blue: 1, alpha: 1)
    }()
    
    var resultTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 1, green: 1, blue: 1, alpha: 1), font: UIFont.boldSystemFont(ofSize: 10))
    }()
    
    var hintTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor(red: 133/255, green: 133/255, blue: 133/255, alpha: 1.0), font: UIFont.systemFont(ofSize: 12))
    }()
    
    var contentBGColor: UIColor? = {
        return UIColor(displayP3Red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0)
    }()
    
    var title: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 1, green: 1, blue: 1, alpha: 1), font: system16Font)
    }()
    
    var backgroundColor: UIColor? = {
        return UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 1.0)
    }()
    
    var resultViewBgColor: UIColor? = {
        UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 1.0)
    }()
}

struct DefaultLobbyGamesTableViewCell: LobbyGameCellCSS {
   
    
    public var favouriteButtonIconSelected: String? = {
        return "heart-outline"
    }()
    
    public var favouriteButtonIconUnselected: String? = {
        return "heart-solid"
    }()
    
    var favouriteButtonTintColor: UIColor? = {
        return UIColor.white
    }()
    
    var favouriteButtonBackgroundColor: UIColor? = {
        return UIColor(white: 0, alpha: 0.4)
    }()
    
    var sticker: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), font: UIFont.boldSystemFont(ofSize: 10))
    }()
    
    var cellSkinColor: UIColor? = {
        return UIColor(displayP3Red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0)
    }()
    
    var priceTagCSS: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 255/255, green: 204/255, blue: 0.0, alpha: 1.0), font: system14Font)
    }()
    
    var gameTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 1, green: 1, blue: 1, alpha: 1), font: UIFont.boldSystemFont(ofSize: 18))
    }()
    
    var favouriteButton: ButtonCSS? = {
        return DefaultButtonCSS(title: nil, selected: UIColor(displayP3Red: 255/255, green: 204/255, blue: 0, alpha: 1.0), normal: UIColor(displayP3Red: 1, green: 1, blue: 1, alpha: 1))
    }()
    
    var priceTag: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 255/255, green: 204/255, blue: 0, alpha: 1.0), font: system14Font)
    }()
    
    var playButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor(displayP3Red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0), font: system14BoldFont)
        return DefaultButtonCSS(title: textCSS, selected: UIColor(displayP3Red: 255/255, green: 217/255, blue: 64/255, alpha: 1.0), normal: UIColor(displayP3Red: 255/255, green: 204/255, blue: 0, alpha: 1.0))
    }()
    
    var downloadButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: .white, font: system14BoldFont)
        return DefaultButtonCSS(title: textCSS, selected: .clear, normal: .clear)
    }()
    
    var downloadButtonBorderColor: UIColor? = {
        return .white
    }()
    
    var speakerButtonTintColor: UIColor? = {
        .white
    }()
    
    var speakerButtonBackgroundColor: UIColor? = {
        UIColor(white: 0, alpha: 0.4)
    }()
    
    var speakerButtonCornerRadius: CGFloat? = {
        17.5
    }()
    
}

struct DefaultRecentlyPlayedViewCSS: RecentlyPlayedViewCSS {
    var title: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 133/255, green: 133/255, blue: 133/255, alpha: 1.0), font: system16Font)
    }()
    
    var seeMoreTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.white, font: system12Font)
    }()
    
    var backgroundColor: UIColor? = {
        return UIColor(red: 1, green: 1, blue: 1, alpha: 1)
    }()
    
    var shadowColor: UIColor? = {
        return UIColor(red: 1, green: 1, blue: 1, alpha: 1)
    }()
    
    var infoButtonTintColor: UIColor? = {
        return .white
    }()

    var descriptionTextColor: TextCSS? = {
        return DefaultTextCSS(color: .white, font: system12Font)
    }()
    
}

struct DefaultSearchContentCSS: LobbySearchContentCSS {
    
    var menuButtonFont: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: .white, font: system12Font)
        return DefaultButtonCSS(title: textCSS, selected: .clear, normal: .clear)
        
    }()
    
    var menuButtonCornerRadius: CGFloat? = {
        16.0
    }()
    
    var menuButtonBgColor: UIColor? = {
        return UIColor(red: 118/255, green: 118/255, blue: 128/255, alpha: 0.24)
    }()
    
    var menuButtonContainerBgColor: UIColor? = {
        return UIColor(red: 0, green: 0, blue: 0, alpha: 0.2)
    }()
    
    var layerColor: UIColor? = {
        return UIColor(red: 193/255, green: 193/255, blue: 193/255, alpha: 1.0)
    }()
    
    
    var shadowColor: UIColor? = {
        return .clear
    }()
    
    var backIconColor: UIColor? = {
        return UIColor(red: 0, green: 0, blue: 0, alpha: 1)
    }()
    
    var clearIconColor: UIColor? = {
        return UIColor(red: 0, green: 0, blue: 0, alpha: 0.2)
    } ()
    
    var searchMicIcon: UIColor? = {
        return UIColor(red: 0, green: 0, blue: 255/255, alpha: 1)
    } ()
    
    var backgroundColor: UIColor? = {
        return UIColor(red: 1, green: 1, blue: 1, alpha: 1)
    }()
    var searchContainerBGColor: UIColor? = {
        return UIColor(red: 118/255, green: 118/255, blue: 128/255, alpha: 0.24)
    }()
    
    var searchContainerTitleColor: UIColor? = {
        return UIColor(red: 235/255, green: 235/255, blue: 245/255, alpha: 0.6)
    }()
    
    var searchParentContainerBGColor: UIColor? = {
        return UIColor(red: 0, green: 0, blue: 0, alpha: 0.2)
    }()
    
    var searchPlaceHolderFont: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 133/255, green: 133/255, blue: 133/255, alpha: 1.0), font: system16Font)
    }()
}

struct DefaultSearchInputAccessoryViewCSS: SearchInputAccessoryViewCSS {
    var micButtonHightedTintColor: UIColor? = {
        .blue
    }()
    
    var bottomSearchButtonBgColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    var bottomSearchButtonTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFCC00"), font: system16Font)
    }()
    
    var bottomSearchIconTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    var searchInputHeaderBgColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    var searchInputHeaderBackButtonTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    var searchInputHeaderTitleColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    var searchInputContainerViewBgColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    var searchInputHeaderTitleFont: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 133/255, green: 133/255, blue: 133/255, alpha: 1.0), font: system16Font)
    }()
    
    var searchInputTextFieldFont: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 133/255, green: 133/255, blue: 133/255, alpha: 1.0), font: system16Font)
    }()
    
    var searchButtonTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    var micButtonTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    var searchFieldCornerRadius: CGFloat? = {
        8.0
    }()
    
    var searchInputTextfieldBgColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    var searchInputPlaceHolderTextColor: UIColor? = {
        .lightGray
    }()
    var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
}


struct DefaultLobbyFilterViewCSS: LobbyFilterView {
    var showBtn: LobbyFilterButtonCSS? = {
        DefaultLobbyFilterButtonCSS()
    }()
    
    var clearBtnIn: LobbyFilterButtonCSS? = {
        DefaultLobbyFilterClearButtonCSS()
    }()
    
    var filterBtn: LobbyFilterButtonCSS? = {
        DefaultLobbyFilterOutButtonCSS()
    }()
    
    var clearBtnOut: LobbyFilterButtonCSS? = {
        DefaultLobbyFilterClearOutButtonCSS()
    }()
    
    var headerView: LobbyFilterHeaderView? = {
        DefaultLobbyFilterHeaderView()
    }()
    
    var filterItem: TextCSS? = {
        return DefaultTextCSS(color: .black, font: system16Font)
    }()
    
    var backgroundColor: UIColor? = {
        .white
    }()
    
    var checkmarkColor: UIColor? = {
        return nil
    }()
    
}
struct DefaultLobbyFilterButtonCSS: LobbyFilterButtonCSS {
    var buttonBorderColor: UIColor? = {
        .clear
    }()
    
    var selected: UIColor? = {
        .clear
    }()
    
    var normal: UIColor? = {
        .clear
    }()
    
    var title: TextCSS? = {
        DefaultTextCSS(color: .black, font: system16BoldFont)
    }()
    
    var backgroundColor: UIColor? = {
        UIColor(displayP3Red: 255/255, green: 204/255, blue: 0, alpha: 1.0)
    }()
    
}
struct DefaultLobbyFilterClearButtonCSS: LobbyFilterButtonCSS {
    var buttonBorderColor: UIColor? = {
        .white
    }()
    
    var selected: UIColor? = {
        .clear
    }()
    
    var normal: UIColor? = {
        .clear
    }()
    
    var title: TextCSS? = {
        DefaultTextCSS(color: .black, font: system14BoldFont)
    }()
    
    var backgroundColor: UIColor? = {
        .clear
    }()
}
struct DefaultLobbyFilterOutButtonCSS: LobbyFilterButtonCSS  {
    var buttonBorderColor: UIColor? = {
        .clear
    }()
    
    var selected: UIColor? = {
        .clear
    }()
    
    var normal: UIColor? = {
        .clear
    }()
    
    var title: TextCSS? = {
        DefaultTextCSS(color: .black, font: system16BoldFont)
    }()
    
    var backgroundColor: UIColor? = {
        UIColor(displayP3Red: 255/255, green: 204/255, blue: 0, alpha: 1.0)
    }()
}

struct DefaultLobbyFilterClearOutButtonCSS: LobbyFilterButtonCSS {
    var buttonBorderColor: UIColor? = {
        .white
    }()
    
    var selected: UIColor? = {
        .clear
    }()
    
    var normal: UIColor? = {
        .clear
    }()
    
    var title: TextCSS? = {
        DefaultTextCSS(color: .black, font: system14BoldFont)
    }()
    
    var backgroundColor: UIColor? = {
        .clear
    }()
}

struct DefaultLobbyFilterHeaderView: LobbyFilterHeaderView {
    var filterHeaderTitle: TextCSS? = {
        DefaultTextCSS(color: .black, font: system16BoldFont)
    }()
    
    var filterHeaderClose: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: .black, font: system14Font)
        return DefaultButtonCSS(title: textCSS, selected: .clear, normal: .clear)
    }()
    
    var backgroundColor: UIColor? = {
        .clear
    }()
}

public struct DefaultLobbyGridViewCSS: LobbyGridView {
    
    public var header: GridHeader? = {
        DefaultGridHeader()
    }()
    
    public var categoryView: CategoryView? = {
        DefaultCategoryView()
    }()
    
    public var jpView: JPView? = {
        DefaultJPView()
    }()
    
    public var myGames: MyGamesView? = {
        DefaultMyGamesView()
    }()
    
    public var backgroundColor: UIColor? = {
        return .black
    }()
    
    public var categoryViewbackgroundColor: UIColor? = {
        return .black
    }()
    public var gridViewbackgroundColor: UIColor? = {
        return .black
    }()
    public var searchBanner: GridSearchBanner? = {
        return DefaultGridSearchBanner()
    }()
}


public struct DefaultGridHeader: GridHeader {
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: .white, font: system20BoldFont)
    }()
    
    public var readyToPlay: TextCSS? = {
        DefaultTextCSS(color: .white, font: system14Font)
    }()
    
    public var myGames: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: .black, font: system14BoldFont)
        return DefaultButtonCSS(title: textCSS, selected: UIColor.hexStringToUIColor(hex: "#ffd940"), normal: brandHexString)
        
    }()
    
    public var searchIconColor: UIColor? = {
        return .white
    }()
    
    public var backgroundColor: UIColor? = {
        return .black
    }()
    
    public var mygamesBorderColor: UIColor? = {
        return .black
    }()
    
}

public struct DefaultCategoryView: CategoryView {
    
    public var selected: TextCSS? = {
        return DefaultTextCSS(color: brandHexString, font: system16BoldFont)
    }()
    
    public var normal: TextCSS? = {
        return DefaultTextCSS(color: UIColor(red: 1, green: 1, blue: 1, alpha: 0.7), font: system16BoldFont)
    }()
    
    public var backgroundColor: UIColor? = {
        return .black
    }()
    
    public var titleNormalColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#ADADAD")
    }()
    
    public var separatorLineColor: UIColor? = {
        return .white
    }()
    
    
}

public struct DefaultJPView: JPView {
    
    public var priceAmount: TextCSS? = {
        return DefaultTextCSS(color: .white, font: UIFont.boldSystemFont(ofSize: 12))
    }()
    
    public var listPriceAmount: UIFont? = {
        return UIFont.boldSystemFont(ofSize: 7)
    }()
    
    public var jpBGColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "333333", withAlpha: 0.8)
    }()
}

public struct DefaultMyGamesView: MyGamesView {
    
    
    public var mygames: TextCSS? = {
        DefaultTextCSS(color: UIColor.black, font: system16BoldFont)
    }()
    
    public var close: TextCSS? = {
        DefaultTextCSS(color: UIColor.black, font: system14Font)
    }()
    
    public var pullView: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "d8d8d8")
    }()
    
    public var noGames: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "5c5c5c"), font: system14Font)
    }()
    
    public var exploreGames: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.black, font: system14BoldFont)
        return DefaultButtonCSS(title: textCSS, selected: UIColor.hexStringToUIColor(hex: "ffd940"), normal: brandHexString)
    }()
    
    public var pickGames: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "5c5c5c"), font: system14Font)
    }()
    
    public var containerViewColor: UIColor? = {
        return .black
    }()
    
    public var backgroundColor: UIColor? = {
        return .white
    }()
    
}

public struct DefaultGridSearchBanner: GridSearchBanner {
    
    public var findText: TextCSS? = {
        DefaultTextCSS(color: .black, font: system14BoldFont)
    }()
    
    public var noSuccess: TextCSS? = {
        DefaultTextCSS(color: .black, font: system14Font)
    }()
    
    public var searchNow: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: .black, font: system14BoldFont)
        return DefaultButtonCSS(title: textCSS, selected: UIColor.clear, normal: UIColor.clear)
    }()
    
    public var searchBorder: UIColor? = {
        return UIColor.black
    }()
    
    public var backgroundColor: UIColor? = {
        return brandHexString
    }()
}

public struct DefaultEpcotLobbyCSS: EpcotLobbyCSS {
    public var liveFeedCSS: LiveFeedCSS? = {
        DefaultLiveFeedCSS()
    }()
    
    
    public var epcotTextColor: UIColor? = {
        return UIColor.black
    }()
    
    public var realityCheckAlertTextColor: UIColor? = {
        return UIColor.black
    }()
    
    public var fallbackPopOverTextColor: UIColor? = {
        return UIColor.black
    }()
    
    public var fallbackPopOverCloseButtonColor: UIColor? = {
        return UIColor.black
    }()
    
    public var customAlertTitleColor: UIColor? = {
        return UIColor.black
    }()
    
    public var epcotGradientButtonColor: UIColor? = {
        return UIColor.black
    }()
    
    
    public var categoryGameCountCSS: CategoryGameCountCSS? = {
         return DefaultEpcotCategoryGameCountCSS()
    }()
    
    public var menuIconFontSize: CGFloat? = {
        16.0
    }()
    
    public var searchMenuIconFontSize: CGFloat? = {
        16.0
    }()
    
    public var categoriesPillsIconFontSize: CGFloat? = {
        16.0
    }()
    
    public var jackpotViewBackgroundColor: UIColor? = {
        return UIColor.white
    }()
    
    public var jackpotViewLayerBackgroundColor: UIColor? = {
        return UIColor(red: 0.02, green: 0.02, blue: 0.02, alpha: 0.4)
    }()
    
    public var shimmerGradients: ShimmerGradients? = {
        let start = UIColor(white: 0.85, alpha: 1.0).cgColor
        let middle = UIColor(white: 0.95, alpha: 1.0).cgColor
        let end = UIColor(white: 0.85, alpha: 1.0).cgColor
        return ShimmerGradients(colors: [start, middle, end])
    }()
    
    public var menuViewCSS: EpcotMenuViewCSS? = {
        DefaultEpcotMenuViewCSS()
    }()
    
    public var teasersViewCSS: EpcotTeasersCSS? = {
        DefaultEpcotTeasersCSS()
    }()
    
    public var menuViewTitle: TextCSS? = {
        DefaultTextCSS(color: .white, font: UIFont.systemFont(ofSize: 13))
    }()
    
    public var menuViewBGColor: UIColor? = {
        .hexStringToUIColor(hex: "#303030")
    }()
    
    public var searchViewTitle: TextCSS? = {
        DefaultTextCSS(color: .white, font: UIFont.systemFont(ofSize: 13))
    }()
    
    public var searchViewBGColor: UIColor? = {
        .hexStringToUIColor(hex: "#303030")
    }()
    
    public var searchMenuContainerViewBGColor: UIColor? = {
        .hexStringToUIColor(hex: "#050505")
    }()
    
    public var categoriesPillTitle: TextCSS? = {
        DefaultTextCSS(color: .white, font: UIFont.systemFont(ofSize: 13))
    }()
    
    public var categoriesPillBorderColor: UIColor? = {
        .hexStringToUIColor(hex: "#FFFFFF", withAlpha: 0.28)
    }()
    
    public var categoriesViewBGColor: UIColor? = {
        .hexStringToUIColor(hex: "#050505")
    }()
    
    public var pageControllerDotsColor: UIColor? = {
        return UIColor.init(white: 0, alpha: 0.5)
    }()
    
    public var pageControllerDotSelectedColor: UIColor? = {
        return UIColor.white
    }()
    
    public var gameCollectionViewBGColor: UIColor? = {
        .hexStringToUIColor(hex: "#050505")
    }()
    
    public var backgroundColor: UIColor? = {
        .white
    }()
    
    public var categoriesSelectedPillTitle: TextCSS? = {
        DefaultTextCSS(color: .hexStringToUIColor(hex: "#050505"), font: UIFont.systemFont(ofSize: 13))
    }()
    
    public var categoriesSelectedViewBGColor: UIColor? = {
        .hexStringToUIColor(hex: "#F3F4F5")
    }()
    
    public var epcotSearchViewCSS: EpcotSearchContentCSS? = {
        return EpcotSearchContentViewCSS()
    }()
    
    public var epcotSecondaryButtonTitleColor: UIColor? = {
        return UIColor.black
    }()
    
    public var epcotButtonTitleFont: UIFont? = {
        return UIFont.systemFont(ofSize: 12.0)
    }()
    
    public var epcotViewBorderColor: UIColor? = {
        return UIColor.black
    }()
    
    public var epcotMenuButtonBorderColor: UIColor? = {
        return .clear
    }()
        
    public var epcotMandortyUpdateButtonColors1: UIColor? = {
        return UIColor.black
    }()
    
    public var epcotMandortyUpdateButtonColors2: UIColor? = {
        return UIColor.black
    }()
    
    public var categoryHeaderCloseIconColor: UIColor? = {
        return UIColor.black
    }()
    
    public var epcotPopUpBgColor: UIColor? = {
        return .clear
    }()
    
    public var epcotPopUpHeaderBgColor: UIColor? = {
        return UIColor.black
    }()
    
    public var epcotCloseButtonColor: UIColor? = {
        return UIColor.black
    }()
    
    public var epcotBodyTextColor: UIColor? = {
        return UIColor.black
    }()
    
    public var epcotTitleFont: UIFont? = {
        return UIFont.systemFont(ofSize: 12.0)
    }()
    
    public var epcotBodyFont: UIFont? = {
        return UIFont.systemFont(ofSize: 12.0)
    }()
    
    public var epcotPopupMessageFont: UIFont? = {
        return UIFont.systemFont(ofSize: 12.0)
    }()
    
    public var isEpcotFeatureEnabled: Bool? = {
        true
    }()
    
    public var immersiveCSS: ImmersiveCSS? = {
        DefaultImmersiveCSS()
    }()
    
    public init() {
        
    }
}

public struct DefaultEpcotCategoryGameCountCSS : CategoryGameCountCSS {
    public var categoryGamesCountTitle: TextCSS? = {
        DefaultTextCSS(color: .hexStringToUIColor(hex: "#79BFFF"), font: UIFont.systemFont(ofSize: 14))
    }()
    
    public var categoryGamesCountCornerRadius: CGFloat? = {
        return 11.5
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#232323")
    }()
    
    public init() {
        
    }
}
public struct DefaultEpcotMenuViewCSS: EpcotMenuViewCSS {
    public var headerBGColor: UIColor? = {
        .hexStringToUIColor(hex: "#F9F9F9", withAlpha: 0.94)
    }()
    
    public var headerCornerRadius: CGFloat? = {
        return 10.0
    }()
    
    public var headerTitle: TextCSS? = {
        DefaultTextCSS(color: .black, font: UIFont.systemFont(ofSize: 17))
    }()
    
    public var doneTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#007AFF"), font: UIFont.systemFont(ofSize: 17))
    }()
    
    public var sectionHeaderTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#63656A"), font: UIFont.systemFont(ofSize: 11))
    }()
    
    public var categoriesListTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#050505"), font: UIFont.systemFont(ofSize: 14))
    }()
    
    public var seperatorLineColour: UIColor? = {
        .hexStringToUIColor(hex: "#DCDFE4")
    }()
    
    public var arrowColour: UIColor? = {
        .hexStringToUIColor(hex: "#475EEC")
    }()
    
    public var appAdsBGColor: UIColor? = {
        .hexStringToUIColor(hex: "#F5F5F5", withAlpha: 0.5)
    }()
    
    public var appAdsTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#000000"), font: UIFont.systemFont(ofSize: 15))
    }()
    
    public var appAdsDescription: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#000000"), font: UIFont.systemFont(ofSize: 13))
    }()
    
    public var backgroundColor: UIColor? = {
        .white
    }()
    
}

public struct DefaultEpcotTeasersCSS: EpcotTeasersCSS {
    
    public var ipadTitle: TextCSS?
    
    public var iPadtitleRegularFont: UIFont?
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: .white, font: system14BoldFont)
    }()
    
    public var subTitle: TextCSS? = {
        DefaultTextCSS(color: .white, font: system12Font)
    }()
    
   public var titleRegularFont: UIFont? = {
       system14Font
   }()

    public var ctaButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: .black, font: system14BoldFont)
        let btnColor = UIColor.hexStringToUIColor(hex: "#BDA871")
        return DefaultButtonCSS(title: textCSS, selected: btnColor, normal: btnColor)
    }()
    
    public var teaserBGColor: UIColor? = {
        .white
    }()
    
    public var teaserCornerRadius: CGFloat? = {
        10.0
    }()
    
    public var backgroundColor: UIColor? = {
        .black
    }()
    
    public var termsBackgroundColor: UIColor? = {
        UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.12)
    }()
    
    public var termsTextColor: UIColor? = {
        UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    }()

    public var termsTextFont: UIFont? = {
        system10Font
    }()
    
    public var embeddedBannerBGColor: UIColor? = {
        .black
    }()
}


struct DefaultExploreLobbyViewCSS: ExploreLobbyViewCSS {
    var categoriesTitle: TextCSS? = {
        DefaultTextCSS(color: .white, font: system12Font)
    }()
    
    var title: TextCSS? = {
        DefaultTextCSS(color: .white, font: system16BoldFont)
    }()
    
    var tintColor: UIColor? = {
        .white
    }()
    
    var switcherTintColor: UIColor? = {
        .white
    }()
    var backgroundColor: UIColor? = {
        exploreHeaderDarkGrayColor
    }()
}

struct DefaultLobbySwitcherPopupViewCSS: LobbySwitcherPopupViewCSS {
    var cornerRadius: CGFloat? = {
        24.0
    }()
    
    var itemContainerCornerRadius: CGFloat? = {
        8.0
    }()
    
    var tintColor: UIColor? = {
        exploreHeaderDarkGrayColor
    }()
    
    var title: TextCSS? = {
        DefaultTextCSS(color: .white, font: system16BoldFont)
    }()
    
    var backgroundColor: UIColor? = {
        exploreHeaderDarkGrayColor
    }()
    
    var itemContainerBGColor: UIColor? = {
        .black
    }()
}

struct DefaultLobbySwitcherItemCSS: LobbySwitcherItemCSS {
    var itemCornerRadius: CGFloat? = {
        8.0
    }()
    
    var titleNormal: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#BEBFC0"), font: system12Font)
    }()
    
    var titleSelected: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#0A0A0A"), font: system12Font)
    }()
    
    var backgroundColor: UIColor? = {
        .clear
    }()
    
    var contentHightedBGColor: UIColor? = {
        brandHexString
    }()
    var tintColor: UIColor? = {
        .white
    }()
    
}

struct DefaultExploreCategoriesPopUpCSS: ExploreLobbyCategeroiesPopUpCSS {
    var cornerRadius: CGFloat? = {
        16.0
    }()
    
    var applyButtonCornerRadius: CGFloat? = {
        4.0
    }()
    
    var cellSeperatorColor: UIColor? = {
        UIColor(displayP3Red: 51.0/255.0, green: 51.0/255.0, blue: 51.0/255.0, alpha: 1.0)
    }()
    
    var tintColor: UIColor? = {
        brandHexString
    }()
    
    var itemCornerRadius: CGFloat? = {
        8.0
    }()
    
    var backgroundColor: UIColor? = {
        exploreHeaderDarkGrayColor
    }()
    
    var title: TextCSS? = {
        DefaultTextCSS(color: .white, font: system16Font)
    }()
    
    var categoryTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#D4D4D5"), font: system12Font)
    }()
    
    var cellTitleNormal: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#BEBFC0"), font: system16Font)
    }()
    
    var cellTitleSelected: TextCSS? = {
        DefaultTextCSS(color: brandHexString, font: system16Font)
    }()
    
    var applyButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.black, font: system12Font)
        return DefaultButtonCSS(title: textCSS, selected: brandHexString, normal: brandHexString)
    }()
    
}


struct EpcotSearchContentViewCSS: EpcotSearchContentCSS {
    
    var backgroundColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#F3F4F5")
    }()
    
    var headerTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 1),
                              font: system20BoldFont)
    } ()
    
    var headerButtonCSS: ButtonCSS? = {
        let color = UIColor.hexStringToUIColor(hex: "#475EEC")
        return DefaultButtonCSS(title: DefaultTextCSS(color: color, font: system16BoldFont),
                                selected: color,
                                normal: color)
    }()
    
    var headerBackgroundColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#F3F4F5")
    }()
    
    var searchText: TextCSS? = {
        return DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#050505", withAlpha: 1),
                              font: system13Font)
    } ()
    
    var clearIconColor: UIColor? = {
        return UIColor(red: 0, green: 0, blue: 0, alpha: 1)
    } ()
    
    var micIconColor: UIColor? = {
        return UIColor(red: 0, green: 0, blue: 255/255, alpha: 1)
    } ()
    
    var suggestionsBackgroundColor: UIColor? = {
        return UIColor(displayP3Red: 1, green: 1, blue: 1, alpha: 1.0)
    }()
    
    var nodataTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 1.0),
                              font: system16BoldFont)
    }()
    
    var nodataBackgroundColor: UIColor? = {
        return .clear
    }()
    
}

public struct DefaultEpcotShimmerCSS: ShimmerViewCSS {
    
    public init() { }
    
    public var backgroundColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#050505")
    }()
    
    public var borderColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#303030")
    }()
    
    public var cornerRadius: CGFloat? = {
        return 6.0
    }()
    
    public var gradients: ShimmerGradients? = {
        let start = UIColor.hexStringToUIColor(hex: "#303030", withAlpha: 0.85).cgColor
        let middle = UIColor.hexStringToUIColor(hex: "#303030", withAlpha: 0.95).cgColor
        let end = UIColor.hexStringToUIColor(hex: "#303030", withAlpha: 0.85).cgColor
        return ShimmerGradients(colors: [start, middle, end])
    }()
}

public struct DefaultImmersiveShimmerCSS: ShimmerViewCSS {
    
    public init() { }
    
    public var backgroundColor: UIColor? = {
        return UIColor.white
    }()
    
    public var borderColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#F2F4F7")
    }()
    
    public var cornerRadius: CGFloat? = {
        return 8.0
    }()
    
    public var gradients: ShimmerGradients? = {
        let start = UIColor.hexStringToUIColor(hex: "#F2F4F7", withAlpha: 0.85).cgColor
        let middle = UIColor.hexStringToUIColor(hex: "#F2F4F7", withAlpha: 0.95).cgColor
        let end = UIColor.hexStringToUIColor(hex: "#F2F4F7", withAlpha: 0.85).cgColor
        return ShimmerGradients(colors: [start, middle, end])
    }()
}

public struct DefaultRcpSessionCoolOffAlertCSS: SessionCoolOffAlertCSS {
    
    public init() {
        
    }
    
    public var description: TextCSS? = {
        return DefaultTextCSS(color: UIColor(red: 0, green: 0, blue: 0, alpha: 1.0), font: system14Font)
    }()
    
    public var okBtn: ButtonCSS? = {
        let color = UIColor.hexStringToUIColor(hex: "#000000")
        return DefaultButtonCSS(title: DefaultTextCSS(color: color, font: system16BoldFont), selected: UIColor.hexStringToUIColor(hex: "#96BB43"),
                                normal: UIColor.hexStringToUIColor(hex: "#96BB43"))
    }()
    
    public var leaveBtn: ButtonCSS? = {
        let color = UIColor.hexStringToUIColor(hex: "#000000")
        return DefaultButtonCSS(title: DefaultTextCSS(color: color, font: system16BoldFont),
                                selected: UIColor.hexStringToUIColor(hex: "#FFFFFF"),
                                normal: UIColor.hexStringToUIColor(hex: "#FFFFFF"))
    }()
    
    public var containerBgColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var cornerRadius: CGFloat? = {
        return 5.0
    }()
    
    public var leaveButtonBorderColor: UIColor? = {
        .black
    }()
}

public struct DefaultSessionCoolOffTimerAlertCSS:  GermanSessionCoolOffTimerAlertCSS {
    
    public init() {
        
    }
    
    public var bannerTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor(red: 0, green: 0, blue: 0, alpha: 1.0), font: system16BoldFont)
        
    }()
    
    public var bannerBody: TextCSS? = {
        return DefaultTextCSS(color: UIColor(red: 0, green: 0, blue: 0, alpha: 1.0), font: system14Font)
        
    }()
    
    public var bannerBtn: ButtonCSS? = {
        let color = UIColor.hexStringToUIColor(hex: "#000000")
        return DefaultButtonCSS(title: DefaultTextCSS(color: color, font: system14BoldFont), selected: UIColor.hexStringToUIColor(hex: "#FFFFFF"),
                                normal: UIColor.hexStringToUIColor(hex: "#FFFFFF"))
    }()
    
    public var progressTimerText: TextCSS? = {
        return DefaultTextCSS(color: UIColor(red: 255, green: 255, blue: 255, alpha: 1.0), font: system14BoldFont)
    }()
    
    public var progressTimerTextBgViewColor: UIColor? = {
        UIColor.black
    }()
    
    public var progressBarColor: UIColor? = {
        UIColor(red: 112/255.0, green: 172/255.0, blue: 93/255.0, alpha: 1.0)
    }()
    public var progressBarTrackColor: UIColor? = {
        UIColor.black.withAlphaComponent(0.2)
    }()
}

public struct DefaultImmersiveCSS: ImmersiveCSS {
    
    public var portraitSectionCSS: TextCSS? = {
        return DefaultTextCSS(color: UIColor.white, font: system10Font)
    }()
    
    public var downloadIconBGColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#333333")
    }()
    
    public var downloadIconCornerRdius: CGFloat? = {
        return 4
    }()
}

public struct DefaultFallbackSolutionCSS: FallbackCSS {
    
    public var fallbackDecription: TextCSS? = {
        return DefaultTextCSS(color:UIColor.hexStringToUIColor(hex: "#000000"), font: system12BoldFont)
    }()
    
    public var playButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#ffffff"), font: system12BoldFont)
        return DefaultButtonCSS(title: textCSS, selected: .clear, normal: UIColor.hexStringToUIColor(hex: "#ffcc00"))
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#ffffff")
    }()
    
    public var headerTitle: TextCSS? = {
        return DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#000000"), font: system16BoldFont)
    }()
    
    public var headerClose: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#000000"), font: system14Font)
        return DefaultButtonCSS(title: textCSS, selected: .clear, normal: .clear)
    }()
    
    public var playMode: PlayModeCSS? = {
       return DefaultCasinoPlayModeCSS()
    }()
    
    public var gameImagePath: String? = {
        return "square"
    }()
}

public struct DefaultGameExclusionViewCSS: GameExclusionViewCSS {
    
    public init() {
        
    }
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#000000"), font: system14Font)
    }()
    
    public var hyperLinkCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#000000"), font: system14BoldFont)
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#EDC543")
    }()
}

public struct DefaultCasinoPlayModeCSS: PlayModeCSS {
   
    public var cellSkinColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#191919")
    }()
    
    public var gameTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#ffffff"), font: system14BoldFont)
    }()
    
    public var playButton: ButtonCSS? = {
        let textCSS = DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#ffffff"), font: system12BoldFont)
         return DefaultButtonCSS(title: textCSS, selected: UIColor.hexStringToUIColor(hex: "#000000"),
                                 normal:  UIColor.hexStringToUIColor(hex: "#f00a47"))
    }()
}
public struct DefaultGermanResponsibleGamingCSS: GermanResponsibleGamingCSS {
    
    public init() {
        
    }
    
   public var containerBG: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#550D08")
    }()
    
    public var title: TextCSS? = {
        DefaultTextCSS(color: UIColor.white, font: UIFont.boldSystemFont(ofSize: 14))
    }()
    
    public var body: TextCSS? = {
        DefaultTextCSS(color: UIColor.white, font: UIFont.boldSystemFont(ofSize: 13))
    }()
    
    public var continueButton: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.black, font: UIFont.boldSystemFont(ofSize: 15)),
                         selected: UIColor(red: 247/255, green: 206/255, blue: 24/255, alpha: 1.0),
                         normal: UIColor(red: 247/255, green: 206/255, blue: 24/255, alpha: 1.0))
    }()
    
    public var linkColor: UIColor? = {
        UIColor(red: 247/255, green: 206/255, blue: 24/255, alpha: 1.0)
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.clear
    }()
}

public struct DefaultJackpotWidgetCss: JackpotWidgetsCSS {
    
    public var navigationArrowTintColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#EAEAEA")
    }()
    
    
    public var widgetSelectedColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFCC00")
    }()
    
    public var widgetNormalColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#707070")
    }()
    
    public var mustGoJackpot: MustGoJackpotWidgetsCSS? = {
        DefaultMustGoJackpotWidgetCss ()
    }()
    
    public var singleJackpot: JackpotTextCSS? = {
        DefaultSingleJackpotWidgetCss ()
    }()
    
    
    public struct DefaultMustGoJackpotWidgetCss: MustGoJackpotWidgetsCSS {
        
        public var title: TextCSS? = {
            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#D6D6D6"), font: system16Font)
        }()
        
        public var price: TextCSS? = {
            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFCC00"), font: system14Font)
        }()
        
        public var borderColor: UIColor? = {
            UIColor.hexStringToUIColor(hex: "#474747", withAlpha: 0.9)
        }()
        
        public var borderWidth: CGFloat? = {
            1.0
        }()
        
        public var cornerRadius: CGFloat? = {
            return 8.0
        }()
        
        public var backgroundColor: UIColor? = {
            return .black
        }()
    }
    
    public struct DefaultSingleJackpotWidgetCss: JackpotTextCSS {
        
        public var title: TextCSS? = {
            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#D6D6D6"), font: system20Font)
        }()
        
        public var price: TextCSS? = {
            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFCC00"), font: system24Font)
        }()
        
        public var backgroundColor: UIColor? = {
            .black
        }()
        
    }
    
    public var widgetDecoratorBackgroundColor: UIColor? = {
        return .black
    }()
    
    public var multipleWidgetsDecoratorBackgroundColor: UIColor? = {
        return .black
    }()
    
    public var mustGoWidgetDecoratorBackgroundColor: UIColor? = {
        return .black
    }()
    
    public var singleJackpotHeaderCss: RecentlyPlayedViewCSS? = {
        return DefaultRecentlyPlayedViewCSS()
    }()
    
    public var multipleJackpotsHeaderCss: RecentlyPlayedViewCSS? = {
        return DefaultRecentlyPlayedViewCSS()
    }()
    
    public var mustGoJackpotHeaderCss: RecentlyPlayedViewCSS? = {
        return DefaultRecentlyPlayedViewCSS()
    }()
    
}

struct DefaultBingoButtonCSS: BingoButtonCSS {
    
    var titleCss: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#FFFFFF"), font: UIFont(name: "Poppins-Bold", size: 12))
    }()
    
    var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FE368A")
    }()
    
    var cornerRadius: CGFloat? = {
        4.0
    }()
}

public struct DefaultJackpotFusionInfoPopUpCSS: JackpotFusionInfoViewCSS {
    
    public var jackpotFusionInfoViewBackgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#000000").withAlphaComponent(0.4)

    }()
    
    public var jackpotFusionInfoViewContentBackgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }()
    
    public var jackpotFusionInfoViewHeaderBackgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#F3F4F5")
    }()
    
    public var jackpotFusionInfoViewHeaderTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#050505"), font: UIFont.boldSystemFont(ofSize: 17))
    }()
    
    public var jackpotFusionInfoViewCloseButtonCSS: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "#050505"), font: UIFont.systemFont(ofSize: 13)),
                         selected: UIColor.black.withAlphaComponent(0),
                         normal: UIColor.black.withAlphaComponent(0))
    }()
    
    public var jackpotFusionInfoViewCloseButtonBorderColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#303030").withAlphaComponent(0.24)
    }()
    
    public var jackpotFusionInfoViewCloseButtonBorderWidth: CGFloat? = {
        1.0
    }()
    
    public var jackpotFusionInfoViewCloseButtonCornerRadius: CGFloat? = {
        16.0
    }()
    
    public var jackpotFusionInfoViewSeeallButtonCSS: ButtonCSS? = {
        DefaultButtonCSS(title:
                            DefaultTextCSS(color: UIColor.black, font: UIFont.systemFont(ofSize: 13)),
                         selected: UIColor.black.withAlphaComponent(0),
                         normal: UIColor.black.withAlphaComponent(0))
    }()
    
    public var jackpotFusionInfoViewSeeallButtonBorderWidth: CGFloat? = {
        0
    }()
    
    public var jackpotFusionInfoViewSeeallButtonCornerRadius: CGFloat? = {
        6.0
    }()
    
    public var jackpotFusionInfoViewBadgeTitle: TextCSS? = {
        DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "050505"), font: UIFont.systemFont(ofSize: 13))
    }()
    
    public var jackpotFusionInfoViewBadgeBackgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#D6BC684D").withAlphaComponent(0.3)
    }()
    
    public var jackpotFusionInfoViewBadgeButtonCornerRadius: CGFloat? = {
        4.0
    }()
    
    public var backgroundColor: UIColor? = {
        UIColor.hexStringToUIColor(hex: "#000000").withAlphaComponent(0.4)
    }()
    
    public var jackpotFusionInfoViewContentViewCornerRadius: CGFloat? = {
        6.0
    }()

    public var jackpotFusionInfoViewContentFontSize: CGFloat? = {
        13.0
    }()
    
    public var jackpotFusionInfoViewContentFontName: String? = {
        "poppinMedium"
    }()
    
    public var jackpotFusionInfoViewContentFontFileName: String? = {
        "SecondaryLightFont.ttf"
    }()
}
