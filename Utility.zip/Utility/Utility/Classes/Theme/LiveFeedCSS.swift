//
//  LiveFeedCSS.swift
//  Utility
//
//  Created by Naresh Banavath on 10/09/24.
//

import Foundation
public protocol LiveFeedCSS {
    
    var lastResultsTextFont: UIFont? { get set }
    var availableSeatsTextFont: UIFont? { get set }
    var lastResultsValuesFont: UIFont? { get set }
    var availableSeatsAvatarSize: CGFloat? { get set }
    var minBetText: TextCSS? { get set }
    var viewBackgroundColor: UIColor? { get set }
    var viewLayerBackgroundColor: UIColor? { get set }
    var viewOpaqueColor: UIColor? { get set }
        
}
