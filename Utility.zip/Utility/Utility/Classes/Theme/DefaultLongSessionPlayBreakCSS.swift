//
//  DefaultLongSessionPlayBreakCSS.swift
//  Utility
//
//  Created by Gostu Bhargavi on 01/09/22.
//

import Foundation
import UIKit

public struct DefaultLongSessionToastViewCSS: TakeAPlayBreakToastViewCSS {
    
    public init() {
        
    }
    
    public var descriptionCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.black, font: UIFont.systemFont(ofSize: 16))
    }()
    
    public var titleCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.black, font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var showLaterButtonCSS: ButtonCSS? = {
        DefaultButtonCSS(
            title: DefaultTextCSS(color: UIColor.black,
                                  font: UIFont.boldSystemFont(ofSize: 14)),
            selected: UIColor.clear,
            normal: UIColor.clear)
    }()
    
    public var takeABreakButtonCSS: ButtonCSS? = {
        DefaultButtonCSS(
            title: DefaultTextCSS(color: UIColor.black,
                                  font: UIFont.boldSystemFont(ofSize: 14)),
            selected: UIColor.clear,
            normal: UIColor.hexStringToUIColor(hex: "#70EADF"))
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.white
    }()
    
    public var containerViewCornerRadius: CGFloat? = {
        5.0
    }()
}

public struct DefaultLongSessionPlayBreakSetUpViewCSS: LongSessionBreakSetUpViewCSS {
    
    public init() {
        
    }
    
    public var descriptionCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.black, font: UIFont.boldSystemFont(ofSize: 16))
        
    }()
    
    public var titleCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.black, font: UIFont.boldSystemFont(ofSize: 16))
    }()
    
    public var durationButtonCSS: ButtonCSS? = {
        DefaultButtonCSS(
            title: DefaultTextCSS(color: UIColor.black,
                                  font: UIFont.systemFont(ofSize: 14)),
            selected: UIColor.clear,
            normal: UIColor.clear)
    }()
    
    public var continueButtonCSS: ButtonCSS? = {
        DefaultButtonCSS(
            title: DefaultTextCSS(color: UIColor.black,
                                  font: UIFont.boldSystemFont(ofSize: 14)),
            selected: UIColor.clear,
            normal: UIColor.hexStringToUIColor(hex: "#70EADF"))
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.white
    }()
    
    public var dropDownBorderSelectedColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#4994EC")
    }()
    
    public var dropDownBorderUnSelectedColor: UIColor? = {
        return UIColor.hexStringToUIColor(hex: "#71982D")
    }()
    
    public var containerViewCornerRadius: CGFloat? = {
        5.0
    }()
}

public struct DefaultLongSessionPlayBreakConfirmationViewCSS: LongSessionBreakConfirmationViewCSS {
    public init() {
        
    }
    
    public var descriptionCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.black, font: UIFont.systemFont(ofSize: 16))

    }()
    
    public var titleCSS: TextCSS? = {
        DefaultTextCSS(color: UIColor.black, font: UIFont.boldSystemFont(ofSize: 16))

    }()
    
    public var changeSettingsButtonCSS: ButtonCSS? = {
        DefaultButtonCSS(
            title: DefaultTextCSS(color: UIColor.black,
                                  font: UIFont.boldSystemFont(ofSize: 14)),
            selected: UIColor.clear,
            normal: UIColor.clear)
    }()
    
    public var confirmButtonCSS: ButtonCSS? = {
        DefaultButtonCSS(
            title: DefaultTextCSS(color: UIColor.black,
                                  font: UIFont.boldSystemFont(ofSize: 14)),
            selected: UIColor.clear,
            normal: UIColor.hexStringToUIColor(hex: "#70EADF"))
    }()
    
    public var backgroundColor: UIColor? = {
        return UIColor.white
    }()
    
    public var containerViewCornerRadius: CGFloat? = {
        5.0    }()
}

