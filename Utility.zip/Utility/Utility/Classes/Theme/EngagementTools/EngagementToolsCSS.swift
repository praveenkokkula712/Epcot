//
//  EngagementToolsCSS.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 28/08/24.
//

import Foundation

public protocol EngagementToolsCSS: ViewCSS {
    var freeBadgeText: TextCSS? { get set }
    var freeBadgeBackgroundColor: UIColor? { get set }
    var freeBadgeCornerRadius: CGFloat? { get set }
    var titleText: TextCSS? { get set }
    var expiryText: TextCSS? { get set }
    var spinsLeftText: TextCSS? { get set }
    var backgroundGradientFirstColor: UIColor? { get set }
    var backgroundGradientSecondColor: UIColor? { get set }
    var ctaSize: CGFloat? { get set }
    var height: CGFloat? { get set }
    var cornerRadius: CGFloat? { get set }
    var padding: CGFloat? { get set }
}
