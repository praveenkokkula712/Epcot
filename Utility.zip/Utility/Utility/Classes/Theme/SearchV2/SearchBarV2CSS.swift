//
//  SearchBarV2CSS.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 10/08/23.
//

import Foundation

public protocol SearchBarV2CSS: ViewCSS {
    var height: CGFloat? { get set }
    var cornerRadius: CGFloat? { get set }
    var iconSize: CGFloat? { get set }
    var placeholderColor: UIColor? { get set }
    var title: TextCSS? { get set }
    var clearBackgroundColor: UIColor? { get set }
    var clearSize: CGFloat? { get set }
    var audioButtonSize: CGFloat? { get set }
    var cancelText: TextCSS? { get set }
    var shadowColor: UIColor? { get set }
    var shadowRadius: CGFloat? { get set }
    var micActiveColor: UIColor? { get set }
    var micInactiveColor: UIColor? { get set }
}
