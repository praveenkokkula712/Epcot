//
//  SearchHeaderV2CSS.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 10/08/23.
//

import Foundation

public protocol SearchHeaderV2CSS: ViewCSS {
    var height: CGFloat? { get set }
    var title: TextCSS? { get set }
    var backIconSize: CGFloat? { get set }
}
