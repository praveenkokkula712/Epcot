//
//  SearchV2CSS.swift
//  Utility
//
//  Created by Yemireddi Sateesh on 10/08/23.
//

import Foundation

public protocol SearchV2CSS: ViewCSS {
    var searchBarV2CSS: SearchBarV2CSS? { get set }
    var searchHeaderV2CSS: SearchHeaderV2CSS? { get set }
    var searchSectionsV2CSS: SearchSectionsV2CSS? { get set }
    var searchResultsV2CSS: SearchResultsV2CSS? { get set }
}
