//
//  SearchResultsCSS.swift
//  Utility
//
//  Created by Sindhuja Vedire on 15/09/23.
//

import Foundation

public protocol SearchResultsV2CSS {
    
    var header: TextCSS? { get set }
    var searchResultsBackgroundColor: UIColor? { get set}
    var listItemImageCornerRadius: CGFloat? { get set }
    var listItemTitle: TextCSS? { get set }
    var listItemArrowIcon: CGFloat? { get set }
    var listItemArrowIconColor: UIColor? { get set }
    var iconSize: CGFloat? { get set }
    var noResultsFoundBackgroundColor: UIColor? { get set }
    var title: TextCSS? { get set }
    var subtitle: TextCSS? { get set }
    var categoryTabViewBgColor: UIColor? { get set }
    var selectedTabTextColor: UIColor? { get set }
    var unselectedTabTexColor: UIColor? { get set }
    var selectedTabTextFont: UIFont? { get set }
    var unSelectedTabTextFont: UIFont? { get set }
    var dividerColor: UIColor? { get set }
    var hairLineHeight: CGFloat? { get set }
    var hairLineColor: UIColor? { get set }
    var highlightedSearchTextColor: UIColor? { get set }
}
