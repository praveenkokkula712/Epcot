//
//  SearchSectionsV2CSS.swift
//  Utility
//
//  Created by Sindhuja Vedire on 24/08/23.
//

import Foundation

public protocol SearchSectionsV2CSS: ViewCSS {
    
    var pillsBackgroundColor: UIColor? { get set }
    var recentSearchBackgroundColor: UIColor? { get set }
    var sectionHeaderTitle: TextCSS? { get set }
    var clearAllTitle: TextCSS? { get set }
    var clearAllIconSize: CGFloat? { get set }
    var title: TextCSS? { get set }
    var listTitle: TextCSS? { get set }
    var pillsCornerRadius: CGFloat? { get set }
    var dividerColor: UIColor? { get set }
    var height: CGFloat? { get set }
    var closeIconSize: CGFloat? { get set }
    var searchHistoryIconSize: CGFloat? { get set }
    var arrowIconSize: CGFloat? { get set }
    var stickerBackGroundColor: UIColor? { get set }
    var stickerText: TextCSS? { get set }
    var stickerCornerRadius: CGFloat? { get set }
    var gameTileCss: SearchGameTileCSS? { get set }
}

public protocol SearchGameTileCSS {
    var gameTileCornerRadius: CGFloat? { get set }
    var shadowColor: UIColor? { get set }
    var favouriteButtonIconSelected: String? {get set}
    var favouriteButtonIconUnselected: String? {get set}
    var favouriteButtonTintColor: UIColor? { get set }
    var favouriteButtonBackgroundColor: UIColor? { get set }
    var favouriteIconFontSize: CGFloat? { get set }
    var jpView: JPView? { get set }
}
