//
//  DialogButtonCSS.swift
//  Utility
//
//  Created by Challa Venkata Narasimha Karthik on 04/03/22.
//

import UIKit

public protocol DialogButtonCSS: ButtonCSS {
    
    var backgroundColor: UIColor? { get set }
    
    var cornerRadius: CGFloat? { get set }
    
    var borderWidth: CGFloat? { get set }
    
    var borderColor: UIColor? { get set }
}

public struct DefaultDialogButtonCSS: DialogButtonCSS {
    
    public var backgroundColor: UIColor? = .clear
    
    public var cornerRadius: CGFloat? = nil
    
    public var borderWidth: CGFloat? = nil
    
    public var borderColor: UIColor? = nil
    
    public var selected: UIColor? = UIColor.hexStringToUIColor(hex: "2b2b2b")
    
    public var normal: UIColor? = UIColor.hexStringToUIColor(hex: "2b2b2b")
    
    public var title: TextCSS? = DefaultTextCSS(color: UIColor.hexStringToUIColor(hex: "2b2b2b"),
                                                font: UIFont.boldSystemFont(ofSize: 12))
    
    public init() { }
    
    public init(from response: ButtonCSS?) {
        selected = response?.selected
        normal = response?.normal
        title = response?.title
    }
}
