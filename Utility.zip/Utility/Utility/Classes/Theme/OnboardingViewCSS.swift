//
//  OnboardingViewCSS.swift
//  Utility
//
//  Created by Rajani Bhimanadham on 25/04/23.
//

import Foundation

public protocol OnbordingViewCSS {
    var welcomeScreenCSS: OnbordingWelcomeScreenCSS {get set}
    var journeyViewCSS: OnbordingJourneyViewCSS {get set}
}

public protocol OnbordingCommonCSS: ViewCSS {
    var title: TextCSS? {get set}
    var description: TextCSS? {get set}
    var closeButton: ButtonCSS? {get set}
    var cornerRadius: CGFloat? {get set}
}

public protocol OnbordingWelcomeScreenCSS: OnbordingCommonCSS {
    var getStartedButton: ButtonCSS? {get set}
    var getStartedButtonCornerRadius: CGFloat? {get set}
    var skipButton: ButtonCSS? {get set}
    var skipButtonCornerRadius: CGFloat? {get set}
    var overlayBgColor: UIColor? {get set}
}

public protocol OnbordingJourneyViewCSS: OnbordingCommonCSS {
    var backBtn: ButtonCSS? {get set}
    var journeyCount: TextCSS? {get set}
    var nextBtn: ButtonCSS? {get set}
    var dividerColor: UIColor? {get set}
    var overlayBorderColor: UIColor? {get set}
}
