//
//  GamePremiereCSS.swift
//  Utility
//
//  Created by Sindhuja Vedire on 02/05/24.
//

import Foundation

public protocol GamePremiereCSS {
    
    var overlayBackGroundColor: UIColor? { get set }
    
    var closeIconColor: UIColor? { get set }
    
    var subTitle1Css: TextCSS? { get set }
    
    var subTitle2Css: TextCSS? { get set }
    
    var stickerViewBgColor1: UIColor? { get set }
    
    var stickerViewBgColor2: UIColor? { get set }
    
    var stickerTitleCss: TextCSS? { get set }
    
    var stickerViewCornerRadius: CGFloat? { get set }
    
    var mainTitleCss: TextCSS? { get set }
    
    var stepsTitleCss: TextCSS? { get set }
    
    var stepCircleColor: UIColor? { get set }
    
    var stepNumberCss: TextCSS? { get set }
    
    var stepsTextCss: TextCSS? { get set }
    
    var stepsVerticalLineColor: UIColor? { get set }
    
    var additionalInfoCss: TextCSS? { get set }
    
    var moreInfoTextCss: TextCSS? { get set }
    
    var moreInfoDownArrowColor: UIColor? { get set }
    
    var dividerColor: UIColor? { get set }
    
    var viewFullDetailsTextCss: TextCSS? { get set }
    
    var viewFullDetailsUnderLineColor: UIColor? { get set }
    
    var optedInToasterBgColor: UIColor? { get set }
    
    var optedInTextCss: TextCSS? { get set }
    
    var optedInToasterCornerRadius: CGFloat? { get set }
    
    var toasterBarColor: UIColor? { get set }
    
    var toasterBarWidth: CGFloat? { get set }

    var buttonBorderColor:  UIColor? { get set }
    
    var buttonBorderWidth:  CGFloat? { get set }
    
    var buttonCornerRadius: CGFloat? { get set }
    
    var optInButton: ButtonCSS? { get set }
    
    var playNowButton: ButtonCSS? { get set }
    
    var moreInfoContentBgColor: UIColor? { get set }
    
    var moreInfoContentTextColor: UIColor? { get set }
    
    var moreInfoContentFontName: String? { get set }
    
    var moreInfoContentFontSize: CGFloat? { get set }
    
    var offersIconName: String? {get set}
    
    var offersIconSize: CGFloat? {get set}
    
    var offersIconColor: UIColor? {get set}
    
    var overlayGradientBgColor1: UIColor? { get set }
    
    var overlayGradientBgColor2: UIColor? { get set }
    
    var overlayGradientBgColor3: UIColor? { get set }
    
    var speakerIconColor: UIColor? { get set }
    
    var borderWidth: CGFloat? { get set }
    
    var borderRadius: CGFloat? { get set }
    
    var borderBackgroundColor: UIColor? { get set }
    
    var borderForegroundColor: UIColor? { get set }
    
    var borderStripesAngle: CGFloat? { get set }
    
    var borderBarWidth: CGFloat? { get set }
     
    var borderBarSpacing: CGFloat? { get set }
    
    var isVideoFullScreenEnabled: String? { get set }
    
}
