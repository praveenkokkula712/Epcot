//
//  ProgressBarCSS.swift
//  Utility
//
//  Created by Challa Venkata Narasimha Karthik on 25/03/22.
//  Copyright © 2022 Ivy Comptech. All rights reserved.
//

import UIKit

public protocol ProgressBarCSS: ViewCSS {
    
    var trackTintColor: UIColor? { get set }
    
    var progressTintColor: UIColor? { get set }
}

public struct DefaultProgressBarCSS: ProgressBarCSS {
    
    public var backgroundColor: UIColor? = .clear
    
    public var trackTintColor: UIColor? = UIColor.hexStringToUIColor(hex: "d5d5d5")
    
    public var progressTintColor: UIColor? = UIColor.hexStringToUIColor(hex: "fac031")
}

