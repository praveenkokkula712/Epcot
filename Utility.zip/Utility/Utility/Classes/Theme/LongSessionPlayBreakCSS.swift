//
//  LongSessionPlayBreakCSS.swift
//  Utility
//
//  Created by Gostu Bhargavi on 01/09/22.
//

import Foundation
import UIKit

public protocol TakeAPlayBreakToastViewCSS: ViewCSS {

    var descriptionCSS: TextCSS? { get set }
    
    var titleCSS: TextCSS? { get set }
    
    var showLaterButtonCSS: ButtonCSS? {get set}
    
    var takeABreakButtonCSS: ButtonCSS? {get set}
    
    var backgroundColor: UIColor? {get set}
    
    var containerViewCornerRadius: CGFloat? {get set}

}

public protocol LongSessionBreakSetUpViewCSS: ViewCSS {

    var descriptionCSS: TextCSS? { get set }
    
    var titleCSS: TextCSS? { get set }
    
    var durationButtonCSS: ButtonCSS? {get set}
    
    var continueButtonCSS: ButtonCSS? {get set}
    
    var backgroundColor: UIColor? {get set}
    
    var containerViewCornerRadius: CGFloat? {get set}
    
    var dropDownBorderSelectedColor: UIColor? {get set}
    
    var dropDownBorderUnSelectedColor: UIColor? {get set}

}

public protocol LongSessionBreakConfirmationViewCSS: ViewCSS {

    var descriptionCSS: TextCSS? { get set }
    
    var titleCSS: TextCSS? { get set }
    
    var changeSettingsButtonCSS: ButtonCSS? {get set}
    
    var confirmButtonCSS: ButtonCSS? {get set}
    
    var backgroundColor: UIColor? {get set}
    
    var containerViewCornerRadius: CGFloat? {get set}

}
