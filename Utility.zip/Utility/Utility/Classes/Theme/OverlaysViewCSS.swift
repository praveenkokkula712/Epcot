//
//  OverlaysViewCSS.swift
//  Utility
//
//  Created by Gostu Bhargavi on 31/03/23.
//

import Foundation

public protocol OverlaysViewCSS: ViewCSS {
    
    var title: TextCSS? {get set}
    var description: TextCSS? {get set}
    var ctaButton: ButtonCSS? {get set}
    var containerBackgroundColor: UIColor? {get set}
    var backgroundColor: UIColor? {get set}
    var imageCornerRadius: CGFloat? {get set}
    var imageShadowRadius: CGFloat? {get set}
    var imageShadowColor: UIColor? {get set}
    var cornerRadius: CGFloat? {get set}
    var borderWidth: CGFloat? {get set}
    var borderColor: UIColor? {get set}
    var ctaButtonCornerRadius: CGFloat? {get set}
    var ctaButtonBorderColor: UIColor? {get set}
    var ctaButtonBackgroundColor: UIColor? {get set}
    var titleBackgroundColor: UIColor? {get set}
    var descriptionBackgroundColor: UIColor? {get set}
    var containerShadowColor: UIColor? {get set}
    var containerShadowRadius: CGFloat? {get set}
    var overlayBackgroundColor: UIColor? {get set}
    var cancelButtonCornerRadius: CGFloat? {get set}
    var cancelButtonBorderWidth: CGFloat? {get set}
    var cancelButtonBorderColor: UIColor? {get set}
    var cancelButton: ButtonCSS? {get set}

}
