//
//  UtilityTests.swift
//  UtilityTests
//
//  Created by Sumeet Bajaj on 13/01/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import XCTest
@testable import Utility

class UtilityTests: XCTestCase {

    func testDiskManager() {
        
        Logger.debug(UIDevice.current.diskSizeInBytes(type: .total))
        Logger.debug(UIDevice.current.diskSizeInBytes(type: .free))
        Logger.debug(UIDevice.current.diskSizeInBytes(type: .used))
        
        Logger.debug(UIDevice.current.diskSize(type: .total, units: .useGB))
        Logger.debug(UIDevice.current.diskSize(type: .free, units: .useGB))
        Logger.debug(UIDevice.current.diskSize(type: .used, units: .useGB))
        
        let exception = expectation(description: "asynccall")
        let path = "/Users/sbajaj/Desktop/GameController.zip"
      
       
        FileManager.default.sizeOfItemInBytes(forPath: path) { (size) in
            Logger.debug("Size of Item at: \(path) is: \(size) Bytes")
            exception.fulfill()
        }

        wait(for: [exception], timeout: 10)
    }
}
