//
//  SearchHeaderCSSTests.swift
//  EpcotLobbyTests
//
//  Created by Yemireddi Sateesh on 11/08/23.
//

import XCTest
@testable import EpcotLobby

final class SearchHeaderCSSTests: XCTestCase {
    
    // MARK: Properties
    var sut: SearchHeaderCSS!
    
    // MARK: Setup
    override func setUp() {
        super.setUp()
        sut = SearchHeaderCSS()
    }
    
    // MARK: Teardown
    override func tearDown() {
        super.tearDown()
        sut = nil
    }
    
    // MARK: Tests
    func test_default_styles() {
        XCTAssertNotNil(sut.backgroundColor)
        XCTAssertNotNil(sut.height)
        XCTAssertNotNil(sut.titleFont)
        XCTAssertNotNil(sut.titleColor)
        XCTAssertNotNil(sut.backIconSize)
    }
}
