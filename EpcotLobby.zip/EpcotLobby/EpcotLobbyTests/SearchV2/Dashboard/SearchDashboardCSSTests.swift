//
//  SearchDashboardCSSTests.swift
//  EpcotLobbyTests
//
//  Created by Yemireddi Sateesh on 11/08/23.
//

import XCTest
@testable import EpcotLobby

final class SearchDashboardCSSTests: XCTestCase {
    
    // MARK: Properties
    var sut: SearchDashboardCSS!
    
    // MARK: Setup
    override func setUp() {
        super.setUp()
        sut = SearchDashboardCSS()
    }
    
    // MARK: Teardown
    override func tearDown() {
        super.tearDown()
        sut = nil
    }
    
    // MARK: Tests
    func test_default_styles() {
        XCTAssertNotNil(sut.backgroundColor)
    }
}
