//
//  SearchDashboardViewModelTests.swift
//  EpcotLobbyTests
//
//  Created by Yemireddi Sateesh on 11/08/23.
//

import XCTest
@testable import EpcotLobby

final class SearchDashboardViewModelTests: XCTestCase {

    // MARK: Properties
    var sut: SearchDashboardViewModel!
    
    // MARK: Setup
    override func setUp() {
        super.setUp()
        sut = SearchDashboardViewModel(isVoiceCommand: false)
    }
    
    // MARK: Teardown
    override func tearDown() {
        super.tearDown()
        sut = nil
    }
    
    // MARK: Tests
    func test_ROWSearch() {
        // GIVEN
        let expectation = XCTestExpectation(description: "closeDashBoard")
        let voiceActivated = true
        var dashboardClosed = false
        
        // WHEN
        sut = SearchDashboardViewModel(
            isVoiceCommand: voiceActivated,
            closeDashboard: {
                dashboardClosed = true
                expectation.fulfill()
            }
        )
        sut.closeDashboard()
        wait(for: [expectation], timeout: 1.0)

        // THEN
        XCTAssertFalse(sut.isEpcot)
        XCTAssertTrue(sut.isVoiceCommand)
        XCTAssertTrue(dashboardClosed)
    }

    func test_EpcotSearch() {
        // GIVEN
        let expectation = XCTestExpectation(description: "closeDashBoard")
        let isEpoct = true
        let voiceActivated = true
        var dashboardClosed = false

        // WHEN
        sut = SearchDashboardViewModel(
            isEpcot: isEpoct,
            isVoiceCommand: voiceActivated,
            closeDashboard: {
                dashboardClosed = true
                expectation.fulfill()
            }
        )
        sut.closeDashboard()
        wait(for: [expectation], timeout: 1.0)

        // THEN
        XCTAssertTrue(sut.isEpcot)
        XCTAssertTrue(sut.isVoiceCommand)
        XCTAssertTrue(dashboardClosed)
    }
}
