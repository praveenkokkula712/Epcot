//
//  SearchBarViewModelTests.swift
//  EpcotLobbyTests
//
//  Created by Yemireddi Sateesh on 11/08/23.
//

import XCTest
@testable import EpcotLobby

final class SearchBarViewModelTests: XCTestCase {
    var sut: SearchBarViewModel!
    
    override func setUp() {
        super.setUp()
        sut = SearchBarViewModel()
    }
    
    override func tearDown() {
        super.tearDown()
        sut = nil
    }
    
    func test_simple_search() {
        // GIVEN
        let searchText = "Test"

        // WHEN
        sut.searchText = searchText
        
        // THEN
        XCTAssertTrue(sut.searchText == "Test")
        XCTAssertNotNil(sut.voiceCommandAction)
        XCTAssertNotNil(sut.cancelAction)
    }
}
