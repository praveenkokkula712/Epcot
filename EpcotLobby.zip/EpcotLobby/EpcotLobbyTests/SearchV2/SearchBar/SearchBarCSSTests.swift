//
//  SearchBarCSSTests.swift
//  EpcotLobbyTests
//
//  Created by Yemireddi Sateesh on 11/08/23.
//

import XCTest
@testable import EpcotLobby

final class SearchBarCSSTests: XCTestCase {
    
    // MARK: Properties
    var sut: SearchBarCSS!
    
    // MARK: Setup
    override func setUp() {
        super.setUp()
        sut = SearchBarCSS()
    }
    
    // MARK: Teardown
    override func tearDown() {
        super.tearDown()
        sut = nil
    }
    
    // MARK: Tests
    func test_default_styles() {
        XCTAssertNotNil(sut.backgroundColor)
        XCTAssertNotNil(sut.height)
        XCTAssertNotNil(sut.cornerRadius)
        XCTAssertNotNil(sut.iconSize)
        XCTAssertNotNil(sut.placeholderColor)
        XCTAssertNotNil(sut.titleFont)
        XCTAssertNotNil(sut.titleColor)
        XCTAssertNotNil(sut.clearSize)
        XCTAssertNotNil(sut.audioButtonSize)
        XCTAssertNotNil(sut.cancelFont)
        XCTAssertNotNil(sut.cancelColor)
        XCTAssertNotNil(sut.shadowRadius)
        XCTAssertNotNil(sut.shadowColor)
    }
}
