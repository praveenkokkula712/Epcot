//
//  SearchSectionTests.swift
//  EpcotLobbyTests
//
//  Created by Yemireddi Sateesh on 17/08/23.
//

import XCTest
@testable import EpcotLobby
@testable import Utility

final class SearchSectionTests: XCTestCase {
    var sut: SearchSection!
    
    override func setUp() {
        super.setUp()
        sut = SearchSection()
    }
    
    override func tearDown() {
        super.tearDown()
        sut = nil
    }
    
    func test_empty_section() {
        // THEN
        XCTAssertTrue(sut.title.isEmpty)
        XCTAssertEqual(sut.layoutType, .none)
        XCTAssertEqual(sut.headerType, .text)
        XCTAssertEqual(sut.sectionType, .none)
        XCTAssertEqual(sut.limit, 0)
        XCTAssertEqual(sut.stickers, [])
    }
    
    func test_section_with_data() {
        // GIVEN
        let section = dummySections.first ?? [:]
        let sectionData = SearchSectionData(sectionData: section)
        
        // THEN
        XCTAssertEqual(sectionData.title, "recent_search_title")
        XCTAssertEqual(sectionData.layoutType, 1)
        XCTAssertEqual(sectionData.headerType, 2)
        XCTAssertEqual(sectionData.dataSourceType, 1)
        XCTAssertEqual(sectionData.limit, 10)
        XCTAssertEqual(sectionData.stickers, [])
    }
}
