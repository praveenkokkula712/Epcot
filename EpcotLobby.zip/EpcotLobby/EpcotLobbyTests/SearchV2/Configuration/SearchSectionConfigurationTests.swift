//
//  SearchSectionConfigurationTests.swift
//  EpcotLobbyTests
//
//  Created by Yemireddi Sateesh on 17/08/23.
//

import XCTest
@testable import EpcotLobby
@testable import Utility

final class SearchSectionConfigurationTests: XCTestCase {
    var sut: SearchSectionConfiguration!
    
    override func setUp() {
        super.setUp()
        sut = SearchSectionConfiguration()
    }
    
    override func tearDown() {
        super.tearDown()
        sut = nil
    }
    
    func test_search_configurations() {
        // GIVEN
        let config = SearchConfiguration(
            showCategories: true,
            sections: dummySections
        )
        sut = SearchSectionConfiguration(config: config)

        // THEN
        XCTAssertTrue(sut.showCategories)

        let sections = sut.sections
        XCTAssertTrue(sut.sections.count > 0)

        let firstSection = sections.first
        XCTAssertEqual(firstSection?.title ?? "", "recent_search_title")
        XCTAssertEqual(firstSection?.limit ?? 0, 10)
        XCTAssertEqual(firstSection?.layoutType ?? .none, .pillsWithClose)
        XCTAssertEqual(firstSection?.headerType ?? .text, .textWithClear)
        XCTAssertEqual(firstSection?.sectionType ?? .none, .recentSearch)
        
        let lastSection = sections.last
        XCTAssertEqual(lastSection?.title ?? "", "categories_title")
        XCTAssertEqual(lastSection?.limit ?? 0, 0)
        XCTAssertEqual(lastSection?.layoutType ?? .none, .pills)
        XCTAssertEqual(lastSection?.headerType ?? .text, .text)
        XCTAssertEqual(lastSection?.sectionType ?? .none, .lmtCategoryNames)
    }
}

let dummySections: [[String: Any]] = [
    [
        "title": "recent_search_title",
        "limit": 10,
        "layoutType": 1,
        "headerType": 2,
        "dataSourceType": 1
    ],
    [
        "title": "categories_title",
        "layoutType": 2,
        "dataSourceType": 7
    ]
]
