//
//  EpcotTeasersFilterTest.swift
//  EpcotLobbyTests
//
//  Created by Gostu Bhargavi on 13/06/22.
//


import XCTest
@testable import EpcotLobby

class EpcotTeasersFilterMockData {
    static let notNativeCondition = "TRUE AND Assembly.HasVersion AND NOT NativeApplication.IsNative AND Not Device.IsIOS OR NOT Device.IsTablet AND ((Not User.LoggedIn AND User.LoginName IN ['Batman', 'Joker’]) AND User.Country in [GB, IR, AT]) OR Geolocation.Country=GB or Geolocation.Country IN [GB, IR]"

    static let nativeCondition = "TRUE AND Assembly.HasVersion AND NativeApplication.IsNative AND Device.IsIOS OR NOT Device.IsTablet AND ((User.LoggedIn AND User.LoginName IN ['Batman', 'Joker’]) AND User.Country in [GB, IR, AT]) OR Geolocation.Country=GB or Geolocation.Country IN [GB, IR]"

    static let nativeAndNonLoggedIn = "TRUE AND Assembly.HasVersion AND NativeApplication.IsNative AND Device.IsIOS OR NOT Device.IsTablet AND ((NOt User.LoggedIn AND User.LoginName IN ['Batman', 'Joker’]) AND User.Country in [GB, IR, AT]) OR Geolocation.Country=GB or Geolocation.Country IN [GB, IR]"
    
    static let notValidUser = "TRUE AND Assembly.HasVersion AND NativeApplication.IsNative AND Device.IsIOS OR NOT Device.IsTablet AND ((User.LoggedIn AND false) AND true) OR Geolocation.Country=GB or true "

}

class EpcotTeasersFilterDataTests: XCTestCase {

    func test_IsNotNative() {
        let result = TeasersFilterModel().filterTeasersModel(teasersCondition: EpcotTeasersFilterMockData.notNativeCondition)
        XCTAssertFalse(result)
    }
    
    func test_IsNative() {
        let result = TeasersFilterModel().filterTeasersModel(teasersCondition: EpcotTeasersFilterMockData.nativeCondition)
        XCTAssertTrue(result)
    }
    
    func test_IsNotDeviceIsIOS() {
        let result = TeasersFilterModel().filterTeasersModel(teasersCondition: EpcotTeasersFilterMockData.notNativeCondition)
        XCTAssertFalse(result)
    }
    
    func test_IsDeviceIsIOS() {
        let result = TeasersFilterModel().filterTeasersModel(teasersCondition: EpcotTeasersFilterMockData.nativeCondition)
        XCTAssertTrue(result)
    }
    
    func test_IsNotUserLoggedIn() {
        let result = TeasersFilterModel().filterTeasersModel(teasersCondition: EpcotTeasersFilterMockData.notNativeCondition)
        XCTAssertFalse(result)
    }
    
    func test_IsUserLoggedIn() {
        let result = TeasersFilterModel().filterTeasersModel(teasersCondition: EpcotTeasersFilterMockData.nativeCondition)
        XCTAssertTrue(result)
    }
    
    func test_IsLoggedUserNotValid() {
        let result = TeasersFilterModel().checkUserBasedListConditions(filterCondition: EpcotTeasersFilterMockData.nativeCondition)
        
        XCTAssertEqual(result, EpcotTeasersFilterMockData.notValidUser.lowercased().trimmingCharacters(in: .whitespaces))
    }
    
    func test_IsValidForNonLoggedInUser() {
        let result = TeasersFilterModel().filterTeasersModel(teasersCondition: EpcotTeasersFilterMockData.nativeAndNonLoggedIn)
        XCTAssertTrue(result)
    }
    
    func test_IsLoggedUserValid() {
        let result = TeasersFilterModel().checkUserBasedListConditions(filterCondition: EpcotTeasersFilterMockData.nativeCondition)
        
        XCTAssertEqual(result, EpcotTeasersFilterMockData.notValidUser.lowercased().trimmingCharacters(in: .whitespaces))
    }
    
}

