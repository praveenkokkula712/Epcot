//
//  SiteCoreTeasersViewModel.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 04/05/22.
//

import Foundation
import CasinoAPI
import UIKit

class SiteCoreTeasersViewModel: NSObject {
    
    private var teasersConfig: TeaserDynaconConfig? {
        EpcotLobbyManager.shared?.datasource?.teasersDynaconConfig
    }
    
    override init() {
        super.init()
    }
    
    func fetchSiteCoreDataContent() async throws -> (teasers: [TeaserContentModel]?, banner: TeaserContentModel?, defaultTeaser: TeaserContentModel?) {
        guard let teasersConfig , teasersConfig.isTeaserEnabled else  {
            return (nil, nil, nil)
        }
        do {
            var teasersDataModel = try await SitecoreTeaserContentManager().fetchResponse().get()
            return self.parseReponse(teasersDataModel: teasersDataModel, with: teasersConfig.teasersDisplayLimit)
        } catch {
            return (nil,nil,nil)
        }
    }

    func fetchLocalCache() -> (teasers: [TeaserContentModel]?, banner: TeaserContentModel?, defaultTeaser: TeaserContentModel?) {
        guard let teasersConfig ,
                teasersConfig.isTeaserEnabled,
                let teasersDataModel = SitecoreTeaserContentManager().fetchCachedResponse() else  {
            return (nil, nil, nil)
        }
        return self.parseReponse(teasersDataModel: teasersDataModel, with: teasersConfig.teasersDisplayLimit)
    }
    
    private func parseReponse(teasersDataModel: [TeaserContentModel], with limit: Int) -> (teasers: [TeaserContentModel]?, banner: TeaserContentModel?, defaultTeaser: TeaserContentModel?) {
        var teasersDataModel = teasersDataModel
        let globalTeaser = teasersDataModel.first(where: {$0.attributes?.globalSettingsFlag?.bool ?? false})
        teasersDataModel.removeAll(where: {$0 == globalTeaser})
        let embeddedTeaser = teasersDataModel.first(where: { $0.isEmbeddedTeaser?.bool == true })
        teasersDataModel.removeAll(where: { $0 == embeddedTeaser })
        let filteredTeasers = Array(teasersDataModel.prefix(limit))
        guard let bannerConfig = EpcotLobbyManager.shared?.datasource?.embeddBannerConfig,
              bannerConfig.isEnabled,
              let embeddedBanner = embeddedTeaser else {
            return (filteredTeasers, nil, globalTeaser)
        }
        return (filteredTeasers, embeddedBanner, globalTeaser)
    }
}
