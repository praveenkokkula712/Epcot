//
//  UserJourneyViewModel.swift
//  CasinoAPI
//
//  Created by Sreekanth Reddy Tadi on 03/04/23.
//

import Foundation
import CasinoAPI
import Utility
import Combine
import TrackerClient

public protocol UserOnboardingProtocol {
    func subscribeTo(subject: UserOnboardingPassthroughSubject)
}

public class UserOnboardingViewModel {
        
    private static var instance: UserOnboardingViewModel?
    
    public class weak var shared: UserOnboardingViewModel? {
        self.instance = self.instance ?? UserOnboardingViewModel()
        return self.instance
    }
    
    private lazy var passthroughSubject = {
        UserOnboardingPassthroughSubject()
    }()
    
    private lazy var passthroughSubjectCasinoStories = {
        UserOnboardingPassthroughSubject()
    }()
    
    private var popTipView: PopTip?
    
    public var index = -1 {
        didSet {
            if index == -1 {
                return
            }
            self.setUpPopTipView(of: self.currentUserJourney ?? UserOnboardingJourney())
        }
    }
    
    public var count: Int {
        self.lobbyPageUserJourneys.count
    }
    
    private var userJourneys = {
        [UserOnboardingJourney]()
    }()
    
    private var lobbyPageUserJourneys = {
        [UserOnboardingJourney]()
    }()
    
    public var currentUserJourney: UserOnboardingJourney? {
        guard (!self.lobbyPageUserJourneys.isEmpty) || self.index != -1 else { return nil }
        if self.lobbyPageUserJourneys.count > self.index && self.index != -1 {
            return self.lobbyPageUserJourneys[self.index]
        }
        return nil
    }
    
    func setupData(isSeeAllAvailable: Bool, isJacpotFusionInfoAvailable: Bool) {
        self.userJourneys.removeAll()
        self.lobbyPageUserJourneys.removeAll()
        if let journeys = self.fetchDataContent,
            !journeys.isEmpty {
            self.userJourneys = journeys
            self.lobbyPageUserJourneys = journeys.filter ({
                let type = $0.type
                return type != .voiceSearch && type != .voiceSearchEnhanced && type != .lobbySwitcher && type != .casinoStories
            })
            if !isSeeAllAvailable {
                self.lobbyPageUserJourneys = self.lobbyPageUserJourneys.filter({$0.type != .seeAll})
            }
            if !isJacpotFusionInfoAvailable {
                self.lobbyPageUserJourneys = self.lobbyPageUserJourneys.filter({$0.type != .jackpotFusionInfo})
            }
            self.index = 0
            self.send(with: self.currentUserJourney)
            self.sendUpdateToCasinoStories()
        }
    }
    
    public func subscribeTo(view: UserOnboardingProtocol) {
        view.subscribeTo(subject: passthroughSubject)
    }
    
    public func subscribeToCasinoStories(view: UserOnboardingProtocol) {
        view.subscribeTo(subject: passthroughSubjectCasinoStories)
    }
    
    public func send(with model: UserOnboardingJourney?) {
        guard let model else { return }
        passthroughSubject.send(model)
    }
    @discardableResult
    public func show(with frame: CGRect,
                     model: UserOnboardingJourney,
                     currentPage: Int = (UserOnboardingViewModel.shared?.index ?? 0) + 1,
                     numberOfPages: Int = UserOnboardingViewModel.shared?.count ?? 0,
                     userAction: (() -> Void)? = nil) -> Bool {
        guard var vc = EpcotLobbyManager.shared?.delegate?.lobbyViewController ?? UIApplication.mainWindow.rootViewController else { return false}
        guard (!(self.popTipView?.isVisible ?? false) || model.isDeviceRotated) else { return false}
        if model.isDeviceRotated {
            self.setUpPopTipView(of: model)
        }
        let currentJourney = model
        var direction = currentJourney.tipDirection?.popTipDirection ?? .auto
        switch model.type {
        case .voiceSearch:
            vc = EpcotLobbyManager.shared?.onboardingSearchController ?? vc
            model.markVisited()
        case .voiceSearchEnhanced:
            vc = EpcotLobbyManager.shared?.enhancedSearchController ?? vc
            model.markVisited()
        case .lobbySwitcher:
            vc = EpcotLobbyManager.shared?.onboardingSeeMoreViewController ?? vc
        case .seeAll, .jackpotFusionInfo:
            direction = frame.origin.y > (UIDevice.screenSize.height * 0.5) ? .up : direction
        default: break
        }
        var eventDetails: EpcotEventDetails?
        var userOnboardingView: UserOnBoardingView {
            UserOnBoardingView(journey: currentJourney,
                               currentPage: currentPage,
                               numberOfPages: numberOfPages,
                               clickAction: { action in
                currentJourney.markVisited()
                switch action {
                case .back:
                    self.index -= 1
                    if self.index < 0 {
                        self.popTipView?.hide(forced: true)
                    }
                    self.send(with: self.currentUserJourney)
                    eventDetails = .back
                case .next:
                    self.index += 1
                    if self.index >= self.lobbyPageUserJourneys.count {
                        self.popTipView?.hide(forced: true)
                    }
                    self.send(with: self.currentUserJourney)
                    eventDetails = .next
                case .close:
                    ///for close action/remaining all actions
                    self.index = -1
                    self.send(with: UserOnboardingJourney())
                    self.popTipView?.hide(forced: true)
                    UserDefaults.isJourneyClosed = true
                    eventDetails = .close
                    ETLogger.debug("close clicked")
                case .done:
                    self.index = -1
                    self.send(with: UserOnboardingJourney())
                    self.popTipView?.hide(forced: true)
                    eventDetails = .done
                    ETLogger.debug("Done clicked")
                }
                userAction?()
                if let eventDetails {
                    self.trackEvent(actionEvent: .click,
                                    eventLabel: currentJourney.type.rawValue,
                                    eventDetails: eventDetails.rawValue,
                                    eventPosition: "\(currentPage)")
                }
            })
        }
        popTipView?.show(rootView: userOnboardingView,
                        direction: direction,
                        in: vc.view,
                        from: frame,
                        parent: vc)
        model.markVisited()
        if model.type == .voiceSearch {
            popTipView?.becomeFirstResponder()
        }
        let navController = vc.parent as? UINavigationController
        navController?.setNavigationBarHidden(true, animated: false)
        navController?.isNavigationBarHidden = true
        navController?.isToolbarHidden = true
        self.trackEvent(actionEvent: .load,
                        eventLabel: currentJourney.type.rawValue,
                        eventDetails: GtmLogConstants.GeneralConstants.notApplicable.rawValue,
                        eventPosition: "\(currentPage)")
        return true
    }
    
    public var isVoiceSearchJourneyTobeDisplayed: Bool {
        guard var journey = self.userJourneys.first(where: { $0.type == .voiceSearch && $0.isVisited == false }) else { return false }
        guard var vc = EpcotLobbyManager.shared?.delegate?.lobbyViewController ?? UIApplication.mainWindow.rootViewController else { return false}
        guard (!(self.popTipView?.isVisible ?? false)) else { return false}
        return true
    }
    
    public func updateViewsOnRotation() {
        if var currentUserJourney {
            currentUserJourney.updateDeviceRotateValue()
            self.send(with: currentUserJourney)
        }
    }
    
    @discardableResult
    public func show(with frame: CGRect,
                     of type: UserOnboardingJourneyType,
                     switcherType:SwitcherCategoryType = .grid,
                     action: (() -> Void)? = nil) -> Bool {
        
        guard var journey = self.userJourneys.first(where: { $0.type == type && $0.isVisited == false }) else { return false }
        if type == .lobbySwitcher {
            let layoutType = switcherType == .grid ? "Grid".localized : "List".localized
            let description = String(format:journey.description?.localized ?? "", layoutType)
            journey = UserOnboardingJourney(uniqueId: journey.uniqueId, title: journey.title, description: description, isPreLogin: journey.isPreLogin, isPostLogin: journey.isPostLogin, showAfterClose: journey.showAfterClose, showAfterSkip: journey.showAfterSkip, tipDirection: journey.tipDirection)
        }
        return self.show(with: frame, model: journey, currentPage: 1, numberOfPages: 1, userAction: action)
    }
    
    func journey(with type: UserOnboardingJourneyType) -> UserOnboardingJourney? {
        return self.userJourneys.first(where: { $0.type == type && $0.isVisited == false })
    }
}

extension UserOnboardingViewModel {
    
    public func setUpPopTipView(of type: UserOnboardingJourney) {
        let prevPopView = self.popTipView
        self.popTipView = PopTip()
        popTipView?.shouldShowMask = true
        popTipView?.shouldCutoutMask = true
        popTipView?.arrowSize = CGSize(width: 8, height: 4)
        popTipView?.arrowOffset = 4.0
        popTipView?.offset = 14
        /// bubble color should match with journey view bg color
        let css = EpcotLobbyManager.shared?.css.onboardingViewCSS?.journeyViewCSS
        popTipView?.bubbleColor = css?.backgroundColor ?? UIColor.hexStringToUIColor(hex: "#333333")
        popTipView?.cornerRadius = css?.cornerRadius ?? 4.0
        popTipView?.edgeMargin = 20
        popTipView?.shouldDismissOnTap = false
        popTipView?.shouldDismissOnTapOutside = false
        popTipView?.shouldDismissOnSwipeOutside = false
        popTipView?.shouldConsiderCutoutTapSeparately = false
        popTipView?.entranceAnimation = .none
        popTipView?.exitAnimation = .none
        popTipView?.maskColor = .clear
        popTipView?.cutoutPathGenerator = { from in
            UIBezierPath(roundedRect: from.insetBy(dx: type.cutOutInset ?? 0.0, dy: type.cutOutInset ?? 0.0), byRoundingCorners: .allCorners, cornerRadii: CGSize(width: type.cutOutRadius ?? 0.0, height: type.cutOutRadius ?? 0.0))
        }
        DispatchQueue.main.async {
            prevPopView?.hide(forced: true)
        }
    }
    
    public func hidePopTipViewIfAny() {
        self.popTipView?.hide(forced: true)
    }
}

extension UserOnboardingViewModel {
    
    var newUserOnboardingJourneys : UserOnboardingJourneys? {
        EpcotLobbyManager.shared?.datasource?.didRequestForUserOnboardingJourneys
    }
    
    private var fetchDataContent: [UserOnboardingJourney]? {
        let isEpcotEnabled = CasinoCSS.lobby?.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false
        if isEpcotEnabled { return nil }
        ///dynacon journeys
        guard let userJourneys = self.newUserOnboardingJourneys, userJourneys.enableNewUserJourney else { return nil }
        
        if var userOnboardingJouneys = userJourneys.items {
            let isLoggedIn = EntainContext.user?.isLoggedIn() ?? false
            userOnboardingJouneys = userOnboardingJouneys.reduce(into: [UserOnboardingJourney]()) { partialResult, journey in
                ///prelogin/postlogin user journey filter
                ///user visited or not filter
                guard !journey.isVisited else { return }
                if isLoggedIn {
                    if journey.isPostLogin, journey.type.isAvailable {
                        partialResult.append(journey)
                    }
                } else {
                    if journey.isPreLogin, journey.type.isAvailable, (UserDefaults.userLoggedInCount == 0) {
                        partialResult.append(journey)
                    }
                }
            }
            let userJourneyWelcomeAction = UserOnboardingWelcomeAction(rawValue: UserDefaults.userJourneyWelcomeAction)
            let userLoggedInCount = UserDefaults.userLoggedInCount
            switch userJourneyWelcomeAction {
            case .started:
                userOnboardingJouneys = userOnboardingJouneys.filter { journey in
                    if UserDefaults.isJourneyClosed {
                        if journey.showAfterClose {
                            return !journey.isVisited && (userLoggedInCount == journey.nextLoginCount || userLoggedInCount == journey.loginCount)
                        } else {
                            return !journey.isVisited && userLoggedInCount == journey.loginCount
                        }
                    } else {
                        return !journey.isVisited && userLoggedInCount == journey.loginCount
                    }
                }
            case .close, .skip:
                userOnboardingJouneys = userOnboardingJouneys.filter { journey in
                    return !journey.isVisited && journey.showAfterClose && (userLoggedInCount == journey.nextLoginCount || userLoggedInCount == journey.loginCount)
                }
            default: break
            }
            return userOnboardingJouneys
        }
        return nil
    }
}
extension UserOnboardingJourneyType {
    var isAvailable:Bool {
        switch self {
        case .search:
            let isBottomSearchEnabled = EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .searchButtonEnabled) ?? false
            return isBottomSearchEnabled
            
        case .seeAll:
            let isSeeAllViewAvailable = EpcotLobbyManager.shared?.isSeeAllViewAvailableForOnboarding ?? false
            return isSeeAllViewAvailable
        default:
            return true
        }
    }
}

///Casino Gaming Stories
extension UserOnboardingViewModel {
    
    func sendUpdateToCasinoStories() {
        if let journeyCasinoStories = self.journey(with: .casinoStories) {
            passthroughSubjectCasinoStories.send(journeyCasinoStories)
        }
    }
    
}
