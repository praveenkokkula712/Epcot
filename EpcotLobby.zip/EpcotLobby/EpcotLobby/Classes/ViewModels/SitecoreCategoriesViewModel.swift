//
//  SotecoreCategoriesViewModel.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 07/04/22.
//

import Foundation
import CasinoAPI
import UIKit

class SiteCoreCategoriesViewModel {
    
    private let defaultSitecoreCategoryId = "Default"
    
    private var categories: [String]
    ///to get category name based on categoryId
    var onRequestCategoryName: ((_ categoryId: String) -> String)?
    
    ///Call back for game count based on sticker ID
    var gamesCountHandler: ((_ categoryId: String ,_ item: String) -> Int?)?
    
    private var defaultItems : (subNavigationItems: SubNavigationItems, burgerMenuItems: BurgerMenuItems ) {
        ([.categories: defaultSubNavigationItems],[.featured: (defaultSubNavigationItems, Localize.forYou)])
    }
    
    var defaultSubNavigationItems: [EntainSiteCoreItem] {
        return self.categories.reduce(into: [EntainSiteCoreItem]()) { partialResult, categoryId in
            let title = self.onRequestCategoryName?(categoryId) ?? ""
            let item = EntainSiteCoreItem(title: title)
            let params = EntainParameters(id: categoryId)
            item.parameters = params
            partialResult.append(item)
        }
    }
    
    init(categories: [String]) {
        self.categories = categories
    }
    
    func fetchSiteCoreItems() -> (subNavigationItems: SubNavigationItems?,
                                               burgerMenuItems: BurgerMenuItems?) {
        
        var subNavItems: SubNavigationItems?
        var burgerItems: BurgerMenuItems?
        
        if let burgerMenuItems = POSAPI.shared?.burgerMenu {
            for item in burgerMenuItems {
                if item.type == .burgerMenu {
                    let burgerMenuItems = self.parseBurgerMenuItems(item)
                    burgerItems = burgerMenuItems
                }
            }
        }
        if let items = POSAPI.shared?.subNavigationMenu {
            for item in items {
                let subNavigationItems = self.parseSubNavigationItems(item)
                subNavItems = subNavigationItems
            }
        }
        return (subNavItems,burgerItems)
    }
    
    //Burger menu item configurations
    private func parseBurgerMenuItems(_ item: EntainSiteCoreMenuItemModel) -> BurgerMenuItems {
        var result = [EpcotMenuSection : ([EntainSiteCoreItem], String)]()
        
        let catgoriesDict = self.categories.reduce(into: [:]) { partialResult, categoryId in
            partialResult[categoryId] = self.onRequestCategoryName?(categoryId)
        }
        
        if let featuredMenuItem = item.menuItem[.orderFeatured]?.getEntainSiteCoreItems(from: catgoriesDict),
            let siteCoreItems = featuredMenuItem.siteCoreItem {
            result[.featured] = (siteCoreItems, featuredMenuItem.title ?? Localize.featured)
        }
        
        if let forYouItem = item.menuItem[.forYou]?.getEntainSiteCoreItems(from: catgoriesDict,
                                                                           type: Localize.forYou),
            let siteCoreItems = forYouItem.siteCoreItem {
            result[.foryou] = (siteCoreItems, forYouItem.title ?? Localize.forYou)
        }
            
        if let inAppMenuItem = item.menuItem[.apps],
            let inAppItems = inAppMenuItem.items {
            result[.appAds] = (inAppItems, inAppMenuItem.title ?? "")
        }
        
        if let headerBarItem = item.menuItem[.headerBar],
            let params = headerBarItem.parameters {
            let title = headerBarItem.title ?? Localize.casino
            let entainItem = EntainSiteCoreItem(title: title, image: nil, parameters: params, isSelected: false)
            result[.headerBar] = ([entainItem],title)
        }
        return result
    }
    
    // Sub navigation items configurations.
    private func parseSubNavigationItems(_ item: EntainSiteCoreMenuItemModel) -> SubNavigationItems? {
        var subNaviagationItems = [SubNavigationType: [EntainSiteCoreItem]]()
        
        if let subNavigationMenuItem = item.menuItem[.categories],
            let subNavigationCategories = subNavigationMenuItem.items {
            var subCategories = self.categories.reduce(into: [EntainSiteCoreItem]()) { partialResult, categoryId in
                let title = self.onRequestCategoryName?(categoryId) ?? ""
                if let item = subNavigationCategories.first(where: {$0.parameters?.id == categoryId}) {
                    item.title = title
                    if item.parameters?.shouldDisplayGamesCount ?? false,
                        let stickerID = item.parameters?.stickerID,
                        let count = self.gamesCountHandler?(categoryId,stickerID) {
                        item.parameters?.updateStickerGamesCount(with: count)
                    }
                    partialResult.append(item)
                } else if let defaultItem = subNavigationCategories.first(where: {$0.parameters?.id == kDefaultCategory}) {
                    if let params = defaultItem.parameters {
                        let entainParams = EntainParameters(id: categoryId,
                                                            nativeActionCategory: params.nativeActionCategory,
                                                            nativeActionUrl: params.nativeActionUrl,
                                                            description: params.description,
                                                            iconCss: params.iconCss,
                                                            textCss: params.textCss,
                                                            viewCss: params.viewCss)
                        var entainImage: EntainImage?
                        if let image = defaultItem.image {
                            entainImage = image
                        }
                        let entainItem = EntainSiteCoreItem(title: title, image: entainImage, parameters: entainParams, isSelected: false)
                        partialResult.append(entainItem)
                    }
                } else {
                    let customItem = EntainSiteCoreItem(title: title)
                    let parameters = EntainParameters(id: categoryId)
                    customItem.parameters = parameters
                    partialResult.append(customItem)
                }
            }
            if EpcotLobbyManager.shared?.css.lobbyheaderViewType == .wheelOfFortuneCategories {
                EpcotLobbyManager.shared?.delegate?.didUpdateWOFCategories(subCategories)
            }
            if let isExtendedCategoriesFetchEnabled = EntainContext.app?.isExtendedCategoriesFetchEnabled, isExtendedCategoriesFetchEnabled, let extendedSubCategories = item.menuItem[.extendedCategories]?.items, !extendedSubCategories.isEmpty {
                let sortedCategories = extendedSubCategories.sorted(by: {($0.parameters?.nativeIconPosition ?? -1) < ($1.parameters?.nativeIconPosition ?? -1)})
                sortedCategories.forEach { item in
                    if let categoryId = item.parameters?.id, !categoryId.isEmpty,
                       (categoryId == kLmcRecentlyPlay || categoryId == kLmcFavourites) {
                        if let nativeItemIndex = subCategories.firstIndex(where: {$0.parameters?.id == categoryId}), let position = item.parameters?.nativeIconPosition {
                            if position < subCategories.count && position > 0 {
                                subCategories.move(fromOffsets: [nativeItemIndex], toOffset: position)
                            }
                        }
                    } else {
                        var item = item
                        item.title = item.title?.displayName()
                        if let position = item.parameters?.nativeIconPosition,
                            (position < subCategories.count && position > 0) {
                            subCategories.insert(item, at: position )
                        } else {
                            subCategories.append(item)
                        }
                    }
                }
            }
            subNaviagationItems[.categories] = subCategories
        }
        
        if let webCategories = item.menuItem[.webCategories], let webItems = webCategories.items {
            subNaviagationItems[.webCategories] = webItems
        }
        return subNaviagationItems
    }
}
