//
//  UserJourney+Tracker.swift
//  EpcotLobby
//
//  Created by Santhosh Kodadi on 08/05/23.
//

import TrackerClient
import Utility

extension UserOnboardingViewModel {
    func trackEvent(actionEvent: EpcotEventAction,
                    eventLabel: String,
                    eventDetails: String,
                    eventPosition: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.user_onboarding.rawValue,
                                     actionEvent: actionEvent.rawValue,
                                     labelEvent: eventLabel,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: eventDetails,
                                     positionEvent: eventPosition)
            let event = TrackerEvent(type: EventType.user_onboarding, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}
