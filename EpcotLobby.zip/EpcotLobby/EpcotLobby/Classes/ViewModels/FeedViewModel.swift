//
//  FeedViewModel.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 31/03/22.
//

import Foundation
import CasinoAPI
import CasinoGames
import Utility
import Combine
import ConfigModule

/// Class: FeedViewModel, will do the fetching of LMT operation and updates the data. It will also provide the LMT information to the views which binds to this viewModel class.
final class FeedViewModel: CleanProtocol {
    
    // MARK: -  Private variables
    @Atomic private(set) var feedModel: Feed?
    private var jackpotAPITimer: DispatchTimer?
    private var liveAPITimer:  Publishers.Autoconnect<Timer.TimerPublisher>?
    private var timerCancellable: AnyCancellable?
    private var jpPoolService: JPGroupPoolService?
    
    var refreshLobby = CurrentValueSubject<Bool, Never>(true)
    var refreshJackpotTiles = CurrentValueSubject<[JackpotTile]?, Never>(nil)

    /// returns boolean value if the layout type is of latest grid and latest list views as well as should display value for recently played view enabled or not in dynacon.
    var isRPGamesFetchEnabled: Bool {
        EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .recentlyPlayedGamesView) ?? false
    }
    
    var isFavouriteFetchEnabled: Bool {
        EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .favouriteGamesView) ?? false
    }
    
    var isPlayerStatsFetchEnabled: Bool {
        EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .playerStatsView) ?? false
    }
    
    var categoryIds: [String]? {
        get{
            var categoryIdList = self.feedModel?.lobbyFeedObj?.categoryIds
            if EntainContext.user?.isLoggedIn() ?? false {
                if self.isRPGamesFetchEnabled, !(self.recentlyPlayedGames?.isEmpty ?? true)  {
                    categoryIdList?.append(kLmcRecentlyPlay)
                }
                if let favGames = self.favouriteGames, !favGames.isEmpty {
                    categoryIdList?.append(kLmcFavourites)
                }
            }
            return categoryIdList
        }
        set {
            newValue
        }
    }
    
    var gameImageSuffix: String {
        let isKycNeeded = DynaconAPIConfiguration.shared?.posAppConfig?.features?.isKycVerificationNeeded ?? false
        let imageSuffix = self.feedModel?.lobbyFeedObj?.gameIconImageSuffix ?? ""
        return isKycNeeded ? imageSuffix : ""
    }
    
    /// Will provide the first category name to be displaying purpose under searh bar as suggestion
    var firstCategory: String {
        self.categoryIds?.first ?? ""
    }
    /// Will provide the first category games list fetched from LMT response
    var homeCategoryGames: [Game]? {
        let firstCategory = self.categoryIds?.first ?? ""
        return self.getGames(for: firstCategory)
    }
    
    /// Will provide the Recently Played games fetched based on the user details.
    var recentlyPlayedGames: [Game]? {
        self.feedModel?.lobbyFeedObj?.rpGames
    }
    
    /// Will provide the favourite games fetched based on the user details.
    var favouriteGames: [Game]? {
        self.feedModel?.lobbyFeedObj?.favouriteGames
    }
    
    /// Will provide the Live Casino games fetched from LobbyType LiveCasino.
    var liveCasinoGames: [Game]? {
        self.feedModel?.lobbyFeedObj?.liveCasinoGames
    }
    
    /// returns the first game name from first category games list for search suggestion purpose.
    var firstGameName: String {
        let fistCategoryGame = self.homeCategoryGames?.first?.game ?? ""
        let firstGameMetata: GameMetaData? = self.feedModel?.lobbyFeedObj?[fistCategoryGame]
        return firstGameMetata?.name ?? ""
    }
    
    var vendorGames: [String: [String]] {
        self.feedModel?.lobbyFeedObj?.vendorGames ?? [:]
    }

    var vendorGameIds: [String: Int] {
        self.feedModel?.lobbyFeedObj?.vendorGameIds ?? [:]
    }
    
    var isHTMLGamesEnabled: Bool { DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.liveCasinoLMTConfig?.isHTMLGamesEnabled ?? false
    }
    
    var didUpdateJackpotAmount: (() -> Void)?
    var didUpdateLiveFeedData: (([String: LiveCasinoFeed]) -> Void)?

    private var isPlayerStatsDataAvailable: Bool {
        guard EntainContext.user?.isLoggedIn() ?? false else { return false }
        return !(self.feedModel?.lobbyFeedObj?.monthlyStats?.isEmpty ?? false) ||
        !(self.feedModel?.lobbyFeedObj?.weeklyStats?.isEmpty ?? false)
    }
    
    /// Method will remove all instances for feed view model, delegate and Jackpot timer values.
    func clean() {
        CasinoGamesAccessor.instance?.cancelFeedService()
        self.stopJackpotTimer()
        self.stopFeedTimers()
        self.didUpdateJackpotAmount = nil
        self.jpPoolService?.cancel()
        self.jpPoolService = nil
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        ETLogger.debug("Deintialized Feed View model")
    }
    
    func fetchCachedResponse() -> Feed? {
        let feed = CasinoGamesAccessor.instance?.fetchCachedFeed()
        self.feedModel = nil
        self.feedModel = feed
        self.updateRecentlyPlayedCachedGames()
        self.updateFavouritesCachedGames()
        self.startFeedTimers()
        return self.feedModel
    }
    
    private func updateRecentlyPlayedCachedGames() {
        let isLoggedIn = EntainContext.user?.isLoggedIn() ?? false
        guard isLoggedIn else {
            return
        }
        if self.isRPGamesFetchEnabled,
            let games = RecentlyPlayedService().fetchCachedGames() {
            self.feedModel?.lobbyFeedObj?.updateRecentlyPlayedGames(with: games)
        }
    }
    
    private func updateFavouritesCachedGames() {
        let isLoggedIn = EntainContext.user?.isLoggedIn() ?? false
        guard isLoggedIn else {
            return
        }
        if self.isFavouriteFetchEnabled,
            let games = FavouriteService().fetchCachedGames() {
            self.feedModel?.lobbyFeedObj?.updateFavouriteGames(with: games)
        }
    }
    
    // MARK: Lobby API
    func refreshLobbyMetaData() async throws -> (error:Error?,isLoadingNeeded: Bool) {
        do {
            guard let response = try await CasinoGamesAccessor.instance?.fetchFeed(refresh: true) else {
                throw "Feed Not found".localizedDescription
            }
            if !response.1 {
                try await self.updateUserBasedGames()
                return (nil, response.1 || self.isPlayerStatsDataAvailable)
            }
            if let feed = response.0 {
                try await self.onFinishLobbyRequest(model: feed)
                refreshLobby.send(true)
            }
            return (nil,true)
        } catch {
            ETLogger.debug(error.localizedDescription)
            return (error,true)
        }
    }
    
    /// Method will pass the information to view and updates the LMT data as per the views convienience.
    /// - Parameter model: Feed response fetched from LMT
    private func onFinishLobbyRequest(model:Feed?) async throws {
        self.feedModel = nil
        self.feedModel = model
        try await self.updateUserBasedGames()
    }
    
    private func updateUserBasedGames() async throws {
        let isLoggedIn = EntainContext.user?.isLoggedIn() ?? false
        guard isLoggedIn else {
            self.startFeedTimers()
            return
        }
        try? await self.refreshUserGamesIfNeeded()
        try? await self.fetchAndUpdateFavouriteGames()
        try? await self.fetchAndUpdatePlayerStatsGames()
        self.startJackpotTimer()
        self.startFeedTimers()
    }
    
    /// Method will refresh the user related info of games history like recently played favourite games.
    func refreshUserGamesIfNeeded() async throws {
        self.stopFeedTimers()
        /// Checking for Recently Played Games
        if self.isRPGamesFetchEnabled {
            try await self.fetchAndUpdateRecentlyPlayedGames()
        }
        if let cachedGames = CasinoGamesAccessor.instance?.cachedGames, !cachedGames.isEmpty {
            self.feedModel?.lobbyFeedObj?.updateLocalDownloadGames(isHTMLGamesEnabled: isHTMLGamesEnabled, with: cachedGames)
        }
    }
    
    /// Method will fetch the Recently Played games as per the user sso key
    func fetchAndUpdateRecentlyPlayedGames() async throws {
        guard let rpGames = try? await RecentlyPlayedService().fetchGames()?
            .games?
            .compactMap({$0.gamevariant}) else {
            return
        }
        self.feedModel?.lobbyFeedObj?.updateRecentlyPlayedGames(with: rpGames)
    }
    
    /// Method will update the feed with the fetched games from Recently played API service
    /// - Parameter list: list of game variant names in string format.
    func updateRecentlyPlayedGames(onLoginRefresh: Bool = false, with list: [String]) {
        let result = self.feedModel?.lobbyFeedObj?.updateRecentlyPlayedGames(with: list) ?? false
        if result && !onLoginRefresh {
            Feed.postNotification(notification: .didUpdateRecentlyPlayed)
        }
    }
    
    /// Method will update the feed with the fetched games from Favourites API service
    func fetchAndUpdateFavouriteGames() async throws {
        guard self.isFavouriteFetchEnabled else { return }
        guard let games = try? await FavouriteService().fetchGames()?.favourites else {
            return
        }
        self.feedModel?.lobbyFeedObj?.updateFavouriteGames(with: games)
    }
    
    func fetchAndUpdatePlayerStatsGames() async throws {
        guard self.isPlayerStatsFetchEnabled else { return }
        async let monthlyGames = try? PlayerStatsService().fetchGames(with: .monthly)
        async let weeklyGames = try?  PlayerStatsService().fetchGames(with: .weekly)
        let minimumMultiplierBet = DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.playerStatsConfigurations?.minimumMuliplierBet ?? 0
        
        if let weeklyGames = await weeklyGames,
           let weekGames = weeklyGames.winnerMultiplierDetails?.filter({ $0.betAmount ?? 0 > minimumMultiplierBet }), !weekGames.isEmpty {
            let games = weekGames.sorted(by: {$0.multiplier ?? 0 > $1.multiplier ?? 0})
            self.feedModel?.lobbyFeedObj?.updateGames(of: .weekly, with: games)
        }
        
        if let monthlyGames = await monthlyGames,
           let monthGames = monthlyGames.winnerMultiplierDetails?.filter({ $0.betAmount ?? 0 > minimumMultiplierBet }), !monthGames.isEmpty {
            let games = monthGames.sorted(by: {$0.multiplier ?? 0 > $1.multiplier ?? 0})
            self.feedModel?.lobbyFeedObj?.updateGames(of: .monthly, with: games)
        }
    }
    
    @discardableResult
    func updateFavouriteState(with state: Bool, for game: String) async throws -> FavouriteState {
        var currentState: FavouriteState = state ? .selected : .unselected
        let response = try await FavouriteService().update(state: state, gameId: game)
        ETLogger.debug(response)
        switch response {
        case .success(_): break
        case .failure(let error):
            currentState = !currentState
            Toast.show(message: "Failed updating favourite state.", type: .normal)
        }
        self.feedModel?.lobbyFeedObj?.updateFavouiteGame(with: currentState, game)
        if let favGames = self.feedModel?.lobbyFeedObj?.favouriteGames, favGames.isEmpty {
            self.categoryIds?.removeAll(where: { $0 == kLmcFavourites })
        }
        return currentState
    }
    
    // Use to update Favourite State locally only for Search V2
    func updateFavouriteStateInFeed(with state: Bool, for game: String) {
        self.feedModel?.lobbyFeedObj?.updateFavouiteGame(with: state ? .selected : .unselected, game)
    }
    
    // MARK: - Initializing API Timers
    func startFeedTimers() {
        guard self.feedModel != nil else { return }
        self.startJackpotTimer()
        self.startLiveAPITimer()
    }
    
    //MARK: - Stopping API Timer.
    func stopFeedTimers() {
        self.stopJackpotTimer()
        self.stopLiveAPITimer()
    }
    
    /// will update the jackpot info from Cache.
    func updateJackpotInfoFromCache() {
        if let response = JPGroupPoolService().fetchCachedResponse {
            self.onFinishJackpotAPI(model: response)
        }
        self.refreshJackpotTiles.send(self.feedModel?.lobbyFeedObj?.updatedJackpotTiles)
    }
    
    /// Method will post the notification related to Local game download status.
    /// - Parameters:
    ///   - game: Game variant name
    ///   - value: Boolean status whether the game is downloaded or removed.
    func didUpdatedGameInCache(game: String, value: Bool) -> Bool {
        self.feedModel?.lobbyFeedObj?.updateLocalCache(isHTMLGamesEnabled: isHTMLGamesEnabled, with: game, state: value) ?? false
    }
    
    /// will provide the information of the local game other than Favourite and Recently Play status
    /// - Parameter game: Game variant name
    /// - Returns: Local Games Info includes (gameVariantName, gameMetadata, Local download state, jackpotgamePrice, imagePath).
    func getLocalGameInfo(with game: String) -> LocalGameInfo? {
        self.feedModel?.lobbyFeedObj?[game]
    }
    
    /// Method will provide the Games object list based on the category name
    /// - Parameter category: Category ID from LMT response.
    /// - Returns: Games Object list
    func getGames(for categoryId: String) -> [Game]? {
        if categoryId == kLmcRecentlyPlay {
            return self.recentlyPlayedGames
        }
        if categoryId == kLmcFavourites {
            return self.favouriteGames
        }
        if categoryId == kLmcLiveCasino {
            return self.liveCasinoGames
        }
        
        return self.feedModel?.lobbyFeedObj?[categoryId]
    }
    
    /// Method will provide the game Metadata based on game variant name.
    /// - Parameter gameVariant: Game variant name which unique for any game.
    /// - Returns: GameMetadata object.
    func getGameMetadata(for gameVariant: String) -> GameMetaData? {
        self.feedModel?.lobbyFeedObj?[gameVariant] ?? GameMetaData(game: gameVariant)
    }
    
    /// Method will provide the game Metadata based on game variant name.
    /// - Parameter gameVariant: Game variant name which unique for any game.
    /// - Returns: GameMetadata object.
    func getMostSearchedGameMetadata(for gameVariant: String) -> GameMetaData? {
        self.feedModel?.lobbyFeedObj?[gameVariant]
    }
    
    /// Method will provide the list of Game objects based on the search string
    /// - Parameters:
    ///   - searchString: search string entered by user
    ///   - checkVendors: whether search string games to be filtered by vendor name or not
    /// - Returns: Game object list.
    func getSearchedGames(with searchString: String, checkVendors: Bool = false) -> [Game]? {
        var games: [Game] = [Game]()
        if searchString.lowercased() == self.getCategoryName(for: kLmcRecentlyPlay).lowercased() {
            if let rpGames  = self.recentlyPlayedGames {
                games.append(contentsOf: rpGames)
            }
        }
        if searchString.lowercased() == self.getCategoryName(for: kLmcFavourites).lowercased() {
            if let favouriteGames  = self.favouriteGames {
                games.append(contentsOf: favouriteGames)
            }
        }
        
        if searchString.lowercased() == self.getCategoryName(for: kLmcLiveCasino).lowercased(),
            let liveGames = self.feedModel?.lobbyFeedObj?.liveCasinoGames  {
            games.append(contentsOf: liveGames)
        }
        
        //Section Vendor Games
        if checkVendors {
            let sectionVendorGames = self.vendorGames.reduce(into: [Game]()) { partialResult, vendor in
                let vendorName = vendor.key
                let vendorGames = vendor.value
                if vendorName.lowercased().contains(searchString.lowercased()) {
                    if let _ = self.vendorGameIds[vendorName], !vendorGames.isEmpty {
                        partialResult.append(contentsOf: vendorGames.compactMap({ Game(game: $0) }))
                    }
                }
            }
            if !sectionVendorGames.isEmpty {
                games.append(contentsOf: sectionVendorGames)
            }
        }
        
        if let searchedGames = self.feedModel?.lobbyFeedObj?.getSearchedGames(with: searchString) {
            games.append(contentsOf: searchedGames)
        }
        let filteredGames = games.removingDuplicates(byKey: { $0.game })
        return filteredGames
    }
    
    /// Method will returns the JackpotPrice(String) for the provided game variant name
    /// - Parameter game: game variant name
    /// - Returns: Jackpot price fetched from JackpotAPI service call.
    func getJackpotAmount(for game: String) -> JackpotPrice? {
        self.feedModel?.lobbyFeedObj?[game]
    }
    
    /// Method will returns the state of  the provided game variant name in terms of recently played or not.
    /// - Parameter game: game variant name
    /// - Returns: State of the game variant for that user under Recently played games.
    func getRecentlyPlayedState(for game: String) -> Bool? {
        self.feedModel?.lobbyFeedObj?[game, .recentlyPlayed] ?? false
    }
    
    /// Method will returns the state of  the provided game variant name in terms of locally downloaded or not.
    /// - Parameter game: game variant name
    /// - Returns: State of the game variant for that user under local download games.
    func getLocalDownloadState(for game: String) -> Bool? {
        self.feedModel?.lobbyFeedObj?[game, .localCache] ?? false
    }
    
    /// Will provide the localised category name based on the category ID
    /// - Parameter categoryId: Cateogry ID fetched from LMT response
    /// - Returns: Localised category name.
    func getCategoryName(for categoryId: String, isSubCategory: Bool = false) -> String {
        if categoryId == kLmcRecentlyPlay {
            return Localize.kRecently_Played.displayName(isSubCategory: isSubCategory)
        }
        if categoryId == kLmcFavourites {
            return Localize.kFavouritesTitle.displayName(isSubCategory: isSubCategory)
        }
        if categoryId == kLmcLiveCasino {
            return Localize.kLiveCasinoTitle.displayName(isSubCategory: isSubCategory)
        }
        if let categoryName:CategoryVariant = self.feedModel?.lobbyFeedObj?[categoryId] {
            return categoryName.name.displayName(isSubCategory: isSubCategory)
        }
        return ""
    }
    
        /// Method will returns the sliced games with the provided position to show the embedd banner in between the games.
        /// - Parameters:
        ///   - category: Category ID
        ///   - tillPosition: position which is number of games to be sliced.
        /// - Returns: returns two game arrays after division.
    func getSlicedGames(with category: String, tillPosition: Int) -> ([Game]?, [Game]?)? {
        guard let games = self.getGames(for: category) else {
            return nil
        }
        guard games.count > tillPosition else {
            return (games, nil)
        }
        let preDividedGames = Array(games[0..<tillPosition])
        let postDividedGames = Array(games[tillPosition..<games.count])
        return (preDividedGames, postDividedGames)
    }
    
        /// Method will provide the index of the game variant name inside gametadata array
        /// - Parameter game: Game variant name which unique for any game.
        /// - Returns: Index of the element inside Game metadata object.
    func getIndex(for game: String?) -> Int {
        if let game, let lobbyFeedObj = self.feedModel?.lobbyFeedObj {
            let index: (Int,FeedType) = lobbyFeedObj[game]
            return index.0
        }
        return 0
    }
        /// Method will provide the GameInfo object based on game variant name
        /// - Parameter game: Game variant name
        /// - Returns: GameInfo
    func getGameInfo(with game: String) -> GameInfo? {
        self.feedModel?.lobbyFeedObj?[game]
    }
    
    /// Will provide the list of subCategory ID from LMT
    /// - Parameter category: Category ID for which subcategory list needed.
    /// - Returns: arry of subCategory IDs.
    func getSubCategories(for category: String) -> [SubCategory]? {
        self.feedModel?.lobbyFeedObj?.getSubCategories(for: category)
    }
    
    /// Will provide the games list from a subCategory inside a category.
    /// - Parameters:
    ///   - subCategory: subCategory ID
    ///   - category: Category ID
    /// - Returns: List of games.
    func getSubCategoryGames(for subCategory: String, in category: String) -> [Game]? {
        self.feedModel?.lobbyFeedObj?.getGames(for: subCategory, from: category)
    }

    /// Will provide the games list from a subCategory Route inside a category.
    /// - Parameters:
    ///   - subCategoryRoute: subCategory Route
    ///   - category: Category ID
    /// - Returns: List of games.
    func getSubCategoryRouteGames(for subCategoryRoute: String, in category: String) -> [Game]? {
        self.feedModel?.lobbyFeedObj?.getRouteGames(with: subCategoryRoute, from: category)
    }
    
    /// Method will returns the subCategory based on the subCategory ID and category ID
    /// - Parameters:
    ///   - subCategory: Sub Category ID
    ///   - category: Category ID
    /// - Returns: SubCategory model
    func getSubCategory(for subCategory: String, in category: String) -> SubCategory? {
        self.feedModel?.lobbyFeedObj?.getSubCatgory(with: subCategory, from: category)
    }
    
    /// Will provide the list of subCategories
    /// - Parameter category: Category ID for which the subCateogries list is needed
    /// - Returns: subCategories array.
    func getSubCategoryIdList(for category: String) -> [String]? {
        self.feedModel?.lobbyFeedObj?
            .getSubCategories(for: category)?
            .compactMap({$0.subcategoryid})
    }
    
    func isCasiaCategoryAvailable(for category: String, subCategory: String) -> Bool {
        self.feedModel?.lobbyFeedObj?.isCasiaCategoryAvailable(for: category, subCategory: subCategory) ?? false
    }
    
    func getImmersiveInfo(for game: String, with iconSize: String, isGIFImage: Bool = false) -> ImmersiveGameInfo? {
        guard let localInfo = self.getLocalGameInfo(with: game) else { return nil }

        let isEpcotEnabled =  DynaconAPIConfiguration.shared?.posAppConfig?.features?.enableEpcotFeature ?? false

        let defaultFireImageName = isEpcotEnabled ? "epcothotjackpot.svg" : "hotjackpot.png"
        
        if let json = EpcotLobbyManager.shared?.css.immersiveImagePathJson {
            let deviceType = UIDevice.isIPad() ? "ipad" : "iphone"
            var fireImageFolder = "square"
            if let fireImage = json["fireImagePath"] as? String {
                fireImageFolder =  fireImage
            }
            let fireImageName = DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.jackpotFireIconName ?? defaultFireImageName
            
            if let imageFolderPath = json[iconSize] as? [String: Any],
               var folder = imageFolderPath[deviceType] as? String {
                let imageExtension = isGIFImage ? ".gif" : ".jpg"
                folder += gameImageSuffix
                return (localInfo.imagePath + "/" + folder + "/" + game + imageExtension , localInfo, localInfo.imagePath + "/" + fireImageFolder + "/" + fireImageName)
            }
        }
        let brandDNS = ETCasinoAPI.updatedGameTileDNS ?? "https://casinogames.bwin.com"
        let imagePath = ETCasinoAPI.routes?[ETCasinoAPI.ImagePath] ?? "/htmllobby/images/newlmticons/"
        var folderPath = "supersquare" + self.gameImageSuffix
        return (brandDNS + imagePath + "/" + folderPath + "/" + game + ".jpg" , localInfo, brandDNS + imagePath + "/square/" + defaultFireImageName)
    }
    
    func getListCellBlurImagePath(for game: String) -> String {
        var imageKey = "iphone-blur"
        if UIDevice.isIPad() {
            let currentOrientation = UIDevice.currentOrientation
            switch currentOrientation {
            case .portrait, .portraitUpsideDown:
                imageKey = "ipad-portrait-blur"
            default :
                imageKey = "ipad-landscpae-blur"
            }
        }
        if let localInfo = self.getLocalGameInfo(with: game),
            let json = EpcotLobbyManager.shared?.css.immersiveImagePathJson {
            if let imageFolderPath = json["\(LayoutType.list.rawValue)"] as? [String: Any],
               var folder = imageFolderPath[imageKey] as? String {
                folder += gameImageSuffix
                return (localInfo.imagePath + "/" + folder + "/" + game + ".jpg" )
            }
        }
        let brandDNS = ETCasinoAPI.updatedGameTileDNS ?? "https://casinogames.bwin.com"
        let imagePath = ETCasinoAPI.routes?[ETCasinoAPI.ImagePath] ?? "/htmllobby/images/newlmticons/"
        let folder = "ios" + gameImageSuffix + "/"
        return (brandDNS + imagePath + "/" + folder + game + ".jpg")
    }
    
    func getJackpotBasedGames(for jackpotId: String) -> [Game]? {
        self.feedModel?.lobbyFeedObj?.getGames(for: jackpotId)
    }
    
    func getJackpotIdBasedGames(for jackpotId: String) -> [Game]? {
        if let jpName = self.feedModel?.lobbyFeedObj?.getJackpotName(for: jackpotId) {
            return self.getJackpotBasedGames(for: jpName)
        }
        return nil
    }
    
    func getSubJackpotDetails(for jackpotId: String) -> [SubJackpotDetails]? {
        self.feedModel?.lobbyFeedObj?.getSubJackpotDetails(for: jackpotId)
    }
    
    func getAmountForJackpotId(for jackpotId:String) -> String? {
        self.feedModel?.lobbyFeedObj?.getAmountForJackpotId(for: jackpotId)
    }
    
    public func getAllJackpotAmounts() -> [String: String]? {
        self.feedModel?.lobbyFeedObj?.getAllJackpotAmounts()
    }
    
    public func getGameCount(cateogryId: String, stickerId: String) -> Int? {
        self.feedModel?.lobbyFeedObj?.getGameCount(categoryId: cateogryId,
                                                   stickerId: stickerId)
    }
    
    func getStickerGames(for stickers: [String], limit: Int) -> [Game] {
        self.feedModel?.lobbyFeedObj?.getStickerGames(with: stickers, limit: limit) ?? []
    }
    
    func getRecommendedGames(limit: Int) -> [Game] {
        self.feedModel?.lobbyFeedObj?.getRecommededGames(limit: limit) ?? []
    }
    
    func getCategoryBasedGames(with searchString: String) -> [(String, [Game])] {
        var searchedGames = self.feedModel?.lobbyFeedObj?.getCategoryBasedSearchedGames(with: searchString) ?? []
        var result = [(String, [Game])]()
        searchedGames.forEach { categoryName, games in
            result.append((categoryName.displayName(),games))
        }
        return result
    }
}

//MARK: - Jackpot info update changes
extension FeedViewModel {
    
    // MARK: - Initializing Jackpot API Timer
    private func startJackpotTimer() {
        guard  self.jackpotAPITimer == nil else { return }
        self.refreshJackpotInfo()
        self.jackpotAPITimer =  DispatchTimer(handler: refreshJackpotInfo)
        ETLogger.debug("Starting Jackpot Timer")
    }
    
    /// will refresh the jackpot info.
    private func refreshJackpotInfo() {
        guard self.jpPoolService == nil else { return }
        self.jpPoolService = JPGroupPoolService()
        Task {
            defer {
                self.jpPoolService = nil
            }
            do {
                let response = try await self.jpPoolService?.call()
                self.onFinishJackpotAPI(model: response)
            } catch {
                ETLogger.debug(error.localizedDescription)
            }
        }
    }
    
    /// - Parameter model: Jackpot info fetched from api service.
    private func onFinishJackpotAPI(model: JackpotPoolInfo?) {
        guard let model = model else { return }
        if self.feedModel?.lobbyFeedObj?.updateJackpotFeed(model) ?? false {
            self.refreshJackpotTiles.send(self.feedModel?.lobbyFeedObj?.updatedJackpotTiles)
            self.didUpdateJackpotAmount?()
        }
    }
    
    //MARK: - Stopping Jackpot API Timer.
    private func stopJackpotTimer() {
        guard self.jackpotAPITimer != nil else { return }
        ETLogger.debug("Invalidating Jackpot timer ....")
        self.jackpotAPITimer?.cancel()
        self.jackpotAPITimer = nil
    }
}

//MARK: - Live API  info update changes
extension FeedViewModel {
    
    var liveFeedCasinoConfig: LiveFeedCasinoConfiguration? {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.liveFeedCasinoConfiguration
    }
    
    // MARK: - Initializing Live feed API Timer
    private func startLiveAPITimer() {
        guard  self.liveAPITimer == nil,
               let isEnabled = self.liveFeedCasinoConfig?.isEnabled,
               isEnabled else { return }
        
        fetchLiveFeedInfo()
        
        func fetchLiveFeedInfo() {
            if let vendorNames = liveFeedCasinoConfig?.vendorNames {
                vendorNames.forEach { vendor in
                    self.refreshLiveFeedInfo(with: vendor)
                }
            }
        }
        
        let interval = liveFeedCasinoConfig?.apiFeedInterval ??  30
        let timeInterval: TimeInterval = Double(interval)
        self.liveAPITimer = Timer.publish(every: timeInterval,
                                          on: .main,
                                          in: .common)
        .autoconnect()
        
        self.timerCancellable = self.liveAPITimer?
            .sink {[weak self] _ in
                guard let self = self else {return}
                fetchLiveFeedInfo()
            }
    }
    
    //MARK: - Stopping Live API Timer.
    private func stopLiveAPITimer() {
        guard self.liveAPITimer != nil else { return }
        ETLogger.debug("Invalidating Live API timer ....")
        self.liveAPITimer?
            .upstream
            .connect()
            .cancel()
        self.liveAPITimer = nil
        self.timerCancellable?.cancel()
    }
    
    private func refreshLiveFeedInfo(with vendor: String) {
        let systemLanguage = DynaconAPIConfiguration.shared?.appConfigs?.systemLanguage ?? "en"
        let liveFeedService = LiveFeedCasinoService(vendorName: vendor,
                                                    systemLanguage: systemLanguage,
                                                    channel: liveFeedCasinoConfig?.channel ?? "mobile",
                                                    vipLevel: liveFeedCasinoConfig?.vipLevel ?? "1")
        Task {
            do {
                if let response = try await liveFeedService.call()?.get() as? [LiveAPICasinoFeed] {
                    let liveFeedConfig = DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.liveFeedCasinoConfiguration
                    if let liveFeedData = self.feedModel?.lobbyFeedObj?.updateLiveFeedAPIData(with: response,
                                                                                              config: liveFeedConfig) {
                        if !liveFeedData.isEmpty {
                            self.didUpdateLiveFeedData?(liveFeedData)
                        }
                    }
                }
            } catch {
                ETLogger.debug(error.localizedDescription)
            }
        }
    }
}
