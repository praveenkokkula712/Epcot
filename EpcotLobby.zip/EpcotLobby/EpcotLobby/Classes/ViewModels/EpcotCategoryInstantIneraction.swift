//
//  EpcotCategoryInstantIneraction.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 28/06/23.
//

import Foundation

class EpcotCategoryInstantIneraction: ObservableObject {
    @Published var categoryInteracted = 0.0
    @Published var categoryCloseInteracted = 0.0
    @Published var switcherGridInteracted = 0.0
    @Published var switcherListInteracted = 0.0
    @Published var jackpotTileBackInteracted = 0.0
}
