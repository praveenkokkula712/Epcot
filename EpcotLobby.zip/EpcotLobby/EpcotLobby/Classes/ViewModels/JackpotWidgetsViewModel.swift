//
//  JackpotWidgetsViewModel.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 31/10/22.
//

import Foundation

class JackpotWidgetsViewModel {
    static let shared = JackpotWidgetsViewModel()
    
    private(set) var routeWidgets: [String: NativeWidgetsModel] = [:]
    private(set) var videoRouteWidgets: [String: NativeWidgetsModel] = [:]
    private(set) var jackpotFusionWidgets: [String: NativeWidgetsModel] = [:]
    private(set) var freeSpinsWidgets: [String: NativeWidgetsModel] = [:]
    private(set) var playerStatWidgets: [String: NativeWidgetsModel] = [:]
    private(set) var originalsWidget: [String: NativeWidgetsModel] = [:]
    private(set) var attributes: [String: Any] = [:]
    private(set) var engagementToolsWidgets: [String: NativeWidgetsModel] = [:]

    private init() { }
    
    func getNativeWidgetBasedOnRoute() {
        guard let widgets = POSAPI.shared?.nativeWidgets else { return }
        
        widgets.forEach { model in
            self.attributes[model.routeValue.lowercased()] = model.attributes ?? [:]
        }
        
        let filteredWidgets = widgets.filter {
            ($0.showMustGo?.boolValue ?? false) ||
            ($0.showJackpotWidget?.boolValue ?? false) ||
            !($0.imageOrVideoUrl?.isEmpty ?? true) ||
            ($0.displayFreeSpins ?? false) ||
            ($0.isPlayerStatsEnabled ?? false) ||
            ($0.isBetMgmOriginalsEnabled ?? false)
        }
        guard !filteredWidgets.isEmpty else { return }
        
        self.videoRouteWidgets = [:]
        self.routeWidgets = [:]
        
        let jackpotWidgets = POSAPI.shared?.jackpotWidgets
        
        filteredWidgets.forEach { nativeWidget in
            let routeValue = nativeWidget.routeValue.lowercased()
            if let _ = nativeWidget.imageOrVideoUrl {
                self.videoRouteWidgets[routeValue] = nativeWidget
            }
            //update jackpot widgets in native widget model
            nativeWidget.updateJackpotWidgets(from: jackpotWidgets)
            self.routeWidgets[routeValue] = nativeWidget
            if nativeWidget.isPlayerStatsEnabled ?? false {
                self.playerStatWidgets[routeValue] = nativeWidget
            }
//            if nativeWidget.displayFreeSpins ?? false {
//                self.freeSpinsWidgets[routeValue] = nativeWidget
//            }
            if nativeWidget.isBetMgmOriginalsEnabled ?? false {
                self.originalsWidget[routeValue] = nativeWidget
            }
            // TODO: Engagement Tools - Add associate logic to handle the response.
//            self.engagementToolsWidgets[routeValue] = nativeWidget
        }
    }
    
    func getJackpotFusionWidgets() {
        guard let widgets = POSAPI.shared?.nativeWidgets else { return }
        self.jackpotFusionWidgets = [:]
        widgets.forEach { widget in
            self.jackpotFusionWidgets[widget.routeValue.lowercased()] = widget
        }
    }
    
}
