//
//  EpcotLobby.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 31/03/22.
//

import Foundation
import UIKit
import Utility

public protocol ETEpcotLobby: Lobby {
    
    var isOverlaysOrToastersPresented: Bool? {get set}

        /// Method will start the Epcot lobby with delegate and datasource.
    func set(delegate: EpcotLobbyViewDelegate?, dataSource: EpcotLobbyViewDataSource?)
    
    func cancelFeedService()
    
    func showPlayBreakView(with type: PlayBreakType,duration: String, completion: ((PlaybreakAction) -> Void)?)
    
    func removePlaybreakIfNeeded()
    
    func onLogout()
}

/****************************************************************/
/* Accessor to access instance of EpcotLobby */
/****************************************************************/
public class EpcotLobbyAccessor {    
    public class var instance: ETEpcotLobby? {
        return EpcotLobbyManager.shared
    }
}
