//
//  EpcotLobbyViewDatasource.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 15/06/23.
//

import Foundation
import CasinoGames
import CasinoAPI
import Utility

/****************************************************************/
/* Data source to request data from client */
/****************************************************************/

public protocol EpcotLobbyViewDataSource: LobbyDatasource, CasinoGamesDataSourceOptionals {
    
    func didRequestforFooterStates() -> (selectedState: String?, states: [String]?)
    
    var didRequestForHorizontalScrollLimit: Int {get}
    
    var nativeFooterTypes: [NativeFooterContext.NativeFooterType]? { get }

    var loggedInTime: Date? { get }
    
    var layoutOrder: [ImmersiveLayoutSectionsPriority]? { get }
    
    var isJackpotAutoScrollEnabled: Bool? { get }

    var rtmsToasterDisplayTimeDuration: Int? {get}
    
    var rtmsOverlayDisplayTimeDuration: Int? {get}
    
    var imageCacheConfig: ImageCacheExpirationConfig? { get }
    
    var didRequestForUserOnboardingJourneys: UserOnboardingJourneys? { get }
    
    var isWebViewVisisble: Bool {get}
    
}
