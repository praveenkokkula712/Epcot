//
//  ETEpcotLobby+Datasource.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 15/06/23.
//

import Foundation
import ConfigModule

// MARK: - Epcot Lobby View Datasource extension
public extension EpcotLobbyViewDataSource {
    
    private var config: PosAppConfiguration? {
        DynaconAPIConfiguration.shared?.posAppConfig
    }
    private var odrAws: AppConfigurationODRAWS? {
        config?.odrAws
    }
    
    var didRequestForHorizontalScrollLimit: Int {
        self.odrAws?.horizontalScrollLimitForImmersive ?? 12
    }
    
    var isJackpotAutoScrollEnabled: Bool? {
        self.odrAws?.isJackpotAutoScrollEnabled ?? false
    }
    
    var textAllignmentForJackpot: JackpotTitleAlignment? {
        self.odrAws?.textAlignmentForJackpot ?? .left
    }
    
    var nativeFooterTypes: [NativeFooterContext.NativeFooterType]? {
        guard config?.features?.nativeFooterEnabled == true,
              let footerTypes = config?.features?.nativeFooterItems,
              !footerTypes.isEmpty else { return nil }
        return footerTypes.reduce(into: [NativeFooterContext.NativeFooterType]()) { partialResult, value in
            if let type = NativeFooterContext.NativeFooterType(rawValue: value) {
                partialResult.append(type)
            }
        }
    }
    
    var layoutOrder: [ImmersiveLayoutSectionsPriority]?  {
        self.odrAws?.immersiveSectionLayoutOrder?.compactMap({ImmersiveLayoutSectionsPriority(rawValue: $0)})
    }
    
    var rtmsToasterDisplayTimeDuration: Int? {
        self.odrAws?.toastersDisplayTime
    }
    
    var rtmsOverlayDisplayTimeDuration: Int? {
        self.odrAws?.overlaysDisplayTime
    }
    
    var imageCacheConfig: ImageCacheExpirationConfig? {
        self.odrAws?.imageCacheExpirationConfig
    }
    
    var searchVersion: FeatureVersion? {
        self.config?.features?.searchVersion
    }
    
    var didRequestForUserOnboardingJourneys: UserOnboardingJourneys? {
        self.config?.features?.userOnboardingJourneys
    }
    
    var isWebViewVisisble: Bool {
        return true
    }
}
