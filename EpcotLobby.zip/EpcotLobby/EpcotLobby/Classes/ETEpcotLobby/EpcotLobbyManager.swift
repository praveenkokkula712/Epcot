    //
    //  EpcotLobbyManager.swift
    //  EpcotLobby
    //
    //  Created by Praveen Kokkula on 31/03/22.
    //

import UIKit
import CasinoGames
import CasinoAPI
import Utility
import CasinoCore
import WebKit
import Kingfisher
import AVFoundation

class EpcotLobbyManager: ETEpcotLobby {
    
        // MARK:- Class/static Properties
    private static var instance: EpcotLobbyManager?
    
    class weak var shared: EpcotLobbyManager? {
        self.instance = self.instance ?? EpcotLobbyManager()
        return self.instance
    }
    
        // MARK:- Class Methods
    class func disposedShared() {
        self.instance = nil
    }
    
        // MARK:-  Private Properties
    private var isGameDownloadCompleted = false
    private(set) var initialGameId: String?
    private var isFromSearch: Bool = false
    private(set) weak var delegate: EpcotLobbyViewDelegate?
    private(set) var datasource: EpcotLobbyViewDataSource?
    private var epcotLobbyViewController: EpcotLobbyViewController?
    private(set) var isGameControllerLoaded = false
    private(set) var isLobbyLoaded = false
    var isOverlaysOrToastersPresented: Bool?
    
        // MARK:- Get Properties
    var css: LobbyCSS {
        CasinoCSS.lobby ?? DefaultCSS()
    }
    
    var lobbySwitcherType: SwitcherCategoryType {
        return self.getLobbyType
    }
    
    lazy var recenltyPlayedGameImagePath: String = {
        let imagePath = self.css.imageFolderPathJson?["recentlyPlayed"] as? String ?? kSquareImageFolder
        return imagePath
    }()
    
    func didUpdateLocalizaedStrings() {
        Feed.postNotification(notification: .didUpdateLocalizedStrings)
    }
    
    func didUpdateSiteCoreModels() {
        Feed.postNotification(notification: .didUpdateSitecoreModels)
    }
    
        // MARK: Instance Methods
    func load(game: String? = nil, completion: ((UIView?) -> Void)) {
        self.isLobbyLoaded = true
        guard self.epcotLobbyViewController == nil else {
            completion(self.epcotLobbyViewController?.view)
            return
        }
        self.epcotLobbyViewController = EpcotLobbyViewController.loadFromNib()
        self.initialGameId = game
        self.startCasinoGames()
        self.setupKfCacheDuration()
        completion(self.epcotLobbyViewController?.view)
    }
    
    private func setupKfCacheDuration() {
        if let config = self.datasource?.imageCacheConfig,
        config.isEnabled {
            let cache = ImageCache.default
            cache.memoryStorage.config.expiration = .days(config.expirationDuration)
            cache.diskStorage.config.expiration = .days(config.expirationDuration)
        }
    }
    
    func set(delegate: EpcotLobbyViewDelegate?, dataSource: EpcotLobbyViewDataSource?) {
        self.delegate = delegate
        self.datasource = dataSource
    }
    
    func didCloseCategoryWeblinkView() {
        
    }
    func videoPlayHandler(isWindowClosed: Bool){
        self.epcotLobbyViewController?.immersiveGamesCollectionViewController?.reloadVideoTeaserOnGamePlayDismiss(isPresenting: isWindowClosed)
    }
    func scrollGamesViewToTop() {
        self.epcotLobbyViewController?.scrollCollectionViewtoTop()
    }
    
    func reload() {
        DispatchQueue.main.async {[weak self] in
            guard let self = self else { return }
            let shouldRefetchMetaData = self.datasource?.shouldRefetchLobbyMetaData() ?? false
            if let rootVC = self.epcotLobbyViewController {
                    /// After successful login, reloading the lobby.
                rootVC.reload(shouldRefetchData: shouldRefetchMetaData)
            } else {
                    /// After succesful login from webView/promotions page, loading the prelogged in game if any.
                CasinoGamesAccessor.instance?.loadPreLoginGamesIfAny()
            }
        }
    }
    
    func onLogout() {
        DispatchQueue.main.async {[weak self] in
            guard let self = self else {
                return
            }
            if let epcotLobbyViewController = self.epcotLobbyViewController {
                epcotLobbyViewController.onLogout()
            }
        }
    }
    
    func unload() {
        ETCasinoAPI.clean()
        self.clean()
    }
    
    func load(game: String, additionalParams: AdditionalParameters?) {
        if CasinoGamesAccessor.instance?.currentState == .inactive {
            DispatchQueue.main.async {[weak self] in
                self?.initialGameId = game
                if !(self?.isLobbyLoaded ?? false) {
                    guard let vc = self?.datasource?.controllerForLoadGame() else {
                        self?.delegate?.didFailedLoading?(game: game, error: "controller to load the game is not available".localizedDescription)
                        return
                    }
                    vc.showLoader()
                }
                self?.startCasinoGames()
            }
        }
        else {
            CasinoGamesAccessor.instance?.load(game, additionalParams: additionalParams)
        }
    }
    
    private func startCasinoGames()  {
        do {
            if EntainContext.dualModeConfigContext?.downloadMode != nil {
                try CasinoGamesAccessor.instance?.begin(with: self, and: self)
            } else {
                try CasinoGamesAccessor.instance?.start(delegate: self, dataSource: self)
            }
        }
        catch {
            ETLogger.debug(error.localizedDescription)
        }
    }
    
    func sendFailedLoadingCallBack(game: String?) {
        self.delegate?.didFailedLoading?(game: game, error: "Game not available".localizedDescription)
        self.initialGameId = nil
    }
    
    func onLoggedIn() {
        if let rootVC = self.epcotLobbyViewController {
            /// After successful login, reload recenlty played and favourites.
            rootVC.onLoggedIn()
        }
    }
    
    func sendLoginRequest() {
        self.delegate?.didRequestLogin(completionHandler: { (_result) in
            if _result {
                self.onLoggedIn()
            }
            else {
                self.initialGameId = nil
            }
        })
    }
    
        /// Launch Lobby View
    func navigateToLobby() {
        CasinoGamesAccessor.instance?.unload()
        self.goToRootViewController(animated: false)
    }
    
    private func goToRootViewController(animated: Bool) {
        DispatchQueue.main.async {[weak self] in
            self?.epcotLobbyViewController?.dismiss(animated: animated, completion: nil)
            UIApplication.topViewController()?.dismiss(animated: animated, completion: nil)
        }
    }
    
        // MARK:- Private Instance Methods
    private func shouldAskForPlayMode() -> Bool {
        
        return self.datasource?.shouldAskPlayMode() ?? false
    }
    
    private func clean() {
            // clean up rootviewcontroller
        DispatchQueue.main.async {[weak self] in
            self?.goToRootViewController(animated: false)
            self?.epcotLobbyViewController?.clean()
                /// clear navigation controller
            self?.epcotLobbyViewController?.removeChildrenView()
            self?.epcotLobbyViewController = nil
        }
            /// stop casino games framework
        CasinoGamesAccessor.instance?.stop()
            // clear local properties
        self.initialGameId = nil
        /// clear shared instance
        EpcotLobbyManager.disposedShared()
    }
    
    func didUpdateWOFGamesSelectedFromMenu(with category: String) {
        self.epcotLobbyViewController?.didClickCategoryFromMenu(category: category)
    }
    
    func closeGameWindowIfNeeded(completion: @escaping () -> Void) {
        self.epcotLobbyViewController?.dismissChildViewsIfAny()
        CasinoGamesAccessor.instance?.closeGameWindowIfNeeded(completion: {
            completion()
        })
    }
    
    ///This method get user selected lobbyType from defaults when headertype is Explore switcher
    private var getLobbyType: SwitcherCategoryType {
        guard (self.css.lobbyheaderViewType == .lobbyExploreSwitcher || ImmersiveInstance.shared.isEnabled) else {
            return self.switcherLobbyType
        }
        guard let userSelectedLobbyType = UserDefaults.lobbySwitcherType else {
            return self.switcherLobbyType
        }
        return  SwitcherCategoryType(rawValue: userSelectedLobbyType) ?? .grid
    }
    
    var switcherLobbyType: SwitcherCategoryType {
        switch self.css.type {
        case .listView, .listLayoutV2:
            return .list
        default :
            return .grid
        }
    }
    
    func cancelFeedService() {
        CasinoGamesAccessor.instance?.cancelFeedService()
    }
    
    func loadDeepLinkUrl(url: String) {
        self.epcotLobbyViewController?.loadDeeplinkForCategories(urlStr: url)
    }
    
    func showPlayBreakView(with type: Utility.PlayBreakType, duration: String, completion: ((PlaybreakAction) -> Void)?) {
        self.epcotLobbyViewController?.showPlayBreakView(with: type, duration: duration, completion: completion)
    }
    
    func removePlaybreakIfNeeded() {
        self.epcotLobbyViewController?.removePlaybreakIfNeeded()
    }
}

extension EpcotLobbyManager:CasinoGamesDelegate {
    func didReceiveKycResponse(with model: KYCStatusModel?) {
        self.delegate?.didReceiveKycResponse(with: model)
    }
    
    func showOverlaysAndToastersIfAvailable() {
        EpcotLobbyManager.shared?.delegate?.didOverlaysAndToasterDismissed?()
    }
    
    func showAlertViewWith(title: String, description: String, buttons: NSArray, completion: ((Int, String?) -> ())?) {
        
    }
    
    func didUpdateGameInCache(for game: String, state: Bool) {
        self.epcotLobbyViewController?.didFinishDownloadingGame(game: game, state: state)
    }
    
    func didClickedOnNativeUrl(with url: String) {
        self.delegate?.didClickWeblink(with: .regulatoryItem(NavigateCategory.inAppBrowserFullScreen.rawValue, url), buttonType: nil)
    }
    
    func didFailedLoading(game: String?, error: Error?) {
        self.delegate?.didFailedLoading?(game: game, error: error)
    }
    
    func didReceivedPingFrom(game: String?) {
        self.delegate?.didReceivedPingFrom?(game: game)
    }
    
    func didFinishLoading(error: Error?) {
        if error == nil {
            DispatchQueue.main.async {[weak self] in
                guard let self = self else { return }
                self.isGameControllerLoaded = true
                self.epcotLobbyViewController?.onFinishLoadingCasinoGames()
                if !(self.isLobbyLoaded) {
                    if let vc = self.datasource?.controllerForLoadGame() {
                        vc.removeLoader()
                    }
                }
                if let _game = self.initialGameId {
                    self.load(game: _game, additionalParams: nil)
                    self.initialGameId = nil
                }
            }
        }
    }
    
    func didUpdate(state: GameState, game: GameMetaData?) {
        self.delegate?.didUpdateGame(state: state, of: game?.game)
        switch state {
        case .completed:
            isGameDownloadCompleted = true
        case .unloaded:
            if isGameDownloadCompleted {
                self.epcotLobbyViewController?.didFinishedGamePlay()
                isGameDownloadCompleted = false
            } else {
                self.epcotLobbyViewController?.didGameUnloadedOnDownloadFailOrCancel()
            }
        case .loaded, .completed:
            self.setupAudioSessionForBackgroundAudio()
        default: break
        }
    }
    
    func didRequestLogout() {
        self.delegate?.didRequestLogout()
    }
    
    func cgWebView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        self.delegate?.clWebView?(webView, didFinish: navigation)
    }
    
    func cgWebView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        self.delegate?.clWebView?(webView, didFail: navigation, withError: error)
    }
    
    func cgWebView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction) {
        self.delegate?.clWebView?(webView, decidePolicyFor: navigationAction)
    }
    
    func cgWebView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge) {
        self.delegate?.clWebView?(webView, didReceive: challenge)
    }
    
    func cgUserContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        self.delegate?.clUserContentController?(userContentController, didReceive: message)
    }
    
    func showRCPOneHourAlertView() {
        self.delegate?.showRCPOneHourAlertView()
    }
    
    func showAlertViewWith(title: String, description: String, buttons: NSArray, attributedDescription: NSAttributedString?, completion: ((Int, String?) -> ())?) {
        self.delegate?.showAlertViewWith(title: title, description: description, buttons: buttons, attributedDescription: nil, completion: completion)
    }
    
    func didReceiveRtmsNotification(notification: RTMNotification) {
        self.delegate?.didReceiveRtmsNotification(notification: notification)
    }
    
    func showRegulatoryEvent(with model: RegulatoryEventType) {
        self.delegate?.showRegulatoryEvent(with: model)
    }
    
}

extension EpcotLobbyManager: CasinoGamesDataSource {
    
    var didRequestForCasinoCss: LobbyCSS? {
        self.css
    }
    
    func didRequestCurrentStateCurrency() -> String? {
        self.datasource?.didRequestCurrentStateCurrency()
    }
    
    func headerForGameController() -> CasinoGamesHeader? {
        return self.datasource?.headerForGameController()
    }
    
    func didRequestParams(for type: CGURLType) -> String? {
        return self.datasource?.didRequestParams(for: type)
    }
    
    func didRequestPresentorController() -> UIViewController? {
        return self.datasource?.controllerForLoadGame()
    }
    
    func validateUserScreenName(completionHandler: @escaping (Bool) -> Void) {
        self.datasource?.validateUserScreenName(completionHandler: completionHandler)
    }
    
    func didRequestLogin() {
        self.delegate?.didRequestLogin(completionHandler: { (status) in
            if status {
                self.reload()
            } else {
                CasinoGamesAccessor.instance?.clearUserSelectedGames()
                self.epcotLobbyViewController?.didGameUnloadedOnDownloadFailOrCancel()
            }
        })
    }
    
    func didRequestForLoginSessionTime() -> Int? {
        return self.datasource?.didRequestForLoginSessionTime()
    }
    
    func didRequestSlotSessionTimer(for type: SlotSessionType) -> String? {
        return self.datasource?.didRequestSlotSessionTimer(for: type)
    }
    
    func didRequestVersionForEasyNav() -> Int {
        return self.datasource?.didRequestVersionForEasyNav() ?? 2
    }
    
    func didRequestforRTMSServerURL(for type: RtmsServerUrlType) -> String? {
        return self.datasource?.didRequestforRTMSServerURL(for: type)
    }
    
    func didRequestForODRTagSuffix(for provider: String) -> String? {
        return self.datasource?.didRequestForODRTagSuffix(for: provider)
    }
    
    func shouldDisplayView(of type: CLCustomViewType) -> Bool {
        return self.datasource?.shouldDisplayView(of: type) ?? false
    }
    
    func didRequestForSearchTilePosition() -> Int {
        self.datasource?.didRequestForSearchTilePosition() ?? 12
    }
    
    func shouldIncludePullToRefresh() -> Bool {
        self.datasource?.shouldIncludeRefreshControl() ?? true
    }
    
    func enableVoiceSearch() -> Bool {
        self.datasource?.enableVoiceSearch() ?? false
    }
    
    var didRequestForInstantInteraction: InstantInteractionModel? {
        self.datasource?.didRequestForInstantInteraction
    }

    func didRequestForLastPlayedGamesDisplayLimit() -> Int? {
        self.datasource?.didRequestForLastPlayedGamesDisplayLimit()
    }
    
    var vendorBasedGeoVariants: [String : String]? {
        self.datasource?.vendorBasedGeoVariants
    }
    
    var dynaconFeed: [String : Any]? {
        self.datasource?.dynaconFeed
    }
    
    var didRequestResponsibleGamingImageUrl: String? {
        self.datasource?.didRequestResponsibleGamingImageUrl
    }
    
    var didRequestResponsibleGamingNavigationUrl: String? {
        self.datasource?.didRequestResponsibleGamingNavigationUrl
    }
    
    var gameDirectoryVendorsPath: [String]? {
        self.datasource?.gameDirectoryVendorsPath
    }
    
}

extension EpcotLobbyManager {
    var onboardingSearchController: UIViewController? {
        self.epcotLobbyViewController?.onboardingSearchController
    }
    var isSeeAllViewAvailableForOnboarding: Bool {
        self.epcotLobbyViewController?.isOnboardingSeeAllViewAvailable ?? false
    }
    var onboardingSeeMoreViewController: UIViewController? {
        self.epcotLobbyViewController?.onboardingSeeMoreViewController
    }
    
    var enhancedSearchController: UIViewController? {
        self.epcotLobbyViewController?.enhancedSearchController
    }

    func setupAudioSessionForBackgroundAudio() {
        //enable other applications music to play in background mode
        try? AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
        try? AVAudioSession.sharedInstance().setActive(true)
    }
}
