//
//  ETEpcotLobby+Delegate.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 15/06/23.
//

import Foundation
import CasinoGames
import Utility
import CasinoAPI
import CasinoCore

public extension EpcotLobbyViewDelegate {
    
    func didClickWeblink(with item: WebLinkItemType, buttonType: TeaserButtonType?) {
        
    }
    
    func didUpdateWOFCategories(_ categories: [EntainSiteCoreItem]?) {
        
    }
    
    func didLobbyLoaded() {

    }
    
    func showRegulatoryEvent(with model: RegulatoryEventType) {
        
    }

    var lobbyViewController: UIViewController? {
        return nil
    }
    
    func didReceiveKycResponse(with model: KYCStatusModel?) {
        
    }
}
