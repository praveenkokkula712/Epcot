//
//  EpcotLobbyViewDelegate.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 15/06/23.
//

import Foundation
import CasinoGames
import Utility
import CasinoAPI
import CasinoCore

public protocol EpcotLobbyViewDelegate: LobbyDelegate {
    
    ///This method will get invoked when user click on weblink Category
    func didClickWeblink(with item: WebLinkItemType, buttonType: TeaserButtonType?)
        
    /// Update list of EntainSiteCoreItem to APP
    /// - Parameter categories: updated list of EntainSiteCoreItem
    func didUpdateWOFCategories(_ categories: [EntainSiteCoreItem]?)
    
    ///This delegate method is used to notify lobby load to main app
    func didLobbyLoaded()
    
    ///This delegate method will get called when user selected state from list
    func didClicked(item: NativeFooterItem)

    func showRegulatoryEvent(with model: RegulatoryEventType)
    
    var lobbyViewController: UIViewController? {get}
    
    func didFullScreenEnabled(with value : Bool)
    
    func didReceiveKycResponse(with model: KYCStatusModel?)
}
