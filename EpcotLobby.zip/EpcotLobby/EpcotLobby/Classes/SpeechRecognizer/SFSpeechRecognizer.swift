//
//  SFSpeechRecognizer.swift
//  EpcotLobby
//
//  Created by Bandana Choudhury on 20/04/22.
//

import Foundation
import Speech

class SpeechRecognizerManager: NSObject, SFSpeechRecognizerDelegate {
    
    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var audioEngine: AVAudioEngine?
    var dispatchWorkItem: DispatchWorkItem?
    private let speechIdealTime = 2
    
    var didFailedToAccessMicrophone: (() -> Void)?
    var status: ((SpeechRecognizerStatus) -> Void)?
    
    override init() {
        self.audioEngine = AVAudioEngine()
        self.speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "\(Locale.current)"))
    }
    
    /// to set up speech recognizer
    /// - Parameter complitionHandler: it will give autherizationStatus
    func setUpSpeechRecognizer(complitionHandler: @escaping (Bool) -> Void) {
       
        SFSpeechRecognizer.requestAuthorization { (authStatus) in
            var autherizationStatus = false
            switch authStatus {
            case .authorized:
                autherizationStatus = true
            default:
                autherizationStatus = false
                ETLogger.debug("User denied access to speech recognition")
            }
            complitionHandler(autherizationStatus)
        }
    }
    
    /// This method will invoked when user click on mic button
    func startRecording(complitionHandler: @escaping (_ text: String?, _ isFinal: Bool) -> Void) {
        guard let audioEngine = self.audioEngine else { return }
        if audioEngine.isRunning {
            audioEngine.stop()
            self.recognitionRequest?.endAudio()
        } else {
            if recognitionTask != nil {
                recognitionTask?.cancel()
                recognitionTask = nil
            }
            let audioSession = AVAudioSession.sharedInstance()
            do {
                try audioSession.setCategory(AVAudioSession.Category.record)
                try audioSession.setMode(AVAudioSession.Mode.measurement)
                try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
            } catch {
                ETLogger.debug("audioSession properties weren't set because of an error.")
            }
            self.recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            let inputNode = audioEngine.inputNode
            guard let recognitionRequest = self.recognitionRequest else {
                complitionHandler(nil,false)
                self.stopRecording()
                return
            }
            recognitionRequest.shouldReportPartialResults = true
            audioSession.requestRecordPermission { granted in
                DispatchQueue.main.async {
                    if granted {
                        self.status?(.start)
                        self.recogniseSpeech(request: recognitionRequest, complitionHandler: complitionHandler, inputNode: inputNode)
                    } else {
                        self.didFailedToAccessMicrophone?()
                    }
                }
            }
        }
    }
    /// This method will invoked when user click on mic button
    private func recogniseSpeech(request: SFSpeechAudioBufferRecognitionRequest, complitionHandler: @escaping (_ text: String?, _ isFinal: Bool) -> Void, inputNode: AVAudioInputNode) {
        guard let audioEngine = self.audioEngine else {
            return
        }
        recognitionTask = self.speechRecognizer?.recognitionTask(with: recognitionRequest!, resultHandler: { (result, error) in
            var isFinal = false
            if result != nil {
                ETLogger.debug("speech: recognized\(String(describing: result?.bestTranscription.formattedString))")
                self.dispatchWorkItem?.cancel()
                isFinal = result?.isFinal ?? false
                self.addWorkItem()
                complitionHandler(result?.bestTranscription.formattedString, isFinal)
            }
            if error != nil || isFinal {
               audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                self.recognitionRequest = nil
                self.recognitionTask = nil
                ETLogger.debug("speech: isFinally stopped")
            }
        })
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recognitionRequest?.append(buffer)
        }
        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            ETLogger.debug("audioEngine couldn't start because of an error.")
        }
        self.addWorkItem()
    }
    
    private func addWorkItem() {
        let workItem = DispatchWorkItem(block: {
            self.stopRecording()
        })
        self.dispatchWorkItem = workItem
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(speechIdealTime), execute: workItem)
    }
    
    /// This method will invoked when  engine stop recording
    func stopRecording() {
        guard let audioEngine = self.audioEngine else {
            return
        }
        if audioEngine.isRunning {
            self.status?(.stop)
            ETLogger.debug("speech: audio record stopped")
            audioEngine.stop()
            recognitionRequest?.endAudio()
            self.recognitionRequest = nil
            self.recognitionTask = nil
            self.status = nil
            self.didFailedToAccessMicrophone = nil
        }
    }
    
}
