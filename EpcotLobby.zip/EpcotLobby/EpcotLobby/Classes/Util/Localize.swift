//
//  Localize.swift
//  ARAMessageFactory
//
//  Created by Praveen Kokkula on 07/04/22.
//

import Foundation

struct Localize {
    @LocalizedStrings static private(set) var error = "error_title"
    @LocalizedStrings static private(set) var reloadLobby = "reload_lobby"
    @LocalizedStrings static private(set) var reload = "reload"
    @LocalizedStrings static private(set) var cancelButtonTitle = "Cancel_Button_Title"
    @LocalizedStrings static private(set) var searchCasino = "Search_Casino"
    @LocalizedStrings static private(set) var casino = "Casino"
    @LocalizedStrings static private(set) var searchTitle = "search_title"    
    @LocalizedStrings static private(set) var oopsNoGame = "Oops_No_Game"
    @LocalizedStrings static private(set) var someSuggestions = "Some_suggestions"
    @LocalizedStrings static private(set) var results = "Results"
    @LocalizedStrings static private(set) var startTyping = "Start_typing"
    @LocalizedStrings static private(set) var launchGame = "Launch_game"
    @LocalizedStrings static private(set) var kRecently_Played = "Recently_Played"
    @LocalizedStrings static private(set) var kFavouritesTitle = "Favourites"
    @LocalizedStrings static private(set) var kLiveCasinoTitle = "LiveCasino"
    @LocalizedStrings static private(set) var featured = "FEATURED"
    @LocalizedStrings static private(set) var okButtonTitle = "OK"
    @LocalizedStrings static private(set) var alertTitle = "alert_title"
    @LocalizedStrings static private(set) var alertMessageForSpeech = "alert_message_for_speech"
    @LocalizedStrings static private(set) var alertMessageForMicrophone = "alert_message_for_microphone"
    @LocalizedStrings static private(set) var forYou = "FOR_YOU"
    @LocalizedStrings static private(set) var done = "Done"
    @LocalizedStrings static private(set) var allGames = "All_Games"
    @LocalizedStrings static private(set) var allCategories = "All_Categories"
    @LocalizedStrings static private(set) var kPlay = "Play"
    @LocalizedStrings static private(set) var kDownload = "Download"
    @LocalizedStrings static private(set) var exploreHeaderTitle = "explore_Library_HeaderView_title"
    @LocalizedStrings static private(set) var selectTitle = "select_title"
    @LocalizedStrings static private(set) var lobbySwitcherType = "lobbyType"
    @LocalizedStrings static private(set) var applyBtnTitle = "apply_Button_title"
    @LocalizedStrings static private(set) var seeAll = "See_All"
    @LocalizedStrings static private(set) var alertSpeechTitle = "alert_speech_title"
    @LocalizedStrings static private(set) var alertMicrophoneTitle = "alert_microphone_title"
    @LocalizedStrings static private(set) var alertSpeechTitleVoice = "voice_search"
    @LocalizedStrings static private(set) var alertMicrophoneBold = "microphone"
    @LocalizedStrings static private(set) var qualifyingGames = "qualifyingGames"
    @LocalizedStrings static private(set) var allqualifyingGames = "allqualifyingGames"
    @LocalizedStrings static private(set) var favoriteToastMessage = "Favorite_toast_message"
    @LocalizedStrings static private(set) var latestStories = "Latest_Stories"
    @LocalizedStrings static private(set) var see_more = "SEE MORE"
    @LocalizedStrings static private(set) var onboardingWelcomeScreenTitle = "onboarding_welcome_title"
    @LocalizedStrings static private(set) var onboardingWelcomeScreenDescription = "onboarding_welcome_description"
    @LocalizedStrings static private(set) var onboardingWelcomeScreenGetStartedTitle = "onboarding_welcome_get_started"
    @LocalizedStrings static private(set) var onboardingWelcomeScreenSkipNowTitle = "onboarding_welcome_skip"
    @LocalizedStrings static private(set) var onboardingJourneyBackButtonTitle = "onboarding_back"
    @LocalizedStrings static private(set) var onboardingJourneyNextButtonTitle = "onboarding_next"
    @LocalizedStrings static private(set) var onboardingJourneyDoneButtonTitle = "onboarding_done"
    @LocalizedStrings static private(set) var casinoStoriesHoldTouchHint = "casino_stories_hold_touch_hint"
    @LocalizedStrings static private(set) var casinoStoriesLeftTouchHint = "casino_stories_left_touch_hint"
    @LocalizedStrings static private(set) var casinoStoriesRightTouchHint = "casino_stories_right_touch_hint"
    @LocalizedStrings static private(set) var close = "filterview_close"
    @LocalizedStrings static private(set) var seeAllGames = "seeall_games"
    
}
