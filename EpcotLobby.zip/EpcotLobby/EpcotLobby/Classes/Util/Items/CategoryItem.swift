//
//  CategoryItem.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 19/04/22.
//

import Foundation
import CasinoAPI

enum CategoryItem: Hashable {
    case loading(UUID)
    case category(EntainSiteCoreItem)
}

extension CategoryItem {
    static var loadingItems: [CategoryItem] {
        return Array(repeatingExpression: CategoryItem.loading(UUID()), count: 20)
    }
}
