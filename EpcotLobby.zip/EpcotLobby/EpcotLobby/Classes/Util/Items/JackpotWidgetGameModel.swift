//
//  JackpotWidgetGameModel.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 10/05/23.
//

import Foundation
import CasinoAPI

struct JackpotWidgetGameModel: Hashable {
    var game: Game
    var uuid: UUID = UUID()
    var isJackpotWidgetGame: Bool = false
}
