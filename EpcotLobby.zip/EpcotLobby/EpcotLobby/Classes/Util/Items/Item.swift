//
//  Item.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 19/04/22.
//

import Foundation
import CasinoAPI

enum Item: Hashable {
    case loading(UUID)
    case teasers(TeaserContentModel, UUID)
    case rpGames(JackpotWidgetGameModel)
    case game(Game, UUID)
    case banner(TeaserContentModel)
    case singleJackpot(JackpotWidgetsModel, UUID)
    case mustGoJackpot(JackpotWidgetsModel, UUID)
    case footerDividerLine
    case footerStateSwitcher
    case aboutUs(FooterAboutUsModel, UUID)
    case footerSeoLinks(FooterSeoLinksModel, UUID)
    case footerMediaLogo(FooterLogoContentModel, UUID)
    case footerBrandLogo(FooterLogoContentModel, UUID)
    case footerTextContent(FooterContentModel, UUID)
    case footerCopyRightContent(FooterCopyRightModel, UUID)
    case bingoButtonItem(String)
    case teaserVideos(NativeWidgetsModel, UUID)
    case bingoWidgets(
        [GamesList], [String], [BingoRoomImage], BingoRoomNames,
        BingoRoomIcons, BingoRoomIcons, BingoRoomTexts, BingoRoomTexts,
        BingoRoomSEPTexts, BingoWidgetCombinedRooms
    )
    case freeSpins(
        NativeWidgetsModel, ProminentFreeSpins, ProminentFreeSpinDetails,
        FreeSpinsConfigurationTexts, String, String
    )
    case topGames([Game])
    case playerStatsWidget(NativeWidgetsModel, PlayerStatsConfigurations,
                           PlayerStatsBackgroundImages)
    case jackpotTiles(JackPotModel, UUID)
    case engagementTools(
        NativeWidgetsModel, ProminentFreeSpins, ProminentFreeSpinDetails,
        FreeSpinsConfigurationTexts, String, String, 
        [EngagementTool.ToolType: [PromoEngagementTool]], [LobbyEngagementTools]
    )
    case originalsWidget(OriginalsWidgetConfigurations, Bool)
}

extension Item {
    static var loadingItems: [Item] {
        return Array(repeatingExpression: Item.loading(UUID()), count: 50)
    }
    
    static func loadingItems(with count: Int = 12) -> [Item] {
        Array(repeatingExpression: Item.loading(UUID()), count: count)
    }
}
