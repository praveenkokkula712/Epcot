//
//  JackpotWidgetType.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 10/06/23.
//

import Foundation

enum JackpotWidgetType {
    case mustGo
    case singleJackpot
}
