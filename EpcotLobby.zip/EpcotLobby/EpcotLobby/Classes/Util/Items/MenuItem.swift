//
//  MenuItem.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 10/06/23.
//

import Foundation

enum MenuItem: Hashable {
    case loading(UUID)
    case featured(EntainSiteCoreItem)
    case foryou(EntainSiteCoreItem)
    case app(EntainSiteCoreItem)
}

extension MenuItem {
    static var loadingItems: [MenuItem] {
        return Array(repeatingExpression: MenuItem.loading(UUID()), count: 8)
    }
}
