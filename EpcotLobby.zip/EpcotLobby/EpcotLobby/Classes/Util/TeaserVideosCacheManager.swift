//
//  TeaserVideosCacheManager.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 28/07/23.
//

import Foundation
import GSPlayer

private let secondsInOneDay = 86400

class TeaserVideosCacheManager {

    private static let cacheLastCleanedTimeStamp = "TeaserVideosCacheTimeStamp"
    
    static func clearCacheIfNeeded() {
        guard let config = EpcotLobbyManager.shared?.datasource?.imageCacheConfig,
        config.isEnabled else {
           return
        }
        
        let cacheInterval = Double(config.expirationDuration * secondsInOneDay)
        let userDefaults = UserDefaults.standard
        let currentTimeStamp = Date()

        guard let lastClearingTimeStamp = userDefaults.object(forKey: cacheLastCleanedTimeStamp) as? Date else {
            // Cache never cleared before, set the initial time stamp
            userDefaults.set(currentTimeStamp, forKey: cacheLastCleanedTimeStamp)
            return
        }
        // Check the clearing interval with last clean.
        if currentTimeStamp.timeIntervalSince(lastClearingTimeStamp) >= cacheInterval {
            do {
                //Clear the video cache
                try VideoCacheManager.cleanAllCache()
                //Update cacheLastCleanedTimeStamp
                userDefaults.set(currentTimeStamp, forKey: cacheLastCleanedTimeStamp)
                ETLogger.debug("Video cache cleaned")
            } catch {
                ETLogger.debug("Video cache clean failed")
            }
        }
    }
}
