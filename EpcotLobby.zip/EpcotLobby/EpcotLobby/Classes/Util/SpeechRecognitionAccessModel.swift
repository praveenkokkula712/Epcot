//
//  SpeechRecognitionAccessModel.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 19/10/23.
//

import Foundation

class SpeechRecognitionAccessModel {
    
    var lobbyCss: LobbyCSS? {
        EpcotLobbyManager.shared?.css
    }
    
    func showVoiceSearchPopUpView(alertTitle: String, alertDescription: String) {
        let cssMessageBold = self.lobbyCss?.fallback?.playButton?.title?.font ?? UIFont.boldSystemFont(ofSize: 12)
        let cssMessageRegular = self.lobbyCss?.lobbySwitcherItemView?.titleNormal?.font
        let attrs = [NSAttributedString.Key.foregroundColor: UIColor.black,
                     NSAttributedString.Key.font: cssMessageRegular ?? UIFont.systemFont(ofSize: 12)]
        alertDescription.convertHTMLInBackground(attrs: attrs) { result in
            let value = result as? NSMutableAttributedString
            if let range = value?.getTheRange(of: Localize.alertSpeechTitleVoice) {
                value?.apply(font: cssMessageBold, onRange: range)
            }
            if let range = value?.getTheRange(of: Localize.alertMicrophoneBold) {
                value?.apply(font: cssMessageBold, onRange: range)
            }
            DispatchQueue.main.async { [weak self] in
                EpcotLobbyManager.shared?.delegate?.showAlertViewWith(title: alertTitle,
                                                                      description: "",
                                                                      buttons: [Localize.okButtonTitle, Localize.cancelButtonTitle.capitalizingFirstLetter()],
                                                                      attributedDescription: value,
                                                                      completion: { index, action in
                    if index == 1, let settings = URL(string: UIApplication.openSettingsURLString) {
                        UIApplication.shared.open(settings)
                    }
                })
            }
        }
    }
}

extension NSMutableAttributedString {
    func getTheRange(of value: String) -> NSRange? {
        if let textRange = self.string.range(of: value) {
            return NSRange(textRange, in: self.string)
        }
        return nil
    }
}

