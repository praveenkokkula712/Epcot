//
//  LobbyDataSourceable.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 16/08/23.
//

import Foundation
import Utility

protocol LobbyDataSourceable {
    static var datasource: EpcotLobbyViewDataSource? { get }
}

extension LobbyDataSourceable {
    static var datasource: EpcotLobbyViewDataSource? {
        EpcotLobbyManager.shared?.datasource
    }
}
