//
//  PageControllerView.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 25/05/22.
//

import Foundation

class PageControlView: UIView {
    
    private var animationDuration = 0.2
    
    private var mustGoCurrentItem: CGFloat = 0
    private var previuscurrentItem: CGFloat = 0
    private var displayLink: CADisplayLink?
    private var startTime = 0.0
    
    var numberOfPages: Int {
        get {
            return drawer.numberOfPages
        }
        set(val) {
            setNeedsDisplay()
            drawer.numberOfPages = val
        }
    }
    
    var drawerStyle: DrawerStyle {
        get {
            return drawer.drawerStyle
        }
        set(value) {
            setNeedsDisplay()
            drawer.drawerStyle = value
        }
    }
    
    var drawer = ScaleDrawer()
    
    init() {
        super.init(frame: .zero)
        backgroundColor = .clear
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        backgroundColor = .clear
    }
    
    func setPageOffset(_ offset: CGFloat) {
        drawer.currentItem = CGFloat(offset)
        setNeedsDisplay()
    }
    
    func setPage(_ index: Int) {
        if mustGoCurrentItem != CGFloat(index) {
            previuscurrentItem = round(drawer.currentItem)
            self.mustGoCurrentItem = CGFloat(index)
            startDisplayLink()
        }
    }
    
    override  var intrinsicContentSize: CGSize {
        return CGSize(width: self.drawer.size, height: self.drawer.size + 16)
    }
    
    override  func draw(_ rect: CGRect) {
        drawer.draw(rect)
    }
    
    private func startDisplayLink() {
        stopDisplayLink()
        startTime = Date.timeIntervalSinceReferenceDate
        let displayLink = CADisplayLink(
            target: self, selector: #selector(displayLinkDidFire)
        )
        displayLink.add(to: .current, forMode: .common)
        self.displayLink = displayLink
    }
    
    @objc private func displayLinkDidFire(_: CADisplayLink) {
        var elapsedTime = Date.timeIntervalSinceReferenceDate - startTime
        
        if elapsedTime > animationDuration {
            stopDisplayLink()
            elapsedTime = animationDuration
        }
        let progress = CGFloat(elapsedTime / animationDuration)
        
        let sign = mustGoCurrentItem - previuscurrentItem
        
        drawer.currentItem = CGFloat(progress * sign + previuscurrentItem)
        
        setNeedsDisplay()
    }
    
        // invalidate display link if it's non-nil, then set to nil
    private func stopDisplayLink() {
        displayLink?.invalidate()
        displayLink = nil
    }
}
