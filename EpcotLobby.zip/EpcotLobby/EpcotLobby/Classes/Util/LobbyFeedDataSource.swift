//
//  Extenstions.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 07/04/22.
//

import Foundation

/// Feed datasource
protocol LobbyFeedDataSource: AnyObject {
    var feedViewModel: FeedViewModel? { get }
}
