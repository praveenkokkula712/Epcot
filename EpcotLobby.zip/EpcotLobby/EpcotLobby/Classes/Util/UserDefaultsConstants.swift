//
//  UserDefaultsConstants.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 15/05/23.
//

//Key used to set/get list of game Story paths in Defaults
let kGameStoriesPaths = "stories_paths"
///Game story dictionary inside keys
let kGameStoryVisited = "visited"
let kGameStoryOpted = "opted"
let kGameStoryTime = "date_time"
