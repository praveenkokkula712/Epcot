//
//  Enums.swift
//  EpcotLobby
//
//  Created by Challa Venkata Narasimha Karthik on 19/04/22.
//
import Foundation

enum SpeechRecognizerStatus {
    case start, stop
}
