//
//  UICollectionViewExtension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 07/04/22.
//

import Foundation
import UIKit

struct CellIdentifier {
    static let reuseIdentifier = "EpcotCell"
    static let gameCell = "EpcotGameCollectionViewCell"
    static let categoriesCell = "EpcotMenuCustomCell"
    static let recentlyPlayedGamesHeader = "EpcotRecentlyPlayedHeader"
    static let bingoSectionCollectionViewCell = "BingoSectionCollectionViewCell"
    static let epcotHeaderView = "epcotHeaderView"
    static let epcotMenuViewController = "EpcotMenuViewController"
    static let teasersCollectionCell = "EpcotBannerCollectionViewCell"
    static let epcotBannerVideoCell = "EpcotBannerVideoCell"
    static let teasersFooterCell = "EpcotPageControlFooterView"
    static let appPromoCell = "AppPromotionCollectionViewCell"
    static let recommendationCell = "EpcotRecommendationCollectionViewCell"
    static let epcotEmbeddedBannerCell = "EpcotEmbeddedBannerCollectionViewCell"
    static let switcherCategoryPopUpTableViewCell = "SwitcherCategoryPopUpTableViewCell"
    static let suggestionsCell = "SuggestionTableViewCell"
    static let lobbyListCVCell = "GamesListViewCell"
    static let moreSectionCell = "MoreItemsCollectionReusableView"
    static let portraitCell = "PortraitSectionCollectionViewCell"
    static let mustGoJackpoCell = "MustGoCollectionViewCell"
    static let jackpotWidgetCell = "JackpotWidgetCollectionViewCell"
    static let shimmerCell = "ShimmerCollectionViewCell"
    static let footerDividerLineCell = "NativeFooterDividerLineCell"
    static let footerStateChangerCell = "NativeFooterStateChangerCell"
    static let footerBaseCell = "NativeFooterBaseCell"
    static let footerLogoCell = "NativeFooterLogoCell"
    static let footerTextContentCell = "NativeFooterContentCell"
    static let footerCopyRightCell = "NativeFooterCopyRightCell"
    static let footerBaseHeaderReusableView = "NativeFooterBaseReusableView"
    static let gameTeaserVideosCustomCell = "TeaserVideosCustomCell"
    static let bingoWidgetContainerCell = "BingoWidgetContainerCell"
    static let playerWidgetContainerCell = "PlayerWidgetContainerCell"
    static let jackpotTileCell = "JackpotTileCell"
    static let originalsContainerCell = "OriginalsWidgetContainerCell"
}

