//
//  ShimmerResponseType.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 23/11/22.
//

import Foundation

enum ShimmerReceivedResponseType: CaseIterable {
    case categories
    case games
}
