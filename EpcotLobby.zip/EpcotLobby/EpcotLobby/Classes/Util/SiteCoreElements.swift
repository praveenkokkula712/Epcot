//
//  SiteCoreElements.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 10/06/23.
//

import Foundation

public enum SiteCoreElements: String, Hashable {
    case subCategories
    case featured
    case forYou
}
