//
//  PlaybreakAction.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 19/04/24.
//

import Foundation

public enum PlaybreakAction {
    case dismiss
    case notNow
    case takeABreak
    case contact
}
