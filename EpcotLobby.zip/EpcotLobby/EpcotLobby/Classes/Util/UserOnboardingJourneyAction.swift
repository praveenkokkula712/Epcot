//
//  UserJourneyWelcomeAction.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 04/04/23.
//

import Foundation

public enum UserOnboardingWelcomeAction: Int {
    case started    = 1
    case skip       = 2
    case close      = 3
    case none       = 0
}

enum UserOnboardingViewAction: String {
    case back, next, close, done
}
