//
//  EpcotCheckable.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 10/08/23.
//

import Foundation
import Utility

protocol EpcotCheckable {
    static var isEpcot: Bool { get }
}

extension EpcotCheckable {
    static var isEpcot: Bool {
        return CasinoCSS.lobby?.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false
    }
}
