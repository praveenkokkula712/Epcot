//
//  LobbyStylable.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 10/08/23.
//

import Foundation
import Utility

protocol LobbyStylable {
    static var lobbyCSS: LobbyCSS? { get }
}

extension LobbyStylable {
    static var lobbyCSS: LobbyCSS? { EpcotLobbyManager.shared?.css }
}
