//
//  FavouritesButton.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 02/01/23.
//

import UIKit
import CasinoAPI

class FavouritesButton: UIButton {
    
    var isFavouriteFetchEnabled: Bool {
        EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .favouriteGamesView) ?? false
    }
    
    var isFavouriteSelected: FavouriteState = .unselected {
        didSet {
            guard let isLoggedIn = EntainContext.user?.isLoggedIn(),
                    isLoggedIn,
                    self.isFavouriteFetchEnabled else {
                self.isHidden = true
                return
            }
            self.isHidden = false
            self.isEnabled = isFavouriteSelected != .progress
            guard self.isFavouriteSelected != .progress else { return }
            self.isSelected = isFavouriteSelected.boolValue
            let css = EpcotLobbyManager.shared?.css.gamesCell
            let imageName = isFavouriteSelected.boolValue ? css?.favouriteButtonIconSelected : css?.favouriteButtonIconUnselected
            let iconVariant = EpcotLobbyManager.shared?.datasource?.didRequestForIconVariant(with: imageName ?? "", fontSize: EpcotLobbyManager.shared?.css.favouritesIconFontSize ?? 14.0)
            self.layer.cornerRadius = self.frame.height / 2
            self.backgroundColor = css?.favouriteButtonBackgroundColor
            self.setTitle(iconVariant?.icon, for: .normal)
            self.titleLabel?.font = iconVariant?.font
            self.setTitleColor(css?.favouriteButtonTintColor, for: .normal)
        }
    }
}
