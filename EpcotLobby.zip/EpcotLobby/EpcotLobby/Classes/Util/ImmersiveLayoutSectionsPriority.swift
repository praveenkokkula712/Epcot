//
//  ImmersiveLayoutSectionsPriority.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 31/01/23.
//

import Foundation

public enum ImmersiveLayoutSectionsPriority: Int {
    case teasers = 0
    case bingoButton
    case recentlyPlayedGames
    case favouriteGames
    case bingoWidget
}
