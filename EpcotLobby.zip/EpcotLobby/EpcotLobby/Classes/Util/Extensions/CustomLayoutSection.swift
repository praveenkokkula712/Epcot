//
//  NSCollectionLayoutSection+Extension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 19/04/22.
//

import Foundation
import UIKit
import Utility

struct CustomLayoutSection {
    
    //MARK: - Native footer layout
    static func fullWidthDynamicHeightSection(height: CGFloat) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                               heightDimension: .absolute(height))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitem: item,
                                                       count: 1)
        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = NSDirectionalEdgeInsets(top: 16, leading: 0, bottom: 0, trailing: 0)
        return section
    }
    
    //MARK: - Game cells layout
    static func gridLayoutSection(width: CGFloat,
                                  isPreBanner: Bool = true,
                                  isHeaderAvailable: Bool = false,
                                  isHeaderDescriptionAvailable: Bool = false,
                                  isFirstSection: Bool = false,
                                  orthoGonalScrollingBehaviour: UICollectionLayoutSectionOrthogonalScrollingBehavior = .none,
                                  isFromSearchController: Bool = false) -> NSCollectionLayoutSection {
        var fraction = 0.5
        var count = 2
        let itemSpacing: CGFloat = 8.0
        if UIDevice.isIPad() {
            /// This is to check and set the number of items per row or columns inside collection view
            switch (width > kMaxWidthThresholdLandscape) {
            case true:
                fraction = kPercentageOfColumnsLandscape
                count = kColumnsLandscape
            case false:
                fraction = kPercentageOfColumnsPortraitIpad
                count = kColumnsPortraitIpad
            }
            switch (width > kMaxWidthThresholdLandscape) {
            case true:
                fraction = kPercentageOfColumnsLandscape
                count = kColumnsLandscape
            case false:
                fraction = kPercentageOfColumnsPortraitIpad
                count = kColumnsPortraitIpad
            }
        }
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(fraction),
                                              heightDimension: .fractionalWidth(fraction))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                               heightDimension: .estimated(200))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitem: item,
                                                       count: count)
        group.interItemSpacing = .fixed(itemSpacing)
        
        let section = NSCollectionLayoutSection(group: group)
        var topSpace = 16.0
        if (!ImmersiveInstance.shared.isEnabled && !isPreBanner)  {
            topSpace = -24.0
        }
        topSpace = isFromSearchController ? 0 : topSpace
        section.contentInsets = NSDirectionalEdgeInsets(top: topSpace,
                                                        leading: 16,
                                                        bottom: kSectionBottomPadding,
                                                        trailing: 16)
        section.interGroupSpacing = itemSpacing
        if isHeaderAvailable && isPreBanner {
            var headerHeight = isFirstSection ? kFirstSectionHeaderHeight : kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
        }
        section.orthogonalScrollingBehavior = orthoGonalScrollingBehaviour
        return section
    }
    
    //MARK: - Recently played games cell layout
    static func horizontalscrollSection(with fraction: CGFloat,
                                        isHeaderAvailable: Bool = true,
                                        isHeaderDescriptionAvailable: Bool = false,
                                        isFirstSection: Bool = false) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(fraction),
                                               heightDimension: .fractionalWidth(fraction))
        
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        
        let section = NSCollectionLayoutSection(group: group)
        section.interGroupSpacing = 8
        section.contentInsets = NSDirectionalEdgeInsets.uniform()
        section.orthogonalScrollingBehavior = .continuous
        if isHeaderAvailable {
            var headerHeight = isFirstSection ? kFirstSectionHeaderHeight : kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
        }
        return section
    }
    
    //MARK: - Jackpot widget qualifying games cell layout
    static func horizontalWidgetGamesScrollSection(with fraction: CGFloat,
                                                   widgetLayoutType: LayoutType) -> NSCollectionLayoutSection {
        let section = CustomLayoutSection.horizontalscrollSection(with: fraction)
        var reuseIdentifier = WidgetGamesDecoratorView.reuseIdentifier
        switch widgetLayoutType {
        case .jackpotMustGoWidget: reuseIdentifier = MustGoWidgetGamesDecoratorView.reuseIdentifier
        case .multipleJackpotWidget: reuseIdentifier = MultipleWidgetsGamesDecoratorView.reuseIdentifier
        default: reuseIdentifier = WidgetGamesDecoratorView.reuseIdentifier
        }
        section.decorationItems = [
            NSCollectionLayoutDecorationItem.background(elementKind: reuseIdentifier)
        ]
        return section
    }
    
    
    //MARK:- List GameCell Layout
    static func listGameCellLayoutSection(width: CGFloat,
                                          isPreBanner: Bool = true,
                                          isHeaderAvailable: Bool = false,
                                          isHeaderDescriptionAvailable: Bool = false,
                                          isFirstSection: Bool = false,
                                          isFromSearchController: Bool = false) -> NSCollectionLayoutSection {
        var fraction = 1.0
        var count = 1
        let itemSpacing: CGFloat = 8.0
        if UIDevice.isIPad() {
            /// This is to check and set the number of items per row or columns inside collection view
            fraction = kPercentageOfColumnsPortrait
            count = kColumnsPortrait
        }
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(fraction),
                                              heightDimension: .absolute(96.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                               heightDimension: .absolute(96.0))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitem: item,
                                                       count: count)
        group.interItemSpacing = .fixed(itemSpacing)
        let section = NSCollectionLayoutSection(group: group)
        let isEpcotLobby = EpcotLobbyManager.shared?.css.lobbyheaderViewType == .epcotCategoryPills
        var topSpace = 16.0
        if (!ImmersiveInstance.shared.isEnabled && !isPreBanner)  {
            topSpace = -24.0
        }
        topSpace = isFromSearchController ? 0 : topSpace
        section.contentInsets = NSDirectionalEdgeInsets(top: topSpace,
                                                        leading: 16.0,
                                                        bottom: kSectionBottomPadding,
                                                        trailing: 16.0)
        section.interGroupSpacing = itemSpacing
        if isHeaderAvailable && isPreBanner {
            var headerHeight = isFirstSection ? kFirstSectionHeaderHeight : kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
        }
        return section
    }
    
    //MARK: - Recently played games cell layout
    /// Will provide the layout for Recently played games, immersive section when rowCount is other than 0 or -1
    /// - Returns: NSCollectionLayoutSection -- which will have 3 items in iPhone and 5 items in iPad in continuous manner.
    static func verticalImmersiveSection(isHeaderAvailable: Bool = true,
                                         isHeaderDescriptionAvailable: Bool = false,
                                         isFirstSection: Bool = false, isFromSearchController: Bool = false) -> NSCollectionLayoutSection {
        let itemSpacing: CGFloat = 8.0
        let count = UIDevice.isIPad() ? 6 : kColumnsPortraitIphone
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                              heightDimension: .fractionalHeight(1))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                               heightDimension: .fractionalWidth(1/CGFloat(count)))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitem: item,
                                                       count: count)
        group.interItemSpacing = .fixed(itemSpacing)
        let section = NSCollectionLayoutSection(group: group)
        if isFromSearchController {
            var insets: NSDirectionalEdgeInsets {
                .init(top: 0, leading: 16, bottom: 16, trailing: 16)
            }
            section.contentInsets = insets
        } else {
            section.contentInsets = .uniform()
        }
        section.interGroupSpacing = itemSpacing
        if isHeaderAvailable {
            var headerHeight = isFirstSection ? kFirstSectionHeaderHeight : kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
        }
        return section
    }
    
    //MARK: - Menu items section layout
    static func listLayoutSection(isHeaderEnabled:Bool = true,
                                  headerHeight: CGFloat = kSectionHeaderHeight) -> NSCollectionLayoutSection {
        
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                              heightDimension: .fractionalHeight(1))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let layoutSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                heightDimension: .estimated(44.0))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: layoutSize,
                                                       subitem: item,
                                                       count: 1)
        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 16, bottom: 16, trailing: 16)
        if isHeaderEnabled {
            section.boundarySupplementaryItems = [CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)]
        }
        return section
    }
    
    
    //MARK: - InApp advertisement sectio layout
    static func inAppAdsLayoutSection(with height: CGFloat = 58.0) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                              heightDimension: .fractionalHeight(1))
        
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                               heightDimension: .absolute(height))
        
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        let section = NSCollectionLayoutSection(group: group)
        section.interGroupSpacing = 12
        section.contentInsets = NSDirectionalEdgeInsets(horizontal: 16, vertical: 32)
        return section
    }
    
    static func carouselTeasersLayoutSection() -> NSCollectionLayoutSection {
        let section = CustomLayoutSection.teasersLayoutSection()
        guard let teasersConfig = EpcotLobbyManager.shared?.datasource?.teasersDynaconConfig, teasersConfig.isTeaserEnabled, teasersConfig.shouldDisplayPageControl, !UIDevice.isIPad() else {
            return section
        }
        let footer = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: 20, kind: UICollectionView.elementKindSectionFooter,alignment: .bottom)
        section.boundarySupplementaryItems = [footer]
        return section
    }
    
    static func teasersLayoutSection() -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let groupSize = NSCollectionLayoutSize(widthDimension: .absolute(280),
                                               heightDimension: .absolute(140))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .continuousGroupLeadingBoundary
        let bottomPadding: CGFloat = UIDevice.isIPad() ?  12 : 5
        section.contentInsets = NSDirectionalEdgeInsets(top: 6, leading: 16, bottom: bottomPadding, trailing: 16)
        section.interGroupSpacing = 8
        return section
    }
    
    static func teasersIpadLayoutSection(numberOfTeasers: Int) -> NSCollectionLayoutSection {
         let itemSize = NSCollectionLayoutSize(widthDimension: .absolute(280),
                                               heightDimension: .absolute(140))
        // Create an item with the custom size
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let width = (280 * numberOfTeasers) + (8 * (numberOfTeasers - 1))
        // Add the item to a group with the same width and height as the item
        let groupSize = NSCollectionLayoutSize(widthDimension: .absolute(CGFloat(width)),
                                               heightDimension: .absolute(140))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitem: item,
                                                       count: numberOfTeasers)
        group.interItemSpacing = .fixed(8)
        // Create a section with the group and set the content inset to center the group
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .groupPagingCentered
        let bottomPadding: CGFloat = UIDevice.isIPad() ?  12 : 5
        section.contentInsets = NSDirectionalEdgeInsets(top: 6, leading: 16, bottom: bottomPadding, trailing: 16)
        return section
    }
    
    static func embeddedBannersLayoutSection() -> NSCollectionLayoutSection {
        let isIPad = UIDevice.isIPad()
        let itemSpacing: CGFloat = isIPad ? 8.0 : 0.0
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                              heightDimension: .fractionalHeight(1))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let count = isIPad ? 4 : 1
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                               heightDimension: .fractionalWidth(1.0/CGFloat(count)))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        group.interItemSpacing = .fixed(itemSpacing)
        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = NSDirectionalEdgeInsets(top: 8,
                                                        leading: 16,
                                                        bottom: 16,
                                                        trailing: 8)
        section.interGroupSpacing = itemSpacing
        return section
    }
     
    static func fullWidthGridSection(isFirstSection: Bool = false, isHeaderAvailable: Bool = true,
        isHeaderDescriptionAvailable: Bool = false) -> NSCollectionLayoutSection {
        let itemSpacing: CGFloat = 8.0
        let count = UIDevice.isIPad() ? 2 : 1
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                              heightDimension: .fractionalHeight(1))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1/CGFloat(count)),
                                               heightDimension: .fractionalWidth(1/CGFloat(count)))

        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        group.interItemSpacing = .fixed(itemSpacing)
        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = .init(horizontal: 16.0, vertical: 16.0)
        section.interGroupSpacing = itemSpacing
        if isHeaderAvailable {
            var headerHeight = isFirstSection ? kFirstSectionHeaderHeight : kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
        }
        
        if UIDevice.isIPad() {
            section.orthogonalScrollingBehavior = .groupPagingCentered
        }
        return section
    }
    
    static func portraitSectionLayout(isFirstSection: Bool = false,
                                      isHeaderAvailable: Bool = true,
                                      isHeaderDescriptionAvailable: Bool = false) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(UIDevice.isIPad() ? 0.15 : 0.29),
                                               heightDimension: .absolute(200))
        
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        
        let section = NSCollectionLayoutSection(group: group)
        section.interGroupSpacing = 8
        section.contentInsets = NSDirectionalEdgeInsets.uniform()
        section.orthogonalScrollingBehavior = .continuous
        if isHeaderAvailable {
            var headerHeight = isFirstSection ? kFirstSectionHeaderHeight : kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
        }
        return section
    }
    
    static func jackpotMustGoWidgetLayoutSection(
        isHeaderAvailable: Bool,
        isHeaderDescriptionAvailable: Bool
    ) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                               heightDimension: .absolute(261))
        
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        
        let section = NSCollectionLayoutSection(group: group)
        section.decorationItems = [
            NSCollectionLayoutDecorationItem.background(elementKind: MustGoWidgetDecoratorView.reuseIdentifier)
        ]
        var topSpace: Double = 0
        let padding = 16.0
        if isHeaderAvailable {
            var headerHeight = kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
            topSpace = padding
        }
        section.contentInsets = .init(top: topSpace, leading: 0, bottom: isHeaderAvailable ? 0 : 8, trailing: 0)
        return section
    }
    
    
    static func jackpotWidgetLayoutSection(
        isHeaderAvailable: Bool,
        isHeaderDescriptionAvailable: Bool
    ) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                               heightDimension: .absolute(250))
        
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        
        let section = NSCollectionLayoutSection(group: group)
        section.decorationItems = [
            NSCollectionLayoutDecorationItem.background(elementKind: WidgetDecoratorView.reuseIdentifier)
        ]
        var topSpace: Double = 0
        let padding = 16.0
        if isHeaderAvailable {
            var headerHeight = kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
            topSpace = padding
        }
        section.contentInsets = .init(top: topSpace, leading: 0, bottom: isHeaderAvailable ? 0 : 8, trailing: 0)
        return section
    }
    
    static func multipleJackpotWidgetsLayoutSection(
        isHeaderAvailable: Bool,
        isHeaderDescriptionAvailable: Bool
    ) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                               heightDimension: .absolute(250))
        
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .continuousGroupLeadingBoundary

        let footer = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: 20, kind: UICollectionView.elementKindSectionFooter,alignment: .bottom)
        section.boundarySupplementaryItems = [footer]
        section.decorationItems = [
            NSCollectionLayoutDecorationItem.background(elementKind: MultipleWidgetsDecoratorView.reuseIdentifier)
        ]
        var topSpace: Double = 0
        let padding = 16.0
        if isHeaderAvailable {
            var headerHeight = kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
            topSpace = padding
        }
        section.contentInsets = .init(top: topSpace, leading: 0, bottom: isHeaderAvailable ? 0.0 : 8.0, trailing: 0)
        return section
    }
    
    //MARK: - Footer
    static func nativeFooterDividerLineLayout() -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .absolute(20))
        let layoutItem = NSCollectionLayoutItem(layoutSize: itemSize)
        
        let layoutGroupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                                     heightDimension: itemSize.heightDimension)
        let layoutGroup = NSCollectionLayoutGroup.horizontal(layoutSize: layoutGroupSize,
                                                             subitems: [layoutItem])
        
        let layoutSection = NSCollectionLayoutSection(group: layoutGroup)
        layoutSection.decorationItems = [
            NSCollectionLayoutDecorationItem.background(elementKind: FooterDivideLineDecoratorView.reuseIdentifier)
        ]
        return layoutSection
    }
    
    static func nativeFooterStateSwitcherLayout() -> NSCollectionLayoutSection {
        let states = EpcotLobbyManager.shared?.datasource?.didRequestforFooterStates().states
        let height: CGFloat = states == nil ? 40: 70
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .absolute(height))
        let layoutItem = NSCollectionLayoutItem(layoutSize: itemSize)
        
        let layoutGroupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                                     heightDimension: itemSize.heightDimension)
        let layoutGroup = NSCollectionLayoutGroup.horizontal(layoutSize: layoutGroupSize,
                                                             subitems: [layoutItem])
        layoutGroup.interItemSpacing = .fixed(6)

        let layoutSection = NSCollectionLayoutSection(group: layoutGroup)
        
        layoutSection.contentInsets = .init(horizontal: 10, vertical: states == nil ? 0 : 10)
        layoutSection.decorationItems = [
            NSCollectionLayoutDecorationItem.background(elementKind: FooterStateDecoratorView.reuseIdentifier)
        ]
        return layoutSection
    }
    
    static func nativeFooterSeoLinksSectionLayout() -> NSCollectionLayoutSection {
        let layoutSection = nativeFooterBaseSectionLayout()
        layoutSection.decorationItems = [
            NSCollectionLayoutDecorationItem.background(elementKind: FooterSeoLinksDecoratorView.reuseIdentifier)
        ]
        return layoutSection
    }
    
    static func nativeFooterAboutUsSectionLayout() -> NSCollectionLayoutSection {
        let layoutSection = nativeFooterBaseSectionLayout()
        layoutSection.decorationItems = [
            NSCollectionLayoutDecorationItem.background(elementKind: FooterAboutUsDecoratorView.reuseIdentifier)
        ]
        return layoutSection
    }
    
    private static func nativeFooterBaseSectionLayout() -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .estimated(100),
                                              heightDimension: .absolute(30))
        let layoutItem = NSCollectionLayoutItem(layoutSize: itemSize)
        
        let layoutGroupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                                     heightDimension: itemSize.heightDimension)
        let layoutGroup = NSCollectionLayoutGroup.horizontal(layoutSize: layoutGroupSize,
                                                             subitems: [layoutItem])
        layoutGroup.interItemSpacing = .fixed(6)

        let layoutSection = NSCollectionLayoutSection(group: layoutGroup)
        layoutSection.contentInsets = .init(horizontal: 10, vertical: 0)
        let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: 35)
        layoutSection.boundarySupplementaryItems = [header]
        return layoutSection
    }
    
    static func nativeFooterLogosLayout() -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .estimated(80),
                                              heightDimension: .estimated(40))
        let layoutItem = NSCollectionLayoutItem(layoutSize: itemSize)

        let sectionLayoutSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                                       heightDimension: itemSize.heightDimension)
        
        let layoutGroup = NSCollectionLayoutGroup.horizontal(layoutSize: sectionLayoutSize,
                                                             subitems: [layoutItem])
        layoutGroup.interItemSpacing = .fixed(16)

        let layoutSection = NSCollectionLayoutSection(group: layoutGroup)
        layoutSection.contentInsets = .init(horizontal: 10, vertical: 0)
        layoutSection.interGroupSpacing = 16
        layoutSection.decorationItems = [
            NSCollectionLayoutDecorationItem.background(elementKind: FooterLogosDecoratorView.reuseIdentifier)
        ]
        return layoutSection
    }
    
    static func nativeFooterContentLayout() -> NSCollectionLayoutSection {
        let size = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                          heightDimension: .estimated(50))
        
        let item = NSCollectionLayoutItem(layoutSize: size)
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: size,
                                                       subitem: item,
                                                       count: 1)
        
        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = .init(horizontal: 6, vertical: 10)
        section.interGroupSpacing = 10
        section.decorationItems = [
            NSCollectionLayoutDecorationItem.background(elementKind: FooterContentDecoratorView.reuseIdentifier)
        ]
        return section
    }
    
    static func nativeFooterCopyRightLayout() -> NSCollectionLayoutSection {
        let size = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                          heightDimension: .absolute(50))
        
        let item = NSCollectionLayoutItem(layoutSize: size)
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: size,
                                                       subitem: item,
                                                       count: 1)

        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = .init(horizontal: 10, vertical: 0)
        section.interGroupSpacing = 10
        section.decorationItems = [
            NSCollectionLayoutDecorationItem.background(elementKind: FooterCopyRightDecoratorView.reuseIdentifier)
        ]
        return section
    }
    
    static func bingoLogoSectionLayout() -> NSCollectionLayoutSection {
        let size = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                          heightDimension: .absolute(40))
        
        let item = NSCollectionLayoutItem(layoutSize: size)
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: size,
                                                       subitem: item,
                                                       count: 1)

        let section = NSCollectionLayoutSection(group: group)
        var topInset: CGFloat = 16
        if EntainContext.user?.isLoggedIn() ?? false {
            topInset = 0
        }
        section.contentInsets = NSDirectionalEdgeInsets(top: topInset, leading: 16, bottom: 16, trailing: 16)
        return section
    }

    static func nativeBingoWidgetSectionLayout() -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .estimated(272))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .continuous
        return section
    }
    
    static func videoLayoutSection(
        isHeaderAvailable: Bool = false,
        isHeaderDescriptionAvailable: Bool
    ) -> NSCollectionLayoutSection {
        let padding = 16.0
        let screenWidth = UIDevice.screenSize.width - (2 * padding)
        let height = UIDevice.isIPad() ? screenWidth/3 : screenWidth/1.5
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .absolute(height))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                               heightDimension: itemSize.heightDimension)
        
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        
        let section = NSCollectionLayoutSection(group: group)
        var topSpace: Double = 0
        if isHeaderAvailable {
            var headerHeight = kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
            topSpace = padding
        }
        section.contentInsets = .init(top: topSpace, leading: padding, bottom: isHeaderAvailable ? 0.0 : padding, trailing: padding)
        return section
    }
    
    ///FREE SPINS
    static func freeSpinsWidgetSectionLayout(
        isHeaderAvailable: Bool,
        isFreeSpinsScrollable: Bool,
        isHeaderDescriptionAvailable: Bool
    ) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let height: CGFloat = isFreeSpinsScrollable ? 136.0 : 124.0
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .estimated(height))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        let section = NSCollectionLayoutSection(group: group)
        var topSpace: Double = 0
        let padding = 16.0
        if isHeaderAvailable {
            var headerHeight = kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
            topSpace = padding
        }
        section.contentInsets = .init(top: topSpace, leading: 0.0, bottom: isHeaderAvailable ? 0.0 : padding, trailing: 0.0)
        return section
    }

    // MARK: Top 10 Games Scroll
    static func topGamesHorizontalScrollSection(
        layoutType: LayoutType,
        heightFactor: CGFloat = 1.0,
        isHeaderAvailable: Bool = true,
        isHeaderDescriptionAvailable: Bool = false,
        isFirstSection: Bool = false
    ) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(1.0),
            heightDimension: .fractionalHeight(1.0)
        )
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let dimension: NSCollectionLayoutDimension
        switch layoutType {
        case .topGamesPortraitGrid:
            dimension = .absolute(200.0 + 16.0)
        case .topGamesImmersiveGrid, .topGamesHorizontalGrid:
            dimension = .fractionalWidth(heightFactor)
        default:
            dimension = .fractionalWidth(1.0)
        }
        let groupSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(1.0),
            heightDimension: dimension
        )
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = .init(horizontal: 0.0, vertical: 16.0)
        if isHeaderAvailable {
            var headerHeight = isFirstSection ? kFirstSectionHeaderHeight : kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let padding = 16.0
            let screenWidth = UIDevice.screenSize.width - (2 * padding)
            let header = CustomBoundarySupplementaryItem
                .fixedSizeSupplementaryItem(
                    width: screenWidth,
                    height: headerHeight
                )
            section.boundarySupplementaryItems = [header]
        }
        return section
    }
    
    static func playerStatWidgetSectionLayout(
        isHeaderAvailable: Bool,
        isHeaderDescriptionAvailable: Bool
    ) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let height: CGFloat = 304
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .estimated(height))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        let section = NSCollectionLayoutSection(group: group)
        var topSpace: Double = 0
        let padding = 16.0
        if isHeaderAvailable {
            var headerHeight = kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
            topSpace = padding
        }
        section.contentInsets = .init(top: topSpace, leading: padding, bottom: isHeaderAvailable ? 0 : padding, trailing: padding)
        return section
    }

    /// JackpotTiles
    static func jackpotTilesSectionLayout(
        isJackPotFullWidthNeeded: Bool,
        isHeaderAvailable: Bool,
        isHeaderDescriptionAvailable: Bool,
        isCategorySection: Bool
    ) -> NSCollectionLayoutSection {
        
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        if isJackPotFullWidthNeeded {
            item.contentInsets = .init(horizontal: 16.0, vertical: 16.0)
        }
        let groupWidthDimension: NSCollectionLayoutDimension = isJackPotFullWidthNeeded ? .fractionalWidth(1.0) : UIDevice.isIPad() ? .absolute(378) : .fractionalWidth(0.85)
        let groupSize = NSCollectionLayoutSize(widthDimension: groupWidthDimension,
                                              heightDimension: .absolute(214))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        
        let section = NSCollectionLayoutSection(group: group)
        section.interGroupSpacing = 8
        section.orthogonalScrollingBehavior = isCategorySection ? .groupPagingCentered : .groupPaging
        var topSpace: Double = 0
        let padding = 16.0
        if isHeaderAvailable {
            var headerHeight = kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
            topSpace = padding
        }
        if isJackPotFullWidthNeeded {
            if isCategorySection {
                section.contentInsets = .init(top: topSpace, leading: 16, bottom: isHeaderAvailable ? 0 : 16, trailing: 16)
            } else {
                section.contentInsets = .init(top: 0, leading: 0, bottom: 16, trailing: 0)
            }
        } else {
            section.contentInsets = .init(top: topSpace, leading: 16, bottom: 16, trailing: 16)
        }
        return section
    }
    
    static func originalsWidgetSectionLayout(showInCategory: Bool,
                                             isHeaderAvailable: Bool,
                                             isHeaderDescriptionAvailable: Bool) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let height: CGFloat = showInCategory ? 320 : 216
        let count = UIDevice.isIPad() ? 2 : 1
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0/CGFloat(count)),
                                               heightDimension: .estimated(height))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        let section = NSCollectionLayoutSection(group: group)
        
        if isHeaderAvailable {
            var headerHeight = kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            header.contentInsets = NSDirectionalEdgeInsets(top: 0,
                                                           leading: 16,
                                                           bottom: 0,
                                                           trailing: 16)
            section.boundarySupplementaryItems = [header]
        }
        section.contentInsets = NSDirectionalEdgeInsets(top: (showInCategory || isHeaderAvailable) ? 8 : 0, leading: 0, bottom: isHeaderAvailable ? 0 : 16, trailing: 0)
        if UIDevice.isIPad() {
            section.orthogonalScrollingBehavior = .groupPagingCentered
        }
        return section
    }
    
    static func engagementToolsSectionLayout(
        isHeaderAvailable: Bool,
        isEngagementToolsScrollable: Bool,
        isHeaderDescriptionAvailable: Bool
    ) -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                              heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let height: CGFloat = isEngagementToolsScrollable ? 136.0 : 124.0
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                               heightDimension: .estimated(height))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        let section = NSCollectionLayoutSection(group: group)
        let padding = 16.0
        var topSpace: Double = 0
        if isHeaderAvailable {
            var headerHeight = kSectionHeaderHeight
            if isHeaderDescriptionAvailable {
                headerHeight += kHeaderDescriptionHeight
            }
            let header = CustomBoundarySupplementaryItem.fixedHeightSupplementaryItem(with: headerHeight)
            section.boundarySupplementaryItems = [header]
            topSpace = padding
        }
        section.contentInsets = .init(top: topSpace, leading: 0.0, bottom: isHeaderAvailable ? 0.0 : padding, trailing: 0.0)
        return section
    }
}
