//
//  TeaserContentModel+Extension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 01/06/22.
//

import Foundation
import CasinoAPI

extension TeaserContentModel {
    
    private var css: EpcotTeasersCSS? {
        EpcotLobbyManager.shared?.css.epcotLobbyCSS?.teasersViewCSS
    }
    
    func getTitleAttributedText(with globalAttributes: TeaserContentModel?, completion: ((_ text: NSAttributedString?) -> Void)? ) {
        let fontColor = (self.attributes?.titleColor?.hexColor ?? globalAttributes?.attributes?.teaserTitleDefaultFontColor?.hexColor) ?? css?.title?.color
        
        let fontStyle = self.titleFont ?? .big
        var font = (fontStyle == .big ? css?.title?.font : css?.titleRegularFont) ?? UIFont.boldSystemFont(ofSize: 14)
        
        if UIDevice.isIPad() && (self.isEmbeddedTeaser?.bool == true) {
            font = (fontStyle == .big ? css?.ipadTitle?.font : css?.iPadtitleRegularFont) ?? UIFont.boldSystemFont(ofSize: 14)
        }
        
        let style = NSMutableParagraphStyle()
        
        var alignment = (self.titleAlignment ?? globalAttributes?.teaserDefaultTitleAlignment) ?? .center
        if UIDevice.isIPad() && (self.isEmbeddedTeaser?.bool == true) {
            alignment = .left
        }
        style.alignment = alignment
        if let tempTitle = self.title?.replacingOccurrences(of: " ", with: ""),
           tempTitle.isEmpty {
            completion?(NSAttributedString(string: self.title ?? ""))
        }
        let attrs = [NSAttributedString.Key.paragraphStyle: style,
                     NSAttributedString.Key.foregroundColor: fontColor,
                     NSAttributedString.Key.font: font]
        self.title?.convertHTMLInBackground(attrs:attrs) { result in
            completion?(result)
        }
    }
    
    func getSubTitleAttributedText(with globalAttributes:TeaserContentModel?, completion:((_ text: NSAttributedString?)->Void)?) {
        let fontColor = (self.attributes?.subTitleColor?.hexColor ?? globalAttributes?.attributes?.teaserSubTitleDefaultFontColor) ?? css?.subTitle?.color
        let font = self.css?.subTitle?.font ?? UIFont.boldSystemFont(ofSize: 14)
        let style = NSMutableParagraphStyle()
        var alignment = (self.titleAlignment ?? globalAttributes?.teaserDefaultTitleAlignment) ?? .center
        if UIDevice.isIPad() && (self.isEmbeddedTeaser?.bool == true){
            alignment = .left
        }
        style.alignment = alignment
        if let tempTitle = self.subTitle?.replacingOccurrences(of: " ", with: ""),
           tempTitle.isEmpty {
            completion?(NSAttributedString(string: self.subTitle ?? ""))
        }
        let attrs = [NSAttributedString.Key.paragraphStyle: style,
                     NSAttributedString.Key.foregroundColor: fontColor,
                     NSAttributedString.Key.font: font]
        self.subTitle?.convertHTMLInBackground(attrs: attrs, completion: { result in
            completion?(result)
        })
    }
    
    var ctaButtonTitleColor: UIColor? {
        self.css?.ctaButton?.title?.color
    }
    
    var ctaButtonBackgroundColor: UIColor? {
        self.css?.ctaButton?.normal ?? .white
    }
    
    var ctaButtonFont: UIFont? {
        var font = self.css?.ctaButton?.title?.font
        return font ?? UIFont(name: kRegularFont, size: 12) ?? UIFont.systemFont(ofSize: 12)
    }
    
    var contentViewBackgroundColor: UIColor? {
        self.backgroundColor?.hexColor ?? .black
    }
    
    var embeddedBannerBGColor: UIColor? {
        self.css?.embeddedBannerBGColor ?? .black
    }
    
    func getTermsAttributedText(with globalAttributes: TeaserContentModel?, completion: ((_ text: NSAttributedString?)->Void)?) {
        let fontColor = (globalAttributes?.attributes?.teaserDefaultTermsTextColor?.hexColor ?? self.css?.termsTextColor) ?? UIColor.white
        let font = self.css?.termsTextFont ?? UIFont.boldSystemFont(ofSize: 8)
        let style = NSMutableParagraphStyle()
        style.alignment = (self.titleAlignment ?? globalAttributes?.teaserDefaultTermsTextAlignment) ?? .center
        style.lineSpacing = 0.5
        style.firstLineHeadIndent = 5.0
        style.headIndent = 5.0
        if let tempTitle = self.termstext?.replacingOccurrences(of: " ", with: ""),
           tempTitle.isEmpty {
            completion?(NSAttributedString(string: self.termstext ?? ""))
        }
        let attrs = [NSAttributedString.Key.paragraphStyle: style,
                     NSAttributedString.Key.foregroundColor: fontColor,
                     NSAttributedString.Key.font: font]
        self.termstext?.convertHTMLInBackground(attrs: attrs, completion: { result in
            completion?(result)
        })
    }
}
