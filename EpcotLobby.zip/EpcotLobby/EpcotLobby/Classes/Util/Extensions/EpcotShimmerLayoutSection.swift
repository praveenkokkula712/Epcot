//
//  ShimmerLayoutSection.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 23/11/22.
//

import Foundation
import UIKit

fileprivate let kShimmerCategoriesFractionHeight: CGFloat = 0.06
fileprivate let kShimmerGamesFractionHeight: CGFloat = 0.23

struct EpcotLobbyShimmerLayoutSection {
    
    //MARK: - Category pills section layout
    static func categoryPillLayoutSection() -> NSCollectionLayoutSection {
        let item = ShimmerLayoutSection.defaultItem()
        
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(0.2),
                                               heightDimension: .fractionalHeight(kShimmerCategoriesFractionHeight))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        group.contentInsets = NSDirectionalEdgeInsets(top: 6, leading: 0, bottom: 0, trailing: 0)
        
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .continuous
        return ShimmerLayoutSection.sectionWithDefaultSpacing(section: section)
    }
    
    static func carouselTeasersLayoutSection() -> NSCollectionLayoutSection {
        return CustomLayoutSection.teasersLayoutSection()
    }
    
    //MARK: - Game cells layout
    static func gamesLayoutSection() -> NSCollectionLayoutSection {
        let item = ShimmerLayoutSection.defaultItem()
        
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                               heightDimension: .fractionalHeight(kShimmerGamesFractionHeight))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize,
                                                       subitems: [item])
        let section = NSCollectionLayoutSection(group: group)
        return ShimmerLayoutSection.sectionWithDefaultSpacing(section: section)
    }
}
 
struct ShimmerLayoutSection {
    //MARK: - Default Item
    static func defaultItem(widthDimention: CGFloat = 1.0, heightDimention: CGFloat = 1.0) -> NSCollectionLayoutItem {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(widthDimention),
                                              heightDimension: heightDimention > 1 ? .absolute(heightDimention) : .fractionalHeight(heightDimention))
        return NSCollectionLayoutItem(layoutSize: itemSize)
    }
    
    //MARK: - Default padding
    static func sectionWithDefaultSpacing(section: NSCollectionLayoutSection) -> NSCollectionLayoutSection {
        section.contentInsets = NSDirectionalEdgeInsets(horizontal: 8, vertical: 6)
        section.interGroupSpacing = 8
        return section
    }
        
    static func sectionWithDefaultImmersiveSpacing(section: NSCollectionLayoutSection) -> NSCollectionLayoutSection {
        section.contentInsets = NSDirectionalEdgeInsets(horizontal: 12, vertical: 0)
        section.interGroupSpacing = 12
        return section
    }
}
