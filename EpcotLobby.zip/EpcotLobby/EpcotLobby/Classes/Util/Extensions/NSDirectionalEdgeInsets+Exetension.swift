//
//  NSDirectionalEdgeInsets+Exetension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 19/04/22.
//

import Foundation

extension NSDirectionalEdgeInsets {
    
    static func uniform(size: CGFloat = 16.0) -> NSDirectionalEdgeInsets {
        return NSDirectionalEdgeInsets(top: size, leading: size, bottom: kSectionBottomPadding, trailing: size)
    }
    
    init(horizontal: CGFloat, vertical: CGFloat) {
        self.init(top: vertical, leading: horizontal, bottom: vertical, trailing: horizontal)
    }
}
