//
//  EntainSiteCoreMenuItem+Extension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 10/06/23.
//

import Foundation

extension EntainSiteCoreMenuItem {
    func getEntainSiteCoreItems(from categories: [String: String], type: String = Localize.featured) -> (siteCoreItem: [EntainSiteCoreItem]?, title: String?) {
        if let items = self.items {
            let title = self.title ?? type
            var resultItems = [EntainSiteCoreItem]()
            items.forEach { siteCoreItem in
                if let category = categories.keys.first(where: {$0 == siteCoreItem.parameters?.id}) {
                    let title = categories[siteCoreItem.parameters?.id ?? ""] ?? ""
                    siteCoreItem.title = title
                    resultItems.append(siteCoreItem)
                } else {
                    if let nativeActionUrl = siteCoreItem.parameters?.nativeActionUrl, !nativeActionUrl.isEmpty {
                        siteCoreItem.title = siteCoreItem.title?.displayName()
                        resultItems.append(siteCoreItem)
                    }
                }
            }
            if !resultItems.isEmpty {
                 return (resultItems, title)
            }
        }
        return (nil, nil)
    }
}
