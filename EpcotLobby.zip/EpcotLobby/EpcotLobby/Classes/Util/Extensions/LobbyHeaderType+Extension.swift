//
//  LobbyEnums.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 15/07/22.
//

import Foundation
import Utility

extension LobbyHeaderType {

    var height: CGFloat {
        switch self {
        case .gamesCategories:
            return 48.0
        case .lobbyExploreSwitcher:
            return 70.0
        case .wheelOfFortuneCategories:
            return 64.0
        case .epcotCategoryPills:
            return 44.0
        }
    }
}
