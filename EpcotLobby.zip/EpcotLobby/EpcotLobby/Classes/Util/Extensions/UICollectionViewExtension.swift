//
//  UICollectionViewExtension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 12/05/22.
//

import Foundation
import UIKit
import Utility

extension UICollectionView {
    
    func setupEpcotCollectionView() {
        self.setupDefaultConfiguration()
        self.registerDefaultCell(with: CellIdentifier.reuseIdentifier, CellIdentifier.originalsContainerCell)
        self.registerDefaultCell(with: CellIdentifier.reuseIdentifier,
                                 CellIdentifier.playerWidgetContainerCell)
        self.registerNibCells(withCells: CellIdentifier.gameCell,
                              CellIdentifier.teasersCollectionCell,
                              CellIdentifier.epcotEmbeddedBannerCell,
                              CellIdentifier.lobbyListCVCell,
                              CellIdentifier.portraitCell,
                              CellIdentifier.mustGoJackpoCell,
                              CellIdentifier.jackpotWidgetCell,
                              CellIdentifier.footerDividerLineCell,
                              CellIdentifier.footerStateChangerCell,
                              CellIdentifier.footerBaseCell,
                              CellIdentifier.footerTextContentCell,
                              CellIdentifier.footerLogoCell,
                              CellIdentifier.footerCopyRightCell,
                              CellIdentifier.gameTeaserVideosCustomCell,
                              CellIdentifier.epcotBannerVideoCell,
                              CellIdentifier.bingoWidgetContainerCell,
                              CellIdentifier.playerWidgetContainerCell,
                              bundle: kEpcotBundle)
        
        self.register(EpcotPageControlFooterView.self,
                      forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter,
                      withReuseIdentifier: CellIdentifier.teasersFooterCell)
        
        self.register(EpcotSectionHeader.self,
                      forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                      withReuseIdentifier: CellIdentifier.recentlyPlayedGamesHeader)
        self.register(BingoSectionCollectionViewCell.self,
                      forCellWithReuseIdentifier: CellIdentifier.bingoSectionCollectionViewCell)
        self.register(BingoWidgetContainerCell.self,
                      forCellWithReuseIdentifier: CellIdentifier.bingoWidgetContainerCell)
        
        self.register(UINib(nibName: CellIdentifier.moreSectionCell, bundle: kEpcotBundle),
                      forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                      withReuseIdentifier: CellIdentifier.moreSectionCell)

        self.register(NativeFooterBaseReusableView.self,
                      forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                      withReuseIdentifier: CellIdentifier.footerBaseHeaderReusableView)
        self.register(UICollectionViewCell.self, forCellWithReuseIdentifier: CellIdentifier.jackpotTileCell)
    }
}
