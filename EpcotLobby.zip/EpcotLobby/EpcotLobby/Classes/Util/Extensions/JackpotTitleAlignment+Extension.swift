//
//  Allignment.swift
//  EpcotLobby
//
//  Created by Bandana Choudhury on 02/09/24.
//

import Foundation
import ConfigModule

extension JackpotTitleAlignment {
    var alignment: UIStackView.Alignment {
        switch self {
        case .center:
            return .center
        case .left:
            return .leading
        case .right:
            return .trailing
        }
    }
}
