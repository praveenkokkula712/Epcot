//
//  String+CategoryDisplayConfig.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 08/07/24.
//

import Foundation
import ConfigModule

extension String {
    func displayName(isSubCategory: Bool = false) -> Self {
        guard let displayConfig = DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.categoryDisplayConfiguration  else {
            return self
        }
        if isSubCategory {
            let subCategory = displayConfig.subCategory
            return self.getString(for: subCategory)
        }
        let category = displayConfig.category
        return self.getString(for: category)
    }
    
    func getString(for type: NamingConfiguration) -> Self {
        switch type {
        case .upperCased:
            return self.localizedUppercase
        case .lowerCased:
            return self.localizedLowercase
        case .capitalized:
            return self.localizedCapitalized
        case .lmtBased:
            return self
        }
    }
}
