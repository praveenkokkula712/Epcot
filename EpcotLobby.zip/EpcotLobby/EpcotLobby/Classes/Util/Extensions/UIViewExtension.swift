//
//  UIViewExtension.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 20/04/23.
//

extension UIView {
    var globalFrameFromLobbyView: CGRect {
        if let globalSuperview = EpcotLobbyManager.shared?.delegate?.lobbyViewController?.view,
           let innerSuperView = self.superview {
            return globalSuperview.convert(self.frame, from: innerSuperView)
        }
        return self.frame
    }
}
