//
//  Entain+SVGURLExtension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 09/06/23.
//

import Foundation
import SwiftUI
import SVGKit

extension URL {
    var svgImage: some View {
        VStack {
            SVGImageView(url:self,
                         size: CGSize(width: 16, height: 16))
                .padding(.leading, 12)
                .padding(.trailing, 4)
        }
        .frame(height: 16)
    }
}
