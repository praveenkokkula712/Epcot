//
//  ImmersiveShimmerSection.swift
//  ImmersiveLobby
//
//  Created by Sreekanth Reddy Tadi on 28/11/22.
//

import Foundation
import UIKit

fileprivate let kShimmerHeaderHeight: CGFloat = 57
fileprivate let kShimmerCategoryHeight: CGFloat = 44

struct ImmersiveLobbyShimmerLayoutSection {
    
    static func shimmerCategoryLayout() -> NSCollectionLayoutSection {
        let section = CustomLayoutSection.fullWidthDynamicHeightSection(height: kShimmerCategoryHeight)
        section.contentInsets = NSDirectionalEdgeInsets(top: 12, leading: 0, bottom: 0, trailing: 0)
        return section
    }
    
    static func shimmerHorizontalGridLayout() -> NSCollectionLayoutSection {
        let fraction = UIDevice.isIPad() ? 0.19 : 0.37
        let section = CustomLayoutSection.horizontalscrollSection(with: fraction,
                                                                  isHeaderAvailable: false)
        return ImmersiveLobbyShimmerLayoutSection.titleHeaderWithDefualtSpacing(for: section)
    }
    
    static func shimmerVerticalImmersiveGrid() -> NSCollectionLayoutSection {
        let section = CustomLayoutSection.verticalImmersiveSection()
        return ImmersiveLobbyShimmerLayoutSection.titleHeaderWithDefualtSpacing(for: section)
    }
    
    static func shimmerVerticalGrid() -> NSCollectionLayoutSection {
        let section = CustomLayoutSection.gridLayoutSection(width: UIDevice.screenSize.width)
        return ImmersiveLobbyShimmerLayoutSection.titleHeaderWithDefualtSpacing(for: section)
    }
}

extension ImmersiveLobbyShimmerLayoutSection {
    fileprivate static func titleHeaderSection(with section: NSCollectionLayoutSection) -> NSCollectionLayoutSection {
        let headerLayoutSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1),
                                                      heightDimension: .absolute(kShimmerHeaderHeight))
        let item = NSCollectionLayoutBoundarySupplementaryItem(layoutSize: headerLayoutSize,
                                                               elementKind: UICollectionView.elementKindSectionHeader,
                                                               alignment: .topLeading)
        section.boundarySupplementaryItems = [item]
        section.supplementariesFollowContentInsets = true
        return section
    }
    
    fileprivate static func titleHeaderWithDefualtSpacing(for section: NSCollectionLayoutSection) -> NSCollectionLayoutSection {
        let titleSection = ImmersiveLobbyShimmerLayoutSection.titleHeaderSection(with: section)
        return ShimmerLayoutSection.sectionWithDefaultImmersiveSpacing(section: titleSection)
    }
}
