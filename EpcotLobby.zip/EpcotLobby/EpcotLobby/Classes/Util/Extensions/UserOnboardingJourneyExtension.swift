//
//  UserOnboardingJourneyExtension.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 13/04/23.
//

import Foundation

extension String {
    var popTipDirection:PopTipDirection {
        switch self.lowercased() {
        case "up": return .up
        case "down": return .down
        case "left": return .left
        case "right": return .right
        case "auto": return .auto
        case "none": return .none
        default: return .down
        }
    }
}
