//
//  NSCollectionLayoutBoundarySupplementaryItem+Extension.swift
//  EpcotLobby
//
//  Created by Challa Venkata Narasimha Karthik on 21/04/22.
//

import Foundation

struct CustomBoundarySupplementaryItem {
    static func fixedHeightSupplementaryItem(with height: CGFloat,
                                             kind: String = UICollectionView.elementKindSectionHeader, alignment:NSRectAlignment = .top ) -> NSCollectionLayoutBoundarySupplementaryItem {
        
        let headerLayoutSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                      heightDimension: .absolute(height))
        return NSCollectionLayoutBoundarySupplementaryItem(layoutSize: headerLayoutSize,
                                                           elementKind: kind,
                                                           alignment: alignment)
    }

    static func fixedSizeSupplementaryItem(
        width: CGFloat,
        height: CGFloat,
        kind: String = UICollectionView.elementKindSectionHeader,
        alignment:NSRectAlignment = .top
    ) -> NSCollectionLayoutBoundarySupplementaryItem {

        let headerLayoutSize = NSCollectionLayoutSize(
            widthDimension: .absolute(width),
            heightDimension: .absolute(height)
        )
        return NSCollectionLayoutBoundarySupplementaryItem(
            layoutSize: headerLayoutSize,
            elementKind: kind,
            alignment: alignment
        )
    }
}
