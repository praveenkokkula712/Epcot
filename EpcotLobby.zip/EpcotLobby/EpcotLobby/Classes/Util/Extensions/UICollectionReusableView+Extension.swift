//
//  UICollectionReusableView+Extension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 29/11/22.
//

import Foundation

extension UICollectionReusableView {
    static var reuseIdentifier: String {
        return String(describing: Self.self)
    }
}
