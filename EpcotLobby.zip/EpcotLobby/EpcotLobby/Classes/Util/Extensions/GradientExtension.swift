//
//  GradientExtension.swift
//  EpcotLobby
//
//  Created by Bandana Choudhury on 28/07/23.
//

import Foundation
import SwiftUI

extension Gradient {
    private static var overlaysCSS: OverlaysCSSModel {
        OverlaysCSSModel()
    }
    
    static var interactionModel: InstantInteractionModel? {
        EpcotLobbyManager.shared?.datasource?.didRequestForInstantInteraction
    }
    
    private static var isEpcotFeatureEnabled: Bool {
        return EpcotLobbyManager.shared?.css.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false
    }
    static var overlay40Color: Gradient {
        let color = interactionModel?.overlay40Color?.hexColor?.withAlphaComponent(0.4) ?? UIColor.white.withAlphaComponent(0.4)
        return Gradient(colors: [Color(color)])
    }
    
    static var defaultGradientColors: Gradient {
        if isEpcotFeatureEnabled {
            return Gradient(colors: [Color(CasinoCSS.lobby?.epcotLobbyCSS?.epcotMandortyUpdateButtonColors1 ?? .black), Color(CasinoCSS.lobby?.epcotLobbyCSS?.epcotMandortyUpdateButtonColors2 ?? .black)])
        }
        return  Gradient(colors: [overlaysCSS.ctaButtonBackgroundColor])
    }
}
