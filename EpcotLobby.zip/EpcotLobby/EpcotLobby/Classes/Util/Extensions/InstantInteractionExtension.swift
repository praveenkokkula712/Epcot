//
//  InstantInteractionExtension.swift
//  EpcotLobby
//
//  Created by Bandana Choudhury on 28/04/23.
//

import Foundation
import Utility

public enum InteractionType {
    case opacity
    case transform
    case overLay12
    case overLay40
}


public extension InteractionType {
    
    public var interactionModel: InstantInteractionModel? {
        EpcotLobbyManager.shared?.datasource?.didRequestForInstantInteraction
    }
        
    public var interaction: InstantInteraction {
        var interactionType: InstantInteraction = .none
        guard  let interactionModel = interactionModel else {
            return interactionType
        }
        switch self {
        case .opacity:
            if let opacity = interactionModel.opacity {
                interactionType = InstantInteraction.decreaseOpacity(opacity)
            }
        case .transform:
            if let transform = interactionModel.transformSize {
                interactionType = InstantInteraction.reduceSize(transform)
            }
        case .overLay12:
            if let overLayColor = interactionModel.overlay12Color {
                interactionType = InstantInteraction.overlay12(overLayColor.hexColor ?? .white)
            }
        case .overLay40:
            if let overLayColor = interactionModel.overlay40Color {
                interactionType = InstantInteraction.overlay40(overLayColor.hexColor ?? .white)
            }
        }
        return interactionType
    }
}
