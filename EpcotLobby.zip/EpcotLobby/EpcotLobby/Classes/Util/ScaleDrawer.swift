    //
    //  ScaleDrawer.swift
    //  EpcotLobby
    //
    //  Created by Praveen Kokkula on 24/05/22.
    //

import Foundation
import UIKit

class ScaleDrawer {
    var size: CGFloat
    var space: CGFloat
    var dotsColor: UIColor
    var dotSelectedColor: UIColor
    
    var scaleFactor: CGFloat = 4
    var currentItem: CGFloat = 0
    var numberOfPages: Int = 5
    var drawerStyle: DrawerStyle = .scale
    
    init(size: CGFloat = 8,
         space: CGFloat = 9,
         dotsColor: UIColor = UIColor.white,
         selectedColor: UIColor = UIColor.white) {
        self.space = space
        self.dotsColor = dotsColor
        self.size = size
        self.dotSelectedColor = selectedColor
    }
    
    func getCenteredXPosition(_ rect: CGRect, itemPos: CGFloat, numberOfPages: Int) -> CGFloat {
        let individualDotPos = (itemPos * (size + space))
        let halfViewWidth = (rect.width / 2)
        let halfAlldotsWidthWithSpaces = ((CGFloat(numberOfPages) * (size + (space - 1))) / 2.0)
        return individualDotPos - halfAlldotsWidthWithSpaces + halfViewWidth
    }
    
    func getCenteredYPosition(_ rect: CGRect) -> CGFloat {
        let halfViewHeight = (rect.size.height / 2)
        let halfDotSize = (size / 2)
        let centeredYPosition = halfViewHeight - halfDotSize
        return centeredYPosition
    }
    
    func drawItem(_ rect: CGRect, raduis: CGFloat, color: UIColor,  index _: Int = 0) {
        let path = UIBezierPath(roundedRect: rect, cornerRadius: raduis)
        path.stroke()
        color.setFill()
        path.fill()
    }
    
    func draw(_ rect: CGRect) {
        switch self.drawerStyle {
        case .slide:
            self.drawSlideIndicators(rect)
            self.drawCurrentItem(rect)
        case .scale:
            self.drawScaleTranslation(rect)
        }
    }
    
    private func drawScaleTranslation(_ rect: CGRect) {
        for i in 0 ..< numberOfPages {
            let topTranslate = scaleFactor
            let progress = currentItem - floor(currentItem)
            let translate = scaleFactor * (currentItem - floor(currentItem))
            if Int(floor(currentItem)) != i {
                if i == Int(floor(currentItem) + 1) {
                    let centeredYPosition = getCenteredYPosition(rect)
                    let y = rect.origin.y + centeredYPosition - (translate / 2)
                    let x = getCenteredXPosition(rect, itemPos: CGFloat(i), numberOfPages: numberOfPages) - (translate / 2)
                    drawItem(CGRect(x: x, y: y, width: size + translate, height: size + translate),
                             raduis: (size / 2) + (translate / 2),
                             color: dotsColor,
                             index: i)
                } else {
                    let centeredYPosition = getCenteredYPosition(rect)
                    let y = rect.origin.y + centeredYPosition
                    let x = getCenteredXPosition(rect, itemPos: CGFloat(i), numberOfPages: numberOfPages)
                    drawItem(CGRect(x: x, y: y, width: size, height: size),
                             raduis: (size / 2),
                             color: dotsColor,
                             index: i)
                }
            } else {
                let opisiteTranslate = (topTranslate - translate)
                let centeredYPosition = getCenteredYPosition(rect)
                let y = rect.origin.y + centeredYPosition - (opisiteTranslate / 2)
                let x = getCenteredXPosition(rect, itemPos: CGFloat(i), numberOfPages: numberOfPages) - (opisiteTranslate / 2)
                drawItem(CGRect(x: x, y: y, width: size + opisiteTranslate, height: size + opisiteTranslate),
                         raduis: (size / 2) + (opisiteTranslate / 2),
                         color: dotSelectedColor,
                         index: i)
            }
        }
    }
    
    func drawSlideIndicators(_ rect: CGRect) {
        for i in 0 ..< numberOfPages {
            let centeredYPosition = getCenteredYPosition(rect)
            let y = rect.origin.y + centeredYPosition
            let x = getCenteredXPosition(rect, itemPos: CGFloat(i), numberOfPages: numberOfPages)
            let color = EpcotLobbyManager.shared?.css.jackpotWidgets?.widgetNormalColor ?? .gray
            drawItem(CGRect(x: x, y: y, width: CGFloat(8), height: CGFloat(8)),
                     raduis: 4.0, color: color, borderWidth: 1.0)
        }
    }

    fileprivate func drawCurrentItem(_ rect: CGRect) {
        let centeredYPosition = getCenteredYPosition(rect)
        let y = rect.origin.y + centeredYPosition
        let x = getCenteredXPosition(rect, itemPos: currentItem, numberOfPages: numberOfPages)
        let color = EpcotLobbyManager.shared?.css.jackpotWidgets?.widgetSelectedColor ?? UIColor.hexStringToUIColor(hex: "#FFCC00")
        drawItem(CGRect(x: x, y: y, width: 8, height: 8),
                 raduis: 4.0, color: color, borderWidth: 1.0)
    }
    
    func drawItem(_ rect: CGRect, raduis: CGFloat, color: UIColor, borderWidth: CGFloat = 0) {
        let path = UIBezierPath(roundedRect: rect, cornerRadius: raduis)
        path.lineWidth = borderWidth
        color.setStroke()
        path.stroke()
        color.setFill()
        path.fill()
    }
}

func + (color1: UIColor, color2: UIColor) -> UIColor {
    var (r1, g1, b1, a1) = (CGFloat(0), CGFloat(0), CGFloat(0), CGFloat(0))
    var (r2, g2, b2, a2) = (CGFloat(0), CGFloat(0), CGFloat(0), CGFloat(0))
    
    color1.getRed(&r1, green: &g1, blue: &b1, alpha: &a1)
    color2.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)
    
        // add the components, but don't let them go above 1.0
    return UIColor(red: min(r1 + r2, 1), green: min(g1 + g2, 1), blue: min(b1 + b2, 1), alpha: (a1 + a2) / 2)
}

func * (color: UIColor, multiplier: Double) -> UIColor {
    var (r, g, b, a) = (CGFloat(0), CGFloat(0), CGFloat(0), CGFloat(0))
    color.getRed(&r, green: &g, blue: &b, alpha: &a)
    return UIColor(red: r * multiplier, green: g * multiplier, blue: b * multiplier, alpha: a)
}


enum DrawerStyle {
    case scale
    case slide
}
