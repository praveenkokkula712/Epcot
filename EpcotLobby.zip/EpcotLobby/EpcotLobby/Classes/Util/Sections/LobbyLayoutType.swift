//
//  LobbyLayoutType.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 10/06/23.
//

import Foundation

enum LayoutType: Int {
    case verticalImmersiveGrid = 1 // row count is 0 and above icon size: 1
    case list // row count is 0 and above icon size: 2
    case portraitSection // any row  count and above icon size: 3
    case verticalGrid // row count is 0 and above icon size: 4
    case horizontalGrid // row count is -1 and above icon size: 4
    case horizontalImmersiveGrid // row count is -1 and above icon size: 1
    case recentlyPlayedGrid // row count is -1 and above icon size: 1
    case favouriteGamesGrid
    case teasers
    case embeddedBanner
    case superSquare // row count is 0  and above icon size: 11
    case jackpotWidget
    case multipleJackpotWidget
    case jackpotMustGoWidget
    case multiJackpotWidgetGames
    case footerDividerLine
    case footerStateswitcher
    case footerAboutUs
    case footerSeoLinks
    case footerMediaLogos
    case footerBrandLogos
    case footerTextContent
    case footerCopyRight
    case bingoButtonLayout
    case videoLayout
    case bingoWidgetLayout
    case freeSpinsWidget
    case topGamesImmersiveGrid
    case topGamesHorizontalGrid
    case topGamesPortraitGrid
    case playerStatsWidget
    case jackpotTiles
    case engagementTools
    case jackpotTileFullWidth
    case originalsWidget
    
    var isGamesSection: Bool {
        switch self {
        case .verticalImmersiveGrid,.list, .portraitSection,.verticalGrid, .horizontalGrid, .horizontalImmersiveGrid, .recentlyPlayedGrid, .favouriteGamesGrid, .superSquare:
            return true
        default:
            return false
        }
    }
}
