//
//  LobbyLayoutType+Extension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 10/06/23.
//

import Foundation

extension LayoutType {
    
    var isFooterLayoutType: Bool {
        self == .footerStateswitcher ||
        self == .footerAboutUs ||
        self == .footerSeoLinks ||
        self == .footerMediaLogos ||
        self == .footerBrandLogos ||
        self == .footerTextContent ||
        self == .footerCopyRight
    }
    
    var isJackpotWidget: Bool {
        self == .jackpotWidget || self == .multipleJackpotWidget || self == .jackpotMustGoWidget
    }
}
