//
//  LobbySection.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 19/04/22.
//

import Foundation

enum EpcotLobbySectionType: Int,CaseIterable {
    case teasers
}
