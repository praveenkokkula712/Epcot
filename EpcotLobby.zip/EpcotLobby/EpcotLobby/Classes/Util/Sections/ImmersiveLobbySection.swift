//
//  ImmersiveLobbySection.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 05/08/22.
//

import Foundation
import UIKit
import CasinoAPI

struct ImmersiveLobbySection: Hashable {
    
    static func == (lhs: ImmersiveLobbySection, rhs: ImmersiveLobbySection) -> Bool {
        lhs.subCategoryId == rhs.subCategoryId && lhs.uuid == rhs.uuid
    }
    let uuid = UUID()
    var subCategoryId: String?
    var games: [Game]?
    var bingoLobbyModel: BingoLobbyModel?
    var layoutType: LayoutType = .verticalImmersiveGrid
    var isGamesPrefixed: Bool = false
    var jackpotWidget: [JackpotWidgetsModel]? = nil
    var jackpotName: String? = nil
    var footerAboutUsItem: [FooterAboutUsModel]? = nil
    var footerSeoLinks: [FooterSeoLinksModel]? = nil
    var footerContent: [FooterContentModel]? = nil
    var footerMediaLogos: [FooterLogoContentModel]? = nil
    var footerBrandLogos: [FooterLogoContentModel]? = nil
    var footerCopyRight: [FooterCopyRightModel]? = nil
    var freeSpinWidgets: NativeWidgetsModel? = nil
    var playerStatsWidget: NativeWidgetsModel? = nil
    var engagementTools: NativeWidgetsModel? = nil
    var originalsWidget: (model: OriginalsWidgetConfigurations?, showInCategory: Bool)? = nil
    var jackpotTiles: [JackPotModel]? = nil
    var isHeaderAvailable: Bool = true
    var isPreBannerGames: Bool = true
    var bingoButtonLogo: [String]? = nil
    var isFromSearchController: Bool = false
    var subCategoryHeaderDescription: String? = nil
    var route: String?
    
    var isHeaderDescriptionAvailable: Bool {
        get {
            return !(subCategoryHeaderDescription?.isEmpty ?? true)
        }
    }
    
    var videosTeasersSection: [NativeWidgetsModel]? = nil
    ///Jackpot Widget layout Type for Qualifying games section
    var widgetLayoutType: LayoutType = .verticalImmersiveGrid
    
    // Free Spins Models
    var prominentFreeSpins: ProminentFreeSpins?
    var freeSpinsDetails: ProminentFreeSpinDetails?

    // Engagement Tools
    // TODO: Engagement Tools - Create data store properties
    var promoEngagementTools: [EngagementTool.ToolType: [PromoEngagementTool]]?

    func hash(into hasher: inout Hasher) {
        hasher.combine(subCategoryId)
        hasher.combine(uuid)
    }
    
    mutating func updateGames(newGames: [Game]) {
        self.games = newGames
    }
    
    func createSection(with deviceWidth: CGFloat,
                       isFirstSection: Bool = false,
                       numberOfTeasers: Int = 0,
                       isFreeSpinsScrollable: Bool,
                       isEngagementToolsScrollable: Bool) -> NSCollectionLayoutSection {
        switch self.layoutType {
        case .verticalImmersiveGrid:
            return CustomLayoutSection.verticalImmersiveSection(isHeaderAvailable: isHeaderAvailable,
                                                                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable, isFirstSection: isFirstSection,
                                                                isFromSearchController:
                                                                    isFromSearchController)
        case .horizontalImmersiveGrid, .recentlyPlayedGrid, .favouriteGamesGrid:
            let fraction = UIDevice.isIPad() ? 0.15 : 0.29
            return CustomLayoutSection.horizontalscrollSection(with: fraction,
                                                               isHeaderAvailable: isHeaderAvailable,
                                                               isHeaderDescriptionAvailable: isHeaderDescriptionAvailable,
                                                               isFirstSection: isFirstSection)
        case .horizontalGrid:
            let fraction = UIDevice.isIPad() ? 0.23 : 0.44
            return CustomLayoutSection.horizontalscrollSection(with: fraction,
                                                               isHeaderAvailable: isHeaderAvailable,
                                                               isHeaderDescriptionAvailable: isHeaderDescriptionAvailable,
                                                               isFirstSection: isFirstSection)
        case .verticalGrid:
            return CustomLayoutSection.gridLayoutSection(width: deviceWidth,
                                                         isPreBanner: isPreBannerGames,
                                                         isHeaderAvailable: isHeaderAvailable,
                                                         isHeaderDescriptionAvailable: isHeaderDescriptionAvailable,
                                                         isFirstSection: isFirstSection,
                                                         isFromSearchController: isFromSearchController)
        case .list:
            return CustomLayoutSection.listGameCellLayoutSection(width: deviceWidth,
                                                                 isPreBanner: isPreBannerGames,
                                                                 isHeaderAvailable: isHeaderAvailable,
                                                                 isHeaderDescriptionAvailable: isHeaderDescriptionAvailable,
                                                                 isFirstSection: isFirstSection,
                                                                 isFromSearchController: isFromSearchController)
        case .teasers:
            if UIDevice.isIPad() {
                let teasersWidth: CGFloat = CGFloat(32 + (8 * numberOfTeasers) + (280 * numberOfTeasers))
                if teasersWidth < deviceWidth {
                    return CustomLayoutSection.teasersIpadLayoutSection(numberOfTeasers: numberOfTeasers)
                }
            }
            return CustomLayoutSection.carouselTeasersLayoutSection()
        case .embeddedBanner:
            return CustomLayoutSection.embeddedBannersLayoutSection()
        case .superSquare:
            return CustomLayoutSection.fullWidthGridSection(isFirstSection: isFirstSection,
                                                            isHeaderAvailable: isHeaderAvailable,
                                                            isHeaderDescriptionAvailable: isHeaderDescriptionAvailable)
        case .portraitSection:
            return CustomLayoutSection.portraitSectionLayout(isFirstSection: isFirstSection, isHeaderAvailable: isHeaderAvailable, isHeaderDescriptionAvailable: isHeaderDescriptionAvailable)
        case .jackpotMustGoWidget:
            return CustomLayoutSection.jackpotMustGoWidgetLayoutSection(
                isHeaderAvailable: isHeaderAvailable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable
            )
        case .jackpotWidget:
            return CustomLayoutSection.jackpotWidgetLayoutSection(
                isHeaderAvailable: isHeaderAvailable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable
            )
        case .multipleJackpotWidget:
            return CustomLayoutSection.multipleJackpotWidgetsLayoutSection(
                isHeaderAvailable: isHeaderAvailable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable
            )
        case .multiJackpotWidgetGames:
            let fraction = UIDevice.isIPad() ? 0.15 : 0.29
            return CustomLayoutSection.horizontalWidgetGamesScrollSection(with: fraction,
                                                                          widgetLayoutType: self.widgetLayoutType)
        case .footerDividerLine:
            return CustomLayoutSection.nativeFooterDividerLineLayout()
        case .footerStateswitcher:
            return CustomLayoutSection.nativeFooterStateSwitcherLayout()
        case .footerAboutUs:
            return CustomLayoutSection.nativeFooterAboutUsSectionLayout()
        case .footerSeoLinks:
            return CustomLayoutSection.nativeFooterSeoLinksSectionLayout()
        case .footerTextContent:
            return CustomLayoutSection.nativeFooterContentLayout()
        case .footerMediaLogos, .footerBrandLogos:
            return CustomLayoutSection.nativeFooterLogosLayout()
        case .footerCopyRight:
            return CustomLayoutSection.nativeFooterCopyRightLayout()
        case .bingoButtonLayout:
            return CustomLayoutSection.bingoLogoSectionLayout()
        case .videoLayout:
            return CustomLayoutSection.videoLayoutSection(
                isHeaderAvailable: isHeaderAvailable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable
            )
        case .bingoWidgetLayout:
            return CustomLayoutSection.nativeBingoWidgetSectionLayout()
        case .freeSpinsWidget:
            return CustomLayoutSection.freeSpinsWidgetSectionLayout(
                isHeaderAvailable: isHeaderAvailable,
                isFreeSpinsScrollable: isFreeSpinsScrollable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable
            )
        case .topGamesImmersiveGrid:
            let insetFactor = 16.0 / UIDevice.screenSize.width
            let heightFactor = UIDevice.isIPad() ? 0.15 : 0.3
            let layoutSection = CustomLayoutSection.topGamesHorizontalScrollSection(
                layoutType: self.layoutType,
                heightFactor: heightFactor + insetFactor,
                isHeaderAvailable: isHeaderAvailable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable,
                isFirstSection: isFirstSection
            )
            return layoutSection
        case .topGamesHorizontalGrid:
            let insetFactor = 16.0 / UIDevice.screenSize.width
            let heightFactor = UIDevice.isIPad() ? 0.23 : 0.44
            let layoutSection = CustomLayoutSection.topGamesHorizontalScrollSection(
                layoutType: self.layoutType,
                heightFactor: heightFactor + insetFactor,
                isHeaderAvailable: isHeaderAvailable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable,
                isFirstSection: isFirstSection
            )
            return layoutSection
        case .topGamesPortraitGrid:
            let layoutSection = CustomLayoutSection.topGamesHorizontalScrollSection(
                layoutType: self.layoutType,
                isHeaderAvailable: isHeaderAvailable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable,
                isFirstSection: isFirstSection
            )
            return layoutSection
        case .playerStatsWidget:
            return CustomLayoutSection.playerStatWidgetSectionLayout(
                isHeaderAvailable: isHeaderAvailable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable
            )
        case .engagementTools:
            return CustomLayoutSection.engagementToolsSectionLayout(
                isHeaderAvailable: isHeaderAvailable,
                isEngagementToolsScrollable: isEngagementToolsScrollable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable
            )
        case .jackpotTiles:
            return CustomLayoutSection.jackpotTilesSectionLayout(
                isJackPotFullWidthNeeded: self.jackpotTiles?.count == 1,
                isHeaderAvailable: isHeaderAvailable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable,
                isCategorySection: self.jackpotTiles?.count == 1
            ) // 85% of screen width in lobby
        case .originalsWidget:
            let showInCategory = self.originalsWidget?.showInCategory ?? false
            return CustomLayoutSection.originalsWidgetSectionLayout(showInCategory: showInCategory,
                                                                    isHeaderAvailable: isHeaderAvailable,
                                                                    isHeaderDescriptionAvailable: isHeaderDescriptionAvailable)
        case .jackpotTileFullWidth:
            return CustomLayoutSection.jackpotTilesSectionLayout(
                isJackPotFullWidthNeeded: true,
                isHeaderAvailable: isHeaderAvailable,
                isHeaderDescriptionAvailable: isHeaderDescriptionAvailable,
                isCategorySection: false
            ) // 100% of screen width in allEligibleGames View
        }
    }
}
