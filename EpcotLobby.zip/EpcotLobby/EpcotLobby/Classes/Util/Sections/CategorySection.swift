//
//  CategorySection.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 19/04/22.
//

import Foundation
import CasinoAPI

enum EpcotLobbyCateogrySectionType: Int, CaseIterable {
    case categories
}
