//
//  EpcotMenuSection.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 10/06/23.
//

import Foundation

enum EpcotMenuSection: Int, CaseIterable {
    case featured, foryou, appAds, headerBar
}
