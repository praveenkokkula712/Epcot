//
//  TypeAliases.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 19/04/22.
//

import Foundation
import CasinoAPI
import Combine

 //MARK: - NSDiffableDataSourceSnapshot
typealias CategorySnapshot = NSDiffableDataSourceSnapshot<EpcotLobbyCateogrySectionType, CategoryItem>

typealias MenuSnapshot = NSDiffableDataSourceSnapshot<EpcotMenuSection, MenuItem>

typealias SearchSnapshot = NSDiffableDataSourceSnapshot<EpcotSearchSection, SearchItem>

typealias ImmersiveSnapshot = NSDiffableDataSourceSnapshot<ImmersiveLobbySection, Item>

typealias EpcotShimmerSnapshot = NSDiffableDataSourceSnapshot<EpcotShimmerSectionType, EpcotShimmerItem>

typealias ImmersiveShimmerSnapshot = NSDiffableDataSourceSnapshot<ImmersiveShimmerSectionType, ImmersiveShimmerItem>

//MARK: - UICollectionViewDiffableDataSource
typealias CategoryDatasource = UICollectionViewDiffableDataSource<EpcotLobbyCateogrySectionType, CategoryItem>

typealias MenuDatasource = UICollectionViewDiffableDataSource<EpcotMenuSection, MenuItem>

typealias SearchDatasource = UICollectionViewDiffableDataSource<EpcotSearchSection, SearchItem>

typealias SwitcherCategoryDatasource = UITableViewDiffableDataSource<EpcotLobbyCateogrySectionType, CategoryItem>

typealias ImmersiveDatasource = UICollectionViewDiffableDataSource<ImmersiveLobbySection, Item>

typealias EpcotShimmerDatasource = UICollectionViewDiffableDataSource<EpcotShimmerSectionType, EpcotShimmerItem>

typealias ImmersiveShimmerDatasource = UICollectionViewDiffableDataSource<ImmersiveShimmerSectionType, ImmersiveShimmerItem>

//MARK: - Other Constants
typealias SubNavigationItems =  [SubNavigationType :[EntainSiteCoreItem]]
typealias BurgerMenuItems = [EpcotMenuSection: (items: [EntainSiteCoreItem], headerTitle: String)]
typealias GamePlayHandler = ((_ game: String, _ additionalParams: AdditionalParameters? ) -> Void)

typealias CategorySelectionHandler = ((_ item: EntainSiteCoreItem, _ location: String) -> Bool)

typealias ImmersiveGameInfo = (imagePath: String, gameInfo: LocalGameInfo, fireIconImagePath: String)

typealias GameTilePublisher = PassthroughSubject<GameTileReceiver?, Never>

//MARK: - Use Onboarding
public typealias UserOnboardingPassthroughSubject = PassthroughSubject<UserOnboardingJourney, Never>

