//
//  CustomSearchButton.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 15/02/23.
//

import UIKit

public class CustomSearchButton: UIButton {

    func updateButtonTheming(with css: SearchInputAccessoryViewCSS?) {
        self.backgroundColor = css?.bottomSearchButtonBgColor
        self.setTitleColor(.black, for: .normal)
        self.setTitleColor(css?.bottomSearchButtonTitle?.color, for: .normal)
        self.setTitle(Localize.searchTitle, for: .normal)
        self.titleLabel?.font = css?.bottomSearchButtonTitle?.font
        let tintColor = css?.bottomSearchIconTintColor
        self.setImage(with: kBottomSearch, tintColor: tintColor, bundle: kEpcotBundle)
    }
}
