//
//  WebLinkItemType.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 15/06/23.
//

import Foundation
import CasinoAPI
import Utility

public enum WebLinkItemType {
    case categories(EntainSiteCoreItem) ///On categories and menu web link selection
    case teasers(TeaserContentModel) /// Teasers selection
    case footer(NativeFooterItem) /// Footer selection
    case bingoItem(String) /// app advertisement logo.
    case bingoRoom(String) /// Bingo Room Play URL
    case toastersAndOverlays(String)
    case teaserVideos(String)
    case gameStoryItem(String)
    case regulatoryItem(Int, String)
    case freeSpinsDetails(String)
    case jackpotTiles(String)
}
