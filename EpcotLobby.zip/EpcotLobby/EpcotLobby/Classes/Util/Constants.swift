//
//  Constants.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 07/04/22.
//

import Foundation

let kReal = "real"
let kLobbyCornerRadius: CGFloat = 12.0
let kSquareImageFolder = "supersquare"
let kiOSImageFolder = "ios"
let kFire = "fire"
let kEpcotBundle = Bundle(for: EpcotLobbyManager.self)
let kSearchIcon: String = "searchIcon"
let kMenuIcon: String = "hamburgerIcon"
let kbackArrowIcon = "back_arrow"
let kNoResults =  "noResults"
let kSearchWhite = "search_white"
let kBottomSearch = "bottom_search"
let kBack = "back"
let kUiStatusBarStyle = "UIStatusBarStyle"
let kUiStatusBarStyleLightContent = "UIStatusBarStyleLightContent"
let kCloseWhite = "closeWhite"
let kClose = "Close"
let kLmcRecentlyPlay = "LMC_RECENTLY_PLAYED_GAMES_NATIVE"
let kLmcFavourites = "LMC_FAVOURITE_GAMES_NATIVE"
let kLmcBingoButton = "LMC_BINGO_BUTTON_NATIVE"
let kDefaultCategory = "LMC_DEFAULT"
///for Switcher Category Views
let kGridLayoutIcon = "grid_view"
let kListLayoutIcon = "list_view"
let kDropDownIcon = "dropDown"
let kcheckMarkIcon = "checkmark"
let kDownloadIcon = "download"
let kRecentPlayIcon = "recent_play"

let kFavouriteSelected   = "icon-glyph_favorites_i"
let kFavouriteUnselected  = "icon-glyph_favorites"

let kAnimationDuration: CGFloat = 0.3

let searchContainerHeight: CGFloat = 52.0
let kMaxSearchTextFiledLength = 200
let kSearchTopSpaceValue: CGFloat = 24
let kSectionHeaderHeight: CGFloat = 24
let kHeaderDescriptionHeight: CGFloat = 24
let kFirstSectionHeaderHeight: CGFloat = 28
let kSectionBottomPadding: CGFloat = 32
let kSearchQueueKey = "SearchQueue"
let kErase = "erase"

let kBottomSearchButtonWidthConstraint = 86.0
let kBottomSearchButtonBottomConstraint = 8.0
let kBottomSearchkButtonCornerRadius = 15.0
let kDefaultKeyBoardHeight = 216.0
let kGameImageCornerRadius: CGFloat = 8.0
let kButtonCornerRadius: CGFloat = 3.0
let kMenuContainerWidth: CGFloat = 90.0
let kMainViewPadding: CGFloat = 6.0
let kSearchContainerBGColor: UIColor = UIColor(red: 118/255, green: 118/255, blue: 128/255, alpha: 0.24)
let kImageCornerRadius: CGFloat = 8.0

// CompositionalCollectionView layout constants
let kPercentageOfColumnsLandscape: CGFloat = 1/4
let kPercentageOfColumnsPortraitIpad: CGFloat = 1/3
let kPercentageOfColumnsPortrait: CGFloat = 1/2
let kColumnsLandscape: Int = 4
let kColumnsPortraitIpad: Int = 3
let kColumnsPortrait: Int = 2
let kColumnsPortraitIphone: Int = 3
let kColumnsIpad:Int = 5
let kGlobalSearch = "globalSearch"

let kMaxWidthThresholdLandscape: CGFloat = 1000.0
let kShimmerFooterHeight: CGFloat = 75.0
let kShimmerTitleHeight: CGFloat = 13
let microphone = "microphone_fill"

let kArrow = "arrow"

let kRegularFont = "Roboto-Regular"

let kHorizontalScrollRowCount = -1
let kGridVerticalScrollRowCount = 0
let kPortraitSectionRowCount = -2


let kTrackEventQueue = "TrackEvent"
let seeMoreSideArrow = "seeMoreSideArrow"
let kCollectionViewOffSet = CGPoint(x: 0, y: -4)

let kStateIconSelected = "icon-theme-radio-on"
let kStateIconUnSelected = "icon-theme-radio-off"

let kResetBottomSearchLayout = "resetBottomSearchLayout"

let kToasterCardHeight = 72.0
let kToasterImageHeight = 56.0

let kOverlayCardHeight : CGFloat = 450.0
let kOverlayMultiCardHeight : CGFloat = 480.0

///Casino Game Story
let leftArrowIcon = "left-arrow-big"
let rightArrowIcon = "right-arrow"
let kUpArrowIcon = "up-arrow"
///For Gaming Story See More View
let minDraggedOffset: CGFloat = 170

///Casino Game Story Onboarding Hint text
let kOnboardingLeftHint = "Swipe or tap on the left to go to the previous story"
let kOnboardingTapHint = "Tap and hold to pause the story"
let kOnboardingRightHint = "Swipe or tap on the right to go to the next story"


/// SubCategory display type attribute keys
let kTitleDisplayColor = "subCategoryTitleTextColor"
let kDescriptionDisplayColor = "subCategoryDescriptionTextColor"
let kSubCategoryDisplayType = "subCategoryDisplayType"
