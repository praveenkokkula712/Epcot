//
//  Epcot+EntainSiteCoreItemExtension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 09/06/23.
//

import Foundation
import CasinoAPI
import Utility
import SVGKit
import SwiftUI

extension EntainSiteCoreItem {
    
    var epcotCss: EpcotLobbyCSS? {
        EpcotLobbyManager.shared?.css.epcotLobbyCSS
    }
    
    var epcotIconVariant: IconVariant? {
        let iconName = self.isSelected ? self.parameters?.iconCss?.selectedNativeIcon : self.parameters?.iconCss?.nativeIcon
        let iconVariant = EpcotLobbyManager.shared?.datasource?.didRequestForIconVariant(with: iconName ?? "", fontSize: epcotCss?.categoriesPillsIconFontSize ?? 16.0)
        return iconVariant
    }
    
    var epcotIcon: String {
        epcotIconVariant?.icon ?? ""
    }
    
    var epcotIconFont: Font {
        Font(epcotIconVariant?.font ?? .systemFont(ofSize: 12))
    }
    
    var epcotIconColor: Color {
        let textColor = self.isSelected ? epcotCss?.categoriesSelectedPillTitle?.color : epcotCss?.categoriesPillTitle?.color
        return Color(textColor ?? .black)
    }
    
    var epcotBorderColor: Color {
        let borderColor = epcotCss?.categoriesPillBorderColor
        return Color(borderColor ?? .white)
    }
    
    var epcotTitleColor: Color {
        let textColor = self.isSelected ? epcotCss?.categoriesSelectedPillTitle?.color : epcotCss?.categoriesPillTitle?.color
        return Color(textColor ?? .white)
    }
    
    var epcotTitleFont: Font {
        Font(epcotCss?.categoriesPillTitle?.font ?? .systemFont(ofSize: 12))
    }
    
    var isEpcotSVGImageAvailable: Bool {
        let iconURL = epcotIconUrl
        let selectedIconUrl = epcotSelectedIconUrl
        let result = (!iconURL.isEmpty && !selectedIconUrl.isEmpty)
        if result {
            return iconURL.contains(".svg") && selectedIconUrl.contains(".svg")
        }
        return result
    }
    
    private var epcotSelectedIconUrl: String {
        self.parameters?.iconCss?.selectedColouredIconUrl ?? ""
    }
    
    private var epcotIconUrl: String {
        self.parameters?.iconCss?.colouredIconUrl ?? ""
    }
    
    var epcotSvgIconUrl: URL? {
        self.isSelected ? URL(string: epcotSelectedIconUrl) : URL(string: epcotIconUrl)
    }
    
    var stickerBackgroundColor: Color {
        Color(epcotCss?.categoryGameCountCSS?.backgroundColor ?? .gray)
    }
    
    var stickerTextColor: Color {
        Color(epcotCss?.categoryGameCountCSS?.categoryGamesCountTitle?.color ?? .blue)
    }
    
    var stickerFont: Font {
        Font(epcotCss?.categoryGameCountCSS?.categoryGamesCountTitle?.font ?? .systemFont(ofSize: 12))
    }
    
    var containerBackgroundColor: Color {
        let color = self.isSelected ? epcotCss?.categoriesSelectedViewBGColor : epcotCss?.categoriesViewBGColor
        return Color(color ?? .white)
    }
    
    var categoryHeaderCloseIconColor: Color {
        let buttonColor = epcotCss?.categoryHeaderCloseIconColor
        return Color(buttonColor ?? .white)
    }
}
