//
//  JackpotTileOrderViewModel.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 29/07/24.
//

import Foundation
import CasinoAPI
import Combine

class JackpotTileOrderViewModel {
    static let shared = JackpotTileOrderViewModel()
    
    private(set) var routeWidgets: [String: NativeWidgetsModel] = [:]
    private(set) var jackpotTiles: [JackpotTile]?
    private var subscriber: AnyCancellable?
    var onJackpotTilesUpdated : ((Bool)->())?

    private init() { }
    
    func getNativeWidgetsBasedOnRoute(feedDatasource: LobbyFeedDataSource?) {
        /// Setting the subscriber
        self.subscribeToFeed(feedDatasource: feedDatasource)
        guard let widgets = POSAPI.shared?.nativeWidgets else { return }
        guard !widgets.isEmpty else { return }
        self.routeWidgets = [:]
        widgets.forEach { nativeWidget in
            if let isJackpotTileEnabled = nativeWidget.isJackpotTileEnabled, isJackpotTileEnabled {
                self.routeWidgets[nativeWidget.routeValue.lowercased()] = nativeWidget
            }
        }
        if let tiles = feedDatasource?.feedViewModel?.feedModel?.lobbyFeedObj?.updatedJackpotTiles {
            self.updateJackpotTiles(with: tiles)
        }
    }
    
    private func subscribeToFeed(feedDatasource: LobbyFeedDataSource?) {
        self.removeSubscriber()
        self.subscriber = feedDatasource?.feedViewModel?.refreshJackpotTiles
            .receive(on: DispatchQueue.main)
            .sink { [weak self] jackpotTiles in
                if let tiles = jackpotTiles {
                    self?.updateJackpotTiles(with: tiles)
                }
            }
        if let tiles = feedDatasource?.feedViewModel?.feedModel?.lobbyFeedObj?.updatedJackpotTiles {
            self.updateJackpotTiles(with: tiles)
        }
    }
    
    private func updateJackpotTiles(with tiles: [JackpotTile]) {
        let tiles = POSAPI.shared?.jackpotTilesOrder?.paths?.reduce(into: [JackpotTile](), { partialResult, path in
            if let tile = tiles.first(where: { $0.path == path }) {
                partialResult.append(tile)
            }
        })
        if let tiles, !tiles.isEmpty {
            self.jackpotTiles = tiles
            self.onJackpotTilesUpdated?(true)
        }
    }
    
    private func removeSubscriber() {
        self.subscriber?.cancel()
        self.subscriber = nil
    }
}
