//
//  JackpotView.swift
//  Created by Naresh Banavath on 29/05/24.
//

import SwiftUI

struct JackpotView: View {
    
    @ObservedObject var viewModel: JackpotTileViewModel
    
    var body: some View {
        ZStack(alignment: .top) {
            
            /// background image
            if let bgImage = viewModel.backgroundImage {
                JackpotTileBlurImageView(image: bgImage)
            }
            
            VStack {
                TopView(viewModel: viewModel)
                    .frame(height: 131, alignment: .top)
                
                switch viewModel.jackPotTileType {
                    /// Daily based Jackpots
                case .daily:
                    if let dailyModel = viewModel.dailyModel {
                        DailyBottomView(model: dailyModel)
                            .frame(height: 83)
                    }
                    /// Value based Jackpots
                case .value:
                    if viewModel.showValueSubjackpots,
                       let valueModel = viewModel.valueModel {
                        ValueBottomView(jackpotDetails: valueModel)
                            .frame(height: 83)
                    }
                    /// Progressive based Jackpots
                case .progressive:
                    if let progressiveModel = viewModel.progressiveModel {
                        ProgressiveBottomView(model: progressiveModel)
                            .frame(height: 83)
                    }
                }
            }
        }
        .environment(\.jackPotTileCss, viewModel.css)
        .frame(maxWidth: .infinity)
        .frame(height: 214)
        .clipShape(RoundedRectangle(cornerRadius: 8.0))
        .overlay(
            RoundedRectangle(cornerRadius: viewModel.css.cornerRadius)
                .inset(by: 0.5)
                .stroke(viewModel.css.strokeColor(type: viewModel.jackPotTileType), lineWidth: 1)
        )
    }
}

//MARK: Custom Environment
private struct JackpotTilesCSSKey : EnvironmentKey {
    static let defaultValue: JackpotTilesCSSModel = .init()
}
extension EnvironmentValues {
    var jackPotTileCss : JackpotTilesCSSModel {
        get { self[JackpotTilesCSSKey.self]}
        set { self[JackpotTilesCSSKey.self] = newValue }
    }
}
