//
//  TimeBasedViewModel.swift
//  Alamofire
//
//  Created by Naresh Banavath on 23/07/24.
//

import Foundation
import Combine

class TimeBasedViewModel: ObservableObject {
    let triggerDate: Date
    @Published var time: JackpotTileTime
    var timer: Publishers.Autoconnect<Timer.TimerPublisher>?
    private var cancellable: AnyCancellable?
    
    init(triggerDate: Date,
         showTimer: Bool = false) {
        self.triggerDate = triggerDate
        self.time = Self.timeDifference(futureDate: triggerDate)
        if showTimer {
            self.startTimer(interval: 1)
        }
    }
    
    func updateTime() {
        let time = Self.timeDifference(futureDate: triggerDate)
        DispatchQueue.main.async {
            self.time = time
        }
        if time.isEmpty {
            stopTimer()
        }
    }
    
    // MARK: Expiry time update
    private func startTimer(interval: Int) {
        timer = Timer.publish(every: TimeInterval(interval), on: .main, in: .common)
            .autoconnect()
        cancellable = timer?
            .sink { [weak self] _ in
                guard let self else { return }
                self.updateTime()
            }
    }
    
    private func stopTimer() {
        timer?.upstream.connect().cancel()
        timer = nil
    }
    
    
    static func timeDifference(futureDate: Date) -> JackpotTileTime {
        let elapsedTime = futureDate.timeIntervalSince(Date.now.withTimeZone())
        let hours = Int(elapsedTime) / 3600
        let minutes = (Int(elapsedTime) % 3600) / 60
        return JackpotTileTime(hours: hours, minutes: minutes)
    }
}

struct JackpotTileTime {
    let hours: [String]
    let minutes: [String]
    private let hourValue: Int
    private let minutesValue: Int
    
    init(hours: Int, minutes: Int) {
        self.hourValue = hours
        self.minutesValue = minutes
        var hour = Array("\(hours)").compactMap({String($0)})
        var minute = Array("\(minutes)").compactMap({String($0)})
        if hour.count == 1 {
            hour.insert("0", at: 0)
        }
        if minute.count == 1 {
            minute.insert("0", at: 0)
        }
        self.hours = hour
        self.minutes = minute
    }
    
}
extension JackpotTileTime {
    var isEmpty: Bool {
        let totalTime = hourValue + minutesValue
        return totalTime <= 0
    }
}
