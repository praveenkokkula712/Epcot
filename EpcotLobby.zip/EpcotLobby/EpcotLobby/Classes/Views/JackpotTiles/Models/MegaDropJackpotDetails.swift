//
//  MegaDropJackpotDetails.swift
//  EpcotLobby
//
//  Created by Naresh Banavath on 26/07/24.
//

import Foundation

struct MegaDropJackpotDetails: Identifiable, Hashable {
    public var id: UUID = UUID()
    public private(set) var title: String?
    public private(set) var maxAmount: String?
    public private(set) var elapsedAmount: String?
    public private(set) var percentage: Double?

    public init(apiData: JackpotTile, subJackpot: SubJackpotDetails) {
        
        let subJackpotPercentage = subJackpot.subJPCompPercent?.doubleValue
        let subJackpotAmount = subJackpot.subJackpotAmount
        let maxAmount = subJackpot.triggerInfo ?? ""
        let maxText = apiData.maxText ?? "MAX".localized()
        
        let subjackpotTitle = apiData.subJackpotDetails?.first(where: { $0.key == subJackpot.jackpotFeedId })?.value as? String
        var title: String?
        if let trimmedTitle = subjackpotTitle?.trimmed, !trimmedTitle.isEmpty {
             title = subjackpotTitle
        } else {
            title = subJackpot.subJackpotName
        }
        
        self.title =  title ?? ""
        self.maxAmount =  "\(maxAmount) \(maxText)"
        self.elapsedAmount =  subJackpotAmount
        if let subJackpotPercentage {
            self.percentage =  subJackpotPercentage/100
        } else {
            self.percentage = nil
        }
        
    }
    
}
