//
//  JackpotTilesCSSModel.swift
//  EpcotLobby
//
//  Created by Naresh Banavath on 01/07/24.
//

import Foundation
import SwiftUI
import Utility

struct JackpotTilesCSSModel {
    private let model: JackPotModel?
    init(model: JackPotModel? = nil) {
        self.model = model
    }
    
    private var css: JackpotTilesViewCSS {
        return EpcotLobbyManager.shared?.css.jackpotTilesViewCSS ?? DefaultJackpotTilesViewCSS()
    }
    
    private var tileBorderColor: Color? {
        self.model?.jackpotTile.tilebordercolor?.swiftUIColor
    }
    
    var cornerRadius: CGFloat {
        css.cornerRadius ?? 8.0
    }
    /// JackPotTile TopView
    var badgeTitleColor: Color {
        model?.jackpotTile.jackpotTypeColor?.swiftUIColor ?? css.badgeTitle?.color?.swiftUIColor ?? .white
    }
    
    var badgeTitleBackgroundColor: Color {
        model?.jackpotTile.jackpotTypeBackgroundColor?.swiftUIColor ?? css.badgeTitleBackgroundColor?.swiftUIColor ?? .white
    }
    
    var badgeTitleFont: Font {
        Font(css.badgeTitle?.font ?? .systemFont(ofSize: 12.0))
    }
    var badgeTitleCornerRadius: CGFloat{
        css.badgeTitleCornerRadius ?? 4.0
    }
    var titleColor: Color {
        model?.jackpotTile.jackpotGroupTextColor?.swiftUIColor ?? css.title?.color?.swiftUIColor ?? .white
    }
    var titleFont: Font{
        Font(css.title?.font ?? .systemFont(ofSize: 17, weight: .bold))
    }
    var descriptionColor: Color {
        model?.jackpotTile.subJackpotInfoTextColor?.swiftUIColor ?? css.description?.color?.swiftUIColor ?? .white
    }
    var descriptionFont: Font{
        Font(css.description?.font ?? .systemFont(ofSize: 11))
    }
    var descriptionUIFont : UIFont {
        css.description?.font ?? .systemFont(ofSize: 11)
    }
    var lastWinTextColor: Color {
        css.lastWin?.color?.swiftUIColor ?? .white
    }
    var lastWinTextFont: Font{
        Font(css.lastWin?.font ?? .systemFont(ofSize: 9, weight: .medium))
    }
    var gameImageCornerRadius: CGFloat{
        css.gameImageCornerRadius ?? 6.0
    }
    var viewGamesButtonTextColor: Color {
        model?.jackpotTile.viewGamesTextColor?.swiftUIColor ?? css.viewGameBtn?.title?.color?.swiftUIColor ?? .blue
    }
    var viewGamesButtonTextFont: Font {
        Font(css.viewGameBtn?.title?.font ?? .systemFont(ofSize: 11))
    }
    var bottomViewBackgroundColor: Color {
        css.bottomViewBackgroundColor?.swiftUIColor ??  .black.opacity(0.25)
    }
    /// - JackpotTile BottomViews
    
    /// DailyBottomView
    var dailyBottomViewTitleTextColor: Color {
        css.dailyBottomViewTitle?.color?.swiftUIColor ?? .white
    }
    var dailyBottomViewTitleFont: Font {
        Font(css.dailyBottomViewTitle?.font ?? .systemFont(ofSize: 14, weight: .medium))
    }
    var dailyBottomViewAmountTextColor: Color {
        css.dailyBottomViewAmount?.color?.swiftUIColor ?? .white
    }
    var dailyBottomViewAmountTextFont: Font{
        Font(css.dailyBottomViewAmount?.font ?? .systemFont(ofSize: 28))
    }
    var dailyBottomViewTimeLeftTextColor: Color{
        css.dailyBottomViewTimeLeftLabel?.color?.swiftUIColor ?? .white
    }
    var dailyBottomViewTimeLeftTextFont: Font{
        Font(css.dailyBottomViewTimeLeftLabel?.font ?? .systemFont(ofSize: 11))
    }
    var dailyBottomViewHourAndMinuteTitleTextColor: Color {
        css.dailyBottomViewHourAndMinuteTitleLabel?.color?.swiftUIColor ?? .white
    }
    var dailyBottomViewHourAndMinuteTitleTextFont: Font {
        Font(css.dailyBottomViewHourAndMinuteTitleLabel?.font ?? .systemFont(ofSize: 9, weight: .medium))
    }
    var dailyBottomViewHourAndMinuteValuesTextColor: Color{
        css.dailyBottomViewHourAndMinuteValues?.color?.swiftUIColor ?? .white
    }
    var dailyBottomViewHourAndMinuteValuesTextFont: Font{
        Font(css.dailyBottomViewHourAndMinuteValues?.font ?? .systemFont(ofSize: 14, weight: .medium))
    }
    var dailyBottomViewHourAndMinuteValuesBackgroundColor: Color{
        css.dailyBottomViewHourAndMinuteValuesBackgroundColor?.swiftUIColor ?? .black.withAlphaComponent(0.2)
    }
    var dailyBottomViewBackgroundColor: Color {
        css.dailyBottomViewBackgroundColor?.swiftUIColor ?? Color(red: 0.46, green: 0.08, blue: 0.64)
    }
    var dailyBottomViewStrokeColor: Color {
        tileBorderColor ?? css.dailyBottomViewStrokeColor?.swiftUIColor ?? Color(red: 0.67, green: 0.36, blue: 0.85)
    }
    var dailyStartingAtTextColor: Color {
        css.dailyStartingAtText?.color?.swiftUIColor ?? Color.white
    }
    var dailyStartingAtTimeColor: Color {
        css.dailyStartingAtTime?.color?.swiftUIColor ?? Color.white
    }
    var dailyStartingAtTextFont: Font {
        Font(css.dailyStartingAtText?.font ?? .systemFont(ofSize: 11, weight: .bold))
    }
    var dailyStartingAtTimeFont: Font {
        Font(css.dailyStartingAtTime?.font ?? .systemFont(ofSize: 28))
    }
    
    ///ValueBottomView
    
    var valueBottomViewTitleTextColor: Color {
        css.valueBottomViewTitle?.color?.swiftUIColor ?? .white
    }
    var valueBottomViewTitleTextFont: Font {
        Font(css.valueBottomViewTitle?.font ?? .systemFont(ofSize: 11, weight: .bold))
    }
    var valueBottomViewAmountTextColor: Color {
        css.valueBottomViewAmount?.color?.swiftUIColor ?? .white
    }
    var valueBottomViewAmountTextFont: Font {
        Font(css.valueBottomViewAmount?.font ?? .systemFont(ofSize: 13))
    }
    var valueBottomViewProgressColor: Color {
        css.valueBottomViewProgressColor?.swiftUIColor ?? .green
    }
    var valueBottomViewProgressColorWhen90Percent: Color {
         css.valueBottomViewProgressColorWhen90Percent?.swiftUIColor ?? .red
    }
    var valueBottomViewMaxAmountTextColor: Color {
        css.valueBottomViewMaxAmount?.color?.swiftUIColor ?? .white
    }
    var valueBottomViewMaxAmountTextFont: Font {
        Font(css.valueBottomViewMaxAmount?.font ?? .systemFont(ofSize: 11))
    }
    var valueBottomViewBackgroundColor: Color {
        css.valueBottomViewBackgroundColor?.swiftUIColor ?? Color(red: 0.17, green: 0.33, blue: 0.25)
    }
    var valueBottomViewStrokeColor: Color {
        tileBorderColor ?? css.valueBottomViewStrokeColor?.swiftUIColor ?? Color(red: 0.24, green: 0.43, blue: 0.34)
    }
    ///ProgressiveBottomView
    
    var progressiveBottomViewTitleTextColor: Color {
        css.progressiveBottomViewTitle?.color?.swiftUIColor ?? .white
    }
    var progressiveBottomViewTitleTextFont: Font {
        Font(css.progressiveBottomViewTitle?.font ?? .systemFont(ofSize: 13))
    }
    var progressiveBottomViewAmountTextColor: Color {
        css.progressiveBottomViewAmountText?.color?.swiftUIColor ?? .white
    }
    var progressiveBottomViewAmountTextFont: Font {
        Font( css.progressiveBottomViewAmountText?.font ?? .systemFont(ofSize: 28))
    }
    var progressiveBottomViewGameButtonTextColor: Color {
        css.progressiveBottomView_ViewGamesButton?.title?.color?.swiftUIColor ?? .white
    }
    var progressiveBottomViewGameButtonTextFont: Font {
        Font(css.progressiveBottomView_ViewGamesButton?.title?.font ?? .systemFont(ofSize: 13))
    }
    var progressiveBottomViewGameButtonBackgroundColor: Color {
        css.progressiveBottomView_ViewGamesButton?.normal?.swiftUIColor ?? .white.withAlphaComponent(0.28)
    }
    var progressiveBottomViewGameButtonCornerRadius: CGFloat {
        css.progressiveBottomView_ViewGamesButtonCornerRadius ?? 16.0
    }
    var progressiveBottomViewBackgroundColor: Color {
        css.progressiveBottomViewBackgroundColor?.swiftUIColor ?? Color(red: 0.48, green: 0.38, blue: 0.19)
    }
    var progressiveBottomViewStrokeColor: Color {
        tileBorderColor ?? css.progressiveBottomViewStrokeColor?.swiftUIColor ?? Color(red: 0.57, green: 0.47, blue: 0.26)
    }
}
extension JackpotTilesCSSModel {
    
    func backgroundColor(type : JackpotType) -> Color {
        switch type {
        case .daily:
            return dailyBottomViewBackgroundColor
        case .value:
            return valueBottomViewBackgroundColor
        case .progressive:
            return progressiveBottomViewBackgroundColor
        }
    }
    func strokeColor(type : JackpotType) -> Color {
        switch type {
        case .daily:
            return dailyBottomViewStrokeColor
        case .value:
            return valueBottomViewStrokeColor
        case .progressive:
            return progressiveBottomViewStrokeColor
        }
    }
}

