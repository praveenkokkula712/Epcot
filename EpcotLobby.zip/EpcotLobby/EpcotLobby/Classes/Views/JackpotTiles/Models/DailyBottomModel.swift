//
//  DailyBottomModel.swift
//  EpcotLobby
//
//  Created by Naresh Banavath on 26/07/24.
//

import Foundation
struct DailyBottomModel: Hashable, Identifiable {
    let id: UUID = UUID()
    let title: String
    let amount: String
    let triggerDate: Date?
    let timeLeftText: String
    let showTimer: Bool
    let startingAtText: String
    let startingAtTime: String?
    
    init(apiData: JackpotTile){
        self.title = apiData.type ?? ""
        self.amount = apiData.subJackpots?.first?.subJackpotAmount ?? apiData.amount ?? ""
        self.triggerDate = apiData.subJackpots?.first?.triggerInfo?.getDate()?.withTimeZone()
        self.timeLeftText = apiData.timeLeftText ?? "time_left".localized()
        self.showTimer = apiData.showTimer ?? false
        self.startingAtText = apiData.startingAtText ?? "starting_at".localized()
        
        if let startingAtTime = apiData.startingAtTime?.dateFormat(
            currentFormat: "yyyyMMdd'T'HHmmss" ,
            currentTimeZone: TimeZone(abbreviation: "UTC") ?? .current,
            requiredFormat: "hh:mm a",
            requiredTimeZone: .current
        ) {
            self.startingAtTime = startingAtTime + " \(TimeZone.current.abbreviation() ?? "")"
        } else {
            self.startingAtTime = nil
        }
    }
}
