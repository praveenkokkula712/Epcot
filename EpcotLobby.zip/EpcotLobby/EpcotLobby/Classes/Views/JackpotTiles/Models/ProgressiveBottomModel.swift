//
//  ProgressiveBottomModel.swift
//  EpcotLobby
//
//  Created by Naresh Banavath on 26/07/24.
//

import Foundation

struct ProgressiveBottomModel: Hashable, Identifiable {
    let id: UUID = UUID()
    let title: String
    let amount: String
    
    init(apiData: JackpotTile){
        self.title = apiData.progressiveJackpotText ?? ""
        self.amount = apiData.subJackpots?.first?.subJackpotAmount ?? apiData.amount ?? ""
    }
}
