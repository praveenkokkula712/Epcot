//
//  JackpotTracking.swift
//  EpcotLobby
//
//  Created by Naresh Banavath on 18/07/24.
//

import Foundation
import TrackerClient

enum JackpotTileTrackType {
    case load(tileName: String)
    case click(tileName: String, index: String)
    case gameTap(game: GameTrackModel, tileName: String)
}

struct JackpotTileTracking {
    func trackEvent(type : JackpotTileTrackType) {
        switch type {
        case .load(let tileName):
            trackEvent(
                eventDetails  : .jackpot_tiles_interaction,
                eventAction   : .load,
                labelEvent    : tileName,
                eventLocation : .lobby,
                eventType     : .casino_jackpot_tiles
            )
        case .click(let tileName, let index):
            trackEvent(
                eventDetails  : .jackpot_tiles_interaction,
                eventAction   : .click,
                labelEvent    : tileName,
                eventPosition : index,//index of tile tapped
                eventLocation : .lobby,
                eventType     : .casino_jackpot_tiles
            )
        case .gameTap(let game, let tileName):
            gameTrack(game: game, tileName: tileName)
        }
    }
    
    private func trackEvent(
        eventDetails: EpcotEventDetails,
        eventAction: EpcotEventAction,
        labelEvent: String,
        eventPosition: String? = nil,
        eventLocation: EpcotEventLocation,
        eventType: EventType
       
    ) {
        
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent : EpcotEventCategory.jackpotTiles.rawValue,
                                     actionEvent   : eventAction.rawValue,
                                     labelEvent    : labelEvent,
                                     locationEvent : eventLocation.rawValue,
                                     eventDetails  : eventDetails.rawValue,
                                     positionEvent : eventPosition ?? "",
                                     productType   : EpcotEventProductType.casino.rawValue,
                                     userID        : EntainContext.user?.accountId ?? "",
                                     appInfo       : EpcotEventAppInfo.casinow.rawValue,
                                     screenName    : "lobby")
            let event = TrackerEvent(type: eventType, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    private func gameTrack(game: GameTrackModel, tileName: String) {
        
        let log = GameLaunchLog(name           : game.name,
                                position       : game.index,
                                category       : "jackpot_tiles",
                                grid           : GameEvents.GameGrid.not_applicable.rawValue,
                                type           : game.provider,
                                favourite      : game.favouriteState,
                                gameId         : game.gameId,
                                status         : game.status,
                                containerloc   : GameEvents.GameContainerlocation.lobby.rawValue,
                                containerdesc  : GameEvents.GameContainerdesc.not_applicable.rawValue,
                                categoryType   : "casino",
                                categorySubtype: tileName,
                                playingStatus  : GameEvents.GamePlayingStatus.start.rawValue) // Unfinished/Start
        
        let event = TrackerEvent(type: .gameOpen, log: log, tracker: .gtm)
        Tracker.postNotification(object: self, userInfo: [kEvent: event])
    }
}

struct GameTrackModel {
    let name: String
    let index: String
    let provider: String
    let favouriteState: String
    let gameId: String
    let status: String
    let playingStatus: String
}
