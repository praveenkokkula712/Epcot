//
//  JackpotTileAccessibilityIdentifiers.swift
//  EpcotLobby
//
//  Created by Naresh Banavath on 18/06/24.
//

import Foundation
public struct JackpotTileAccessibilityIdentifiers {
    
    public let badgeText            =  "JackpotTiles_Badge"
    public let titleText            =  "JackpotTiles_TitleText"
    public let descriptionText      =  "JackpotTiles_DescriptionText"
    public let lastWinText          =  "JackpotTiles_LastWinText"
    public let gameImage            =  "JackpotTiles_GameImage"
    public let viewGamesBtn         =  "JackpotTiles_ViewGamesButton"
    
    // DailyBottomViewIdentifiers
    struct DailyView {
        public let contentView       = "JackpotTiles_DailyView_ContentView"
        public let titleLabel        = "JackpotTiles_DailyView_TitleLabel"
        public let amountText        = "JackpotTiles_DailyView_AmountText"
        public let timeLeftText      = "JackpotTiles_DailyView_TimeLeftText"
        public let hoursTitleLabel   = "JackpotTiles_DailyView_HoursTitleLabel"
        public let minutesTitleLabel = "JackpotTiles_DailyView_MinutesTitleLabel"
        public let hourMinuteValues        = "JackpotTiles_DailyView_HourMinuteValues"
    }
    
    // ValueBottomViewIdentifiers
    struct ValueView {
        public let contentView       = "JackpotTiles_ValueView_ContentView"
        public let TitleText         = "JackpotTiles_ValueView_%@_TitleText"
        public let AmountText        = "JackpotTiles_ValueView_%@_AmountText"
        public let MaxAmountText     = "JackpotTiles_ValueView_%@_MaxAmountText"
        public let ProgressBar       = "JackpotTiles_ValueView_%@_ProgressBarView"
    }
    
    // ProgressiveBottomViewIdentifiers
    struct ProgressiveView {
        public let contentView           = "JackpotTiles_ProgressiveView_ContentView"
        public let progressiveTitleLabel = "JackpotTiles_ProgressiveView_ProgressiveTitleLabel"
        public let amountText            = "JackpotTiles_ProgressiveView_AmountText"
        public let viewGamesButton       = "JackpotTiles_ProgressiveView_ViewGamesButton"
    }
}
