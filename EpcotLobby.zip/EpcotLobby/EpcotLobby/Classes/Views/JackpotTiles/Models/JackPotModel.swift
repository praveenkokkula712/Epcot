//
//  JackpotViewModel.swift
//
//  Created by Naresh Banavath on 31/05/24.
//

import SwiftUI
import Foundation
import CasinoAPI
import Utility
import ConfigModule

//MARK: - JackpotModel
struct JackPotModel: Hashable {
    var id: UUID = UUID()
    let jackPotTileType: JackpotType
    let jackpotTile: JackpotTile
    var valueModel: [MegaDropJackpotDetails]?
    var dailyModel: DailyBottomModel?
    var progressiveModel: ProgressiveBottomModel?
    
    var games: [Game]? {
        self.jackpotTile.games
    }
    
    var titleText: String {
        jackpotTile.groupName?.limitString(40) ?? ""
    }
    
    var descriptionText: String {
        jackpotTile.tileDescription?.limitString(100) ?? ""
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(self.id)
    }
    
    static func == (lhs: JackPotModel, rhs: JackPotModel) -> Bool {
        lhs.id == rhs.id
    }
    
    init?(apiData : JackpotTile) {
        /// If `triggerType` is not available then pass `type` for differentiating the Jackpots
        if let type = JackpotType(triggerType: apiData.subJackpots?.first?.triggerType ?? apiData.type ?? "") {
            
            self.jackPotTileType = type
            self.jackpotTile = apiData
            
            switch type {
            case .daily:
                self.dailyModel = DailyBottomModel(apiData: apiData)
            case .value:
                self.valueModel = apiData.subJackpots?.prefix(3).map({ MegaDropJackpotDetails(apiData: apiData, subJackpot: $0) })
            case .progressive:
                self.progressiveModel = ProgressiveBottomModel(apiData: apiData)
            }
        } else {
            return nil
        }
    }
}

//MARK: - JackpotType
enum JackpotType {    
    case daily
    case value
    case progressive
    
    static var jackpotTileType : JackpotTileType? {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.jackpotTileType
    }
    static var timeBasedKeys : [String] {
        Self.jackpotTileType?.time ?? []
    }
    static var valueBasedKeys : [String] {
        Self.jackpotTileType?.value ?? []
    }
    static var randomKeys: [String] {
        Self.jackpotTileType?.random ?? []
    }
    static func isContain(_ key: String , in sequence: [String]) -> Bool {
        guard !sequence.isEmpty else { return false }
        return sequence.contains(where: { $0.caseInsensitiveCompare(key) == .orderedSame})
    }
}
extension JackpotType {
    init?(triggerType: String) {
        if JackpotType.isContain(triggerType, in: JackpotType.timeBasedKeys) {
            self = .daily
        } else if JackpotType.isContain(triggerType, in: JackpotType.valueBasedKeys){
            self = .value
        } else if JackpotType.isContain(triggerType, in: JackpotType.randomKeys){
            self = .progressive
        } else {
            /// If `triggerType` is nil then compare with `type`
            switch triggerType.lowercased() {
            case "daily":
                self = .daily
            case "value":
                self = .value
            case "progressive":
                self = .progressive
            default:
                return nil
            }
        }
    }
}
