//
//  JackpotTileViewModel.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 24/07/24.
//

import Foundation
import SwiftUI
import Combine
import CasinoAPI

class JackpotTileViewModel: ObservableObject {
    
    private(set) var model: JackPotModel
    private(set) var showViewGames: Bool
    
    @Published private(set) var jackpotAmount: String?
    @Published var attributedText: AttributedString?
    
    private let feedDatasource: LobbyFeedDataSource?
    private var subscribers = Set<AnyCancellable>()
    private var jackpotTimer: DispatchTimer?
    
    init(model: JackPotModel,
         showViewGames: Bool = true,
         datasource: LobbyFeedDataSource? = nil,
         onViewGamesTap: ((JackPotModel)->())? = nil) {
        self.model = model
        self.showViewGames = showViewGames
        self.feedDatasource = datasource
        self.getAttributedText()
        self.refreshJackpotPrices()
        self.subscribeToRefresh()
        self.startJackpotTimer()
    }
    
    deinit {
        self.stopJackpotTimer()
    }
}

extension JackpotTileViewModel {
    
    var css: JackpotTilesCSSModel {
        JackpotTilesCSSModel(model: model)
    }
    
    var games: [Game]? {
        model.games
    }
    
    var valueModel: [MegaDropJackpotDetails]? {
        model.valueModel
    }
    
    var dailyModel: DailyBottomModel? {
        model.dailyModel
    }
    
    var progressiveModel: ProgressiveBottomModel? {
        model.progressiveModel
    }
    
    var jackPotTileType: JackpotType {
        model.jackPotTileType
    }
    
    var badgeText: String {
        model.jackpotTile.type ?? ""
    }
    
    var titleText: String {
        model.titleText
    }
    
    var descriptionText: String {
        model.jackpotTile.tileDescription ?? ""
    }
    
    var showValueSubjackpots: Bool {
        model.jackpotTile.showValueSubjackpots ?? false
    }
    
    var showLastWin: Bool {
        model.jackpotTile.showLastWin ?? false
    }
    
    var lastWinText: String? {
        guard let lastWinTime = model.jackpotTile.lastWinTime?.dateFormat(),
              let lastWinAmount = model.jackpotTile.lastWinAmount else { return nil }
        return ((model.jackpotTile.lastwinText ?? "last_win".localized) + ": " + lastWinTime + " - " + lastWinAmount)
    }
    
    private var gameName: String? {
        model.jackpotTile.gameName
    }
    
    var jackpotImage: String? {
        guard let gameImage = model.jackpotTile.gameImage,
              !gameImage.isEmpty else {
            guard let gameVariant = self.gameName else { return nil }
            guard let immersiveInfo = feedDatasource?.feedViewModel?.getImmersiveInfo(for: gameVariant,
                                                                                      with: "\(LayoutType.verticalImmersiveGrid.rawValue)")
            else {
                return nil
            }
            guard !immersiveInfo.imagePath.isEmpty else {
                guard !immersiveInfo.imagePath.isEmpty else {
                    return nil
                }
                return immersiveInfo.gameInfo.imagePath
            }
            return immersiveInfo.imagePath
        }
        return gameImage
    }
    
    var backgroundImage: String? {
        model.jackpotTile.backgroundImage
    }
    
    func getAttributedText() {
        let descriptionText = self.descriptionText
        DispatchQueue.global(qos: .userInitiated).async {
            if let htmlString = descriptionText.convertToHTML(attrs: [
                .font: self.css.descriptionUIFont,
                .foregroundColor: self.css.descriptionColor.uiColor
            ]) {
                if let attributedString = try? AttributedString(htmlString, including: \.uiKit) {
                    DispatchQueue.main.async {
                        self.attributedText = attributedString
                    }
                }
            }
        }
    }
}

// MARK: Subscriptions
extension JackpotTileViewModel {
    private func subscribeToRefresh() {
        //return if game name is not available, no need to start the timer
        guard let gameName = self.gameName else { return }
        
        self.feedDatasource?.feedViewModel?.refreshLobby
            .subscribe(on: DispatchQueue.main)
            .sink { [weak self] shouldRefresh in
                guard let self else { return }
                if shouldRefresh {
                    self.stopJackpotTimer()
                    //update if any needed
                    self.startJackpotTimer()
                } else {
                    //No need to call this if sholud refresh is true, because it atomatically updates the view
                    self.refreshJackpotPrices()
                }
            }
            .store(in: &subscribers)
    }
}

//MARK: - Jackpot update
extension JackpotTileViewModel {
    private func startJackpotTimer() {
        guard  self.jackpotTimer == nil else { return }
        let randomInterval = Double.random(in: 1...6)
        self.jackpotTimer =  DispatchTimer(interval: randomInterval, handler: self.refreshJackpot)
    }
    
    func stopJackpotTimer() {
        guard self.jackpotTimer != nil else { return }
        self.jackpotTimer?.cancel()
        self.jackpotTimer = nil
    }
    
    private func refreshJackpot() {
        self.stopJackpotTimer()
        ///counter jackpot time update
        self.updateJackpotTickerAmount()
        self.startJackpotTimer()
    }
    
    private func refreshJackpotPrices () {
        guard let jackpotsValues = self.feedDatasource?.feedViewModel?.getAllJackpotAmounts(),
              let gameVariantName = self.gameName else {
            self.updateJackpotTickerAmount()
            return
        }
        if !gameVariantName.isEmpty,
           let jpPrice = jackpotsValues[gameVariantName] {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.jackpotAmount = jpPrice
            }
        }
    }
    
    func updateJackpotTickerAmount() {
        guard let amount = self.jackpotAmount?.jackpotCounterAmount else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.jackpotAmount = amount
        }
    }
}
