//
//  TopView.swift
//
//  Created by Naresh Banavath on 29/05/24.
//

import SwiftUI
import Kingfisher

struct TopView: View {
    
    @ObservedObject var viewModel: JackpotTileViewModel
    let accessibilityIndentifiers = JackpotTileAccessibilityIdentifiers()
    @Environment(\.jackPotTileCss) var css : JackpotTilesCSSModel
    
    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 8.0) {
                
                /// Badge
                Text(viewModel.badgeText)
                    .font(css.badgeTitleFont)
                    .foregroundStyle(css.badgeTitleColor)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(css.badgeTitleBackgroundColor)
                    .clipShape(RoundedRectangle(cornerRadius: css.badgeTitleCornerRadius))
                    .accessibilityIdentifier(accessibilityIndentifiers.badgeText)
               
                
                Text(viewModel.titleText)
                    .font(css.titleFont)
                    .foregroundStyle(css.titleColor)
                    .accessibilityIdentifier(accessibilityIndentifiers.titleText)
                
                /// Description Text
                if let attributedString = viewModel.attributedText
                {
                    let description = NSAttributedString(attributedString)
                        .string
                        .replacingOccurrences(of: "\n", with: "")
                        .limitString(100)
                    Text(description)
                        .multilineTextAlignment(.leading)
                        .font(css.descriptionFont)
                        .foregroundColor(css.descriptionColor)
                        .accessibilityIdentifier(accessibilityIndentifiers.descriptionText)
                }
                else {
                    Text(viewModel.descriptionText.limitString(100))
                        .foregroundStyle(css.descriptionColor)
                        .font(css.descriptionFont)
                        .accessibilityIdentifier(accessibilityIndentifiers.descriptionText)
                }
                
                if viewModel.showLastWin {
                    if let lastWin = viewModel.lastWinText {
                        Text(lastWin)
                            .foregroundStyle(css.lastWinTextColor)
                            .font(css.lastWinTextFont)
                            .accessibilityIdentifier(accessibilityIndentifiers.lastWinText)
                    }
                }
                
            }
            Spacer()
            VStack(alignment: .trailing) {
                
                if let gameImage = viewModel.jackpotImage {
                    ZStack {
                        KFImage(URL(string: gameImage))
                            .placeholder {
                                PlaceHolderImage()
                            }
                            .resizable()
                            .accessibilityIdentifier(accessibilityIndentifiers.gameImage)
                        
                        VStack {
                            Spacer()
                            
                            //Jackpot Amount
                            if let jpAmount = self.viewModel.jackpotAmount {
                                GameTileJackpotView(
                                    value: jpAmount,
                                    isIconEnabled: false,
                                    jackpotFireIconImagePath: nil
                                )
                                .frame(height: 8)
                            }
                        }
                    }
                    .frame(width: imageSize.width, 
                           height: imageSize.height,
                           alignment: .top)
                    .clipShape(RoundedRectangle(cornerRadius: css.gameImageCornerRadius))
                    .shadow(color: .black.opacity(0.16), radius: 4, x: 0, y: 4)
                }
                
                Spacer()
                
                if viewModel.showViewGames, let viewGamesText = viewModel.model.jackpotTile.viewGamesText {
                    HStack(spacing: 4) {
                        Text(viewGamesText)
                        Image(systemName: "chevron.right")
                    }
                    .font(css.viewGamesButtonTextFont)
                    .foregroundStyle(css.viewGamesButtonTextColor)
                    .accessibilityIdentifier(accessibilityIndentifiers.viewGamesBtn)
                }
            }
            
        }
        .padding([.horizontal,.top], 12)
    }
}

extension TopView {
    var imageSize : CGSize {
        .init(width: 78, height: 78)
    }
}
