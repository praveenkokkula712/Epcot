//
//  JackpotTileBlurImageView.swift
//
//  Created by Naresh Banavath on 29/05/24.
//

import SwiftUI
import Kingfisher

struct JackpotTileBlurImageView : View {
    var image: String
    
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                KFImage(URL(string: image))
                    .placeholder {
                        PlaceHolderImage()
                    }
                    .resizable()
                    .scaledToFill()
                    .clipped()
            }
            .frame(width: proxy.size.width , height: proxy.size.height)
            .cornerRadius(8)
        }
    }
}
