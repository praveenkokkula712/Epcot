//
//  ValueBottomView.swift
//
//  Created by Naresh Banavath on 30/05/24.
//

import SwiftUI
import Utility

struct ValueBottomView: View {
    let accessibilityIdentifiers = JackpotTileAccessibilityIdentifiers.ValueView()
    @Environment(\.jackPotTileCss) var css : JackpotTilesCSSModel
    var jackpotDetails : [MegaDropJackpotDetails]
    
    var body: some View {
        HStack(spacing: 12) {
            ForEach(jackpotDetails) { model in
                EpicView(ids: accessibilityIdentifiers, model: model)
                    .environment(\.jackPotTileCss, css)
            }
        }
        .padding(.horizontal, 12)
        .background(css.bottomViewBackgroundColor)
        .accessibilityIdentifier(accessibilityIdentifiers.contentView)
    }
    
}

//MARK: - EpicView
extension ValueBottomView {
  
    struct EpicView : View {
        
        let ids : JackpotTileAccessibilityIdentifiers.ValueView
        var model : MegaDropJackpotDetails
        @Environment(\.jackPotTileCss) var css : JackpotTilesCSSModel
        
        var body: some View {
            GeometryReader { proxy in
                VStack(alignment: .leading, spacing: 4.0) {
                    Text(model.title ?? "")
                        .foregroundStyle(css.valueBottomViewTitleTextColor)
                        .font(css.valueBottomViewTitleTextFont)
                        .accessibilityIdentifier(String(format: ids.TitleText, model.title ?? ""))
                        .frame(height: 13)
                    Text(model.elapsedAmount ?? "")
                        .foregroundStyle(css.valueBottomViewAmountTextColor)
                        .font(css.valueBottomViewAmountTextFont)
                        .accessibilityIdentifier(String(format: ids.AmountText, model.title ?? ""))
                        .frame(height: 18)
                    ZStack(alignment: .leading) {
                        RoundedRectangle(cornerRadius: 8.0)
                            .frame(height: 6.0)
                            .foregroundStyle(.black.opacity(0.3))
                        Stripes(config: stripeConfig(with: (model.percentage ?? 0.0)))
                            .frame(width: proxy.size.width * (model.percentage ?? 0.0), height: 6.0)
                            .clipShape(RoundedRectangle(cornerRadius: 8.0))
                            .accessibilityIdentifier(String(format: ids.ProgressBar, model.title ?? ""))
                    }
                    .frame(height: 6)
                    Text(model.maxAmount ?? "")
                        .foregroundStyle(css.valueBottomViewMaxAmountTextColor)
                        .font(css.valueBottomViewMaxAmountTextFont)
                        .accessibilityIdentifier(String(format: ids.MaxAmountText, model.title ?? ""))
                        .frame(height: 13)
                }
                .padding(.vertical, 10)
            }
        }
        
        func stripeConfig(with percentage : Double) -> StripesConfig {
            let color = percentage >= 0.9 ? css.valueBottomViewProgressColorWhen90Percent : css.valueBottomViewProgressColor
            return StripesConfig(
                background: .white.opacity(0.8),
                foreground: color,
                degrees: 20.0,
                barWidth: 2.0,
                barSpacing: 1.0
            )
        }
    }
}


