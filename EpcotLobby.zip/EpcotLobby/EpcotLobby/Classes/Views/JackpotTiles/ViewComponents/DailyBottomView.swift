//
//  DailyBottomView.swift
//
//  Created by Naresh Banavath on 29/05/24.
//

import SwiftUI
import Utility

struct DailyBottomView: View {
    
    let accessibilityIdentifiers: JackpotTileAccessibilityIdentifiers.DailyView
    @Environment(\.jackPotTileCss) var css: JackpotTilesCSSModel
    let model: DailyBottomModel
    @ObservedObject var timeViewModel: TimeBasedViewModel
    
    init(model: DailyBottomModel) {
        self.model = model
        timeViewModel = TimeBasedViewModel(
            triggerDate: model.triggerDate?.withTimeZone() ?? .now,
            showTimer: model.showTimer
        )
        self.accessibilityIdentifiers = .init()
    }
    
    var body: some View {
        if model.showTimer,
           !timeViewModel.time.isEmpty {
            HStack(alignment: .top){
                
                VStack(alignment: .leading,spacing: 4) {
                    Text(model.title ?? "")
                        .foregroundStyle(css.dailyBottomViewTitleTextColor)
                        .font(css.dailyBottomViewTitleFont)
                        .accessibilityIdentifier(accessibilityIdentifiers.titleLabel)
                    Text(model.amount ?? "")
                        .foregroundStyle(css.dailyBottomViewAmountTextColor)
                        .font(css.dailyBottomViewAmountTextFont)
                        .accessibilityIdentifier(accessibilityIdentifiers.amountText)
                }
                Spacer()
                
                timeLeftView
            }
            .padding(12)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(css.bottomViewBackgroundColor)
            .accessibilityIdentifier(accessibilityIdentifiers.contentView)
        } else {
            if let startingAtTime = model.startingAtTime {
                VStack(spacing: 4) {
                    Text(model.startingAtText)
                        .foregroundStyle(css.dailyStartingAtTextColor)
                        .font(css.dailyStartingAtTextFont)
                        .frame(height: 13)
                        .padding(.top, 19)
                    Text(startingAtTime)
                        .foregroundStyle(css.dailyStartingAtTimeColor)
                        .font(css.dailyStartingAtTimeFont)
                        .frame(height: 29)
                        .padding(.bottom,18)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(css.bottomViewBackgroundColor)
                .accessibilityIdentifier(accessibilityIdentifiers.contentView)
            }
        }
    }
    
    
    var timeLeftView : some View {
        
        VStack(alignment: .leading, spacing: 4) {
            Text(model.timeLeftText)
                .foregroundStyle(css.dailyBottomViewTimeLeftTextColor)
                .font(css.dailyBottomViewTimeLeftTextFont)
                .accessibilityIdentifier(accessibilityIdentifiers.timeLeftText)
            
            /// Timer View
            HStack(alignment: .center, spacing: 2) {
                Group {
                    ForEach(timeViewModel.time.hours.indices, id: \.self) { t in
                       Text(timeViewModel.time.hours[t])
                            .modifier(TimerModifiers())
                    }
                    
                    VStack(spacing: 3.5) {
                        Rectangle()
                            .fill(css.dailyBottomViewHourAndMinuteTitleTextColor)
                            .frame(width: 1.5, height: 1.5, alignment: .center)
                        Rectangle()
                            .fill(css.dailyBottomViewHourAndMinuteTitleTextColor)
                            .frame(width: 1.5, height: 1.5, alignment: .center)
                    }
                    
                    ForEach(timeViewModel.time.minutes.indices, id: \.self) { t in
                       Text(timeViewModel.time.minutes[t])
                            .modifier(TimerModifiers())
                    }
                }
            }
            .accessibilityIdentifier(accessibilityIdentifiers.hourMinuteValues)
            HStack(spacing: CGFloat((timeViewModel.time.hours.count - 1)) * 22, content: {
                
                Text("Hours".localized())
                    .multilineTextAlignment(.leading)
                    .foregroundStyle(css.dailyBottomViewHourAndMinuteTitleTextColor)
                    .font(css.dailyBottomViewHourAndMinuteTitleTextFont)
                    .offset(x: 4)
                    .accessibilityIdentifier(accessibilityIdentifiers.hoursTitleLabel)
                    
                Text("Minutes".localized())
                    .multilineTextAlignment(.leading)
                    .foregroundStyle(css.dailyBottomViewHourAndMinuteTitleTextColor)
                    .font(css.dailyBottomViewHourAndMinuteTitleTextFont)
                    .accessibilityIdentifier(accessibilityIdentifiers.minutesTitleLabel)
            })
        }
    }
}

fileprivate struct TimerModifiers: ViewModifier {
    @Environment(\.jackPotTileCss) var css
    var backgrounColor: Color?
    func body(content: Content) -> some View {
        content
            .frame(width: 19, height: 27)
            .foregroundStyle(css.dailyBottomViewHourAndMinuteValuesTextColor)
            .font(css.dailyBottomViewHourAndMinuteValuesTextFont)
            .multilineTextAlignment(.center)
            .background(backgrounColor ?? css.dailyBottomViewHourAndMinuteValuesBackgroundColor)
            .clipShape(RoundedRectangle(cornerRadius: 4.0))
    }
}
