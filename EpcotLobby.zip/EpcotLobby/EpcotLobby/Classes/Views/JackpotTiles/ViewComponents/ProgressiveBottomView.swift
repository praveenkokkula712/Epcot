//
//  ProgressiveBottomView.swift
//
//  Created by Naresh Banavath on 30/05/24.
//

import SwiftUI

struct ProgressiveBottomView: View {
    let accessibilityIdentifiers = JackpotTileAccessibilityIdentifiers.ProgressiveView()
    @Environment(\.jackPotTileCss) var css : JackpotTilesCSSModel
    let model: ProgressiveBottomModel
    
    var body: some View {
        HStack{
            VStack(spacing: 4.0 ){
                Text(model.title ?? "")
                    .foregroundStyle(css.progressiveBottomViewTitleTextColor)
                    .font(css.progressiveBottomViewTitleTextFont)
                    .accessibilityIdentifier(accessibilityIdentifiers.progressiveTitleLabel)
                    .frame(height: 13)
                Text(model.amount ?? "")
                    .foregroundStyle(css.progressiveBottomViewAmountTextColor)
                    .font(css.progressiveBottomViewAmountTextFont)
                    .accessibilityIdentifier(accessibilityIdentifiers.amountText)
                    .frame(height: 34)
            }
        }
        .padding(.vertical, 16)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(css.bottomViewBackgroundColor)
        .accessibilityIdentifier(accessibilityIdentifiers.contentView)
    }
}

