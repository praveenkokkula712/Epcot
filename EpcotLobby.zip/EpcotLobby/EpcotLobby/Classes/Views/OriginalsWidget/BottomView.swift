//
//  BottomView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 02/09/24.
//

import SwiftUI

struct BottomView: View {
    
    // MARK: Properties
    @ObservedObject var viewModel: OriginalsWidgetViewModel
    let styles = OriginalsWidgetViewCSS()
    
    // MARK: Body
    var body: some View {
        
        HStack(alignment: .top, spacing: 0) {
            
            // Max price
            VStack(alignment: .leading, spacing: 4) {
                if let maximumPrizeText = viewModel.content?.prizeText {
                    Text(maximumPrizeText)
                        .foregroundColor(styles.maximumPrizeTextColor)
                        .font(styles.maximumPrizeTextFont)
                        .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.maximumPrizeText)
                }
                
                if let maximumPrizeValue = viewModel.content?.prizeValue {
                    Text(maximumPrizeValue)
                        .foregroundColor(styles.maximumPrizeValueColor)
                        .font(styles.maximumPrizeValueFont)
                        .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.maximumPrizeValue)
                }
            }
            
            Spacer(minLength: 20)
 
            VStack(alignment: .leading, spacing: 4)  {
                
                // Time left
                if let timeLeftText = viewModel.content?.timeLeftText {
                    Text(timeLeftText)
                        .foregroundColor(styles.timeLeftTextColor)
                        .font(styles.timeLeftTextFont)
                        .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.timeLeftText)
                }
                
                if let timerViewModel = viewModel.timerViewModel {
                    TimerView(viewModel: viewModel,
                              timeViewModel: timerViewModel,
                              forCategoryWidget: false)
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 12)
        .padding(.bottom, 9)
        .frame(height: 80)
        .background(gradientBackground)
    }
    
    private var gradientBackground: LinearGradient {
        LinearGradient(
            stops: [
                Gradient.Stop(color: styles.widgetBottomViewBgColor1, location: 0.00),
                Gradient.Stop(color: styles.widgetBottomViewBgColor2, location: 1.00)
            ],
            startPoint: .top,
            endPoint: .bottom
        )
    }
}
