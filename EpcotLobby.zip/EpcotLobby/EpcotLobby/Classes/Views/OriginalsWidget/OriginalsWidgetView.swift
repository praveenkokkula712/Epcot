//
//  OriginalsWidgetView.swift
//  Alamofire
//
//  Created by Sindhuja Vedire on 02/09/24.
//

import SwiftUI
import Kingfisher

struct OriginalsWidgetView: View {
    
    // MARK: Properties
    @ObservedObject var viewModel: OriginalsWidgetViewModel
    let styles = OriginalsWidgetViewCSS()
    
    // MARK: Body
    var body: some View {
        
        VStack(spacing: 0) {
            
            ZStack(alignment: .trailing) {
                
                LinearGradient(
                    stops: [
                        Gradient.Stop(
                            color: styles.widgetTopViewBgColor1,
                            location: 0.00
                        ),
                        Gradient.Stop(
                            color: styles.widgetTopViewBgColor2,
                            location: 1.00
                        ),
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .frame(height: 136) // topview fixed height
                
                HStack {
                    
                    Spacer()
                    
                    Color.clear
                        .frame(width: 123, height: 114)
                        .overlay(content: {
                            KFImage(URL(string: viewModel.content?.mobileBackGroundImage ?? ""))
                                .resizable()
                                .placeholder({
                                    PlaceHolderImage()
                                        .frame(width: 123, height: 114)
                                })
                                .scaledToFit()
                                .frame(width: 123, height: 114)
                                .clipShape(Rectangle())
                                .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.ticketsImage)
                        })
                }
                
                // content and buttons
                ContentView(viewModel: viewModel)
            }
            
            // MaxPrice and TimeLeftView
            BottomView(viewModel: viewModel)
        }
        .frame(height: 216)
        .onAppear {
            viewModel.trackOriginalsCasinoEvent(.load)
        }
        .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.lobbyWidget)
    }
}
