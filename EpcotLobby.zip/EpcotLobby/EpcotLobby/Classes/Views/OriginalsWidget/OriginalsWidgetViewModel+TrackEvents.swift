//
//  OriginalsWidgetViewModel+TrackEvents.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 22/10/24.
//

import Foundation
import TrackerClient
import Utility

extension OriginalsWidgetViewModel {
    
    private var isUserLoggedIn: Bool {
        EntainContext.user?.isLoggedIn() ?? false
    }
    private var userId: String {
        EntainContext.user?.accountId ?? ""
    }
}

// Casino Events
extension OriginalsWidgetViewModel {
    func trackOriginalsCasinoEvent(_ type: OriginalsWidgetEvent) {
        var actionEvent: EpcotEventAction = .click
        var labelEvent: EpcotEventLabel = .see_rest_of_games
        var eventDetails = ""
        
        var location_event: EpcotEventLocation = .home
        var position_event: EpcotEventPosition = .in_house_games_widget
        
        switch type {
        case .load:
            actionEvent = .load
            labelEvent = .betmgm_originals
        case .viewGames:
            actionEvent = .click
            labelEvent = .see_rest_of_games
            eventDetails = EpcotEventDetails.view_games.rawValue
        case .seeDetails(let isCategoryView):
            actionEvent = .click
            labelEvent = .in_house_games
            eventDetails = EpcotEventDetails.see_details.rawValue
            if isCategoryView {
                location_event = .originals_lobby
                position_event = .top_ribbon
            }
        case .optIn(let isCategoryView):
            actionEvent = .click
            labelEvent = .in_house_games
            eventDetails = EpcotEventDetails.opt_in.rawValue
            if isCategoryView {
                location_event = .originals_lobby
                position_event = .top_ribbon
            }
        default:
            return
        }
        
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.casino.rawValue,
                                     actionEvent: actionEvent.rawValue,
                                     labelEvent: labelEvent.rawValue,
                                     locationEvent: location_event.rawValue,
                                     eventDetails: eventDetails,
                                     positionEvent: position_event.rawValue,
                                     productType: EpcotEventProductType.casino.rawValue,
                                     userID: self.userId,
                                     screenName: ScreenName.home.rawValue,
                                     loggedInEvent: self.isUserLoggedIn ? .loggedIn : .notLoggedIn,
                                     customerIdEvent: self.userId,
                                     customTimestamp: Date().unixTimestampInMicroseconds,
                                     loggedInState: self.isUserLoggedIn ? .loggedIn : .notLoggedIn,
                                     customerId: self.userId)
            
            let event = TrackerEvent(type: .casino, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}

// Category Events
extension OriginalsWidgetViewModel {
    func trackOriginalsCategoryLoadEvent(_ type: OriginalsWidgetEvent) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(productType: EpcotEventProductType.casino.rawValue,
                                     userID: self.userId,
                                     screenName: ScreenName.home.rawValue,
                                     loggedInEvent: self.isUserLoggedIn ? .loggedIn : .notLoggedIn,
                                     customerIdEvent: self.userId,
                                     customTimestamp: Date().unixTimestampInMicroseconds,
                                     loggedInState: self.isUserLoggedIn ? .loggedIn : .notLoggedIn,
                                     customerId: self.userId,
                                     siteSubSection: EpcotEventLabel.betmgm_originals.rawValue)
            
            let event = TrackerEvent(type: .screen_view, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}

// Promo events
extension OriginalsWidgetViewModel {
    
    func trackOriginalsPromoHubEvent(_ type: OriginalsWidgetPromoEvent) {
        var actionEvent = ""
        var labelEvent = ""
        var eventDetails = ""
        var positionEvent = ""
        var edsCampaignId = ""
        var isLoadedFromCategory = false
        
        switch type {
        case .halfSheetLoad(let promo):
            actionEvent = EpcotEventAction.load.rawValue
            labelEvent = EpcotEventLabel.originals_half_sheet.rawValue
            eventDetails = promo.isFromCategory ? EpcotEventDetails.originals.rawValue : EpcotEventDetails.casino_home.rawValue
            positionEvent = EpcotEventPosition.not_applicable.rawValue
            edsCampaignId = promo.campaignId
            isLoadedFromCategory = promo.isFromCategory
        case .halfSheetOptIn(let promo):
            actionEvent = EpcotEventAction.click.rawValue
            labelEvent = EpcotEventLabel.originals_half_sheet.rawValue
            eventDetails = EpcotEventDetails.opt_in.rawValue
            positionEvent = EpcotEventPosition.not_applicable.rawValue
            edsCampaignId = promo.campaignId
            isLoadedFromCategory = promo.isFromCategory
        case .halfSheetClose(let promo):
            actionEvent = EpcotEventAction.click.rawValue
            labelEvent = EpcotEventLabel.originals_half_sheet.rawValue
            eventDetails = EpcotEventDetails.close.rawValue
            positionEvent = EpcotEventPosition.not_applicable.rawValue
            edsCampaignId = promo.campaignId
            isLoadedFromCategory = promo.isFromCategory
        case .halfSheetViewFull(let promo):
            actionEvent = EpcotEventAction.click.rawValue
            labelEvent = EpcotEventLabel.originals_half_sheet.rawValue
            eventDetails = EpcotEventDetails.view_full_details.rawValue
            positionEvent = EpcotEventPosition.not_applicable.rawValue
            edsCampaignId = promo.campaignId
            isLoadedFromCategory = promo.isFromCategory
        default:
            return
        }
                
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.promo_hub.rawValue,
                                     actionEvent: actionEvent,
                                     labelEvent: labelEvent,
                                     locationEvent: isLoadedFromCategory ? EpcotEventLocation.originals.rawValue : EpcotEventLocation.casino_home.rawValue,
                                     eventDetails: eventDetails,
                                     positionEvent: positionEvent,
                                     productType: EpcotEventProductType.casino.rawValue,
                                     userID: self.userId,
                                     screenName: ScreenName.home.rawValue,
                                     loggedInEvent: self.isUserLoggedIn ? .loggedIn : .notLoggedIn,
                                     customerIdEvent: self.userId,
                                     customTimestamp: Date().unixTimestampInMicroseconds,
                                     loggedInState: self.isUserLoggedIn ? .loggedIn : .notLoggedIn,
                                     customerId: self.userId,
                                     siteSubSection: EpcotEventOriginalsWidget.custom_promotions.rawValue,
                                     edsCampaignId: edsCampaignId,
                                     pageSiteSection: EpcotEventOriginalsWidget.promo_hub.rawValue,
                                     promoIntent: EpcotEventOriginalsWidget.acquisition.rawValue)
            
            let event = TrackerEvent(type: .promo_hub_events, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}
