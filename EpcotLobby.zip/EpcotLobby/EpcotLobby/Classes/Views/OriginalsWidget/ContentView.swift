//
//  ContentView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 02/09/24.
//

import SwiftUI
import Kingfisher
import Utility

struct ContentView: View {
    
    // MARK: Properties
    @ObservedObject var viewModel: OriginalsWidgetViewModel
    let styles = OriginalsWidgetViewCSS()
    
    // MARK: Body
    var body: some View {
        GeometryReader { geometry in
            
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .top) {
                    // Title
                    if let title = viewModel.content?.mainTitle, !title.isEmpty {
                        let titleSubText = viewModel.content?.mainTitleSubText ?? ""
                        let combinedText = [title, titleSubText].joined(separator: " ")
                        Text(combinedText)
                            .foregroundColor(styles.titleColor)
                            .font(styles.titleFont)
                            .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.lobbyWidgetTitle)
                    }
                    
                    Spacer()
                    
                    // view games button
                    if let linkedCategory = viewModel.content?.linkedCategory, !linkedCategory.isEmpty {
                        HapticsButton {
                            HStack(spacing: 3) {
                                if let viewGamesText = viewModel.content?.viewGamesButtonText, !viewGamesText.isEmpty {
                                    Text(viewGamesText)
                                        .foregroundColor(styles.viewGamesTextColor)
                                        .font(styles.viewGamesTextFont)
                                        .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.viewGamesCta)
                                }
                                
                                Image(systemName: "chevron.right")
                                    .frame(width: styles.rightArrowIconSize, height: styles.rightArrowIconSize)
                                    .foregroundColor(styles.viewGamesTextColor)
                            }
                        } action: {
                            viewModel.onTapViewGameButton()
                        }
                    }
                }
                .padding(.bottom, 8)
                
                // description
                VStack(alignment: .leading, spacing: 0) {
                    if let description = viewModel.content?.subTitle, !description.isEmpty {
                        Text(description)
                            .foregroundColor(styles.descriptionColor)
                            .font(styles.descriptionFont)
                            .minimumScaleFactor(0.5)
                            .padding(.trailing, 135)
                            .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.lobbyWidgetDescription)
                    }
                    
                    // see details and optIn buttons
                    ActionButtons(viewModel: viewModel, fromOverlay: false)
                        .padding(.top, 12)
                        .frame(width: geometry.size.width * 0.5, alignment: .topLeading)
                    
                }
            }
            .padding(.leading, 16)
            .padding(.trailing, 10)
            .padding(.top, 14)
            .padding(.bottom, 17)
            .frame(height: 136)
        }
    }
}
