//
//  OriginalsWidgetCSS.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 05/09/24.
//

import Foundation
import SwiftUI
import Utility

struct OriginalsWidgetViewCSS {
    
    var widgetTopViewBgColor1:  Color
    var widgetTopViewBgColor2:  Color
    var widgetBottomViewBgColor1:  Color
    var widgetBottomViewBgColor2:  Color
    var titleColor: Color
    var titleFont: Font
    var descriptionColor: Color
    var descriptionFont: Font
    var viewGamesTextColor: Color
    var viewGamesTextFont: Font
    var rightArrowIconColor: Color
    var rightArrowIconSize: CGFloat
    var seeDetailsCtaTextColor: Color
    var seeDetailsCtaTextFont: Font
    var seeDetailsCtaCornerRadius: CGFloat
    var seeDetailsCtaBorderColor: Color
    var seeDetailsCtaBorderWidth: CGFloat
    var optInCtaTextColor: Color
    var optInCtaTextFont: Font
    var optInCtaCornerRadius: CGFloat
    var optInCtaBgColors: [Color]
    var optedInCtaTextColor: Color
    var optedInCtaTextFont: Font
    var maximumPrizeTextColor: Color
    var maximumPrizeTextFont: Font
    var maximumPrizeValueColor: Color
    var maximumPrizeValueFont: Font
    var timeLeftTextColor: Color
    var timeLeftTextFont: Font
    var timerComponentsBgColor: Color
    var timerComponentsColor: Color
    var timerComponentsFont: Font
    var timerComponentsCornerRadius: CGFloat
    var seperatorColor: Color
    var seperatorSize: CGFloat
    var durationTextColor: Color
    var durationTextFont: Font
    var originalsIconSize: CGFloat
    var greenTickIconSIze: CGFloat
    var greenTickIconColor: Color
    
    var widgetBackgoroundColor1: Color
    var widgetBackgoroundColor2: Color
    var mainTitleColor: Color
    var mainTitleFont: Font
    var subTitleColor: Color
    var subTitleFont: Font
    var timerComponentsBackGroundColor: Color
    var timeComponentsCornerRadius: CGFloat
    var timeComponentsColor: Color
    var timeComponentsFont: Font
    var timeDurationTextColor: Color
    var timeDurationTextFont: Font
    var widgetOveralyBGcolor: Color
    var widgetOveralyCornerRadius: CGFloat
    var widgetOverlayHeaderTextColor: Color
    var widgetOverlayHeaderTextFont: Font
    var widgetOverlayMaximumPrizeTextColor: Color
    var widgetOverlayMaximumPrizeTextFont: Font
    var widgetOverlayMaximumPrizeValueColor: Color
    var widgetOverlayMaximumPrizeValueFont: Font
    var widgetOverlayOptInChancesTextColor: Color
    var widgetOverlayOptInChancesTextFont: Font
    
    var overlayHeaderBgColor: Color
    var overlayHeaderCornerRadius: CGFloat
    var overlayBgColor: Color
    var headerTitleColor: Color
    var headerTitleFont: Font
    var closeBtnTitleColor: Color
    var closeBtnTitleFont: Font
    var closeBtnBorderColor: Color
    var closeBtnBorderWidth: CGFloat
    var closeBtnCornerRadius: CGFloat
    var ticketsIconSize: CGFloat
    var ticketsTextColor: Color
    var ticketsTextFont: Font
    var timerIconSize: CGFloat
    var expiresTextColor: Color
    var expiresTextFont: Font
    var inDaysTextColor: Color
    var inDaysTextFont: Font
    var stepsTitleTextColor: Color
    var stepsTitleTextFont: Font
    var stepNumberBorderColor: Color
    var stepNumberBorderWidth: CGFloat
    var barColor: Color
    var barWidth: CGFloat
    var dividerColor1: Color
    var dividerColor2: Color
    var stepNumberColor: Color
    var stepNumberFont: Font
    var stepsDescriptionColor: Color
    var stepsDescriptionFont: Font
    var bonusIconSize: CGFloat
    var additionalInfoTextColor: Color
    var additionalInfoTextFont: Font
    var viewFullDetailsTextColor: Color
    var viewFullDetailsTextFont: Font
    var viewFullDetailsCtaBorderColor: Color
    var viewFullDetailsCtaBorderWidth: CGFloat
    var overalyOptInCtaTextColor: Color
    var overalyOptInCtaTextFont: Font
    var overalyOptedInCtaTextColor: Color
    var overalyOptedInCtaTextFont: Font

    init() {
        let css: OriginalsWidgetCSS? = CasinoCSS.lobby?.originalsWidgetCSS
        
        self.widgetTopViewBgColor1 = (css?.widgetTopViewBgColor1 ?? Self.defaultWidgetTopViewBgColor1).swiftUIColor
        self.widgetTopViewBgColor2 = (css?.widgetTopViewBgColor2 ?? Self.defaultWidgetTopViewBgColor2).swiftUIColor
        self.widgetBottomViewBgColor1 = (css?.widgetBottomViewBgColor1 ?? Self.defaultWidgetBottomViewBgColor1).swiftUIColor
        self.widgetBottomViewBgColor2 = (css?.widgetBottomViewBgColor2 ?? Self.defaultWidgetBottomViewBgColor2).swiftUIColor
        self.titleColor = (css?.title?.color ?? Self.defaultTitleColor).swiftUIColor
        self.titleFont = Font(css?.title?.font ?? Self.defaultTitleFont)
        self.descriptionColor = (css?.description?.color ?? Self.defaultDescriptionColor).swiftUIColor
        self.descriptionFont = Font(css?.description?.font ?? Self.defaultDescriptionFont)
        self.viewGamesTextColor = (css?.viewGamesCta?.color ?? Self.defaultViewGamesTextColor).swiftUIColor
        self.viewGamesTextFont = Font(css?.viewGamesCta?.font ?? Self.defaultViewGamesTextFont)
        self.rightArrowIconColor = (css?.rightArrowIconColor ?? Self.defaultViewGamesTextColor).swiftUIColor
        self.rightArrowIconSize = css?.rightArrowIconSize ?? 14
        self.seeDetailsCtaTextColor = (css?.seeDetailsCta?.color ?? Self.defaultSeeDetailsCtaTextColor).swiftUIColor
        self.seeDetailsCtaTextFont = Font(css?.seeDetailsCta?.font ?? Self.defaultSeeDetailsCtaTextFont)
        self.seeDetailsCtaCornerRadius = css?.seeDetailsCtaCornerRadius ?? 22
        self.seeDetailsCtaBorderColor = (css?.seeDetailsCtaBorderColor ?? Self.defaultSeeDetailsCtaBorderColor).swiftUIColor
        self.seeDetailsCtaBorderWidth = css?.seeDetailsCtaBorderWidth ?? Self.defaultSeeDetailsCtaBorderWidth
        self.optInCtaTextColor = (css?.optInCta?.color ?? Self.defaultOptInCtaTextColor).swiftUIColor
        self.optInCtaTextFont = Font(css?.optInCta?.font ?? Self.defaultOptInCtaTextFont)
        self.optInCtaCornerRadius = css?.optInCtaCornerRadius ?? 22
        let gradientColors = (css?.optInCtaBgColor ?? Self.defaultGradientColors).reduce(into: [Color]()) { partialResult, uiColor in
            partialResult.append(uiColor.swiftUIColor)
        }
        self.optInCtaBgColors = gradientColors
        self.optedInCtaTextColor = (css?.optedInCta?.color ?? Self.defaultOptedInCtaTextColor).swiftUIColor
        self.optedInCtaTextFont = Font(css?.optedInCta?.font ?? Self.defaultOptedInCtaTextFont)
        self.maximumPrizeTextColor = (css?.maximumPrizeText?.color ?? Self.defaultMaximumPrizeTextColor).swiftUIColor
        self.maximumPrizeTextFont = Font(css?.maximumPrizeText?.font ?? Self.defaultMaximumPrizeTextFont)
        self.maximumPrizeValueColor = (css?.maximumPrizeValue?.color ?? Self.defaultMaximumPrizeValueColor).swiftUIColor
        self.maximumPrizeValueFont = Font(css?.maximumPrizeValue?.font ?? Self.defaultMaximumPrizeValueFont)
        self.timeLeftTextColor = (css?.timeLeftText?.color ?? Self.defaultTimeLeftTextColor).swiftUIColor
        self.timeLeftTextFont = Font(css?.timeLeftText?.font ?? Self.defaultTimeLeftTextFont)
        self.timerComponentsBgColor = (css?.timerComponentsBgColor ?? Self.defaultTimerComponentsBgColor).swiftUIColor
        self.timerComponentsColor = (css?.timerComponents?.color ?? Self.defaultTimerComponentsColor).swiftUIColor
        self.timerComponentsFont = Font(css?.timerComponents?.font ?? Self.defaultTimerComponentsFont)
        self.timerComponentsCornerRadius = css?.timerComponentsCornerRadius ?? 4
        self.seperatorColor = (css?.seperatorColor ?? Self.defaultTimerComponentsColor).swiftUIColor
        self.seperatorSize = css?.seperatorSize ?? 2
        self.durationTextColor = (css?.durationText?.color ?? Self.defaultDurationTextColor).swiftUIColor
        self.durationTextFont = Font(css?.durationText?.font ?? Self.defaultDurationTextFont)
        self.originalsIconSize = css?.originalsIconSize ?? 12
        self.greenTickIconSIze = css?.greenTickIconSIze ?? 12
        self.greenTickIconColor = css?.greenTickIconColor?.swiftUIColor ?? OriginalsWidgetViewCSS.defaultGreenTickIconColor.swiftUIColor
        
        // originals category widget css
        self.widgetBackgoroundColor1 = (css?.widgetBackgoroundColor1 ?? Self.defaultWidgetBackgoroundColor1).swiftUIColor
        self.widgetBackgoroundColor2 = (css?.widgetBackgoroundColor2 ?? Self.defaultWidgetBackgoroundColor2).swiftUIColor
        self.mainTitleColor = (css?.mainTitle?.color ?? Self.defaultMainTitleColor).swiftUIColor
        self.mainTitleFont = Font(css?.mainTitle?.font ?? Self.defaultMainTitleFont)
        self.subTitleColor = (css?.subTitle?.color ?? Self.defaultSubTitleColor).swiftUIColor
        self.subTitleFont = Font(css?.subTitle?.font ?? Self.defaultSubTitleFont)
        self.timerComponentsBackGroundColor = (css?.timerComponentsBackGroundColor ?? Self.defaultTimerComponentsBackGroundColor).swiftUIColor
        self.timeComponentsCornerRadius = css?.timeComponentsCornerRadius ?? 4.0
        self.timeComponentsColor = (css?.timeComponents?.color ?? Self.defaultTimeComponentsColor).swiftUIColor
        self.timeComponentsFont = Font(css?.timeComponents?.font ?? Self.defaultTimeComponentsFont)
        self.timeDurationTextColor = (css?.timeDurationText?.color ?? Self.defaultTimeDurationTextColor).swiftUIColor
        self.timeDurationTextFont = Font(css?.timeDurationText?.font ?? Self.defaultTimeDurationTextFont)
        self.widgetOveralyBGcolor = (css?.widgetOveralyBGcolor ?? Self.defaultWidgetOveralyBGcolor).swiftUIColor
        self.widgetOveralyCornerRadius = css?.widgetOveralyCornerRadius ?? 6
        self.widgetOverlayHeaderTextColor = (css?.widgetOverlayHeaderText?.color ?? Self.defaultWidgetOverlayHeaderTextColor).swiftUIColor
        self.widgetOverlayHeaderTextFont = Font(css?.widgetOverlayHeaderText?.font ?? Self.defaultWidgetOverlayHeaderTextFont)
        self.widgetOverlayMaximumPrizeTextColor = (css?.widgetOverlayMaximumPrizeText?.color ?? Self.defaultWidgetOverlayMaximumPrizeTextColor).swiftUIColor
        self.widgetOverlayMaximumPrizeTextFont = Font(css?.widgetOverlayMaximumPrizeText?.font ?? Self.defaultWidgetOverlayMaximumPrizeTextFont)
        self.widgetOverlayMaximumPrizeValueColor = (css?.widgetOverlayMaximumPrizeValue?.color ?? Self.defaultWidgetOverlayMaximumPrizeValueColor).swiftUIColor
        self.widgetOverlayMaximumPrizeValueFont = Font(css?.widgetOverlayMaximumPrizeValue?.font ?? Self.defaultWidgetOverlayMaximumPrizeValueFont)
        self.widgetOverlayOptInChancesTextColor = (css?.widgetOverlayOptInChancesText?.color ?? Self.defaultWidgetOverlayOptInChancesTextColor).swiftUIColor
        self.widgetOverlayOptInChancesTextFont = Font(css?.widgetOverlayOptInChancesText?.font ?? Self.defaultWidgetOverlayOptInChancesTextFont)

        
        // overlay Css
        self.overlayHeaderBgColor = (css?.overlayHeaderBgColor ?? Self.defaultOverlayHeaderBgColor).swiftUIColor
        self.overlayHeaderCornerRadius = css?.overlayHeaderCornerRadius ?? 6.0
        self.overlayBgColor = (css?.overlayBgColor ?? Self.defaultOverlayBgColor).swiftUIColor
        self.headerTitleColor = (css?.headerTitle?.color ?? Self.defaultHeaderTitleColor).swiftUIColor
        self.headerTitleFont = Font(css?.headerTitle?.font ?? Self.defaultHeaderTitleFont)
        self.closeBtnTitleColor = (css?.closeBtnTitle?.color ?? Self.defaultCloseBtnTitleColor).swiftUIColor
        self.closeBtnTitleFont = Font(css?.closeBtnTitle?.font ?? Self.defaultCloseBtnTitleFont)
        self.closeBtnBorderColor = (css?.closeBtnBorderColor ?? Self.defaultCloseBtnBorderColor).swiftUIColor
        self.closeBtnBorderWidth = css?.closeBtnBorderWidth ?? Self.defaultCloseBtnBorderWidth
        self.closeBtnCornerRadius = css?.closeBtnCornerRadius ?? Self.defaultCloseBtnCornerRadius
        self.ticketsIconSize = css?.ticketsIconSize ?? Self.defaultTicketsIconSize
        self.ticketsTextColor = (css?.ticketsText?.color ?? Self.defaultTicketsTextColor).swiftUIColor
        self.ticketsTextFont = Font(css?.ticketsText?.font ?? Self.defaultTicketsTextFont)
        self.timerIconSize = css?.timerIconSize ?? Self.defaultTimerIconSize
        self.expiresTextColor = (css?.expiresText?.color ?? Self.defaultExpiresTextColor).swiftUIColor
        self.expiresTextFont = Font(css?.expiresText?.font ?? Self.defaultExpiresTextFont)
        self.inDaysTextColor = (css?.inDaysText?.color ?? Self.defaultInDaysTextColor).swiftUIColor
        self.inDaysTextFont = Font(css?.inDaysText?.font ?? Self.defaultInDaysTextFont)
        self.stepsTitleTextColor = (css?.stepsTitleText?.color ?? Self.defaultStepsTitleTextColor).swiftUIColor
        self.stepsTitleTextFont = Font(css?.stepsTitleText?.font ?? Self.defaultStepsTitleTextFont)
        self.stepNumberBorderColor = (css?.stepNumberBorderColor ?? Self.defaultStepNumberBorderColor).swiftUIColor
        self.stepNumberBorderWidth = css?.stepNumberBorderWidth ?? 1.0
        self.barColor = (css?.verticalBarColor ?? Self.defaultBarColor).swiftUIColor
        self.barWidth = css?.verticalBarWidth ?? 2.0
        self.dividerColor1 = (css?.dividerColor1 ?? Self.defaultDividerColor).swiftUIColor
        self.dividerColor2 = (css?.dividerColor2 ?? Self.defaultDividerColor).swiftUIColor
        self.stepNumberColor = (css?.stepNumber?.color ?? Self.defaultStepNumberColor).swiftUIColor
        self.stepNumberFont = Font(css?.stepNumber?.font ?? Self.defaultStepNumberFont)
        self.stepsDescriptionColor = (css?.stepsDescription?.color ?? Self.defaultStepsDescriptionColor).swiftUIColor
        self.stepsDescriptionFont = Font(css?.stepsDescription?.font ?? Self.defaultStepsDescriptionFont)
        self.bonusIconSize = css?.bonusIconSize ?? Self.defaultBonusIconSize
        self.additionalInfoTextColor = (css?.additionalInfoText?.color ?? Self.defaultAdditionalInfoTextColor).swiftUIColor
        self.additionalInfoTextFont = Font(css?.additionalInfoText?.font ?? Self.defaultAdditionalInfoTextFont)
        self.viewFullDetailsTextColor = (css?.viewFullDetailsCta?.color ?? Self.defaultViewFullDetailsTextColor).swiftUIColor
        self.viewFullDetailsTextFont = Font(css?.viewFullDetailsCta?.font ?? Self.defaultViewFullDetailsTextFont)
        self.viewFullDetailsCtaBorderColor = (css?.viewFullDetailsCtaBorderColor ?? Self.defaultViewFullDetailsCtaBorderColor).swiftUIColor
        self.viewFullDetailsCtaBorderWidth = css?.viewFullDetailsCtaBorderWidth ?? Self.defaultViewFullDetailsCtaBorderWidth
        self.overalyOptInCtaTextColor = (css?.overalyOptInCta?.color ?? Self.defaultOveralyOptInCtaTextColor).swiftUIColor
        self.overalyOptInCtaTextFont = Font(css?.overalyOptInCta?.font ?? Self.defaultOveralyOptInCtaTextFont)
        self.overalyOptedInCtaTextColor = (css?.overlayOptedInCta?.color ?? Self.defaultOveralyOptedInCtaTextColor).swiftUIColor
        self.overalyOptedInCtaTextFont = Font(css?.overlayOptedInCta?.font ?? Self.defaultOveralyOptedInCtaTextFont)
    }
}


extension OriginalsWidgetViewCSS {
    
    private static var defaultWidgetTopViewBgColor1: UIColor { .hexStringToUIColor(hex: "#2F2007") }
    private static var defaultWidgetTopViewBgColor2: UIColor { .hexStringToUIColor(hex: "#1E1504") }
    private static var defaultWidgetBottomViewBgColor1: UIColor { .hexStringToUIColor(hex: "#2F2007") }
    private static var defaultWidgetBottomViewBgColor2: UIColor { .hexStringToUIColor(hex: "#1E1504") }
    private static var defaultTitleColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultTitleFont: UIFont { .systemFont(ofSize: 12.0) }
    private static var defaultDescriptionColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultDescriptionFont: UIFont { .systemFont(ofSize: 16.0) }
    private static var defaultViewGamesTextColor: UIColor { .hexStringToUIColor(hex: "#79BFFF") }
    private static var defaultViewGamesTextFont: UIFont { .systemFont(ofSize: 12.0) }
    private static var defaultSeeDetailsCtaTextColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultSeeDetailsCtaTextFont: UIFont { .systemFont(ofSize: 12.0) }
    private static var defaultSeeDetailsCtaBorderColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultSeeDetailsCtaBorderWidth: CGFloat { 1.0 }
    private static var defaultOptInCtaTextColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultOptInCtaTextFont: UIFont { .systemFont(ofSize: 12.0) }
    private static var defaultGradientColors: [UIColor] { [.hexStringToUIColor(hex: "#E9D193"),
                                                           .hexStringToUIColor(hex: "#D4B962")] }
    private static var defaultOptedInCtaTextColor: UIColor { .hexStringToUIColor(hex: "#F3F4F5") }
    private static var defaultOptedInCtaTextFont: UIFont { .systemFont(ofSize: 12.0) }
    private static var defaultMaximumPrizeTextColor: UIColor { .hexStringToUIColor(hex: "#F3F4F5") }
    private static var defaultMaximumPrizeTextFont: UIFont { .systemFont(ofSize: 11.0) }
    private static var defaultMaximumPrizeValueColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultMaximumPrizeValueFont: UIFont { .systemFont(ofSize: 28.0) }
    private static var defaultTimeLeftTextColor: UIColor { .hexStringToUIColor(hex: "#F3F4F5") }
    private static var defaultTimeLeftTextFont: UIFont { .systemFont(ofSize: 11.0) }
    private static var defaultTimerComponentsBgColor: UIColor { .hexStringToUIColor(hex: "#211603") }
    private static var defaultTimerComponentsColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultTimerComponentsFont: UIFont { .systemFont(ofSize: 14.0) }
    private static var defaultDurationTextColor: UIColor { .hexStringToUIColor(hex: "#F3F4F5") }
    private static var defaultDurationTextFont: UIFont { .systemFont(ofSize: 9.0) }
    private static var defaultOriginalsIconSize: CGFloat { 12.0 }
    private static var defaultGreenTickIconSIze: CGFloat { 12.0 }
}

extension OriginalsWidgetViewCSS {
    
    private static var defaultOverlayHeaderBgColor: UIColor { .hexStringToUIColor(hex: "#F3F4F5") }
    private static var defaultOverlayBgColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultHeaderTitleColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultHeaderTitleFont: UIFont { .systemFont(ofSize: 16.0) }
    private static var defaultCloseBtnTitleColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultCloseBtnTitleFont: UIFont { .systemFont(ofSize: 14.0) }
    private static var defaultCloseBtnBorderColor: UIColor { .hexStringToUIColor(hex: "#050505", withAlpha: 0.28) }
    private static var defaultCloseBtnBorderWidth: CGFloat { 1.0 }
    private static var defaultCloseBtnCornerRadius: CGFloat { 16.0 }
    private static var defaultTicketsIconSize: CGFloat { 16.0 }
    private static var defaultTicketsTextColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultTicketsTextFont: UIFont { .systemFont(ofSize: 12.0) }
    private static var defaultTimerIconSize: CGFloat { 16.0 }
    private static var defaultExpiresTextColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultExpiresTextFont: UIFont { .systemFont(ofSize: 12.0) }
    private static var defaultInDaysTextColor: UIColor { .hexStringToUIColor(hex: "#ED2A2A") }
    private static var defaultInDaysTextFont: UIFont { .systemFont(ofSize: 12.0) }
    private static var defaultStepsTitleTextColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultStepsTitleTextFont: UIFont { .systemFont(ofSize: 12.0) }
    private static var defaultStepNumberBorderColor: UIColor { .hexStringToUIColor(hex: "#C3C4C7") }
    private static var defaultStepNumberBorderWidth: CGFloat { 1.0 }
    private static var defaultBarColor: UIColor { .hexStringToUIColor(hex: "#F3F4F5") }
    private static var defaultDividerColor: UIColor { .hexStringToUIColor(hex: "#F3F4F5") }
    private static var defaultStepNumberColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultStepNumberFont: UIFont { .systemFont(ofSize: 12.0) }
    private static var defaultStepsDescriptionColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultStepsDescriptionFont: UIFont { .systemFont(ofSize: 12.0) }
    private static var defaultBonusIconSize: CGFloat { 16.0 }
    private static var defaultAdditionalInfoTextColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultAdditionalInfoTextFont: UIFont { .systemFont(ofSize: 14.0) }
    private static var defaultViewFullDetailsTextColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultViewFullDetailsTextFont: UIFont { .systemFont(ofSize: 14.0) }
    private static var defaultViewFullDetailsCtaBorderColor: UIColor { .hexStringToUIColor(hex: "#050505", withAlpha: 0.28) }
    private static var defaultViewFullDetailsCtaBorderWidth: CGFloat { 1.0 }
    private static var defaultOveralyOptInCtaTextColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultOveralyOptInCtaTextFont: UIFont { .systemFont(ofSize: 14.0) }
    private static var defaultOveralyOptedInCtaTextColor: UIColor { .hexStringToUIColor(hex: "#050505") }
    private static var defaultOveralyOptedInCtaTextFont: UIFont { .systemFont(ofSize: 14.0) }

}

extension OriginalsWidgetViewCSS {
    private static var defaultGreenTickIconColor : UIColor { .hexStringToUIColor(hex: "#61BA2B") }
    private static var defaultWidgetBackgoroundColor1 : UIColor { .hexStringToUIColor(hex: "#E9D193") }
    private static var defaultWidgetBackgoroundColor2 : UIColor { .hexStringToUIColor(hex: "#D4B962") }
    private static var defaultMainTitleColor : UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultMainTitleFont : UIFont { .systemFont(ofSize: 34.0) }
    private static var defaultSubTitleColor : UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultSubTitleFont : UIFont { .systemFont(ofSize: 13.0) }
    private static var defaultTimerComponentsBackGroundColor : UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultTimeComponentsColor : UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultTimeComponentsFont : UIFont { .systemFont(ofSize: 14.0) }
    private static var defaultTimeDurationTextColor : UIColor { .hexStringToUIColor(hex: "#F3F4F5") }
    private static var defaultTimeDurationTextFont : UIFont { .systemFont(ofSize: 9.0) }
    private static var defaultWidgetOveralyBGcolor : UIColor { .hexStringToUIColor(hex: "#303030") }
    private static var defaultWidgetOverlayHeaderTextColor : UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultWidgetOverlayHeaderTextFont : UIFont { .systemFont(ofSize: 14.0) }
    private static var defaultWidgetOverlayMaximumPrizeTextColor : UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultWidgetOverlayMaximumPrizeTextFont : UIFont { .systemFont(ofSize: 11.0) }
    private static var defaultWidgetOverlayMaximumPrizeValueColor : UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultWidgetOverlayMaximumPrizeValueFont : UIFont { .systemFont(ofSize: 11.0) }
    private static var defaultWidgetOverlayOptInChancesTextColor : UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultWidgetOverlayOptInChancesTextFont : UIFont { .systemFont(ofSize: 12.0) }
}
