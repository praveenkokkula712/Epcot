//
//  File.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 23/10/24.
//

import Foundation

//Originals Widget Promo Event params
typealias OriginalsWidgetPromoEventParam = (campaignId: String, isFromCategory: Bool)

//Originals Widget Event
enum OriginalsWidgetEvent {
    case load
    case viewGames
    case seeDetails(Bool) // isFromCategoryselectionView: Bool
    case optIn(Bool) // isFromCategorySelectionView: Bool
    case categoryPill(String, Int, Bool) //category: String, index: Int, isPillClose: Bool
    case categoryLoad
}

//Originals Widget Promo Event
enum OriginalsWidgetPromoEvent {
    case halfSheetLoad(OriginalsWidgetPromoEventParam)
    case halfSheetOptIn(OriginalsWidgetPromoEventParam)
    case halfSheetClose(OriginalsWidgetPromoEventParam)
    case halfSheetViewFull(OriginalsWidgetPromoEventParam)
}
