//
//  OriginalsWidgetViewModel.swift
//  Alamofire
//
//  Created by Sindhuja Vedire on 02/09/24.
//

import Foundation
import CasinoAPI
import Combine
import Utility

@MainActor
class OriginalsWidgetViewModel: ObservableObject {
    
    // MARK: Properties
    var content: OriginalsWidgetConfigurations?
    var isFromCategory: Bool = false
    var seeDetailsBtnAction: (() -> Void)?
    @Published var isOptedIn: Bool = false
    @Published var isViewGamesTapped: Bool = false
    var timerViewModel: TimeViewModel?
    var onClose: (() -> Void)?
    @Published var remainingDaysUntilExpiry: Int?
    @Published var formattedDate: String?
    private var cancellables = Set<AnyCancellable>()
    let styles = OriginalsWidgetViewCSS()
    private var isWidgetExpired: Bool = true
    private var delegate: OriginalsWidgetDelegate?
    
    // MARK: Init
    init(content: OriginalsWidgetConfigurations, delegate: OriginalsWidgetDelegate? = nil) {
        self.content = content
        self.delegate = delegate
        self.timerViewModel = TimeViewModel(expiryDate: content.expiryDate,
                                            expiryDateFormat: content.nativeExpiryDateFormat)
        guard !(self.timerViewModel?.isWidgetTimeExpired() ?? true) else {
            self.delegate?.didUpdateExpiryStatus(with: true)
            self.delegate = nil
            return
        }
        if self.delegate != nil {
            self.timerViewModel?.isTimerExpired = {
                self.delegate?.didUpdateExpiryStatus(with: true)
                self.delegate = nil
            }
        }
        self.formattedDate = timerViewModel?.formattedDate
        self.getRemainingDaysUntilExpiry()
        self.getOptinStatus()
    }
    
    deinit {
        ETLogger.debug("========= OriginalsWidgetViewModel deinit")
    }
    
    func dispose() {
        self.content = nil
        self.delegate = nil
        self.seeDetailsBtnAction = nil
        self.onClose = nil
        self.cancellables.compactMap({$0.cancel})
        self.cancellables.removeAll()
        self.timerViewModel?.isTimerExpired = nil
        self.timerViewModel = nil
    }
}

// MARK: Actions
extension OriginalsWidgetViewModel {
    
    func onTapSeeDetailsButton() {
        self.trackOriginalsCasinoEvent(.seeDetails(isFromCategory))
        self.seeDetailsBtnAction?()
    }
    
    func onTapViewGameButton() {
        self.trackOriginalsCasinoEvent(.viewGames)
        self.isViewGamesTapped = true
    }
}


// MARK: Related to optIn Status
extension OriginalsWidgetViewModel {

    func getOptinStatus() {
        guard (EntainContext.user?.isLoggedIn() ?? false) else { return }
        
        guard let id = content?.sourceId,  let sourceType = content?.sourceType else {
            return
        }
        
        Task {
            if let result = try? await OptInStatusService().getOptInStatus(for: id, sourceType: GamePremiereSourceType(rawValue: sourceType) ?? .promos) {
                self.isOptedIn = result.status == GamePremiereOverlayViewModel.optedIn
                self.isWidgetExpired = result.status == GamePremiereOverlayViewModel.optedIn || result.status == GamePremiereOverlayViewModel.offered
                self.delegate?.didUpdateExpiryStatus(with: !self.isWidgetExpired)
            }
        }
    }
    
    func updateOptInStatus(isFromOverlay: Bool = false) {
        guard let id = content?.sourceId,  let sourceType = content?.sourceType else {
            return
        }
        // opt in track event
        if isFromOverlay {
            self.trackOriginalsPromoHubEvent(.halfSheetOptIn((self.content?.sourceId ?? "",
                                                              self.isFromCategory)))
        } else {
            self.trackOriginalsCasinoEvent(.optIn(self.isFromCategory))
        }
        
        Task {
            if let result = try? await OptInStatusService().updateOptInStatus(id: id, sourceType: GamePremiereSourceType(rawValue: sourceType) ?? .promos)
                as? OptInServiceModel,
               result.status == GamePremiereOverlayViewModel.optedIn {
                self.isOptedIn = true
            }
        }
    }
    
    private func openLoginPage(completion: ((Bool) -> Void)? = nil) {
        EpcotLobbyManager.shared?.delegate?.didRequestLogin(completionHandler: completion)
    }
}

// MARK: Related to Promo Overlay
extension OriginalsWidgetViewModel {
    
    func getRemainingDaysUntilExpiry() {
        timerViewModel?.$time
            .map { $0.days }
            .sink { [weak self] days in
                self?.remainingDaysUntilExpiry = days
            }
            .store(in: &cancellables)
    }

    var durationText: String {
        if let durationText = content?.durationText, let days = remainingDaysUntilExpiry, days != 0 {
            var formattedText = durationText.replacingOccurrences(of: "{{0}}", with: "\(days)")
            return formattedText
        }
        return ""
    }
    
    var timerIcon: IconVariant? {
        let icon = EpcotLobbyManager.shared?
            .datasource?
            .didRequestForIconVariant(with: content?.timerIcon?.replacingOccurrences(of: "theme-", with: "") ?? "time", fontSize:  styles.timerIconSize ?? 16.0)
        return icon
    }
    
    func onClickViewFullDetails(with url: String) {
        // view full button tap event
        self.trackOriginalsPromoHubEvent(.halfSheetViewFull((self.content?.sourceId ?? "",
                                                             self.isFromCategory)))
        self.onClose?()
        EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .teaserVideos(url), buttonType: nil)
    }
    
    func onTapCloseButton() {
        self.trackOriginalsPromoHubEvent(.halfSheetClose((self.content?.sourceId ?? "",
                                                          self.isFromCategory)))
        self.onClose?()
    }
    
    func trackOverlayLoadEvent() {
        self.trackOriginalsPromoHubEvent(.halfSheetLoad((self.content?.sourceId ?? "",
                                                         self.isFromCategory)))
    }
}

protocol OriginalsWidgetDelegate {
    func didUpdateExpiryStatus(with status: Bool)
}
