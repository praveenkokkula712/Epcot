//
//  OriginalsCategoryWidgetView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 11/09/24.
//

import SwiftUI
import Kingfisher
import Utility

struct OriginalsCategoryWidgetView: View {
    
    @ObservedObject var viewModel: OriginalsWidgetViewModel
    let styles = OriginalsWidgetViewCSS()
    
    var body: some View {
        
        GeometryReader { geometry in
            ZStack {
                
                if let imageUrl = viewModel.content?.mobileCategoryBackgroundImage, !imageUrl.isEmpty {
                    loadImage(urlString: imageUrl,
                              width: geometry.size.width,
                              height: 320)
                    .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.backgroundImage)
                }
                
                VStack(spacing: 0) {
                    
                    // title, description and Timer
                    VStack(spacing: 0) {
                        if let titleText = viewModel.content?.mainTitle, !titleText.isEmpty {
                            let titleSubText = viewModel.content?.mainTitleSubText ?? ""
                            let combinedText = [titleText, titleSubText].joined(separator: " ")
                            Text(combinedText)
                                .font(styles.mainTitleFont)
                                .foregroundColor(styles.mainTitleColor)
                                .padding(.bottom, 4)
                                .lineLimit(1)
                                .minimumScaleFactor(0.5)
                                .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.categoryWidgetTitle)
                        }
                        
                        if let description = viewModel.content?.seeDetailsDescription, !description.isEmpty {
                            Text(description)
                                .font(styles.subTitleFont)
                                .multilineTextAlignment(.center)
                                .foregroundColor(styles.subTitleColor)
                                .padding(.bottom, 12)
                                .minimumScaleFactor(0.5)
                                .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.categoryWidgetSubTitle)
                        }
                        if let timerViewModel = viewModel.timerViewModel {
                            TimerView(viewModel: viewModel,
                                      timeViewModel: timerViewModel,
                                      forCategoryWidget: true)
                            .padding(.bottom, 12)
                        }
                    }
                    .padding(.horizontal, 12)
                    
                    // overaly
                    
                    VStack(spacing: 0) {
                        
                        HStack(alignment: .top) {
                            
                            VStack(alignment: .leading, spacing: 0) {
                                
                                // title
                                if let title = viewModel.content?.overlayHeaderText, !title.isEmpty {
                                    Text(title)
                                        .font(styles.widgetOverlayHeaderTextFont)
                                        .foregroundColor(styles.widgetOverlayHeaderTextColor)
                                        .lineLimit(1)
                                        .minimumScaleFactor(0.5)
                                        .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.categoryWidgetOverlayTitle)
                                        .padding(.bottom, 4)
                                }
                                HStack {
                                    
                                    VStack(alignment: .leading, spacing: 4) {
                                        
                                        // Max prizeText and Value
                                        if let maximumPrizeText = viewModel.content?.seeDetailsLastPrize, !maximumPrizeText.isEmpty,
                                           let maximumPrizeValue = viewModel.content?.prizeValue,
                                           !maximumPrizeValue.isEmpty {
                                            let combinedText = [maximumPrizeText, ":", maximumPrizeValue].joined(separator: " ")
                                            Text(combinedText)
                                                .foregroundColor(styles.widgetOverlayMaximumPrizeTextColor)
                                                .font(styles.widgetOverlayMaximumPrizeTextFont)
                                                .lineLimit(1)
                                                .minimumScaleFactor(0.5)
                                                .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.categoryWidgetOverlayMaxPrice)
                                            
                                        }
                                        
                                        if !viewModel.isOptedIn,
                                           let chancesText = viewModel.content?.beforeOptInContent,
                                           !chancesText.isEmpty  {
                                            Text(chancesText)
                                                .font(styles.widgetOverlayOptInChancesTextFont)
                                                .foregroundColor(styles.widgetOverlayOptInChancesTextColor)
                                                .lineLimit(1)
                                                .minimumScaleFactor(0.5)
                                                .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.categoryWidgetOverlayOptinText)
                                        }
                                        
                                        if viewModel.isOptedIn {
                                            Spacer()
                                        }
                                    }
                                    
                                    Spacer()
                                    
                                    VStack {
                                        Spacer()
                                        ActionButtons(viewModel: viewModel, fromOverlay: false)
                                    }
                                    .frame(width: geometry.size.width * 0.5)
                                }
                            }
                        }
                        .padding(8)
                    }
                    .frame(height: 68)
                    .background(styles.widgetOveralyBGcolor)
                    .cornerRadius(styles.widgetOveralyCornerRadius)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 9)
                .padding(.top, 93)
            }
            .frame(width: geometry.size.width, height: 320)
            .background(gradientColor)
            .onAppear {
                viewModel.trackOriginalsCategoryLoadEvent(.categoryLoad)
            }
        }
    }
    
    private var gradientColor: LinearGradient {
        LinearGradient(
            stops: [
                Gradient.Stop(
                    color: styles.widgetBackgoroundColor1,
                    location: 0.00
                ),
                Gradient.Stop(
                    color: styles.widgetBackgoroundColor2,
                    location: 1.00
                ),
            ],
            startPoint: .top,
            endPoint: .bottom
        )
    }
}
