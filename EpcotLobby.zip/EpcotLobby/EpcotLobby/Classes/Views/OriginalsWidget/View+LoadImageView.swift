//
//  View+loadImageView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 12/09/24.
//

import SwiftUI
import SDWebImageSwiftUI
import Kingfisher

extension View {
    
    @ViewBuilder
    func loadImage(urlString: String?, width: CGFloat, height: CGFloat? = nil)  -> some View {
        if let url = urlString {
            if url.isGIF {
                AnimatedImage(url: URL(string: url),  placeholderImage: UIImage.getImage(named: "placeHolder"))
                    .resizable()
                    .indicator(.activity)
                    .transition(.fade)
                    .frame(width: width, height: height)
                
            } else {
                KFImage(URL(string: url))
                    .placeholder({ PlaceHolderImage() })
                    .resizable()
                    .frame(width: width, height: height)
            }
        }
    }
}
