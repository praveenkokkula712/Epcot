//
//  OriginalsAccessibilityIdentifiers.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 14/10/24.
//

import Foundation

public struct OriginalsAccessibilityIdentifiers  {
    
    // Lobby Widget
    public static let lobbyWidget                       = "originals_lobbyWidget"
    public static let ticketsImage                      = "originals_lobbyWidget_ticketsImage"
    public static let lobbyWidgetDrawingsIcon           = "originals_lobbyWidgetDrawingsIcon"
    public static let lobbyWidgetTitle                  = "originals_lobbyWidgetTitle"
    public static let lobbyWidgetDescription            = "originals_lobbyWidgetDescription"
    public static let viewGamesCta                      = "originals_viewGamesCta"
    public static let seeDetailsCta                     = "originals_seeDetailsCta"
    public static let optInCta                          = "originals_optInCta"
    public static let optedInCta                        = "originals_optedInCta"
    public static let maximumPrizeText                  = "originals_maximumPrizeText"
    public static let maximumPrizeValue                 = "originals_maximumPrizeValue"
    public static let timeLeftText                      = "originals_timeLeftText"
    public static let timeDigit                         = "originals_timeDigit"
    public static let timePeriodLabel                   = "originals_timePeriodLabel"
    
    // Category Widget
    public static let categoryWidget                    = "originals_categoryWidget"
    public static let backgroundImage                   = "originals_backgroundImage"
    public static let categoryWidgetTitle               = "originals_categoryWidgetTitle"
    public static let categoryWidgetSubTitle            = "originals_categoryWidgetSubTitle"
    public static let timerValues                       = "originals_timerValues"
    public static let categoryWidgetOverlay             = "originals_categoryWidgetOverlay"
    public static let categoryWidgetOverlayTitle        = "originals_categoryWidgetOverlayTitle"
    public static let categoryWidgetOverlayIcon         = "originals_categoryWidgetOverlayIcon"
    public static let categoryWidgetOverlayMaxPrice     = "originals_categoryWidgetOverlayMaxPrice"
    public static let categoryWidgetOverlayOptinText    = "originals_categoryWidgetOverlayOptinText"
    
    // Overlay
    public static let overlayHeaderText                 = "originals_overlay_headerText"
    public static let overlayHeaderCloseCta             = "originals_overlay_headerCloseCta"
    public static let ticketsIcon                       = "originals_overlay_ticketsIcon"
    public static let ticketsText                       = "originals_overlay_ticketsText"
    public static let timerIcon                         = "originals_overlay_timerIcon"
    public static let expiresText                       = "originals_overlay_expiresText"
    public static let expiryDate                        = "originals_overlay_expiryDate"
    public static let inDaysText                        = "originals_overlay_inDaysText"
    public static let stepsTitle                        = "originals_overlay_stepsTitle"
    public static let stepNumber                        = "originals_overlay_stepNumber"
    public static let step                              = "originals_overlay_steps"
    public static let bonusIcon                         = "originals_overlay_bonusIcon"
    public static let additionalInfo                    = "originals_overlay_additionalInfo"
    public static let viewFullDetailsCta                = "originals_viewFullDetailsCta"
}
