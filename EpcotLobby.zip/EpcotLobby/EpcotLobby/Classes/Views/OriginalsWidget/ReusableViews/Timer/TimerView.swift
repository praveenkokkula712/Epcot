//
//  TimerView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 02/09/24.
//

import SwiftUI

struct TimerView: View {
    
    // MARK: Properties
    @ObservedObject var viewModel: OriginalsWidgetViewModel
    @ObservedObject var timeViewModel: TimeViewModel
    var forCategoryWidget: Bool
    let styles = OriginalsWidgetViewCSS()
    private var showDays: Bool {
        timeViewModel.time.days > 0
    }
    
    // MARK: Body
    var body: some View {
        
        /// Timer View
        HStack(alignment: .top, spacing: 8) {
            Group {
                
                // days
                if showDays {
                    TimerComponentsView(value: timeViewModel.time.days,
                                        label: viewModel.content?.daysText ?? "",
                                        forCategoryWidget: forCategoryWidget)
                    separator
                        .padding(.top, 10)
                }
                
                // hours
                TimerComponentsView(value: timeViewModel.time.hours,
                                    label: viewModel.content?.hoursText ?? "",
                                    forCategoryWidget: forCategoryWidget)
                separator
                    .padding(.top, 10)
                
                // minutes
                TimerComponentsView(value: timeViewModel.time.minutes,
                                    label: viewModel.content?.minutesText ?? "",
                                    forCategoryWidget: forCategoryWidget)
                
                // seconds
                if !showDays {
                    separator
                        .padding(.top, 10)
                    TimerComponentsView(value: timeViewModel.time.seconds,
                                        label: viewModel.content?.secondsText ?? "",
                                        forCategoryWidget: forCategoryWidget)
                }
            }
        }
    }
    
    
    private var separator: some View {
        VStack(spacing: 3.5) {
            Rectangle()
                .fill(styles.seperatorColor)
                .frame(width: styles.seperatorSize, height: styles.seperatorSize)
            Rectangle()
                .fill(styles.seperatorColor)
                .frame(width: styles.seperatorSize, height: styles.seperatorSize)
        }
    }
}
