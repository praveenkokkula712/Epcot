//
//  TimerComponentsView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 02/09/24.
//

import SwiftUI

struct TimerComponentsView: View {
    
    // MARK: Properties
    var value: Int
    var label: String
    var forCategoryWidget: Bool
    let styles = OriginalsWidgetViewCSS()
    
    var body: some View {
        VStack {
            timeDigits(for: value)
            
            Text(label)
                .foregroundColor(forCategoryWidget ? styles.timeDurationTextColor : styles.durationTextColor)
                .font(forCategoryWidget ? styles.timeDurationTextFont : styles.durationTextFont)
                .lineLimit(1)
                .minimumScaleFactor(0.80)
                .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.timePeriodLabel)
        }
    }
    
    /// renders each digit of the formatted number
    func timeDigits(for number: Int) -> some View {
        let formattedNumber = formatNumber(number: number)
        let digits = digits(of: formattedNumber)
        
        return HStack(spacing: 2) {
            ForEach(digits.indices, id: \.self) { index in
                Text("\(digits[index])")
                    .frame(width: 19, height: 27)
                    .foregroundColor(forCategoryWidget ? styles.timeComponentsColor : styles.timerComponentsColor)
                    .font(forCategoryWidget ? styles.timeComponentsFont : styles.timerComponentsFont)
                    .background(forCategoryWidget ? styles.timerComponentsBackGroundColor : styles.timerComponentsBgColor)
                    .clipShape(RoundedRectangle(cornerRadius: forCategoryWidget ? styles.timeComponentsCornerRadius : styles.timerComponentsCornerRadius))
                    .padding(.trailing, 2)
                    .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.timeDigit)
            }
        }
    }
    
    /// Formats an integer as a string and adds a leading zero if integer is less than 10.
    private func formatNumber(number: Int) -> String {
        return number < 10 ? String(format: "0%d", number) : String(number)
    }
    
    private func digits(of formattedString: String) -> [Int] {
        return formattedString.compactMap { $0.wholeNumberValue }
    }
}
