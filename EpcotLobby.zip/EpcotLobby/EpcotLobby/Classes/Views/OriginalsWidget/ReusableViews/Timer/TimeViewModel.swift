//
//  TimeViewModel.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 02/09/24.
//

import Foundation
import Combine

class TimeViewModel: ObservableObject {
    
    // MARK: Properties
    private var timer: Publishers.Autoconnect<Timer.TimerPublisher>?
    private var subscription: AnyCancellable?
    var expiryDate: Date?
    @Published var time: TimeComponents
    @Published var formattedDate: String
    var isTimerExpired: (() -> Void)?
    
    // MARK: Init
    init(expiryDate: String?, expiryDateFormat: String?) {
        self.expiryDate = expiryDate?.getPromoExpiryDate(expiryDateFormat: expiryDateFormat)
        self.time = TimeComponents(days: 0, hours: 0, minutes: 0, seconds: 0)
        self.formattedDate = ""
        self.formatExpiryDate()
        self.calculateTimeDifference()
        self.startTimer()
    }
    
    private func startTimer() {
        timer = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
        subscription = timer?
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in
                guard let self else { return }
                self.calculateTimeDifference()
            }
    }
    
    private func calculateTimeDifference() {
 
        guard !self.isWidgetTimeExpired() else {
            self.isTimerExpired?()
            return
        }
        
        let components = expiryDate?.time(from: Date())
        let days = components?.day ?? 0
        let hours = components?.hour ?? 0
        let minutes = components?.minute ?? 0
        let seconds = components?.second ?? 0
        
        DispatchQueue.main.async {
            self.time = TimeComponents(days: days, hours: hours, minutes: minutes, seconds: seconds)
        }
    }
    
    private func formatExpiryDate()  {
        
        guard let expiryDate = expiryDate else {
            return
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy, h:mm a"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        self.formattedDate = dateFormatter.string(from: expiryDate)
    }
    
    func stopTimer() {
        timer?.upstream.connect().cancel()
        timer = nil
    }
    
    func isWidgetTimeExpired() -> Bool {
        guard let expiryDate = expiryDate else {
            return true
        }
        
        let result = Date().compare(expiryDate)
        guard result == .orderedAscending else {
            stopTimer()
            return true
        }
        return false
    }
}

struct TimeComponents {
    var days: Int
    var hours: Int
    var minutes: Int
    var seconds: Int
}

