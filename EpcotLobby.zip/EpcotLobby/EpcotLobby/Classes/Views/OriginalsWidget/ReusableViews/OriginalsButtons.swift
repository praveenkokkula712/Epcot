//
//  OriginalsButtons.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 02/09/24.
//

import SwiftUI
import Utility
import Kingfisher

struct ActionButtons: View {
    
    // MARK: Properties
    @ObservedObject var viewModel: OriginalsWidgetViewModel
    var fromOverlay: Bool
    let styles = OriginalsWidgetViewCSS()
    
    // MARK: Body
    var body: some View {
        
        HStack(spacing: 12) {
            
            HapticsButton {
                HStack {
                    Text(fromOverlay ? viewModel.content?.viewDetailsText ?? "" : viewModel.content?.seeDetailsText ?? "")
                }
                .frame(maxWidth: .infinity, minHeight: ButtonHeight)
                .applyGradientBgColors(backgroundColors: [],
                                       font: seeDetailsTextFont,
                                       textColor: seeDetailsTextColor,
                                       cornerRadius:  styles.seeDetailsCtaCornerRadius
                )
                .overlay(
                    RoundedRectangle(cornerRadius: styles.seeDetailsCtaCornerRadius)
                        .stroke(seeDetailsBtnBorderColor, lineWidth: seeDetailsBtnBorderWidth)
                )
                .accessibilityIdentifier(fromOverlay ? OriginalsAccessibilityIdentifiers.viewFullDetailsCta : OriginalsAccessibilityIdentifiers.seeDetailsCta)
            } action: {
                self.fromOverlay ? viewModel.onClickViewFullDetails(with: viewModel.content?.viewDetailsUpdatedUrl ?? "") : viewModel.onTapSeeDetailsButton()
            }
            
            HapticsButton {
                HStack(spacing: 5) {
                    
                    if viewModel.isOptedIn ?? false {
                        if let successIcon = self.successIcon {
                            Text(successIcon.icon)
                                .font(Font(successIcon.font))
                                .frame(width: styles.greenTickIconSIze,
                                       height: styles.greenTickIconSIze)
                                .background(.white)
                                .foregroundColor(styles.greenTickIconColor)
                                .cornerRadius((styles.greenTickIconSIze/2) + 1)
                        }
                        Text(viewModel.content?.optedInText ?? "")
                    } else {
                        Text(viewModel.content?.optinText ?? "")
                    }
                }
                .frame(maxWidth: .infinity, minHeight: ButtonHeight)
                .applyGradientBgColors(backgroundColors: viewModel.isOptedIn ?? false ? [] : styles.optInCtaBgColors,
                                       font: viewModel.isOptedIn ?? false ? optedInCtaTextFont : optInCtaTextFont,
                                       textColor: viewModel.isOptedIn ?? false ? optedInCtaTextColor : optInCtaTextColor,
                                       cornerRadius: styles.optInCtaCornerRadius
                )
                .accessibilityIdentifier(viewModel.isOptedIn ? OriginalsAccessibilityIdentifiers.optedInCta : OriginalsAccessibilityIdentifiers.optInCta)
            } action: {
                viewModel.updateOptInStatus(isFromOverlay: self.fromOverlay)
            }
            .disabled(viewModel.isOptedIn ?? false)
        }
        .padding(.horizontal, 1)
    }
}

extension ActionButtons {
    
    var seeDetailsTextColor: Color {
        return fromOverlay ? styles.viewFullDetailsTextColor : styles.seeDetailsCtaTextColor
    }
    
    var seeDetailsTextFont: Font {
        return fromOverlay ? styles.viewFullDetailsTextFont : styles.seeDetailsCtaTextFont
    }
    
    var seeDetailsBtnBorderColor: Color {
        return fromOverlay ? styles.viewFullDetailsCtaBorderColor : styles.seeDetailsCtaBorderColor
    }
    
    var seeDetailsBtnBorderWidth: CGFloat {
        return fromOverlay ? styles.viewFullDetailsCtaBorderWidth : styles.seeDetailsCtaBorderWidth
    }
    
    var optInCtaTextColor: Color {
        return fromOverlay ? styles.overalyOptInCtaTextColor : styles.optInCtaTextColor
    }
    
    var optInCtaTextFont: Font {
        return fromOverlay ? styles.overalyOptInCtaTextFont : styles.optInCtaTextFont
    }
    
    var optedInCtaTextColor: Color {
        return fromOverlay ? styles.overalyOptedInCtaTextColor : styles.optedInCtaTextColor
    }
    
    var optedInCtaTextFont: Font {
        return fromOverlay ? styles.overalyOptedInCtaTextFont : styles.optedInCtaTextFont
    }
    
    var ButtonHeight: CGFloat {
        return fromOverlay ? 40.0 : 24.0
    }
    
    var successIcon: IconVariant? {
        let icon = EpcotLobbyManager.shared?
            .datasource?
            .didRequestForIconVariant(with: viewModel.content?.greenTickIcon?.replacingOccurrences(of: "theme-", with: "") ?? "success-i", fontSize:  styles.greenTickIconSIze ?? 16.0)
        return icon
    }
}
