//
//  EpoctlobbyviewController+OriginalsOverlay.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 04/09/24.
//

import Foundation
import TrackerClient
import SwiftUI

extension EpcotLobbyViewController {
    func presentOriginalsOverlayView() {
        
        if let originalsWidgetViewModel = self.immersiveGamesCollectionViewController?.originalsWidgetViewModel {
            originalsWidgetViewModel.onClose = { [weak self] in
                self?.originalsOverlayController?.dismiss(animated: true)
                self?.originalsOverlayController = nil
            }
            let originalsOverlay = OriginalsOverlayView(viewModel: originalsWidgetViewModel)
            self.originalsOverlayController = UIHostingController(rootView: originalsOverlay)
            self.originalsOverlayController?.modalPresentationStyle = .overFullScreen
            self.originalsOverlayController?.modalPresentationCapturesStatusBarAppearance = true
            self.originalsOverlayController?.view.layer.speed = 0.75
            self.originalsOverlayController?.view.backgroundColor = .black.withAlphaComponent(0.5)
            if let originalsOverlayController,
               let topController = UIApplication.mainWindow.rootViewController {
                topController.present(originalsOverlayController, animated: true)
            }
        }
    }
}

//MARK:  Originals widget navigation click events
extension EpcotLobbyViewController {
    
    func trackOriginalsNavigationEvent(_ type: OriginalsWidgetEvent) {
        let isUserLoggedIn = EntainContext.user?.isLoggedIn() ?? false
        let userId = EntainContext.user?.accountId ?? ""
        
        var locationEvent = ""
        var eventDetails = ""
        var positionEvent = ""
        
        switch type {
        case .categoryPill(let category, let index, let close):
            if close {
                locationEvent = category
                eventDetails = EpcotEventDetails.close.rawValue
            } else {
                locationEvent = ""
                eventDetails = category
            }
            positionEvent = String(index)
        default:
            return
        }
        
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.navigation.rawValue,
                                     actionEvent: EpcotEventAction.click.rawValue,
                                     labelEvent: EpcotEventLabel.quick_nav.rawValue,
                                     locationEvent: locationEvent,
                                     eventDetails: eventDetails,
                                     positionEvent: positionEvent,
                                     productType: EpcotEventProductType.casino.rawValue,
                                     userID: userId,
                                     screenName: ScreenName.home.rawValue,
                                     loggedInEvent: isUserLoggedIn ? .loggedIn : .notLoggedIn,
                                     customerIdEvent: userId,
                                     customTimestamp: Date().unixTimestampInMicroseconds,
                                     loggedInState: isUserLoggedIn ? .loggedIn : .notLoggedIn,
                                     customerId: userId,
                                     lobbyName: EpcotEventOriginalsWidget.casino_lobby.rawValue,
                                     lobbySource: EntainContext.app?.brandId ?? "")
            
            let event = TrackerEvent(type: .quick_navigation, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}

