//
//  DetailedStepsView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 04/09/24.
//

import SwiftUI
import Kingfisher

struct DetailedStepsView: View {
    
    var steps: [String]
    var bonusImageUrl: String?
    let styles = OriginalsWidgetViewCSS()
    
    var body: some View {

        ForEach(steps.indices, id: \.self) { index in
            HStack(alignment: .top) {
                VStack(spacing: 0) {
                    if index != steps.count - 1 {
                        StepNumberView(stepNumber: index + 1)
                            .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.stepNumber + "\(index + 1)")
                        Rectangle()
                            .fill(styles.barColor)
                            .frame(width: styles.barWidth)
                            .padding([.top, .bottom], 2)
                    } else {
                        if let image = bonusImageUrl {
                            KFImage(URL(string: image))
                                .resizable()
                                .placeholder({ PlaceHolderImage() })
                                .scaledToFit()
                                .frame(width: styles.bonusIconSize, height: styles.bonusIconSize)
                                .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.bonusIcon)
                        }
                    }
                }
                .frame(width: 20)
                
                Text(steps[index])
                    .font(styles.stepsDescriptionFont)
                    .foregroundColor(styles.stepsDescriptionColor)
                    .padding(.bottom, 8)
                    .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.step + "\(index + 1)")
            }
        }
    }
}

struct StepNumberView: View {
    
    var stepNumber: Int
    let styles = OriginalsWidgetViewCSS()
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(styles.stepNumberBorderColor,lineWidth: styles.stepNumberBorderWidth)
                .frame(width: 16, height: 16)
            Text("\(stepNumber)")
                .foregroundColor(styles.stepNumberColor)
                .font(styles.stepNumberFont)
        }
    }
}

