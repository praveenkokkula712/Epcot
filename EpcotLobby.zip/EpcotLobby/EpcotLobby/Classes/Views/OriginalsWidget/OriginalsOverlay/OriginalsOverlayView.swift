//
//  OriginalsOverlayView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 04/09/24.
//

import SwiftUI
import Utility
import Kingfisher

struct OriginalsOverlayView: View {
    
    @ObservedObject var viewModel: OriginalsWidgetViewModel
    let styles = OriginalsWidgetViewCSS()
    
    var body: some View {
        
        GeometryReader { geometry in
            ZStack(alignment: .bottom) {
                Color.clear
                    .contentShape(Rectangle())
                    .ignoresSafeArea()
                    .onTapGesture {
                        viewModel.onClose?()
                    }
                
                VStack(spacing: 0) {
                    
                    //Header title
                    HStack {
                        VStack(alignment: .leading) {
                            if let headerText = viewModel.content?.overlayHeaderText {
                                Text(headerText)
                                    .font(styles.headerTitleFont)
                                    .foregroundColor(styles.headerTitleColor)
                                    .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.overlayHeaderText)
                            }
                        }
                        
                        Spacer ()
                        
                        // Close button
                        HapticsButton {
                            HStack {
                                Text(viewModel.content?.overlayHeaderButtonText ?? "")
                            }
                            .frame(minHeight: 16)
                            .foregroundColor(styles.closeBtnTitleColor)
                            .font(styles.closeBtnTitleFont)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .overlay {
                                RoundedRectangle(cornerRadius: styles.closeBtnCornerRadius)
                                    .stroke(styles.closeBtnBorderColor, lineWidth: styles.closeBtnBorderWidth)
                            }
                            .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.overlayHeaderCloseCta)
                        } action: {
                            viewModel.onTapCloseButton()
                        }
                        
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(
                        styles.overlayHeaderBgColor
                            .cornerRadius(styles.overlayHeaderCornerRadius, corners: [.topLeft, .topRight])
                    )
                    
                    ScrollView(showsIndicators: false) {
                        VStack(alignment: .leading, spacing: 0) {
                            HStack(alignment: .top) {
                                
                                if let image = viewModel.content?.ticketIcon, !image.isEmpty {
                                    KFImage(URL(string: image))
                                        .resizable()
                                        .placeholder({ PlaceHolderImage() })
                                        .scaledToFit()
                                        .frame(width: styles.ticketsIconSize,
                                               height: styles.ticketsIconSize)
                                        .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.ticketsIcon)
                                }

                                if let ticketsContent = viewModel.content?.ticketTextDetails {
                                    Text(ticketsContent)
                                        .font(styles.ticketsTextFont)
                                        .foregroundColor(styles.ticketsTextColor)
                                        .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.ticketsText)
                                    Spacer()
                                }
                            }
                            .padding(.bottom, 8)
                            
                            HStack(alignment: .top) {
                             
                                // Timer Icon
                                if let timerIcon = viewModel.timerIcon {
                                    Text(timerIcon.icon)
                                        .font(Font(timerIcon.font))
                                        .frame(width: styles.ticketsIconSize,
                                               height: styles.ticketsIconSize)
                                        .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.timerIcon)
                                }
                                
                           
                                if let expiresText = viewModel.content?.timeTextDetails, let expiryDate = viewModel.formattedDate {
                                    let expiryDateAndTime = [expiresText, ":" , expiryDate].joined(separator: " ")
                                    Text(expiryDateAndTime)
                                        .font(styles.expiresTextFont)
                                        .foregroundColor(styles.expiresTextColor)
                                        .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.expiryDate)
                                }
                                
                                Spacer()
                                
                                // DurationText
                                Text("\(viewModel.durationText)")
                                    .font(styles.inDaysTextFont)
                                    .foregroundColor(styles.inDaysTextColor)
                                    .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.inDaysText)
                            }
                            .padding(.bottom, 12)
                            
                            Divider()
                                .background(styles.dividerColor1)
                                .frame(height: 1)
                            
                            VStack(alignment: .leading, spacing: 0) {
                                if let steps = viewModel.content?.steps {
                                    
                                    // Steps Title
                                    if let stepsTitle = viewModel.content?.subDetailsHeaderText {
                                        Text(stepsTitle)
                                            .font(styles.stepsTitleTextFont)
                                            .foregroundColor(styles.stepsTitleTextColor)
                                            .padding(.bottom, 8)
                                            .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.stepsTitle)
                                    }
                                    
                                    // Steps Description
                                    DetailedStepsView(steps: steps,
                                                      bonusImageUrl: viewModel.content?.themeBonusIcon)
                                    
                                    if let additionalInfo = viewModel.content?.additionalInformation {
                                        Text(additionalInfo)
                                            .font(styles.additionalInfoTextFont)
                                            .foregroundColor(styles.additionalInfoTextColor)
                                            .padding(.top, 10)
                                            .accessibilityIdentifier(OriginalsAccessibilityIdentifiers.additionalInfo)
                                    }
                                }
                            }
                            .padding(.top, 12)
                            .padding(.bottom, 12)
                            
                            Divider()
                                .background(styles.dividerColor2)
                                .frame(height: 1)
                            
                            // Buttons
                            HStack {
                                ActionButtons(viewModel: viewModel, fromOverlay: true)
                            }
                            .padding(.top, 12)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 12)
                    .background(Color.white)
                }
                .frame(width: UIDevice.current.userInterfaceIdiom == .pad ? geometry.size.width * 0.5: geometry.size.width , height: 377)
            }
            .onAppear {
                viewModel.trackOverlayLoadEvent()
            }
        }
    }
}
