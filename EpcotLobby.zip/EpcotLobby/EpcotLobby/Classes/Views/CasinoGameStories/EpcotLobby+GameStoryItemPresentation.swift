//
//  EpcotLobby+GameStoryItemPresentation.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 24/04/23.
//

import UIKit

extension EpcotLobbyViewController {
    func presentGameStoryItemView(viewModel: GameStoriesViewModel) {
        let gameStoryViewController = GameStoryItemViewController(
            viewModel: viewModel
        )
        gameStoryViewController.transitioningDelegate = self
        gameStoryViewController.modalPresentationStyle = .custom
        self.present(gameStoryViewController, animated: true)
    }
}

extension EpcotLobbyViewController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        gameStoryViewTransition.transitionMode = .present
        configureTransition()
        return gameStoryViewTransition
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        gameStoryViewTransition.transitionMode = .dismiss
        configureTransition()
        return gameStoryViewTransition
    }
    
    private func configureTransition() {
        let pointX = gameStoryViewFrame.origin.x + gameStoryViewFrame.width / 2
        let pointY = gameStoryViewFrame.origin.y + gameStoryViewFrame.height / 2
        gameStoryViewTransition.startingPoint = CGPoint(x: pointX, y: pointY)
        gameStoryViewTransition.circleColor = .black
        gameStoryViewTransition.duration = 0.25
    }
}
