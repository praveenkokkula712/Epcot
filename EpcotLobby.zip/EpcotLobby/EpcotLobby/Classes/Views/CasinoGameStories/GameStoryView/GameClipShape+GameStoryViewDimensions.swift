//
//  GameClipShape+GameStoryViewDimensions.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 19/04/23.
//

import Foundation

extension GameClipShape {
    var imageSize: CGSize {
        let isIPad = UIDevice.isIPad()
        switch self {
        case .circle, .roundedRect:
            let tileSize = isIPad ? 72 : 64
            return CGSize(width: tileSize, height: tileSize)
        case .rhombus:
            let tileSize = isIPad ? 96 : 88
            return CGSize(width: tileSize, height: tileSize)
        }
    }

    var optinTickOffset: CGSize {
        switch self {
        case .circle:
            return CGSize(width: 0, height: 2)
        case .roundedRect:
            return CGSize(width: 5, height: -5)
        case .rhombus:
            return CGSize(width: -5, height: 0)
        }
    }

    var verticalSpacer: Double {
        switch self {
        case .circle, .roundedRect:
            return 0.0
        case .rhombus:
            return 8.0
        }
    }

    var horizontalSpacer: Double {
        switch self {
        case .circle, .roundedRect:
            return 4.0
        case .rhombus:
            return 8.0
        }
    }
    
    //NOTE: We are not comparing the showHeaderTitle key for iPad device
    // since the Dynacon does not have the support of differentiate device
    // types.
    var gameStoriesViewHeight: CGFloat {
        let isIPad = UIDevice.isIPad() //UIDevice.isIPad() && showHeaderTitle
        switch self {
        case .circle, .roundedRect:
            return isIPad ? 144 : 112 // 144 = [112 + 20 (header) + 8]
        case .rhombus:
            return isIPad ? 162 : 124 // 162 = [124 + 20 + 8]
        }
    }
}
