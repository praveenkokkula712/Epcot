//
//  GameStoriesView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 13/04/23.
//

import SwiftUI
import Utility

struct GameStoriesView: View {

    // MARK: - Properties
    @StateObject var viewModel = GameStoriesViewModel()
    var styles: GameStoriesViewCSS
    private let accessibilityIdentifiers = CasinoStoriesAccessibilityIdentifiers()
    var onGameStoryTap: (_ storyViewRect: CGRect) -> Void

    @State private var showDetailView = false
    @State private var buttonFrames = [Int: CGRect]()

    // MARK: - UI Content
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {

            // Header View
            if viewModel.showHeaderTitle {
                Text(Localize.latestStories)
                    .foregroundColor(styles.headerTitleColor)
                    .font(styles.headerTitleFont)
                    .padding(.horizontal, horizontalSpacer)
                    .accessibilityIdentifier(headerTitleIdentifier)
            }

            // Game Stories
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack {
                    ForEach(0..<viewModel.stories.count, id: \.self) { index in
                        GameStoryView(story: viewModel.stories[index],
                                      clipShape: viewModel.clipShape,
                                      styles: styles) {
                            viewModel.openStory(of: index)
                            self.onGameStoryTap(self.buttonFrames[index] ?? .zero)
                        }
                        .overlay(
                            GeometryReader(content: { geometry -> Color in
                                DispatchQueue.main.async {
                                    let btFrame = geometry.frame(in: .global)
                                    self.buttonFrames[index] = btFrame
                                }
                                return Color.clear
                            })
                        )
                    }
                }
                .padding(.horizontal, horizontalSpacer)
            }
            .frame(minWidth: 0, maxWidth: .infinity)
        }
    }

    // MARK: - Design Constants
    private var horizontalSpacer: Double {
        let isIPad = UIDevice.isIPad()
        return isIPad ? 24.0 : 16.0
    }
}

// MARK: - Accessibility Identifiers
extension GameStoriesView {
    
    private var headerTitleIdentifier : String {
        accessibilityIdentifiers.casinoStoriesHeader
    }
}

struct GameStoriesView_Previews: PreviewProvider {
    static var previews: some View {
        GameStoriesView(styles: GameStoriesViewCSS()) { _ in }
            .background(Color.black)
    }
}
