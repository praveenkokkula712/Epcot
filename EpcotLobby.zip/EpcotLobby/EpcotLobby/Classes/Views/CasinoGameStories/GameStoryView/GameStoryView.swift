//
//  GameStoryView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 13/04/23.
//

import SwiftUI
import Utility

struct GameStoryView: View {

    // MARK: - Properties
    private(set) var story: GameStory
    private var clipShape: GameClipShape
    private var onGameStoryTap: () -> Void
    private var styles: GameStoriesViewCSS
    private let accessibilityIdentifiers = CasinoStoriesAccessibilityIdentifiers()

    // MARK: - Init
    init(story: GameStory,
         clipShape: GameClipShape,
         styles: GameStoriesViewCSS,
         onGameStoryTap: @escaping () -> Void) {
        self.story = story
        self.clipShape = clipShape
        self.styles = styles
        self.onGameStoryTap = onGameStoryTap
    }

    // MARK: - UI Content
    var body: some View {
        Button(action: onGameStoryTap) {
            VStack {
                GameStoryImage(
                    clipShape: clipShape,
                    width: clipShape.imageSize.width,
                    height: clipShape.imageSize.height,
                    strokeColor: !story.isVisited ? styles.selectedColor : styles.unselectedColor,
                    strokeWidth: styles.lineWidth,
                    cornerRadius: styles.cornerRadius,
                    rotation: 45
                )
                .padding(.bottom, clipShape.verticalSpacer)
                .opacity(
                    !story.isVisited ?
                    1.0 : styles.unselectedViewAlpha
                )
                .accessibilityIdentifier(storyImageIdentifier)
                // TODO: We are commenting this as per Product Team Requirement.
//                .if(story.isOpted) { view in
//                    view
//                        .overlay(
//                            CircularTick(fillColor: tickmarkColor)
//                                .offset(clipShape.optinTickOffset),
//                            alignment: .topTrailing
//                        )
//                }
                Text(story.name)
                    .font(styles.textFont)
                    .foregroundColor(textColor)
                    .accessibilityIdentifier(storyNameIdentifier)
            }
            .offset(x: 0, y: clipShape == .rhombus ? 5 : 0)
            .padding(.horizontal, clipShape.horizontalSpacer)
        }
    }

    // MARK: - Design Constants
    private var circleColor: Color {
        return !story.isVisited ?
        styles.selectedColor : styles.unselectedColor
    }

    private var textColor: Color {
        return !story.isVisited ?
        styles.selectedTextColor : styles.unselectedTextColor
    }

    private var tickmarkColor: Color {
        return story.isOpted ? styles.selectedColor : .clear
    }
}

// MARK: - Accessibility Identifiers
extension GameStoryView {
    
    private var storyImageIdentifier : String {
        accessibilityIdentifiers.mainStoryImage
    }
    private var storyNameIdentifier : String {
        accessibilityIdentifiers.mainStoryTitle
    }
}

struct GameStoryView_Previews: PreviewProvider {
    static var previews: some View {
        HStack {
            GameStoryView(
                story: GameStory.list[3],
                clipShape: .circle,
                styles: GameStoriesViewCSS()
            ) { }
            GameStoryView(
                story: GameStory.list[3],
                clipShape: .roundedRect,
                styles: GameStoriesViewCSS()
            ) { }
            GameStoryView(
                story: GameStory.list[3],
                clipShape: .rhombus,
                styles: GameStoriesViewCSS()
            ) { }
        }
        .background(Color.black)
    }
}
