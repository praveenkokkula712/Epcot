//
//  GameStoryView+Shape.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 13/04/23.
//

import SwiftUI
import Kingfisher

extension GameStoryView {
    func GameStoryImage(clipShape: GameClipShape,
                        width: CGFloat,
                        height: CGFloat,
                        strokeColor: Color,
                        strokeWidth: Double,
                        cornerRadius: Double,
                        rotation: Double) -> some View {
        VStack {
            switch clipShape {
            case .circle:
                CircularMask(strokeColor: strokeColor,
                             strokeWidth: strokeWidth) {
                    GameImage
                        .frame(width: width, height: height)
                }
            case .roundedRect:
                RoundRectangularMask(strokeColor: strokeColor,
                                     strokeWidth: strokeWidth,
                                     cornerRadius: cornerRadius) {
                    GameImage
                        .frame(width: width, height: height)
                }
            case .rhombus:
                DiamondMask(strokeColor: strokeColor,
                            strokeWidth: strokeWidth,
                            cornerRadius: cornerRadius,
                            rotation: rotation) {
                    ZStack {
                        GameImage
                            .frame(width: width, height: height)
                            .rotationEffect(.degrees(-rotation))
                    }
                    .frame(width: cos(.pi/4) * width, height: sin(.pi/4) * height)
                    .cornerRadius(cornerRadius - 4)
                    .rotationEffect(.degrees(rotation))
                }
                .padding(.horizontal, 4)
            }
        }
    }
}

extension GameStoryView {
    @ViewBuilder
    private var GameImage: some View {
        if !story.imageURL.isEmpty,
           let url = URL(string: story.imageURL) {
            KFImage.url(url)
                .placeholder {
                    PlaceHolderImage()
                }
                .resizable()
                .scaledToFill()
        } else if story.isOnboard {
            let content = POSAPI.shared?.casinoStoriesContent
            if let url = URL(string: content?.logoUrl ?? "") {
                KFImage.url(url)
                    .placeholder {
                        PlaceHolderImage()
                    }
                    .resizable()
                    .scaledToFill()
                    .padding(16)
            } else {
                EmptyView()
            }
        } else {
            EmptyView()
        }
    }
}
