//
//  CircularTick.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 13/04/23.
//

import SwiftUI

struct CircularTick: View {

    // MARK: - Properties
    var fillColor: Color
    var radius: Double

    // MARK: - Init
    init(fillColor: Color = .yellow, radius: Double = 20) {
        self.fillColor = fillColor
        self.radius = radius
    }

    // MARK: - UI Content
    var body: some View {
        Circle()
            .fill(fillColor)
            .frame(width: radius)
            .overlay(checkmark)
    }

    @ViewBuilder
    private var checkmark: some View {
        let checkmark = UIImage(named: kcheckMarkIcon,
                                in: Bundle(for: EpcotLobbyManager.self),
                                compatibleWith: nil)
        if let mark = checkmark {
            Image(uiImage: mark)
                .frame(width: 9.0, height: 7.0)
        } else {
            EmptyView()
        }
    }
}

struct CircularTick_Previews: PreviewProvider {
    static var previews: some View {
        CircularTick(fillColor: .yellow)
    }
}
