//
//  GameStoryItemOnboardingProperties.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 25/05/23.
//

import Foundation
import Combine

class GameStoryOnboardingProperties: ObservableObject {
    var isLogoAnimated: Bool = false
    private var cancellable: AnyCancellable?
    private var totalDuration: Double = 12.0
    private var step: Double = 0.051
    private var currentDuration: Double = 0
    private var durationPercentage: Double = 0
    @Published var opacity: Double  = 1
    @Published var radius: Double = 1.0
    @Published var borderWidth: CGFloat = 3.0
}

extension GameStoryOnboardingProperties {
    
    func startLogoRippleEffect(with totalDuration: Int) {
        self.updateTotalDuration(duration: totalDuration)
        self.updateStep()
        
        self.cancellable = Timer.publish(every: self.step, on: .main, in: .default)
            .autoconnect()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                guard let self = self else { return }
                if self.currentDuration == self.totalDuration {
                    self.currentDuration = self.step
                } else if self.currentDuration < self.totalDuration {
                    self.currentDuration = (self.currentDuration + self.step).round(to: 2)
                }
                self.updateRippleEffectProperties()
            }
    }
    
    func cancelLogoRippleEffect() {
        self.cancellable?.cancel()
        self.resetRippleEffectProperties()
    }
    
}

//Private
extension GameStoryOnboardingProperties {

    private func updateTotalDuration(duration: Int) {
        ///making 85% or (85/2)% of total progress interval time as total duration
        let multiple = duration > 9 ? 0.425 : 0.85
        let timeInterval = Double(duration)*multiple
        self.totalDuration = timeInterval.round(to: 2)
    }
    
    private func updateStep() {
        self.step = self.totalDuration/100
    }
    
    private func updateRippleEffectProperties() {
        self.durationPercentage = currentDuration/totalDuration
        self.opacity = 1-self.durationPercentage
        self.radius = 1.0+(3*self.durationPercentage)
        self.borderWidth = 1-self.durationPercentage
    }
    
    private func resetRippleEffectProperties() {
        self.durationPercentage = 0
        self.opacity = 1
        self.radius = 1.0
        self.borderWidth = 1
    }
}
