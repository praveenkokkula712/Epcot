//
//  GameStoryItemViewModel.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 02/05/23.
//

import Foundation

class GameStoryItemViewModel: ObservableObject {

    private(set) var id = UUID()
    // MARK: - Properties
    @Published private(set) var item = GameStoryItem()
    ///as we are storing the storiesViewModel in every itemViewModel, marking this as weak
    private(set) weak var viewModel = GameStoriesViewModel()
    private(set) var story = GameStory()
    private(set) var isOnboardingStory: Bool = false
    private(set) var isSwipeUpContent: Bool = false
    private(set) var selectedItemIndex = 0
    private(set) var onCloseButtonTap: () -> Void
    private(set) var onCTAButtonTap: (String) -> Void
    private(set) var onOptInButtonTap: (GameStoryItemViewModel) -> Void
    private(set) var onSeeMoreButtonTap: (() -> Void)?
    private(set) var moveToNextGameStory: () -> Void
    private(set) var moveToPreviousGameStory: () -> Void
    private(set) var updateCurrentGameStory: ((GameStoryItemViewModel)) -> Void

    @Published var isLongPressed = false
    @Published var closeButtonInteracted = 0.0
    @Published var ctaButtonInteracted = 0.0
    @Published var optInButtonInteracted = 0.0

    // MARK: - Init
    init(viewModel: GameStoriesViewModel = GameStoriesViewModel(),
         story: GameStory = GameStory(),
         isSwipeUp: Bool = false,
         onCloseButtonTap: @escaping () -> Void = { },
         onCTAButtonTap: @escaping (String) -> Void = { _ in },
         onOptInButtonTap: @escaping (GameStoryItemViewModel) -> Void = { _ in },
         moveToNextGameStory: @escaping () -> Void = { },
         moveToPreviousGameStory: @escaping () -> Void = { },
         updateCurrentGameStory: @escaping ((GameStoryItemViewModel)) -> Void = { _ in }) {
        self.viewModel = viewModel
        self.story = story
        self.isOnboardingStory = self.story.isOnboard
        self.isSwipeUpContent = isSwipeUp
        self.onCloseButtonTap = onCloseButtonTap
        self.onCTAButtonTap = onCTAButtonTap
        self.onOptInButtonTap = onOptInButtonTap
        self.moveToNextGameStory = moveToNextGameStory
        self.moveToPreviousGameStory = moveToPreviousGameStory
        self.updateCurrentGameStory = updateCurrentGameStory
        if story.storyItems.isEmpty {
            self.item = GameStoryItem()
        } else {
            let nonVisitedItem = self.nonVisitedItem()
            let swipUpItem = nonVisitedItem.swipeUpContentItems.first ?? nonVisitedItem
            self.item = isSwipeUp ? swipUpItem : nonVisitedItem
        }
    }

    func actions(onCloseButtonTap: @escaping () -> Void = { },
                 onCTAButtonTap: @escaping (String) -> Void = { _ in },
                 onOptInButtonTap: @escaping (GameStoryItemViewModel) -> Void = { _ in },
                 moveToNextGameStory: @escaping () -> Void = { },
                 moveToPreviousGameStory: @escaping () -> Void = { }, 
                 updateCurrentGameStory: @escaping ((GameStoryItemViewModel)) -> Void = { _ in }) -> GameStoryItemViewModel {
        self.onCloseButtonTap = onCloseButtonTap
        self.onCTAButtonTap = onCTAButtonTap
        self.onOptInButtonTap = onOptInButtonTap
        self.moveToNextGameStory = moveToNextGameStory
        self.moveToPreviousGameStory = moveToPreviousGameStory
        self.updateCurrentGameStory = updateCurrentGameStory
        
        return self
    }
    
    // MARK: - Touch Sensing
    func onLeftAreaTouch() {
        guard !isSwipeUpContent else { return }
        if selectedItemIndex > 0 {
            selectedItemIndex -= 1
        }
        item = currentItem
    }

    func onRightAreaTouch() {
        guard !isSwipeUpContent else { return }
        if selectedItemIndex < story.storyItems.count - 1 {
            selectedItemIndex += 1
        }
        item = currentItem
        self.item.markVisited()
        self.markStoryAsVisited()
    }
    
    var isCurrentStoryIsDisplaying: Bool {
        return self.viewModel?.currentStory?.path == self.story.path
    }
    
    func markStoryAsVisited () {
        if selectedItemIndex == story.storyItems.count - 1 {
            self.story.markVisited()
        }
    }
    
    var isFirstStory: Bool {
        return viewModel?.selectedStoryIndex ?? -1 == 0
    }

    var isLastStory: Bool {
        return viewModel?.selectedStoryIndex ?? -1 == (viewModel?.stories.count ?? 0) - 1
    }
    
    //MARK: verify and update Current Story as visible view
    func updateCurrentGameStoryAsVisibleIndex() {
        self.updateCurrentGameStory(self)
    }
    
    // MARK: - Auto Scroll
    func scrollToIndex(_ index: Int) {
        guard story.storyItems.count > index else { return }
        self.selectedItemIndex = index
        item = currentItem
    }

    // MARK: - Helper
    lazy var ctaTitle: String = {
        var htmlParser = HTMLParser(value: item.cta)
        return String(htmlParser.getTitleOfhref().first ?? "")
    }()

    lazy var ctaLink: String = {
        var htmlParser = HTMLParser(value: item.cta)
        return String(htmlParser.getValues(tag: "href").first ?? "")
    }()
}

///Updates from View -- only for Swipe up
extension GameStoryItemViewModel {
    func updateStoryItem(with index: Int) {
        self.selectedItemIndex = index
        self.item = self.currentItem.swipeUpContentItems.first ?? self.currentItem
    }
}

extension GameStoryItemViewModel {
    
    private var currentItem: GameStoryItem {
        guard selectedItemIndex > -1  && selectedItemIndex < story.storyItems.count else { return GameStoryItem() }
        let currentItem = self.story.storyItems[selectedItemIndex]
        return currentItem
    }
    
    private func nonVisitedItem() -> GameStoryItem {
        ///we have 'N' storyItems and if user visited all, we need to make the index as 0 else different index
        self.selectedItemIndex = story.storyItems.firstIndex(where: { !$0.isVisited }) ?? 0
        return currentItem
    }
}
