//
//  GameStoriesViewModel+Onboarding.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 30/05/23.
//

import Foundation

extension GameStoriesViewModel {
    
    var showOnboarding: Bool {
        UserOnboardingViewModel.shared?.journey(with: .casinoStories) != nil
    }
        
    func addOnboardingStory() {
        if self.showOnboarding,
           !self.onboardingStories.isEmpty,
           !(self.stories.first?.isOnboard ?? false) {
            if let onboardingStory = self.onboardingStories.first {
                self.stories.insert(onboardingStory, at: 0)
            }
        }
    }
    
    func removeOnboardingStory() {
        if !self.showOnboarding,
           self.stories.first?.isOnboard ?? false {
            self.stories.removeFirst()
        }
    }

    func replaceOnboardingStoryIfPresent() {
        if let onboardingStoryIndex = stories.firstIndex(where: { $0.isOnboard }),
           onboardingStoryIndex != 0 {
            let onboardingStory = stories[onboardingStoryIndex]
            stories.remove(at: onboardingStoryIndex)
            stories.insert(onboardingStory, at: 0)
        }
    }
}

extension GameStoriesViewModel: UserOnboardingProtocol {
    
    func subscribeTo(subject: UserOnboardingPassthroughSubject) {
        onboardingPagingInfoToken = subject
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: { model in
                switch model.type {
                case .casinoStories:
                    ///index is nil means not opened any story, after lobby/stories loaded
                    if self.selectedStoryIndex == nil {
                        self.addOnboardingStory()
                        self.reOrderStories()
                    }
                default: break
                }
            })
    }
}
