//
//  GameStoriesViewModel.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 17/04/23.
//

import Foundation
import Combine
import Kingfisher
import ConfigModule

enum CasinoGameStoryError: Error {
    case contentNotFound
}

class GameStoriesViewModel: ObservableObject {
    
    // MARK: - Properties
    @Published var showHeaderTitle: Bool
    @Published var clipShape: GameClipShape = .circle
    @Published var stories: [GameStory] = []
    @Published var itemViewModels: [GameStoryItemViewModel] = []
    var onboardingStories: [GameStory] = []
    var selectedStoryIndex: Int?
    var onboardingPagingInfoToken: AnyCancellable?
    var pausedProgressValue: Double = 0.0
    private var openedLobbyStory: Bool = false
    
    var isSeeMoreViewIsShowing = false
    
    var isGameStoriesPresented: Bool = false

    // MARK: - Init
    init(showHeaderTitle: Bool? = false) {
        self.showHeaderTitle = showHeaderTitle ?? false
        UserOnboardingViewModel.shared?.subscribeToCasinoStories(view: self)
    }

    // MARK: - Model updates
    func fetchGameStoriesContent() async throws -> Result<CasinoStoryContainer, Error> {
        let result = try await CasinoStoriesServiceManager().fetch(POSAPI.StoryContent)
        switch result {
        case .success(let response):
            ETLogger.debug("\(response)")
            if let container = response as? CasinoStoryContainer {
                DispatchQueue.main.async {
                    self.updateModel(container)
                }
                return .success(container)
            } else {
                return .failure(CasinoGameStoryError.contentNotFound)
            }
        case .failure(let error):
            ETLogger.debug("\(error.localizedDescription)")
            return .failure(error)
        }
    }

    private func updateModel(_ model: CasinoStoryContainer) {
        let storyItemsDict = model.itemsModel
        var receivedPaths = Set<String>()
        var urls = [URL]()

        //removing all items to avoid duplicates
        stories.removeAll()
        
        if let storyModels = model.storiesModel {
            storyModels.forEach { story in
                let storyItemStrings = story.storyItems
                var storyItems = [GameStoryItem]()
                let storyLastPath = story.path?.components(separatedBy: "/").last ?? ""
                
                storyItemStrings?.forEach {
                    let (storyItem, storyItemImageURL) = self.gameStoryItem(from: storyItemsDict,
                                                                            for: $0,
                                                                            storyPath: storyLastPath)
                    if let storyItemImageURL { urls.append(storyItemImageURL) }
                    if var storyItem = storyItem {
                        let storyItemLastPath = storyItem.lastPath
                        receivedPaths.insert(storyItem.combinedPath)
                        storyItem.swipeUpContent.forEach { swipeUpPath in
                            let (swipeUpItem, swipeUpItemImageURL) = self.gameStoryItem(from: storyItemsDict,
                                                                                        for: swipeUpPath,
                                                                                        storyPath: storyItemLastPath)
                            if let swipeUpItemImageURL { urls.append(swipeUpItemImageURL) }
                            if let swipeUpItem {
                                storyItem.swipeUpContentItems.append(swipeUpItem)
                                receivedPaths.insert(swipeUpItem.combinedPath)
                            }
                        }
                        storyItems.append(storyItem)
                    }
                }
                
                if !storyItems.isEmpty {
                    if let urlString = story.image?.absoluteString,
                       let url = URL(string: urlString) {
                        urls.append(url)
                    }
                    let gameStory = GameStory(
                        path: story.path ?? "",
                        name: story.title ?? "",
                        imageURL: story.image?.absoluteString ?? "",
                        storyItems: storyItems
                    )
                    stories.append(gameStory)
                    receivedPaths.insert(gameStory.combinedPath)
                }
            }
            // Prefetch images and cache them before you display them on the screen.
            let prefetcher = ImagePrefetcher(urls: urls) {
                skippedResources, failedResources, completedResources in
                ETLogger.log("These resources are prefetched: \(completedResources)")
            }
            prefetcher.start()
        }
        var gameStoryItem = GameStoryItem()
        gameStoryItem.isOnboard = true
        let content = POSAPI.shared?.casinoStoriesContent
        let gameStory = GameStory(
            path: "onboarding_path",
            name: content?.storyTitle ?? "",
            imageURL: "",
            storyItems: [gameStoryItem],
            isOnboard: true
        )
        onboardingStories.append(gameStory)
        self.removeSavedStoriesIfNotContains(in: Array(receivedPaths))
        self.clipShape = GameClipShape(rawValue: model.storyIconType ?? "")
        self.addOnboardingStory()
        self.reOrderStories()
    }

    private func gameStoryItem(from models: [String: CasinoStoryItemModel]?,
                               for itemPath: String,
                               storyPath: String) -> (GameStoryItem?, URL?) {
        if let itemModel = models?[itemPath] {
            let itemExpiryTime = itemModel.expirytime?.storyItemDate ?? Date()
            if itemExpiryTime < Date() { return (nil, nil) }
            return (
                GameStoryItem(item: itemModel,
                              path: itemPath,
                              storyPath: storyPath),
                itemModel.backgroundimage
            )
        }
        return (nil, nil)
    }
    
    //MARK: Helper
    var currentStory: GameStory? {
        guard let selectedStoryIndex else { return nil }
        return self.stories[selectedStoryIndex]
    }
    
    //MARK: - Actions
    func updateSelectedStoryIndex(_ index: Int) {
        selectedStoryIndex = index
        if self.openedLobbyStory {
            ///if we mark visited for first item, it's loading from next index, for that reason we are storing this variable
            self.openedLobbyStory = false
            return
        }
        self.markVisitedForFirstItemOfStory(at: index)
    }
    
    //MARK: - Lobby action
    ///when tap on story in lobby page
    func openStory(of index: Int) {
        self.openedLobbyStory = true
        self.updateSelectedStoryIndex(index)
        
        self.itemViewModels.removeAll()
        var viewModels = [GameStoryItemViewModel]()
        
        self.stories.forEach { story in
            let itemViewModel = GameStoryItemViewModel(
                viewModel: self,
                story: story
            )
            viewModels.append(itemViewModel)
        }
        self.itemViewModels = viewModels
    }
    
    //MARK: - Mark first Item as Visited
    private func markVisitedForFirstItemOfStory(at index: Int) {
        guard index > -1 && index < stories.count else { return }
        let story = self.stories[index]
        story.storyItems.first?.markVisited()
    }
    
    //MARK: - Mark story as Visited
    func markStoryAsReadOnclose() {
        let allStories = self.stories
        allStories.forEach { story in
            if !story.isVisited {
                if let _ = story.storyItems.first(where: { !$0.isVisited }) { } // some items are not visited
                else {
                    //all items are visited
                    story.markVisited()
                }
            }
        }
        self.stories = allStories
    }
    
    // MARK: Reordering stories
    func reOrderStories() {
        self.removeOnboardingStory()
        var unReadStories = stories.filter({ !$0.isVisited })
        unReadStories.append(contentsOf: stories.filter({ $0.isVisited }))
        self.stories = unReadStories
        self.replaceOnboardingStoryIfPresent()
        objectWillChange.send()
    }
    
    ///Remove local saved
    func removeSavedStoriesIfNotContains(in paths: [String]) {
        guard !paths.isEmpty else { return }
        let savedPaths = GameStory.gameStoriesPaths
        let expiredPaths = savedPaths.filter({ !paths.contains($0) })
        expiredPaths.forEach({ path in
            RemoveGameStory(path, storyPath: "").removeIfSavedBeforeTimeFrameLimit()
        })
    }
}

extension GameStoriesViewModel {
    func updateStoriesOnClose() {
        ///Adding onboarding story if stories has opened, before onboarding data received
        addOnboardingStory()
        markStoryAsReadOnclose()
        reOrderStories()
        itemViewModels.removeAll()
    }
}
