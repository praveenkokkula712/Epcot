//
//  GameStoryItemViewModel+Onboarding.swift
//  CasinoAPI
//
//  Created by Yemireddi Sateesh on 06/12/23.
//

import CasinoAPI

struct OnboardingGameStoryItem {
    private(set) var logoUrl: URL?
    private(set) var welcomeTitle: String
    private(set) var welcomeMessage: String
    private(set) var swipeLeftUrl: URL?
    private(set) var swipeLeftHint: String
    private(set) var touchHoldUrl: URL?
    private(set) var touchHoldHint: String
    private(set) var swipeRightUrl: URL?
    private(set) var swipeRightHint: String

    init() {
        let model = POSAPI.shared?.casinoStoriesContent
        logoUrl = URL(string: model?.logoUrl ?? "")
        welcomeTitle = try model?.welcomeTitle ?? ""
        welcomeMessage = try model?.welcomeMessage ?? ""
        swipeLeftUrl = URL(string: model?.swipeLeftUrl ?? "")
        swipeLeftHint = model?.swipeLeftHint ?? ""
        touchHoldUrl = URL(string: model?.swipeLeftUrl ?? "")
        touchHoldHint = model?.touchHoldHint ?? ""
        swipeRightUrl = URL(string: model?.swipeRightUrl ?? "")
        swipeRightHint = model?.swipeRightHint ?? ""
    }
}
