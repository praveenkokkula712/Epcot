//
//  StorySave.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 11/05/23.
//

import Foundation

protocol SaveGameStory {
    var path: String { get set }
    var storyPath: String { get set }
}

extension SaveGameStory {
    static var gameStoriesPaths: [String] {
        UserDefaults.standard.stringArray(forKey: kGameStoriesPaths) ?? []
    }
}

extension SaveGameStory {
    var lastPath: String {
        path.components(separatedBy: "/").last ?? ""
    }
    
    //only for StoryItems not for stories
    var combinedPath: String {
        if storyPath.isEmpty {
            return lastPath
        }
        return storyPath+"_"+lastPath
    }
    
    var savedPathData: [String: Any]? {
        guard !lastPath.isEmpty else { return nil }
        return UserDefaults.standard.dictionary(forKey: combinedPath)
    }
    
    var isVisited: Bool {
        return savedPathData?[kGameStoryVisited] as? Bool ?? false
    }
    
    func markVisited() {
        if !lastPath.isEmpty, !isVisited {
            let dict: [String : Any] = [kGameStoryVisited: true, kGameStoryTime: Date()]
            UserDefaults.standard.set(dict, forKey: combinedPath)
            self.updateGameStoriesPaths()
            if let onboardingStory = self as? OnboardingGameStory {
                onboardingStory.markOnboardingItemVisited()
            }
        }
    }
    
    func updateGameStoriesPaths() {
        var paths = Set().union(Self.gameStoriesPaths)
        paths.insert(combinedPath)
        guard !paths.isEmpty else { return }
        UserDefaults.standard.set(Array(paths), forKey: kGameStoriesPaths)
    }
}

struct RemoveGameStory: SaveGameStory {
    var path: String
    var storyPath: String
    private var css: GameStoriesCSS? {
        EpcotLobbyManager.shared?.css.gameStoriesCSS
    }

    init (_ path: String, storyPath: String) {
        self.path = path
        self.storyPath = storyPath
    }
    
    func removeIfSavedBeforeTimeFrameLimit() {
        if let savedTime = savedPathData?[kGameStoryTime] as? Date {
            let days = Calendar.current.dateComponents([.day], from: savedTime, to: Date()).day ?? 0
            let daysToHoldSavedData = css?.daysToHoldSavedData ?? 0
            if daysToHoldSavedData > 0,
               days >= daysToHoldSavedData {
                UserDefaults.standard.removeObject(forKey: combinedPath)
            }
        }
    }
    
}
