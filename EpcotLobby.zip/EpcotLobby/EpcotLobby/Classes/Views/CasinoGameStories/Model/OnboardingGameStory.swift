//
//  OnboardingGameStory.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 30/05/23.
//

protocol OnboardingGameStory {
    var isOnboarding: Bool { get }
}

extension OnboardingGameStory {
    
    func markOnboardingItemVisited() {
        if isOnboarding,
           let journey = UserOnboardingViewModel.shared?.journey(with: .casinoStories),
           !journey.isVisited {
            journey.markVisited()
        }
    }
    
}
