//
//  GameStoryItem+Onboarding.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 25/05/23.
//

extension GameStoryItem {
    static var onboardingType = "Onboarding"

    var isOnboarding: Bool {
        self.type == Self.onboardingType
    }
}

enum OnboardingStoryItemHintType: CaseIterable {
    case swipeLeft
    case touchHold
    case swipeRight
}
