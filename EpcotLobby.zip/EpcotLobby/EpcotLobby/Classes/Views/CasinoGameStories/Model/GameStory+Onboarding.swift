//
//  GameStory+Onboarding.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 25/05/23.
//

extension GameStory: OnboardingGameStory {
    var isOnboarding: Bool {
        self.storyItems.first?.isOnboarding ?? false
    }
}
