//
//  GameStory.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 13/04/23.
//

import Foundation

struct GameStory: Identifiable, Hashable, Equatable, SaveGameStory {
    var id = UUID()
    var path: String = ""
    var storyPath: String = ""
    var name: String = ""
    var imageURL: String = ""
    var storyItems: [GameStoryItem] = []
    var isOnboard = false
}

extension GameStory {
    var isOpted: Bool {
        guard let _ = storyItems.first(where: { $0.isOpted }) else { return false }
        return true
    }
}

extension GameStory {
    static var list: [GameStory] {
        return [
            GameStory(
                name: "Mustang Gold",
                imageURL: "mustang-gold",
                storyItems: GameStoryItem.list
            ),
            GameStory(
                name: "Pirate Gold",
                imageURL: "pirate-gold",
                storyItems: GameStoryItem.list
            ),
            GameStory(
                name: "Tree of Riches",
                imageURL: "tree-of-riches",
                storyItems: GameStoryItem.list
            ),
            GameStory(
                name: "Dwarven Gold",
                imageURL: "dwarven-gold",
                storyItems: GameStoryItem.list
            ),
            GameStory(
                name: "Caishen's Cash",
                imageURL: "caishens-cash",
                storyItems: GameStoryItem.list
            )
        ]
    }
}
