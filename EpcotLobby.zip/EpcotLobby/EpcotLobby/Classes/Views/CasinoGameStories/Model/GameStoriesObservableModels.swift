//
//  GameStoriesObservableModels.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 10/05/23.
//

import Foundation

class DraggingOffset: ObservableObject {
    static var screenHeight: CGFloat { UIDevice.screenSize.height }
    @Published var startingY: CGFloat = DraggingOffset.screenHeight
    @Published var currentY: CGFloat = 0
    @Published var endingY: CGFloat = 0
    
    func reset() {
        self.currentY = 0
        self.endingY = 0
        self.startingY = DraggingOffset.screenHeight
    }
    
    func updatePosition() {
        self.currentY = 0
        self.endingY = -DraggingOffset.screenHeight
        self.startingY = DraggingOffset.screenHeight
    }
    
    func updateValuesOnOrientationChanged() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            if self.endingY != 0 {
                self.updatePosition()
            } else {
                self.reset()
            }
        }
    }
}

class SelectedGameStoryItem: ObservableObject {
    @Published var index: Int = 0
    @Published var savedProgress = 0.0
}
