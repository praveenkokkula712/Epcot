//
//  GameStoryItem.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 25/04/23.
//

import Foundation
import CasinoAPI

struct GameStoryItem: Identifiable, Hashable, SaveGameStory {
    var id = UUID()
    var path: String
    var storyPath: String
    var type: String
    var itemInterval: Int
    var title: String
    var subTitle: String
    var paragraph: String
    var imageURL: URL?
    var cta: String
    var actionType: String
    var showTerms: Bool
    var terms: String
    var showOptIn: Bool
    var optInText: String
    var optedInText: String
    var expiryTime: Date
    var enableSwipeUp: Bool
    var swipeUpContent: [String]
    var swipeUpContentItems: [GameStoryItem]
    var isOnboard = false
    
    init(item: CasinoStoryItemModel = CasinoStoryItemModel.itemModel,
         path: String = "",
         storyPath: String = "") {
        self.id = UUID()
        self.path = path
        self.storyPath = storyPath
        self.type = item.storytype ?? ""
        self.itemInterval = item.storyiteminterval ?? 0
        self.title = item.title ?? ""
        self.subTitle = item.subtitle ?? ""
        self.paragraph = item.description ?? ""
        self.imageURL = item.backgroundimage
        self.cta = item.customcta ?? ""
        self.actionType = item.storyitemactiontype ?? ""
        self.showTerms = item.showtnc ?? 0 == 1
        self.terms = item.tnccontent ?? ""
        self.showOptIn = item.showoptin ?? 0 == 1
        self.optInText = item.optinctatext ?? ""
        self.optedInText = item.optedinctatext ?? ""
        self.expiryTime = item.expirytime?.storyItemDate ?? Date()
        self.enableSwipeUp = item.enableswipeup ?? 0 == 1
        self.swipeUpContent = item.swipeupstoryitemcontent ?? []
        self.swipeUpContentItems = []
        
        if self.lastPath.lowercased().contains(Self.onboardingType.lowercased()) {
            self.type = Self.onboardingType
        }
    }
}

extension GameStoryItem {
    var isOpted: Bool {
        return savedPathData?[kGameStoryOpted] as? Bool ?? false
    }
    func markOpted() {
        if !lastPath.isEmpty, !isOpted {
            let dict: [String : Any] = [
                kGameStoryVisited: true,
                kGameStoryOpted: true,
                kGameStoryTime: Date()
            ]
            UserDefaults.standard.set(dict, forKey: combinedPath)
        }
    }
}

extension GameStoryItem {
    static var list: [GameStoryItem] {
        return [
            GameStoryItem()
        ]
    }
}
