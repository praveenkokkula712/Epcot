//
//  CasinoStories+EventsTracker.swift
//  EpcotLobby
//
//  Created by Santhosh Kodadi on 08/06/23.
//

import TrackerClient
import Utility

extension EpcotLobbyViewController {
    func trackEvent(eventAction: String,
                    eventLable: String,
                    eventLocation: String,
                    eventDetails: String,
                    eventPosition: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.casino_stories.rawValue,
                                     actionEvent:eventAction,
                                     labelEvent: eventLable,
                                     locationEvent: eventLocation,
                                     eventDetails: eventDetails,
                                     positionEvent: eventPosition)
            let event = TrackerEvent(type: EventType.casino_stories, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}
