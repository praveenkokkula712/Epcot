//
//  EpcotLobby+GameStoriesView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 14/04/23.
//

import UIKit
import SwiftUI
import Utility

extension EpcotLobbyViewController {
    func setupGameStoriesView(viewModel: GameStoriesViewModel) {
        let css = EpcotLobbyManager.shared?.css.gameStoriesCSS
        let gameStoriesCSS = GameStoriesViewCSS(css: css)
        let gameStoriesView = GameStoriesView(
            viewModel: viewModel,
            styles: gameStoriesCSS
        ) { [weak self] storyRect in
            guard let self else { return }
            self.gameStoryViewFrame = storyRect
            self.presentGameStoryItemView(viewModel: viewModel)
            viewModel.isGameStoriesPresented = true
        }
        let gameStoriesViewController = UIHostingController(rootView: gameStoriesView)
        if let gameStoriesView = gameStoriesViewController.view {
            gameStoriesView.accessibilityIdentifier = CasinoStoriesAccessibilityIdentifiers().gameStoriesView
            gameStoriesView.backgroundColor = .clear
            gameStoriesContainerView.addSubview(gameStoriesView)
            gameStoriesView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                gameStoriesView.leadingAnchor.constraint(
                    equalTo: gameStoriesContainerView.leadingAnchor
                ),
                gameStoriesView.trailingAnchor.constraint(
                    equalTo: gameStoriesContainerView.trailingAnchor
                ),
                gameStoriesView.topAnchor.constraint(
                    equalTo: gameStoriesContainerView.topAnchor, constant: 8.0
                ),
                gameStoriesView.bottomAnchor.constraint(
                    equalTo: gameStoriesContainerView.bottomAnchor, constant: -8.0
                )
            ])
            self.view.bringSubviewToFront(gameStoriesContainerView)
            gameStoriesContainerView.isHidden = true
        }
    }

    func fetchGameStoriesContent() {
        guard !gameStoriesViewModel.isGameStoriesPresented else { return }
        Task {
            let result = try await gameStoriesViewModel.fetchGameStoriesContent()
            switch result {
            case .failure(let error):
                ETLogger.debug("Failed Service \(error.localizedDescription)")
            case .success(let container):
                let clipShape = GameClipShape(rawValue: container.storyIconType ?? "")
                let height = clipShape.gameStoriesViewHeight
                DispatchQueue.main.async {
                    self.gameStoriesContainerViewHeight.constant = height
                    UIView.animate(withDuration: 0.25) {
                        self.view.layoutIfNeeded()
                        self.gameStoriesContainerView.isHidden = false
                    }
                }
            }
        }
    }
}
