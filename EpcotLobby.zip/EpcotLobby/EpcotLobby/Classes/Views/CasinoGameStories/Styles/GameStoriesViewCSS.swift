//
//  GameStoriesViewCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 13/04/23.
//

import SwiftUI

struct GameStoriesViewCSS {
    var selectedColor: Color
    var unselectedColor: Color
    var selectedTextColor: Color
    var unselectedTextColor: Color
    var unselectedViewAlpha: Double
    var lineWidth: CGFloat
    var cornerRadius: CGFloat
    var textFont: Font
    var textColor: Color
    var headerTitleFont: Font
    var headerTitleColor: Color

    init(css: GameStoriesCSS? = nil) {
        selectedColor = Color(css?.selectedColor ?? Self.defaultSelectedColor)
        unselectedColor = Color(css?.unselectedColor ?? Self.defaultUnselectedColor)
        selectedTextColor = Color(css?.selectedTextColor ?? Self.defaultSelectedTextColor)
        unselectedTextColor = Color(css?.unselectedTextColor ?? Self.defaultUnselectedTextColor)
        unselectedViewAlpha = css?.unselectedViewAlpha ?? Self.defaultUnselectedViewAlpha
        lineWidth = css?.lineWidth ?? Self.defaultLineWidth
        cornerRadius = css?.cornerRadius ?? Self.defaultCornerRadius
        textFont = Font(css?.title?.font ?? .systemFont(ofSize: 10)) ?? Self.defaultTextFont
        textColor = Color(css?.title?.color ?? Self.defaultSelectedTextColor)
        headerTitleFont = Font(css?.headerTitle?.font ?? .systemFont(ofSize: 10)) ?? Self.defaultHeaderTitleFont
        headerTitleColor = Color(css?.headerTitle?.color ?? Self.defaultHeaderTitleColor)
    }
}

// MARK: - Default Styles
extension GameStoriesViewCSS {
    private static let defaultSelectedColor: UIColor = .init(
        red: 1, green: 0.8, blue: 0, alpha: 1.0
    ) // #FFCC00
    private static let defaultUnselectedColor: UIColor = .init(
        red: 0.2, green: 0.2, blue: 0.2, alpha: 0.8
    ) // #333333 0.8
    private static let defaultSelectedTextColor: UIColor = .white
    private static let defaultUnselectedTextColor: UIColor = .init(
        red: 0.6, green: 0.6, blue: 0.6, alpha: 1.0
    ) // #999999
    private static let defaultUnselectedViewAlpha: Double = 0.7
    private static let defaultLineWidth: Double = 2
    private static let defaultCornerRadius: Double = 16
    private static let defaultTextFont: Font = .system(size: 10)
    private static let defaultHeaderTitleColor: UIColor = .white
    private static let defaultHeaderTitleFont = Font.system(size: 16, weight: .bold)
}
