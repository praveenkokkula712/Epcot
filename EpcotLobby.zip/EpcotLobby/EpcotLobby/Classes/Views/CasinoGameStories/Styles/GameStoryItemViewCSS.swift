//
//  GameStoryItemViewCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 25/04/23.
//

import Foundation
import SwiftUI

struct GameStoryItemViewCSS {
    var backgroundColor: Color
    var progressBarColor: Color
    var progressFillColor: Color
    var closeButtonColor: Color
    var titleColor: Color
    var titleFont: Font
    var subTitleColor: Color
    var subTitleFont: Font
    var paragraphColor: Color
    var paragraphFont: Font
    var ctaButtonColor: Color
    var ctaButtonBackgroundColor: Color
    var ctaButtonFont: Font
    var ctaButtonHighlightColor: Color
    var ctaButtonCornerRadius: Double
    var legalTermsColor: Color
    var legalTermsFont: Font
    var legalTermsBackgroundColor: Color
    var seeMoreHandleColor: Color
    var seeMoreButtonColor: Color
    var seeMoreButtonFont: Font
    var scrollButtonBackgroundColor: Color
    var scrollButtonColor: Color
    var closeOffset: Double

    ///for Onboarding
    var touchHandBackgroundColor: Color
    var touchTitleColor: Color
    var touchTitleFont: Font
    var logoColor: Color
    var logoBorderWidth: CGFloat
    var logoBorderColor: Color
    var logoRingColor: Color
    var logoRingWidth: CGFloat
    var logoHairlineColor: Color
    var rippleColor: Color

    init(css: GameStoryItemsCSS? = nil) {
        backgroundColor = Color(css?.backgroundColor ?? Self.backgroundColorDefault)
        progressBarColor = Color(css?.progressBarColor ?? Self.progressBarColorDefault)
        progressFillColor = Color(css?.progressFillColor ?? Self.progressFillColorDefault)
        closeButtonColor = Color(css?.closeButtonColor ?? Self.closeButtonColorDefault)
        titleColor = Color(css?.title?.color ?? Self.titleColorDefault)
        titleFont = Font(css?.title?.font ?? .systemFont(ofSize: 28, weight: .bold)) ?? Self.titleFontDefault
        subTitleColor = Color(css?.subTitle?.color ?? Self.subTitleColorDefault)
        subTitleFont = Font(css?.subTitle?.font ?? .systemFont(ofSize: 28, weight: .bold)) ?? Self.subTitleFontDefault
        paragraphColor = Color(css?.paragraph?.color ?? Self.paragraphColorDefault)
        paragraphFont = Font(css?.paragraph?.font ?? .systemFont(ofSize: 16)) ?? Self.paragraphFontDefault
        ctaButtonColor = Color(css?.ctaButton?.color ?? Self.ctaButtonColorDefault)
        ctaButtonBackgroundColor = Color(css?.ctaButtonBackgroundColor ?? Self.ctaButtonBackgroundColorDefault)
        ctaButtonFont = Font(css?.ctaButton?.font ?? .systemFont(ofSize: 14, weight: .bold)) ?? Self.ctaButtonFontDefault
        ctaButtonHighlightColor = Color(css?.ctaButtonHighlightColor ?? Self.ctaButtonHighlightColorDefault)
        ctaButtonCornerRadius = css?.ctaButtonCornerRadius ?? Self.ctaButtonCornerRadiusDefault
        legalTermsColor = Color(css?.legalTermsText?.color ?? Self.legalTermsColorDefault)
        legalTermsFont = Font(css?.legalTermsText?.font ?? .systemFont(ofSize: 10)) ?? Self.legalTermsFontDefault
        legalTermsBackgroundColor = Color(css?.legalTermsBackgroundColor ?? Self.legalTermsBackgroundColorDefault)
        seeMoreHandleColor = Color(css?.seeMoreHandleColor ?? Self.seeMoreHandleColorDefault)
        seeMoreButtonColor = Color(css?.seeMoreButton?.color ?? Self.seeMoreButtonColorDefault)
        seeMoreButtonFont = Font(css?.seeMoreButton?.font ?? .systemFont(ofSize: 14, weight: .bold)) ?? Self.seeMoreButtonFontDefault
        scrollButtonBackgroundColor = Color(css?.scrollButtonBackgroundColor ?? Self.scrollButtonBackgroundColorDefault)
        scrollButtonColor = Color(css?.scrollButtonColor ?? Self.scrollButtonColorDefault)
        closeOffset = css?.closeOffset ?? Self.defaultCloseOffset

        ///for Onboarding
        touchHandBackgroundColor = Color(css?.touchHandBackgroundColor ?? Self.touchHandBackgroundColorDefault)
        touchTitleColor = Color(css?.touchTitle?.color ?? Self.touchTitleColorDefault)
        touchTitleFont = Font(css?.touchTitle?.font ?? .systemFont(ofSize: 10)) ?? Self.touchTitleFontDefault
        logoColor = Color(css?.logoColor ?? Self.logoColorDefault)
        logoBorderWidth = css?.logoBorderWidth ?? Self.logoBorderWidthDefault
        logoBorderColor = Color(css?.logoBorderColor ?? Self.logoBorderColorDefault)
        logoRingColor = Color(css?.logoRingColor ?? Self.logoRingColorDefault)
        logoRingWidth = css?.logoRingWidth ?? Self.logoRingWidthDefault
        logoHairlineColor = Color(css?.logoHairlineColor ?? Self.logoHairlineColorDefault)
        rippleColor = Color(css?.rippleColor ?? Self.rippleColorDefault)
    }
}

// MARK: - Default Styles
extension GameStoryItemViewCSS {
    private static let backgroundColorDefault: UIColor = .black
    private static let progressBarColorDefault: UIColor = .init(
        red: 0.2, green: 0.2, blue: 0.2, alpha: 0.8
    ) // #333333 0.8
    private static let progressFillColorDefault: UIColor = .white
    private static let closeButtonColorDefault: UIColor = .white
    private static let titleColorDefault: UIColor = .white
    private static let titleFontDefault: Font = .system(size: 28, weight: .bold)
    private static let subTitleColorDefault: UIColor = .init(
        red: 255, green: 204, blue: 0, alpha: 1
    )
    private static let subTitleFontDefault: Font = .system(size: 28, weight: .bold)
    private static let paragraphColorDefault: UIColor = .white
    private static let paragraphFontDefault: Font = .system(size: 16)
    private static let ctaButtonColorDefault: UIColor = .init(
        red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0
    ) // #333333
    private static let ctaButtonBackgroundColorDefault: UIColor = .init(
        red: 1.0, green: 0.8, blue: 0.0, alpha: 1.0
    ) // #FFCC00
    private static let ctaButtonFontDefault: Font = .system(size: 14, weight: .bold)
    private static let ctaButtonHighlightColorDefault: UIColor = .white
    private static let ctaButtonCornerRadiusDefault = 3.0
    private static let legalTermsColorDefault: UIColor = .init(
        red: 0.6, green: 0.6, blue: 0.6, alpha: 1.0
    ) // #999999
    private static let legalTermsFontDefault: Font = .system(size: 10)
    private static let legalTermsBackgroundColorDefault: UIColor = .init(
        red: 0.098, green: 0.098, blue: 0.098, alpha: 1.0
    ) // #191919
    private static let seeMoreHandleColorDefault: UIColor = .init(
        red: 0.439, green: 0.439, blue: 0.439, alpha: 1.0
    ) // #707070
    private static let seeMoreButtonColorDefault: UIColor = .init(
        red: 0.678, green: 0.678, blue: 0.678, alpha: 1.0
    ) // #ADADAD
    private static let seeMoreButtonFontDefault: Font = .system(size: 14, weight: .bold)
    private static let scrollButtonBackgroundColorDefault: UIColor = .init(
        red: 0.2, green: 0.2, blue: 0.2, alpha: 0.8
    ) // #333333 0.8
    private static let scrollButtonColorDefault: UIColor = .init(
        red: 0.6, green: 0.6, blue: 0.6, alpha: 1.0
    ) // #999999
    private static let defaultCloseOffset: Double = 150.0
}
///Onboaridng
extension GameStoryItemViewCSS {
    private static let touchHandBackgroundColorDefault: UIColor = .black
    private static let touchTitleColorDefault: UIColor = UIColor.hexStringToUIColor(hex: "#EAEAEA")
    private static let touchTitleFontDefault: Font = .system(size: 10)
    private static let logoColorDefault: UIColor = UIColor.hexStringToUIColor(hex: "#000000")
    private static let logoBorderWidthDefault: CGFloat = 2.0
    private static let logoBorderColorDefault: UIColor = UIColor.hexStringToUIColor(hex: "#000000")
    private static let logoRingColorDefault: UIColor = UIColor.hexStringToUIColor(hex: "#FFCC00")
    private static let logoRingWidthDefault: CGFloat = 8.0
    private static let logoHairlineColorDefault: UIColor = UIColor.hexStringToUIColor(hex: "#000000", withAlpha: 0.4)
    private static let rippleColorDefault: UIColor = UIColor.hexStringToUIColor(hex: "#FFCC00")
}
