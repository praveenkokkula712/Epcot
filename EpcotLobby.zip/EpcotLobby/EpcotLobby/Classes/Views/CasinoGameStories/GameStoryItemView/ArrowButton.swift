//
//  ArrowButton.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 27/04/23.
//

import SwiftUI
import Utility

struct ArrowButton: View {

    // MARK: - Properties
    private var isLeft: Bool
    private var enable: Bool
    private var action: () -> Void
    private var styles: GameStoryItemViewCSS
    private let accessibilityIdentifiers = CasinoStoriesAccessibilityIdentifiers()

    // MARK: - Init
    init(isLeft: Bool = true,
         enable: Bool = true,
         styles: GameStoryItemViewCSS,
         action: @escaping () -> Void) {
        self.isLeft = isLeft
        self.enable = enable
        self.styles = styles
        self.action = action
    }

    // MARK: - UI Content
    var body: some View {
        HStack(spacing: 0) {
            if !isLeft { Text("").padding(.leading, 40) }
            else { Spacer() }

            Button {
                withAnimation {
                    action()
                }
            } label: {
                Circle()
                    .fill(styles.scrollButtonBackgroundColor)
                    .frame(width: 40)
                    .overlay(
                        arrowImage(left: isLeft)
                            .foregroundColor(styles.scrollButtonColor)
                            .frame(height: 12)
                    )
            }
            .accessibilityIdentifier(arrowButtonIdentifier)

            if isLeft {  Text("").padding(.trailing, 40) }
            else { Spacer() }
        }
        .opacity(enable ? 1.0 : 0.4)
        .disabled(!enable)
    }
    
    @ViewBuilder
    private func arrowImage(left: Bool) -> some View {
        let icon = left ? leftArrowIcon : rightArrowIcon
        if let image = UIImage(
            named: icon,
            in: kEpcotBundle,
            compatibleWith: nil
        ) {
            Image(uiImage: image)
        }
        EmptyView()
    }
}

// MARK: - Accessibility Identifier
extension ArrowButton {
    
    private var arrowButtonIdentifier : String {
        accessibilityIdentifiers.arrowButton
    }
}

struct ArrowButton_Previews: PreviewProvider {
    static var previews: some View {
        HStack {
            ArrowButton(styles: GameStoryItemViewCSS()) {}
            ArrowButton(isLeft: false, styles: GameStoryItemViewCSS()) {}
        }
    }
}
