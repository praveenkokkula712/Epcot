//
//  GameStoryItemsView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 26/04/23.
//

import SwiftUI

struct GameStoryItemsView: View {
    
    // MARK: - Properties
    @ObservedObject var viewModel = GameStoriesViewModel()
    @State private(set) var selectedIndex = 0
    @State private(set) var selectedGameStoryItem = SelectedGameStoryItem()
    @ObservedObject private var draggingOffset = DraggingOffset()
    @State private var previousIndex = 0
    @State private var progressViewPauseState: (Int, Bool) = (-1, false)
    private var styles: GameStoryItemViewCSS
    private var onCloseButtonTap: () -> Void
    @State private var storyItemViewModels = [GameStoryItemViewModel]()
    @State private var progressViewModels = [GameStoryItemProgress]()
    @State private var isAppInForeground = true
    
    // MARK: - Init
    init(
        viewModel: GameStoriesViewModel,
        styles: GameStoryItemViewCSS,
        onCloseButtonTap: @escaping () -> Void
    ) {
        self.viewModel = viewModel
        self.styles = styles
        self.onCloseButtonTap = onCloseButtonTap
    }
    
    // MARK: - UI Content
    var body: some View {
        ZStack {
            styles.backgroundColor
                .edgesIgnoringSafeArea(.all)

            ZStack {
                HStack(spacing: 0) {
                    // Left Button
                    if isIPad {
                        let enable = selectedIndex > 0
                        ArrowButton(enable: enable, styles: styles) {
                            if enable { selectedIndex -= 1 }
                        }
                    }
                    
                    // Game Story Items
                    if !storyItemViewModels.isEmpty && !progressViewModels.isEmpty {
                        TabView(selection: $selectedIndex) {
                            ForEach(0..<viewModel.itemViewModels.count, id: \.self) { index in
                                GameStoryItemView(
                                    viewModel: storyItemViewModels[index],
                                    progressViewModel: progressViewModels[index],
                                    styles: styles,
                                    isActive: index == selectedIndex
                                )
                                .tag(index)
                                .environmentObject(draggingOffset)
                                .environmentObject(selectedGameStoryItem)
                            }
                        }
                        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                        .frame(width: tabViewWidth)
                    }
                    
                    // Right Button
                    if isIPad {
                        let enable = selectedIndex < viewModel.stories.count - 1
                        ArrowButton(isLeft: false, enable: enable, styles: styles) {
                            if enable {
                                selectedIndex += 1
                            }
                        }
                    }
                }
            }
            .opacity(isAppInForeground ? 1.0 : 0.0)
            .offset(y: draggingOffset.endingY)
            .offset(y: draggingOffset.currentY)
            .offset(y: DraggingOffset.screenHeight - draggingOffset.startingY)
            
            let swipeUpItemViewModel = GameStoryItemViewModel(
                story: viewModel.stories[selectedIndex],
                isSwipeUp: true,
                onCloseButtonTap: {
                    ///moving the swipe up content to bottom
                    withAnimation (.spring()) {
                        draggingOffset.reset()
                        viewModel.isSeeMoreViewIsShowing = false
                    }
                    self.trackEvent(for:.close, isSwipeUp: true)
                },
                onCTAButtonTap: { ctaLink in
                    self.trackEvent(for:.cta,
                                    isSwipeUp: true,
                                    ctaButton: ctaLink)
                    self.open(ctaLink: ctaLink)
                },
                onOptInButtonTap: { storyViewModel in
                    self.trackEvent(for:.optIn, isSwipeUp: true)
                    storyViewModel.item.markOpted()
                }
            )
            GameStoryItemView (
                viewModel: swipeUpItemViewModel,
                progressViewModel: GameStoryItemProgress(viewModel: swipeUpItemViewModel),
                styles: styles,
                isActive: false
            )
            .opacity(isAppInForeground ? 1.0 : 0.0)
            .frame(width: tabViewWidth,
                   height: UIDevice.screenSize.height)
            .offset(y: draggingOffset.startingY)
            .offset(y: draggingOffset.currentY)
            .offset(y: draggingOffset.endingY)
            .environmentObject(selectedGameStoryItem)
            .onChange(of: draggingOffset.endingY) { newValue in
                if newValue != 0 {
                    self.trackEvent(for: .swipeUp)
                }
            }
            .onChange(of: draggingOffset.currentY) { newValue in
                if newValue == 0 && draggingOffset.endingY == 0 {
                    self.viewModel.isSeeMoreViewIsShowing = false
                    self.progressViewModels[selectedIndex].resumeCurrentProgress()
                } else {
                    self.progressViewModels[selectedIndex].pauseCurrentProgress()
                    self.viewModel.isSeeMoreViewIsShowing = true
                    if draggingOffset.currentY == 1 {
                        /// check description in 'GameStoryItemSeeMoreView' for code 'draggingOffset.currentY = 1'
                        draggingOffset.currentY = 0
                    }
                }
            }
        }
        .onAppear {
            self.createViewModels()
            self.selectedIndex = viewModel.selectedStoryIndex ?? 0
            self.trackEvent(for: .load)
        }
        .onForeground {
            isAppInForeground = true
            adjustDragOffsetOnAppCycle()
            selectedIndex = viewModel.selectedStoryIndex ?? 0
            progressViewModels[selectedIndex].resumeCurrentProgress()
        }
        .onGoingBackground {
            isAppInForeground = false
            selectedIndex = viewModel.selectedStoryIndex ?? 0
            progressViewModels[selectedIndex].pauseCurrentProgress()
        }
        .onBackground {
            adjustDragOffsetOnAppCycle()
        }
        .onChange(of: selectedIndex, perform: { newValue in
            viewModel.updateSelectedStoryIndex(selectedIndex)
            //swipe
            self.trackEvent(for: self.previousIndex > newValue ? .swipeLeft : .swipeRight)
            self.previousIndex = selectedIndex
        })
        .onReceive(
            NotificationCenter.default.publisher(
                for: UIDevice.orientationDidChangeNotification
            )
        ) { _ in
            self.progressViewPauseState = (selectedGameStoryItem.index, true)
            self.draggingOffset.updateValuesOnOrientationChanged()
            self.progressViewPauseState = (selectedGameStoryItem.index, false)
        }
        .edgesIgnoringSafeArea(.all)
    }
    
    private func adjustDragOffsetOnAppCycle() {
        if draggingOffset.endingY == 0 {
            draggingOffset.reset()
        } else {
            draggingOffset.updatePosition()
        }
    }
    
    private func createViewModels() {
        for itemViewModel in viewModel.itemViewModels {
            let storyItemViewModel = itemViewModel.actions(
                onCloseButtonTap: {
                    self.trackEvent(for: .close)
                    onCloseButtonTap()
                }, onCTAButtonTap: { ctaLink in
                    ///more info
                    self.trackEvent(for: .cta,
                                    ctaButton: ctaLink)
                    self.open(ctaLink: ctaLink)
                }, onOptInButtonTap: { storyViewModel in
                    self.trackEvent(for: .optIn)
                    storyViewModel.item.markOpted()
                }, moveToNextGameStory: moveToNextGameStory,
                moveToPreviousGameStory: moveToPreviousGameStory,
                updateCurrentGameStory: { currentItemViewModel in
                    self.updateCurrentIndex(itemViewModel: currentItemViewModel)
                }
            )
            storyItemViewModels.append(storyItemViewModel)
            
            let progressViewModel = GameStoryItemProgress(
                viewModel: storyItemViewModel,
                changeProgress: progressViewPauseState
            )
            progressViewModels.append(progressViewModel)
        }
    }

    // MARK: - Helper
    private var tabViewWidth: CGFloat {
        let orientationFactor = UIDevice.currentOrientation == .portrait ? 0.6 : 0.4
        return UIDevice.screenSize.width * (isIPad ? orientationFactor : 1.0)
    }

    private var isIPad: Bool {
        UIDevice.isIPad()
    }
    
    private func moveToNextGameStory() {
        if selectedIndex < viewModel.stories.count - 1 {
            withAnimation() {
                selectedIndex += 1
            }
        }
    }
    
    private func moveToPreviousGameStory() {
        if selectedIndex > 0 {
            withAnimation() {
                selectedIndex -= 1
            }
        }
    }
    
    /// if we opened any story other than index '0' from lobby and double tap only on left 'TabView' should go to 0 index, but it's not moving, as we are updating the index with animation
    /// so validating the Id and updating the index
    /// where as right tap is working fine
    func updateCurrentIndex(itemViewModel: GameStoryItemViewModel) {
        if let itemViewModelIndex = self.storyItemViewModels.firstIndex(where: { $0.id == itemViewModel.id }) {
            if self.selectedIndex != itemViewModelIndex {
                let selIndex = self.selectedIndex
                self.selectedIndex = itemViewModelIndex
                withAnimation {
                    self.selectedIndex = selIndex
                }
            }
        }
    }
    
    ///CTA button Action
    private func open(ctaLink: String) {
        EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .gameStoryItem(ctaLink),
                                                            buttonType: nil)
        onCloseButtonTap()
    }
    
}

struct GameStoryItemsView_Previews: PreviewProvider {
    static var previews: some View {
        GameStoryItemsView(
            viewModel: GameStoriesViewModel(),
            styles: GameStoryItemViewCSS()
        ) { }
    }
}
