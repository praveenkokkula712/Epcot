//
//  GameStoryItemSeeMoreView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 04/05/23.
//

import SwiftUI
import Utility

struct GameStoryItemSeeMoreView: View {
    @EnvironmentObject var draggingOffset: DraggingOffset
    private var styles: GameStoryItemViewCSS
    @State private var seeMoreButtonInteracted = 0.0
    private let accessibilityIdentifiers = CasinoStoriesAccessibilityIdentifiers()

    init(styles: GameStoryItemViewCSS) {
        self.styles = styles
    }
    
    var body: some View {
        HStack (alignment: .center) {
            Spacer()
            Button {
                withAnimation (instantInteractionAnimation) {
                    seeMoreButtonInteracted = 1
                }
            } label: {
                VStack(alignment: .center, spacing: 0) {
                    if let image = UIImage(
                        named: kUpArrowIcon,
                        in: kEpcotBundle,
                        compatibleWith: nil
                    ) {
                        Image(uiImage: image)
                            .renderingMode(.template)
                            .foregroundColor(styles.seeMoreHandleColor)
                    }
                    let title = Localize.see_more.isEmpty ? "SEE MORE" : Localize.see_more
                    Text(title)
                        .padding(.top, 8)
                        .foregroundColor(styles.seeMoreButtonColor)
                        .font(styles.seeMoreButtonFont)
                        .background(
                            seeMoreButtonInteracted == 0 ? Color.clear : Color.overlay40Color
                        )
                        .accessibilityIdentifier(seeMoreTextIdentifier)
                }
            }
            .accessibilityIdentifier(seeMoreButtonIdentifier)
            //triggers when see more tap occured
            .onAnimationCompleted(for: seeMoreButtonInteracted) {
                seeMoreButtonInteracted = 0
                withAnimation (.spring()) {
                    draggingOffset.endingY = -DraggingOffset.screenHeight
                    /// draggingOffset.currentY should be '0', but it's not triggering the change observer/receiver in 'GameStoryItemsView'
                    draggingOffset.currentY = 1
                }
            }
            Spacer()
        }
    }
}

// MARK: - Accessibility Identifiers
extension GameStoryItemSeeMoreView {
    
    private var seeMoreButtonIdentifier : String {
        accessibilityIdentifiers.seeMoreButton
    }
    private var seeMoreTextIdentifier : String {
        accessibilityIdentifiers.seeMoreText
    }
}

struct GameStoryItemSeeMoreView_Previews: PreviewProvider {
    static var previews: some View {
        GameStoryItemSeeMoreView(styles: GameStoryItemViewCSS())
    }
}
