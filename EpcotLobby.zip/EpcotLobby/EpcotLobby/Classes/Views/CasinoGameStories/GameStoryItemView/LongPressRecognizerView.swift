//
//  LongPressRecognizerView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 14/05/23.
//

import SwiftUI

struct LongPressRecognizerView: View {
    @GestureState private var isTouching = false
    @Binding private var dragOffset: CGSize
    @Binding private var dragOffsetEnd: Bool
    private var backgroundColor: Color
    private var onTap: () -> Void
    private var onLongPress: (Bool) -> Void

    init(
        backgroundColor: Color = .white.opacity(0.00001),
        onTap: @escaping () -> Void,
        onLongPress: @escaping (Bool) -> Void,
        dragOffset: Binding<CGSize>,
        dragOffsetEnd: Binding<Bool>
    ) {
        self.backgroundColor = backgroundColor
        self.onTap = onTap
        self.onLongPress = onLongPress
        _dragOffset = dragOffset
        _dragOffsetEnd = dragOffsetEnd
    }

    var body: some View {
        VStack { Spacer() }
            .frame(minWidth: 0, maxWidth: .infinity,
                   minHeight: 0, maxHeight: .infinity)
            .background(backgroundColor)
            .simultaneousGesture(
                DragGesture(minimumDistance: 0.0)
                    .updating($isTouching) { _, isTouching, _ in
                        isTouching = true
                    }
                    .onChanged { drag in
                        dragOffsetEnd = false
                        dragOffset = drag.translation
                    }
                    .onEnded { drag in
                        dragOffsetEnd = true
                        dragOffset = drag.translation
                    }
            )
            .highPriorityGesture(
                TapGesture().onEnded(onTap)
            )
            .onChange(of: isTouching, perform: onLongPress)
    }
}

struct TouchContainer_Previews: PreviewProvider {
    static var previews: some View {
        LongPressRecognizerView(
            onTap: { },
            onLongPress: { _ in },
            dragOffset: .constant(.zero),
            dragOffsetEnd: .constant(false)
        )
    }
}
