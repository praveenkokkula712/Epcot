//
//  FadeAwayModifier.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 14/05/23.
//

import SwiftUI

struct FadeAwayModifier: ViewModifier {
    var fade = false
    
    init(fade: Bool) {
        self.fade = fade
    }

    func body(content: Content) -> some View {
        content
            .disabled(fade)
            .opacity(fade ? 0.0 : 1.0)
            .animation(.linear, value: fade)
    }
}
