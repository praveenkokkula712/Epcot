//
//  GameStoryItemView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 24/04/23.
//

import SwiftUI
import Kingfisher
import Utility

struct GameStoryItemView: View {
    
    // MARK: - Properties
    @ObservedObject var viewModel = GameStoryItemViewModel()
    private var progressViewModel: GameStoryItemProgress
    var styles: GameStoryItemViewCSS
    private let accessibilityIdentifiers = CasinoStoriesAccessibilityIdentifiers()
    @EnvironmentObject var selectedStoryItem: SelectedGameStoryItem
    @ObservedObject var rippleProperties = GameStoryOnboardingProperties()
    @State private var viewSwipeOffset = CGSize.zero
    @State private var viewSwipeOffsetDragEnd = false
    @EnvironmentObject var draggingOffset: DraggingOffset

    // MARK: - Init
    init(viewModel: GameStoryItemViewModel,
         progressViewModel: GameStoryItemProgress,
         styles: GameStoryItemViewCSS,
         isActive: Bool) {
        self.viewModel = viewModel
        self.styles = styles
        self.progressViewModel = progressViewModel
        if isActive {
            if viewModel.selectedItemIndex == 0 {
                self.progressViewModel.startProgress()
            } else {
                self.progressViewModel.startProgress(from: viewModel.selectedItemIndex)
            }
            if self.viewModel.viewModel?.isSeeMoreViewIsShowing ?? false {
                self.progressViewModel.pauseCurrentProgress()
            }
        } else {
            self.progressViewModel.resetAllProgresses()
        }
    }

    // MARK: - UI Content
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Image background
                if !viewModel.isOnboardingStory {
                    KFImage(viewModel.item.imageURL)
                        .placeholder { PlaceHolderImage() }
                        .resizable()
                        .scaledToFit()
                        .frame(width: geometry.size.width)
                        .accessibilityIdentifier(storyImageIdentifier)
                    
                    // Oval mask
                    Rectangle()
                        .fill(
                            RadialGradient(
                                gradient: Gradient(
                                    colors: [.clear, styles.backgroundColor]
                                ),
                                center: .center,
                                startRadius: gradientRadii(of: geometry).0,
                                endRadius: gradientRadii(of: geometry).1
                            )
                        )
                    //                        .scaleEffect(
                    //                            x: 1,
                    //                            y: verticalAmount(of: geometry),
                    //                            anchor: .center
                    //                        )
                        .ignoresSafeArea()
                }
                
                if viewModel.isOnboardingStory {
                    CasinoStoryOnboardingView(styles: styles)
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        .edgesIgnoringSafeArea([.horizontal, .bottom])
                }

                VStack {
                    
                    // Progress Bar
                    if showProgress {
                        GameStoryItemProgressView(
                            viewModel: viewModel,
                            styles: styles,
                            progressViewModel: progressViewModel
                        )
                        .padding(.top, 8)
                        .padding(.horizontal, 15)
                        .allowsHitTesting(false)
                        .modifier(FadeAwayModifier(fade: viewModel.isLongPressed))
                    } else {
                        Spacer()
                            .padding(.top, 8)
                            .frame(height: safeAreaInsets.top)
                    }
                    
                    // Close Button
                    VStack(alignment: .trailing) {
                        HStack {
                            Spacer()
                            Button {
                                withAnimation (instantInteractionAnimation) {
                                    viewModel.closeButtonInteracted = 1
                                }
                            } label: {
                                if let closeIcon = UIImage(
                                    named: kCloseWhite,
                                    in: kEpcotBundle,
                                    compatibleWith: nil
                                ) {
                                    Image(uiImage: closeIcon)
                                        .renderingMode(.template)
                                        .foregroundColor(styles.closeButtonColor)
                                        .padding(8)
                                        .frame(width: 32, height: 32)
                                }
                            }
                            .background(
                                viewModel.closeButtonInteracted == 0 ? Color.clear : Color.overlay40Color
                            )
                            .onAnimationCompleted(for: viewModel.closeButtonInteracted) {
                                viewModel.closeButtonInteracted = 0
                                viewModel.onCloseButtonTap()
                            }
                            .accessibilityIdentifier(closeButtonIdentifier)
                        }
                        .padding(.bottom, 8)
                    }
                    .padding(.horizontal, 15)
                    .zIndex(2)
                    .modifier(FadeAwayModifier(fade: viewModel.isLongPressed))
                    
                    if !viewModel.isOnboardingStory {
                        
                        // Title, SubTitle & Description
                        VStack(spacing: 0) {
                            if !viewModel.item.title.isEmpty {
                                Text(viewModel.item.title)
                                    .foregroundColor(styles.titleColor)
                                    .font(styles.titleFont)
                                    .lineLimit(2)
                                    .accessibilityIdentifier(titleIdentifier)
                                    .padding(.top, titleTopPadding)
                            }
                            
                            if !viewModel.item.subTitle.isEmpty {
                                Text(viewModel.item.subTitle)
                                    .foregroundColor(styles.subTitleColor)
                                    .font(styles.subTitleFont)
                                    .lineLimit(2)
                                    .padding(.top, subTitleTopPadding)
                            }
                            
                            if !viewModel.item.paragraph.isEmpty {
                                Text(viewModel.item.paragraph)
                                    .foregroundColor(styles.paragraphColor)
                                    .font(styles.paragraphFont)
                                    .lineLimit(3)
                                    .accessibilityIdentifier(descriptionIdentifier)
                                    .padding(.top, paragraphTopPadding)
                            }
                        }
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                        .allowsHitTesting(false)
                        
                        //
                        Spacer()
                            .allowsHitTesting(false)
                        
                        // CTA Button
                        if !viewModel.item.cta.isEmpty {
                            Button {
                                withAnimation (instantInteractionAnimation) {
                                    viewModel.ctaButtonInteracted = 1
                                }
                            } label: {
                                Text(viewModel.ctaTitle)
                                    .textCase(.uppercase)
                                    .foregroundColor(styles.ctaButtonColor)
                                    .font(styles.ctaButtonFont)
                                    .padding(.vertical, 12)
                                    .padding(.horizontal, 16)
                                    .background(viewModel.ctaButtonInteracted == 0 ? styles.ctaButtonBackgroundColor : Color.overlay40Color)
                            }
                            .cornerRadius(styles.ctaButtonCornerRadius)
                            .padding(
                                .bottom,
                                viewModel.item.terms.isEmpty && 
                                !viewModel.item.showOptIn &&
                                !viewModel.item.enableSwipeUp ? 60 : 32
                            )
                            .modifier(FadeAwayModifier(fade: viewModel.isLongPressed))
                            .onAnimationCompleted(for: viewModel.ctaButtonInteracted) {
                                viewModel.ctaButtonInteracted = 0
                                viewModel.onCTAButtonTap(viewModel.ctaLink)
                            }
                            .accessibilityIdentifier(playNowButtonIdentifier)
                        }
                        
                        // OptIn Button
                        if viewModel.item.showOptIn {
                            Button {
                                withAnimation (instantInteractionAnimation) {
                                    viewModel.optInButtonInteracted = 1
                                }
                            } label: {
                                Text(optInText)
                                    .textCase(.uppercase)
                                    .foregroundColor(styles.ctaButtonColor)
                                    .font(styles.ctaButtonFont)
                                    .padding(.vertical, 12)
                                    .padding(.horizontal, 16)
                                    .background(viewModel.optInButtonInteracted == 0 ? styles.ctaButtonBackgroundColor : Color.overlay40Color)
                            }
                            .cornerRadius(styles.ctaButtonCornerRadius)
                            .padding(
                                .bottom,
                                viewModel.item.terms.isEmpty &&
                                !viewModel.item.enableSwipeUp ? 60 : 32
                            )
                            .modifier(FadeAwayModifier(fade: viewModel.isLongPressed))
                            .onAnimationCompleted(for: viewModel.optInButtonInteracted) {
                                viewModel.optInButtonInteracted = 0
                                viewModel.onOptInButtonTap(viewModel)
                            }
                            .accessibilityIdentifier(optInButtonIdentifier)
                        }
                        
                        // SEE MORE
                        if showProgress, viewModel.item.enableSwipeUp {
                            GameStoryItemSeeMoreView(styles: styles)
                            ///if terms view is available no need to add safe area padding
                                .padding(.bottom, viewModel.item.showTerms ? 0 : safeAreaInsets.bottom)
                                .modifier(FadeAwayModifier(fade: viewModel.isLongPressed))
                        }
                        
                        // Terms & Conditions
                        if viewModel.item.showTerms {
                            VStack(alignment: .center) {
                                Text(viewModel.item.terms)
                                    .font(styles.legalTermsFont)
                                    .foregroundColor(styles.legalTermsColor)
                                    .multilineTextAlignment(.center)
                                    .padding([.horizontal, .top], 16)
                                    .accessibilityIdentifier(legalTermsTextIdentifier)
                                Spacer()
                            }
                            .frame(height: 90)
                            .background(styles.legalTermsBackgroundColor)
                            .allowsHitTesting(false)
                            .accessibilityIdentifier(legalTermsViewIdentifier)
                        }
                    } else {
                        Spacer()
                    }
                }
                .zIndex(1)
                .edgesIgnoringSafeArea([.horizontal, .bottom])
                
                // Touch Containers
                HStack(spacing: 0) {
                    LongPressRecognizerView(
                        onTap: {
                            if !viewModel.isSwipeUpContent {
                                viewModel.onLeftAreaTouch()
                                progressViewModel.startPreviousProgress()
                            }
                        },
                        onLongPress: { active in
                            if !viewModel.isSwipeUpContent {
                                onViewLongPress(active)
                            }
                        },
                        dragOffset: $viewSwipeOffset,
                        dragOffsetEnd: $viewSwipeOffsetDragEnd
                    )
                    .frame(width: geometry.size.width * 0.33)
                    
                    LongPressRecognizerView(
                        onTap: {
                            if !viewModel.isSwipeUpContent {
                                viewModel.onRightAreaTouch()
                                progressViewModel.startNextProgress()
                            }
                        },
                        onLongPress: { active in
                            if !viewModel.isSwipeUpContent {
                                onViewLongPress(active)
                            }
                        },
                        dragOffset: $viewSwipeOffset,
                        dragOffsetEnd: $viewSwipeOffsetDragEnd
                    )
                }
                .edgesIgnoringSafeArea(.all)
                .zIndex(0)
            }
            .background(styles.backgroundColor)
        }
        ///we don't get continuous loop with these two onChange modifiers, as we are mentioning conditions inside
        .onChange(of: viewModel.item) { _ in
            if viewModel.isCurrentStoryIsDisplaying {
                ///Other than swipe up content
                selectedStoryItem.index = viewModel.selectedItemIndex
            }
        }
        .onChange(of: selectedStoryItem.index) { value in
            if viewModel.isSwipeUpContent {
                ///Only for swipe content
                self.viewModel.updateStoryItem(with: value)
            }
        }
        .onAppear {
            if viewModel.isCurrentStoryIsDisplaying,
               !viewModel.isSwipeUpContent {
                viewModel.item.markVisited()
                //marking the story as visited if it is last story item
                viewModel.markStoryAsVisited()
            }
        }
        .onChange(of: viewSwipeOffset) { offset in
            if offset.height >= styles.closeOffset {
                viewModel.onCloseButtonTap()
            } else if offset.height < 0, !viewModel.isSwipeUpContent, (self.viewModel.item.enableSwipeUp || self.draggingOffset.currentY < 0) {
                if viewSwipeOffsetDragEnd {
                    self.draggingEnded()
                } else {
                    withAnimation (.spring()) {
                        ///as we are moving up, current Y will be minus value like -100, -200
                        draggingOffset.currentY = offset.height
                    }
                }
            }
        }
        .onChange(of: viewSwipeOffsetDragEnd) { dragEnd in
            if !viewModel.isSwipeUpContent {
                if dragEnd, draggingOffset.currentY < 0 {
                    self.draggingEnded()
                }
            }
        }
    }
    
    //MARK: - Helper
    
    private var titleTopPadding: CGFloat {
        24
    }
    
    private var subTitleTopPadding: CGFloat {
        return viewModel.item.title.isEmpty ? 24 : 8
    }
    
    private var paragraphTopPadding: CGFloat {
        return (viewModel.item.title.isEmpty && viewModel.item.subTitle.isEmpty) ? 24 : 8
    }
    
    private var safeAreaInsets: UIEdgeInsets {
        UIApplication.safeAreaInsets
    }
    
    private var showProgress: Bool {
        !(viewModel.isSwipeUpContent)
    }
        
    private var optInText: String {
        viewModel.item.isOpted ? viewModel.item.optedInText : viewModel.item.optInText
    }
    
    private func draggingEnded() {
        withAnimation (.spring()) {
            if -(draggingOffset.currentY) > minDraggedOffset {
                draggingOffset.endingY = -draggingOffset.startingY
            }
            draggingOffset.currentY = 0
        }
    }
    
    //MARK: - Action
    private func onViewLongPress(_ active: Bool) {
        if active {
            progressViewModel.pauseCurrentProgress()
            viewModel.isLongPressed.toggle()
        } else {
            progressViewModel.resumeCurrentProgress()
            viewModel.isLongPressed.toggle()
        }
    }

    private func verticalAmount(of geometry: GeometryProxy) -> Double {
        let multiplier = geometry.size.width <= 375 ? 1.65 : 1.85
        return geometry.size.height / (geometry.size.width * multiplier)
    }
    
    private func gradientRadii(of geometry: GeometryProxy) -> (Double, Double) {
        let width: Double = geometry.size.width
        let radii = (width * 0.45, width * 0.75)
        return radii
    }
}

// MARK: - Accessibility Identifiers
extension GameStoryItemView {
    
    private var storyImageIdentifier : String {
        accessibilityIdentifiers.storyImage
    }
    private var closeButtonIdentifier : String {
        accessibilityIdentifiers.storyCloseButton
    }
    private var titleIdentifier : String {
        accessibilityIdentifiers.storyTitle
    }
    private var descriptionIdentifier : String {
        accessibilityIdentifiers.storyDescription
    }
    private var playNowButtonIdentifier : String {
        accessibilityIdentifiers.playNowButton
    }
    private var optInButtonIdentifier : String {
        accessibilityIdentifiers.optInButton
    }
    private var legalTermsViewIdentifier : String {
        accessibilityIdentifiers.legalTermsView
    }
    private var legalTermsTextIdentifier : String {
        accessibilityIdentifiers.legalTermsText
    }
    
}

struct GameStoryItemView_Previews: PreviewProvider {
    static var previews: some View {
        GameStoryItemView(
            viewModel: GameStoryItemViewModel(),
            progressViewModel: GameStoryItemProgress(viewModel: GameStoryItemViewModel()),
            styles: GameStoryItemViewCSS(),
            isActive: false
        )
    }
}
