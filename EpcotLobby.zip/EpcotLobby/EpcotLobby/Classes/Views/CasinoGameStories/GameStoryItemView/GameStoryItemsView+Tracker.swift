//
//  GameStoryItemsView+Tracker.swift
//  EpcotLobby
//
//  Created by Santhosh Kodadi on 13/06/23.
//

import SwiftUI
import TrackerClient

enum GameStoryItemsViewAction {
    case close, cta, optIn, swipeUp, swipeLeft, swipeRight, load
}

extension GameStoryItemsView {
    func trackEvent(for action: GameStoryItemsViewAction, isSwipeUp: Bool = false, ctaButton: String = "") {
        guard self.viewModel.stories.count-1 > self.selectedIndex else { return }
        let story = self.viewModel.stories[self.selectedIndex]
        let storyItemIndex = self.selectedGameStoryItem.index
        guard (story.storyItems.count - 1) > storyItemIndex else { return }
        var storyItem =  story.storyItems[storyItemIndex]
        
        let storyName = story.name
        let storyNumber = self.selectedIndex
        
        if isSwipeUp {
            storyItem = storyItem.swipeUpContentItems.first ?? storyItem
        }
        
        switch action {
        case .close:
            self.trackEvent(eventAction: EpcotEventAction.click.rawValue,
                            eventLable: EpcotEventLabel.promo_nav.rawValue,
                            eventLocation: storyName,
                            eventDetails: EpcotEventDetails.close.rawValue,
                            eventPosition: String(storyNumber))
        case .cta:
            self.trackEvent(eventAction: EpcotEventAction.click.rawValue,
                            eventLable: EpcotEventLabel.promo_nav.rawValue,
                            eventLocation: storyName,
                            eventDetails: ctaButton,
                            eventPosition: String(storyNumber))
        case .optIn:
            self.trackEvent(eventAction: EpcotEventAction.click.rawValue,
                            eventLable: EpcotEventLabel.promo_nav.rawValue,
                            eventLocation: storyName,
                            eventDetails: EpcotEventDetails.opt_in.rawValue,
                            eventPosition: String(storyNumber))
        case .swipeUp:
            self.trackEvent(eventAction: EpcotEventAction.swipe_down.rawValue,
                            eventLable: EpcotEventLabel.page.rawValue,
                            eventLocation: storyName,
                            eventDetails: EpcotEventDetails.see_more.rawValue,
                            eventPosition: String(storyNumber))
        case .swipeLeft:
            self.trackEvent(eventAction: EpcotEventAction.swipe_left.rawValue,
                            eventLable: EpcotEventLabel.promo_nav.rawValue,
                            eventLocation: storyName,
                            eventDetails: GtmLogConstants.GeneralConstants.notApplicable.rawValue,
                            eventPosition: String(storyNumber))
        case .swipeRight:
            self.trackEvent(eventAction: EpcotEventAction.swipe_right.rawValue,
                            eventLable: EpcotEventLabel.promo_nav.rawValue,
                            eventLocation: storyName,
                            eventDetails: GtmLogConstants.GeneralConstants.notApplicable.rawValue,
                            eventPosition: String(storyNumber))
        case .load:
            self.trackEvent(eventAction: EpcotEventAction.load.rawValue,
                            eventLable: EpcotEventLabel.promo_nav.rawValue,
                            eventLocation: storyName,
                            eventDetails: GtmLogConstants.GeneralConstants.notApplicable.rawValue,
                            eventPosition: String(storyNumber))
        }
    }
    
    func trackEvent(eventAction: String,
                    eventLable: String,
                    eventLocation: String,
                    eventDetails: String,
                    eventPosition: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.casino_stories.rawValue,
                                     actionEvent:eventAction,
                                     labelEvent: eventLable,
                                     locationEvent: eventLocation,
                                     eventDetails: eventDetails,
                                     positionEvent: eventPosition)
            let event = TrackerEvent(type: EventType.casino_stories, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}
