//
//  CasinoStoryOnboardingView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 14/12/23.
//

import SwiftUI
import Kingfisher
import Utility

struct CasinoStoryOnboardingView: View {
    
    // MARK: - Properties
    private let onboardingStoryItem = OnboardingGameStoryItem()
    private let styles: GameStoryItemViewCSS
    private let accessibilityIdentifiers = CasinoStoriesAccessibilityIdentifiers()

    // MARK: - Init
    init(styles: GameStoryItemViewCSS) {
        self.styles = styles
    }

    // MARK: - Body
    var body: some View {
        ZStack {
            Rectangle()
                .fill(
                    LinearGradient(
                        stops: [
                            .init(color: styles.backgroundColor, location: 0.25),
                            .init(color: styles.legalTermsBackgroundColor, location: 0.75)
                        ],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .edgesIgnoringSafeArea(.bottom)

            ZStack {
                
                // Circles
                backgroundCircles()
                
                // Logo
                ZStack {
                    Circle()
                        .strokeBorder(styles.logoRingColor, lineWidth: styles.logoRingWidth)
                        .background(Circle().fill(styles.logoColor))
                        .frame(width: logoSize - 15) // inner circle
                    
                    Circle()
                        .strokeBorder(styles.logoHairlineColor, lineWidth: 1)
                        .frame(width: logoSize - 8 - 15) // hairline circle
                    
                    Circle()
                        .strokeBorder(styles.rippleColor, lineWidth: 2)
                        .frame(width: logoSize - 15) // outer circle
                    
                    Circle()
                        .strokeBorder(styles.logoBorderColor, lineWidth: 2)
                        .frame(width: logoSize - 8 - 22) // hairline circle

                    if let logoUrl = onboardingStoryItem.logoUrl {
                        KFImage.url(logoUrl)
                            .placeholder {
                                PlaceHolderImage()
                            }
                            .resizable()
                            .scaledToFit()
                            .frame(width: 50, height: 50)
                            .accessibilityIdentifier(logoIdentifier)
                    }
                    
                    Circle()
                        .strokeBorder(styles.rippleColor.opacity(0.5), lineWidth: 2)
                        .frame(width: logoSize) // nearby ripple circle
                }
                .frame(height: logoSize)
                
                // Title & Description
                VStack(spacing: 8.0) {
                    Text(onboardingStoryItem.welcomeTitle)
                        .foregroundColor(styles.titleColor)
                        .font(styles.titleFont)
                        .lineLimit(2)
                        .accessibilityIdentifier(titleIdentifier)
                    
                    Text(onboardingStoryItem.welcomeMessage)
                        .foregroundColor(styles.paragraphColor)
                        .font(styles.paragraphFont)
                        .lineLimit(3)
                        .accessibilityIdentifier(subTitleIdentifier)
                }
                .multilineTextAlignment(.center)
                .frame(width: screenWidth * 0.55)
                .allowsHitTesting(false)
                .offset(y: logoSize + 10)
            }
            .offset(y: -logoSize)

            VStack {
                Spacer()
                
                //Onboarding Hints
                HStack(alignment: .top) {
                    gestureHint(for: .swipeRight)
    
                    Spacer().layoutPriority(1.0)
    
                    gestureHint(for: .touchHold)
    
                    Spacer().layoutPriority(1.0)
    
                    gestureHint(for: .swipeLeft)
                }
                .padding(.bottom, 32)
            }
            .frame(width: screenWidth * 0.8)
        }
        .frame(width: screenWidth)
    }
}

extension CasinoStoryOnboardingView {
    
    //MARK: - Reusable Views
    @ViewBuilder
    private func gestureHint(for type: OnboardingStoryItemHintType) -> some View {
        let alignment = hintContent(for: type).3
        VStack(alignment: alignment, spacing: 16) {
            gestureHintIcon(for: type)
            gestureHintText(for: type)
        }
        .frame(width: 90)
    }

    @ViewBuilder
    private func gestureHintIcon(for type: OnboardingStoryItemHintType) -> some View {
        if let url = hintContent(for: type).0 {
            Capsule()
                .fill(styles.touchHandBackgroundColor)
                .frame(width: hintIconSize.width, height: hintIconSize.height)
                .overlay(
                    KFImage.url(url)
                        .placeholder { PlaceHolderImage() }
                        .resizable()
                        .scaledToFit()
                        .frame(
                            width: hintIconSize.width / 2,
                            height: hintIconSize.height / 2
                        )
                )
                .accessibilityIdentifier(hintIconIdentifier(for: type))
        } else {
            EmptyView()
        }
    }

    @ViewBuilder
    private func gestureHintText(for type: OnboardingStoryItemHintType) -> some View {
        let content: (_, string: String, _, _, alignment: TextAlignment) = hintContent(for: type)

        return Text(.init(content.string))
            .multilineTextAlignment(content.alignment)
            .foregroundColor(styles.touchTitleColor)
            .font(styles.touchTitleFont)
            .accessibilityIdentifier(hintTextIdentifier(for: type))
    }

    private var circleSizes: [Double] { [220.0, 350.0, 500.0, 700.0] }

    @ViewBuilder
    private func backgroundCircles() -> some View {
        ZStack {
            ForEach(circleSizes, id: \.self) { size in
                Circle()
                    .strokeBorder(styles.rippleColor.opacity(size == 220.0 ? 0.3 : 0.2), lineWidth: 1)
                    .frame(width: size)
            }
        }
    }

    //MARK: - Design Constants
    private var logoTopSpacing: CGFloat { UIDevice.screenSize.height * 0.215 }
    private var hintIconSize: CGSize { .init(width: 64, height: 72) }
    private var screenWidth: CGFloat { tabViewWidth }
    private var logoSize: CGFloat { 125 }

    private var tabViewWidth: CGFloat {
        let orientationFactor = UIDevice.isPortrait ? 0.6 : 0.4
        return UIDevice.screenSize.width * (isIPad ? orientationFactor : 1.0)
    }

    private var isIPad: Bool {
        UIDevice.isIPad()
    }
    
    //MARK: - Helper
    private func hintContent(for type: OnboardingStoryItemHintType) -> (URL?, String, String, HorizontalAlignment, TextAlignment) {
        var url: URL?
        var text: String
        var defaultText: String
        var alignment: HorizontalAlignment
        var textAlignment: TextAlignment
        switch type {
        case .swipeRight:
            url = onboardingStoryItem.swipeRightUrl
            text = onboardingStoryItem.swipeRightHint
            defaultText = kOnboardingRightHint
            alignment = .leading
            textAlignment = .leading
        case .swipeLeft:
            url = onboardingStoryItem.swipeLeftUrl
            text = onboardingStoryItem.swipeLeftHint
            defaultText = kOnboardingLeftHint
            alignment = .trailing
            textAlignment = .trailing
        case .touchHold:
            url = onboardingStoryItem.touchHoldUrl
            text = onboardingStoryItem.touchHoldHint
            defaultText = kOnboardingTapHint
            alignment = .center
            textAlignment = .center
        }
        return (url, text, defaultText, alignment, textAlignment)
    }
}

// MARK: - Accessibility Identifiers
extension CasinoStoryOnboardingView {
    
    private var logoIdentifier : String {
        accessibilityIdentifiers.onboardingLogo
    }
    private var titleIdentifier : String {
        accessibilityIdentifiers.onboardingTitle
    }
    private var subTitleIdentifier : String {
        accessibilityIdentifiers.onboardingSubTitle
    }
    private func hintIconIdentifier(for type: OnboardingStoryItemHintType) -> String {
        switch type {
        case .swipeLeft:
            accessibilityIdentifiers.swipeLeftGestureHintIcon
        case .touchHold:
            accessibilityIdentifiers.touchHoldGestureHintIcon
        case .swipeRight:
            accessibilityIdentifiers.swipeRightGestureHintIcon
        }
    }
    private func hintTextIdentifier(for type: OnboardingStoryItemHintType) -> String {
        switch type {
        case .swipeLeft:
            accessibilityIdentifiers.swipeLeftGestureHintText
        case .touchHold:
            accessibilityIdentifiers.touchHoldGestureHintText
        case .swipeRight:
            accessibilityIdentifiers.swipeRightGestureHintText
        }
    }
}

struct CasinoStoryOnboardingView_Previews: PreviewProvider {
    static var previews: some View {
        CasinoStoryOnboardingView(styles: GameStoryItemViewCSS())
    }
}

