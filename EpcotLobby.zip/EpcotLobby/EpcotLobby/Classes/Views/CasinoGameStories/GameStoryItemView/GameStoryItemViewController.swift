//
//  GameStoryItemViewController.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 24/04/23.
//

import UIKit
import SwiftUI

final class GameStoryItemViewController: UIViewController {
    
    // MARK: - Properties
    private var viewModel: GameStoriesViewModel

    // MARK: - Init
    init(viewModel: GameStoriesViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        let css = EpcotLobbyManager.shared?.css.gameStoryItemsCSS
        let styles = GameStoryItemViewCSS(css: css)
        view.backgroundColor = styles.backgroundColor.uiColor
        let gameStoryItemsView = GameStoryItemsView(
            viewModel: viewModel,
            styles: styles
        ) { [weak self] in
            guard let self else { return }
            self.viewModel.updateStoriesOnClose()
            self.viewModel.isGameStoriesPresented = false
            self.dismiss(animated: true)
        }
        guard 
            let rootView = UIHostingController(rootView: gameStoryItemsView).view
        else { return }
        rootView.backgroundColor = styles.backgroundColor.uiColor
        view.addSubview(rootView)
        rootView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            view.topAnchor.constraint(equalTo: rootView.topAnchor),
            view.bottomAnchor.constraint(equalTo: rootView.bottomAnchor),
            view.leadingAnchor.constraint(equalTo: rootView.leadingAnchor),
            view.trailingAnchor.constraint(equalTo: rootView.trailingAnchor)
        ])
    }
}
