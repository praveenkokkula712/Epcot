//
//  GameStoryItemProgressView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 24/04/23.
//

import SwiftUI

struct GameStoryItemProgressView: View {
    
    // MARK: - Properties
    @ObservedObject var viewModel = GameStoryItemViewModel()
    private var progressViewModel: GameStoryItemProgress
    private var styles: GameStoryItemViewCSS

    // MARK: - Init
    init(viewModel: GameStoryItemViewModel,
         styles: GameStoryItemViewCSS,
         progressViewModel: GameStoryItemProgress
    ) {
        self.viewModel = viewModel
        self.styles = styles
        self.progressViewModel = progressViewModel
    }

    // MARK: - UI Content
    var body: some View {
        HStack {
            ForEach(0..<progressViewModel.progresses.count, id: \.self) { index in
                if index < progressViewModel.progresses.count {
                    GameStorySubItemProgressView(
                        progress: progressViewModel.progresses[index],
                        styles: GameStoryItemViewCSS()
                    )
                } else {
                    EmptyView()
                }
            }
        }
    }
}

struct GameStoryProgressView_Previews: PreviewProvider {
    static var previews: some View {
        GameStoryItemProgressView(
            viewModel: GameStoryItemViewModel(),
            styles: GameStoryItemViewCSS(),
            progressViewModel: GameStoryItemProgress(
                viewModel: GameStoryItemViewModel()
            )
        )
    }
}
