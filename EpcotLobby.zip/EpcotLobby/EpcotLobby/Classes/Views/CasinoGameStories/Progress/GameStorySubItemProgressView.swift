//
//  GameStorySubItemProgressView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 10/05/23.
//

import SwiftUI

struct GameStorySubItemProgressView: View {
    
    // MARK: - Properties
    @ObservedObject var progress = GameStorySubItemProgress()
    private var styles: GameStoryItemViewCSS

    // MARK: - Init
    init(progress: GameStorySubItemProgress, styles: GameStoryItemViewCSS) {
        self.progress = progress
        self.styles = styles
    }
    
    // MARK: - UI Content
    var body: some View {
        ProgressBarView(
            value: progress.progress,
            totalValue: progress.totalProgress,
            styles: styles
        )
        .frame(height: 4.0)
    }
}

struct GameStorySubItemProgressView_Previews: PreviewProvider {
    static var previews: some View {
        GameStorySubItemProgressView(
            progress: GameStorySubItemProgress(),
            styles: GameStoryItemViewCSS()
        )
    }
}
