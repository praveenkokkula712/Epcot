//
//  GameStoryItemProgress.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 10/05/23.
//

import Combine

class GameStoryItemProgress {
    
    // MARK: - Properties
    private(set) var progresses = [GameStorySubItemProgress]()
    private weak var viewModel = GameStoryItemViewModel()
    private var currentProgressIndex = 0
    private var cancellable: AnyCancellable?
    //This 'progressUpdate' has to override, that is why not taken Set<AnyCancellable>
    private var progressUpdate: AnyCancellable?
    private var isLastItem = false

    // MARK: - Init
    init(
        viewModel: GameStoryItemViewModel,
        changeProgress: (atIndex: Int, pause: Bool) = (-1, false)
    ) {
        self.viewModel = viewModel
        for _ in 0..<viewModel.story.storyItems.count {
            self.progresses.append(GameStorySubItemProgress())
        }
        self.updatePreviousProgressValue(atIndex: changeProgress.atIndex,
                                         pause: changeProgress.pause)
    }
    
    //MARK: - progressUpdateOnRotations/previous updates
    func updatePreviousProgressValue(atIndex: Int, pause: Bool) {
        if atIndex > -1,
           atIndex < progresses.count,
           self.viewModel?.isCurrentStoryIsDisplaying ?? false {
            currentProgressIndex = atIndex
            // FIXME: Fix the previous progress fill issue when iPad is rotated.
            fillPreviousProcesses()
            if pause {
                pauseCurrentProgress()
                let currentProgressValue = self.progresses[currentProgressIndex].progress
                self.viewModel?.viewModel?.pausedProgressValue = currentProgressValue
            } else {
                let currentProgressValue = self.viewModel?.viewModel?.pausedProgressValue ?? 0.0
                self.progresses[currentProgressIndex].progress = currentProgressValue
                resumeCurrentProgress()
            }
        }
    }

    //MARK: - start progress from Non-visited item
    func startProgress(from index: Int) {
        guard index > 0 else {
            self.startProgress()
            return
        }
        self.currentProgressIndex = index-1
        self.startNextProgress()
    }
    
    // MARK: - Progress Cycle
    func startProgress() {
        if progresses.count > 0 && progresses.count > currentProgressIndex {
            let currentProgress = progresses[currentProgressIndex]
            currentProgress.startProgress()
            if currentProgressIndex == progresses.count - 1 {
                isLastItem = true
            }
            cancellable = currentProgress.$completed.sink { [weak self] isCompleted in
                guard let self else { return }
                if isCompleted && self.progresses.count - 1 > self.currentProgressIndex {
                    self.moveToNextStoryItem()
                } else if isCompleted && self.isLastItem {
                    self.isLastItem = false
                    self.moveToNextStory()
                }
            }
            
            progressUpdate = currentProgress.$progress.sink { [weak self] progress in
                if self?.viewModel?.viewModel?.isSeeMoreViewIsShowing ?? false {
                    self?.pauseCurrentProgress()
                }
                if self?.viewModel?.isCurrentStoryIsDisplaying ?? false {
                    self?.viewModel?.viewModel?.pausedProgressValue = progress
                }
            }
        }
    }

    func pauseCurrentProgress() {
        guard progresses.count > currentProgressIndex else { return }
        let currentProgress = progresses[currentProgressIndex]
        currentProgress.pauseProgress()
    }

    func resumeCurrentProgress() {
        guard progresses.count > currentProgressIndex else { return }
        let currentProgress = progresses[currentProgressIndex]
        currentProgress.startProgress()
    }

    // MARK: - Move Forward
    func startNextProgress() {
        if progresses.count - 1 > currentProgressIndex {
            fillPreviousProcesses()
            moveToNextStoryItem()
        } else if self.progresses.count - 1 == self.currentProgressIndex {
            moveToNextStory()
        }
    }

    private func fillPreviousProcesses() {
        guard progresses.count > currentProgressIndex else { return }
        for index in 0...currentProgressIndex {
            let progress = progresses[index]
            progress.completeProgress()
        }
    }

    private func moveToNextStory() {
        viewModel?.markStoryAsVisited()
        if viewModel?.isLastStory ?? false {
            viewModel?.onCloseButtonTap()
        } else {
            self.progresses.forEach { $0.resetProgress() }
            viewModel?.moveToNextGameStory()
        }
    }

    private func moveToNextStoryItem() {
        isLastItem = false
        currentProgressIndex += 1
        scrollStoryItemContent(to: currentProgressIndex)
        startProgress()
    }

    // MARK: - Move Backward
    func startPreviousProgress() {
        if currentProgressIndex >= 1 {
            currentProgressIndex -= 1
            scrollStoryItemContent(to: currentProgressIndex)
            resetNextProcesses()
            startProgress()
        } else {
            if !(viewModel?.isFirstStory ?? true) {
                moveToPreviousStory()
            }
            viewModel?.updateCurrentGameStoryAsVisibleIndex()
        }
    }

    private func resetNextProcesses() {
        precondition(
            progresses.count > currentProgressIndex,
            "Progress access out of bounds!"
        )
        for index in currentProgressIndex..<progresses.count {
            let progress = progresses[index]
            progress.resetProgress()
        }
    }
    
    private func moveToPreviousStory() {
        self.progresses.forEach { $0.resetProgress() }
        viewModel?.moveToPreviousGameStory()
    }
    
    private func scrollStoryItemContent(to index: Int) {
        viewModel?.scrollToIndex(currentProgressIndex)
    }

    // MARK: - Reset
    func resetAllProgresses() {
        currentProgressIndex = 0
        isLastItem = false
        progresses.forEach { $0.resetProgress() }
    }
}
