//
//  GameStorySubItemProgress.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 24/04/23.
//

import Foundation
import Combine
import SwiftUI
import ConfigModule

class GameStorySubItemProgress: ObservableObject {

    // MARK: - Properties
    @Published var progress = 0.0
    @Published var completed = false
    //     -------------------------------     //
    //    |  TIME  |  PROGRESS  |  VALUE  |    //
    //     -------------------------------     //
    //    |   0.01 |     1%     |   0.01  |    //
    //     -------------------------------     //
    //    |    1   |     10%    |   0.1   |    //
    //     -------------------------------     //
    //    |   10   |     100%   |    1    |    //
    //     -------------------------------     //
    private var step = 0.01
    private(set) var totalProgress = {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?
            .gameStoriesConfigurations?.subStoryDisplayTime ?? 0.0
    }()
    private var timer: Publishers.Autoconnect<Timer.TimerPublisher>?
    private var subscription: AnyCancellable?
    private var subscriptions = Set<AnyCancellable>()
    private var isAppActive = true

    // MARK: - Init
    init() {
        NotificationCenter.default
            .publisher(for: UIApplication.willResignActiveNotification)
            .sink { _ in
                self.isAppActive = false
            }
            .store(in: &subscriptions)
        NotificationCenter.default
            .publisher(for: UIApplication.didBecomeActiveNotification)
            .sink { _ in
                self.isAppActive = true
            }
            .store(in: &subscriptions)
    }

    // MARK: - Progress
    func startProgress() {
        timer = Timer.publish(every: step, on: .main, in: .common)
            .autoconnect()
        subscription = timer?
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in
                guard let self, self.isAppActive else { return }
                if self.progress < self.totalProgress {
                    self.progress = (self.progress + self.step).round(to: 2)
                } else {
                    self.completed = true
                    self.pauseProgress()
                }
            }
    }

    func pauseProgress() {
        timer?.upstream.connect().cancel()
        timer = nil
        subscription = nil
    }

    func completeProgress() {
        pauseProgress()
        progress = totalProgress
    }

    func resetProgress() {
        pauseProgress()
        progress = 0.0
        completed = false
    }

    // MARK: - De-Init
    deinit {
        pauseProgress()
    }
}
