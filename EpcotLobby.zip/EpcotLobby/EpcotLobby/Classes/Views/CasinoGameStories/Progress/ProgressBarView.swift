//
//  ProgressBarView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 11/05/23.
//

import SwiftUI
import ConfigModule

struct ProgressBarView: View {

    // MARK: - Properties
    private var value: Double
    private var totalValue: Double
    private var styles: GameStoryItemViewCSS
    private let accessibilityIdentifiers = CasinoStoriesAccessibilityIdentifiers()
    private(set) var subStoryCompetionSpeed = {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?
            .gameStoriesConfigurations?.subStoryCompletionSpeed ?? 0.0
    }()

    // MARK: - Init
    init(
        value: Double,
        totalValue: Double,
        styles: GameStoryItemViewCSS
    ) {
        self.value = value
        self.totalValue = totalValue
        self.styles = styles
    }

    var body: some View {
        GeometryReader { proxy in
            progressBar(proxy: proxy)
                .overlay(alignment: .leading) {
                    progressFillBar(proxy: proxy)
                }
        }
    }
    
    @ViewBuilder 
    func progressBar(proxy: GeometryProxy) -> some View {
        Rectangle()
            .frame(width: proxy.size.width, height: proxy.size.height)
            .foregroundColor(styles.progressBarColor)
            .cornerRadius(4.0)
            .accessibilityIdentifier(progressBarIdentifier)
    }
    
    @ViewBuilder
    func progressFillBar(proxy: GeometryProxy) -> some View {
        Rectangle()
            .frame(
                width: min(
                    CGFloat(self.value / self.totalValue) * proxy.size.width,
                    proxy.size.width
                ),
                height: proxy.size.height
            )
            .foregroundColor(styles.progressFillColor)
            .if(subStoryCompetionSpeed > 0) { view in
                view.animation(.linear(duration: subStoryCompetionSpeed))
            }
            .cornerRadius(4.0)
            .accessibilityIdentifier(progressFillBarIdentifier)
    }
}

// MARK: - Accessibility Identifiers
extension ProgressBarView {
    
    private var progressBarIdentifier : String {
        accessibilityIdentifiers.progressBar
    }
    private var progressFillBarIdentifier : String {
        accessibilityIdentifiers.progressFillBar
    }
}

struct ProgressBarView_Previews: PreviewProvider {
    static var previews: some View {
        ProgressBarView(
            value: 0.0,
            totalValue: 1.0,
            styles: GameStoryItemViewCSS()
        )
    }
}
