//
//  GameClipShape.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 13/04/23.
//

import Foundation

enum GameClipShape: String, RawRepresentable {
    case circle
    case roundedRect
    case rhombus
    
    init(rawValue: String) {
        switch rawValue {
        case "Circle": self = .circle
        case "Square": self = .roundedRect
        case "Rhombus": self = .rhombus
        default: self = .circle
        }
    }
}
