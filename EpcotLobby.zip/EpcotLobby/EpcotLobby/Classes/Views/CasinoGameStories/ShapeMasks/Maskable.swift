//
//  Maskable.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 13/04/23.
//

import Foundation
import SwiftUI

protocol BorderMaskable {
    associatedtype Content
    var content: Content { get }
    var strokeColor: Color { get }
    var strokeWidth: Double { get }
}

protocol RoundMaskable {
    var cornerRadius: Double { get }
}

protocol RotateMaskable {
    var rotation: Double { get }
}

typealias RoundRectMaskable = BorderMaskable & RoundMaskable
typealias DiamondMaskable = BorderMaskable & RoundMaskable & RotateMaskable
