//
//  CircularMask.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 13/04/23.
//

import SwiftUI

struct CircularMask<Content: View>: View, BorderMaskable {
    let content: Content
    let strokeColor: Color
    let strokeWidth: Double

    init(strokeColor: Color,
         strokeWidth: Double,
         @ViewBuilder content: () -> Content) {
        self.strokeColor = strokeColor
        self.strokeWidth = strokeWidth
        self.content = content()
    }

    var body: some View {
        content
            .clipShape(
                Circle()
            )
            .padding(4)
            .overlay(
                Circle()
                    .stroke(strokeColor, lineWidth: strokeWidth)
            )
    }
}
