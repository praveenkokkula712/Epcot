//
//  RoundRectangularMask.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 13/04/23.
//

import SwiftUI

struct RoundRectangularMask<Content: View>: View, RoundRectMaskable {
    let content: Content
    let strokeColor: Color
    let strokeWidth: Double
    let cornerRadius: Double

    init(strokeColor: Color,
         strokeWidth: Double,
         cornerRadius: Double,
         @ViewBuilder content: () -> Content) {
        self.content = content()
        self.strokeColor = strokeColor
        self.strokeWidth = strokeWidth
        self.cornerRadius = cornerRadius
    }

    var body: some View {
        content
            .clipShape(
                RoundedRectangle(cornerRadius: cornerRadius)
            )
            .padding(4)
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius + 4)
                    .stroke(strokeColor, lineWidth: strokeWidth)
            )
    }
}

