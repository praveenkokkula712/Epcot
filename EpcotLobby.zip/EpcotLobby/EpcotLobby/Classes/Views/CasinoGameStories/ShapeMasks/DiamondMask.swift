//
//  DiamondMask.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 13/04/23.
//

import SwiftUI

struct DiamondMask<Content: View>: View, DiamondMaskable {
    let content: Content
    let strokeColor: Color
    let strokeWidth: Double
    let cornerRadius: Double
    let rotation: Double

    init(strokeColor: Color,
         strokeWidth: Double,
         cornerRadius: Double,
         rotation: Double,
         @ViewBuilder content: () -> Content) {
        self.content = content()
        self.strokeColor = strokeColor
        self.strokeWidth = strokeWidth
        self.cornerRadius = cornerRadius
        self.rotation = rotation
    }

    var body: some View {
        content
            .padding(4)
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius)
                    .stroke(strokeColor, lineWidth: strokeWidth)
                    .rotationEffect(.degrees(rotation))
            )
    }
}
