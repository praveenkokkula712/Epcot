//
//  MustGoCollectionViewCell.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 14/10/22.
//

import UIKit
import Combine
import Utility

class MustGoCollectionViewCell: UICollectionViewCell {

    @IBOutlet private weak var backgroundImageView  : UIImageView!
    @IBOutlet private weak var jackpotImageView     : UIImageView!
    @IBOutlet private weak var viewMega             : UIView!
    @IBOutlet private weak var viewDaily            : UIView!
    @IBOutlet private weak var viewHourly           : UIView!
    @IBOutlet private weak var labelMega            : UILabel!
    @IBOutlet private weak var labelDaily           : UILabel!
    @IBOutlet private weak var labelHourly          : UILabel!
    @IBOutlet private weak var labelMegaPrice       : UILabel!
    @IBOutlet private weak var labelDailyPrice      : UILabel!
    @IBOutlet private weak var labelHourlyPrice     : UILabel!
   
    var jackpotModel: JackpotWidgetsModel? {
        didSet {
            self.backGroundImageUrl = jackpotModel?.backgroungImage
            self.jackpotImageUrl = jackpotModel?.jackpotImage
        }
    }
    private var pagingInfoToken: AnyCancellable?
    
    private var megaJackpotModel: SubJackpotDetails? {
        didSet {
            guard let megaJackpotModel = megaJackpotModel else {
                return
            }
            if let amount = megaJackpotModel.subJackpotAmount,
               let name = megaJackpotModel.subJackpotName {
                self.megaJackpotPrice = amount
                self.labelMega.text = name
            }
        }
    }
    
    private var megaJackpotPrice: String? {
        didSet {
            guard let megaJackpotPrice = megaJackpotPrice else {
                return
            }
            self.labelMegaPrice.text = megaJackpotPrice
        }
    }
    
    private var dailyJackpotModel: SubJackpotDetails? {
        didSet {
            guard let dailyJackpotModel = dailyJackpotModel else {
                return
            }
            if let amount = dailyJackpotModel.subJackpotAmount,
               let name = dailyJackpotModel.subJackpotName {
                self.dailyJackpotPrice = amount
                self.labelDaily.text = name
            }
        }
    }
    
    private var dailyJackpotPrice: String? {
        didSet {
            guard let dailyJackpotPrice = dailyJackpotPrice else {
                return
            }
            self.labelDailyPrice.text = dailyJackpotPrice
        }
    }
    
    private var hourlyJackpotModel: SubJackpotDetails? {
        didSet {
            guard let hourlyJackpotModel = hourlyJackpotModel else {
                return
            }
            if let amount = hourlyJackpotModel.subJackpotAmount,
               let name = hourlyJackpotModel.subJackpotName {
                self.hourlyJackpotPrice = amount
                self.labelHourly.text = name
            }
        }
    }
    
    private var hourlyJackpotPrice: String? {
        didSet {
            guard let hourlyJackpotPrice = hourlyJackpotPrice else {
                return
            }
            self.labelHourlyPrice.text = hourlyJackpotPrice
        }
    }
        
    var subJackpotDetails: [SubJackpotDetails]? {
        didSet {
            if let subjackpotDetail = subJackpotDetails?.first(where: {$0.jackpotFeedId == "rtgSpeedyJackpot_Mega"}) {
                self.megaJackpotModel = subjackpotDetail
            }
            if let subjackpotDetail = subJackpotDetails?.first(where: {$0.jackpotFeedId == "rtgSpeedyJackpot_daily"}) {
                self.dailyJackpotModel = subjackpotDetail
            }
            if let subjackpotDetail = subJackpotDetails?.first(where: {$0.jackpotFeedId == "rtgSpeedyJackpot_go5K"}) {
                self.hourlyJackpotModel = subjackpotDetail
            }
        }
    }
    
    private var backGroundImageUrl: String? {
        didSet {
            if let backGroundImageUrl = backGroundImageUrl {
                self.backgroundImageView.loadImage(withUrl: backGroundImageUrl)
            }
        }
    }
    
    private var jackpotImageUrl: String? {
        didSet {
            if let jackpotImageUrl = jackpotImageUrl {
                self.jackpotImageView.loadImage(withUrl: jackpotImageUrl)
            }
        }
    }
    
    private var css: MustGoJackpotWidgetsCSS? {
        EpcotLobbyManager.shared?.css.jackpotWidgets?.mustGoJackpot
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.updateCss()
        self.addAccessibilityIdentifiers()
    }
    
    private func updateCss() {
        self.labelMega.textColor = self.css?.title?.color
        self.labelMega.font = self.css?.title?.font
        self.labelDaily.textColor = self.css?.title?.color
        self.labelDaily.font = self.css?.title?.font
        self.labelHourly.textColor = self.css?.title?.color
        self.labelHourly.font = self.css?.title?.font
        self.labelMegaPrice.textColor = self.css?.price?.color
        self.labelMegaPrice.font = self.css?.price?.font
        self.labelDailyPrice.textColor = self.css?.price?.color
        self.labelDailyPrice.font = self.css?.price?.font
        self.labelHourlyPrice.textColor = self.css?.price?.color
        self.labelHourlyPrice.font = self.css?.price?.font
                
        self.viewMega.addBorder(width: self.css?.borderWidth ?? 1.0,
                                color: self.css?.borderColor ?? .clear,
                                with: self.css?.cornerRadius ?? 0.0)
        self.viewDaily.addBorder(width: self.css?.borderWidth ?? 1.0,
                                color: self.css?.borderColor ?? .clear,
                                with: self.css?.cornerRadius ?? 0.0)
        self.viewHourly.addBorder(width: self.css?.borderWidth ?? 1.0,
                                color: self.css?.borderColor ?? .clear,
                                with: self.css?.cornerRadius ?? 0.0)
    }
    
    func subscribeTo(subject: PassthroughSubject<[String: String]?, Never>) {
        pagingInfoToken = subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] values in
                guard let values = values else {
                    if let amount = self?.megaJackpotPrice?.jackpotCounterAmount {
                        self?.megaJackpotPrice = amount
                    }
                    if let amount = self?.hourlyJackpotPrice?.jackpotCounterAmount {
                        self?.hourlyJackpotPrice = amount
                    }
                    if let amount = self?.dailyJackpotPrice?.jackpotCounterAmount {
                        self?.dailyJackpotPrice = amount
                    }
                    return
                }
            }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.pagingInfoToken?.cancel()
        self.pagingInfoToken = nil
    }

}

//MARK: Adding Accessibility Identifiers
extension MustGoCollectionViewCell {
    private func addAccessibilityIdentifiers() {
        backgroundImageView.accessibilityIdentifier = AccessibilityIdentifiers.mustgocollection_backgroundImageView.rawValue
        jackpotImageView.accessibilityIdentifier = AccessibilityIdentifiers.mustgocollection_jackpotImageView.rawValue
        viewMega.accessibilityIdentifier = AccessibilityIdentifiers.mustgocollection_viewMega.rawValue
        viewDaily.accessibilityIdentifier = AccessibilityIdentifiers.mustgocollection_viewDaily.rawValue
        viewHourly.accessibilityIdentifier = AccessibilityIdentifiers.mustgocollection_viewHourly.rawValue
        labelMega.accessibilityIdentifier = AccessibilityIdentifiers.mustgocollection_labelMega.rawValue
        labelDaily.accessibilityIdentifier = AccessibilityIdentifiers.mustgocollection_labelDaily.rawValue
        labelHourly.accessibilityIdentifier = AccessibilityIdentifiers.mustgocollection_labelHourly.rawValue
        labelMegaPrice.accessibilityIdentifier = AccessibilityIdentifiers.mustgocollection_labelMegaPrice.rawValue
        labelDailyPrice.accessibilityIdentifier = AccessibilityIdentifiers.mustgocollection_labelDailyPrice.rawValue
        labelHourlyPrice.accessibilityIdentifier = AccessibilityIdentifiers.mustgocollection_labelHourlyPrice.rawValue
    }
}
