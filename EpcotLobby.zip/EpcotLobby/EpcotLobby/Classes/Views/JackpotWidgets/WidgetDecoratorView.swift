//
//  WidgetDecoratorView.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 29/11/22.
//

import Foundation
class WidgetDecoratorView: UICollectionReusableView {

    var topInset: CGFloat {
        return -8.0
    }
    
    var bottomInset: CGFloat {
        return 0
    }
    
    var css: LobbyCSS? {
        EpcotLobbyManager.shared?.css
    }
    
    var bgColor: UIColor {
        css?.jackpotWidgets?.widgetDecoratorBackgroundColor ?? .black
    }
    
    private var insetView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.clipsToBounds = true
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .clear
        self.insetView.backgroundColor = self.bgColor
        self.addSubview(self.insetView)

        NSLayoutConstraint.activate([
            self.insetView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 0),
            self.trailingAnchor.constraint(equalTo: self.insetView.trailingAnchor, constant: 0),
            self.insetView.topAnchor.constraint(equalTo: topAnchor, constant: topInset),
            self.insetView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: bottomInset)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class MultipleWidgetsDecoratorView: WidgetDecoratorView {
    override var bgColor: UIColor {
        return css?.jackpotWidgets?.multipleWidgetsDecoratorBackgroundColor ?? .black
    }
}

class MustGoWidgetDecoratorView: WidgetDecoratorView {
    override var bgColor: UIColor {
        return css?.jackpotWidgets?.mustGoWidgetDecoratorBackgroundColor ?? .black
    }
}
