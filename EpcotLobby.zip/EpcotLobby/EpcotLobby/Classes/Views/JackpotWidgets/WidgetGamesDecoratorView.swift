//
//  JackpotWidgetGamesDecoratorView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 06/03/23.
//

import Foundation

class WidgetGamesDecoratorView: WidgetDecoratorView {
    override var topInset: CGFloat {
        return 0.0
    }
    
    override var bottomInset: CGFloat {
        return -8.0
    }
}

class MultipleWidgetsGamesDecoratorView: WidgetGamesDecoratorView {
    override var topInset: CGFloat {
        return -0.5
    }
    
    override var bgColor: UIColor {
        return css?.jackpotWidgets?.multipleWidgetsDecoratorBackgroundColor ?? .black
    }
}

class MustGoWidgetGamesDecoratorView: WidgetGamesDecoratorView {
    override var bgColor: UIColor {
        return css?.jackpotWidgets?.mustGoWidgetDecoratorBackgroundColor ?? .black
    }
}
