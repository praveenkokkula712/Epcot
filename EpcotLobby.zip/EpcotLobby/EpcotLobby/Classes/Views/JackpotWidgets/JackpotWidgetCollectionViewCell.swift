//
//  JackpotWidgetCollectionViewCell.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 14/10/22.
//

import UIKit
import Combine
import Utility

class JackpotWidgetCollectionViewCell: UICollectionViewCell {

    @IBOutlet private weak var backgroundImageView  : UIImageView!
    @IBOutlet private weak var jackpotImageView     : UIImageView!
    @IBOutlet private weak var labelJackpotTitle    : UILabel!
    @IBOutlet private weak var labelJackpotPrice    : UILabel!
    
    private var pagingInfoToken: AnyCancellable?
    
    var jackpotModel: JackpotWidgetsModel? {
        didSet {
            self.backgroundImageView.image = nil
            self.backGroundImageUrl = jackpotModel?.backgroungImage
            self.jackpotImageUrl = jackpotModel?.jackpotImage
            self.labelJackpotTitle.text = jackpotModel?.jackpotName
        }
    }
    
    private var backGroundImageUrl: String? {
        didSet {
            if let backGroundImageUrl = backGroundImageUrl {
                self.backgroundImageView.loadImage(withUrl: backGroundImageUrl)
            }
        }
    }
    
    private var jackpotImageUrl: String? {
        didSet {
            if let jackpotImageUrl = jackpotImageUrl {
                self.jackpotImageView.loadImage(withUrl: jackpotImageUrl)
            }
        }
    }
    
    var jackpotAmount: String? {
        didSet {
            self.labelJackpotPrice.text = jackpotAmount
        }
    }
    
    private var css: JackpotTextCSS? {
        EpcotLobbyManager.shared?.css.jackpotWidgets?.singleJackpot
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.updateCss()
        self.addAccessibilityIdentifiers()
    }
    
    private func updateCss() {
        self.labelJackpotTitle.textColor = self.css?.title?.color ?? UIColor.white
        self.labelJackpotPrice.textColor = self.css?.price?.color ?? UIColor.yellow
        self.labelJackpotTitle.font = self.css?.title?.font
        self.labelJackpotPrice.font = self.css?.price?.font
    }
    
    func subscribeTo(subject: PassthroughSubject<[String: String]?, Never>) {
        pagingInfoToken = subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] values in
                guard let values = values else {
                    guard let jpAmount = self?.jackpotAmount?.jackpotCounterAmount else { return }
                    self?.jackpotAmount = jpAmount
                    return
                }
                if let gameVariantName = self?.jackpotModel?.jackpotGroupId,
                   let jpPrice = values[gameVariantName] {
                    self?.jackpotAmount = jpPrice
                }
            }
    }
    override func prepareForReuse() {
        super.prepareForReuse()
        self.pagingInfoToken?.cancel()
        self.pagingInfoToken = nil
    }
}

//MARK: Adding Accessibility Identifiers
extension JackpotWidgetCollectionViewCell {
    private func addAccessibilityIdentifiers() {
        backgroundImageView.accessibilityIdentifier = AccessibilityIdentifiers.jackpotwidgetcollection_backgroundImageView.rawValue
        jackpotImageView.accessibilityIdentifier = AccessibilityIdentifiers.jackpotwidgetcollection_jackpotImageView.rawValue
        labelJackpotTitle.accessibilityIdentifier = AccessibilityIdentifiers.jackpotwidgetcollection_labelJackpotTitle.rawValue
        labelJackpotPrice.accessibilityIdentifier = AccessibilityIdentifiers.jackpotwidgetcollection_labelJackpotPrice.rawValue
    }
}
