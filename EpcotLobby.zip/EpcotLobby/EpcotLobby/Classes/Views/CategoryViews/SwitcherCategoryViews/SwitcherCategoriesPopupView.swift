//
//  LobbyExplorePopupView.swift
//  CasinoLobby
//
//  Created by Vineela Janjirala on 24/01/22.
//

import UIKit
import CasinoAPI
import TrackerClient

class SwitcherCategoriesPopupView: EpcotBaseViewController {
    
    private let cellHeight = 44.0
    private let defaultPopupHeight : CGFloat = 252.0
    
    @IBOutlet private weak var tableViewCategories: UITableView!
    
    @IBOutlet private weak var labelHeaderTitle: UILabel!
    @IBOutlet private weak var labelCategoriesTitle: UILabel!
    @IBOutlet private weak var buttonApply: ResizableButton!
    @IBOutlet private weak var categoriesContainerView: UIView!
    @IBOutlet private weak var categoriesContainerViewHeight: NSLayoutConstraint!
    
    private var categories: [EntainSiteCoreItem] = [EntainSiteCoreItem]()
    /// Do NOT change at any time
    /// previousSelectedCategoryId --->> set default as FIRST category or Selected category from categories list
    private var previousSelectedCategoryId: String?
    
    
    private var css: ExploreLobbyCategeroiesPopUpCSS? {
        EpcotLobbyManager.shared?.css.exploreCategoriesPoppUpView
    }

    private var snapShot: CategorySnapshot?
    private var diffDatasource: SwitcherCategoryDatasource?
        
    /// Call back for updating the games based on category selection.
    var onCategorySelection: CategorySelectionHandler?

    
    //MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.updateCSS()
        self.setupTableView()
        self.addAccessibilityIdentifiers()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.applySnapShot()
        self.view.layoutIfNeeded()
    }
    
    /// delcaration for pop up view initialization.
    /// - Parameters:
    ///   - aView: UIView, where to be shown the popup
    ///   - siteCoreCategories: list of categories from SiteCore
    class func show(on aView: UIView,
                    siteCoreCategories: [EntainSiteCoreItem]) -> SwitcherCategoriesPopupView? {
        guard let topController = UIApplication.topViewController()
        else { return nil }
        let controller = SwitcherCategoriesPopupView.loadFromNib()
        controller.view.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        controller.categories = siteCoreCategories
        let height = controller.updatePopupViewHeight(topController: topController)
        if UIDevice.isIPad() {
            controller.modalPresentationStyle = .popover
            if let pctrl = controller.popoverPresentationController {
                pctrl.sourceView = aView
                let rect = aView.globalFrame ?? aView.bounds
                pctrl.sourceRect = rect
                pctrl.permittedArrowDirections = UIPopoverArrowDirection(rawValue:0)
                controller.popoverPresentationController?.sourceRect = CGRect(x: rect.minX , y: rect.maxY+rect.height , width: 0, height: 0)
                controller.preferredContentSize = CGSize(width: topController.view.frame.size.width * 0.5, height: height)
                pctrl.backgroundColor = controller.css?.backgroundColor
                pctrl.delegate = controller
            }
        } else {
            controller.modalPresentationStyle = .overCurrentContext
            controller.modalPresentationCapturesStatusBarAppearance = true
        }
        topController.present(controller, animated: true, completion: nil)
        return controller
    }
    
    /// Updates height of view based on categories count or default height or screen height
    /// - Parameter topController: UIViewController  -- where to present
    /// - Returns: CGFloat -- updated height
    private func updatePopupViewHeight(topController: UIViewController) -> CGFloat {
        let screenHeight = topController.view.frame.height
        let dynamicHeight = CGFloat(self.categories.count) * self.cellHeight + 120
        let height = (dynamicHeight < self.defaultPopupHeight) ? self.defaultPopupHeight : min(dynamicHeight, screenHeight)
        self.categoriesContainerViewHeight.constant = height
        return height
    }
    
    private func updateCSS() {
        self.labelHeaderTitle.text = Localize.exploreHeaderTitle
        self.labelHeaderTitle.textColor = css?.title?.color
        self.labelHeaderTitle.font = css?.title?.font
        
        self.labelCategoriesTitle.text = Localize.selectTitle
        self.labelCategoriesTitle.textColor = css?.categoryTitle?.color
        self.labelCategoriesTitle.font = css?.categoryTitle?.font
        
        self.buttonApply.titleLabel?.font = css?.applyButton?.title?.font
        self.buttonApply.backgroundColor = css?.applyButton?.normal
        self.buttonApply.setTitleColor(css?.applyButton?.title?.color, for: .normal)
        self.buttonApply.setTitle(Localize.applyBtnTitle, for: .normal)
        self.buttonApply.layer.cornerRadius = css?.applyButtonCornerRadius ?? 8.0
        self.buttonApply.layer.masksToBounds = true
        self.view.layer.masksToBounds = true
        self.view.layer.cornerRadius = UIDevice.isIPad() ? (css?.cornerRadius ?? 8.0) : 0
        self.view.backgroundColor = .clear
        
        self.categoriesContainerView.backgroundColor = css?.backgroundColor
        self.tableViewCategories?.separatorColor = css?.cellSeperatorColor
    }
}

extension SwitcherCategoriesPopupView {
    
    // MARK: - TableView Configuration
    private func setupTableView() {
        self.tableViewCategories?.registerNibCells(withCells: CellIdentifier.switcherCategoryPopUpTableViewCell,
                                                   bundle: kEpcotBundle)
        self.tableViewCategories?.delegate = self
        self.configureDatasource()
    }
    /// configuring UITableViewDiffableDataSource
    private func configureDatasource() {
        diffDatasource = SwitcherCategoryDatasource(tableView: self.tableViewCategories, cellProvider: { tableView, indexPath, itemIdentifier in
            self.cell(tableView: tableView, indexPath: indexPath, itemIdentifier: itemIdentifier)
        })
        self.tableViewCategories.dataSource = diffDatasource
    }
    
    /// creating Tableview cell
    private func cell(tableView: UITableView, indexPath: IndexPath, itemIdentifier: CategoryItem) -> UITableViewCell? {
        guard let cell = tableView.dequeueReusableCell(withIdentifier:
                                                        CellIdentifier.switcherCategoryPopUpTableViewCell,
                                                       for: indexPath) as? SwitcherCategoryPopUpTableViewCell else { return UITableViewCell() }
        guard case .category(let model) = itemIdentifier else {
            return cell
        }
        cell.category = model
        
        return cell
    }
    
    private func applySnapShot() {
        self.snapShot = CategorySnapshot()
        self.snapShot?.appendSections([.categories])
        if self.categories.filter({$0.title?.count ?? 0 > 0}).isEmpty {
            self.snapShot?.appendItems(CategoryItem.loadingItems, toSection: .categories)
        } else {
            self.setDefaultPreviousSelectedCategory()
            self.snapShot?.appendItems(self.categories.map(CategoryItem.category), toSection: .categories)
        }
        guard let snapShot = self.snapShot else { return }
        self.diffDatasource?.apply(snapShot, animatingDifferences: true)
    }
    
    /// Method to set previousSelectedCategoryId
    private func setDefaultPreviousSelectedCategory() {
        var item: EntainSiteCoreItem?
        if self.categories.filter({$0.isSelected == true}).count == 0 {
            item = self.categories.first
            item?.isSelected = true
        } else {
            item = self.categories.first(where: { $0.isSelected == true })
        }
        self.previousSelectedCategoryId = self.categories.first(where: { $0.isSelected == true })?.parameters?.id
        self.labelCategoriesTitle.text = item?.title ?? ""
    }
}

extension SwitcherCategoriesPopupView: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        self.cellHeight
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.categories.firstIndex(where: { $0.isSelected == true }) != indexPath.row {
            self.updateSelectedCategory(with: indexPath.row)
            self.labelCategoriesTitle.text = self.categories[indexPath.row].title ?? Localize.selectTitle
            if let categoryID = self.categories[indexPath.row].parameters?.id {
                self.trackEvent(categoryID: categoryID,
                                index: indexPath.row)
            }
        }
    }
    
    private func updateSelectedCategory(with index: Int) {
        let previousSelectedItem = self.categories.first(where: { $0.isSelected == true })
        previousSelectedItem?.isSelected = false
        self.categories[index].isSelected = true

        var items = [EntainSiteCoreItem]()
        if let item = previousSelectedItem {
            items.append(item)
        }
        items.append(self.categories[index])
        
        guard !items.isEmpty, var snapShot = self.diffDatasource?.snapshot() else { return }
        snapShot.reloadItems(items.map(CategoryItem.category))
        diffDatasource?.apply(snapShot, animatingDifferences: true)
    }
}

extension SwitcherCategoriesPopupView {
    
    @IBAction private func didApplySelected(_ sender: Any) {
        defer {
            self.dismiss(animated: true)
        }
        if let category = self.categories.first(where: { $0.isSelected == true }) {
            self.onCategorySelection?(category, GtmLogConstants.GeneralConstants.switecherCategory.rawValue)
        }
    }
    
    /// calls when action performs out side of pop up view
    /// - Parameter sender: tap action gestures or UIButton
    @IBAction private func dismissView(_ sender: Any) {
        self.resetSelectedCategorytoDefault()
        self.dismiss(animated: true)
    }
    
    /// calls when different category has selected, but not applied the changes --->> reset the category selection to previous selection in lobby View
    private func resetSelectedCategorytoDefault() {
        self.categories.first(where: { $0.isSelected == true })?.isSelected = false
        self.categories.first(where: { $0.parameters?.id == self.previousSelectedCategoryId })?.isSelected = true
    }
}

extension SwitcherCategoriesPopupView: UIPopoverPresentationControllerDelegate {
    
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
        .none
    }
    
    /// Calls when action performs outside of popover view (for iPad)
    func popoverPresentationControllerDidDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) {
        self.resetSelectedCategorytoDefault()
    }
    
}

extension SwitcherCategoriesPopupView {
    private func trackEvent(categoryID: String,
                            index: Int) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.filters.rawValue,
                                     actionEvent:EpcotEventAction.click.rawValue,
                                     labelEvent: EpcotEventLabel.subNavigation.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: categoryID,
                                     positionEvent: "\(index)")
            
            let event = TrackerEvent(type: .navigationFilters, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}

//MARK: Adding Accessibility Identifiers
extension SwitcherCategoriesPopupView {
    private func addAccessibilityIdentifiers() {
        tableViewCategories.accessibilityIdentifier = AccessibilityIdentifiers.switcherCategoryPopUp_tableViewCategories.rawValue
        labelHeaderTitle.accessibilityIdentifier = AccessibilityIdentifiers.switcherCategoryPopUp_labelHeaderTitle.rawValue
        labelCategoriesTitle.accessibilityIdentifier = AccessibilityIdentifiers.switcherCategoryPopUp_labelCategoriesTitle.rawValue
        buttonApply.accessibilityIdentifier = AccessibilityIdentifiers.switcherCategoryPopUp_buttonApply.rawValue
        categoriesContainerView.accessibilityIdentifier = AccessibilityIdentifiers.switcherCategoryPopUp_categoriesContainerView.rawValue
    }
}
