//
//  LobbySwitcherHeaderView.swift
//  CasinoLobby
//
//  Created by Gostu Bhargavi on 05/01/22.
//

import UIKit
import CasinoAPI

protocol SwitcherCategoryHeaderViewDelegate: AnyObject {
    /// switcher toggle click action
    func didClickedSwitcherToggle()
    func didClickedOnCategoryButton(sender : UIButton)
}

class SwitcherCategoryHeaderView: UIView {
    
    static let knibName = "SwitcherCategoryHeaderView"

    @IBOutlet private weak var labelHeaderTitle : UILabel!
    @IBOutlet private weak var lobbySwitcherButton : UIButton!
    @IBOutlet private weak var buttonCategoryTitle : UIButton!

    private(set) weak var delegate: SwitcherCategoryHeaderViewDelegate?
    private var selectedLobbyType: SwitcherCategoryType?
    
    var selectedCategory: EntainSiteCoreItem? {
        didSet {
            DispatchQueue.main.async {
                self.buttonCategoryTitle.setTitle(self.selectedCategory?.title ?? "", for: .normal)
            }
        }
    }
    
    private var lobbySwitcherIcon: String = kListLayoutIcon {
        didSet {
            self.lobbySwitcherButton.setImage(UIImage(named: lobbySwitcherIcon,
                                                      in: Bundle(for: SwitcherCategoryHeaderView.self),
                                                      compatibleWith: nil)?.withRenderingMode(.alwaysTemplate),
                                              for: .normal)
        }
    }
    
    private var css: ExploreLobbyViewCSS? {
        EpcotLobbyManager.shared?.css.exploreLobbyView
    }
    
    private var layoutType: SwitcherCategoryType {
        EpcotLobbyManager.shared?.lobbySwitcherType ?? .list
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupViews()
        self.addAccessibilityIdentifiers()
    }
    
    class func load(delegate: SwitcherCategoryHeaderViewDelegate? = nil) -> SwitcherCategoryHeaderView {
        if let headerView = SwitcherCategoryHeaderView.loadFromNib(knibName, Bundle(for: SwitcherCategoryHeaderView.self)) {
            headerView.delegate = delegate
            return headerView
        }
        return SwitcherCategoryHeaderView()
    }
    
    private func setupViews() {
        self.labelHeaderTitle.text = Localize.exploreHeaderTitle
        self.labelHeaderTitle.textColor = css?.title?.color
        self.labelHeaderTitle.font = css?.title?.font

        self.buttonCategoryTitle.setTitle(Localize.selectTitle, for: .normal)
        self.buttonCategoryTitle.setTitleColor(css?.categoriesTitle?.color, for: .normal)
        self.buttonCategoryTitle.titleLabel?.font = css?.categoriesTitle?.font
        self.buttonCategoryTitle.tintColor = css?.tintColor
        self.selectedLobbyType = layoutType
        self.lobbySwitcherIcon = layoutType.swappedValue.switcherCategoryLayoutIcon
        self.lobbySwitcherButton.tintColor = css?.switcherTintColor
        self.buttonCategoryTitle.setImage(UIImage(named: kDropDownIcon,
                                                  in: Bundle(for: SwitcherCategoryHeaderView.self),
                                                  compatibleWith: nil)?.withRenderingMode(.alwaysTemplate),
                                          for: .normal)
        self.backgroundColor = css?.backgroundColor
    }
    
    @IBAction private func lobbySwitcherToggleClicked() {
        let toggleLayout = self.selectedLobbyType?.swappedValue ?? .list
        self.lobbySwitcherIcon = self.selectedLobbyType?.switcherCategoryLayoutIcon ?? kListLayoutIcon
        self.selectedLobbyType = toggleLayout
        UserDefaults.lobbySwitcherType = toggleLayout.rawValue
        self.delegate?.didClickedSwitcherToggle()
    }
    
    @IBAction private func categoryButtonClicked(sender : UIButton) {
        self.delegate?.didClickedOnCategoryButton(sender: sender)
    }
}

//MARK: Adding Accessibility Identifiers
extension SwitcherCategoryHeaderView {
    private func addAccessibilityIdentifiers() {
        labelHeaderTitle.accessibilityIdentifier = AccessibilityIdentifiers.switcherCategoryHeader_labelHeaderTitle.rawValue
        lobbySwitcherButton.accessibilityIdentifier = AccessibilityIdentifiers.switcherCategoryHeader_lobbySwitcherButton.rawValue
        buttonCategoryTitle.accessibilityIdentifier = AccessibilityIdentifiers.switcherCategoryHeader_buttonCategoryTitle.rawValue
    }
}
