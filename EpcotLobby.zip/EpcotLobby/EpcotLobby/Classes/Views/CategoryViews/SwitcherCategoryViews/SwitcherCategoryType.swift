//
//  LobbySwitcherItem.swift
//  CasinoLobby
//
//  Created by Gostu Bhargavi on 11/01/22.
//

import Foundation
import UIKit

public enum SwitcherCategoryType: String {
    case list
    case grid
    
    var swappedValue: SwitcherCategoryType {
        switch self {
        case .list: return .grid
        case .grid: return .list
        }
    }
    
    var switcherCategoryLayoutIcon : String {
        switch self {
        case .list: return kListLayoutIcon
        case .grid: return kGridLayoutIcon
        }
    }
}
