//
//  LobbyExplorePopUpTableViewCell.swift
//  CasinoLobby
//
//  Created by Vineela Janjirala on 25/01/22.
//

import UIKit
import CasinoAPI

class SwitcherCategoryPopUpTableViewCell: UITableViewCell {
    @IBOutlet private weak var labelTitle: UILabel!
    @IBOutlet private weak var categorySelectionImage: UIImageView!
    
    var category: EntainSiteCoreItem? {
        didSet {
            self.updateCSS()
        }
    }

    private var css: ExploreLobbyCategeroiesPopUpCSS? {
        EpcotLobbyManager.shared?.css.exploreCategoriesPoppUpView
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        self.setDefaultCSS()
        self.addAccessibilityIdentifiers()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    private func setDefaultCSS() {
        self.selectionStyle = .none
        self.backgroundColor = .clear
        self.categorySelectionImage.tintColor = css?.tintColor
        self.categorySelectionImage.backgroundColor = css?.cellTitleSelected?.color
        self.categorySelectionImage.image = UIImage(named: kcheckMarkIcon,
                                                    in: Bundle(for: SwitcherCategoryPopUpTableViewCell.self),
                                                    compatibleWith: nil)?.withRenderingMode(.alwaysOriginal)
        self.categorySelectionImage.getRoundedCorners(OfRadius: self.categorySelectionImage.frame.height/2)

        self.labelTitle.font = css?.cellTitleNormal?.font
        
        self.updateCSS()
    }
    
    private func updateCSS() {
        self.labelTitle.text = self.category?.title ?? ""
        self.labelTitle.textColor = (self.category?.isSelected ?? false) ? css?.cellTitleSelected?.color : css?.cellTitleNormal?.color
        self.categorySelectionImage.isHidden = !(self.category?.isSelected ?? false)
    }
}

//MARK: Adding Accessibility Identifiers
extension SwitcherCategoryPopUpTableViewCell {
    private func addAccessibilityIdentifiers() {
        labelTitle.accessibilityIdentifier = AccessibilityIdentifiers.switcherCategoryTable_labelTitle.rawValue
        categorySelectionImage.accessibilityIdentifier = AccessibilityIdentifiers.switcherCategoryTable_categorySelectionImage.rawValue
    }
}
