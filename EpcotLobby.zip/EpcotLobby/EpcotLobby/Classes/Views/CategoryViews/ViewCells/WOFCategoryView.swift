//
//  WOFCategoryView.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 22/02/23.
//

import SwiftUI
import CasinoAPI
import Utility

struct WOFCategoryView: View {
    
    @ObservedObject var order: CategoryPublishedModel
    
    var onClickCategory: ((_ categoryId: EntainSiteCoreItem?) -> Bool)
    @Namespace var namespace
    
    let screenWidth = UIDevice.screenSize.width
    
    var css: LobbyCSS? {
        EpcotLobbyManager.shared?.css
    }
    
    var body: some View {
        ScrollViewReader { scrollView in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 25) {
                    ForEach(Array(zip(order.siteCoreItems.indices, order.siteCoreItems)), id: \.1.uuid, content:  { index, item in
                        let id = item.parameters?.id
                        VStack(alignment: .center) {
                            Button {
                                withAnimation {
                                    if self.onClickCategory(item) {
                                        order.currentId = item.uuid
                                        scrollView.scrollTo(order.currentId, anchor: anchor)
                                    }
                                }
                            } label: {
                                VStack(alignment: .center, spacing: 2) {
                                    Text(item.wofIcon)
                                        .font(item.wofIconFont)
                                        .foregroundColor(item.wofIconTextColor)
                                        .frame(width: 24, height: 24)
                                    Text("  " + (item.title ?? "") + "  ")
                                        .font(item.normalTextFont)
                                        .foregroundColor(item.wofTextColor)
                                }
                            }
                            .accessibility(identifier: id ?? "")
                            .buttonStyle(GradientButtonStyle())
                            .padding(.top, 9)
                            if order.currentId == item.uuid {
                                item.wofSeperatorColor
                                    .frame(height: 4)
                                    .cornerRadius(2)
                                    .matchedGeometryEffect(id: "animation", in: namespace)
                            } else {
                                Color.clear
                                    .frame(height: 4)
                                    .cornerRadius(2)
                            }
                        }
                    })
                }
                .padding(.horizontal, 12)
            }
            .onChange(of: order.siteCoreItems) { newValue in
                withAnimation {
                    scrollView.scrollTo(order.currentId, anchor: anchor)
                }
            }
            .onReceive(order.$siteCoreItems, perform: { _ in
                withAnimation {
                    scrollView.scrollTo(order.currentId, anchor: anchor)
                }
            })
        }
    }
}
