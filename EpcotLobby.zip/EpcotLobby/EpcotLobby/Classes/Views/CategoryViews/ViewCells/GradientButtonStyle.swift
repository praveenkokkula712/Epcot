//
//  GradientButtonStyle.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 22/02/23.
//

import Foundation
import SwiftUI

struct GradientButtonStyle: ButtonStyle {
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.8 : 1.0)
    }
}
