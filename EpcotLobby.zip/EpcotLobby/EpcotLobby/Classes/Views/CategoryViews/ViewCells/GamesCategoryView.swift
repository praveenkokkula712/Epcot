//
//  GamesCategoryView.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 20/02/23.
//

import SwiftUI
import Utility
import CasinoAPI
import Combine

struct GamesCategoryView: View {
    
    @ObservedObject var order: CategoryPublishedModel
    var onClickCategory: ((_ categoryId: EntainSiteCoreItem?) -> Bool)
    @Namespace var namespace
    
    var css: LobbyCSS? {
        EpcotLobbyManager.shared?.css
    }
    
    var body: some View {
        ScrollViewReader { scrollView in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(Array(zip(order.siteCoreItems.indices, order.siteCoreItems)), id: \.1.uuid, content:  { index, item in
                        let id = item.parameters?.id
                        VStack {
                            Spacer()
                            Button {
                                withAnimation {
                                    if self.onClickCategory(item) {
                                        order.currentId = item.uuid
                                        scrollView.scrollTo(order.currentId, anchor: anchor)
                                    }
                                }
                            } label: {
                                Text(item.title ?? "")
                                    .font(order.currentId == item.uuid ? item.selectedTextFont : item.normalTextFont)
                                    .foregroundColor(order.currentId == item.uuid ? item.selectedTextColor : item.normalTextColor)
                                    .if(shouldApplyPadding) { view in
                                        view.fixedSize(horizontal: true, vertical: false)
                                    }
                            }
                            .accessibility(identifier: id ?? "")
                            .buttonStyle(GradientButtonStyle())
                            .padding(.horizontal, 8)
                            
                            if order.currentId == item.uuid {
                                item.selectedSeperatorColor
                                    .frame(height: 6)
                                    .cornerRadius(12)
                                    .matchedGeometryEffect(id: "animation", in: namespace)
                            } else {
                                Color.clear
                                    .frame(height: 6)
                                    .cornerRadius(12)
                            }
                        }
                    })
                }
                .padding(.horizontal, 16)
            }
            .padding(.bottom, -3)
            .onChange(of: order.siteCoreItems) { newValue in
                withAnimation {
                    scrollView.scrollTo(order.currentId, anchor: anchor)
                }
            }
            .onReceive(order.$siteCoreItems, perform: { _ in
                withAnimation {
                    scrollView.scrollTo(order.currentId, anchor: anchor)
                }
            })
            .background(Color(css?.gridView?.categoryViewbackgroundColor ?? .gray))
            .edgesIgnoringSafeArea(.top)
        }
        .onRotate(perform: { _ in
            if UIDevice.isIPad() {
                if let currentJourney = UserOnboardingViewModel.shared?.currentUserJourney {
                    if currentJourney.type == .category {
                        UserOnboardingViewModel.shared?.updateViewsOnRotation()
                    }
                }
            }
        })
    }
}
