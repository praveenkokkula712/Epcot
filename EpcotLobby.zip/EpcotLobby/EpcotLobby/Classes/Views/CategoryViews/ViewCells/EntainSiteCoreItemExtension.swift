//
//  EntainSiteCoreItemExtension.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 22/02/23.
//

import Foundation
import CasinoAPI
import Utility
import SwiftUI

extension EntainSiteCoreItem: Equatable {
    
    var dataSource: EpcotLobbyViewDataSource? {
        EpcotLobbyManager.shared?.datasource
    }
    
    var css: CategoryView? {
        EpcotLobbyManager.shared?.css.gridView?.categoryView
    }
    
    var selectedTextFont: Font {
        Font(css?.selected?.font ?? .boldSystemFont(ofSize: 12))
    }
    
    var selectedTextColor: Color {
        Color(css?.selected?.color ?? .green)
    }
    
    var normalTextFont: Font {
        Font(css?.normal?.font ?? .systemFont(ofSize: 12))
    }
    
    var normalTextColor: Color {
        Color(css?.normal?.color ?? .green)
    }
    
    var selectedSeperatorColor: Color {
        Color(css?.separatorLineColor ?? .green)
    }
    
    var wofTextColor: Color {
        Color(self.parameters?.textCss?.titleNormalColor ?? .white)
    }
    
    var wofBackgroundColor: Color {
        Color(self.parameters?.viewCss?.backgroundColor ?? UIColor.hexStringToUIColor(hex: "#353541"))
    }
    
    var iconVariant: IconVariant? {
        self.dataSource?.didRequestForIconVariant(with: self.parameters?.iconCss?.nativeIcon ?? "icon-Games", fontSize: EpcotLobbyManager.shared?.css.categoriesIconFontSize ?? 16.0)
    }
    
    var wofIcon: String {
        iconVariant?.icon ?? ""
    }
    
    var wofIconFont: Font {
        Font(iconVariant?.font ?? .systemFont(ofSize: 12))
    }
    
    var wofIconTextColor: Color {
        Color(self.parameters?.iconCss?.nativeIconColor ?? UIColor.hexStringToUIColor(hex: "#FFFFFF"))
    }
    var wofSeperatorColor: Color {
        Color(self.parameters?.viewCss?.selectedBgColor ?? UIColor.hexStringToUIColor(hex: "#FFFFFF"))
    }
}
