//
//  CategoryPublishedModel.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 22/02/23.
//

import SwiftUI
import CasinoAPI
import Utility

class CategoryPublishedModel: ObservableObject {
    @Published var currentId: UUID = UUID()
    @Published var siteCoreItems = [EntainSiteCoreItem]()
    var headerType: LobbyHeaderType = .gamesCategories
}

