//
//  File.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 22/07/22.
//

import UIKit
import Foundation

class EpcotCategoryCell: EpcotBaseCollectionViewCell {
    var categoryModel: EntainSiteCoreItem?
}
