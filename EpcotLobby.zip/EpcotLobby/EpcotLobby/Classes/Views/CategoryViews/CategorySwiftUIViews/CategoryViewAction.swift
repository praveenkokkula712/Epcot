//
//  CategoryViewAction.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 09/06/23.
//

import Foundation
import CasinoAPI

enum CategoryViewAction {
    case close(EntainSiteCoreItem)
    case grid(String)
    case list(String)
    case categorySelection(EntainSiteCoreItem)
    
    var imageName: String {
        switch self {
        case .close:
            return kCloseWhite
        case .grid(let string):
            return string
        case .list(let string):
            return string
        case .categorySelection(let entainSiteCoreItem):
            return ""
        }
    }
}
