//
//  EpcotCategoriesView+Switcher.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 10/06/23.
//

import Foundation
import SwiftUI
import Utility

extension EpcotCategoriesView {
    
    var switcherButtonsView: some View {
        HStack(spacing: 16) {
            self.getSwitcherButton(with: .grid(kGridLayoutIcon)) { _ in
                withAnimation (instantInteractionAnimation) {
                    interactions.switcherGridInteracted = 1
                    self.action(.grid(""))
                    self.setSelectedSwitcherLayout()
                }
            }
            .background(
                interactions.switcherGridInteracted == 0 ? Color.clear : self.getTintColor(with: .grid("")).instantInteractionOverlay40
            )
            .onAnimationCompleted(for: interactions.switcherGridInteracted) {
                interactions.switcherGridInteracted = 0
            }
            self.getSwitcherButton(with: .list(kListLayoutIcon)) { _ in
                withAnimation (instantInteractionAnimation) {
                    interactions.switcherListInteracted = 1
                    self.action(.list(""))
                    self.setSelectedSwitcherLayout()
                }
            }
            .background(
                interactions.switcherListInteracted == 0 ? Color.clear : self.getTintColor(with: .list("")).instantInteractionOverlay40
            )
            .onAnimationCompleted(for: interactions.switcherListInteracted) {
                interactions.switcherListInteracted = 0
            }
        }
        .padding(.trailing, 16)
        .onAppear {
            interactions.switcherGridInteracted = 0
            interactions.switcherListInteracted = 0
        }
    }
    
}
