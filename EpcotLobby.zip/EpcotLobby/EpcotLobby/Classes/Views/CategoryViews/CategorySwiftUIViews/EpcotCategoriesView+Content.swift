//
//  EpcotCategoriesView+Content.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 09/06/23.
//

import Foundation
import SwiftUI
import CasinoAPI
import Utility

extension EpcotCategoriesView {
    func createContentView(with item: EntainSiteCoreItem, action: @escaping itemSelectionAction) -> some View {
        HStack(spacing: 4) {
            item.iconView
            HStack(spacing: 4) {
                item.titleView
                item.countView
            }
            .padding(.trailing, 12)
        }
        .frame(height: 34)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .stroke(item.epcotBorderColor,lineWidth: 2)
                .frame(height: 32)
                .background(
                    interactions.categoryInteracted == 0 ? item.containerBackgroundColor : item.containerBackgroundColor.withAlphaComponent(0.4)
                )
                .cornerRadius(16)
        )
        .zIndex(1)
        .onTapGesture {
            guard !item.isSelected else { return }
            withAnimation (instantInteractionAnimation) {
                interactions.categoryInteracted = 1
                action(item)
            }
        }
        .onAnimationCompleted(for: interactions.categoryInteracted) {
            interactions.categoryInteracted = 0
        }
    }
}
