//
//  Epcot+EntainSiteCore+Views.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 09/06/23.
//

import Foundation
import SwiftUI
import CasinoAPI
import ConfigModule

extension EntainSiteCoreItem {
    
    var iconView: some View {
        Group {
            if self.isEpcotSVGImageAvailable,
                let imageUrl = self.epcotSvgIconUrl {
                imageUrl.svgImage
            } else {
                Text(self.epcotIcon)
                    .font(self.epcotIconFont)
                    .foregroundColor(self.epcotIconColor)
                    .padding(.leading, 12)
                    .padding(.trailing, 4)
                    .minimumScaleFactor(0.5)
            }
        }
    }
    
    var titleView: some View {
        var title = self.title
        if let displayType = self.parameters?.displayType {
            title = title?.getString(for: NamingConfiguration(rawValue: displayType))
        }
        return Text(title ?? "")
            .foregroundColor(self.epcotTitleColor)
            .font(self.epcotTitleFont)
            .padding(.top, 2)
    }
    
    var countView: some View {
        Group {
            if let count = self.parameters?.stickerGameCount, count != 0, !self.isSelected {
                Text("\(count)")
                    .foregroundColor(self.stickerTextColor)
                    .font(self.stickerFont)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(self.stickerBackgroundColor)
                    .cornerRadius(20)
            } else {
                EmptyView()
                    .frame(width: 0,height: 0)
            }
        }
    }
}
