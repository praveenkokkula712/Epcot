//
//  EpcotCategoriesView.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 08/06/23.
//

import SwiftUI
import CasinoAPI
import SVGKit

struct EpcotCategoriesView: View {
    
    @ObservedObject var viewModel = EpcotCategoryPublishedModel()
    var action: (_ action: CategoryViewAction) -> Void
    @State var isGridLayoutSelected = false
    @State var isListLayoutSelected = false
    @State var animationDuration = 0.1
    @ObservedObject var interactions = EpcotCategoryInstantIneraction()
    
    var body: some View {
        HStack {
            VStack {
                ScrollView(.horizontal, showsIndicators: false)  {
                    HStack(spacing: 8) {
                        ForEach(viewModel.items, id: \.uuid) { item in
                            HStack(spacing: 12) {
                                if item.isSelected {
                                    self.closeButtonView(with: item) { selectedItem in
                                        self.animationDuration = 0.3
                                        self.action(.close(selectedItem))
                                    }
                                    .onAppear {
                                        interactions.categoryCloseInteracted = 0
                                    }
                                }
                                self.createContentView(with: item) { selectedItem in
                                    self.animationDuration = 0.1
                                    self.action(.categorySelection(selectedItem))
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 8)
                }
                .animation(.easeInOut(duration: animationDuration))
            }
            if self.viewModel.isLinkedCategory {
                Spacer()
                self.switcherButtonsView
            }
        }
       .frame(height: 44)
       .onAppear {
           UIScrollView.appearance().bounces = false
           self.setSelectedSwitcherLayout()
       }
       .onDisappear {
           UIScrollView.appearance().bounces = true
       }
       .onReceive(self.viewModel.$items) { _ in
           self.setSelectedSwitcherLayout()
       }
   }
    
    func setSelectedSwitcherLayout() {
        let layout = EpcotLobbyManager.shared?.lobbySwitcherType ?? .grid
        self.isGridLayoutSelected = layout == .grid
        self.isListLayoutSelected = layout == .list
    }
}

struct EpcotCategoriesView_Previews: PreviewProvider {
    static var previews: some View {
        EpcotCategoriesView { _ in }
    }
}
