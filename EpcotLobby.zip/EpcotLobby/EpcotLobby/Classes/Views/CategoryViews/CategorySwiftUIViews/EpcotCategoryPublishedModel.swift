//
//  EpcotCategoryPublishedModel.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 10/06/23.
//

import Foundation
import SwiftUI
import CasinoAPI

class EpcotCategoryPublishedModel: ObservableObject {
    @Published var items = [EntainSiteCoreItem]()
    var selectedItems = [EpcotCategorySelection]()
    @Published var isLinkedCategory: Bool = false
}

struct EpcotCategorySelection {
    var item: EntainSiteCoreItem
    var jackpotModel: JackPotModel?
    var categoryId: String?
    var subCategoryId: String?
    var isSeeMoreItem: Bool?
}
