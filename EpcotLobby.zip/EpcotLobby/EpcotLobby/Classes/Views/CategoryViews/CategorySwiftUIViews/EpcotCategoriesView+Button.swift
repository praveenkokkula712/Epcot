//
//  EpcotCategoriesView+Button.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 09/06/23.
//

import Foundation
import SwiftUI
import Utility
import CasinoAPI

extension EpcotCategoriesView {
    
    typealias itemSelectionAction = (_ item:EntainSiteCoreItem) -> Void
    typealias switcherSelection = (_ selection: CategoryViewAction) -> Void
    
    func closeButtonView(with item: EntainSiteCoreItem, action: @escaping itemSelectionAction) -> some View {
        HStack {
            Button {
                withAnimation (instantInteractionAnimation) {
                    interactions.categoryCloseInteracted = 1
                    action(item)
                }
            } label: {
                kCloseWhite.image
                    .colorMultiply(.white)
            }
        }
        .foregroundColor(item.categoryHeaderCloseIconColor)
        .frame(width: 32,height: 32)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(item.epcotBorderColor, lineWidth: 1)
                .background(
                    interactions.categoryCloseInteracted == 0 ? Color.clear : Color.white.withAlphaComponent(0.4)
                )
        )
        .onAnimationCompleted(for: interactions.categoryCloseInteracted) {
            interactions.categoryCloseInteracted = 0
        }
    }
    
    func getSwitcherButton(with action: CategoryViewAction, selection: @escaping switcherSelection) -> some View {
        return Button {
            selection(action)
        } label: {
            action.imageName.image
                .colorMultiply(self.getTintColor(with: action))
        }
        .foregroundColor(.white)
        .frame(width: 16,height: 16)
    }
    
    func getTintColor(with action: CategoryViewAction) -> Color {
        var color = Color.white
        let css = EpcotLobbyManager.shared?.css
        let selectedColor = (css?.seeMoreSectionView?.switcherSelectedColor) ?? UIColor.hexStringToUIColor(hex: "#fffff")
        let unselectedColor = (css?.seeMoreSectionView?.switcherUnselectedColor) ?? UIColor.hexStringToUIColor(hex: "#ADADAD")
        let currentLayout = EpcotLobbyManager.shared?.lobbySwitcherType ?? .grid
        switch action {
        case .grid(let _):
            color = (currentLayout == .grid || self.isGridLayoutSelected) ? Color(selectedColor) : Color(unselectedColor)
        case .list(let _):
            color = (currentLayout == .list || self.isListLayoutSelected) ? Color(selectedColor) : Color(unselectedColor)
        case .categorySelection(let _), .close:
            break
        }
        return color
    }
}

extension String {
    
    var image: Image {
        let image = UIImage(named: self,
                in: kEpcotBundle,
                compatibleWith: nil) ?? UIImage()
        return Image(uiImage: image)
            .renderingMode(.template)
    }
    
}
