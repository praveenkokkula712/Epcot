//
//  EpcotMenuHeaderView.swift
//  EpcotLobby
//
//  Created by Challa Venkata Narasimha Karthik on 19/04/22.
//

import UIKit

class EpcotMenuHeaderView: EpcotBaseHeaderView {
    override func configureView() {
        let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS
        self.titleLabel.font = css?.menuViewCSS?.sectionHeaderTitle?.font
        self.titleLabel.textColor = css?.menuViewCSS?.sectionHeaderTitle?.color
    }
}
