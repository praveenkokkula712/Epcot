//
//  MenuViewController.swift
//  EpcotSample
//
//  Created by Gostu Bhargavi on 21/03/22.
//

import UIKit
import CasinoAPI
import TrackerClient
import Utility
import SDWebImageSVGCoder

class EpcotMenuViewController: EpcotBaseViewController {

    @IBOutlet private weak var collectionView : UICollectionView!
    @IBOutlet private weak var buttonDone: UIButton!
    @IBOutlet weak var menuHeaderView: UIView!
    @IBOutlet weak var casinoLbl: UILabel!
    @IBOutlet weak var headerSeperatorView: UIView!
    @IBOutlet var collectionViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet var menuHeaderViewTopConstraint: NSLayoutConstraint!
    @IBOutlet var menuHeaderViewBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var dismissButton: UIButton!

    var categorySelected: CategorySelectionHandler?
    var onWebCategorySelection:((EntainSiteCoreItem) -> Void)?
    var onDismiss: ((() -> Void))?
    
    var burgerMenuItems: BurgerMenuItems = [EpcotMenuSection.featured: ([EntainSiteCoreItem()],"")] {
        didSet {
            DispatchQueue.main.async {
                if oldValue.values.isEmpty {
                    self.snapShot?.deleteSections([.featured, .foryou, .appAds])
                    guard let snapShot = self.snapShot else {return}
                    self.diffDatasource?.apply(snapShot, animatingDifferences: false)
                }
                self.applySnapShot()
            }
        }
    }
    
    private var diffDatasource: MenuDatasource?
    private var snapShot: MenuSnapshot?

    convenience init() {
        self.init(nibName: CellIdentifier.epcotMenuViewController,
                  bundle: Bundle(for: EpcotMenuViewController.self))
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupViews()
        self.setupCollectionView()
        self.addAccessibilityIdentifiers()
        let SVGCoder = SDImageSVGCoder.shared
        SDImageCodersManager.shared.addCoder(SVGCoder)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !UIDevice.isIPad() {
            let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS?.menuViewCSS
            self.menuHeaderView.roundCorners(corners: [.topLeft, .topRight], radius: css?.headerCornerRadius ?? 10.0)
        }
    }
    
    @IBAction func actionDone(_ sender: UIButton) {
        let instantInteraction = InteractionType.opacity.interaction
        sender.tapAnimation(type: instantInteraction) {
            self.onDismiss?()
        }
    }
    
    //MARK: - Datasource and snapshot setup.
    private func configureDatasource() {
        guard self.collectionView != nil else { return }
        diffDatasource = MenuDatasource(collectionView: self.collectionView, cellProvider: { collectionView, indexPath, itemIdentifier in
            self.cell(collectionView: collectionView, indexPath: indexPath, itemIdentifier: itemIdentifier)
        })
        configureHeaderDatasource()
        applySnapShot()
    }
    
        /// Header / supplementary view setup
    private func configureHeaderDatasource() {
        diffDatasource?.supplementaryViewProvider = { collectionView, kind, indexPath in
            guard kind == UICollectionView.elementKindSectionHeader else {
                return nil
            }
            
            let sectionType = EpcotMenuSection(rawValue: indexPath.section)
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind,
                                                                       withReuseIdentifier: EpcotBaseHeaderView.identifier,
                                                                       for: indexPath) as? EpcotMenuHeaderView
            switch sectionType {
            case .featured:
                headerView?.titleLabel.text = self.burgerMenuItems[.featured]?.headerTitle ?? Localize.featured
            case .foryou:
                headerView?.titleLabel.text = self.burgerMenuItems[.foryou]?.headerTitle ?? Localize.forYou
            case .appAds, .none, .headerBar: break
            }
            return headerView
        }
    }
    
        /// Cell setup based on the datasourcce
        /// - Parameters:
        ///   - collectionView: collection view
        ///   - indexPath: indexPath of the item to be dispalyed.
        ///   - itemIdentifier: item Id for dispalying purpose which will hold either category Item or loading item
        /// - Returns: UIcollectionView cell.
    private func cell(collectionView: UICollectionView, indexPath: IndexPath, itemIdentifier: MenuItem) -> UICollectionViewCell? {
        switch itemIdentifier {
        case .loading( _):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.categoriesCell, for: indexPath) as? EpcotMenuCustomCell
            cell?.showLoading()
            return cell
        case .featured(let model):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.categoriesCell, for: indexPath) as? EpcotMenuCustomCell
            cell?.configureView(with: model)
            return cell
        case .foryou(let model):
            let recommendationCell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.recommendationCell, for: indexPath) as? EpcotRecommendationCollectionViewCell
            recommendationCell?.model = model
            return recommendationCell
        case .app(let model):
            let appCell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.appPromoCell, for: indexPath) as? AppPromotionCollectionViewCell
            appCell?.configureView(with: model)
            return appCell
        }
    }
    
        /// will apply the snapshot
    private func applySnapShot() {
        guard self.collectionView != nil else { return }
        snapShot = MenuSnapshot()
        snapShot?.appendSections([.featured, .foryou, .appAds])
        if self.burgerMenuItems.values.isEmpty {
            snapShot?.appendItems(MenuItem.loadingItems, toSection: .featured)
        } else {
            if let items = self.burgerMenuItems[.featured]?.items, !items.isEmpty {
                snapShot?.appendItems(items.map(MenuItem.featured), toSection: .featured)
            }
            if let items = self.burgerMenuItems[.foryou]?.items, !items.isEmpty  {
                snapShot?.appendItems(items.map(MenuItem.foryou), toSection: .foryou)
            }
            if let items = self.burgerMenuItems[.appAds]?.items, !items.isEmpty  {
                snapShot?.appendItems(items.map(MenuItem.app), toSection: .appAds)
            }
        }
        guard let snapShot = snapShot else { return }
        diffDatasource?.apply(snapShot, animatingDifferences: true, completion: {
            if !UIDevice.isIPad() {
                let height = self.collectionView.collectionViewLayout.collectionViewContentSize.height + 56
                if height < UIDevice.screenSize.height {
                    self.collectionViewHeightConstraint?.constant = height
                    let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS?.menuViewCSS
                    self.menuHeaderView.roundCorners(corners: [.topLeft, .topRight], radius: css?.headerCornerRadius ?? 10.0)
                }
            }  
        })
    }
    
    deinit {
        ETLogger.debug("Deinit \(type(of: self))")
    }
}

extension EpcotMenuViewController {
    
    private func setupViews() {
        //css form main.nss
        
        if UIDevice.isIPad() {
            NSLayoutConstraint.deactivate([
                self.collectionViewHeightConstraint
            ])
            NSLayoutConstraint.activate([
                self.menuHeaderViewTopConstraint
            ])
        } else {
            NSLayoutConstraint.deactivate([
                self.menuHeaderViewTopConstraint
            ])
            NSLayoutConstraint.activate([
                self.collectionViewHeightConstraint
            ])
        }
        self.view.layoutIfNeeded()
        
        let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS
        self.buttonDone.setTitle(Localize.done, for: .normal)
        self.buttonDone.titleLabel?.font = css?.menuViewCSS?.doneTitle?.font
        self.buttonDone.setTitleColor(css?.menuViewCSS?.doneTitle?.color, for: .normal)
        
        self.menuHeaderView.backgroundColor = css?.menuViewCSS?.headerBGColor
        
        self.casinoLbl.font = css?.menuViewCSS?.headerTitle?.font
        self.casinoLbl.textColor = css?.menuViewCSS?.headerTitle?.color
        self.casinoLbl.text = self.burgerMenuItems[.headerBar]?.headerTitle ?? Localize.casino
    }
    
    @IBAction private func dismissView() {
        self.onDismiss?()
    }
    
    func clearView() {
        self.categorySelected = nil
        self.onWebCategorySelection = nil
        self.onDismiss = nil
        self.diffDatasource = nil
        self.snapShot = nil
        guard self.collectionView != nil else { return }
        self.collectionView.removeFromSuperview()
        self.collectionView = nil
    }
}

//MARK: - Collection View Setup
extension EpcotMenuViewController {
    
    private func configureHierarchy() {
        func configureLayout() -> UICollectionViewCompositionalLayout {
            let layout = UICollectionViewCompositionalLayout { (sectionIndex: Int,
                                                                layoutEnvironment: NSCollectionLayoutEnvironment) -> NSCollectionLayoutSection? in
                switch EpcotMenuSection(rawValue: sectionIndex) {
                case .featured:
                    guard !(self.burgerMenuItems[.featured]?.items.isEmpty ?? true) else { return nil }
                    return CustomLayoutSection.listLayoutSection()
                case .foryou:
                    guard !(self.burgerMenuItems[.foryou]?.items.isEmpty ?? true) else { return nil }
                    let section: NSCollectionLayoutSection = CustomLayoutSection.listLayoutSection()
                    section.contentInsets = NSDirectionalEdgeInsets(horizontal: 16, vertical: 0)
                    return section
                case .appAds:
                    guard !(self.burgerMenuItems[.appAds]?.items.isEmpty ?? true) else { return nil }
                    return CustomLayoutSection.inAppAdsLayoutSection()
                case .none, .headerBar:
                    return nil
                }
            }
            return layout
        }
        guard self.collectionView != nil else { return }
        self.collectionView.collectionViewLayout = configureLayout()
    }
    
    private func setupCollectionView() {
        self.collectionView.contentInset = UIEdgeInsets(top: 16, left: 0, bottom: 0, right: 0)
        self.configureHierarchy()
        // Registering cell
        self.collectionView.registerNibCells(withCells: CellIdentifier.categoriesCell,CellIdentifier.recommendationCell,CellIdentifier.appPromoCell, bundle: kEpcotBundle)
        // Registering header view
        self.collectionView.register(EpcotMenuHeaderView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: EpcotBaseHeaderView.identifier)
        self.collectionView.delegate = self
        self.configureDatasource()
    }
}

//MARK: - Collection View Delegates
extension EpcotMenuViewController: UICollectionViewDelegate  {    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let cell = collectionView.cellForItem(at: indexPath) else { return }
        let sectionType = EpcotMenuSection(rawValue: indexPath.section) ?? .featured
        switch sectionType {
        case .featured, .foryou:
            let instantInteraction = InteractionType.opacity.interaction
            cell.tapAnimation(type: instantInteraction) {
                if let featuredItems = self.burgerMenuItems[sectionType]?.items {
                    let featureItem = featuredItems[indexPath.row]
                    featureItem.isSelected = true
                    self.categorySelected?(featureItem, GtmLogConstants.GeneralConstants.sectionMenu.rawValue)
                }
            }
        case .appAds:
            let instantInteraction = InteractionType.opacity.interaction
            cell.tapAnimation(type: instantInteraction) {
                if let items = self.burgerMenuItems[.appAds]?.items {
                    let item = items[indexPath.row]
                    self.onWebCategorySelection?(item)
                }
            }
        case .headerBar: break
        }
    }
}

//MARK: Adding Accessibility Identifiers
extension EpcotMenuViewController {
    private func addAccessibilityIdentifiers() {
        collectionView.accessibilityIdentifier = AccessibilityIdentifiers.epcotmenu_collectionView.rawValue
        buttonDone.accessibilityIdentifier = AccessibilityIdentifiers.epcotmenu_buttonDone.rawValue
        menuHeaderView.accessibilityIdentifier = AccessibilityIdentifiers.epcotmenu_menuHeaderView.rawValue
        casinoLbl.accessibilityIdentifier = AccessibilityIdentifiers.epcotmenu_casinoLbl.rawValue
        headerSeperatorView.accessibilityIdentifier = AccessibilityIdentifiers.epcotmenu_headerSeperatorView.rawValue
        dismissButton.accessibilityIdentifier = AccessibilityIdentifiers.epcotmenu_dismissButton.rawValue
    }
}
