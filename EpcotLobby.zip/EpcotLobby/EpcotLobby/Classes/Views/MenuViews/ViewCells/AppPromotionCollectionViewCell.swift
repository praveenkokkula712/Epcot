//
//  AppPromotionCollectionViewCell.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 11/05/22.
//

import UIKit
import CasinoAPI

class AppPromotionCollectionViewCell: EpcotBaseCollectionViewCell {
    
    @IBOutlet private weak var imageViewIcon: UIImageView!
    @IBOutlet private weak var labelTitle: UILabel!
    @IBOutlet private weak var labelDescription: UILabel!
    
    private let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS

    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupViews()
    }
    
    private func setupViews() {
        contentView.layer.backgroundColor = css?.menuViewCSS?.appAdsBGColor?.cgColor
        self.layer.cornerRadius = 16
        self.updateShadow()
        self.imageViewIcon.getRoundedCorners(OfRadius: 4)
        self.addAccessibilityIdentifiers()
    }
    
    func configureView(with model: EntainSiteCoreItem) {
        if let imageUrl = model.image?.imageUrl {
            self.imageViewIcon.loadImage(withUrl: imageUrl)
        }
        self.labelTitle.text = model.title
        self.labelDescription.text = model.parameters?.subTitle ?? ""
        self.labelTitle.textColor = css?.menuViewCSS?.appAdsTitle?.color
        self.labelDescription.textColor = css?.menuViewCSS?.appAdsDescription?.color
        self.labelTitle.font = css?.menuViewCSS?.appAdsTitle?.font
        self.labelDescription.font = css?.menuViewCSS?.appAdsDescription?.font
    }
}

//MARK: Adding Accessibility Identifiers
extension AppPromotionCollectionViewCell {
    private func addAccessibilityIdentifiers() {
        imageViewIcon.accessibilityIdentifier = AccessibilityIdentifiers.apppromotion_imageViewIcon.rawValue
        labelTitle.accessibilityIdentifier = AccessibilityIdentifiers.apppromotion_labelTitle.rawValue
        labelDescription.accessibilityIdentifier = AccessibilityIdentifiers.apppromotion_labelDescription.rawValue
    }
}
