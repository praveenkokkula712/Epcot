//
//  EpcotRecommendationCollectionViewCell.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 03/05/22.
//

import UIKit
import CasinoAPI

class EpcotRecommendationCollectionViewCell: EpcotBaseCollectionViewCell {
    
    @IBOutlet private weak var labelTitle: UILabel!
    @IBOutlet private weak var imageViewArrow: UIImageView!
    @IBOutlet private weak var viewSeparator: UIView!
    
    private let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS
    
    var model: EntainSiteCoreItem = EntainSiteCoreItem() {
        didSet {
            self.labelTitle.text = model.title
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupViews()
        self.addAccessibilityIdentifiers()
    }
    
    private func setupViews() {
        //css from main.nss
        self.viewSeparator.backgroundColor = css?.menuViewCSS?.seperatorLineColour
        self.imageViewArrow.image = UIImage(named: kArrow,
                                  in: Bundle(for: EpcotRecommendationCollectionViewCell.self),
                                  compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        self.imageViewArrow.tintColor = css?.menuViewCSS?.arrowColour
        self.labelTitle.textColor = css?.menuViewCSS?.categoriesListTitle?.color
        self.labelTitle.font = css?.menuViewCSS?.categoriesListTitle?.font
    }
}

//MARK: Adding Accessibility Identifiers
extension EpcotRecommendationCollectionViewCell {
    private func addAccessibilityIdentifiers() {
        labelTitle.accessibilityIdentifier = AccessibilityIdentifiers.epcotrecommendation_labelTitle.rawValue
        imageViewArrow.accessibilityIdentifier = AccessibilityIdentifiers.epcotrecommendation_imageViewArrow.rawValue
        viewSeparator.accessibilityIdentifier = AccessibilityIdentifiers.epcotrecommendation_viewSeparator.rawValue
    }
}
