//
//  MenuCustomCell.swift
//  EpcotSample
//
//  Created by Gostu Bhargavi on 17/03/22.
//

import UIKit
import CasinoAPI
import SVGKit
import SDWebImageSVGCoder

class EpcotMenuCustomCell: EpcotBaseCollectionViewCell  {
    
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var viewSeparator: UIView!
    @IBOutlet private weak var arrowIcon: UIImageView!
    @IBOutlet weak var svgImageView: UIImageView!
    @IBOutlet private weak var labelIcon: UILabel!
    
    private var css: EpcotLobbyCSS? {
        EpcotLobbyManager.shared?.css.epcotLobbyCSS
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupViews()
        self.addAccessibilityIdentifiers()
    }
    
    private func setupViews() {
        self.backgroundColor = .white
        self.clipsToBounds = true
        self.layer.cornerRadius = 4
        self.arrowIcon.image = UIImage(named: kArrow,
                                  in: Bundle(for: EpcotMenuCustomCell.self),
                                  compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        self.arrowIcon.tintColor = css?.menuViewCSS?.arrowColour
        self.viewSeparator.backgroundColor = css?.menuViewCSS?.seperatorLineColour
        self.labelIcon.adjustsFontSizeToFitWidth = true
        self.labelIcon.minimumScaleFactor = 0.5
    }
    
    func configureView(with model: EntainSiteCoreItem, type cellType: CellType = CellType.menu) {
        self.titleLabel.text = model.title
        
        //css from main.nss
        self.titleLabel.font = css?.menuViewCSS?.categoriesListTitle?.font
        self.titleLabel.textColor = css?.menuViewCSS?.categoriesListTitle?.color
        
        if let colouredIcon = cellType == .menu ? model.parameters?.iconCss?.colouredIconUrl : model.parameters?.iconCss?.searchPageIconUrl {
            self.labelIcon.isHidden = true
            self.svgImageView.isHidden = false
            if colouredIcon.contains(".svg") {
                svgImageView.sd_setImage(with: URL(string: colouredIcon))
            } else {
                self.svgImageView.loadImage(withUrl: colouredIcon)
            }
        } else {
            self.svgImageView.isHidden = true
            self.labelIcon.isHidden = false
            let iconVariant = EpcotLobbyManager.shared?.datasource?.didRequestForIconVariant(with: model.parameters?.iconCss?.nativeIcon ?? "", fontSize: css?.menuIconFontSize ?? 16.0)
            self.labelIcon.text = iconVariant?.icon
            self.labelIcon.font = iconVariant?.font
            self.labelIcon.textColor = css?.menuViewCSS?.categoriesListTitle?.color
        }
    }
}

enum CellType {
    case menu, suggestion
}

//MARK: Adding Accessibility Identifiers
extension EpcotMenuCustomCell {
    private func addAccessibilityIdentifiers() {
        titleLabel.accessibilityIdentifier = AccessibilityIdentifiers.epcotmenucustom_titleLabel.rawValue
        viewSeparator.accessibilityIdentifier = AccessibilityIdentifiers.epcotmenucustom_viewSeparator.rawValue
        arrowIcon.accessibilityIdentifier = AccessibilityIdentifiers.epcotmenucustom_arrowIcon.rawValue
        svgImageView.accessibilityIdentifier = AccessibilityIdentifiers.epcotmenucustom_svgImageView.rawValue
        labelIcon.accessibilityIdentifier = AccessibilityIdentifiers.epcotmenucustom_labelIcon.rawValue
    }
}
