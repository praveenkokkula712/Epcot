//
//  OverlaysCSSModel.swift
//  Utility
//
//  Created by Gostu Bhargavi on 30/03/23.
//

import Foundation
import SwiftUI

struct OverlaysCSSModel {
    
    private var overlayViewCSS: OverlaysViewCSS {
        return EpcotLobbyManager.shared?.css.overlaysViewCSS ?? DefaultOverlayViewCss()
    }
    
    var titleFont: Font {
        Font(overlayViewCSS.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var titleColor: Color {
        Color(overlayViewCSS.title?.color ?? .black)
    }
    
    var descriptionFont: Font {
        Font(overlayViewCSS.description?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var descriptionUIFont: UIFont {
        overlayViewCSS.description?.font ?? UIFont.systemFont(ofSize: 14)
    }
    
    var descriptionColor: Color {
        Color(overlayViewCSS.description?.color ?? .black)
    }
    
    var descriptionUIColor: UIColor {
        overlayViewCSS.description?.color ?? .black
    }
    
    var ctaButtonTextColor: Color {
        Color(self.overlayViewCSS.ctaButton?.title?.color ?? .white)
    }
    
    var ctaButtonTextFont: Font {
        Font(self.overlayViewCSS.ctaButton?.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var ctaButtonBackgroundColor: Color {
        Color(self.overlayViewCSS.ctaButtonBackgroundColor ?? .clear)
    }
    
    var ctaButtonBorderColor: Color {
        Color(self.overlayViewCSS.ctaButtonBorderColor ?? .white)
    }
    
    var ctaButtonCornerRadius: CGFloat {
        self.overlayViewCSS.ctaButtonCornerRadius ?? 3
    }
    
    var imageShadowColor: Color {
        Color(self.overlayViewCSS.imageShadowColor ?? .black.withAlphaComponent(0.12))
    }
    
    var imageCornerRadius: CGFloat {
        self.overlayViewCSS.imageCornerRadius ?? 8
    }
    
    var imageShadowRadius: CGFloat {
        self.overlayViewCSS.imageShadowRadius ?? 8
    }
    
    var containerCornerRadius: CGFloat {
        self.overlayViewCSS.cornerRadius ?? 16
    }
    
    var containerBackgroundColor: Color {
        Color(self.overlayViewCSS.backgroundColor ?? .black)
    }
    
    var containerShadowColor: Color {
        Color(self.overlayViewCSS.containerShadowColor ?? .black.withAlphaComponent(0.8))
    }
    
    var containerShadowRadius: CGFloat {
        self.overlayViewCSS.containerShadowRadius ?? 8
    }
    
    var overlayBgColor: Color {
        Color(self.overlayViewCSS.overlayBackgroundColor ?? .black.withAlphaComponent(0.5))
    }
    
    var overlayBgUIColor: UIColor {
        self.overlayViewCSS.overlayBackgroundColor ?? .black.withAlphaComponent(0.5)
    }
    
    var cancelButtonTextColor: Color {
        Color(self.overlayViewCSS.cancelButton?.title?.color ?? .white)
    }
    
    var cancelButtonTextFont: Font {
        Font(self.overlayViewCSS.cancelButton?.title?.font ?? UIFont.systemFont(ofSize: 12))
    }
    
    var cancelButtonBackgroundColor: Color {
        Color(self.overlayViewCSS.cancelButton?.normal ?? .clear)
    }
    
    var cancelButtonBorderColor: Color {
        Color(self.overlayViewCSS.cancelButtonBorderColor ?? .white)
    }
    
    var cancelButtonCornerRadius: CGFloat {
        self.overlayViewCSS.cancelButtonCornerRadius ?? 3
    }
    
    var cancelButtonBorderWidth: CGFloat {
        self.overlayViewCSS.cancelButtonBorderWidth ?? 3
    }
}
