//
//  OverlaysModelExtension.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 29/03/23.
//

import Foundation
import SwiftUI

extension OverlayModel {
    
    var overlayTitle: String {
        if !self.title.isEmpty {
            return self.title
        }
        // INC1693867 - Removing this as per incident
//        else if !(self.commonModel?.title?.isEmpty ?? true) {
//            return self.commonModel?.title ?? ""
//        }
        return ""
    }
    
    var descriptionStr: String {
        if !self.desc.isEmpty {
            return self.desc
        }
        return ""
    }
    
    var overlayCtaTitle: String {
        if !self.ctaTitle.isEmpty {
            return self.ctaTitle
        }
        return ""
    }
    
    var imageUrl: String {
        if !self.imagePath.isEmpty  {
            return self.imagePath
        }
        return ""
    }
}

