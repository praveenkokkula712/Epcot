//
//  ToastersCSSModel.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 27/03/23.
//

import Foundation
import SwiftUI

struct ToasterCSSModel {
    
    private var toasterViewCSS: ToastersViewCSS {
        return EpcotLobbyManager.shared?.css.toasterViewCSS ?? DefaultToasterViewCss()
    }
    
    var titleFont: Font {
        Font(toasterViewCSS.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var titleColor: Color {
        Color(toasterViewCSS.title?.color ?? .black)
    }
    
    var descriptionFont: Font {
        Font(toasterViewCSS.description?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var descriptionColor: Color {
        Color(toasterViewCSS.description?.color ?? .black)
    }
    
    var descriptionUIFont: UIFont {
        toasterViewCSS.description?.font ?? UIFont.systemFont(ofSize: 14)
    }
        
    var descriptionUIColor: UIColor {
        toasterViewCSS.description?.color ?? .black
    }
    
    var ctaButtonTextColor: Color {
        Color(self.toasterViewCSS.ctaButton?.title?.color ?? .white)
    }
    
    var ctaButtonTextFont: Font {
        Font(self.toasterViewCSS.ctaButton?.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var ctaButtonBackgroundColor: Color {
        Color(self.toasterViewCSS.ctaButtonBackgroundColor ?? .clear)
    }
    
    var ctaButtonBorderColor: Color {
        Color(self.toasterViewCSS.ctaButtonBorderColor ?? .white)
    }
    
    var ctaButtonCornerRadius: CGFloat {
        self.toasterViewCSS.ctaButtonCornerRadius ?? 3
    }
    
    var imageShadowColor: Color {
        Color(self.toasterViewCSS.imageShadowColor ?? .black.withAlphaComponent(0.12))
    }
    
    var imageCornerRadius: CGFloat {
        self.toasterViewCSS.imageCornerRadius ?? 8
    }
    
    var imageShadowRadius: CGFloat {
        self.toasterViewCSS.imageShadowRadius ?? 8
    }
    
    var containerCornerRadius: CGFloat {
        self.toasterViewCSS.cornerRadius ?? 16
    }
    
    var containerBackgroundColor: Color {
        Color(self.toasterViewCSS.backgroundColor ?? .black)
    }
    
    var containerShadowColor: Color {
        Color(self.toasterViewCSS.containerShadowColor ?? .black.withAlphaComponent(0.8))
    }
    
    var containerShadowRadius: CGFloat {
        self.toasterViewCSS.containerShadowRadius ?? 8
    }
    
}
