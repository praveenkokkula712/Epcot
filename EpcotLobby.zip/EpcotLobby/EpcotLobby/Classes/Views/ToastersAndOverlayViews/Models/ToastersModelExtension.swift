//
//  ToastersModelExtension.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 27/03/23.
//

import Foundation
import SwiftUI
import Utility

extension ToasterModel {
    
    var toasterTitle: String {
        if !self.title.isEmpty {
            return self.title
        }
        return ""
    }
    
    var toasterCtaTitle: String {
        if !self.ctaTitle.isEmpty {
            return self.ctaTitle
        }
        return ""
    }
    
    var imageUrl: String {
        if !self.imagePath.isEmpty  {
            return self.imagePath
        }
        return ""
    }
}

