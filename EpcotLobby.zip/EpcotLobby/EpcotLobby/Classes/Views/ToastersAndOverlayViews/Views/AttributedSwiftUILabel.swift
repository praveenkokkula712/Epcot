//
//  AttributedSwiftUILabel.swift
//  Utility
//
//  Created by Gostu Bhargavi on 04/04/23.
//

import SwiftUI

struct AttributedSwiftUITextView: UIViewRepresentable {
    
    var text: NSAttributedString
    var labelUIFont: UIFont
    var labelTextColor: UIColor
    var lineLimit: Int
    
    var didTapOnHyperlink: (_ url: URL) -> Void

    class Coordinator : NSObject, UITextViewDelegate {
        var didTapOnHyperlink: (_ url: URL) -> Void
        
        init(didTapOnHyperlink: @escaping (_: URL) -> Void) {
            self.didTapOnHyperlink = didTapOnHyperlink
        }
        
        func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
            self.didTapOnHyperlink(URL)
            return false
        }
    }
    
    func makeUIView(context: UIViewRepresentableContext<Self>) -> UITextView {
        let textView = UITextView()
        textView.delegate = context.coordinator
        textView.isScrollEnabled = false
        textView.isEditable = false
        textView.isSelectable = true
        
        textView.setContentHuggingPriority(.required, for: .vertical)
        textView.setContentCompressionResistancePriority(.required, for: .vertical)
        textView.setContentHuggingPriority(.defaultLow, for: .horizontal)
        textView.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        return textView
    }
    
    func updateUIView(_ uiView: UITextView, context: UIViewRepresentableContext<Self>) {
        uiView.attributedText = text
        uiView.font = labelUIFont
        uiView.textColor = labelTextColor
        uiView.backgroundColor = .clear
    }
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(didTapOnHyperlink: {url in
            self.didTapOnHyperlink(url)
        })
    }
}
