//
//  OverlaysCardView.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 27/03/23.
//

import SwiftUI
import CasinoAPI
import Utility
import Kingfisher
import Combine

struct OverlaysCardView: View {
    
    var overlaysModel : OverlayModel
    
    var onCTAAction: (_ overlayModel: OverlayModel) -> Void
    
    private var onRemove: (_ overlayModel: OverlayModel) -> Void
    
    private var overlaysCSS = OverlaysCSSModel()
    
    @State var descriptionString: NSAttributedString?
 
    @Environment(\.safeAreaInsets) private var safeAreaInsets

    private var isEpcotFeatureEnabled: Bool {
        return EpcotLobbyManager.shared?.css.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false
    }
        
    private var isCTAFullWidth: Bool {
        if let overlayConfig = EntainContext.app?.overelaysAndToastersConfig {
            return overlayConfig.isOverlaysCTAFullWidth
        }
        return false
    }
    @State private var ctaInteractions = 0.0
    @State private var cancelInteractions = 0.0
    
    init(overlayModel: OverlayModel, onRemove: @escaping (_ overlayModel: OverlayModel) -> Void, onCTAAction: @escaping (_ overlayModel: OverlayModel) -> Void) {
        self.overlaysModel = overlayModel
        self.onRemove = onRemove
        self.onCTAAction = onCTAAction
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .bottom) {
                VStack {
                    ZStack(alignment: .bottom) {
                        ScrollView {
                            VStack(alignment: .leading) {
                                cancelHeaderView
                                let imageWidth = geometry.size.width - 32
                                overlaysImageView
                                    .frame(maxWidth: imageWidth, maxHeight: imageWidth/2)
                                    .cornerRadius(overlaysCSS.imageCornerRadius)
                                    .layoutPriority(2)
                                titleView
                                if let _ = descriptionString {
                                    descriptionView
                                }
                            }
                            .padding(.horizontal)
                            .padding(.top,20)
                            .padding(.bottom, 10)
                            .onAppear {
                                overlaysModel.descriptionStr.convertHTMLInBackground(isFixedLineRequired: true) { result in
                                    DispatchQueue.main.async {
                                        descriptionString = result
                                    }
                                }
                            }
                        }
                        .mask(
                            LinearGradient(gradient:
                                            Gradient(colors: [
                                                overlaysCSS.containerBackgroundColor,
                                                overlaysCSS.containerBackgroundColor,
                                                overlaysCSS.containerBackgroundColor,
                                                overlaysCSS.containerBackgroundColor,
                                                overlaysCSS.containerBackgroundColor.opacity(0)
                                                        ]),
                                           startPoint: .top, endPoint: .bottom)
                                                        .mask( Rectangle() )
                                                        .frame(height: geometry.size.height)
                        )
                    }
                    Spacer()
                        .frame(height: 0)
                    HStack(alignment: .center) {
                        Spacer()
                        ctaButton
                            .truncationMode(.tail)
                        Spacer()
                    }
                    .background(Color.clear)
                    .shadow(color: overlaysCSS.containerShadowColor,radius: overlaysCSS.containerShadowRadius)
                    Spacer(minLength: safeAreaInsets.bottom)
                }
                .frame(height: kOverlayCardHeight)
                .background(overlaysCSS.containerBackgroundColor)
            }
            .ignoresSafeArea(.all, edges: .bottom)
            .frame(height: kOverlayCardHeight)
            .background(Color.clear)
        }
    }
}

extension OverlaysCardView {
    
    @ViewBuilder
    private var titleView: some View {
        if !overlaysModel.overlayTitle.isEmpty {
            Text(overlaysModel.overlayTitle)
                .foregroundColor(overlaysCSS.titleColor)
                .font(overlaysCSS.titleFont)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        }
    }
    
    @ViewBuilder
    private var descriptionView: some View {
        Text(descriptionString?.string ?? "")
            .foregroundColor(overlaysCSS.descriptionColor)
            .font(overlaysCSS.descriptionFont)
            .fixedSize(horizontal: false, vertical: true)
    }
    
    @ViewBuilder
    private var overlaysImageView: some View {
        if let img = overlaysModel.diskImage {
            Image(uiImage: img)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .cornerRadius(overlaysCSS.imageCornerRadius)
        } else if !overlaysModel.imageUrl.isEmpty {
            let imageWidth = UIDevice.screenSize.width - 32
            KFImage(URL(string: overlaysModel.imageUrl))
                .placeholder {
                    PlaceHolderImage()
                }
                .setProcessor(ResizingImageProcessor(referenceSize:
                                    CGSize(width: imageWidth, height: imageWidth/2), mode: .aspectFit))
                .resizable()
                .aspectRatio(contentMode: .fit)
                .cornerRadius(overlaysCSS.imageCornerRadius)
        }
    }
    
    private var cancelHeaderView: some View {
        HStack {
            Spacer()
            Button(action: {
                withAnimation(instantInteractionAnimation) {
                    cancelInteractions = 1
                    self.onRemove(overlaysModel)
                }
            }) {
                Text("close_title".localized)
                    .foregroundColor(overlaysCSS.cancelButtonTextColor)
                    .padding(.vertical,5)
                    .padding(.horizontal,10)
                    .font(overlaysCSS.cancelButtonTextFont)
                    .background(cancelInteractions == 0 ?
                                overlaysCSS.cancelButtonBackgroundColor :
                                overlaysCSS.cancelButtonBackgroundColor.instantInteractionOverlay40)
                    .clipShape(RoundedRectangle(cornerRadius: overlaysCSS.cancelButtonCornerRadius))
                    .overlay(
                        RoundedRectangle(cornerRadius: overlaysCSS.cancelButtonCornerRadius)
                            .stroke(overlaysCSS.cancelButtonBorderColor,
                                    lineWidth: overlaysCSS.cancelButtonBorderWidth)
                    )
                    .frame(height: 35)
            }
            .onAnimationCompleted(for: cancelInteractions) {
                cancelInteractions = 0
            }
        }
        .padding(.bottom,8)
    }
    
    @ViewBuilder
    private var ctaButton: some View {
        if !overlaysModel.overlayCtaTitle.isEmpty {
            Button(action: {
                withAnimation(instantInteractionAnimation) {
                    ctaInteractions = 1
                }
            }) {
                HStack (alignment: .center) {
                    Text(overlaysModel.overlayCtaTitle)
                        .frame(maxWidth: isCTAFullWidth ? .infinity : nil)
                }
                .frame(minWidth: 83,idealHeight: 40)
                .frame(height: 40)
            }
            .overlay(RoundedRectangle(cornerRadius: 0)
                .stroke(overlaysCSS.ctaButtonBorderColor, lineWidth: 1))
            .cornerRadius(overlaysCSS.ctaButtonCornerRadius)
            .background(LinearGradient(gradient: ctaInteractions == 0 ?
                                       Gradient.defaultGradientColors : Gradient.overlay40Color,
                                       startPoint: .leading, endPoint: .trailing))
            .onAnimationCompleted(for: ctaInteractions) {
                ctaInteractions = 0
                self.onCTAAction(self.overlaysModel)
            }
            .applyEpcotGradientBgColor(backgroundColor: overlaysCSS.ctaButtonBackgroundColor,
                                       font: overlaysCSS.ctaButtonTextFont,
                                       textColor: overlaysCSS.ctaButtonTextColor,
                                       cornerRadius: overlaysCSS.ctaButtonCornerRadius,
                                       isEpcotEnabled: isEpcotFeatureEnabled)
        }
    }
}

struct SafeAreaInsetsKey: EnvironmentKey {
    static var defaultValue: EdgeInsets {
        UIApplication.safeAreaInsets.insets
    }
}

extension EnvironmentValues {
    var safeAreaInsets: EdgeInsets {
        self[SafeAreaInsetsKey.self]
    }
}

extension UIEdgeInsets {
    var insets: EdgeInsets {
        EdgeInsets(top: top, leading: left, bottom: bottom, trailing: right)
    }
}

