//
//  ToastersHostingController.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 01/08/23.
//

import SwiftUI

class ToastersHostingController: UIHostingController<ToastersStackView> {
    
    init(toaster: ToasterModel) {
        super.init(rootView: ToastersStackView(toasterModel: toaster))
        EpcotLobbyManager.shared?.isOverlaysOrToastersPresented = true
        rootView.dismiss = dismiss
    }
    
    @objc required dynamic init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func dismiss() {
        if let toasterStackView = self.view {
            AlertCoordinator.removeView(toasterStackView)
            EpcotLobbyManager.shared?.isOverlaysOrToastersPresented = false
        }
    }
}
