//
//  ToastersCardView.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 16/03/23.
//

import SwiftUI
import CasinoAPI
import Utility
import Kingfisher
import Combine

fileprivate let kPlaceHolder = "placeHolder"

struct ToastersCardView : View {
    var toasterModel : ToasterModel
    @State private var translation: CGSize = .zero
    private let timer: Publishers.Autoconnect<Timer.TimerPublisher>
    
    var onCTAAction: (_ toaster: ToasterModel) -> Void
    
    private var onRemove: (_ toasterData: ToasterModel) -> Void
    
    private var toasterCSS = ToasterCSSModel()
    
    private var isEpcotFeatureEnabled: Bool {
        return EpcotLobbyManager.shared?.css.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false
    }
    
    @State private var ctaInteractions = 0.0
    
    init(toasterData: ToasterModel, timeout: Int, onRemove: @escaping (_ toaster: ToasterModel) -> Void, onCTAAction: @escaping (_ toaster: ToasterModel) -> Void) {
        self.toasterModel = toasterData
        self.onRemove = onRemove
        self.onCTAAction = onCTAAction
        self.timer = Timer.TimerPublisher(interval: TimeInterval(timeout), runLoop: .main, mode: .common).autoconnect()
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .center) {
                RoundedRectangle(cornerRadius: toasterCSS.containerCornerRadius).fill(Color.clear)
                    .frame(height: kToasterCardHeight)
                VStack(alignment: .center) {
                    HStack(alignment: .center, spacing: 8) {
                        HStack(alignment: .center, spacing: 12) {
                            toasterImageView
                            VStack(alignment: .leading) {
                                titleView
                                descriptionView
                            }
                        }
                        .padding(.horizontal, 8)
                        ctaButton
                    }
                }
            }
            .background(toasterCSS.containerBackgroundColor)
            .shadow(color: toasterCSS.containerShadowColor,radius: toasterCSS.containerShadowRadius)
            .onReceive(timer) { _ in
                self.removeToaster()
            }
            .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .local)
                .onEnded({ value in
                    if value.translation.height < 0 {
                        self.removeToaster()
                    }
                }))
        }
    }

    private func removeToaster() {
        withAnimation {
            self.onRemove(self.toasterModel)
        }
        self.timer.upstream.connect().cancel()
    }
}

extension ToastersCardView {
    
    @ViewBuilder
    private var titleView: some View {
        if !toasterModel.toasterTitle.isEmpty {
            Text(toasterModel.toasterTitle)
                .foregroundColor(toasterCSS.titleColor)
                .font(toasterCSS.titleFont)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
    
    @ViewBuilder
    private var descriptionView: some View {
        if !toasterModel.attributedDesc.isEmpty {
            Text(toasterModel.attributedDesc.trimmingCharacters(in: .whitespacesAndNewlines))
                .foregroundColor(toasterCSS.descriptionColor)
                .font(toasterCSS.descriptionFont)
                .lineLimit(2)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
    
    @ViewBuilder
    private var toasterImageView: some View {
        if let img = toasterModel.diskImage {
            Image(uiImage: img)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: kToasterImageHeight, height: kToasterImageHeight)
                .cornerRadius(toasterCSS.imageCornerRadius)
                .shadow(color: toasterCSS.imageShadowColor,radius: toasterCSS.imageShadowRadius)
        } else if !toasterModel.imageUrl.isEmpty {
            KFImage(URL(string: toasterModel.imageUrl))
                .placeholder {
                    PlaceHolderImage()
                }
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: kToasterImageHeight, height: kToasterImageHeight)
                .cornerRadius(toasterCSS.imageCornerRadius)
                .shadow(color: toasterCSS.imageShadowColor,radius: toasterCSS.imageShadowRadius)
        }
    }
    
    @ViewBuilder
    private var ctaButton: some View {
        if !toasterModel.toasterCtaTitle.isEmpty {
            Button(action: {
                withAnimation(instantInteractionAnimation) {
                    ctaInteractions = 1
                    self.onCTAAction(self.toasterModel)
                }
            }) {
                HStack {
                    Text(toasterModel.toasterCtaTitle)
                        .font(toasterCSS.ctaButtonTextFont)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(EdgeInsets(top: 2, leading: 4, bottom: 2, trailing: 4))
                .foregroundColor(toasterCSS.ctaButtonTextColor)
                .overlay(RoundedRectangle(cornerRadius: toasterCSS.ctaButtonCornerRadius)
                    .stroke(toasterCSS.ctaButtonBorderColor, lineWidth: isEpcotFeatureEnabled ? 0 : 1))
                .cornerRadius(toasterCSS.ctaButtonCornerRadius)
            }
            .background(toasterCSS.ctaButtonBackgroundColor)
            .background(LinearGradient(gradient: ctaInteractions == 0 ? Gradient.defaultGradientColors : Gradient.overlay40Color, startPoint: .leading, endPoint: .trailing))
            .onAnimationCompleted(for: ctaInteractions) {
                ctaInteractions = 0
            }
            .frame(minWidth: 60, maxWidth: 80, minHeight: 34, maxHeight: 34)
            .applyEpcotGradientBgColor(backgroundColor: toasterCSS.ctaButtonBackgroundColor,
                                       font: toasterCSS.ctaButtonTextFont,
                                       textColor: toasterCSS.ctaButtonTextColor,
                                       cornerRadius: toasterCSS.ctaButtonCornerRadius,
                                       isEpcotEnabled: isEpcotFeatureEnabled)
            .padding(.trailing, 16)
        }
    }
}
