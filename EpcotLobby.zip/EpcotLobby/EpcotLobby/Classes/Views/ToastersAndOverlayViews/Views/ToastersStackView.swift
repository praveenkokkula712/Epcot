//
//  ToastersStackView.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 16/03/23.
//

import SwiftUI
import CasinoAPI
import TrackerClient
import Utility

struct ToastersStackView: View {
    
    var toasterModel : ToasterModel
    private var toasterCSS = ToasterCSSModel()
    @State private var isVisible = false
    var dismiss: (() -> Void)?
    private var toasterDuation: Int {
        return EpcotLobbyManager.shared?.datasource?.rtmsToasterDisplayTimeDuration ?? 10
    }

    init(toasterModel: ToasterModel) {
        self.toasterModel = toasterModel
    }
    
    var body: some View {
        VStack {
            if isVisible {
                GeometryReader { geometry in
                    VStack {
                        ToastersCardView(toasterData: toasterModel,
                                         timeout: toasterDuation,
                                         onRemove: { toaster in
                            self.trackToasterEvents(toasterTitle: toaster.title,
                                                    actionType: EpcotEventAction.swipe_left.rawValue, eventName: GtmLogConstants.GeneralConstants.notApplicable.rawValue,
                                                    positionEvent: EpcotEventPosition.unstacked_toasters.rawValue)
                            
                            // Remove that toaster View
                            withAnimation {
                                self.isVisible.toggle()
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                    dismissHostingView()
                                    EpcotLobbyManager.shared?.delegate?.didOverlaysAndToasterDismissed?()
                                }
                            }
                        }, onCTAAction: {toaster in
                            withAnimation {
                                self.isVisible.toggle()
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                    self.didTapOnCTAButton(toaster: toaster)
                                }
                            }
                        } )
                        .cornerRadius(toasterCSS.containerCornerRadius)
                        .frame(height: kToasterCardHeight)
                        .offset(x: 0, y: 10)
                    }
                    
                }
                .frame(height: kToasterCardHeight)
                .transition(.move(edge: .top))
                .animation(.easeIn, value: isVisible)
            }
        }
        .onAppear {
            isVisible.toggle()
        }
    }
}


extension ToastersStackView {
    
    private func didTapOnCTAButton(toaster: ToasterModel) {
        var ctaUrlString = ""
        if !toaster.ctaLink.isEmpty {
            ctaUrlString = toaster.ctaLink
        } else if let ctaUrl = toaster.commonModel?.ctaLink as? String, !ctaUrl.isEmpty {
            ctaUrlString = ctaUrl
        }
        self.trackToasterEvents(toasterTitle: toaster.title,
                                actionType: EpcotEventAction.click.rawValue, eventName: ctaUrlString,
                                positionEvent: EpcotEventPosition.unstacked_toasters.rawValue)

        dismissHostingView()

        EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .toastersAndOverlays(ctaUrlString), buttonType: nil)
    }
    
    private func trackToasterEvents(toasterTitle: String, actionType: String, eventName: String, positionEvent: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = PageViewLog(categoryEvent: EpcotEventCategory.toaster.rawValue,
                                  labelEvent: toasterTitle,
                                  actionEvent: actionType,
                                  positionEvent: positionEvent,
                                  locationEvent: ScreenName.casino.rawValue,
                                  eventDetails: eventName)

            let event = TrackerEvent(type: .toaster_click, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
    private func dismissHostingView() {
        dismiss?()
    }
}
