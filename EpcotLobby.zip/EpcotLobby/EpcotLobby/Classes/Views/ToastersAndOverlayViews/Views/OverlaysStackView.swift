//
//  OverlaysStackView.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 29/03/23.
//

import SwiftUI
import CasinoAPI
import TrackerClient
import Utility

struct OverlaysStackView: View {
    var overlayModel : OverlayModel
            
    var dismissView: (() -> Void)?
    
    private var overlaysCSS = OverlaysCSSModel()
    
    private func didTapOnCTAButton(overlay: OverlayModel) {
        var ctaUrlString = ""
        if let ctaUrl = overlay.ctaLink as? String, !ctaUrl.isEmpty {
            ctaUrlString = ctaUrl
        } else if let ctaUrl = overlay.commonModel?.ctaLink as? String, !ctaUrl.isEmpty {
            ctaUrlString = ctaUrl
        }
        self.trackOverlaysEvents(title: overlay.title,
                                 actionType: EpcotEventAction.click.rawValue, eventName: ctaUrlString,
                                 positionEvent: EpcotEventPosition.unstacked_toasters.rawValue)

        dismissView?()
        EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .toastersAndOverlays(ctaUrlString), buttonType: nil)
    }
    
    init(overlayModel: OverlayModel) {
        self.overlayModel = overlayModel
    }
    
    var body: some View {
        GeometryReader { geometry in
            VStack {
                Spacer()
                ZStack {
                    OverlaysCardView(overlayModel: overlayModel, onRemove: { overlay in
                        self.trackOverlaysEvents(title: overlay.title,
                                                 actionType: EpcotEventAction.click.rawValue,
                                                 eventName: GtmLogConstants.GeneralConstants.notApplicable.rawValue,
                                                 positionEvent: EpcotEventPosition.unstacked_toasters.rawValue)
                        // Remove overlay View
                        dismissView?()
                        EpcotLobbyManager.shared?.delegate?.didOverlaysAndToasterDismissed?()
                    }, onCTAAction: {overlay in
                        self.didTapOnCTAButton(overlay: overlay)
                    })
                    .cornerRadius(overlaysCSS.containerCornerRadius, corners: [.topLeft, .topRight])
                    .onTapGesture {
                        /// Added Empty implementation to to tap gesture on internal View
                    }
                }
                .frame(width: UIDevice.isIPad() ? geometry.size.width/2 : geometry.size.width, height: kOverlayCardHeight)
                .onTapGesture {
                    /// Added Empty implementation to to tap gesture on internal View
                }
            }
            .ignoresSafeArea()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.clear)
            .padding(.bottom, 0)
            .contentShape(Rectangle())
            .onTapGesture {
                self.trackOverlaysEvents(title: overlayModel.title,
                                         actionType: EpcotEventAction.click.rawValue,
                                         eventName: GtmLogConstants.GeneralConstants.notApplicable.rawValue,
                                         positionEvent: EpcotEventPosition.unstacked_toasters.rawValue)
                /// Added tap gesture on outside view
                dismissView?()
                EpcotLobbyManager.shared?.delegate?.didOverlaysAndToasterDismissed?()
            }
        }
    }
}

extension OverlaysStackView {
    private func trackOverlaysEvents(title: String, actionType: String, eventName: String, positionEvent: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = PageViewLog(categoryEvent: EpcotEventCategory.overlay.rawValue,
                                  labelEvent: title,
                                  actionEvent: actionType,
                                  positionEvent: positionEvent,
                                  locationEvent: ScreenName.casino.rawValue,
                                  eventDetails: eventName)
            
            let event = TrackerEvent(type: .overlays_click, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}
