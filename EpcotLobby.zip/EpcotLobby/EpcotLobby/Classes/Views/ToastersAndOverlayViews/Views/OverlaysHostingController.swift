//
//  OverlaysHostingController.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 01/08/23.
//

import SwiftUI

class OverlaysHostingController: UIHostingController<OverlaysStackView> {
    
    init(overlay: OverlayModel) {
        super.init(rootView: OverlaysStackView(overlayModel: overlay))
        EpcotLobbyManager.shared?.isOverlaysOrToastersPresented = true
        rootView.dismissView = dismissView
    }
    
    @objc required dynamic init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func dismissView() {
        AlertCoordinator.removeView(self)
        EpcotLobbyManager.shared?.isOverlaysOrToastersPresented = false
    }
}
