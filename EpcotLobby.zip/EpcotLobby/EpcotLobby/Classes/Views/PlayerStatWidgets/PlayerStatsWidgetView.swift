//
//  PlayerStatsWidgetView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 27/06/24.
//


import SwiftUI
import CasinoAPI
import Kingfisher
import SDWebImageSwiftUI
import TrackerClient

struct PlayerStatsWidgetView: View {
    
    // MARK: Properties
    @ObservedObject var viewModel: PlayerStatsWidgetViewModel
    let styles = PlayerStatsWidgetCss()
    
    
    // MARK: Body
    var body: some View {
        GeometryReader { geometry in
            VStack {

                ZStack {
                    // background images
                    ZStack(alignment: .bottom) {
                        
                        let imageWidth = geometry.size.width
                        let imageHeight = geometry.size.height
                        
                        loadImage(urlString: viewModel.backgroundImageLaye1,
                                  width: imageWidth,
                                  height: imageHeight)
                        .accessibilityIdentifier(PlayerStatsAccessibilityIdentifiers.backgroundImageLayer1)
                        loadImage(urlString: viewModel.backgroundImageLayer2,
                                  width: imageWidth,
                                  height: imageHeight)
                        .accessibilityIdentifier(PlayerStatsAccessibilityIdentifiers.backgroundImageLayer1)
                        
                        // background image at bottom of the widget with height 36
                        loadImage(urlString: viewModel.backgroundBottomImage,
                                  width: imageWidth,
                                  height: 36)
                        .accessibilityIdentifier(PlayerStatsAccessibilityIdentifiers.backgroundImageLayer1)
                    }
                    
                    // Content
                    ScrollViewReader { proxy in
                        
                    VStack(spacing: 0) {
                        
                        HStack(spacing: 10) {
                            // lastWeek Button
                            if viewModel.weeklyGameTiles.count > 1 && !viewModel.lastWeekText.isEmpty {
                                Button(action: {
                                    if !viewModel.isWeeklyGamesSelected {
                                        Haptics.play(.light)
                                        viewModel.onButtonClick(fromlastWeek: true)
                                        proxy.scrollTo(0, anchor: .leading)
                                        viewModel.trackEvent(eventDetails: EpcotEventDetails.last_week.rawValue,
                                                             gamePosition: "0",
                                                             eventType: .casino_widgets)
                                    }
                                }, label: {
                                    HStack {
                                        Text(viewModel.lastWeekCta)
                                    }
                                    .frame(minHeight: 32.0)
                                    .padding(.horizontal,8)
                                    .applyGradientBgColors(backgroundColors: lastWeekCtaBgColor,
                                                           font: lastWeekTitleFont,
                                                           textColor: lastWeekCtaTitleColor,
                                                           cornerRadius: lastWeekCtaCornerRadius,
                                                           fromPlayerStatsWidget: true
                                    )
                                })
                                .accessibilityIdentifier(PlayerStatsAccessibilityIdentifiers.lastWeekCta)
                            }
                            
                            // lastMonth Button
                            if viewModel.monthlyGameTiles.count > 1 && !viewModel.lastMonthText.isEmpty {
                                Button(action: {
                                    if viewModel.isWeeklyGamesSelected {
                                        Haptics.play(.light)
                                        viewModel.onButtonClick(fromlastWeek: false)
                                        proxy.scrollTo(0, anchor: .leading)
                                        viewModel.trackEvent(eventDetails: EpcotEventDetails.last_month.rawValue,
                                                             gamePosition: viewModel.weeklyGameTiles.isEmpty ? "0" : "1",
                                                             eventType: .casino_widgets)
                                    }
                                }, label: {
                                    HStack {
                                        Text(viewModel.lastMonthCta)
                                    }
                                    .frame(minHeight: 32.0)
                                    .padding(.horizontal,8)
                                    .applyGradientBgColors(backgroundColors: lastMonthCtaBgColor,
                                                           font: lastMonthTitleFont,
                                                           textColor: lastMonthCtaTitleColor,
                                                           cornerRadius: lastMonthCtaCornerRadius,
                                                           fromPlayerStatsWidget: true
                                    )
                                    .overlay(
                                        RoundedRectangle(cornerRadius: styles.unSelectedPeriodCornerRadius)
                                            .inset(by: 0.5)
                                            .stroke(styles.unSelectedPeriodBorderColor, lineWidth: styles.unSelectedPeriodBorderWidth)
                                    )
                                })
                                .accessibilityIdentifier(PlayerStatsAccessibilityIdentifiers.lastMonthCta)
                            }
                        }
                        .padding(.bottom, 12)
                        
                        VStack(spacing: 8) {
                            
                            // Title
                            HStack {
                                Text(viewModel.title)
                                    .font(styles.titleFont)
                                    .foregroundColor(styles.titleColor)
                                
                                +
                                Text(" ")
                                    .foregroundColor(Color.clear)
                                
                                +
                                Text(viewModel.lastWeekOrLastMonthText)
                                    .font(styles.titleFont)
                                    .foregroundColor(styles.titleCtaColor)
                            }
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 3)
                            .minimumScaleFactor(0.5)
                            .accessibilityIdentifier(PlayerStatsAccessibilityIdentifiers.title)
                            
                            // Subtitle
                            Text(viewModel.subTitle)
                                .font(styles.messageTextFont)
                                .foregroundColor(styles.messageTextColor)
                                .opacity(styles.messageTextOpacity)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 3)
                                .minimumScaleFactor(0.5)
                                .accessibilityIdentifier(PlayerStatsAccessibilityIdentifiers.subTitle)
                        }
                        .padding(.bottom, 24)
                        
                        // GameTiles
                        ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 10) {
                                    
                                    ForEach(viewModel.games.indices, id: \.self) { index in
                                        let fixedHeight = 145.0
                                        let fixedWidth = 2*(fixedHeight)
                                        
                                        var gameTilesize: CGSize {
                                            return CGSize(width: index == 0 || viewModel.onlyTwoGamesAvailable ? fixedWidth : fixedHeight, height: fixedHeight)
                                        }
                                        
                                        var jackPotAmountheight: CGFloat {
                                            return index == 0 || viewModel.onlyTwoGamesAvailable ? 32 : 16
                                        }
                                        PlayerStatsGameTileView(viewModel: viewModel,
                                                                gameInfo: viewModel.games[index],
                                                                size: gameTilesize,
                                                                jackPotAmountheight: jackPotAmountheight
                                        )
                                        .id(index)
                                    }
                                }
                            }
                            .padding(.bottom, 16)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 16)
                }
            }
        }
    }
}

extension PlayerStatsWidgetView {
    
    @ViewBuilder
    private func loadImage(urlString: String?, width: CGFloat, height: CGFloat? = nil)  -> some View {
        if let url = urlString {
            if url.isGIF {
                AnimatedImage(url: URL(string: url),  placeholderImage: UIImage.getImage(named: "placeHolder"))
                                    .resizable()
                                    .indicator(.activity)
                                    .transition(.fade)
                                    .frame(width: width, height: height)
                                    .cornerRadius(styles.widgetCornerRadius)
            } else {
                KFImage(URL(string: url))
                    .placeholder {
                        PlaceHolderImage()
                    }
                    .resizable()
                    .frame(width: width, height: height)
                    .cornerRadius(styles.widgetCornerRadius)
            }
        }
    }
}

extension PlayerStatsWidgetView {
    
    var lastWeekCtaBgColor: [Color] {
        return viewModel.isWeeklyGamesSelected ? [styles.selectedPeriodBgColor] : styles.unSelectedPeriodGradientColors
    }
    
    var lastMonthCtaBgColor: [Color] {
        return viewModel.isWeeklyGamesSelected ? styles.unSelectedPeriodGradientColors : [styles.selectedPeriodBgColor]
    }
    
    var lastWeekTitleFont: Font {
        return viewModel.isWeeklyGamesSelected ? styles.selectedPeriodTitleFont : styles.unSelectedPeriodTitleFont
    }
    
    var lastMonthTitleFont: Font {
        return viewModel.isWeeklyGamesSelected ? styles.unSelectedPeriodTitleFont : styles.selectedPeriodTitleFont
    }
    
    var lastWeekCtaTitleColor: Color {
        return viewModel.isWeeklyGamesSelected ? styles.selectedPeriodTitleColor : styles.unSelectedPeriodTitleColor
    }
    
    var lastMonthCtaTitleColor: Color {
        return viewModel.isWeeklyGamesSelected ? styles.unSelectedPeriodTitleColor : styles.selectedPeriodTitleColor
    }
    
    var lastWeekCtaCornerRadius: CGFloat {
        return viewModel.isWeeklyGamesSelected ?  styles.selectedPeriodCornerRadius : styles.unSelectedPeriodCornerRadius
    }
    
    var lastMonthCtaCornerRadius: CGFloat {
        return viewModel.isWeeklyGamesSelected ?  styles.unSelectedPeriodCornerRadius : styles.selectedPeriodCornerRadius
    }
}
