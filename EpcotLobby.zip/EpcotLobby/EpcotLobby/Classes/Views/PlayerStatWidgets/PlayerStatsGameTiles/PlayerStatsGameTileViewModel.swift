//
//  PlayerStatsGameTileViewModel.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 08/07/24.
//

import Foundation
import Combine
import Utility

class PlayerStatsGameTileViewModel: ObservableObject {
    
    private let game: String
    @Published var jackpotAmount: String?
    @Published var jackpotFireImagePath: String?
    @Published var isHotJackpotGame: Bool
    private var subscriber: AnyCancellable?

    init(gameInfo: PlayerStatsGameTile) {
        self.game = gameInfo.game.game ?? ""
        self.jackpotAmount = gameInfo.immersiveInfo?.gameInfo.jpPrice?.trimmingCharacters(in: .whitespaces)
        self.jackpotFireImagePath = gameInfo.immersiveInfo?.fireIconImagePath
        self.isHotJackpotGame = gameInfo.immersiveInfo?.gameInfo.isHotJackpotGame ?? false
        self.subscribeTo(publisher: gameInfo.publisher)
    }
}

extension PlayerStatsGameTileViewModel {
    private func subscribeTo(publisher: GameTilePublisher?) {
        subscriber = publisher?
            .receive(on: DispatchQueue.main)
            .sink { [weak self] values in
                self?.updateJackpot(with: values?.jackpot)
            }
    }
    
    private func updateJackpot(with jackpotInfo: [String: String]?) {
        guard let jackpotsValues = jackpotInfo else {
            guard let amount = self.jackpotAmount?.jackpotCounterAmount else { return }
            self.jackpotAmount = amount
            return
        }
        let gameVariantName = self.game
        if !gameVariantName.isEmpty,
           let jpPrice = jackpotsValues[gameVariantName] {
            self.jackpotAmount = jpPrice
        }
    }
}

