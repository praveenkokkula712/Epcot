//
//  PlayerStatsGameTile.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 02/07/24.
//

import Foundation
import CasinoAPI

struct PlayerStatsGameTile {
    var game: Game
    var immersiveInfo: ImmersiveGameInfo?
    var publisher: GameTilePublisher?
    var multiplier: CGFloat?
}
