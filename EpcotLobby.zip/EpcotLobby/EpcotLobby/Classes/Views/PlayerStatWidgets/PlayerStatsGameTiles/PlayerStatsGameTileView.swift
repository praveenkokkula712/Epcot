//
//  PlayerStatsGameTiles.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 27/06/24.
//

import SwiftUI
import Kingfisher
import Utility
import CasinoAPI
import TrackerClient

struct PlayerStatsGameTileView: View {
    
    // MARK: Properties
    var viewModel: PlayerStatsWidgetViewModel
    var gameInfo: PlayerStatsGameTile
    var size: CGSize
    var jackPotAmountheight: CGFloat
    let styles = PlayerStatsWidgetCss()
    @ObservedObject private var gameTileViewModel: PlayerStatsGameTileViewModel
    
    // MARK: Init
    init(viewModel: PlayerStatsWidgetViewModel, gameInfo: PlayerStatsGameTile, size: CGSize, jackPotAmountheight: CGFloat) {
        self.viewModel = viewModel
        self.gameInfo = gameInfo
        self.size = size
        self.jackPotAmountheight = jackPotAmountheight
        self.gameTileViewModel = PlayerStatsGameTileViewModel(gameInfo: gameInfo)
    }
    
    // MARK: Body
    var body: some View {
        
        ZStack(alignment: .bottom) {
            
            // GameImage
            KFImage(URL(string: gameInfo.immersiveInfo?.imagePath ?? ""))
                .placeholder {
                    PlaceHolderImage()
                }
                .resizable()
                .frame(width: size.width, height: size.height)
                .cornerRadius(styles.gameTileCornerRadius)
                .accessibilityIdentifier(PlayerStatsAccessibilityIdentifiers.gameTile)
            
            
            VStack(spacing: 1) {
                HStack {
                    Spacer()
                    
                    // Multiplier
                    if let multiplier = gameInfo.multiplier {
                        let intValue = Int(multiplier)
                        let multiplier = String(intValue) + viewModel.multiplier
                        let digits = Array(multiplier)
                        
                        HStack(spacing: 1) {
                            ForEach(digits.indices, id: \.self) { index in
                                ZStack {
                                    Text(String(digits[index]))
                                        .foregroundColor(styles.multiplierDigitColor)
                                        .font(styles.multiplierDigitFont)
                                        .accessibilityIdentifier(PlayerStatsAccessibilityIdentifiers.multiplerDigit)
                                }
                                .frame(width: 16, height: 22)
                                .background(styles.multiplierDigitViewBgColor)
                                .cornerRadius(styles.multiplierDigitViewCornerRadius)
                                .padding(.vertical, 1)
                                .padding(.leading, index == 0 ? 1 : 0 )
                                .padding(.trailing, index == digits.count - 1 ? 1 : 0 )
                            }
                        }
                        .background(styles.multiplierViewBgColor)
                        .cornerRadius(styles.multiplierViewCornerRadius)
                        .overlay(
                            RoundedRectangle(cornerRadius: styles.multiplierViewCornerRadius)
                                .stroke(styles.multiplierViewBorderColor, lineWidth: styles.multiplierViewBorderWidth))
                        .padding(.trailing, 1)
                        .padding(.bottom, gameTileViewModel.jackpotAmount != nil ? 0 : 16)
                        .minimumScaleFactor(0.7)
                        .accessibilityIdentifier(PlayerStatsAccessibilityIdentifiers.multiplerView)
                    }
                }
                
                // JackpotAmountView
                if let jpAmount = gameTileViewModel.jackpotAmount {
                    GameTileJackpotView(
                        value: jpAmount,
                        isIconEnabled: gameTileViewModel.isHotJackpotGame,
                        jackpotFireIconImagePath: gameTileViewModel.jackpotFireImagePath,
                        viewHeight: jackPotAmountheight,
                        fromPlayerStats: true
                    )
                }
            }
        }
        .cornerRadius(styles.gameTileCornerRadius)
        .onTapGesture {
            if let gameVaraint = gameInfo.immersiveInfo?.gameInfo.gameMetadata.game {
                viewModel.onGameTap?(gameVaraint)
                viewModel.trackEvent(gameInfo: gameInfo,
                                     gameCategory: EpcotEventCategory.player_stats.rawValue,
                                     gamePlayingStatus: GameEvents.GameStatus.start.rawValue,
                                     eventType: .game_launch)
            }
        }
        .onAppear {
            viewModel.trackEvent(categoryEvent: EpcotEventCategory.games.rawValue,
                                 actionEvent: EpcotEventAction.impressions.rawValue,
                                 labelEvent: EpcotEventLabel.game_multiplier.rawValue,
                                 eventDetails: EpcotEventDetails.app.rawValue,
                                 gameInfo: gameInfo,
                                 gameCategory: EpcotEventCategory.player_stats.rawValue,
                                 eventType: .view_item_list)
        }
    }
}
