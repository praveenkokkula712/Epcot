//
//  PlayerWidgetContainerCell.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 27/06/24.
//

import UIKit

class PlayerWidgetContainerCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
