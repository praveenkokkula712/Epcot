//
//  PlayerStatsAccessibilityIdentifiers.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 04/07/24.
//

import Foundation

public struct PlayerStatsAccessibilityIdentifiers  {
    
    public static let backgroundImageLayer1             = "playerStats_backgroundImageLayer1"
    public static let backgroundImageLayer2             = "playerStats_backgroundImageLayer2"
    public static let backgroundImageLayer3             = "playerStats_backgroundImageLayer3"
    public static let lastWeekCta                       = "playerStats_lastWeekCta"
    public static let lastMonthCta                      = "playerStats_lastMonthCta"
    public static let title                             = "playerStats_title"
    public static let subTitle                          = "playerStats_subTitle"
    public static let gameTile                          = "playerStats_gameTile"
    public static let multiplerView                     = "playerStats_multiplerView"
    public static let multiplerDigit                    = "playerStats_multiplerDigit"
    public static let jpAmount                          = "playerStats_jpAmount"
}
