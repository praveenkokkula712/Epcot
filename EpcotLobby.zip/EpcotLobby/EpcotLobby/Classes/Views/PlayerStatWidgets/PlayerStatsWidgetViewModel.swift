//
//  PlayerStatsWidgetViewModel.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 27/06/24.
//

import Foundation
import CasinoAPI
import SwiftUI
import Combine

class PlayerStatsWidgetViewModel: ObservableObject {
    
    // MARK: Properties
    private static var instance: PlayerStatsWidgetViewModel?
    
    class weak var shared: PlayerStatsWidgetViewModel? {
        self.instance = self.instance ?? PlayerStatsWidgetViewModel()
        return self.instance
    }
    
    class func disposeShared() {
        self.instance = nil
    }
    
    private init() {
       
    }
    
    var feedDatasource: LobbyFeedDataSource?
    var texts: PlayerStatsConfigurations?
    var backgroundImages: PlayerStatsBackgroundImages?
    private(set) var immersiveInfo: ((Int, Game, Bool) -> ImmersiveGameInfo?)?
    var onGameTap: ((String) -> Void)?
    
    var weeklyGameTiles = [PlayerStatsGameTile]()
    var monthlyGameTiles = [PlayerStatsGameTile]()
    @Published var isWeeklyGamesSelected: Bool = false
    
    private var subscriber: AnyCancellable?
    private var jackpotTimer: DispatchTimer?
    private(set) var gameTilePublisher = GameTilePublisher()
    
    
    deinit {
        self.stopJackpotTimer()
        ETLogger.debug("Deinit")
    }
    
    func configure(feedDatasource: LobbyFeedDataSource, texts: PlayerStatsConfigurations, backgroundImages: PlayerStatsBackgroundImages, onGameTap: @escaping (String) -> Void) {
        self.feedDatasource = feedDatasource
        self.texts = texts
        self.backgroundImages = backgroundImages
        self.onGameTap = onGameTap
        self.configureImmersiveInfo()
        self.subscribeToRefresh()
        self.configureGames()
        self.startJackpotTimer()
        self.isWeeklyGamesSelected = weeklyGameTiles.count > 1
    }
    
    private func configureGames() {
        let lastWeekGames =  feedViewModel?.feedModel?.lobbyFeedObj?.weeklyStats ?? []
        let lastMonthGames = feedViewModel?.feedModel?.lobbyFeedObj?.monthlyStats ?? []
        self.weeklyGameTiles = createGameTiles(for: lastWeekGames)
        self.monthlyGameTiles = createGameTiles(for: lastMonthGames)
    }
    
    private func createGameTiles(for games: [WinnerMultiplierDetails]) -> [PlayerStatsGameTile] {
        
        var gameTiles = [PlayerStatsGameTile]()
        let onlyTwoGamesAvailable =  games.count == 2
        games.enumerated().forEach { index, game in
            let gameVaraint = Game(game: game.gameVariant ?? "")
            let gameImmersiveInfo = self.immersiveInfo?(index, gameVaraint, onlyTwoGamesAvailable)
            let gameTile = PlayerStatsGameTile(game: gameVaraint,
                                               immersiveInfo: gameImmersiveInfo,
                                               publisher: gameTilePublisher, 
                                               multiplier: game.multiplier)
            gameTiles.append(gameTile)
        }
        return gameTiles
    }
    
    private func configureImmersiveInfo() {
        self.immersiveInfo = { [weak self] index, game, onlyTwoGamesAvailable in
            let gameVariant = game.game
            return self?.feedViewModel?.getImmersiveInfo(for: gameVariant ?? "",
                                                         with: index == 0 || onlyTwoGamesAvailable ? "\(LayoutType.playerStatsWidget.rawValue)" : "\(LayoutType.horizontalGrid.rawValue)")
        }
    }
    
    func onButtonClick(fromlastWeek: Bool) {
        self.isWeeklyGamesSelected = fromlastWeek
    }
}

//MARK: - Jackpot
extension PlayerStatsWidgetViewModel {
    
    // MARK: Subscriptions
    private func subscribeToRefresh() {
        self.subscriber = self.feedDatasource?.feedViewModel?.refreshLobby
            .subscribe(on: DispatchQueue.main)
            .sink { [weak self] shouldRefresh in
                guard let self else { return }
                if shouldRefresh {
                    self.stopJackpotTimer()
                    self.startJackpotTimer()
                } else {
                    //No need to call this method, if 'sholudRefresh' is true, because it atomatically updates the view
                    self.refreshJackporPrices()
                }
            }
    }
    
    private func startJackpotTimer() {
        guard  self.jackpotTimer == nil else { return }
        let randomInterval = Double.random(in: 1...6)
        self.jackpotTimer =  DispatchTimer(interval: randomInterval) { [weak self] in
            self?.refreshJackpot()
        }
    }
    
    private func stopJackpotTimer() {
        guard self.jackpotTimer != nil else { return }
        self.jackpotTimer?.cancel()
        self.jackpotTimer = nil
    }
    
    private func refreshJackpot() {
        self.stopJackpotTimer()
        ///counter jackpot time update
        self.gameTilePublisher.send(nil)
        self.startJackpotTimer()
    }
    
    private func refreshJackporPrices () {
        if let jpPrices = self.feedViewModel?.getAllJackpotAmounts() {
            let jackpots = GameTileReceiver(jackpot: jpPrices)
            gameTilePublisher.send(jackpots)
        }
    }
}


//MARK: - UI Content
extension PlayerStatsWidgetViewModel {
    
    var games: [PlayerStatsGameTile] {
        return isWeeklyGamesSelected ? weeklyGameTiles : monthlyGameTiles
    }
    
    var onlyTwoGamesAvailable: Bool {
        return isWeeklyGamesSelected ? weeklyGameTiles.count == 2 : monthlyGameTiles.count == 2
    }
    
    var lastWeekCta: String {
        return texts?.lastWeekCta ?? ""
    }
    
    var lastMonthCta: String {
        return texts?.lastMonthCta ?? ""
    }
    
    var lastWeekText: String {
        return texts?.lastWeekText ?? ""
    }
    
    var lastMonthText: String {
        return texts?.lastMonthText ?? ""
    }
    
    var weeklyTitle: String {
        return texts?.weeklyTitle ?? ""
    }
    
    var monthlyTitle: String {
        return texts?.monthlyTitle ?? ""
    }
    
    var weeklySubTitle: String {
        return texts?.weeklySubTitle ?? ""
    }
    
    var monthlySubTitle: String {
        return texts?.monthlySubTitle ?? ""
    }
    
    var multiplier: String {
        return texts?.multipliercomponent ?? ""
    }
    
    var lastWeekOrLastMonthText: String {
        return isWeeklyGamesSelected ? lastWeekText : lastMonthText
    }
    
    var title: String {
        return isWeeklyGamesSelected ? weeklyTitle : monthlyTitle
    }
    
    var subTitle: String {
        return isWeeklyGamesSelected ? weeklySubTitle : monthlySubTitle
    }
    
    var backgroundImageLaye1: String {
        return backgroundImages?.backgroundImageLayer1 ?? ""
    }
    
    var backgroundImageLayer2: String {
        return backgroundImages?.backgroundImageLayer2 ?? ""
    }
    
    var backgroundBottomImage: String {
        return backgroundImages?.backgroundBottomImage ?? ""
    }
    
    var feedViewModel: FeedViewModel? {
        self.feedDatasource?.feedViewModel
    }
}
