//
//  PlayerStatsWidgetCss.swift
//  Utility
//
//  Created by Sreekanth Reddy Tadi on 02/07/24.
//

import Foundation
import SwiftUI
import Utility

struct PlayerStatsWidgetCss {
    var widgetCornerRadius: CGFloat
    
    var selectedPeriodBgColor: Color
    var selectedPeriodCornerRadius: CGFloat
    var selectedPeriodTitleColor: Color
    var selectedPeriodTitleFont: Font

    var unSelectedPeriodGradientColors: [Color]
    var unSelectedPeriodCornerRadius: CGFloat
    var unSelectedPeriodTitleColor: Color
    var unSelectedPeriodTitleFont: Font

    var unSelectedPeriodBorderWidth: CGFloat
    var unSelectedPeriodBorderColor: Color
    
    var titleColor: Color
    var titleFont: Font

    var titleCtaColor: Color
    var titleCtaFont: Font
    
    var messageTextColor: Color
    var messageTextFont: Font
    var messageTextOpacity: CGFloat
    
    var gameTileCornerRadius: CGFloat
    var multiplierViewBgColor: Color
    var multiplierViewBorderColor: Color
    var multiplierViewBorderWidth: CGFloat
    var multiplierViewCornerRadius: CGFloat
    var multiplierDigitViewBgColor: Color
    var multiplierDigitColor: Color
    var multiplierDigitFont: Font
    var multiplierDigitViewCornerRadius: CGFloat
    
    var jpPriceBgColor: Color
    var jpPriceColor: Color
    var jpPriceFont: Font
    var jpPriceSecondColor: Color
    var jpPriceSecondFont: Font

    init() {
        let css: PlayerStatsWidgetCSS? = CasinoCSS.lobby?.playerStatsWidgetCSS
        
        self.widgetCornerRadius = css?.playerStatsWidgetCornerRadius ?? Self.defaultWidgetCornerRadius
        
        self.selectedPeriodBgColor = (css?.statsPeriodSelectedBgColor ?? Self.defaultSelectedPeriodBgColor).swiftUIColor
        self.selectedPeriodCornerRadius = css?.statsPeriodSelectedCornerRadius ?? Self.defaultSelectedPeriodCornerRadius
        
        self.selectedPeriodTitleColor = (css?.statsPeriodSelectedTitle?.color ?? Self.defaultSelectedPeriodTitleColor).swiftUIColor
        self.selectedPeriodTitleFont = Font(css?.statsPeriodSelectedTitle?.font ?? Self.defaultSelectedPeriodTitleFont)
        
        let gradientColors = (css?.statsPeriodUnSelected?.gradientColors ?? Self.defaultUnSelectedPeriodGradientColors).reduce(into: [Color]()) { partialResult, uiColor in
            partialResult.append(uiColor.swiftUIColor)
        }
        self.unSelectedPeriodGradientColors = gradientColors
        
        self.unSelectedPeriodCornerRadius = css?.statsPeriodUnSelected?.cornerRadius ?? Self.defaultUnSelectedPeriodCornerRadius
        self.unSelectedPeriodTitleColor = (css?.statsPeriodUnSelected?.title?.color ?? Self.defaultUnSelectedPeriodTitleColor).swiftUIColor
        self.unSelectedPeriodTitleFont = Font(css?.statsPeriodUnSelected?.title?.font ?? Self.defaultUnSelectedPeriodTitleFont)
        
        
        self.unSelectedPeriodBorderWidth = css?.statsPeriodUnSelected?.borderWidth ?? Self.defaultUnSelectedPeriodBorderWidth
        self.unSelectedPeriodBorderColor = (css?.statsPeriodUnSelected?.borderColor ?? Self.defaultUnSelectedPeriodBorderColor).swiftUIColor
        
        
        self.titleColor = (css?.title?.color ?? Self.defaultTitleColor).swiftUIColor
        self.titleFont = Font(css?.title?.font ?? Self.defaultTitleFont)
        
        self.titleCtaColor = (css?.titleCta?.color ?? Self.defaultTitleCtaColor).swiftUIColor
        self.titleCtaFont = Font(css?.titleCta?.font ?? Self.defaultTitleCtaFont)
    
        self.messageTextColor = (css?.message?.color ?? Self.defaultMessageTextColor).swiftUIColor
        self.messageTextFont = Font(css?.message?.font ?? Self.defaultMessageTextFont)

        self.messageTextOpacity = css?.messageTextOpacity ?? Self.defaultMessageTextOpacity
        
        self.gameTileCornerRadius = css?.gameTileCornerRadius ?? Self.defaultGameTileCornerRadius
        self.multiplierViewBgColor = (css?.multiplierViewBgColor ?? Self.defaultMultiplierViewBgColor).swiftUIColor
        self.multiplierViewBorderColor = (css?.multiplierViewBorderColor ?? Self.defaultMultiplierViewBorderColor).swiftUIColor
        self.multiplierViewBorderWidth = css?.multiplierViewBorderWidth ?? Self.defaultMultilierViewBorderWidth
        self.multiplierViewCornerRadius = css?.multiplierViewCornerRadius ?? Self.defaultMultiplierViewCornerRadius
        self.multiplierDigitViewBgColor = (css?.multiplierDigitViewBgColor ?? Self.defaultMultiplierDigitBgColor).swiftUIColor
        self.multiplierDigitColor = (css?.multiplierDigit?.color ?? Self.defaultMultiplierDigitColor).swiftUIColor
        self.multiplierDigitFont = Font(css?.multiplierDigit?.font ?? Self.defaultMultiplierDigitFont)
        self.multiplierDigitViewCornerRadius = css?.multiplierDigitViewCornerRadius ?? Self.defaultMultiplierDigitCornerRadius
        
        self.jpPriceBgColor = (css?.jpPriceBgColor ?? Self.defaultJpPriceBgColor).swiftUIColor
        self.jpPriceColor = (css?.jpPrice?.color ?? Self.defaultJpPriceColor).swiftUIColor
        self.jpPriceFont = Font(css?.jpPrice?.font ?? Self.defaultJpPriceFont)
        self.jpPriceSecondColor = (css?.jpPriceTwo?.color ?? Self.defaultJpPriceColor).swiftUIColor
        self.jpPriceSecondFont = Font(css?.jpPriceTwo?.font ?? Self.defaultJpPriceFont2)
    }
}

extension PlayerStatsWidgetCss {
    private static var defaultWidgetCornerRadius: CGFloat { 2.0 }
    private static var defaultSelectedPeriodBgColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultSelectedPeriodCornerRadius: CGFloat { 4.0 }
    private static var defaultSelectedPeriodTitleColor: UIColor { .hexStringToUIColor(hex: "#333333") }
    private static var defaultSelectedPeriodTitleFont: UIFont { .systemFont(ofSize: 16.0) }

    private static var defaultUnSelectedPeriodGradientColors: [UIColor] { [.hexStringToUIColor(hex: "#FFFFFF", withAlpha: 0.4),
                                                                           .hexStringToUIColor(hex: "#FFFFFF", withAlpha: 0.1)] }
    private static var defaultUnSelectedPeriodCornerRadius: CGFloat { 3.0 }
    private static var defaultUnSelectedPeriodTitleColor: UIColor { .hexStringToUIColor(hex: "#EAEAEA", withAlpha: 0.1) }
    private static var defaultUnSelectedPeriodTitleFont: UIFont { .systemFont(ofSize: 16.0) }

    private static var defaultUnSelectedPeriodBorderWidth: CGFloat { 1.0 }
    private static var defaultUnSelectedPeriodBorderColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF", withAlpha: 0.2) }
    
    private static var defaultTitleColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultTitleFont: UIFont { .boldSystemFont(ofSize: 16.0) }

    private static var defaultTitleCtaColor: UIColor { .hexStringToUIColor(hex: "#FFCC00") }
    private static var defaultTitleCtaFont: UIFont { .boldSystemFont(ofSize: 16.0) }
    
    private static var defaultMessageTextColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultMessageTextFont: UIFont { .systemFont(ofSize: 10.0) }
    private static var defaultMessageTextOpacity: CGFloat { 0.8 }
    
    private static var defaultGameTileCornerRadius: CGFloat { 4.0 }
    private static var defaultMultiplierViewBgColor: UIColor { .hexStringToUIColor(hex: "#5C5C5C", withAlpha: 0.8) }
    private static var defaultMultiplierViewBorderColor: UIColor { .hexStringToUIColor(hex: "#333333") }
    private static var defaultMultilierViewBorderWidth: CGFloat { 2.0 }
    private static var defaultMultiplierViewCornerRadius: CGFloat { 2.0 }
    private static var defaultMultiplierDigitBgColor: UIColor { .hexStringToUIColor(hex: "#FFCC00") }
    private static var defaultMultiplierDigitColor: UIColor { .hexStringToUIColor(hex: "#333333") }
    private static var defaultMultiplierDigitFont: UIFont { .systemFont(ofSize: 20.0) }
    private static var defaultMultiplierDigitCornerRadius: CGFloat { 2.0 }
    private static var defaultJpPriceBgColor: UIColor { .hexStringToUIColor(hex: "#333333", withAlpha: 0.8) }
    private static var defaultJpPriceColor: UIColor { .hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultJpPriceFont: UIFont { .boldSystemFont(ofSize: 16.0) }
    private static var defaultJpPriceFont2: UIFont { .boldSystemFont(ofSize: 12.0) }
}
