//
//  PlayerStatsWidgetView+EventsTracker.swift
//  EpcotLobby
//
//  Created by Santhosh Kodadi on 18/07/24.
//

import Utility
import TrackerClient

extension PlayerStatsWidgetViewModel {
    func trackEvent(categoryEvent: String = "",
                    actionEvent: String = "",
                    labelEvent: String = "",
                    eventDetails: String = "",
                    gameInfo: PlayerStatsGameTile? = nil,
                    gameCategory: String = "",
                    gamePosition: String = "",
                    gamePlayingStatus: String = "",
                    eventType: EventType = EventType.view_item_list) {
        DispatchQueue(label: kTrackEventQueue).async {
            switch eventType {
            case .view_item_list, .game_launch:
                let immersiveInfo = gameInfo?.immersiveInfo?.gameInfo
                let log = InteractionLog(categoryEvent: categoryEvent,
                                         actionEvent: actionEvent,
                                         labelEvent: labelEvent,
                                         eventDetails: eventDetails,
                                         gameCategory: gameCategory,
                                         gameType: immersiveInfo?.gameMetadata.provider ?? "",
                                         gameContainerLocation: GameEvents.GameContainerlocation.lobby.rawValue,
                                         categoryType: ScreenName.casino.rawValue,
                                         categorySubType: ScreenName.home.rawValue,
                                         gamePlayingStatus: gamePlayingStatus,
                                         gamePosition: gamePosition,
                                         gameName: immersiveInfo?.gameMetadata.name ?? "",
                                         gameId: immersiveInfo?.gameMetadata.game ?? "",
                                         itemListID: EpcotEventItems.item_list_id.rawValue,
                                         itemListName: EpcotEventItems.item_list_name.rawValue,
                                         gameContainerDesc: GameEvents.GameContainerdesc.not_applicable.rawValue,
                                         gameFav: immersiveInfo?.isFavouriteGame.description ?? false.description)
                let event = TrackerEvent(type: eventType, log: log, tracker: .gtm)
                Tracker.postNotification(object: self, userInfo: [kEvent: event])
                
            case .casino_widgets:
                let log = InteractionLog(categoryEvent: EpcotEventCategory.casino_widgets.rawValue,
                                         actionEvent: EpcotEventAction.click.rawValue,
                                         labelEvent: EpcotEventLabel.multiplier_widget.rawValue,
                                         locationEvent: ScreenName.casino.rawValue,
                                         eventDetails: eventDetails,
                                         positionEvent: gamePosition,
                                         productType: ScreenName.casino.rawValue,
                                         userID: EntainContext.user?.accountId ?? "",
                                         appInfo: EpcotEventAppInfo.casinow.rawValue,
                                         screenName: GameEvents.GameContainerlocation.lobby.rawValue)
                let event = TrackerEvent(type: eventType, log: log, tracker: .gtm)
                Tracker.postNotification(object: self, userInfo: [kEvent: event])
                
            default:
                break
            }
        }
    }
}
