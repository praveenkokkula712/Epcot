//
//  GridLayout.swift
//  SampleCollectionView
//
//  Created by Santhosh Kodadi on 07/02/23.
//

import Foundation
import UIKit

class GridCollectionViewLayout: UICollectionViewFlowLayout {
        
    override init() {
        super.init()
        setupLayout()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupLayout()
    }
   
    private func setupLayout() {
        minimumInteritemSpacing = 3
        minimumLineSpacing = 8
        scrollDirection = .vertical
        sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
    }
    
    /// width of cell and creating number of columns 
    var itemWidth: CGFloat {
        let fraction : CGFloat = UIDevice.isIPad() ? 6 : 3
        let width = UIDevice.screenSize.width
        return width / fraction - (minimumLineSpacing * 2)
    }
    override var itemSize: CGSize {
        set {
            self.itemSize = CGSize(width: itemWidth, height: itemWidth)
            
        }
        get {
            return CGSize(width: itemWidth, height: itemWidth)
        }
    }
    
    override func targetContentOffset(forProposedContentOffset proposedContentOffset: CGPoint) -> CGPoint {
        return collectionView?.contentOffset ?? CGPoint(x: 5, y: 5)
    }
}
