//
//  PortraiSectionCollectionViewCell.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 01/09/22.
//

import UIKit
import CasinoAPI
import Combine
import Utility
import SVGKit
import SDWebImage
import SDWebImageSVGKitPlugin
import ConfigModule

class PortraitSectionCollectionViewCell: EpcotBaseCollectionViewCell {

    @IBOutlet private weak var priceHolderView: UIView!
    @IBOutlet private weak var priceLabel: UILabel!
    @IBOutlet private weak var priceImage: UIImageView!
    @IBOutlet private weak var viewOpaque: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var gameImageView: UIImageView!
    @IBOutlet private weak var favouriteButton: FavouritesButton!
    @IBOutlet private weak var stickerLabel: StickerLabel!
    @IBOutlet private weak var jackpotStackView: UIStackView!
    
    var isFavouriteGame: FavouriteState = .unselected {
        didSet {
            self.favouriteButton.isFavouriteSelected = isFavouriteGame
        }
    }
    
    private var jackpotAmount: String? {
        didSet {
            self.updateAmount(amount: jackpotAmount)
        }
    }
    
    private var fireIconImageUrl: String = "" {
        didSet {
            if fireIconImageUrl.isSVG, let url = URL(string: fireIconImageUrl) {
                self.priceImage.sd_setImage(with: url)
            } else {
                self.priceImage.loadImage(withUrl: fireIconImageUrl)
            }
        }
    }
    
    private let epcotCss = EpcotLobbyManager.shared?.css
    private var gameVariant: String?
    private var pagingInfoToken: AnyCancellable?
    
    private var textAllignmentForJackpot: JackpotTitleAlignment {
        EpcotLobbyManager.shared?.datasource?.textAllignmentForJackpot ?? .left
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.updateView()
    }
    
    deinit {
        self.pagingInfoToken?.cancel()
        self.pagingInfoToken = nil
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.pagingInfoToken?.cancel()
        self.pagingInfoToken = nil
    }

    private func updateView() {
        self.contentView.getRoundedCorners(OfRadius: 8)
        self.gameImageView.getRoundedCorners(OfRadius: 8)
        
        //Jackpot View theming
        self.priceHolderView.getRoundedCorners(OfRadius: 8)
        self.priceHolderView.clipsToBounds = false
        self.priceHolderView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        self.priceHolderView.backgroundColor = self.epcotCss?.epcotLobbyCSS?.jackpotViewBackgroundColor ?? UIColor.white
        let layerColor =  self.epcotCss?.epcotLobbyCSS?.jackpotViewLayerBackgroundColor ?? UIColor(red: 0.02, green: 0.02, blue: 0.02, alpha: 0.4)
        self.priceHolderView.layer.backgroundColor = layerColor.cgColor
        self.priceImage.isHidden = false
        let jpView = self.epcotCss?.gridView?.jpView
        self.viewOpaque.backgroundColor = jpView?.jpBGColor
        self.priceLabel.font = jpView?.priceAmount?.font
        self.priceLabel.textColor = jpView?.priceAmount?.color
        self.jackpotStackView.alignment = textAllignmentForJackpot.alignment
    }
    
    func confiureImmersiveCell(with info: ImmersiveGameInfo, sticker: String? = nil) {
        let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS?.immersiveCSS?.portraitSectionCSS
        self.gameImageView.loadImage(withUrl: info.imagePath)
        self.titleLabel.textColor = css?.color ?? UIColor.white
        self.titleLabel.text = info.gameInfo.gameMetadata.name ?? ""
        self.titleLabel.font = css?.font ?? UIFont.systemFont(ofSize: 10)
        self.isFavouriteGame = info.gameInfo.isFavouriteGame.favouriteState
        self.gameVariant = info.gameInfo.gameVariantName
        self.stickerLabel.updateContent(with: sticker)
        self.jackpotAmount = info.gameInfo.jpPrice
        if info.gameInfo.isHotJackpotGame {
            self.fireIconImageUrl = info.fireIconImagePath
        }
        self.priceImage.isHidden = !info.gameInfo.isHotJackpotGame
    }

    @IBAction func didClickOnFavouriteButton(sender: FavouritesButton) {
        sender.tapAnimation {[weak self] in
            guard let self = self else { return }
            sender.isSelected = !sender.isSelected
            self.favouriteButton.isFavouriteSelected = sender.isSelected ? .selected : .unselected
            self.favouritesDelegate?.didTappedOn(favourites: self,
                                                 gameVariant: self.gameVariant ?? "",
                                                 state: sender.isSelected)
        }
        Haptics.play(.light)
    }
}

//MARK: - Configure methods.
extension PortraitSectionCollectionViewCell {
    
    func subscribeTo(subject: PassthroughSubject<[String: String]?, Never>) {
        pagingInfoToken = subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] values in
                guard let self else { return }
                guard let values = values else {
                    guard let amount = self.jackpotAmount?.jackpotCounterAmount else { return }
                    self.jackpotAmount = amount
                    return
                }
                if let gameVariantName = self.gameVariant,
                   let jpPrice = values[gameVariantName] {
                    self.jackpotAmount = jpPrice
                }
            }
    }
    
    /// this method will invoked when amout is updaing from jackpot
    private func updateAmount(amount: String?) {
        if let _amount = amount {
            self.priceHolderView.isHidden = false
            self.priceLabel.text = _amount
        } else {
            self.priceHolderView.isHidden = true
        }
    }
}
