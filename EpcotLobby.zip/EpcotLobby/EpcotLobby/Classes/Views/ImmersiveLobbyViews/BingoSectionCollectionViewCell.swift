//
//  BrandAdvertiseCollectionViewCell.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 31/01/23.
//

import UIKit
import Utility

class BingoSectionCollectionViewCell: UICollectionViewCell {
    
    var css: BingoButtonCSS?  {
        EpcotLobbyManager.shared?.css.bingoButtonCSS
    }
    
    var logoLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.configureCell()
    }
    
    private func configureCell() {
        self.logoLabel.configure(on: self.contentView)
        self.logoLabel.textColor = self.css?.titleCss?.color ?? .white
        self.logoLabel.font = self.css?.titleCss?.font ?? UIFont.boldSystemFont(ofSize: 12)
        self.logoLabel.text = "open_Bingo_Lobby".localized
        self.contentView.backgroundColor = self.css?.backgroundColor ?? UIColor.hexStringToUIColor(hex: "#FE368A")
        self.contentView.getRoundedCorners(OfRadius: self.css?.cornerRadius ?? 4.0)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
     
}
