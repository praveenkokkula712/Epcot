//
//  GamesLayoutView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 25/06/24.
//

import SwiftUI

struct GamesLayoutView: View {
    
    // MARK: Properties
    let layout: LayoutType
    @ObservedObject var viewModel: GamesEssentialsViewModel

    // MARK: Init
    init(layout: LayoutType, viewModel: GamesEssentialsViewModel) {
        self.layout = layout
        self.viewModel = viewModel
    }

    // MARK: Body
    var body: some View {
        switch layout {
        case .topGamesImmersiveGrid:
            HorizontalTop10GamesView(layout: layout, games: viewModel.gameTiles, onGameTap: viewModel.onGameTap)
        case .topGamesHorizontalGrid:
            HorizontalTop10GamesView(layout: layout, games: viewModel.gameTiles, onGameTap: viewModel.onGameTap)
        case .topGamesPortraitGrid:
            HorizontalTop10GamesView(layout: layout, games: viewModel.gameTiles, onGameTap: viewModel.onGameTap)
        default:
            EmptyView()
        }
    }
}
