import SwiftUI
import Utility
import TrackerClient

struct JackpotFusionInfoView: View {
    @State private var textHeight: CGFloat = 0
    @State var size: CGSize = .zero
    @State var isScrollEnabled: Bool = false
    var jackpotFusionInfoModel: JackpotFusionInfoModel
    var closeAction: (() -> ())?
    var seeAllGamesAction: (() -> ())?
    @State private var closeScaleValue = 1.0
    @State private var seeAllBtnScaleValue = 1.0
    @State private var isLoaded = false
    
    let fusionPopUpCss = JackpotFusionInfoViewCSSModel(css: EpcotLobbyManager.shared?.css.jackpotFusionPopUpViewCSS)
    
    private var isEpcotFeatureEnabled: Bool {
        return EpcotLobbyManager.shared?.css.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false
    }
    
    var body: some View {
        GeometryReader(content: { proxy in
            ZStack {
                Color.black.opacity(0.4)
                    .edgesIgnoringSafeArea(.all)
                    .onTapGesture {
                        self.closeAction?()
                        self.trackEvent(actionEvent: EpcotEventAction.close.rawValue,
                                         eventDetails: EpcotEventDetails.close.rawValue,
                                         eventPosition: jackpotFusionInfoModel.title)
                    }
                VStack {
                    HStack {
                        Text(jackpotFusionInfoModel.title)
                            .font(fusionPopUpCss.headerTitleFont)
                            .foregroundColor(fusionPopUpCss.headerTitleColor)
                            .padding(.leading)
                            .accessibilityIdentifier("jackpotFusion_Title")
                        if let badge = jackpotFusionInfoModel.badge {
                            Text(badge)
                                .font(fusionPopUpCss.badgeTitleFont)
                                .foregroundColor(fusionPopUpCss.badgeTitleColor)
                                .padding(.horizontal, 5)
                                .padding(.vertical, 2)
                                .background(fusionPopUpCss.badgeBackgroundColor)
                                .cornerRadius(fusionPopUpCss.badgeButtonCornerRadius)
                                .accessibilityIdentifier("jackpotFusion_Badge")
                        }
                        Spacer()
                        Button(Localize.close) {
                            Haptics.play(.light)
                            self.closeScaleValue = 0.95
                            withAnimation(Animation.linear.delay(0.2)) {
                                self.closeScaleValue = 1.0
                                self.closeAction?()
                                self.trackEvent(actionEvent: EpcotEventAction.close.rawValue,
                                                 eventDetails: EpcotEventDetails.close.rawValue,
                                                 eventPosition: jackpotFusionInfoModel.title)
                            }
                        }
                        .font(fusionPopUpCss.closeButtonTitleFont)
                        .foregroundColor(fusionPopUpCss.closeButtonTitleColor)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 16)
                        .background(Capsule() .stroke(fusionPopUpCss.closeButtonBorderColor, lineWidth: fusionPopUpCss.closeButtonBorderWidth))
                        .padding(.trailing, 8)
                        .accessibilityIdentifier("jackpotFusion_Close")
                    }
                    .frame(height: 60)
                    .background(fusionPopUpCss.headerBackgroundColor)
                    
                    ScrollView(showsIndicators: !isScrollEnabled) {
                        AttributedText(htmlContent: jackpotFusionInfoModel.content,
                                       size: $size,
                                       isLoaded: $isLoaded,
                                       jackpotInfoViewContentValues: fusionPopUpCss.contentModel)
                            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, idealHeight: size.height, maxHeight: .infinity)
                            .padding(.leading, 4)
                            .fixedSize(horizontal: false, vertical: true)
                            .background(GeometryReader {
                                Color.clear.preference(key: TextHeightKey.self, value: $0.frame(in: .local).size.height)
                            })
                            .accessibilityIdentifier("jackpotFusion_Content")
                    }
                    .disabled(isScrollEnabled)
                    if jackpotFusionInfoModel.isSeeAllAvailable {
                        Button(action: {
                            Haptics.play(.light)
                            self.seeAllBtnScaleValue = 0.95
                            withAnimation(Animation.linear.delay(0.2)) {
                                self.seeAllBtnScaleValue = 1.0
                                self.seeAllGamesAction?()
                                self.trackEvent(actionEvent: EpcotEventAction.click.rawValue,
                                                 eventDetails: EpcotEventDetails.see_all_games.rawValue,
                                                 eventPosition: jackpotFusionInfoModel.title)
                            }
                        }) {
                            Text(Localize.seeAllGames)
                                .frame(maxWidth: .infinity)
                                .font(fusionPopUpCss.seeallButtonTitleFont)
                                .foregroundColor(fusionPopUpCss.seeallButtonTitleColor)
                                .padding()
                                .applyEpcotGradientBgColor(backgroundColor: fusionPopUpCss.backgroundColor,
                                                           font: fusionPopUpCss.seeallButtonTitleFont,
                                                           textColor: fusionPopUpCss.seeallButtonTitleColor,
                                                           cornerRadius: fusionPopUpCss.seeallButtonCornerRadius,
                                                           isEpcotEnabled: isEpcotFeatureEnabled)

                        }
                        .padding(.all, 10)
                        .accessibilityIdentifier("jackpotFusion_SeeAll_Games")
                    }
                }
                .background(fusionPopUpCss.contentBackgroundColor)
                .cornerRadius(fusionPopUpCss.contentViewCornerRadius)
                .padding()
                .onPreferenceChange(TextHeightKey.self) {
                    textHeight = $0
                    isScrollEnabled = proxy.size.height * 0.7 > textHeight
                }
                .frame(width: UIDevice.isIPad() ? proxy.size.width * 0.75 : proxy.size.width)
                .frame(height: min(proxy.size.height * 0.7,textHeight) + 130) // Add some extra height for padding and button
            }
            .opacity(isLoaded ? 1 : 0)
            .onAppear {
                self.trackEvent(actionEvent: EpcotEventAction.load.rawValue,
                                 eventDetails: EpcotEventDetails.megajackpot_pop_up_load.rawValue,
                                 eventPosition: jackpotFusionInfoModel.title)
            }
        })
    }
}

struct JackpotFusionInfoView_Previews: PreviewProvider {
    static var previews: some View {
        JackpotFusionInfoView(jackpotFusionInfoModel: JackpotFusionInfoModel(title: "", content: "",badge: "", isSeeAllAvailable: false))
    }
}

extension JackpotFusionInfoView {
    private func trackEvent(actionEvent: String, eventDetails: String, eventPosition: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.global_jackpots.rawValue,
                                     actionEvent: actionEvent,
                                     labelEvent: EpcotEventLabel.reveal_card.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: eventDetails,
                                     positionEvent: eventPosition)
            let event = TrackerEvent(type: .jackpots, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}
