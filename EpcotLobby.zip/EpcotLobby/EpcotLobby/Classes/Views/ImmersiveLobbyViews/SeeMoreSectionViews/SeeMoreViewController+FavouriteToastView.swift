//
//  SeeMoreViewController+FavouriteToastView.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 11/05/23.
//

import Foundation
import SwiftUI

extension SeeMoreSectionViewController {
    
    // MARK: - Setup Toast
    func setupFavoriteToastView(viewModel: FavoriteToastViewModel) {
        guard self.toastFavoriteView == nil else { return }
        let viewCSS = EpcotLobbyManager.shared?.css.favoriteToasterViewCSS
        var css = DefaultFavoriteToasterViewCSS(css: viewCSS)
        var viewModel = viewModel
        viewModel.isCTAEnabled = false
        self.toastFavoriteView = FavoriteToasterView(viewModel: viewModel,  css: css) { }
        let favoriteToastViewController = UIHostingController(rootView: self.toastFavoriteView)
        if let toastView = favoriteToastViewController.view {
            let screenWidth = UIDevice.screenSize.width
            let width = UIDevice.isIPad() ? screenWidth * 0.5 : (screenWidth - 32)
            toastView.frame = CGRect(origin: .zero, size: CGSize(width: width, height: 64))
            toastView.layer.cornerRadius = css.viewCornerRadius
            toastView.layer.masksToBounds = false
            favouriteToastView.addSubview(toastView)
        }
        favouriteToastView.backgroundColor = .clear
        favouriteToastView.dropShadow(color: css.shadowColor,
                                     offSet: CGSize(width: 0, height: 4),
                                     shadowRadius: 5)
        view.bringSubviewToFront(favouriteToastView)
    }

    // MARK: - Display Toast
    func displayFavoriteToastView(with viewModel : FavoriteToastViewModel, state: FavouriteState) {
        self.setupFavoriteToastView(viewModel: viewModel)
        if let count = feedViewModel?.favouriteGames?.count {
            if count == 1, state == .selected {
                showFavoriteToastView()
            } else {
                hideFavoriteToastView()
            }
        }
    }
    
    private func showFavoriteToastView() {
        createTimer()
        favouriteToastBottomConstraint.constant = 22.0
        animateToastView()
    }

    @objc func hideFavoriteToastView() {
        destroyTimer()
        DispatchQueue.main.async {
            self.favouriteToastBottomConstraint.constant = -200.0
            self.animateToastView()
        }
    }
    
    private func animateToastView() {
        UIView.animate(withDuration: 0.2,
                       delay: 0,
                       options: .curveEaseIn) {
            self.view.layoutIfNeeded()
        }
    }

    // MARK: - Hide Toast on Delay
    private func createTimer() {
        let timeout = favoriteToastConfig?.favoriteToastTimeout ?? 5
        favoriteToastTimer = DispatchTimer(
            interval: TimeInterval(timeout),
            handler: hideFavoriteToastView
        )
    }

    private func destroyTimer() {
        favoriteToastTimer?.cancel()
    }
}

