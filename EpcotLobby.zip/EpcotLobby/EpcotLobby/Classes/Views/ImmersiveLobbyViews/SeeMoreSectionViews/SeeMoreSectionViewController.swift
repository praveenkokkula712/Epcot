//
//  SeeMoreSectionViewController.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 24/08/22.
//

import UIKit
import CasinoAPI
import TrackerClient
import Combine

class SeeMoreSectionViewController: EpcotBaseViewController {

    @IBOutlet weak var collectionHolderView: UIView!
    @IBOutlet weak var tiltleView: UIView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var gridButton: UIButton!
    @IBOutlet weak var listButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var jpGamesTitleLabel: UILabel!
    @IBOutlet var topSpacing, centerSpacing, bottomSpacing: NSLayoutConstraint!
    
    @IBOutlet weak var favouriteToastBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var favouriteToastView: UIView!
    
    var onClickedGamePlay: GamePlayHandler?
    weak var delegate: ImmersiveLobbyCollectionControllerDelegate?
    
    private var games:[Game]?
    private var datasource: LobbyFeedDataSource?
    private(set) var seeMoreCollectionView: SeeMoreSectionCollectionViewController?
    private var subCategoryName: String?
    
    private var isJackpotWidgetGames = false
    
    private var jackpotAmount = "" {
        didSet {
            self.priceLabel.text = jackpotAmount
        }
    }
    
    private var jackpotTimer: DispatchTimer?

    var layoutType: SwitcherCategoryType  = .list {
        didSet {
            self.setUpGridAndListViews()
        }
    }
    
    var toastFavoriteView: FavoriteToasterView?
    
    ///Layout for CollectionView
    private var isGridLayoutUsed: Bool = false {
            didSet {
                updateCollectionViewLayoutAppearance()
            }
        }
    
    private var gridLayout = GridCollectionViewLayout()
    private var listLayout = ListCollectionViewLayout()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupView()
        self.addObservers()
        self.setupCollectionView()
        self.addAccessibilityIdentifiers()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if isJackpotWidgetGames, !self.jackpotAmount.isEmpty {
            self.startJackpotTimer()
        }
        self.showOnboardingView()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.stopJackpotTimer()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        seeMoreCollectionView?.collectionView?.collectionViewLayout.invalidateLayout()
    }
    
    class func show(subCatgoryName name: String?, with games: [Game], dataSource: LobbyFeedDataSource?, isJackpotWidget: Bool = false, on presentingController: UIViewController) -> SeeMoreSectionViewController? {
        let controller = SeeMoreSectionViewController.loadFromNib()
        controller.datasource = dataSource
        controller.games = games
        controller.subCategoryName = name
        controller.isJackpotWidgetGames = isJackpotWidget
        let topViewController = EpcotLobbyManager.shared?.datasource?.controllerForLoadGame() ?? presentingController
        controller.modalPresentationStyle = .overFullScreen
        controller.modalPresentationCapturesStatusBarAppearance = true
        topViewController.presentDetail(controller)
        return controller
    }
    
    private func setupView() {
            // back Button
        let css = EpcotLobbyManager.shared?.css.seeMoreSectionView
        self.view.backgroundColor = css?.titleViewBackgroundColor
        self.headerView.backgroundColor = css?.collectionViewBGColor
        self.collectionHolderView.backgroundColor = css?.collectionViewBGColor
        let backImage = UIImage(named: kBack, in: Bundle(for: type(of: self)), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        self.backButton.setImage(backImage, for: .normal)
        self.backButton.backgroundColor = UIColor.clear
        self.backButton.tintColor = css?.backButtontint
        self.backButton.contentVerticalAlignment = .fill
        self.backButton.contentHorizontalAlignment = .fill
        
            // titleLabel
        self.titleLabel.font = css?.title?.font
        self.titleLabel.textColor = css?.title?.color
        self.titleLabel.text = self.subCategoryName ?? "Section Title"
        
            // Switcher Button
        self.listButton.backgroundColor = UIColor.clear
        self.gridButton.backgroundColor = UIColor.clear
        let selectedColor = (EpcotLobbyManager.shared?.css.seeMoreSectionView?.switcherSelectedColor) ?? UIColor.hexStringToUIColor(hex: "#fffff")
        let unselectedColor = (EpcotLobbyManager.shared?.css.seeMoreSectionView?.switcherUnselectedColor) ?? UIColor.hexStringToUIColor(hex: "#ADADAD")
        let gridIcon = UIImage(named: kGridLayoutIcon, in: Bundle(for:                    type(of:self)), with: nil)
        let listIcon = UIImage(named: kListLayoutIcon, in: Bundle(for:                    type(of:self)), with: nil)
        self.gridButton.setImage(gridIcon?.image(withTintColor: unselectedColor), for: .normal)
        self.gridButton.setImage(gridIcon?.image(withTintColor: selectedColor), for: .selected)
        self.listButton.setImage(listIcon?.image(withTintColor: unselectedColor), for: .normal)
        self.listButton.setImage(listIcon?.image(withTintColor: selectedColor), for: .selected)
        self.layoutType = EpcotLobbyManager.shared?.lobbySwitcherType ?? .list
            // TitleView
        
        self.tiltleView.backgroundColor = css?.titleViewBackgroundColor
        
        self.tiltleView.dropShadow(color: EpcotLobbyManager.shared?.css.navigationView?.shadowColor ?? UIColor.black, offSet: CGSize(width: 0, height: 3), shadowRadius: 2)
        self.tiltleView.superview?.bringSubviewToFront(self.tiltleView)
        
        if self.isJackpotWidgetGames {
            self.priceLabel.isHidden = false
            self.priceLabel.font = css?.headerPrice?.font
            self.priceLabel.textColor = css?.headerPrice?.color
            self.updateJackpotAmount()
            self.jpGamesTitleLabel.isHidden = false
            self.jpGamesTitleLabel.font = css?.headerTitle?.font
            self.jpGamesTitleLabel.textColor = css?.headerTitle?.color
            self.jpGamesTitleLabel.text = Localize.allqualifyingGames ?? "All Qualifying games"
            
            topSpacing.constant = 16
            centerSpacing.constant = 8
            bottomSpacing.constant = 4
        }
    }
    
    private func updateJackpotAmount() {
        if let subCategoryName = self.subCategoryName, let amount = self.feedViewModel?.getAmountForJackpotId(for: subCategoryName) {
            self.jackpotAmount = amount
        } else if let gameVariant = self.games?.first?.game, let amount = self.feedViewModel?.getJackpotAmount(for: gameVariant) {
            self.jackpotAmount = amount
        }
    }
    
    private func setupCollectionView() {
        guard let games = games else { return }
        self.seeMoreCollectionView = SeeMoreSectionCollectionViewController(games: games,
                                                                            datasource: self,
                                                                            isJackpotWidgetGames: self.isJackpotWidgetGames)
        self.seeMoreCollectionView?.onClickGameplay = { (selectedGame, additionalParams) in
                self.dismissDetail {[weak self] in
                    self?.onClickedGamePlay?(selectedGame, additionalParams)
                }
        }
        self.seeMoreCollectionView?.onJackpotUpdate = {[weak self] in
            if self?.isJackpotWidgetGames ?? false {
                self?.stopJackpotTimer()
                self?.updateJackpotAmount()
                self?.startJackpotTimer()
            }
        }
        self.seeMoreCollectionView?.delegate = self
        self.configureChildViewController(childController: self.seeMoreCollectionView ?? UIViewController(),
                                          onView: self.collectionHolderView)
    }
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        sender.tapAnimation {
            self.datasource = nil
            self.onClickedGamePlay = nil
            self.delegate = nil
            self.dismissDetail()
        }
    }
    
    fileprivate func updateCollectionViewLayoutAppearance() {
        let layout = isGridLayoutUsed ? gridLayout : listLayout
        UIView.animate(withDuration: 0.2) { () -> Void in
            self.seeMoreCollectionView?.collectionViewLayout.invalidateLayout()
            self.seeMoreCollectionView?.collectionView.setCollectionViewLayout(layout, animated: true)
        }
    }
    
    @IBAction func gridAction(_ sender: UIButton) {
        let instantInteraction = InteractionType.transform.interaction
        sender.tapAnimation(type: instantInteraction) {
            UserDefaults.userOnboardingLobbySwitcher = true
            guard self.layoutType == .list else { return }
            self.layoutType = .grid
            UserDefaults.lobbySwitcherType = SwitcherCategoryType.grid.rawValue
            self.setUpGridAndListViews()
            self.trackLobbySwitchEvent(selectionType: EpcotEventPosition.gridView.rawValue)
            self.isGridLayoutUsed = true
        }
    }
    
    @IBAction func listAction(_ sender: UIButton) {
        let instantInteraction = InteractionType.transform.interaction
        sender.tapAnimation(type: instantInteraction) {
            UserDefaults.userOnboardingLobbySwitcher = true
            guard self.layoutType == .grid else { return }
            self.layoutType = .list
            UserDefaults.lobbySwitcherType = SwitcherCategoryType.list.rawValue
            self.setUpGridAndListViews()
            self.trackLobbySwitchEvent(selectionType: EpcotEventPosition.listView.rawValue)
            self.isGridLayoutUsed = false
        }
    }
    
    private func setUpGridAndListViews() {
        
        self.gridButton.isSelected = layoutType == .grid
        self.listButton.isSelected = layoutType == .list
         
        self.seeMoreCollectionView?.collectionView.setContentOffset(.zero, animated: false)
        self.seeMoreCollectionView?.applySnapshot(isFromSwitcher: true)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        ETLogger.debug("Deinit \(type(of: self))")
    }
}

extension SeeMoreSectionViewController {
    
    private func startJackpotTimer() {
        guard  self.jackpotTimer == nil else { return }
        let randomValue = Double.random(in: 1...6)
        self.jackpotTimer =  DispatchTimer(interval: randomValue, handler: self.refreshJackpot)
    }
    
    private func stopJackpotTimer() {
        guard self.jackpotTimer != nil else { return }
        self.jackpotTimer?.cancel()
        self.jackpotTimer = nil
    }
    
    private func refreshJackpot() {
        guard self.isJackpotWidgetGames else { return }
        DispatchQueue.main.async {[weak self] in
            if  let amount = self?.jackpotAmount.jackpotCounterAmount {
                self?.stopJackpotTimer()
                self?.jackpotAmount = amount
                self?.startJackpotTimer()
            }
        }
    }
}

extension SeeMoreSectionViewController : LobbyFeedDataSource {
    var feedViewModel: FeedViewModel? {
        self.datasource?.feedViewModel
    }
}

extension SeeMoreSectionViewController {
    private func trackLobbySwitchEvent(selectionType: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.navigation.rawValue,
                                     actionEvent:EpcotEventAction.click.rawValue,
                                     labelEvent: EpcotEventLabel.topNavBar.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: EpcotEventDetails.lobbySwitch.rawValue,
                                     positionEvent: selectionType)
            
            let event = TrackerEvent(type: .lobbySwitch, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}

extension SeeMoreSectionViewController: ImmersiveLobbyCollectionControllerDelegate {
    func didTappedOnFavourites(gameVariant: String, state: Bool, from seeMoreSection: Bool) {
        self.delegate?.didTappedOnFavourites(gameVariant: gameVariant, state: state, from: seeMoreSection)
    }
}

//MARK: Adding Accessibility Identifiers
extension SeeMoreSectionViewController {
    private func addAccessibilityIdentifiers() {
        collectionHolderView.accessibilityIdentifier = AccessibilityIdentifiers.seemoreSection_collectionHolderView.rawValue
        tiltleView.accessibilityIdentifier = AccessibilityIdentifiers.seemoreSection_tiltleView.rawValue
        headerView.accessibilityIdentifier = AccessibilityIdentifiers.seemoreSection_headerView.rawValue
        titleLabel.accessibilityIdentifier = AccessibilityIdentifiers.seemoreSection_titleLabel.rawValue
        gridButton.accessibilityIdentifier = AccessibilityIdentifiers.seemoreSection_gridButton.rawValue
        listButton.accessibilityIdentifier = AccessibilityIdentifiers.seemoreSection_listButton.rawValue
        backButton.accessibilityIdentifier = AccessibilityIdentifiers.seemoreSection_backButton.rawValue
        priceLabel.accessibilityIdentifier = AccessibilityIdentifiers.seemoreSection_priceLabel.rawValue
        jpGamesTitleLabel.accessibilityIdentifier = AccessibilityIdentifiers.seemoreSection_jpGamesTitleLabel.rawValue
        favouriteToastView.accessibilityIdentifier = AccessibilityIdentifiers.seemoreSection_favouriteToastView.rawValue
    }
}
