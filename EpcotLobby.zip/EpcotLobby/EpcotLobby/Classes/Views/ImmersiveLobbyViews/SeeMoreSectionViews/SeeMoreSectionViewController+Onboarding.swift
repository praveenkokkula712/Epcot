//
//  SeeMoreSectionViewController+Onboarding.swift
//  EpcotLobby
//
//  Created by Rajani Bhimanadham on 24/04/23.
//

import Foundation
import UIKit

extension SeeMoreSectionViewController {
    
    func addObservers() {
        if UIDevice.isIPad() {
            NotificationCenter.default.addObserver(self,
                                                   selector: #selector(didDeviceRotated),
                                                   name: UIDevice.orientationDidChangeNotification,
                                                   object: nil)
        }
    }
    
    @objc func didDeviceRotated() {
        UserOnboardingViewModel.shared?.setUpPopTipView(of: UserOnboardingViewModel.shared?.currentUserJourney ?? UserOnboardingJourney())
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            guard let self = self else { return }
            self.showOnboardingView()
        }
    }
    
    func showOnboardingView() {
        var button: UIView = self.gridButton
        if self.layoutType == .grid {
            ///list button
            button = self.listButton
        }
        UserOnboardingViewModel.shared?.show(with: button.globalFrameFromLobbyView,
                                             of: .lobbySwitcher, switcherType: self.layoutType.swappedValue)
    }
}
