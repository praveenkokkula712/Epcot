//
//  SeeMoreSectionCollectionViewController.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 24/08/22.
//

import UIKit
import CasinoAPI

class SeeMoreSectionCollectionViewController: ImmersiveLobbyCollectionViewController {
    
    private var games: [Game]?
    var isFromSwitcher: Bool = false
    private var isJackpotWidgetGames: Bool = false
    private var cleanOnDisappear: Bool = true
    var onJackpotUpdate: (() -> Void)?
    
    var layoutType: SwitcherCategoryType {
        EpcotLobbyManager.shared?.lobbySwitcherType ?? .grid
    }

    private var gridLayout = GridCollectionViewLayout()
    private var listLayout = ListCollectionViewLayout()

    convenience init( games: [Game],
                      datasource: LobbyFeedDataSource? = nil,
                      isJackpotWidgetGames: Bool = false,
                      cleanOnDisappear: Bool = true) {
        self.init(collectionViewLayout: UICollectionViewFlowLayout())
        self.datasource = datasource
        self.games = games
        self.isJackpotWidgetGames = isJackpotWidgetGames
        self.cleanOnDisappear = cleanOnDisappear
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if self.cleanOnDisappear {
            self.clean()
        }
    }
    
    override func setupCollectionView() {
        self.collectionView.isPrefetchingEnabled = true
        self.collectionView.prefetchDataSource = self
        self.collectionView.setupDefaultConfiguration()
        self.collectionView.registerNibCells(withCells: CellIdentifier.gameCell,
                              CellIdentifier.lobbyListCVCell,
                              bundle: kEpcotBundle)
        let layout = layoutType == .grid ? gridLayout : listLayout
        self.collectionView.collectionViewLayout = layout
        self.collectionView.contentInset = .zero
        self.collectionView.backgroundColor = (epcotCss?.type == .epcotLobby) ? epcotCss?.epcotLobbyCSS?.gameCollectionViewBGColor : EpcotLobbyManager.shared?.css.seeMoreSectionView?.collectionViewBGColor ??  UIColor.hexStringToUIColor(hex: "#191919")
    }
    
    override func configureDatasource() {
        guard self.collectionView != nil else { return }
        self.diffDatasource = ImmersiveDatasource(collectionView: self.collectionView, cellProvider: { collectionView, indexPath, itemIdentifier in
            self.cell(collectionView: collectionView, indexPath: indexPath, item: itemIdentifier)
        })
        self.applySnapshot(isFromSwitcher: false)
    }
    
    override func cell(collectionView: UICollectionView, indexPath: IndexPath, item: Item) -> UICollectionViewCell? {
        let layoutType = self.immersiveElements[indexPath.section].layoutType
        let iconSize = self.immersiveElements[indexPath.section].layoutType.rawValue
        guard case .game(let game, let _) = item else {
            return collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.gameCell, for: indexPath) as? EpcotGameCollectionViewCell
        }
        let sticker = game.sticker
        let localizedStickerName = self.datasource?.feedViewModel?.getCategoryName(for: sticker ?? "")
        if layoutType == .list {
            let listCell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.lobbyListCVCell, for: indexPath) as? GamesListViewCell
            if let gameVariant = game.game,
               let immersiveInfo = self.datasource?.feedViewModel?.getImmersiveInfo(for: gameVariant, with: "\(iconSize)") {
                let blurImagePath = self.datasource?.feedViewModel?.getListCellBlurImagePath(for: gameVariant)
                listCell?.configureCell(with: immersiveInfo,
                                        isJackpotGame: isJackpotWidgetGames,
                                        blurImagePath: blurImagePath,
                                        sticker: localizedStickerName)
                listCell?.favouritesDelegate = self
                listCell?.subscribeTo(subject: self.jackpotInfoSubject)
            }
            return listCell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.gameCell, for: indexPath) as? EpcotGameCollectionViewCell
            if let gameVariant = game.game,
               let immersiveInfo = self.datasource?.feedViewModel?.getImmersiveInfo(for: gameVariant, with: "\(iconSize)") {
                cell?.configureCell(with: immersiveInfo,
                                    isJackpotGame: self.isJackpotWidgetGames,
                                    sticker: localizedStickerName)
                cell?.favouritesDelegate = self
                cell?.subscribeTo(subject: self.jackpotInfoSubject)
            }
            return cell
        }
    }
    
    func reloadItems() {
        if self.isJackpotWidgetGames {
            self.onJackpotUpdate?()
        }
        guard let snapshot = self.snapShot else { return }
        self.diffDatasource?.applySnapshotUsingReloadData(self.snapShot ?? snapshot)
    }
    
    func applySnapshot(isFromSwitcher: Bool = false) {
        self.immersiveElements.removeAll()
        let layoutType: LayoutType = self.layoutType == .grid ? .verticalImmersiveGrid : .list
        let immersiveSection = ImmersiveLobbySection(games: self.games,
                                                     layoutType: layoutType)
        self.immersiveElements.append(immersiveSection)
        self.snapShot = ImmersiveSnapshot()
        self.immersiveElements.forEach { section in
            self.snapShot?.appendSections([section])
            if let games = section.games {
                self.snapShot?.appendItems(games.map({Item.game($0, UUID())}), toSection: section)
            }
        }
        if let snapshot = self.snapShot {
            self.isFromSwitcher = isFromSwitcher
            self.diffDatasource?.apply(snapshot, animatingDifferences: false, completion: {
                self.isFromSwitcher = false
                self.startJackpotTimer()
            })
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let item = diffDatasource?.itemIdentifier(for: indexPath),
              case .game(let game, let _) = item,
                let selectedGame = game.game else { return }
        if let cell = collectionView.cellForItem(at: indexPath) {
            cell.tapAnimation {
                var additionalParams = self.setAdditionalParameters(indexpath: indexPath)
                additionalParams.location = GameSection.seeMore.name
                self.onClickGameplay?(selectedGame, additionalParams)
            }
        }
    }
    
    override func createCompositionalLayout() -> UICollectionViewCompositionalLayout {
        let layout = UICollectionViewCompositionalLayout { (sectionIndex: Int,
                                                            layoutEnvironment: NSCollectionLayoutEnvironment) -> NSCollectionLayoutSection? in
            let width = layoutEnvironment.container.effectiveContentSize.width
            switch self.layoutType {
            case .list:
                return CustomLayoutSection.listGameCellLayoutSection(width: width, isPreBanner: false)
            case .grid:
                return CustomLayoutSection.verticalImmersiveSection(isHeaderAvailable: false)
            }
        }
        return layout
    }
    
    override func dismiss(animated flag: Bool, completion: (() -> Void)? = nil) {
        super.dismiss(animated: flag, completion: completion)
        self.stopJackpotTimer()
    }
    
    deinit {
        self.stopJackpotTimer()
        ETLogger.debug("Deinit \(type(of: self))")
    }
    
    override func didTappedOn(favourites cell: EpcotBaseCollectionViewCell, gameVariant: String, state: Bool) {
        let favouriteState: FavouriteState = state ? .selected : .unselected
        if let collectionCell = cell as? EpcotGameCollectionViewCell {
            collectionCell.isFavouriteGame = favouriteState
        } else if let listCell = cell as? GamesListViewCell {
            listCell.isFavouriteGame = favouriteState
        }
        self.delegate?.didTappedOnFavourites(gameVariant: gameVariant, state: state,from: true)
    }
}
