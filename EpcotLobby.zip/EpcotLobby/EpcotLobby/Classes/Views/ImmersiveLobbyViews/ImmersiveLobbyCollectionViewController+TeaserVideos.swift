//
//  ImmersiveLobbyCollectionViewController+TeaserVideos.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 24/01/24.
//

import Foundation

extension ImmersiveLobbyCollectionViewController {
 
    func reloadVideoTeaserOnGamePlayDismiss(isPresenting: Bool? = nil) {
        ///Video reload changes for Banner Video cell
        if let previousVideoCell {
            DispatchQueue.main.async {
                if let isPresentingView = isPresenting {
                    if let videoUrl = self.activeTeaserVideoUrl {
                        self.teaserVideoInfoSubject.send((self.teaserCurrentIndex, isPresentingView ? videoUrl : nil))
                        if isPresentingView {
                            self.startScrollTimerForVideoTeaser()
                        }
                    } else {
                        self.teaserVideoInfoSubject.send((self.teaserCurrentIndex, nil))
                    }
                }
            }
        }
        ///Video reload changes for netflix style teasers
        DispatchQueue.main.async {
            if UIDevice.isIPad() {
                if self.previousVideoCell == nil {
                    if let isPresentingView = isPresenting {
                        self.netflixVideoPlayStatusInfoSubject.send(!isPresentingView)
                    } else {
                        self.netflixVideoPlayStatusInfoSubject.send(true)
                    }
                }
            } else {
                if let isPresentingView = isPresenting {
                    self.netflixVideoPlayStatusInfoSubject.send(!isPresentingView)
                } else {
                    self.netflixVideoPlayStatusInfoSubject.send(false)
                }
            }
        }
    }
}


