//
//  ImmersiveLobbyCollectionViewController+Onboarding.swift
//  EpcotLobby
//
//  Created by Rajani Bhimanadham on 24/04/23.
//
import Foundation
import UIKit

extension ImmersiveLobbyCollectionViewController {
    var onboardingSeeMoreViewController: UIViewController? {
        self.seeMoreController
    }
    
    var isSeeAllViewAvailableForOnboarding: Bool {
        if let _ = self.immersiveElements.first(where: { $0.isHeaderAvailable && $0.isGamesPrefixed }) {
            return true
        }
        return false
    }
    
    var isJackpotFusionInfoAvailable: Bool {
        if let _ = self.immersiveElements.first(where: {$0.isHeaderDescriptionAvailable}) {
            return true
        }
        return false
    }
    
    private var onboardingSeeAllIndex: Int? {
        self.immersiveElements.firstIndex(where: { $0.isHeaderAvailable && $0.isGamesPrefixed })
    }
    
    private var onboardingJacpotFusionInfoIndex: Int? {
        self.immersiveElements.firstIndex(where: { $0.isHeaderDescriptionAvailable })
    }

    var onboardingSeeAllFrame: CGRect {
        if let index = self.onboardingSeeAllIndex {
            let indexPath = IndexPath(item: 0, section: index)
            if let seeAllHeaderView = self.collectionView.supplementaryView(forElementKind: UICollectionView.elementKindSectionHeader, at: indexPath) as? MoreItemsCollectionReusableView {
                return seeAllHeaderView.seeMoreButton.globalFrameFromLobbyView
            }
        }
        return .zero
    }
    
    var onboardingJackpotFusionInfoFramme: CGRect {
        if let index = self.onboardingJacpotFusionInfoIndex {
            let indexPath = IndexPath(item: 0, section: index)
            if let jackpotFusionInfoView = self.collectionView.supplementaryView(forElementKind: UICollectionView.elementKindSectionHeader, at: indexPath) as? MoreItemsCollectionReusableView {
                return jackpotFusionInfoView.infoButton.globalFrameFromLobbyView
            }
        }
        return .zero
    }
        
    func scrollToIndex(of type:ImmersiveOnboardingElementType = .seeAll, isScrollNeeded: Bool = true) -> (Bool, Int) {
        var isFrameVisible = false
        let index = type == .seeAll ? self.onboardingSeeAllIndex : self.onboardingJacpotFusionInfoIndex
        if let index {
            let indexPath = IndexPath(item: 0, section: index)
            let theAttributes = self.collectionView.layoutAttributesForItem(at: indexPath)
            if let superView = self.collectionView.superview,
               var cellFrame = theAttributes?.frame {
                let yPosition = (UIDevice.screenSize.height - (cellFrame.origin.y - self.collectionView.contentOffset.y))
                if yPosition < 250 {
                    /// Given padding 150 to display onboarding see all view
                    cellFrame.origin.y = cellFrame.origin.y + 150
                    let cellFrameInSuperview = self.collectionView.convert(cellFrame, from: superView)
                    if isScrollNeeded {
                        self.collectionView.scrollRectToVisible(cellFrameInSuperview, animated: true)
                    }
                } else {
                    isFrameVisible = true
                }
            }
            return (isFrameVisible, index)
        }
        return (isFrameVisible, 0)
    }
}

enum ImmersiveOnboardingElementType {
    case seeAll
    case jackpotFusionInfo
}
