//
//  GamesEssentialsViewModel.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 25/06/24.
//

import Foundation
import Combine

class GamesEssentialsViewModel: ObservableObject {
    
    // MARK: Properties
    let feedDatasource: LobbyFeedDataSource?
    private(set) var immersiveInfo: ((Game) -> ImmersiveGameInfo?)?
    private(set) var blurImagePath: ((Game) -> String?)?
    private(set) var onFavoriteGameTap: ((Game) -> Void)?
    private(set) var sticker: ((Game) -> String?)?
    private(set) var onGameTap: ((Game) -> Void)?
    private var subscriber: AnyCancellable?
    private var jackpotTimer: DispatchTimer?
    private var layout: LayoutType
    private var iconSize: Int
    private(set) var gameTilePublisher = GameTilePublisher()
    @Published private(set) var gameTiles = [GameTile]()

    // MARK: Init
    init(
        feedDatasource: LobbyFeedDataSource?,
        games: [Game],
        layout: LayoutType,
        iconSize: Int,
        onGameTap: ((Game) -> Void)?
    ) {
        self.feedDatasource = feedDatasource
        self.layout = layout
        self.iconSize = iconSize
        self.onGameTap = onGameTap
        self.cofigureBlurImagePath()
        self.configureImmersiveInfo()
        self.cofigureSticker()
        self.configureFavorite()
        self.subscribeToRefresh()
        self.configureGames(with: games)
        self.startJackpotTimer()
    }
    
    func configureGames(with games: [Game]) {
        self.gameTiles.removeAll()
        self.gameTiles = games.map { game in
            return GameTile(
                game: game,
                sticker: sticker?(game),
                blurImagePath: blurImagePath?(game),
                immersiveInfo: immersiveInfo?(game),
                publisher: gameTilePublisher,
                onTap: { [weak self] gameTile in
                    self?.onGameTap?(gameTile.game)
                },
                onFavoriteTap: { [weak self] gameTile in
                    self?.onFavoriteGameTap?(gameTile.game)
                }
            )
        }
    }

    // MARK: Subscriptions
    private func subscribeToRefresh() {
        self.subscriber = self.feedDatasource?.feedViewModel?.refreshLobby
            .subscribe(on: DispatchQueue.main)
            .sink { [weak self] shouldRefresh in
                guard let self else { return }
                if shouldRefresh {
                    self.stopJackpotTimer()
                    self.startJackpotTimer()
                } else {
                    //No need to call this method, if 'sholudRefresh' is true, because it atomatically updates the view
                    self.refreshJackporPrices()
                }
            }
    }
    
    // MARK: Helper
    var feedViewModel: FeedViewModel? {
        self.feedDatasource?.feedViewModel
    }
}

//MARK: -

extension GamesEssentialsViewModel {

    //MARK: Game Info

    private func cofigureBlurImagePath() {
        self.blurImagePath = { [weak self] game in
            guard let gameVariant = game.game, let self else { return nil }
            let path = self.feedViewModel?.getListCellBlurImagePath(for: gameVariant)
            return path
        }
    }
    
    private func cofigureSticker() {
        self.sticker = { [weak self] game in
            guard let gameVariant = game.sticker, let self else { return nil }
            let sticker = self.feedViewModel?.getCategoryName(for: gameVariant)
            return sticker
        }
    }
    
    private func configureImmersiveInfo() {
        self.immersiveInfo = { [weak self] game in
            guard let gameVariant = game.game, let self else { return nil }
            let info = self.feedViewModel?.getImmersiveInfo(
                for: gameVariant,
                with: "\(self.iconSize)"
            )
            return info
        }
    }

    // MARK: Favourite toggle

    private func configureFavorite() {
        self.onFavoriteGameTap = { [weak self] game in
            guard let gameVariant = game.game, let self else { return }
            //Fetch local game info
            let gameFav = self.immersiveInfo?(game)?.gameInfo.isFavouriteGame ?? false
            self.updateFavorite(selected: !gameFav, for: gameVariant)
        }
    }

    private func updateFavorite(selected: Bool, for game: String) {
        self.feedViewModel?.updateFavouriteStateInFeed(
            with: selected, for: game
        )
        //API
        Task {
            _ = try await self.feedViewModel?.updateFavouriteState(
                with: selected,
                for: game
            )
            let favoriteGames = self.feedDatasource?.feedViewModel?.favouriteGames?
                .reduce(into: [String: Bool]()) { partialResult, favGame in
                    if let name = favGame.game {
                        partialResult[name] = true
                    }
                }
            //updating favorites through subscriber after API is completed
            let favorites = GameTileReceiver(favorite: favoriteGames)
            self.gameTilePublisher.send(favorites)
        }
    }

    //MARK: Jackpot

    private func startJackpotTimer() {
        guard  self.jackpotTimer == nil else { return }
        let randomInterval = Double.random(in: 1...6)
        self.jackpotTimer =  DispatchTimer(interval: randomInterval, handler: self.refreshJackpot)
    }
    
    func stopJackpotTimer() {
        guard self.jackpotTimer != nil else { return }
        self.jackpotTimer?.cancel()
        self.jackpotTimer = nil
    }
    
    private func refreshJackpot() {
        self.stopJackpotTimer()
        ///counter jackpot time update
        self.gameTilePublisher.send(nil)
        self.startJackpotTimer()
    }
    
    private func refreshJackporPrices () {
        if let jpPrices = self.feedViewModel?.getAllJackpotAmounts() {
            let jackpots = GameTileReceiver(jackpot: jpPrices)
            gameTilePublisher.send(jackpots)
        }
    }
}
