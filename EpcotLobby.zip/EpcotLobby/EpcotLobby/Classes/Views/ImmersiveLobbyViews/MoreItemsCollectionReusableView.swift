//
//  MoreItemsCollectionReusableView.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 24/08/22.
//

import UIKit
import Utility
import TrackerClient

class MoreItemsCollectionReusableView: UICollectionReusableView {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var seeMoreButton: UIButton!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var infoButton: UIButton!
    @IBOutlet weak var seeMoreArrowButton: UIButton!
    @IBOutlet weak var buttonView: UIView!
    @IBOutlet weak var descriptionHeightConstraint: NSLayoutConstraint!
    var delegate: EpcotSectionHeaderDelegate?
    var subCategoryId : String?
    
    var layoutType: LayoutType? {
        didSet {
            if let layoutType {
                self.configureViewsForJackpotWidgets(with: layoutType)
            }
        }
    }
    
    var route: String? {
        didSet {
            guard let route else { return }
            let jackpotViewModel = JackpotWidgetsViewModel.shared
            let colorAttributes = jackpotViewModel.attributes[route] as? [String: Any]
            if let titleHexCode = colorAttributes?[kTitleDisplayColor] as? String,
                !titleHexCode.isEmpty,
                let titleColor = titleHexCode.hexColor {
                self.titleLabel.textColor = titleColor
                self.infoButton.tintColor = titleColor
            }
            if let descriptionHexCode = colorAttributes?[kDescriptionDisplayColor] as? String,
                !descriptionHexCode.isEmpty,
                let descriptionColor = descriptionHexCode.hexColor {
                self.descriptionLabel.textColor = descriptionColor
            }
        }
    }
    
    var css: LobbyCSS? {
        EpcotLobbyManager.shared?.css
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.addObservers()
        self.addAccessibilityIdentifiers()
    }
        
    private func configureViews(with titleCss: TextCSS?, seeMoreCss: TextCSS?, descriptionCss: TextCSS?, infoTintColor: UIColor?) {
        self.titleLabel.textColor = titleCss?.color
        self.titleLabel.font = titleCss?.font
        self.descriptionLabel.textColor = descriptionCss?.color
        self.descriptionLabel.font = descriptionCss?.font
        self.seeMoreButton.setTitleColor(seeMoreCss?.color, for: .normal)
        self.seeMoreButton.contentHorizontalAlignment = .right
        self.seeMoreButton.titleLabel?.font = seeMoreCss?.font
        self.seeMoreButton.tintColor = titleCss?.color ?? .white
        self.seeMoreButton.setTitle(Localize.seeAll, for: .normal)
        self.seeMoreArrowButton.setImage(UIImage(named: seeMoreSideArrow,
                                                 in: Bundle(for:type(of:self)), with:nil)?.withRenderingMode(.alwaysTemplate),
                                         for: .normal)
        self.seeMoreArrowButton.tintColor = seeMoreCss?.color ?? .white
        self.seeMoreArrowButton.isHidden = !(
            CasinoCSS.lobby?.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false)
        self.infoButton.setImage(UIImage(named: "infoIcon",
                                         in: Bundle(for:type(of:self)), with:nil)?.withRenderingMode(.alwaysTemplate), for: .normal)
        self.infoButton.tintColor = infoTintColor
    }
    
    private func configureViewsForJackpotWidgets(with layoutType: LayoutType) {
        var titleCss = self.css?.recentlyPlayedView?.title
        var seeMoreCss = self.css?.recentlyPlayedView?.seeMoreTitle
        var descriptionCss = self.css?.recentlyPlayedView?.descriptionTextColor
        var infoCss = self.css?.recentlyPlayedView?.infoButtonTintColor
        switch layoutType {
        case .jackpotMustGoWidget:
            titleCss = self.css?.jackpotWidgets?.mustGoJackpotHeaderCss?.title
            seeMoreCss = self.css?.jackpotWidgets?.mustGoJackpotHeaderCss?.seeMoreTitle
            descriptionCss = self.css?.jackpotWidgets?.mustGoJackpotHeaderCss?.descriptionTextColor
            infoCss = self.css?.jackpotWidgets?.mustGoJackpotHeaderCss?.infoButtonTintColor
        case .multipleJackpotWidget:
            titleCss = self.css?.jackpotWidgets?.multipleJackpotsHeaderCss?.title
            seeMoreCss = self.css?.jackpotWidgets?.multipleJackpotsHeaderCss?.seeMoreTitle
            descriptionCss = self.css?.jackpotWidgets?.multipleJackpotsHeaderCss?.descriptionTextColor
            infoCss = self.css?.jackpotWidgets?.multipleJackpotsHeaderCss?.infoButtonTintColor
        case .jackpotWidget:
            titleCss = self.css?.jackpotWidgets?.singleJackpotHeaderCss?.title
            seeMoreCss = self.css?.jackpotWidgets?.singleJackpotHeaderCss?.seeMoreTitle
            descriptionCss = self.css?.jackpotWidgets?.singleJackpotHeaderCss?.descriptionTextColor
            infoCss = self.css?.jackpotWidgets?.singleJackpotHeaderCss?.infoButtonTintColor
        default:
            titleCss = self.css?.recentlyPlayedView?.title
            seeMoreCss = self.css?.recentlyPlayedView?.seeMoreTitle
            descriptionCss = self.css?.recentlyPlayedView?.descriptionTextColor
            infoCss = self.css?.recentlyPlayedView?.infoButtonTintColor
        }
        self.configureViews(with: titleCss,
                            seeMoreCss: seeMoreCss, descriptionCss: descriptionCss, infoTintColor: infoCss)
    }
    
    
    private func addObservers() {
        Feed.addObserver(observer: self,
                         selector: #selector(self.didUpdateSitecoreModels),
                         notification: .didUpdateSitecoreModels)
        
        Feed.addObserver(observer: self,
                         selector: #selector(self.didUpdateSitecoreModels),
                         notification: .didUpdateLocalizedStrings)
    }
    
    @objc private func didUpdateSitecoreModels() {
        DispatchQueue.main.async {
            let title = Localize.seeAll.isEmpty ? "See All" : Localize.seeAll
            self.seeMoreButton.setTitle(title, for: .normal)
        }
    }
    
    @IBAction func seeMoreButtonAction(_ sender: UIButton) {
        let instantInteraction = InteractionType.opacity.interaction
        buttonView.tapAnimation(type: instantInteraction) {
            UserDefaults.userOnboardingSeeAll = true
            self.delegate?.didTapOnHeaderElement(of: .seeMore(self.subCategoryId))
        }
    }
    
    @IBAction func infoAction(_ sender: UIButton) {
        let instantInteraction = InteractionType.opacity.interaction
        infoButton.tapAnimation(type: instantInteraction) {
            UserDefaults.userOnboardingJackpotFusionInfo = true
            self.delegate?.didTapOnHeaderElement(of: .info(self.subCategoryId, self.route))
            self.trackEvent()
        }
    }
    
    deinit {
        Feed.removeObserver(observer: self,
                            notification: .didUpdateSitecoreModels)
    }
}

protocol EpcotSectionHeaderDelegate: AnyObject {
    func didTapOnHeaderElement(of type: SectionHeaderElementType)
}

enum SectionHeaderElementType {
    case seeMore(String?)
    case info(String?, String?)
}

//MARK: Adding Accessibility Identifiers
extension MoreItemsCollectionReusableView {
    private func addAccessibilityIdentifiers() {
        titleLabel.accessibilityIdentifier = AccessibilityIdentifiers.seemoreCollection_titleLabel.rawValue
        seeMoreButton.accessibilityIdentifier = AccessibilityIdentifiers.seemoreCollection_seeMoreButton.rawValue
        seeMoreArrowButton.accessibilityIdentifier = AccessibilityIdentifiers.seemoreCollection_seeMoreArrowButton.rawValue
        buttonView.accessibilityIdentifier = AccessibilityIdentifiers.seemoreCollection_buttonView.rawValue
        descriptionLabel.accessibilityIdentifier = AccessibilityIdentifiers.seemoreCollection_descriptionLabel.rawValue
        infoButton.accessibilityIdentifier = AccessibilityIdentifiers.seemoreCollection_infoButton.rawValue
    }
    private func trackEvent() {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.global_jackpots.rawValue,
                                     actionEvent:EpcotEventAction.click.rawValue,
                                     labelEvent: EpcotEventLabel.reveal_card.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: EpcotEventDetails.info_icon_click.rawValue,
                                     positionEvent: "")
            let event = TrackerEvent(type: .jackpots, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}
