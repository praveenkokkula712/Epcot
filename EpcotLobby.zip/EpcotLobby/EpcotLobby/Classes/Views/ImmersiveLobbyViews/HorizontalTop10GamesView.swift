//
//  HorizontalTop10GamesView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 25/06/24.
//

import SwiftUI
import Utility
import SDWebImageSwiftUI
import SDWebImageSVGKitPlugin

struct HorizontalTop10GamesView: View {

    // MARK: Properties
    let layout: LayoutType
    let games: [GameTile]
    let onGameTap: ((Game) -> Void)?

    init(layout: LayoutType, games: [GameTile], onGameTap: ((Game) -> Void)?) {
        self.layout = layout
        self.games = games
        self.onGameTap = onGameTap
        SDImageCodersManager.shared.addCoder(SDImageSVGKCoder.shared)
    }

    // MARK: Body
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHGrid(rows: layout.rows) {
                ForEach(Array(games.enumerated()), id: \.element) { index, game in
                    // TODO: NAT-101630 Write a logic give the ranking for top games.
                    let width = getGameTileWidth(index: index)
                    Top10GameTileView(
                        game: game,
                        index: index,
                        rankWidth: width,
                        tileSize: CGSize(
                            width: layout.tileSize.width,
                            height: layout.tileSize.height
                        ),
                        onGameTap: onGameTap
                    )
                    .frame(width: layout.tileSize.width + width)
                }
            }
            .padding(.trailing, getGameTileWidth(index: games.count))
        }
    }

    private func getGameTileWidth(index: Int) -> Double {
        // TODO: NAT-101630 Add this to Top 10 games's configuration
        index < 10 ? layout.rankWidth : layout.tengthRankWidth
    }
}

fileprivate extension LayoutType {
    
    var rows: [GridItem] {
        switch self {
        case .topGamesHorizontalGrid, 
                .topGamesPortraitGrid,
                .topGamesImmersiveGrid:
            return .init(
                repeating: GridItem(
                    .flexible(
                        minimum: tileSize.width + rankWidth,
                        maximum: tileSize.width + tengthRankWidth
                    )
                ),
                count: 1
            )
        default:
            return .init()
        }
    }

    var tileSize: CGSize {
        var widthFactor = 1.0
        var heightFactor = 1.0

        switch self {
        case .topGamesHorizontalGrid:
            widthFactor = isIPad ? 0.23 : 0.44
            heightFactor = isIPad ? 0.23 : 0.44
        case .topGamesPortraitGrid:
            widthFactor = isIPad ? 0.23 : 0.3
        case .topGamesImmersiveGrid:
            widthFactor = isIPad ? 0.15 : 0.3
            heightFactor = isIPad ? 0.15 : 0.3
        default: break
        }

        let width = UIDevice.screenSize.width * widthFactor
        let height = self == .topGamesPortraitGrid ? 200.0 : UIDevice.screenSize.width * heightFactor
        return CGSize(width: width, height: height)
    }

    var rankWidth: CGFloat {
        let styles = Top10GamesViewCSS()
        return styles.rankWidth
    }

    var tengthRankWidth: CGFloat {
        let styles = Top10GamesViewCSS()
        return styles.tengthRankWidth
    }

    private var isIPad: Bool {
        UIDevice.isIPad()
    }
}
