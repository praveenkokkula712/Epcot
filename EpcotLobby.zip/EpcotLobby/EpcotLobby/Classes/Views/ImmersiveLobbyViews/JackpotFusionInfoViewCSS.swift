//
//  CSS.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 28/12/23.
//


import SwiftUI

struct JackpotFusionInfoViewCSSModel {
    var backgroundColor: Color
    var contentBackgroundColor: Color
    var headerBackgroundColor: Color
    var headerTitleColor: Color
    var headerTitleFont: Font
    var closeButtonTitleColor: Color
    var closeButtonTitleFont: Font
    var closeButtonBackgroundColor: Color
    var closeButtonBorderColor: Color
    var closeButtonBorderWidth: Double
    var closeButtonCornerRadius: Double
    var seeallButtonTitleColor: Color
    var seeallButtonTitleFont: Font
    var seeallButtonBackgroundColor: Color
    var seeallButtonBorderWidth: Double
    var seeallButtonCornerRadius: Double
    var badgeTitleColor: Color
    var badgeTitleFont: Font
    var badgeBackgroundColor: Color
    var badgeButtonCornerRadius: Double
    var contentViewCornerRadius: Double
    var jackpotFusionInfoViewContentFontSize: Double
    var jackpotFusionInfoViewContentFontName: String
    var jackpotFusionInfoViewContentFontFileName: String
    
    var contentModel: JackpotInfoViewContentModel {
        JackpotInfoViewContentModel(fontFileName: self.jackpotFusionInfoViewContentFontFileName,
                                    fontSize: Int(self.jackpotFusionInfoViewContentFontSize),
                                    fontName: self.jackpotFusionInfoViewContentFontName)
    }
    
    init(css: JackpotFusionInfoViewCSS? = nil) {
        
         backgroundColor = Color(css?.jackpotFusionInfoViewBackgroundColor ?? .black.withAlphaComponent(0.4))
         contentBackgroundColor = Color(css?.jackpotFusionInfoViewContentBackgroundColor ?? .white)
         headerBackgroundColor = Color(css?.jackpotFusionInfoViewHeaderBackgroundColor ?? UIColor(hex: "#f3f4f5"))
         headerTitleColor = Color(css?.jackpotFusionInfoViewHeaderTitle?.color ?? .black)
         headerTitleFont = Font(css?.jackpotFusionInfoViewHeaderTitle?.font ?? .boldSystemFont(ofSize: 17))
         closeButtonTitleColor = Color(css?.jackpotFusionInfoViewCloseButtonCSS?.title?.color ?? .black)
         closeButtonTitleFont = Font(css?.jackpotFusionInfoViewCloseButtonCSS?.title?.font ?? .systemFont(ofSize: 13))
         closeButtonBackgroundColor = Color(css?.jackpotFusionInfoViewCloseButtonCSS?.normal ?? .clear)
         closeButtonBorderColor = Color(css?.jackpotFusionInfoViewCloseButtonBorderColor ?? .lightGray)
         closeButtonBorderWidth = css?.jackpotFusionInfoViewCloseButtonBorderWidth ?? 1.0
         closeButtonCornerRadius = css?.jackpotFusionInfoViewCloseButtonCornerRadius ?? 16.0
         seeallButtonTitleColor = Color(css?.jackpotFusionInfoViewSeeallButtonCSS?.title?.color ?? .black)
         seeallButtonTitleFont = Font(css?.jackpotFusionInfoViewSeeallButtonCSS?.title?.font ?? .systemFont(ofSize: 13))
         seeallButtonBackgroundColor = Color(css?.jackpotFusionInfoViewSeeallButtonCSS?.normal ?? UIColor(hex:"#D4B962").withAlphaComponent(0.83))
         seeallButtonBorderWidth = css?.jackpotFusionInfoViewSeeallButtonBorderWidth ?? 0
         seeallButtonCornerRadius = css?.jackpotFusionInfoViewSeeallButtonCornerRadius ?? 16.0
         badgeTitleColor = Color(css?.jackpotFusionInfoViewBadgeTitle?.color ?? .black)
         badgeTitleFont = Font(css?.jackpotFusionInfoViewBadgeTitle?.font ?? .systemFont(ofSize: 13))
        badgeBackgroundColor = Color(css?.jackpotFusionInfoViewBadgeBackgroundColor ?? UIColor.hexStringToUIColor(hex: "#D6BC68").withAlphaComponent(0.3))
        badgeButtonCornerRadius = css?.jackpotFusionInfoViewBadgeButtonCornerRadius ?? 4.0
        contentViewCornerRadius = css?.jackpotFusionInfoViewContentViewCornerRadius ?? 6.0
        jackpotFusionInfoViewContentFontSize = css?.jackpotFusionInfoViewContentFontSize ?? 13.0
        jackpotFusionInfoViewContentFontName = css?.jackpotFusionInfoViewContentFontName ?? "poppinMedium"
        jackpotFusionInfoViewContentFontFileName = css?.jackpotFusionInfoViewContentFontFileName ?? "SecondaryLightFont.ttf"
    }
}
