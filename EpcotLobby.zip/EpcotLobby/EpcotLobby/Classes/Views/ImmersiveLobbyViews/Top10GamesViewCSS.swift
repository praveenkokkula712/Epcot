//
//  Top10GamesViewCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 30/06/24.
//

import SwiftUI
import Utility

struct Top10GamesViewCSS {

    // MARK: Properties
    let rankFont: Font
    let rankOpacity: Double
    let rankHeight: Double
    let rankGradientTopColor: Color
    let rankGradientBottomColor: Color
    let rankWidth: Double
    let tengthRankWidth: Double

    // MARK: Init
    init(top10GamesCSS: Top10GamesCSS? = nil) {
        let css = top10GamesCSS ?? Self.lobbyCSS?.top10GamesCSS
        self.rankFont = Font(css?.rankFont ?? Self.rankFont)
        self.rankOpacity = css?.rankOpacity ?? Self.rankOpacity
        self.rankHeight = css?.rankHeight ?? Self.rankHeight
        self.rankGradientTopColor = Color(css?.rankGradientTopColor ?? Self.rankGradientTopColor)
        self.rankGradientBottomColor = Color(css?.rankGradientBottomColor ?? Self.rankGradientBottomColor)
        self.rankWidth = css?.rankWidth ?? Self.rankWidth
        self.tengthRankWidth = css?.tengthRankWidth ?? Self.tengthRankWidth
    }
}

// MARK: - Helper
extension Top10GamesViewCSS: LobbyStylable { }

extension Top10GamesViewCSS {
    static var rankFont: UIFont {
        UIFont(name: "Kanit-SemiBold", size: 82.0)!
    }
    static var rankOpacity: Double { 0.6 }
    static var rankHeight: Double { 52.0 }
    static var rankWidth: Double { 22.0 }
    static var tengthRankWidth: Double { 36.0 }
    static var rankGradientTopColor: UIColor {
        UIColor.convertFrom(hex: "#FFFFFF")
    }
    static var rankGradientBottomColor: UIColor {
        UIColor.convertFrom(hex: "#414141")
    }
}
