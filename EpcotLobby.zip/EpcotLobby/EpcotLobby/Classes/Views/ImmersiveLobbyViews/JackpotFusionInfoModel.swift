//
//  JackpotInfoModel.swift
//  EpcotLobby
//
//  Created by Rajani Bhimanadham on 27/12/23.
//

import Foundation

struct JackpotFusionInfoModel {
    var title, content : String
    var badge: String?
    var isSeeAllAvailable : Bool
}
