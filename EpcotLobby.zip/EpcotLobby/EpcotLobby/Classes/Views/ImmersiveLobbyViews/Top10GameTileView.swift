//
//  Top10GameTileView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 27/06/24.
//

import SwiftUI
import Utility

struct Top10GameTileView<GameTileConfig>: View
where GameTileConfig: GameTileConfigurable {

    // MARK: Properties
    let game: GameTileConfig
    let index: Int
    let rankWidth: CGFloat
    let tileSize: CGSize
    let onGameTap: ((Game) -> Void)?
    @ObservedObject private var viewModel: GameTileViewModel
    private let styles = Top10GamesViewCSS()

    // MARK: Init
    init(game: GameTileConfig, index: Int, rankWidth: CGFloat, tileSize: CGSize, onGameTap: ((Game) -> Void)?) {
        self.game = game
        self.index = index
        self.rankWidth = rankWidth
        self.tileSize = tileSize
        self.onGameTap = onGameTap
        self.viewModel = GameTileViewModel(self.game, isFromSearch: false)
    }

    // MARK: Body
    var body: some View {
        EntainAnimatedButton(type: .opacity) {
            self.onGameTap?(game.game)
        } label: {
            ZStack(alignment: .bottomLeading) {
                Text("\(index + 1)")
                    .kerning(-5.0)
                    .font(styles.rankFont)
                    .foregroundLinearGradient(
                        colors: [
                            styles.rankGradientTopColor,
                            styles.rankGradientBottomColor
                        ],
                        startPoint: .init(x: 1.0, y: 0.2),
                        endPoint: .init(x: 1.0, y: 0.7)
                    )
                    .opacity(styles.rankOpacity)
                    .frame(height: styles.rankHeight)
                    .offset(x: -5.0, y: -12.0)

                GameTileView(game: game, size: tileSize)
                    .offset(x: rankWidth)
                    .disabled(true)
            }
        }
    }
}
