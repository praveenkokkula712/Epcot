//
//  ImmersiveLobbyCollectionViewController.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 05/08/22.
//

import UIKit
import Utility
import CasinoAPI
import Combine
import TrackerClient
import Kingfisher
import AVFoundation
import SwiftUI
import ConfigModule
import SDWebImageSVGKitPlugin

protocol ImmersiveLobbyCollectionControllerDelegate: AnyObject {
    func didTappedOnFavourites(gameVariant: String, state: Bool, from seeMoreSection: Bool)
    func didUpdateFavourite(gameVariant: String, state: FavouriteState,from seeMoreSection: Bool)
    func didOriginalWidgetExpired() -> Bool
}

extension ImmersiveLobbyCollectionControllerDelegate {
    func didUpdateFavourite(gameVariant: String, state: FavouriteState, from seeMoreSection: Bool) {
        
    }
    func didOriginalWidgetExpired() -> Bool {
        return true
    }
}

class ImmersiveLobbyCollectionViewController: UICollectionViewController {
    
    weak var delegate: ImmersiveLobbyCollectionControllerDelegate?
    // Variable declaration
    var diffDatasource: ImmersiveDatasource?
    var snapShot: ImmersiveSnapshot?
    var onClickGameplay: GamePlayHandler?
    var onClickLinkedCategory: ((_ linkedCategory: String) -> Void)?
    var onClickSubCategorySeeMore: ((_ categoryId: String,_ subcategoryId: String) -> Void)?
    var onClickFreeSpinsWidget: ((FreeSpin, [String]) -> Void)? // freeSpin, gameNames
    var isCategorySelected: Bool = false
    var selectedCategory: String?
    var onClickJackpotTile:((_ model: JackPotModel) -> Void)?
    var showJackpotTileDetails: (show: Bool, model: JackPotModel?) = (false, nil)
    var immersiveElements = [ImmersiveLobbySection]()
    private var immersiveFooterElements = [ImmersiveLobbySection]()
    var previousVideoCell: EpcotBannerVideoCell?
    var onClickSeeDeailsBtn: (() -> Void)?
    var teaserCurrentIndex = 0 {
        didSet {
            self.updateTeaserVideoCellWithCarouselTimer()
        }
    }
    private(set) weak var seeMoreController: SeeMoreSectionViewController?
    private var previousOffset: CGFloat = 0.0
    private var scollEventNumber = 0
    private var stateSwitcherModel: FooterStateSwitcherModel?
    var isOriginalsWidgetExpired = true {
        didSet {
            self.applySnapshot(with: self.selectedCategory, for: true)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
                if self.isOriginalsWidgetExpired {
                    self.originalsWidgetViewModel?.dispose()
                    self.originalsWidgetViewModel = nil
                }
            })
        }
    }
    
    private var bingoLobbyModel: BingoLobbyModel?
    private var footerTimer: DispatchTimer?
    private var jackpotTimer: DispatchTimer?
    private var jackpotScrollTimer: DispatchTimer?
    private var prominentFreeSpins: ProminentFreeSpins?
    private var freeSpinsDetails: ProminentFreeSpinDetails?
    private(set) var originalsWidgetViewModel: OriginalsWidgetViewModel?
    private var promoEngagementTools: [EngagementTool.ToolType: [PromoEngagementTool]] = [:]

    // weak variable declaration
    weak var datasource: LobbyFeedDataSource?
    
    // Private variable declaration
    private let pagingInfoSubject = PassthroughSubject<IndexPath, Never>()
    ///send [gameVariantName: jackpot price] or [jackpotId: jackpot price] or nil
    let jackpotInfoSubject = PassthroughSubject<[String: String]?, Never>()
    
    let liveFeedInfoSubject = PassthroughSubject<[String: LiveCasinoFeed]?, Never>()

    private let loggedInInfoSubject = PassthroughSubject<Date?, Never>()
    private let currentDateInfoSubject = PassthroughSubject<Void, Never>()
    let stateSwitcherInfoSubject = PassthroughSubject<Bool, Never>()
    let teaserVideoInfoSubject = PassthroughSubject<(Int,URL?), Never>()
    private var videoDurations = [String: Double]()
    let netflixVideoPlayStatusInfoSubject = PassthroughSubject<Bool, Never>()
    private var prefetcher: ImagePrefetcher?
    private var anycancellables = Set<AnyCancellable>()
    var activeTeaserVideoUrl: URL? {
        get {
            guard teaserCurrentIndex >= 0,
               self.teasersContentModel.count > teaserCurrentIndex,
               let activeTeaser = self.teasersContentModel[teaserCurrentIndex] as? TeaserContentModel,
               let videoUrlStr = activeTeaser.attributes?.teaserVideoUrl else {
                return nil
            }
            return videoUrlStr.url
        }
    }
    
    var jackpotFusionInfoView : UIHostingController<JackpotFusionInfoView>?
    
    // Private get-only property declaration.
    var epcotCss: LobbyCSS? {
        EpcotLobbyManager.shared?.css
    }
    
    private var odrAws:AppConfigurationODRAWS? {
        return DynaconAPIConfiguration.shared?.posAppConfig?.odrAws
    }
    
    private var headerType: LobbyHeaderType? {
        EpcotLobbyManager.shared?.css.lobbyheaderViewType
    }
    
    private var teaserDynaconConfig: TeaserDynaconConfig? {
        EpcotLobbyManager.shared?.datasource?.teasersDynaconConfig
    }
    
    private var bannerDynaconConfig: EmbeddBannerDynaconConfig? {
        EpcotLobbyManager.shared?.datasource?.embeddBannerConfig
    }
    
    private var gameTileItemsConfig: GameTileItemsConfiguration? {
        EpcotLobbyManager.shared?.datasource?.gameTileItemsConfiguration
    }

    private var bannerPosition: Int {
        let bannerPosition = self.bannerContentModel?.attributes?.positionInLobby?.toInt ?? self.bannerDynaconConfig?.position
        if var position = bannerPosition {
            if !ImmersiveInstance.shared.isEnabled, !position.isMultiple(of: 4) {
                position = position <= 4 ? 4  : (position / 4) * 4
            }
            return position
        }
        return 12
    }
    
    private var jackpotWidgets: [String: NativeWidgetsModel] {
        JackpotWidgetsViewModel.shared.routeWidgets
    }
    var jackpotTiles: [String: NativeWidgetsModel] {
        JackpotTileOrderViewModel.shared.routeWidgets
    }
    private var updatedJackpotTiles : [JackpotTile]? {
        JackpotTileOrderViewModel.shared.jackpotTiles
    }
    private var videoWidgets: [String: NativeWidgetsModel] {
        JackpotWidgetsViewModel.shared.videoRouteWidgets
    }
    
    private var jackpotFusion: [String: NativeWidgetsModel] {
        JackpotWidgetsViewModel.shared.jackpotFusionWidgets
    }
    
    private var freeSpinsWidgets: [String: NativeWidgetsModel] {
        JackpotWidgetsViewModel.shared.freeSpinsWidgets
    }
    
    private var engagementToolsWidgets: [String: NativeWidgetsModel] {
        JackpotWidgetsViewModel.shared.engagementToolsWidgets
    }
    
    private var playerStatsWidgets: [String: NativeWidgetsModel] {
        JackpotWidgetsViewModel.shared.playerStatWidgets
    }
    
    private var playerStatsWidgetViewModel: PlayerStatsWidgetViewModel? {
        if EntainContext.user?.isLoggedIn() ?? false {
            return PlayerStatsWidgetViewModel.shared
        }
        return nil
    }
    
    private var originalsWidget: [String: NativeWidgetsModel] {
        JackpotWidgetsViewModel.shared.originalsWidget
    }
    
    private var horizontalScrollLimt: Int {
        EpcotLobbyManager.shared?.datasource?.didRequestForHorizontalScrollLimit ?? 12
    }
    
    private var isFavGamesSectionShown: Bool {
        EpcotLobbyManager.shared?.datasource?.layoutOrder?.contains(where: {$0 == .favouriteGames}) ?? false
    }
    
    private var isEpcotEnabled: Bool {
        return CasinoCSS.lobby?.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false
    }
    
    /// checks if the page controller footer is visible or not, based on the below conditions.
    /// if the footer is in the visible area or not.
    /// if snapshot contains this layout or not
    private var isPageControllerFooterVisible: (isVisible: Bool,teasers: Int ) {
        guard self.collectionView.indexPathsForVisibleItems.contains(where: {$0.section == EpcotLobbySectionType.teasers.rawValue}) else {
            return (false,0)
        }
        
        guard let _ = self.collectionView.indexPathsForVisibleSupplementaryElements(ofKind: UICollectionView.elementKindSectionFooter).first(where: {$0.section == EpcotLobbySectionType.teasers.rawValue}) else{
            return (false,0)
        }
        guard let teaserSection = self.snapShot?.sectionIdentifiers.first(where: {$0.layoutType == .teasers}),
              let numberOfTeasers = self.snapShot?.numberOfItems(inSection: teaserSection) else {
            return (false,0)
        }
        return (true,numberOfTeasers)
    }
    
    // private properties with didSet propery observers.
    var teasersContentModel = [TeaserContentModel]() {
        didSet {
            guard !(teasersContentModel.isEmpty) else { return }
            DispatchQueue.main.async {[weak self] in
                guard let self = self else { return }
                if self.globalTeaser?.attributes?.enablePagination?.bool ?? true {
                    self.setupCarouselTimer()
                }
            }
        }
    }
    
    private var globalTeaser: TeaserContentModel?
    
    private var bannerContentModel: TeaserContentModel?
    
    private var multipleJackpotsCurrentIndexPath: IndexPath = IndexPath(item: 0, section: 0) {
        didSet {
            guard multipleJackpotsCurrentIndexPath != oldValue else { return }
            self.updateGamesForMultipleJackpotWidget(with: multipleJackpotsCurrentIndexPath)
        }
    }
        
    /// View didLoad view life cycle method.
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupCollectionView()
        self.addObservers()
        self.configureDatasource()
    }
    
    //MARK: - Clean method implemenation for removal observers and instances.
    /// Clean protocol implementation
    func clean() {
        ETLogger.debug("cleaning \(self)")
        self.stopJackpotTimer()
        self.stopJackpotWidgetScrollTimer()
        self.stopFooterTimer()
        self.stopCarouselTimer()
        NotificationCenter.default.removeObserver(self)
        self.onClickGameplay = nil
        self.onClickLinkedCategory = nil
        self.onClickSubCategorySeeMore = nil
        self.onClickFreeSpinsWidget = nil
        self.onClickJackpotTile = nil
        self.diffDatasource = nil
        self.snapShot = nil
        self.datasource = nil
        self.delegate = nil
        self.immersiveElements.removeAll()
        self.immersiveFooterElements.removeAll()
        self.originalsWidgetViewModel = nil
        PlayerStatsWidgetViewModel.disposeShared()
        guard self.collectionView != nil else { return }
        self.collectionView.removeFromSuperview()
        self.collectionView.collectionViewLayout.invalidateLayout()
        self.collectionView = nil
    }
    
    //MARK: - Initialisation methods.
    /// Convenience init declaration
    required convenience init?(coder: NSCoder) {
        self.init(coder: coder)
    }
    
    /// Convenience delcaration for collection view initialization.
    /// - Parameters:
    ///   - delegate: EpcotLobbyCollectionViewDelegate
    ///   - datasource: EpcotLobbyFeedDataSource
    convenience init(datasource: LobbyFeedDataSource? = nil) {
        self.init(collectionViewLayout: UICollectionViewFlowLayout())
        self.datasource = datasource
    }
    
    //MARK: - Collection View setup and data update methods.
    /// Setup collection View will update the collection view layout info and sets the required delegate and data source information.
    func setupCollectionView() {
        self.collectionView.isPrefetchingEnabled = true
        self.collectionView.prefetchDataSource = self
        self.collectionView.setupEpcotCollectionView()
        self.collectionView.collectionViewLayout = self.createCompositionalLayout()
        self.collectionView.backgroundColor = (epcotCss?.type == .epcotLobby) ? epcotCss?.epcotLobbyCSS?.gameCollectionViewBGColor : epcotCss?.gridView?.myGames?.containerViewColor
        self.collectionView.contentInset = UIEdgeInsets(top: 6.0, left: 0, bottom: 0, right: 0)
        // Configure SDWebImage to use the SVGKit plugin
              let svgCoder = SDImageSVGKCoder.shared
              SDImageCodersManager.shared.addCoder(svgCoder)
    }
    
    /// Reload method will invalidate the layout of the collection view and apply the snapshot for first category.
    func reload() {
        guard self.collectionView != nil else { return }
        ///remove state switcher view when user interacted with search view
        self.collectionView.collectionViewLayout.invalidateLayout()
        let response = SiteCoreTeasersViewModel().fetchLocalCache()
        if let teasers = response.teasers {
            self.teasersContentModel = teasers
        }
        if let banners = response.banner {
            self.bannerContentModel = banners
        }
        self.applySnapshot()
        self.fetchTeasers()
        self.startFooterTimer()
        self.getBingoLobbyData()
        if let user = EntainContext.user, user.isLoggedIn() {
            self.fetchProminentFreeSpins()
            self.fetchPromoEngagementTools()
        }
    }
    
    /// Reload item will reload the items/games in the collection view
    /// - Parameter gameVariant: game variant, which will reload the particular game if any.
    func reloadItem(_ gameVariant: String? = nil, isFavouriteUpdate: Bool = false) {
        ETLogger.debug("jackpot updated.")
        guard let _ = self.feedViewModel else {return}
        guard var snapShot = self.diffDatasource?.snapshot() else { return }
        if isFavouriteUpdate {
            self.applySnapshot(with: self.selectedCategory,for: true)
            return
        }
        
        if let gameVariant = gameVariant {
            let sections = snapShot.sectionIdentifiers.filter({$0.games?.first(where: {$0.game == gameVariant}) != nil})
            sections.forEach { section in
                let items = snapShot.itemIdentifiers(inSection: section)
                items.forEach { item in
                    if case let .game(gameObject, _) = item, gameObject.game == gameVariant {
                        snapShot.reloadItems([item])
                    }
                    if case let .rpGames(jackpotWidgetGameModel) = item, jackpotWidgetGameModel.game.game == gameVariant {
                        snapShot.reloadItems([item])
                    }
                }
            }
            self.diffDatasource?.apply(snapShot, animatingDifferences: false)
            return
        }
        guard !self.checkForJackpotWidgetSections() else {
            return
        }
        
        if let jpPrices = self.feedViewModel?.getAllJackpotAmounts() {
            self.stopJackpotTimer()
            self.stopJackpotWidgetScrollTimer()
            self.jackpotInfoSubject.send(jpPrices)
            ///to update must go jackpots we need to pass the info by creating a KV pair like [String: [SubJackpotDetails]]?
            ///instead of doing huge operations to filter the must go sections with jackpotGroupIds we can reload snapshot
            let mustGoWidgets = self.immersiveElements.filter({ $0.layoutType == .jackpotMustGoWidget })
            if !mustGoWidgets.isEmpty,
                snapShot.sectionIdentifiers.contains(where: {$0.layoutType == .jackpotMustGoWidget}) {
                snapShot.reloadSections(mustGoWidgets)
                self.diffDatasource?.apply(snapShot)
            }
            self.startJackpotTimer()
            self.startJackpotScrollTimer()
        } else {
            self.didUpdateTilesForJackpotAmount()
        }
    }
     
    /// Method will reload the games for recently played.
    func reloadRecentlyPlayedGamesSection() {
        self.applySnapshot(with: self.selectedCategory, for: true)
        ETLogger.debug("Jackpot updated Recently")
    }
    
    //MARK: - Notification Observers and implementations.
    /// Method will set the observers to the collection View.
    private func addObservers() {
        guard !self.isKind(of: EpcotSearchResultViewController.self) else { return }
        
        NotificationCenter.default.addObserver(self,
                                    selector: #selector(applicationDidEnterBackgroundNotification),
                                    name: UIApplication.didEnterBackgroundNotification,
                                    object: nil)
        NotificationCenter.default.addObserver(self,
                                    selector: #selector(applicationDidEnterForegroundNotification),
                                    name: UIApplication.willEnterForegroundNotification,
                                    object: nil)
        NotificationCenter.default.addObserver(self,
                                           selector: #selector(handleAudioInterruption),
                                           name: AVAudioSession.interruptionNotification,
                                           object: nil)
        JackpotTileOrderViewModel.shared.onJackpotTilesUpdated = { [weak self] isUpdated in
            guard isUpdated else { return }
            if self?.immersiveElements.first(where: {$0.layoutType == .jackpotTiles})?.jackpotTiles == nil && self?.isCategorySelected == false {
                self?.applySnapshot(for: true)
            }
        }
    }
    
    @objc func applicationDidEnterBackgroundNotification() {
        self.reloadVideoTeaserOnGamePlayDismiss()
    }

    @objc func applicationDidEnterForegroundNotification() {
        self.reloadVideoTeaserOnGamePlayDismiss()
        EpcotLobbyManager.shared?.setupAudioSessionForBackgroundAudio()
    }
    
    @objc func handleAudioInterruption(notification: Notification) {
        guard UIApplication.shared.applicationState == .active else { return }
        guard let userInfo = notification.userInfo,
              let typeValue = userInfo[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: typeValue) else {
            return
        }
        if type == .began {
            self.reloadVideoTeaserOnGamePlayDismiss(isPresenting: false)
        }
    }
        
    /// Method will setup the carousel timer for page controller footer, based on the teaser dynacon configuration.
    private func setupCarouselTimer() {
        guard !self.isKind(of: EpcotSearchResultViewController.self) else { return }
        guard let teasersConfig = self.teaserDynaconConfig,
              teasersConfig.isTeaserEnabled, teasersConfig.isPageControlAutoScrolEnabled else { return }
        guard !self.teasersContentModel.isEmpty else { return }
        if UIDevice.isIPad() {
            guard self.isIpadAutoScrollEnabled else { return }
        }
        
        self.teasersContentModel.enumerated().forEach { index,teaser in
            let duration = teasersConfig.durationforAutoScroll
            if let url = teaser.attributes?.teaserVideoUrl {
                self.videoDurations[url] = duration
            } else {
                self.videoDurations["\(index)"] = duration
            }
        }
        self.startScrollTimerForVideoTeaser()
    }
    
    var isIpadAutoScrollEnabled: Bool {
        let deviceWidth = UIDevice.screenSize.width
        let numberOfTeasers = self.teasersContentModel.count
        let sectionWidth = CGFloat(32 + (8 * numberOfTeasers) + (280 * numberOfTeasers))
        return (teaserDynaconConfig?.iPadAutoscrollEnabled ?? false) && (deviceWidth < sectionWidth)
    }
    
    /// Method will update the scrolled count in page controller footer view.
    /// - Parameter timer: timer.
    @objc func startScrollAnimation() {
        guard self.collectionView != nil else { return }
        guard let teaserSection = self.snapShot?.sectionIdentifiers.first(where: {$0.layoutType == .teasers}) else { return }
        guard self.collectionView != nil else { return }
        
        var isAutoScrollEnabled = UIDevice.isIPad() ? self.isIpadAutoScrollEnabled : isPageControllerFooterVisible.isVisible
        
        guard isAutoScrollEnabled else { return }
        teaserCurrentIndex += 1
        if teaserCurrentIndex >= self.snapShot?.numberOfItems(inSection: teaserSection) ?? 0 {
            teaserCurrentIndex = 0
        }
        let indexPathToScroll = IndexPath(item: teaserCurrentIndex, section: 0)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            guard self.collectionView != nil else { return }
            self.collectionView.scrollToItem(
                at: indexPathToScroll,
                at: .left,
                animated: self.teaserCurrentIndex != 0
            )
            self.startScrollTimerForVideoTeaser()
        }
    }
    
    func startScrollTimerForVideoTeaser() {
        NSObject.cancelPreviousPerformRequests(withTarget: self,
                                               selector: #selector(self.startScrollAnimation),
                                               object: nil)
        var duration = self.teaserDynaconConfig?.durationforAutoScroll ?? 10
        if teaserCurrentIndex >= 0, teaserCurrentIndex < self.teasersContentModel.count,
            let url = self.teasersContentModel[teaserCurrentIndex].attributes?.teaserVideoUrl,
            let videoDuration = self.videoDurations[url] {
            duration = videoDuration
        }
        self.perform(#selector(self.startScrollAnimation),
                     with: nil,
                     afterDelay: duration)
    }
    
    /// Method will clear all the stored properties and re-apply the snapshot.
    private func clearDatasource() {
        NSObject.cancelPreviousPerformRequests(withTarget: self,
                                               selector: #selector(self.startScrollAnimation),
                                               object: nil)
        self.teasersContentModel.removeAll()
        self.bannerContentModel = nil
        self.pagingInfoSubject.send(IndexPath(row: 0, section: 0))
        self.isCategorySelected = false
        self.selectedCategory = nil
        self.applySnapshot(with: nil)
        self.stopFooterTimer()
    }
    
    /// Method will configure the diffable datasource and returns the cells and supplementary views.
    func configureDatasource() {
        guard self.collectionView != nil else { return }
        self.diffDatasource = ImmersiveDatasource(collectionView: self.collectionView, cellProvider: { collectionView, indexPath, itemIdentifier in
            self.cell(collectionView: collectionView, indexPath: indexPath, item: itemIdentifier)
        })
        
        self.diffDatasource?.supplementaryViewProvider =  { collectionView, elementKind, indexPath in
            self.supplementaryView(collectionView: collectionView, indexPath: indexPath, kind: elementKind)
        }
        
        self.applySnapshot()
    }
    
    /// Confiure CollectionView cells based on the existing state
    /// - Parameters:
    ///   - collectionView: UICollectionView
    ///   - indexPath: IndexPath from DataSource
    ///   - item: Item
    /// - Returns: UICollectionViewCell
    func cell(collectionView: UICollectionView,
              indexPath: IndexPath,
              item: Item) -> UICollectionViewCell? {
        switch item {
            /// Game will be returned based on the layout type
            /// if layout type is list then list cell will be returned.
            /// if layout type is grid then grid cell will be returned.
        case .game(let game, let _):
            guard self.immersiveElements.count > indexPath.section else {
                return collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.gameCell, for: indexPath) as? EpcotGameCollectionViewCell
            }
            let layoutType = self.immersiveElements[indexPath.section].layoutType
            let iconSize = self.immersiveElements[indexPath.section].layoutType.rawValue
            let sticker = game.sticker
            let localizedStickerName = self.datasource?.feedViewModel?.getCategoryName(for: sticker ?? "")
            let isGIFImage = game.icon ?? 0 < 0
            if layoutType == .list {
                let listCell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.lobbyListCVCell, for: indexPath) as? GamesListViewCell
                if let gameVariant = game.game,
                   let immersiveInfo = self.datasource?.feedViewModel?.getImmersiveInfo(for: gameVariant, with: "\(iconSize)", isGIFImage: isGIFImage) {
                    let blurImagePath = self.datasource?.feedViewModel?.getListCellBlurImagePath(for: gameVariant)
                    listCell?.configureCell(with: immersiveInfo,
                                            blurImagePath: blurImagePath,
                                            sticker: localizedStickerName)
                    listCell?.subscribeTo(subject: jackpotInfoSubject)
                    listCell?.favouritesDelegate = self
                }
                return listCell
            } else if layoutType == .portraitSection {
                let portraitCell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.portraitCell, for: indexPath) as? PortraitSectionCollectionViewCell
                if let gameVariant = game.game,
                   let immersiveInfo = self.datasource?.feedViewModel?.getImmersiveInfo(for: gameVariant, with: "\(iconSize)", isGIFImage: isGIFImage) {
                    portraitCell?.confiureImmersiveCell(with: immersiveInfo,
                                                        sticker: localizedStickerName)
                    portraitCell?.favouritesDelegate = self
                }
                portraitCell?.subscribeTo(subject: jackpotInfoSubject)
                return portraitCell
            }
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.gameCell, for: indexPath) as? EpcotGameCollectionViewCell
            if let gameVariant = game.game,
               let immersiveInfo = self.datasource?.feedViewModel?.getImmersiveInfo(for: gameVariant, with: "\(iconSize)", isGIFImage: isGIFImage) {
                cell?.configureCell(with: immersiveInfo,
                                    sticker: localizedStickerName)
                cell?.subscribeTo(subject: jackpotInfoSubject)
                cell?.subscribeToLiveFeed(subject: liveFeedInfoSubject)
                cell?.favouritesDelegate = self
            }
            return cell
            /// Banner cell will be returned.
        case .banner(let banner) :
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.epcotEmbeddedBannerCell, for: indexPath) as? EpcotEmbeddedBannerCollectionViewCell
            cell?.delegate = self
            cell?.globalTeaserInfo = globalTeaser
            cell?.bannerInfo = banner
            return cell
            /// Recently played games cell will be returned which doesn't hold any local game download state or jackpot amount.
        case .rpGames(let model):
            let layoutType = self.immersiveElements[indexPath.section].layoutType
            let iconSize = layoutType.rawValue
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.gameCell, for: indexPath) as? EpcotGameCollectionViewCell
            let sticker = model.game.sticker
            let localizedStickerName = self.datasource?.feedViewModel?.getCategoryName(for: sticker ?? "")
            if let gameVariant = model.game.game,
               let immersiveInfo = self.datasource?.feedViewModel?.getImmersiveInfo(for: gameVariant, with: "\(iconSize)") {
                cell?.configureCell(with: immersiveInfo,
                                    isJackpotGame: model.isJackpotWidgetGame,
                                    sticker: localizedStickerName)
                cell?.subscribeTo(subject: jackpotInfoSubject)
                cell?.subscribeToLiveFeed(subject: liveFeedInfoSubject)
                cell?.favouritesDelegate = self
            }
            return cell
            /// Teasers cell will be returned.
        case .teasers(let model, let _):
            if let videoUrl = model.attributes?.teaserVideoUrl, !videoUrl.isEmpty {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.epcotBannerVideoCell, for: indexPath) as? EpcotBannerVideoCell
                cell?.subscribeTo(subject: teaserVideoInfoSubject)
                cell?.teaserInfo = model
                cell?.globalTeaserInfo = globalTeaser
                cell?.videoDelegate = self
                cell?.index = indexPath.item
                if indexPath.item == 0 {
                    self.teaserVideoInfoSubject.send((indexPath.item, videoUrl.url))
                }
                return cell
            } else {
                
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.teasersCollectionCell, for: indexPath) as? EpcotBannerCollectionViewCell
                cell?.teaserInfo =  model
                cell?.globalTeaserInfo = globalTeaser
                cell?.delegate = self
                return cell
            }
        case .singleJackpot(let widget, let _):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.jackpotWidgetCell, for: indexPath) as? JackpotWidgetCollectionViewCell
            cell?.jackpotModel = widget
            let jackpotGroupId = widget.jackpotGroupId.isEmpty ? widget.routeValue : widget.jackpotGroupId
            let amount = self.feedViewModel?.getAmountForJackpotId(for: jackpotGroupId)
            cell?.jackpotAmount = amount
            cell?.subscribeTo(subject: jackpotInfoSubject)
            return cell
            /// nothing covers then default cell will be retuned with loading view.
        case .mustGoJackpot(let widget, let _):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.mustGoJackpoCell, for: indexPath) as? MustGoCollectionViewCell
            cell?.jackpotModel = widget
            let jackpotGroupId = widget.jackpotGroupId.isEmpty ? widget.routeValue : widget.jackpotGroupId
            let subJackpotDetails = self.feedViewModel?.getSubJackpotDetails(for: jackpotGroupId)
            cell?.subJackpotDetails = subJackpotDetails
            cell?.subscribeTo(subject: jackpotInfoSubject)
            return cell
            /// Native footer will be returned.
        case .footerDividerLine:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.footerDividerLineCell, for: indexPath) as? NativeFooterDividerLineCell
            return cell
        case .footerStateSwitcher:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.footerStateChangerCell, for: indexPath) as? NativeFooterStateChangerCell
            cell?.delegate = self
            cell?.updateStateChangeView()
            cell?.selectedState = EpcotLobbyManager.shared?.datasource?.didRequestforFooterStates().selectedState ?? ""
            cell?.stateSwitcherModel = self.stateSwitcherModel
            ///subscription to display login duration time
            cell?.subscribeTo(subject: self.loggedInInfoSubject)
            /// subscription for state changer switch tap gesture.
            cell?.subscribeTo(subject: stateSwitcherInfoSubject)
            return cell
        case .aboutUs(let model, let _):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.footerBaseCell, for: indexPath) as? NativeFooterBaseCell
            cell?.contentModel = model
            return cell
        case .footerSeoLinks(let model, let _):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.footerBaseCell, for: indexPath) as? NativeFooterBaseCell
            cell?.seoModel = model
            return cell
        case .footerTextContent(let model, let _):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.footerTextContentCell, for: indexPath) as? NativeFooterContentCell
            cell?.contentModel = model
            return cell
        case .footerMediaLogo(let model, let _), .footerBrandLogo(let model, let _):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.footerLogoCell, for: indexPath) as? NativeFooterLogoCell
            cell?.contentModel = model
            return cell
        case .footerCopyRightContent(let model, let _):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.footerCopyRightCell, for: indexPath) as? NativeFooterCopyRightCell
            cell?.contentModel = model
            cell?.subscribeTo(subject: self.currentDateInfoSubject)
            return cell
        case .bingoButtonItem(let model):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.bingoSectionCollectionViewCell, for: indexPath) as? BingoSectionCollectionViewCell
            cell?.logoLabel.text = "open_Bingo_Lobby".localized
            return cell
        case .teaserVideos(let model, let _):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.gameTeaserVideosCustomCell, for: indexPath) as? TeaserVideosCustomCell
            cell?.subscribeTo(subject: netflixVideoPlayStatusInfoSubject)
            cell?.teaserInfo =  model
            cell?.teaserVideoDelegate = self
            return cell
        case .bingoWidgets(
            let models, let favouriteRoomIds, let roomImages, let names,
            let gameFeatureIcons, let icons, let texts, let globalTexts,
            let combinedRoomTexts, let combinedRooms
        ):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.bingoWidgetContainerCell, for: indexPath) as? BingoWidgetContainerCell
            let viewModel = BingoWidgetContainerViewModel(
                models: models,
                favouriteRoomIds: favouriteRoomIds,
                roomImages: roomImages,
                roomNames: names,
                gameFeatureIcons: gameFeatureIcons,
                roomIcons: icons,
                roomTexts: texts,
                globalTexts: globalTexts,
                combinedRoomTexts: combinedRoomTexts,
                combinedRooms: combinedRooms,
                seeAllAction: {
                    EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .bingoItem(""), buttonType: nil)
                },
                fetchBingoRooms: {
                    self.getBingoLobbyData()
                })
            
            cell?.contentConfiguration = UIHostingConfiguration {
                BingoWidgetContainerView(baseViewModel: viewModel)
            }
            
            return cell
        case .freeSpins(
            let widgets, let freeSpins, let freeSpinsDetails,
            let texts, let backgroundImage, let ctaImage
        ):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.reuseIdentifier, for: indexPath) as? UICollectionViewCell
            let container = FreeSpinsContainer(
                freeSpins: freeSpins,
                freeSpinsDetails: freeSpinsDetails,
                texts: texts,
                backgroundImage: backgroundImage,
                ctaImage: ctaImage
            ) { freeSpin, gameNames  in
                self.onClickFreeSpinsWidget?(freeSpin, gameNames)
            }
            
            cell?.contentConfiguration = UIHostingConfiguration {
                FreeSpinsContainerView(container: container)
            }
            
            return cell
        case .topGames(let games):
            let layoutType = self.immersiveElements[indexPath.section].layoutType
            let iconSize = self.immersiveElements[indexPath.section].layoutType.rawValue
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.reuseIdentifier, for: indexPath) as? UICollectionViewCell
            switch layoutType {
            case .topGamesPortraitGrid, 
                    .topGamesImmersiveGrid,
                    .topGamesHorizontalGrid:
                let viewModel = GamesEssentialsViewModel(
                    feedDatasource: self.datasource,
                    games: games, 
                    layout: layoutType, 
                    iconSize: iconSize
                ) { [weak self] game in
                    guard let selectedGame = game.game, let self else { return }
                    var subCategoryName = ""
                    if let subCategoryId =
                        self.immersiveElements[indexPath.section].subCategoryId {
                        if let name = self.datasource?.feedViewModel?.getCategoryName(for: subCategoryId) {
                            subCategoryName = name
                        }
                    }
                    var additionalParams = self.setAdditionalParameters(indexpath: indexPath)
                    additionalParams.subCategoryID = subCategoryName
                    additionalParams.location = GameSection.lobby.name
                    self.onClickGameplay?(selectedGame, additionalParams)
                }
                
                cell?.contentConfiguration = UIHostingConfiguration {
                    GamesLayoutView(layout: layoutType, viewModel: viewModel)
                }
                
                return cell
            default:
                break
            }
            return cell
        case .playerStatsWidget(let widget, let texts, let backgroundImages):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.playerWidgetContainerCell, for: indexPath) as? UICollectionViewCell
            
            self.playerStatsWidgetViewModel?.configure(feedDatasource: self,
                                                       texts: texts,
                                                       backgroundImages: backgroundImages) { [weak self] game in
                
                var additionalParams = self?.setAdditionalParameters(indexpath: indexPath)
                if let selectedCategory = self?.selectedCategory, let subCategories = self?.feedViewModel?.getSubCategories(for: selectedCategory) {
                    var subCategoryID = ""
                    for subCategory in subCategories {
                        if let route = subCategory.route?.lowercased(),  self?.playerStatsWidgets[route] != nil {
                            subCategoryID = subCategory.subcategoryid ?? route
                            break
                        }
                    }
                    additionalParams?.subCategoryID = subCategoryID
                }
                additionalParams?.location = GameSection.lobby.name
                self?.onClickGameplay?(game, additionalParams)
            }
            
            guard let playerStatsWidgetViewModel else { return cell }
            
            cell?.contentConfiguration = UIHostingConfiguration {
                PlayerStatsWidgetView(viewModel: playerStatsWidgetViewModel)
            }
            
            return cell
        case .jackpotTiles(let model, _) :
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.jackpotTileCell, for: indexPath) as? UICollectionViewCell
            cell?.contentView.backgroundColor = .clear
            let showViewGames = !(model.games?.isEmpty ?? true) && !self.showJackpotTileDetails.show
            let viewModel = JackpotTileViewModel(model: model,
                                                 showViewGames: showViewGames,
                                                 datasource: self)
            let tileWidth = UIDevice.isIPad() ? 378 : UIDevice.screenSize.width - 32
            let devWidth = showViewGames ? (cell?.contentView.frame.width ?? .infinity) : tileWidth
            
            cell?.contentConfiguration = UIHostingConfiguration {
                JackpotView(viewModel: viewModel)
                    .background(Color.clear)
                    .frame(width: devWidth, height: cell?.contentView.frame.height ?? .infinity)
            }
            return cell
            
        case .originalsWidget(let model, let showInCategory):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.originalsContainerCell, for: indexPath) as? UICollectionViewCell
            if self.originalsWidgetViewModel == nil {
                if let base = DynaconAPIConfiguration.shared?.posAppConfig?.portal?.promoBaseUrl {
                    model.updatePromoUrl(with: base)
                }
                self.originalsWidgetViewModel = OriginalsWidgetViewModel(content: model)
            }
            /// as view model is using main actor and
            /// the same view model is using every where,
            /// updating the variable on every load
            self.originalsWidgetViewModel?.isFromCategory = showInCategory
            
            if let originalsWidgetViewModel {
                cell?.contentConfiguration = UIHostingConfiguration {
                    if showInCategory {
                        OriginalsCategoryWidgetView(viewModel: originalsWidgetViewModel)
                            .frame(width: cell?.contentView.frame.width, height: 320)
                    } else {
                        OriginalsWidgetView(viewModel: originalsWidgetViewModel)
                            .frame(width: cell?.contentView.frame.width)
                    }
                }
                self.originalsWidgetViewModel?.seeDetailsBtnAction = { [weak self] in
                    self?.onClickSeeDeailsBtn?()
                }
                self.originalsWidgetViewModel?.$isViewGamesTapped.sink(receiveValue: {[weak self] tapped in
                    if tapped, let categoryId = model.linkedCategory {
                        self?.onClickLinkedCategory?(categoryId)
                        self?.originalsWidgetViewModel?.isViewGamesTapped = false
                    }
                })
                .store(in: &anycancellables)
            }
            return cell
        case .engagementTools(
            let widgets, let freeSpins, let freeSpinsDetails,
            let texts, let backgroundImage, let ctaImage,
            let promoEngagementTools, let toolsData
        ):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.reuseIdentifier, for: indexPath) as? UICollectionViewCell

            let container = EngagementToolsContainer(
                freeSpins: freeSpins,
                freeSpinsDetails: freeSpinsDetails,
                texts: texts,
                backgroundImage: backgroundImage,
                ctaImage: ctaImage,
                promoEngagementTools: promoEngagementTools,
                toolsData: toolsData
            ) { tool, gameNames in
                if tool.type == .freeSpins, let freeSpin = tool.freeSpin {
                    self.onClickFreeSpinsWidget?(freeSpin, gameNames)
                } else {
                    // MARK: Engagement Tools - Handle on click action
                }
            }
            
            cell?.contentConfiguration = UIHostingConfiguration {
                EngagementToolsContainerView(container: container)
            }
            
            return cell
        default:
            var layout:LayoutType = .verticalImmersiveGrid
            if self.immersiveElements.count > indexPath.section {
                layout = self.immersiveElements[indexPath.section].layoutType
            }
            var cell: EpcotBaseCollectionViewCell?
            switch layout {
            case .list:
                cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.lobbyListCVCell, for: indexPath) as? GamesListViewCell
            case .teasers:
                cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.teasersCollectionCell, for: indexPath) as? EpcotBannerCollectionViewCell
            case .embeddedBanner:
                cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.epcotEmbeddedBannerCell, for: indexPath) as? EpcotEmbeddedBannerCollectionViewCell
            default:
                cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.gameCell, for: indexPath) as? EpcotGameCollectionViewCell
            }
            cell?.showLoading()
            return cell
        }
    }
    
    func createCompositionalLayout() -> UICollectionViewCompositionalLayout {
        let layout = UICollectionViewCompositionalLayout { (sectionIndex: Int,
                                                            layoutEnvironment: NSCollectionLayoutEnvironment) -> NSCollectionLayoutSection? in
            let width = layoutEnvironment.container.effectiveContentSize.width
            guard let sectionIdentifiers = self.snapShot?.sectionIdentifiers, sectionIdentifiers.count > sectionIndex else {
                return CustomLayoutSection.verticalImmersiveSection(isHeaderAvailable: false)
            }
            let teasersCount = self.teasersContentModel.count
            let freeSpinsScrollable = (self.freeSpinsDetails?.rewardDetails?.count ?? 0) > 1
            // TODO: Engagement Tools - Write the logic for scrolling
            let engagementToolsScrollable = (self.freeSpinsDetails?.rewardDetails?.count ?? 0) > 1
            let section = sectionIdentifiers[sectionIndex].createSection(
                with: width,
                isFirstSection: sectionIndex == 0,
                numberOfTeasers: teasersCount,
                isFreeSpinsScrollable: freeSpinsScrollable,
                isEngagementToolsScrollable: engagementToolsScrollable
            )
            section.visibleItemsInvalidationHandler = { [weak self] (visibleItems, scrollOffset, layoutEnvironment) -> Void in
                guard let self = self else { return }
                guard !self.immersiveElements.isEmpty else { return }
                if visibleItems.contains(where: { visibleItem in
                    if self.immersiveElements.count > visibleItem.indexPath.section {
                        return self.immersiveElements[visibleItem.indexPath.section].layoutType == LayoutType.teasers
                    }
                    return false
                }) {
                    self.updateTeasersScroll(layoutEnvironment: layoutEnvironment,
                                             scrollOffset: scrollOffset,
                                             sectionIndex: sectionIndex)
                } else if visibleItems.contains(where: { visibleItem in
                    if self.immersiveElements.count > visibleItem.indexPath.section {
                        return self.immersiveElements[visibleItem.indexPath.section].layoutType == LayoutType.multipleJackpotWidget
                    }
                    return false
                }) {
                    self.stopJackpotTimer()
                    self.stopJackpotWidgetScrollTimer()
                    self.updateJackpotWidgetScroll(layoutEnvironment: layoutEnvironment,
                                                   scrollOffset: scrollOffset,
                                                   sectionIndex: sectionIndex)
                }
            }
            return section
        }
        layout.register(WidgetDecoratorView.self,
                        forDecorationViewOfKind: WidgetDecoratorView.reuseIdentifier)
        layout.register(MultipleWidgetsDecoratorView.self,
                        forDecorationViewOfKind: MultipleWidgetsDecoratorView.reuseIdentifier)
        layout.register(MustGoWidgetDecoratorView.self,
                        forDecorationViewOfKind: MustGoWidgetDecoratorView.reuseIdentifier)
        layout.register(WidgetGamesDecoratorView.self,
                        forDecorationViewOfKind: WidgetGamesDecoratorView.reuseIdentifier)
        layout.register(MultipleWidgetsGamesDecoratorView.self,
                        forDecorationViewOfKind: MultipleWidgetsGamesDecoratorView.reuseIdentifier)
        layout.register(MustGoWidgetGamesDecoratorView.self,
                        forDecorationViewOfKind: MustGoWidgetGamesDecoratorView.reuseIdentifier)
        layout.register(FooterStateDecoratorView.self,
                        forDecorationViewOfKind: FooterStateDecoratorView.reuseIdentifier)
        layout.register(FooterDivideLineDecoratorView.self,
                        forDecorationViewOfKind: FooterDivideLineDecoratorView.reuseIdentifier)
        layout.register(FooterAboutUsDecoratorView.self,
                        forDecorationViewOfKind: FooterAboutUsDecoratorView.reuseIdentifier)
        layout.register(FooterSeoLinksDecoratorView.self,
                        forDecorationViewOfKind: FooterSeoLinksDecoratorView.reuseIdentifier)
        layout.register(FooterLogosDecoratorView.self,
                        forDecorationViewOfKind: FooterLogosDecoratorView.reuseIdentifier)
        layout.register(FooterContentDecoratorView.self,
                        forDecorationViewOfKind: FooterContentDecoratorView.reuseIdentifier)
        layout.register(FooterCopyRightDecoratorView.self,
                        forDecorationViewOfKind: FooterCopyRightDecoratorView.reuseIdentifier)
        return layout
    }
    
    /// Method will apply the snapshot based on the immersive layout type.
    /// - Parameter category: category for which snapshot to be applied.
    func applySnapshot(with category: String? = nil,
                       for isJackpotUpdate:Bool = false) {
        self.snapShot = ImmersiveSnapshot()
        guard let sections = self.createDatasource(for: category) else {
            self.createLoaderDataSource()
            return
        }
        self.snapShot?.appendSections(sections)
        sections.forEach { section in
            let layout = section.layoutType
            switch layout {
            case .verticalImmersiveGrid,
                    .horizontalImmersiveGrid,
                    .verticalGrid, .horizontalGrid, .list, .superSquare, .portraitSection :
                if let games = section.games {
                    self.snapShot?.appendItems(games.map({Item.game($0, UUID())}), toSection: section)
                }
            case .topGamesPortraitGrid, 
                    .topGamesImmersiveGrid,
                    .topGamesHorizontalGrid:
                if let games = section.games {
                    self.snapShot?.appendItems(
                        [Item.topGames(games)],
                        toSection: section
                    )
                }
            case .teasers:
                self.snapShot?.appendItems(self.teasersContentModel.map({Item.teasers($0, UUID())}), toSection: section)
            case .embeddedBanner:
                if let bannerModel = self.bannerContentModel {
                    self.snapShot?.appendItems([bannerModel].map(Item.banner), toSection: section)
                }
            case .recentlyPlayedGrid, .favouriteGamesGrid:
                if let recentlyPlayedGames = section.games {
                    self.snapShot?.appendItems(recentlyPlayedGames.map({Item.rpGames(JackpotWidgetGameModel(game: $0))}), toSection: section)
                }
            case .multiJackpotWidgetGames:
                if let recentlyPlayedGames = section.games {
                    self.snapShot?.appendItems(recentlyPlayedGames.map({Item.rpGames(JackpotWidgetGameModel(game: $0, isJackpotWidgetGame: true))}), toSection: section)
                }
            case .jackpotWidget:
                if let widget = section.jackpotWidget {
                    self.snapShot?.appendItems(widget.map({Item.singleJackpot($0, UUID())}), toSection: section)
                }
            case .jackpotMustGoWidget:
                if let widget = section.jackpotWidget {
                    self.snapShot?.appendItems(widget.map({Item.mustGoJackpot($0, UUID())}), toSection: section)
                }
            case .multipleJackpotWidget:
                if let widget = section.jackpotWidget {
                    self.snapShot?.appendItems(widget.map({Item.singleJackpot($0, UUID())}), toSection: section)
                }
            case .freeSpinsWidget:
                let backgroundImage = POSAPI.shared?.freeSpinsWidgetBackgroundImage ?? ""
                let ctaImage = POSAPI.shared?.freeSpinsWidgetCtaBackgroundImage ?? ""
                if let widgets = section.freeSpinWidgets,
                   let freeSpins = section.prominentFreeSpins,
                   let freeSpinsDetails = section.freeSpinsDetails,
                   let texts = POSAPI.shared?.freeSpinsWidgetConfigurationTexts {
                    self.snapShot?.appendItems(
                        [
                            Item.freeSpins(
                                widgets, freeSpins, freeSpinsDetails, texts,
                                backgroundImage, ctaImage
                            )
                        ],
                        toSection: section
                    )
                }
            case .playerStatsWidget:
                if let widget = section.playerStatsWidget,
                   let texts = POSAPI.shared?.playerStatsConfigurations,
                   let backgroundImages = POSAPI.shared?.playerStatsBackGroundImages {
                    self.snapShot?.appendItems([Item.playerStatsWidget(widget, texts, backgroundImages)],
                                               toSection: section)
                }
            case .footerDividerLine:
                self.snapShot?.appendItems([Item.footerDividerLine], toSection: section)
            case .footerStateswitcher:
                self.snapShot?.appendItems([Item.footerStateSwitcher], toSection: section)
            case .footerAboutUs:
                if let aboutUsDataSource = section.footerAboutUsItem {
                    self.snapShot?.appendItems(aboutUsDataSource.map({Item.aboutUs($0, UUID())}), toSection: section)
                }
            case .footerSeoLinks:
                if let seoLinks = section.footerSeoLinks {
                    self.snapShot?.appendItems(seoLinks.map({Item.footerSeoLinks($0, UUID())}), toSection: section)
                }
            case .footerMediaLogos:
                if let mediaLogos = section.footerMediaLogos {
                    self.snapShot?.appendItems(mediaLogos.map({Item.footerMediaLogo($0, UUID())}), toSection: section)
                }
            case .footerTextContent:
                if let textContent = section.footerContent {
                    self.snapShot?.appendItems(textContent.map({Item.footerTextContent($0, UUID())}), toSection: section)
                }
            case .footerCopyRight:
                if let copyRight = section.footerCopyRight {
                        self.snapShot?.appendItems(copyRight.map({Item.footerCopyRightContent($0, UUID())}), toSection: section)
                }
            case .footerBrandLogos:
                if let brandLogos = section.footerBrandLogos {
                            self.snapShot?.appendItems(brandLogos.map({Item.footerBrandLogo($0, UUID())}), toSection: section)
                }
            case .bingoButtonLayout:
                if let bingoButton = section.bingoButtonLogo {
                                self.snapShot?.appendItems(bingoButton.map(Item.bingoButtonItem), toSection: section)
                }
            case .bingoWidgetLayout:
                if let gamesList = section.bingoLobbyModel?.result?.gamesList,
                   let roomImages = POSAPI.shared?.bingoRoomImages,
                   let roomNames = POSAPI.shared?.bingoRoomNames,
                   let featureIcons = POSAPI.shared?.bingoRoomGameFeatureIcons,
                   let icons = POSAPI.shared?.bingoRoomIcons,
                   let texts = POSAPI.shared?.bingoRoomTexts,
                   let globalTexts = POSAPI.shared?.bingoRoomGlobalTexts,
                   let combinedRoomTexts = POSAPI.shared?.bingoRoomGlobalSEPTexts,
                   let combinedRooms = POSAPI.shared?.bingoWidgetCombinedRooms {
                    let favouriteRooms = section.bingoLobbyModel?.result?.favouriteRooms ?? []
                    self.snapShot?.appendItems(
                        [Item.bingoWidgets(
                            gamesList, favouriteRooms, roomImages, roomNames, featureIcons, icons, texts, globalTexts, combinedRoomTexts, combinedRooms
                        )],
                        toSection: section
                    )
                }
            case .videoLayout:
                if let teaserVideos = section.videosTeasersSection {
                    self.snapShot?.appendItems(teaserVideos.map({Item.teaserVideos($0, UUID())}), toSection: section)
                }
            case .jackpotTiles, .jackpotTileFullWidth:
                if let tiles = section.jackpotTiles {
                    self.snapShot?.appendItems(tiles.map({ .jackpotTiles($0, UUID()) }), toSection: section)
                }
            case .originalsWidget:
                if let originalsWidget = section.originalsWidget, let model = originalsWidget.model {
                    let showInCategory = originalsWidget.showInCategory
                    self.snapShot?.appendItems([Item.originalsWidget(model, showInCategory)],
                                               toSection: section)
                }
            case .engagementTools:
                let backgroundImage = POSAPI.shared?.freeSpinsWidgetBackgroundImage ?? ""
                let ctaImage = POSAPI.shared?.freeSpinsWidgetCtaBackgroundImage ?? ""
                let tools = section.engagementTools // Native widget data
                let freeSpins = section.prominentFreeSpins
                let freeSpinsDetails = section.freeSpinsDetails
                let texts = POSAPI.shared?.freeSpinsWidgetConfigurationTexts
                let promoEngagementTools = section.promoEngagementTools
                let toolsData = POSAPI.shared?.engagementTools // Site-core data

                if let tools, let freeSpins, let freeSpinsDetails,
                    let texts, let toolsData, let promoEngagementTools {
                    self.snapShot?.appendItems(
                        [
                            Item.engagementTools(
                                tools, freeSpins, freeSpinsDetails, texts,
                                backgroundImage, ctaImage,
                                promoEngagementTools, toolsData
                            )
                        ],
                        toSection: section
                    )
                }
            }
        }
        guard let snapshot = self.snapShot else { return }
        DispatchQueue.main.async {
            if isJackpotUpdate {
                self.diffDatasource?.apply(self.snapShot ?? snapshot, animatingDifferences: false, completion: {[weak self] in
                    EpcotLobbyManager.shared?.delegate?.didLobbyLoaded()
                    self?.startJackpotTimer()
                    self?.startJackpotScrollTimer()
                })
            } else {
                self.diffDatasource?.apply(self.snapShot ?? snapshot, animatingDifferences: false, completion: {[weak self] in
                    guard let self = self, self.collectionView != nil else { return }
                    self.collectionView.setContentOffset(kCollectionViewOffSet, animated: false)
                    EpcotLobbyManager.shared?.delegate?.didLobbyLoaded()
                    self.startJackpotTimer()
                    self.startJackpotScrollTimer()
                })
            }
        }
    }
    
    func didTappedOn(favourites cell: EpcotBaseCollectionViewCell, gameVariant: String, state: Bool) {
        self.updateGameFavouriteState(cell: cell, game: gameVariant, state: state)
        let actionEvent = state ? EpcotEventAction.addFavorites.rawValue : EpcotEventAction.removeFavorites.rawValue
        let eventType = state ? EventType.favouriteGameAdd : EventType.favouriteGameRemove
        var section = ""
        if let indexPath = self.collectionView.indexPath(for: cell),self.immersiveElements.count > indexPath.section {
            section =
            self.immersiveElements[indexPath.section].subCategoryId ?? ""
        }
        self.trackFavouritesClickEvent(gameName: gameVariant, action: actionEvent, section: section, type: eventType)
    }
}

//MARK: - Diffable datasource and snapshot setup
extension ImmersiveLobbyCollectionViewController {
    /// Method will return the supplementary view based on the section type.
    /// - Parameters:
    ///   - collectionView: collection View
    ///   - indexPath: index path of the section for which header/footer is required.
    ///   - kind: element kind either header/footer
    /// - Returns: supplementary view
    func supplementaryView(collectionView: UICollectionView,
                           indexPath: IndexPath,
                           kind: String) -> UICollectionReusableView? {
        if kind == UICollectionView.elementKindSectionHeader {
            if self.immersiveElements.count > indexPath.section,
               let subCategoryId = self.immersiveElements[indexPath.section].subCategoryId  {
                var title = subCategoryId == Localize.allGames ? Localize.allGames.displayName(isSubCategory: true) : self.datasource?.feedViewModel?.getCategoryName(for: subCategoryId, isSubCategory: true) ?? Localize.qualifyingGames.displayName(isSubCategory: true)
                
                /// we have to verify first whether the jackpot widget is available or not.
                /// if let widgetType = self.immersiveElements[indexPath.section].jackpotWidget, then we have to return the widget based info
                /// if games are prefixed or only certain limit of games are considered then MoreItemsCollectionReusableView will be returned and other wise EpcotSectionHeader will be returned.
                /// headerView.siteCoreData = siteCoreData
                /// headerView.AmountData = amount
            
                if self.immersiveElements[indexPath.section].layoutType == .footerAboutUs || self.immersiveElements[indexPath.section].layoutType == .footerSeoLinks {
                    title = subCategoryId
                    let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind,
                                                                                     withReuseIdentifier: CellIdentifier.footerBaseHeaderReusableView,
                                                                                     for: indexPath) as? NativeFooterBaseReusableView
                    
                    headerView?.titleLabel.text = (title.isEmpty || title == Localize.qualifyingGames) ? "" : title
                    return headerView
                }

                let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: CellIdentifier.moreSectionCell, for: indexPath) as? MoreItemsCollectionReusableView
                
                /// Setting the title
                if title.isEmpty {
                    title = Localize.qualifyingGames.isEmpty ? "Qualifying Games" : Localize.qualifyingGames
                    title = title.displayName(isSubCategory: true)
                }
                
                /// Setting Accessibility Identifier
                headerView?.seeMoreButton.accessibilityIdentifier = "seeAll_\(indexPath.section)"
                headerView?.descriptionLabel.accessibilityIdentifier = "jackpotFusion_description_\(indexPath.section)"
                headerView?.infoButton.accessibilityIdentifier = "jackpotFusion_info_\(indexPath.section)"
                
                /// Setting the layout type
                headerView?.layoutType = self.immersiveElements[indexPath.section].widgetLayoutType
                
                /// Dequeing the content
                headerView?.infoButton.isHidden = true
                headerView?.descriptionLabel.isHidden = true
                headerView?.descriptionHeightConstraint.constant = 0
                headerView?.route = nil
                
                /// Setting the content based on the route
                if let route  = self.immersiveElements[indexPath.section].route {
                    if let headerDescription = self.jackpotFusion[route]?.headerTitle,
                        !headerDescription.isEmpty {
                        headerView?.descriptionLabel.text = headerDescription
                        headerView?.descriptionLabel.isHidden = false
                        headerView?.descriptionHeightConstraint.constant = kHeaderDescriptionHeight
                    }
                    if let content = self.jackpotFusion[route]?.jackpotInfo,
                        !content.isEmpty {
                        headerView?.infoButton.isHidden = false
                    }
                    headerView?.route = route
                    let attributes = JackpotWidgetsViewModel.shared.attributes[route] as? [String: Any]
                    if let displayType = attributes?[kSubCategoryDisplayType] as? String {
                        title = title.getString(for: NamingConfiguration(rawValue: displayType.toInt))
                    }
                }
                
                headerView?.titleLabel.text = title
                headerView?.seeMoreButton.isHidden = !self.immersiveElements[indexPath.section].isGamesPrefixed
                headerView?.seeMoreArrowButton.isHidden = !self.immersiveElements[indexPath.section].isGamesPrefixed
                
                headerView?.delegate = self
                headerView?.subCategoryId = subCategoryId
                return headerView
            }
        } else if self.immersiveElements.count > indexPath.section {
            /// Footer view for teasers will be returned.
            let footerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind,
                                                                             withReuseIdentifier: CellIdentifier.teasersFooterCell,
                                                                             for: indexPath) as? EpcotPageControlFooterView
            if self.immersiveElements[indexPath.section].layoutType == .teasers {
                footerView?.pageControl.numberOfPages = self.teasersContentModel.count
                footerView?.pageControl.drawerStyle = .scale
                footerView?.updateContentTheme(normalColor:
                                                globalTeaser?.attributes?.teaserDefaultBulletNormalColor?.hexColor,
                                               selectedColor:
                                                globalTeaser?.attributes?.teaserDefaultBulletHighlightedColor?.hexColor)
                footerView?.subscribeTo(subject: pagingInfoSubject)
            } else if self.immersiveElements[indexPath.section].layoutType == .multipleJackpotWidget {
                footerView?.pageControl.numberOfPages = self.immersiveElements[indexPath.section].jackpotWidget?.count ?? 0
                footerView?.pageControl.drawerStyle = .slide
                footerView?.subscribeTo(subject: pagingInfoSubject)
            }
            return footerView
        }
        let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind,
                                                                         withReuseIdentifier: CellIdentifier.recentlyPlayedGamesHeader,
                                                                         for: indexPath) as? EpcotSectionHeader
        return headerView
    }
    
    /// Method will created the datasource by using  the category, teasers, banners, recently played games, native footer.
    /// - Parameter category: category for which subCategories to be displayed.
    /// - Returns: Immersive Lobby sections array which will hold the games, layout type.
    private func createDatasource(for category: String? = nil)-> [ImmersiveLobbySection]? {
        self.immersiveElements.removeAll()
        self.immersiveElements = [ImmersiveLobbySection]()
        
        guard !self.createJackPotTilesDataSourceAsCategory() else {
            //if jackpot tiles selected, showing jackpot tiles details with games
            ///Footer Configuration
            self.setupNativeFooterDatasource()
            JackpotTileTracking().trackEvent(type: .load(tileName: self.showJackpotTileDetails.model?.titleText ?? ""))
            return self.immersiveElements
        }
        
        let categoryId = category ?? self.datasource?.feedViewModel?.firstCategory
        if categoryId == POSAPI.shared?.originalsWidgetConfigurations?.linkedCategory {
            createOriginalsWidgetInCategoryPage()
        }
        self.selectedCategory = categoryId
        if self.datasource?.feedViewModel?.firstCategory == category && self.headerType != .epcotCategoryPills {
            self.isCategorySelected = false
        }
        if categoryId == kLmcRecentlyPlay {
            if let recentlyPlayedGames = self.datasource?.feedViewModel?.recentlyPlayedGames, !recentlyPlayedGames.isEmpty {
                let isHeaderAvailable = ImmersiveInstance.shared.isEnabled
                let immersiveRecentlyPlayedSection = ImmersiveLobbySection(subCategoryId: kLmcRecentlyPlay,
                                                                           games: recentlyPlayedGames,
                                                                           layoutType: .verticalGrid,
                                                                           isHeaderAvailable: isHeaderAvailable)
                self.immersiveElements.insert(immersiveRecentlyPlayedSection, at: 0)
                self.setupNativeFooterDatasource()
            }
            return self.immersiveElements
        } else if categoryId == kLmcFavourites {
            if let favouritesGames = self.datasource?.feedViewModel?.favouriteGames, !favouritesGames.isEmpty {
                let favouriteSection = ImmersiveLobbySection(subCategoryId: kLmcFavourites,
                                                                           games: favouritesGames,
                                                                           layoutType: .verticalGrid)
                self.immersiveElements.insert(favouriteSection, at: 0)
                self.setupNativeFooterDatasource()
            }
            return self.immersiveElements
        } else {
            if let firstCateogry = categoryId,
               let subCategories =  self.datasource?.feedViewModel?.getSubCategories(for: firstCateogry) {
                subCategories.forEach { subCategory in
                    let isCasiaAvailable = self.feedViewModel?.isCasiaCategoryAvailable(for: firstCateogry, subCategory: subCategory.subcategoryid ?? "") ?? false
                    let gamesList = isCasiaAvailable ? self.feedViewModel?.getSubCategoryGames(for: subCategory.subcategoryid ?? "", in: firstCateogry) : subCategory.gamelist
                    if let subCategoryId = subCategory.subcategoryid,
                       var games = gamesList, !games.isEmpty {
                        let rowCount = subCategory.rowCount?.toInt ?? 0
                        let iconSize = games.first(where: {$0.icon != nil})?.icon ?? 1
                        var isGamesPrefixed = false
                        let limit = horizontalScrollLimt
                        var layoutType = LayoutType(rawValue: abs(iconSize)) ?? .verticalImmersiveGrid
                        // TODO: NAT-101630 - Write a logic to compare this static key or enable it from site-core.
                        if subCategory.route == "" {
                            if iconSize == 1 {
                                layoutType = .topGamesImmersiveGrid
                            } else if iconSize == 3 {
                                layoutType = .topGamesPortraitGrid
                            } else if iconSize == 4 {
                                layoutType = .topGamesHorizontalGrid
                            }
                            isGamesPrefixed = games.count > limit
                            games = Array(games.prefix(limit))
                        } else {
                            if rowCount == kHorizontalScrollRowCount /* -1 */ {
                                /// row count -1 then, horizontal scroll will be displayed with the limit provided from dynacon.
                                if iconSize == 3 {
                                    isGamesPrefixed = games.count > limit
                                    games = Array(games.prefix(limit))
                                } else {
                                    isGamesPrefixed = games.count > limit
                                    games = Array(games.prefix(limit))
                                    layoutType = iconSize == 4 ? .horizontalGrid : .horizontalImmersiveGrid
                                }
                            } else if rowCount > kGridVerticalScrollRowCount /* 0 */ {
                                /// row count is greater than zero then, horizontal scroll will be displayed with the limit based on the rowCount
                                switch layoutType {
                                case .verticalGrid:
                                    /// only two items will be displayed and it is grid
                                    let prefixCount = UIDevice.isIPad() ? 4 : 2
                                    let prefixLimit = prefixCount * rowCount
                                    isGamesPrefixed = games.count > prefixLimit
                                    games = Array(games.prefix(prefixLimit))
                                case .list:
                                    /// only one item will be displayed and it is list view.
                                    let prefix = UIDevice.isIPad() ? 2 : 1
                                    let prefixLimit = prefix * rowCount
                                    isGamesPrefixed = games.count > prefixLimit
                                    games = Array(games.prefix(prefixLimit))
                                case .superSquare:
                                    /// only one big square item will be displayed.
                                    let prefixCount = UIDevice.isIPad() ? 2 : 1
                                    isGamesPrefixed = games.count > 1
                                    games = Array(games.prefix(prefixCount))
                                case .portraitSection:
                                    isGamesPrefixed = games.count > limit
                                    games = Array(games.prefix(limit))
                                case .horizontalImmersiveGrid, .horizontalGrid, .recentlyPlayedGrid, .teasers, .embeddedBanner, .footerAboutUs, .favouriteGamesGrid:
                                    let prefixCount = UIDevice.isIPad() ? 6 : 3
                                    let prefixLimit = prefixCount * rowCount
                                    isGamesPrefixed = games.count > prefixLimit
                                    games = Array(games.prefix(prefixLimit))
                                    layoutType = .verticalImmersiveGrid
                                default:
                                    /// other wise 3 times the rowCount items will be displayed in vertical scroll manner with 3 items per row.
                                    let prefixCount = UIDevice.isIPad() ? 6 : 3
                                    let prefixLimit = prefixCount * rowCount
                                    isGamesPrefixed = games.count > prefixLimit
                                    games = Array(games.prefix(prefixLimit))
                                }
                            } else {
                                /// if row Count 0 or any negative integer other than -1 then there will be no limit
                                switch layoutType {
                                case .superSquare:
                                    /// Super square/ big tile will be displayed.
                                    let prefixCount = UIDevice.isIPad() ? 2 : 1
                                    isGamesPrefixed = games.count > 1
                                    games = Array(games.prefix(prefixCount))
                                case .horizontalImmersiveGrid, .horizontalGrid, .recentlyPlayedGrid,.teasers, .embeddedBanner:
                                    layoutType = .verticalImmersiveGrid
                                default: break
                                }
                            }
                        }
                        if !isGamesPrefixed {
                            if let linkedCategroy = subCategory.linkedCategory, !linkedCategroy.isEmpty,
                               let categories = self.feedViewModel?.categoryIds, categories.contains(where: {$0 == linkedCategroy}) {
                                isGamesPrefixed = true
                            }
                        }
                    
                        let route = subCategory.route?.lowercased() ?? ""
                        
                        let jackpotTile = jackpotTiles[route]
                        let jackpotTilePosition = jackpotTile?.jackpotTilesPosition ?? .afterGames
                        
                        let playerStats = playerStatsWidgets[route]
                        let playerStatsPosition = playerStats?.playerStatsPosition ?? .afterGames
                        
                        let originalWidget = self.originalsWidget[route]
                        let originalsPosition = originalWidget?.betMGMOriginalsPosition ?? .afterGames
                        
                        var isHeaderIncluded = true
                        let positions = gameTileItemsConfig?.gameTileItemsPositions ?? [0,1,2,3,4,5,6]
                        let priority = positions.compactMap { SubCategoryItemsPriority(rawValue: $0) }
                        var priorities = positions.compactMap { SubCategoryItemsPriority(rawValue: $0) }
                        var priorPriorites = [SubCategoryItemsPriority]()
                        
                        priorities.forEach { priority in
                            switch priority {
                            case .playerStatsWidget where playerStatsPosition == .beforeGames,
                                    .jackpotTiles where jackpotTilePosition == .beforeGames,
                                    .originalsWidget where originalsPosition == .beforeGames:
                                priorities.removeAll { $0 == priority }
                                priorPriorites.append(priority)
                            default:
                                break
                            }
                        }
                        
                        priorities = priorPriorites + priorities
                        
                        var headerDescription = ""
                        if let route = subCategory.route?.lowercased(),
                           let description = self.jackpotFusion[route]?.headerTitle {
                            headerDescription = description
                        }
                        
                        for (index,priorityItem) in priorities.enumerated() {
                            switch priorityItem {
                            case .games:
                                let immersiveSection = ImmersiveLobbySection(subCategoryId: subCategoryId,
                                                                             games: games,
                                                                             layoutType: layoutType,
                                                                             isGamesPrefixed: isGamesPrefixed,
                                                                             isHeaderAvailable: isHeaderIncluded,
                                                                             subCategoryHeaderDescription:headerDescription,
                                                                             route: subCategory.route?.lowercased())
                                self.immersiveElements.append(immersiveSection)
                                if isHeaderIncluded {
                                    isHeaderIncluded = false
                                }
                            case .jackpotWidgets:
                                isHeaderIncluded = self.setupJackpotWidgetDatasource(
                                    with: subCategory,
                                    isGamesPrefixed: isGamesPrefixed,
                                    isHeaderAvailable: isHeaderIncluded,
                                    subCategoryHeaderDescription: headerDescription
                                )
                            case .videoTeaser:
                                self.setupGameTeaserVideosDatasource(
                                    with: subCategory,
                                    with: index,
                                    isGamesPrefixed: isGamesPrefixed,
                                    subCategoryHeaderDescription: headerDescription
                                )
                            case .freeSpinWidgets:
                                isHeaderIncluded = self.setupFreeSpinsWidgetDataSource(
                                    with: subCategory,
                                    isGamesPrefixed: isGamesPrefixed,
                                    isHeaderAvailable: isHeaderIncluded,
                                    subCategoryHeaderDescription: headerDescription
                                )
                            case .playerStatsWidget:
                                isHeaderIncluded = self.setupPlayerWidgetDataSource(
                                    with: subCategory,
                                    isGamesPrefixed: isGamesPrefixed,
                                    isHeaderAvailable: isHeaderIncluded,
                                    subCategoryHeaderDescription: headerDescription
                                )
                            case .jackpotTiles:
                                if jackpotTile?.isJackpotTileEnabled == true {
                                    isHeaderIncluded = self.setupJackPotTilesDataSource(
                                        with: subCategory,
                                        isGamesPrefixed: isGamesPrefixed,
                                        isHeaderAvailable: isHeaderIncluded,
                                        subCategoryHeaderDescription: headerDescription
                                    )
                                }
                            case .originalsWidget:
                                isHeaderIncluded =  self.setupOriginalsWidgetDataSource(with: subCategory,
                                                                                        isGamesPrefixed: isGamesPrefixed,
                                                                                        isHeaderAvailable: isHeaderIncluded,
                                                                                        subCategoryHeaderDescription: headerDescription)
                            case .engagementTools:
                                self.setupEngagementToolsDataSource(with: subCategory)
                            }
                        }
                    }
                }
            } else {
                var lobbyType: SwitcherCategoryType = EpcotLobbyManager.shared?.lobbySwitcherType ?? .grid
                let immersiveLayoutType: LayoutType = lobbyType == .grid ? .verticalGrid : .list
                if let firstCategory = categoryId {
                    if firstCategory == kLmcLiveCasino,
                            let games = self.feedViewModel?.getGames(for: firstCategory) {
                        let immersiveSection = ImmersiveLobbySection(subCategoryId: Localize.allGames,
                                                                     games: games,
                                                                     layoutType: immersiveLayoutType,
                                                                     isHeaderAvailable: false)
                        self.immersiveElements.append(immersiveSection)
                    } else if let games = self.feedViewModel?.getSlicedGames(with: firstCategory,
                                                                               tillPosition: self.bannerPosition) {
                        if let preBannerGames = games.0 {
                            let preBannerGamesSection = ImmersiveLobbySection(subCategoryId: Localize.allGames,
                                                                              games: preBannerGames,
                                                                              layoutType: immersiveLayoutType,
                                                                              isGamesPrefixed: false,
                                                                              isHeaderAvailable: !self.isCategorySelected,
                                                                              isPreBannerGames: true)
                            self.immersiveElements.append(preBannerGamesSection)
                        }
                        if let postBannerGames = games.1 {
                            let postBannerGamesSection = ImmersiveLobbySection(subCategoryId: Localize.allGames,
                                                                               games: postBannerGames,
                                                                               layoutType: immersiveLayoutType,
                                                                               isGamesPrefixed: false,
                                                                               isHeaderAvailable: false,
                                                                               isPreBannerGames: false)
                            self.immersiveElements.append(postBannerGamesSection)
                        }
                    }
                }
            }
            /// Embedded Banners configuration.
            self.setupEmbeddBannerDatasource()
            
            ///Footer Configuration
            self.setupNativeFooterDatasource()
            
            guard !self.isCategorySelected else { return self.immersiveElements }
            
            if let priroity = EpcotLobbyManager.shared?.datasource?.layoutOrder?.reversed() {
                priroity.forEach { sectionPriority in
                    switch sectionPriority {
                    case .teasers: self.setupTeasersDatasource()
                    case .recentlyPlayedGames: self.setupRecentlyPlayedGamesDatasource()
                    case .favouriteGames: self.setupFavouriteGamesDatasource()
                    case .bingoButton: self.setupBingoButtonDatasource()
                    case .bingoWidget: self.setupNativeBingoWidgetDatasource()
                    }
                }
            } else {
                if self.isFavGamesSectionShown {
                    self.setupFavouriteGamesDatasource()
                }
                self.setupRecentlyPlayedGamesDatasource()
                self.setupTeasersDatasource()
            }
            return self.immersiveElements
        }
    }
    
    private func setupJackpotWidgetDatasource(
        with subCategory: SubCategory,
        isGamesPrefixed: Bool,
        isHeaderAvailable: Bool,
        subCategoryHeaderDescription: String?
    ) -> Bool {
        if let route = subCategory.route?.lowercased(), !route.isEmpty,
            let nativeWidget = self.jackpotWidgets[route] {
            var layoutType: LayoutType = .jackpotWidget
            var widgets = nativeWidget.jackpotWidgets
            widgets = widgets.filter({!(self.feedViewModel?.getJackpotBasedGames(for: $0.routeValue)?.isEmpty ?? true)})
            if nativeWidget.showMustGo?.boolValue ?? false {
                layoutType = .jackpotMustGoWidget
            } else if widgets.count > 1 {
                layoutType = .multipleJackpotWidget
            }
            
            if !widgets.isEmpty, let jackpotId = widgets.first?.routeValue,
                var games = self.feedViewModel?.getJackpotBasedGames(for: jackpotId),
                !games.isEmpty {
                let multipleJackpotsSection = ImmersiveLobbySection(
                    subCategoryId: route,
                    layoutType: layoutType,
                    isGamesPrefixed: isGamesPrefixed,
                    jackpotWidget: widgets,
                    isHeaderAvailable: isHeaderAvailable,
                    subCategoryHeaderDescription: subCategoryHeaderDescription,
                    route: route
                )
                self.immersiveElements.append(multipleJackpotsSection)
                
                //show first widget games
                let isGamesPrefixed = games.count > horizontalScrollLimt
                let filteredGames = games.prefix(horizontalScrollLimt)
                games.removeAll()
                filteredGames.forEach { games.append($0) }
                let gamesSection = ImmersiveLobbySection(subCategoryId: jackpotId,
                                                         games: games,
                                                         layoutType: .multiJackpotWidgetGames,
                                                         isGamesPrefixed: isGamesPrefixed,
                                                         jackpotName: widgets.first?.jackpotName,
                                                         widgetLayoutType: layoutType)
                self.immersiveElements.append(gamesSection)
                if isHeaderAvailable { return false }
            }
        }
        
        return isHeaderAvailable
    }
    
    private func setupGameTeaserVideosDatasource(
        with subCategory: SubCategory,
        with position: Int = 2,
        isGamesPrefixed: Bool = false,
        subCategoryHeaderDescription: String?
    ) {
        if let route = subCategory.route?.lowercased(),
            !route.isEmpty,
            let nativeWidget = self.videoWidgets[route],
            let videoUrl = nativeWidget.imageOrVideoUrl {
            
            let immersiveTeaserVideosSection = ImmersiveLobbySection(
                subCategoryId: subCategory.subcategoryid,
                layoutType: .videoLayout,
                isGamesPrefixed: isGamesPrefixed,
                isHeaderAvailable: position == 0,
                subCategoryHeaderDescription: subCategoryHeaderDescription,
                route: route,
                videosTeasersSection: [nativeWidget]
            )
            self.immersiveElements.append(immersiveTeaserVideosSection)
        }
    }
    
    private func setupEmbeddBannerDatasource() {
        guard !self.isCategorySelected else { return }
        /// Banner configuration
        if let bannerConfig = self.bannerDynaconConfig,
           let bannerModel = self.bannerContentModel {
            var position = self.bannerPosition
            let immersiveBannerSection = ImmersiveLobbySection(layoutType: .embeddedBanner)
            if self.immersiveElements.count >= position {
                let gameItems = self.immersiveElements
                    .filter({$0.layoutType.isGamesSection})
                if gameItems.count > position {
                    let gameItem = gameItems[position]
                    if var updatedPosition = self.immersiveElements.firstIndex(where: {$0 == gameItem}) {
                        self.immersiveElements.insert(immersiveBannerSection, at: updatedPosition)
                        return
                    }
                } else {
                    if let gameItem = gameItems.last,
                        var updatedPosition = self.immersiveElements
                        .firstIndex(where: {$0 == gameItem}) {
                        self.immersiveElements
                            .insert(immersiveBannerSection, at: updatedPosition + 1)
                        return
                    }
                }
                if position != 0,
                   self.immersiveElements[position-1].layoutType.isJackpotWidget {
                    position += 1
                }
                self.immersiveElements.insert(immersiveBannerSection, at: position)
            } else {
                self.immersiveElements.append(immersiveBannerSection)
            }
        }
    }
    
    private func setupRecentlyPlayedGamesDatasource() {
        /// Recently Played games configuration.
        if let recentlyPlayedGames = self.datasource?.feedViewModel?.recentlyPlayedGames, !recentlyPlayedGames.isEmpty {
            let immersiveRecentlyPlayedSection = ImmersiveLobbySection(subCategoryId: kLmcRecentlyPlay,
                                                                       games: recentlyPlayedGames,
                                                                       layoutType: .recentlyPlayedGrid)
            self.immersiveElements.insert(immersiveRecentlyPlayedSection, at: 0)
        }
    }
    
    private func setupFavouriteGamesDatasource() {
        /// Favourite  games configuration.
        if let favouritesGames = self.datasource?.feedViewModel?.favouriteGames,
            !favouritesGames.isEmpty {
            let immersiveFavouriteSection = ImmersiveLobbySection(subCategoryId: kLmcFavourites,
                                                                  games: favouritesGames,
                                                                  layoutType: .favouriteGamesGrid)
            self.immersiveElements.insert(immersiveFavouriteSection, at: 0)
        }
    }
    
    private func setupBingoButtonDatasource() {
        let bingoSection = ImmersiveLobbySection(subCategoryId: kLmcBingoButton,
                                                 layoutType: .bingoButtonLayout,
                                                 bingoButtonLogo: ["open app"])
        self.immersiveElements.insert(bingoSection, at: 0)
    }
    
    private func setupNativeBingoWidgetDatasource() {
        if (odrAws?.bingoWidget?.enableBingoWidget ?? false), let gamesList = self.bingoLobbyModel?.result?.gamesList, !gamesList.isEmpty {
        let immersiveBingoSection =  ImmersiveLobbySection(bingoLobbyModel: bingoLobbyModel, layoutType: .bingoWidgetLayout)
            self.immersiveElements.insert(immersiveBingoSection, at: 0)
        }
    }
    
    private func setupTeasersDatasource() {
        ///  Teaser configuration.
        if !self.teasersContentModel.isEmpty {
            let immersiveTeaserSection =  ImmersiveLobbySection(layoutType: .teasers)
            self.immersiveElements.insert(immersiveTeaserSection, at: 0)
        }
    }
    
    
    //MARK: - Footer
    private func setupNativeFooterDatasource() {
        guard self.immersiveFooterElements.isEmpty else {
            self.immersiveElements.append(contentsOf: self.immersiveFooterElements)
            return
        }
        if let footerTypes: [NativeFooterContext.NativeFooterType] = EpcotLobbyManager.shared?.datasource?.nativeFooterTypes, !footerTypes.isEmpty {
            
            self.setupFooterDividerLineDatasource()

            for type in footerTypes {
                switch type {
                case .stateSelect:
                    self.setupFooterStateSwitcherDatasource()
                case .seolinks:
                    self.setUpFooterSEOLinksDataSource()
                case .aboutUs:
                    self.setUpFooterAboutUsDataSource()
                case .content:
                    self.setUpFooterContentDataSource()
                case .rgcontent:
                    break
                case .copyright:
                    self.setupFooterCopyRightDataSource()
                case .logos:
                    self.setUpFooterLogosDataSource()
                case .brandlogo:
                    self.setUpFooterBrandLogosDataSource()
                case .rigtOldlogos:
                    break
                }
            }
        }
        self.immersiveElements.append(contentsOf: self.immersiveFooterElements)
    }
    
    private func setupFooterDividerLineDatasource() {
        let footer = ImmersiveLobbySection(layoutType: .footerDividerLine)
        self.immersiveFooterElements.append(footer)
    }
    
    private func setupFooterStateSwitcherDatasource()  {
        let statesAvailable = EpcotLobbyManager.shared?.datasource?.didRequestforFooterStates().states
        if self.updateFooterStateSwitcherModel() || (statesAvailable != nil) {
            let footerStateChanger = ImmersiveLobbySection(layoutType: .footerStateswitcher)
            self.immersiveFooterElements.append(footerStateChanger)
        }
    }
    
    private func setUpFooterAboutUsDataSource() {
        if var aboutUsModels = POSAPI.shared?.footerAboutUs,
            !aboutUsModels.isEmpty  {
            let aboutUsHeaderData = aboutUsModels.removeFirst()
            
            let footerData = ImmersiveLobbySection(subCategoryId: aboutUsHeaderData.headerName,
                                                   layoutType: .footerAboutUs,
                                                   footerAboutUsItem: aboutUsModels)
            self.immersiveFooterElements.append(footerData)
        }
    }
    
    private func setUpFooterSEOLinksDataSource() {
        if let seoLinks = POSAPI.shared?.footerSeoLinks,
           !seoLinks.isEmpty  {
            seoLinks.forEach { seoItem in
                let headerTitle = seoItem.title
                if let seoSubCategories = seoItem.items {
                    let seoData = ImmersiveLobbySection(subCategoryId: headerTitle,
                                                        layoutType: .footerSeoLinks,
                                                        footerSeoLinks: seoSubCategories)
                    self.immersiveFooterElements.append(seoData)
                }
            }
        }
    }
    
    private func setUpFooterLogosDataSource() {
        if let footerLogoModels = POSAPI.shared?.footerLogos,
           !footerLogoModels.isEmpty  {
            let footerLogos = footerLogoModels.reduce(into: [FooterLogoContentModel]()) { result, item in
                var logo = item
                if item.isSizeCalculated == false {
                    logo.calculateLogoSize()
                }
                result.append(logo)
            }
            let footerData = ImmersiveLobbySection(layoutType: .footerMediaLogos,
                                                   footerMediaLogos: footerLogos)
            self.immersiveFooterElements.append(footerData)
        }
    }
    
    private func setUpFooterBrandLogosDataSource() {
        if var footerBrandLogo = POSAPI.shared?.footerBrandLogo {
            footerBrandLogo.calculateLogoSize()
            
            let footerData = ImmersiveLobbySection(layoutType: .footerBrandLogos,
                                                   footerBrandLogos: [footerBrandLogo])
            self.immersiveFooterElements.append(footerData)
        }
    }
    
    private func setUpFooterContentDataSource() {
        if let footerContentModel = POSAPI.shared?.footerContent {
            let footerContentData = ImmersiveLobbySection(layoutType: .footerTextContent,
                                                          footerContent: [footerContentModel])
            self.immersiveFooterElements.append(footerContentData)
        }
    }
    
    private func setupFooterCopyRightDataSource() {
        if let footerCopyRight = POSAPI.shared?.footerCopyRight {
            let footerContentData = ImmersiveLobbySection(layoutType: .footerCopyRight,
                                                          footerCopyRight: [footerCopyRight])
            self.immersiveFooterElements.append(footerContentData)
        }
    }
    
    private func setupFreeSpinsWidgetDataSource(
        with subCategory: SubCategory,
        isGamesPrefixed: Bool,
        isHeaderAvailable: Bool,
        subCategoryHeaderDescription: String?
    ) -> Bool {
        guard EntainContext.user?.isLoggedIn() ?? false else {
            return isHeaderAvailable
        }
        if let route = subCategory.route?.lowercased(),
           !route.isEmpty,
           let nativeWidget = self.freeSpinsWidgets[route] {
            let widgetSection = ImmersiveLobbySection(
                subCategoryId: route,
                layoutType: .freeSpinsWidget,
                isGamesPrefixed: isGamesPrefixed,
                freeSpinWidgets: nativeWidget,
                isHeaderAvailable: isHeaderAvailable,
                subCategoryHeaderDescription: subCategoryHeaderDescription,
                route: route,
                prominentFreeSpins: prominentFreeSpins,
                freeSpinsDetails: freeSpinsDetails
            )
            self.immersiveElements.append(widgetSection)
            if isHeaderAvailable { return false }
        }
        return isHeaderAvailable
    }
    
    // TODO: Engagement Tools - Assign the data store properties
    private func setupEngagementToolsDataSource(with subCategory: SubCategory) {
        guard EntainContext.user?.isLoggedIn() ?? false else {
            return
        }
        if let route = subCategory.route?.lowercased(),
           !route.isEmpty,
           let nativeWidget = self.engagementToolsWidgets[route] {
            let widgetSection = ImmersiveLobbySection(
                subCategoryId: route,
                layoutType: .engagementTools,
                engagementTools: nativeWidget,
                prominentFreeSpins: prominentFreeSpins,
                freeSpinsDetails: freeSpinsDetails,
                promoEngagementTools: promoEngagementTools
            )
            self.immersiveElements.append(widgetSection)
        }
    }
    
    private func setupPlayerWidgetDataSource(
        with subCategory: SubCategory,
        isGamesPrefixed: Bool,
        isHeaderAvailable: Bool,
        subCategoryHeaderDescription: String?
    ) -> Bool {
        guard EntainContext.user?.isLoggedIn() ?? false else {
            return isHeaderAvailable
        }
        
        let lastWeekGames = feedViewModel?.feedModel?.lobbyFeedObj?.weeklyStats
        let lastMonthGames = feedViewModel?.feedModel?.lobbyFeedObj?.monthlyStats
        
        if lastWeekGames?.count ?? 0 > 1 || lastMonthGames?.count ?? 0 > 1  {
            if let route = subCategory.route?.lowercased(),
               !route.isEmpty,
               let nativeWidget = self.playerStatsWidgets[route] {
                let widgetSection = ImmersiveLobbySection(
                    subCategoryId: route,
                    layoutType: .playerStatsWidget,
                    isGamesPrefixed: isGamesPrefixed,
                    playerStatsWidget: nativeWidget,
                    isHeaderAvailable: isHeaderAvailable,
                    subCategoryHeaderDescription: subCategoryHeaderDescription,
                    route: route
                )
                self.immersiveElements.append(widgetSection)
                if isHeaderAvailable { return false }
            }
        }
        return isHeaderAvailable
    }
    
    private func setupJackPotTilesDataSource(
        with subCategory: SubCategory,
        isGamesPrefixed: Bool,
        isHeaderAvailable: Bool,
        subCategoryHeaderDescription: String?
    ) -> Bool {

        if let route = subCategory.route?.lowercased(),
           !route.isEmpty,
           let jackpotTiles = self.updatedJackpotTiles {
            let layoutType: LayoutType = jackpotTiles.count == 1 ? .jackpotTileFullWidth : .jackpotTiles
            let section = ImmersiveLobbySection(
                subCategoryId: subCategory.subcategoryid,
                layoutType: layoutType,
                isGamesPrefixed: isGamesPrefixed,
                jackpotTiles: jackpotTiles.compactMap { JackPotModel(apiData: $0) },
                isHeaderAvailable: isHeaderAvailable,
                subCategoryHeaderDescription: subCategoryHeaderDescription,
                route: route
            )
            self.immersiveElements.append(section)
            if isHeaderAvailable { return false }
        }
        return isHeaderAvailable
    }
    
    private func createJackPotTilesDataSourceAsCategory() -> Bool {
        if self.showJackpotTileDetails.show,
           let model = self.showJackpotTileDetails.model,
           let jackpotGroupId = model.jackpotTile.groupId {
            //jackpot Tiles section
            let section = ImmersiveLobbySection(
                subCategoryId: "",
                layoutType: .jackpotTileFullWidth,
                jackpotTiles: [model],
                isHeaderAvailable: false
            )
            self.immersiveElements.append(section)
            
            //jackpot Tiles games section
            if let games = self.feedViewModel?.getJackpotIdBasedGames(for: jackpotGroupId) {
                let immersiveSection = ImmersiveLobbySection(subCategoryId: "",
                                                             games: games,
                                                             layoutType: .verticalImmersiveGrid,
                                                             isGamesPrefixed: false,
                                                             isHeaderAvailable: false,
                                                             //to reduce top spacing sending this var as true
                                                             isFromSearchController: true,
                                                             subCategoryHeaderDescription:"",
                                                             route: "")
                self.immersiveElements.append(immersiveSection)
            }
            return true
        }
        return false
    }
    
    private func setupOriginalsWidgetDataSource(with subCategory: SubCategory,
                                                isGamesPrefixed: Bool,
                                                isHeaderAvailable: Bool,
                                                subCategoryHeaderDescription: String?) -> Bool {
        
        guard !(self.delegate?.didOriginalWidgetExpired() ?? false) else {
            return isHeaderAvailable
        }
        guard EntainContext.user?.isLoggedIn() ?? false else {
            return isHeaderAvailable
        }
        
        if EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .originalsWidgetView) ?? false,
           let route = subCategory.route?.lowercased(),!route.isEmpty,
           let nativeWidget = self.originalsWidget[route],
           let model = POSAPI.shared?.originalsWidgetConfigurations {
            if let linkedCategory = subCategory.linkedCategory,
                !linkedCategory.isEmpty {
                model.updateLinkedCategory(with: linkedCategory)
            }
            if let base = DynaconAPIConfiguration.shared?.posAppConfig?.portal?.promoBaseUrl {
                model.updatePromoUrl(with: base)
            }
            let widgetSection = ImmersiveLobbySection(
                subCategoryId: subCategory.subcategoryid,
                layoutType: .originalsWidget,
                isGamesPrefixed: isGamesPrefixed,
                originalsWidget: (model: model, showInCategory: false), // show in lobby home
                isHeaderAvailable: isHeaderAvailable,
                subCategoryHeaderDescription: subCategoryHeaderDescription,
                route: route
            )
            self.immersiveElements.append(widgetSection)
            if isHeaderAvailable { return false }
        }
        return isHeaderAvailable
    }
    
    private func createOriginalsWidgetInCategoryPage() {
        
        guard !(self.delegate?.didOriginalWidgetExpired() ?? false) else {
            return
        }
        
        guard EntainContext.user?.isLoggedIn() ?? false else {
            return
        }
        
        if EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .originalsWidgetView) ?? false,
           let model = POSAPI.shared?.originalsWidgetConfigurations {
            let widgetSection = ImmersiveLobbySection(
                subCategoryId: "",
                layoutType: .originalsWidget,
                originalsWidget: (model: model, showInCategory: true), // show this in category
                isHeaderAvailable: false
            )
            self.immersiveElements.append(widgetSection)
        }
    }
    
    //MARK: -
    private func createLoaderDataSource() {
        DispatchQueue.main.async {
            self.snapShot?.deleteAllItems()
            if let snapShot = self.snapShot {
                self.diffDatasource?.apply(self.snapShot ?? snapShot)
            }
            let teasersSection = ImmersiveLobbySection(layoutType: .teasers)
            let horizontalImmersiveSection = ImmersiveLobbySection(layoutType: .horizontalImmersiveGrid)
            let immersiveSection = ImmersiveLobbySection(layoutType: .verticalImmersiveGrid)
            let gridSection = ImmersiveLobbySection(layoutType: .verticalGrid)
            let horizontalGridSection = ImmersiveLobbySection(layoutType: .horizontalGrid)
            let listSection = ImmersiveLobbySection(layoutType: .list)
            let bannerSection = ImmersiveLobbySection(layoutType: .embeddedBanner)
            self.immersiveElements = [teasersSection,horizontalImmersiveSection,horizontalGridSection,bannerSection,immersiveSection,gridSection,listSection]
            self.snapShot?.appendSections(self.immersiveElements)
            self.snapShot?.sectionIdentifiers.forEach({ section in
                let loadingItems = self.snapShot?.appendItems(Item.loadingItems(), toSection: section)
            })
            guard let snapshot = self.snapShot else { return }
            self.diffDatasource?.apply(self.snapShot ?? snapshot)
        }
    }
    
    func startJackpotTimer() {
        guard  self.jackpotTimer == nil else { return }
        let randomInterval = Double.random(in: 1...6)
        self.jackpotTimer =  DispatchTimer(interval: randomInterval, handler: self.refreshJackpot)
    }
    
    func startJackpotScrollTimer() {
        guard EpcotLobbyManager.shared?.datasource?.isJackpotAutoScrollEnabled ?? false else { return }
        guard  self.jackpotScrollTimer == nil else { return }
        self.jackpotScrollTimer =  DispatchTimer(interval: 5.0, handler: self.updateIndexofJackpotWidget)
    }
    
    func stopJackpotTimer() {
        guard self.jackpotTimer != nil else { return }
        self.jackpotTimer?.cancel()
        self.jackpotTimer = nil
    }
    
    func stopJackpotWidgetScrollTimer() {
        guard self.jackpotScrollTimer != nil else { return }
        self.jackpotScrollTimer?.cancel()
        self.jackpotScrollTimer = nil
    }
    
    private func refreshJackpot() {
        self.stopJackpotTimer()
        ///counter jackpot time update
        self.jackpotInfoSubject.send(nil)
        self.startJackpotTimer()
    }
    
    private func updateIndexofJackpotWidget() {
        DispatchQueue.main.async {[weak self] in
            guard let self = self else { return }
            guard let jackpotSection = self.snapShot?.sectionIdentifiers.first(where: {$0.layoutType == .multipleJackpotWidget}) else { return }
            guard let section = self.immersiveElements.firstIndex(where: {$0.layoutType == .multipleJackpotWidget}) else { return }
            guard self.collectionView != nil else { return }
            guard self.collectionView.indexPathsForVisibleItems.contains(where: {$0.section == section}) else { return }
            var currentJackpotIndex = self.multipleJackpotsCurrentIndexPath.item
            currentJackpotIndex += 1
            if currentJackpotIndex == self.snapShot?.numberOfItems(inSection: jackpotSection) ?? 0 {
                currentJackpotIndex = 0
            }
            let indexPathToScroll = IndexPath(item: currentJackpotIndex, section: section)
            self.collectionView.scrollToItem(at: indexPathToScroll,
                                             at: .centeredHorizontally,
                                             animated: currentJackpotIndex != 0)
        }
    }
    
    private func updateGamesForMultipleJackpotWidget(with indexPath: IndexPath) {
        guard indexPath.row >= 0 else { return }
        guard self.immersiveElements.count > indexPath.section else { return }
        let immersiveElementsSection = indexPath.section
        let jackpotGamesSection = immersiveElementsSection + 1
        guard let widget = immersiveElements[immersiveElementsSection].jackpotWidget?[indexPath.row] else { return }
        guard var games = self.feedViewModel?.getJackpotBasedGames(for: widget.routeValue), !games.isEmpty else { return }
        guard var snapShot = self.diffDatasource?.snapshot() else { return }
        snapShot.deleteSections([self.immersiveElements[jackpotGamesSection]])
        self.immersiveElements.remove(at: jackpotGamesSection)
        let limit = horizontalScrollLimt
        let isGamesPrefixed = games.count > limit
        games = Array(games.prefix(limit))
        let immersiveGamesSection = ImmersiveLobbySection(subCategoryId: widget.routeValue,
                                                          games: games,
                                                          layoutType: .multiJackpotWidgetGames,
                                                          isGamesPrefixed: isGamesPrefixed,
                                                          jackpotName: widget.jackpotName,
                                                          widgetLayoutType: .multipleJackpotWidget)
        self.immersiveElements.insert(immersiveGamesSection, at: jackpotGamesSection)
        
        let snapShotMultipleJackpotsSection = snapShot.sectionIdentifiers[immersiveElementsSection]
        snapShot.insertSections([immersiveGamesSection], afterSection: snapShotMultipleJackpotsSection)
        snapShot.appendItems(games.map({Item.rpGames(JackpotWidgetGameModel(game: $0, isJackpotWidgetGame: true))}), toSection: immersiveGamesSection)
        snapShot.reloadSections([immersiveGamesSection])
        DispatchQueue.main.async {
            self.diffDatasource?.apply(snapShot, animatingDifferences: false,completion: {[weak self] in
                self?.startJackpotTimer()
                self?.startJackpotScrollTimer()
            })
        }
    }
}
extension ImmersiveLobbyCollectionViewController: UICollectionViewDataSourcePrefetching {
    
    // MARK: UICollectionViewDataSourcePrefetching
    func collectionView(_ collectionView: UICollectionView, prefetchItemsAt indexPaths: [IndexPath]) {
        var urlsArray = [URL]()
        for indexPath in indexPaths {
            let section = indexPath.section
            let item = indexPath.row
            if self.immersiveElements.count > section,
               let games = self.immersiveElements[section].games,
               games.count > item {
                let game = games[item].game
                let iconSize = self.immersiveElements[section].layoutType.rawValue
                
                if let gameVariant = game,
                   let immersiveInfo = self.datasource?.feedViewModel?.getImmersiveInfo(for: gameVariant, with: "\(iconSize)") {
                    let imagePath = immersiveInfo.imagePath
                    if let url = URL(string: imagePath) {
                        urlsArray.append(url)
                    }
                }
            }
        }
        self.prefetcher = ImagePrefetcher(urls: urlsArray)
        self.prefetcher?.start()
    }
    
    func collectionView(_ collectionView: UICollectionView, cancelPrefetchingForItemsAt indexPaths: [IndexPath]) {
        self.prefetcher?.stop()
    }
}

extension ImmersiveLobbyCollectionViewController {
    
    override func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if !UIDevice.isIPad() {
            if let videoCell = cell as? TeaserVideosCustomCell {
                self.previousVideoCell == nil
                videoCell.playVideo()
            }
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if !UIDevice.isIPad() {
            if let videoCell = cell as? TeaserVideosCustomCell {
                videoCell.pauseVideo()
            }
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let item = diffDatasource?.itemIdentifier(for: indexPath) else { return }
        switch item {
            /// loading the game based on the game variant name.
        case .game(let game, let _) :
            guard let selectedGame = game.game else { return }
            if let cell = collectionView.cellForItem(at: indexPath) {
                let instantInteraction = InteractionType.opacity.interaction
                cell.tapAnimation(type: instantInteraction) { [weak self] in
                    guard let self else { return }
            
                    var additionalParams = self.setAdditionalParameters(indexpath: indexPath)
                    additionalParams.location = GameSection.search.name
                    if self.isKind(of: EpcotSearchResultViewController.self) {
                        self.onClickGameplay?(selectedGame, additionalParams)
                       
                    } else {
                        var subCategoryName = ""
                        if self.immersiveElements.count > indexPath.section,
                            let subCategoryId = self.immersiveElements[indexPath.section].subCategoryId {
                            if let name = self.datasource?.feedViewModel?.getCategoryName(for: subCategoryId, isSubCategory: true) {
                                subCategoryName = name
                            }
                        }
                        
                        var additionalParams = self.setAdditionalParameters(indexpath: indexPath)
                        additionalParams.subCategoryID = subCategoryName
                        additionalParams.location = GameSection.lobby.name

                        self.onClickGameplay?(selectedGame, additionalParams)
                    }
                }
            }
        case .rpGames(let model) :
            guard let selectedGame = model.game.game else { return }
            if let cell = collectionView.cellForItem(at: indexPath) {
                let instantInteraction = InteractionType.overLay40.interaction
                cell.tapAnimation(type: instantInteraction) {
                    
                    var additionalParams = self.setAdditionalParameters(indexpath: indexPath)
                    additionalParams.location = GameSection.search.name
                    self.onClickGameplay?(selectedGame, additionalParams)
                }
            }
            /// sending the selected teaser to Application for showing the web view and type as teaser.
        case .teasers(let teaser, let _) :
            guard self.collectionView != nil, let cell = self.collectionView.cellForItem(at: indexPath) else { return }
            let instantInteraction = InteractionType.overLay40.interaction
            cell.tapAnimation(type: instantInteraction) {
                EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .teasers(teaser),
                                                                    buttonType: .teaser)
            }
            self.trackEvent(bannerName: teaser.title ?? "",
                            index: indexPath.row,
                            cta: teaser.ctaTitle ?? teaser.ctaLink ?? "")
            if let cell = cell as? EpcotBannerVideoCell {
                cell.pauseVideo()
                NSObject.cancelPreviousPerformRequests(withTarget: self,
                                                       selector: #selector(self.startScrollAnimation),
                                                       object: nil)
            }
            /// sending the selected teaser to Application for showing the web view and type as banner.
        case .banner(let banner):
            guard self.collectionView != nil,let cell = self.collectionView.cellForItem(at: indexPath) else { return }
            let instantInteraction = InteractionType.overLay40.interaction
            cell.tapAnimation(type: instantInteraction) {
                EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .teasers(banner),
                                                                    buttonType: .teaser)
            }
            self.trackEvent(bannerName: banner.title ?? "",
                            index: indexPath.row,
                            cta: banner.ctaTitle ?? banner.ctaLink ?? "",
                            isEmbeddBanner: true)
        case .mustGoJackpot(let model, let _), .singleJackpot(let model, let _):
            var subCategoryName = ""
            if let subCategoryId =
                self.immersiveElements[indexPath.section-1].subCategoryId {
                if let name = self.datasource?.feedViewModel?.getCategoryName(for: subCategoryId, isSubCategory: true) {
                    subCategoryName = name
                }
            }
            self.trackJackpotWidgetsEvent(jackpotName: model.jackpotName, jackpotSectionTitle: subCategoryName)
        case .aboutUs(let model):
            guard self.collectionView != nil, let cell = self.collectionView.cellForItem(at: indexPath) as? NativeFooterBaseCell else { return }
            let instantInteraction = InteractionType.opacity.interaction
            cell.tapAnimation(type: instantInteraction) {
                let aboutUsModel = cell.contentModel
                let footerItem = NativeFooterItem(type: .aboutUs,
                                                  referenceLink:aboutUsModel?.referenceLink,
                                                  nativeActionCategory: aboutUsModel?.nativeActionCategory)
                EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .footer(footerItem),
                                                                    buttonType: nil)
            }
        case .footerSeoLinks(let model):
            guard self.collectionView != nil, let cell = self.collectionView.cellForItem(at: indexPath) as? NativeFooterBaseCell else { return }
            let instantInteraction = InteractionType.opacity.interaction
            cell.tapAnimation(type: instantInteraction) {
                let seoModel = cell.seoModel
                let footerItem = NativeFooterItem(type: .seolinks,
                                                  referenceLink:seoModel?.referenceLink,
                                                  nativeActionCategory: seoModel?.nativeActionCategory)
                EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .footer(footerItem),
                                                                    buttonType: nil)
            }
        case .footerMediaLogo(let model):
            guard self.collectionView != nil, let cell = self.collectionView.cellForItem(at: indexPath) as? NativeFooterLogoCell else { return }
            let instantInteraction = InteractionType.opacity.interaction
            cell.tapAnimation(type: instantInteraction) {
                let seoModel = cell.contentModel
                let footerItem = NativeFooterItem(type: .logos,
                                                  referenceLink:seoModel?.referenceLink,
                                                  nativeActionCategory: seoModel?.nativeActionCategory)
                EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .footer(footerItem),
                                                                    buttonType: nil)
            }
        case .bingoButtonItem(let brandLogo):
            if let cell = collectionView.cellForItem(at: indexPath) {
                cell.tapAnimation {
                    EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .bingoItem(brandLogo),
                                                                        buttonType: nil)
                }
            }
        case .teaserVideos(let model, _):
            if let cell = collectionView.cellForItem(at: indexPath) as? TeaserVideosCustomCell {
                if let launchUrl = model.videoLaunchUrl {
                    cell.tapAnimation {
                        cell.pauseVideo()
                        EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .teaserVideos(launchUrl), buttonType: nil)
                    }
                }
            }
        case .jackpotTiles(let model, _):
           
            guard !(model.games?.isEmpty ?? true) else { return }
            if !self.showJackpotTileDetails.show {
                JackpotTileTracking().trackEvent(type: .click(tileName: model.titleText, index: "\(indexPath.item)"))
                self.showJackpotTileDetails = (true, model)
                self.onClickJackpotTile?(model)
            }
        case .originalsWidget(let model, let showInCategory):
            if !showInCategory {
                if let categoryId = POSAPI.shared?.originalsWidgetConfigurations?.linkedCategory, !categoryId.isEmpty {
                    self.onClickLinkedCategory?(categoryId)
                }
            }
        default: break
        }
    }
    
    // MARK: set additional params
    func setAdditionalParameters(indexpath: IndexPath) -> AdditionalParameters{
        var additionalParams = AdditionalParameters()
        var subCategoryID = ""
        var itemsPerRow = 0
        var row = 0
        var column = 0
        var positionCount = 0
        var iconSize = 0
        if immersiveElements.count > indexpath.section {
            iconSize = self.immersiveElements[indexpath.section].layoutType.rawValue
        }
        switch iconSize {
        case 1:
            itemsPerRow = UIDevice.isIPad() ? kColumnsIpad : kColumnsPortraitIphone
        case 2:
            itemsPerRow = UIDevice.isIPad() ? kColumnsPortrait : 1
        case 4:
            itemsPerRow =  UIDevice.isIPad() ? kColumnsPortraitIpad : UIDevice.current.orientation.isLandscape ? kColumnsLandscape : kColumnsPortrait
        default:
            itemsPerRow = 1
        }
        
        if iconSize == 3 {
            row = 0
            column = indexpath.item
            positionCount = (indexpath.item + 1)
        } else {
            row = (indexpath.item / itemsPerRow)
            column = (indexpath.item % itemsPerRow)
            positionCount = ((row * itemsPerRow) + column + 1)
        }
        
        additionalParams = AdditionalParameters(categoryID: self.selectedCategory ?? kGlobalSearch, subCategoryID: subCategoryID, row: row + 1, column: column + 1, positionCount: positionCount, iconSize: iconSize)
        
        return additionalParams
    }
}

extension ImmersiveLobbyCollectionViewController {
    
    ///Method to update favourite state for game
    func updateGameFavouriteState(cell: Any ,game: String, state: Bool) {
        guard let isLoggedIn = EntainContext.user?.isLoggedIn(), isLoggedIn else { return }
        Task {
            let favouriteState = try await self.feedViewModel?.updateFavouriteState(with: state, for: game)
            let favState = favouriteState ?? (state ? .unselected : .selected)
            self.updateFavouriteState(state: favState, cell: cell, gameVariant: game)
            if state == favState.boolValue {
                if self.isFavGamesSectionShown {
                    let isFavGamesAvailableAfter = self.feedViewModel?.favouriteGames?.isEmpty ?? false
                    if !self.isCategorySelected  {
                        if let favSection = self.snapShot?.sectionIdentifiers.first(where: {$0.layoutType == .favouriteGamesGrid}) {
                            if state {
                                self.insertFavouriteItem(with: game,
                                                         in: favSection)
                            } else {
                                if isFavGamesAvailableAfter {
                                    self.deleteFavouriteSection(isScrollToTopNeeded: false)
                                } else {
                                    self.deleteFavouriteItem(with: game,
                                                             from: favSection)
                                }
                            }
                            return
                        } else {
                            state == true ? self.insertFavouriteSection() : self.deleteFavouriteSection()
                            return
                        }
                    } else if self.selectedCategory == kLmcFavourites {
                        self.deleteFavouriteItem(with: game,
                                                 from: self.snapShot?.sectionIdentifiers.first)
                    }
                }
            }
        }
    }
    
    private func deleteFavouriteItem(with game: String, from section: ImmersiveLobbySection?) {
        if let section = section, let items = self.snapShot?.itemIdentifiers(inSection: section) {
            if let deletedItem = items.first(where: { item in
                if case let .rpGames(gameObject) = item {
                    if let gameObject = gameObject as? Game {
                        return gameObject.game == game
                    }
                }
                return false
            }) {
                self.snapShot?.deleteItems([deletedItem])
                guard var snapShot = self.snapShot else { return }
                self.diffDatasource?.apply(self.snapShot ?? snapShot, animatingDifferences: true)
            }
        }
    }
    
    private func insertFavouriteItem(with game: String, in section: ImmersiveLobbySection?) {
        if let section = section,
            let item = self.snapShot?.itemIdentifiers(inSection: section).last {
            self.snapShot?.insertItems([Game(game: game)].map({Item.rpGames(JackpotWidgetGameModel(game: $0, isJackpotWidgetGame: true))}), afterItem: item)
        }
        guard var snapShot = self.snapShot else { return }
        self.diffDatasource?.apply(self.snapShot ?? snapShot, animatingDifferences: true)
    }
    
    private func deleteFavouriteSection(isScrollToTopNeeded: Bool = true) {
        if let favSection = self.snapShot?.sectionIdentifiers.first(where: {$0.layoutType == .favouriteGamesGrid}) {
            self.snapShot?.deleteSections([favSection])
            self.immersiveElements.removeAll(where: {$0.layoutType == .favouriteGamesGrid})
            guard var snapShot = self.snapShot else { return }
            self.diffDatasource?.apply(snapShot, animatingDifferences: true,completion: {
                if isScrollToTopNeeded {
                    self.collectionView.setContentOffset(kCollectionViewOffSet, animated: false)
                }
            })
        }
    }
    
    private func insertFavouriteSection() {
        func insertBeforeFirstSubCategorySection() {
            if let selectedCategory = self.selectedCategory,
               let firstSubCategory = self.feedViewModel?.getSubCategories(for: selectedCategory)?.first?.subcategoryid,
               let section = self.snapShot?.sectionIdentifiers.first(where: {$0.subCategoryId == firstSubCategory}),
                let favGames = self.feedViewModel?.favouriteGames {
                let immersiveFavouriteSection = ImmersiveLobbySection(subCategoryId: kLmcFavourites,
                                                                      games: favGames,
                                                                           layoutType: .favouriteGamesGrid)
                self.snapShot?.insertSections([immersiveFavouriteSection], beforeSection: section)
                if let favSection = self.snapShot?.sectionIdentifiers.first(where: {$0.layoutType == .favouriteGamesGrid}) {
                    self.snapShot?.appendItems(favGames.map({Item.rpGames(JackpotWidgetGameModel(game: $0))}),toSection: favSection)
                }
                if let index = self.immersiveElements.firstIndex(where: {$0.subCategoryId == firstSubCategory}) {
                    self.immersiveElements.insert(immersiveFavouriteSection, at: index)
                }
            }
        }
        
        if let layoutPrioritySection = EpcotLobbyManager.shared?.datasource?.layoutOrder?.last, layoutPrioritySection == .favouriteGames {
            insertBeforeFirstSubCategorySection()
        } else {
            self.applySnapshot(with: self.selectedCategory,for: true)
        }
        guard var snapShot = self.snapShot else { return }
        self.diffDatasource?.apply(self.snapShot ?? snapShot, animatingDifferences: true)
    }
}
//MARK: - Fetching of the Teasers and embedd Banners.
extension ImmersiveLobbyCollectionViewController {
    /// Method will fetch the teasers.
    private func fetchTeasers() {
        Task {
            do {
                let (teasers, banner, global) = try await SiteCoreTeasersViewModel().fetchSiteCoreDataContent()
                self.globalTeaser = global
                if let teasers = teasers {
                    self.teasersContentModel = teasers
                }
                if let banner = banner {
                    self.bannerContentModel = banner
                }
                DispatchQueue.main.async {[weak self] in
                    guard let self = self else { return }
                    self.applySnapshot(for: true)
                }
            } catch {
                ETLogger.debug(error.localizedDescription)
            }
        }
    }
    
    private func getBingoLobbyData() {
        guard let route = DynaconAPIConfiguration.shared?.posAppConfig?.services?.bingoWidgetRoute else { return }
        let bingoRouter = BingoLobbyService(route: route)
        Task {
            do {
                let model = try await bingoRouter.fetchBingoLobbyResponse().get()
                if let bingoModel = model as? BingoLobbyModel {
                    self.bingoLobbyModel = bingoModel
                }
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.applySnapshot(for: true)
                }
            } catch {
                ETLogger.debug(error.localizedDescription)
            }
        }
    }
 
    private func updateFavouriteState(state: FavouriteState, cell: Any, gameVariant: String) {
        DispatchQueue.main.async {
            if let collectionCell = cell as? EpcotGameCollectionViewCell {
                collectionCell.isFavouriteGame = state
            } else if let listCell = cell as? GamesListViewCell {
                listCell.isFavouriteGame = state
            } else if let portraitCell = cell as? PortraitSectionCollectionViewCell {
                portraitCell.isFavouriteGame = state
            }
        }
        self.delegate?.didUpdateFavourite(gameVariant: gameVariant, state: state, from: false)
    }
    
    private func updateTeaserVideoCellWithCarouselTimer() {
        guard self.teasersContentModel.count > teaserCurrentIndex else { return }
        if let activeTeaserVideoUrl {
            if let cell = collectionView.cellForItem(at: IndexPath(item: teaserCurrentIndex, section: 0)) as? EpcotBannerVideoCell {
                previousVideoCell = cell
            }
        } else {
            if previousVideoCell != nil {
                previousVideoCell = nil
            }
        }
        self.teasersContentModel.enumerated().forEach { index, teaser in
            if index == teaserCurrentIndex, let url = teaser.attributes?.teaserVideoUrl?.url {
                self.teaserVideoInfoSubject.send((index,url))
            } else {
                self.teaserVideoInfoSubject.send((index,nil))
            }
        }
        self.startScrollTimerForVideoTeaser()
    }
}

// MARK: Fetching Prominent Free Spins
extension ImmersiveLobbyCollectionViewController {
    func fetchProminentFreeSpins() {
        let posAppConfig = DynaconAPIConfiguration.shared?.posAppConfig
        let freeSpinsConfig = posAppConfig?.odrAws?.prominentFreeSpinsConfig
        let showProminentFreeSpins = freeSpinsConfig?.enableProminentFreeSpinsDisplay ?? false

        guard showProminentFreeSpins, let endPoint = posAppConfig?.services?.prominentFreeSpinsEndPoint else {
            ETLogger.debug("Unable to find the Free Spins End Points!")
            return
        }

        let freeSpinsSummaryService = ProminentFreeSpinsService(
            endPoint: endPoint,
            requestType: .freeSpinsSummary
        )
        let freeSpinsDetailsService = ProminentFreeSpinsService(
            endPoint: endPoint,
            requestType: .rewardDetails
        )

        Task {
            do {
                // Fetching data from Free Spins Summary API
                let freeSpinsModel = try await freeSpinsSummaryService.fetchProminentFreeSpins().get()
                guard let freeSpins = freeSpinsModel as? ProminentFreeSpins else {
                    ETLogger.debug("Free Spins model parsing is failed!")
                    return
                }
                self.prominentFreeSpins = freeSpins
                ETLogger.debug(freeSpins)
                
                // Parse free spins IDs from Summary API
                var rewardIDs = [Int]()
                guard let gameDetails = freeSpins.gameDetails?.values else {
                    ETLogger.debug("No Free Spins game details found!")
                    return
                }
                gameDetails.forEach {
                    let ids = $0.rewardIDS ?? []
                    rewardIDs.append(contentsOf: ids)
                }
                
                if rewardIDs.isEmpty {
                    ETLogger.debug("No Free Spins IDs found!")
                    return
                }

                // Fetching data from Free Spins Details API
                let freeSpinsDetailsModel = try await freeSpinsDetailsService.fetchProminentFreeSpins(rewardIDs: rewardIDs).get()
                guard let freeSpinsDetails = freeSpinsDetailsModel as? ProminentFreeSpinDetails else {
                    ETLogger.debug("Free Spins model parsing is failed!")
                    return
                }
                self.freeSpinsDetails = freeSpinsDetails
                ETLogger.debug(freeSpinsDetails)

                DispatchQueue.main.async {[weak self] in
                    guard let self = self else { return }
                    self.applySnapshot(for: true)
                }
            } catch {
                ETLogger.debug(error.localizedDescription)
            }
        }
    }
}

// MARK: Fetching Promo Engagement Tools
extension ImmersiveLobbyCollectionViewController {
    func fetchPromoEngagementTools() {
        
        let posAppConfig = DynaconAPIConfiguration.shared?.posAppConfig
        let engagementToolsConfig = posAppConfig?.odrAws?.engagementToolsConfig
        let enablePromoEngagementTools = engagementToolsConfig?.enablePromoEngagementTools ?? false

        guard enablePromoEngagementTools, let endPoints = posAppConfig?.services?.promoEngagementToolsEndPoints else {
            ETLogger.debug("Unable to find the Promo Engagement Tools End Points!")
            return
        }

        let service = PromoEngagementToolsService()

        Task {
            do {
                // Fetching data from Promo Enagement Tools API
                let spinTheWheelTools = try await service.getAllPromoEngagementTools(
                    path: endPoints.allItems,
                    for:  endPoints.spinTheWheel
                )
                self.promoEngagementTools[.spinTheWheel] = spinTheWheelTools
                ETLogger.debug(promoEngagementTools)

                DispatchQueue.main.async {[weak self] in
                    guard let self = self else { return }
                    self.applySnapshot(for: true)
                }
            } catch {
                ETLogger.debug(error.localizedDescription)
            }
        }
    }
}

//MARK: - EpcotBannerCollectionViewCellDelegate method implementations.
extension ImmersiveLobbyCollectionViewController: EpcotBaseCollectionViewCellDelegate {
    

}

extension ImmersiveLobbyCollectionViewController: EpcotVideoBannerDelegate {
    func didUpdateVideoDuration(duration: Double, urlString: String?) {
        if !UIDevice.isIPad() {
            if let urlString {
                self.videoDurations[urlString] = duration
            }
        }
    }
    
    func didTapOnPlayButton(videoCell: EpcotBannerVideoCell) {
        DispatchQueue.main.async {
            self.netflixVideoPlayStatusInfoSubject.send(false)
            if self.previousVideoCell != nil {
                if self.previousVideoCell == videoCell {
                    self.previousVideoCell?.reloadVideoPlayer()
                    return
                } else {
                    self.previousVideoCell?.pauseVideo()
                }
            }
            self.previousVideoCell = videoCell
            guard let videoUrlStr = videoCell.teaserInfo?.attributes?.teaserVideoUrl, let teaserVideoUrl = videoUrlStr.url else { return }
            
            self.previousVideoCell?.playTeaserVideo(videoUrl: teaserVideoUrl)
        }
    }
}

extension ImmersiveLobbyCollectionViewController: TeaserVideosCustomCellDelegate {
        
    func didTapOnPlayButton(videoCell: TeaserVideosCustomCell) {
        DispatchQueue.main.async {
            self.teaserVideoInfoSubject.send((self.teaserCurrentIndex, nil))
            self.previousVideoCell = nil
        }
    }
}

//MARK: - EpcotBannerCollectionViewCellDelegate method implementations.
extension ImmersiveLobbyCollectionViewController: EpcotBannerCollectionViewCellDelegate {
    
    /// Method will send the selected cell to application's web view.
    /// - Parameters:
    ///   - cell: cell
    ///   - type: teaser button type (teaser, terms, cta).
    func didTapped(on cell: EpcotBaseCollectionViewCell, type: TeaserButtonType) {
        guard self.collectionView != nil, let indexPath = self.collectionView.indexPath(for: cell) else { return }
        if cell.isKind(of: EpcotEmbeddedBannerCollectionViewCell.self) {
            if let banner =  self.bannerContentModel {
                EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .teasers(banner), buttonType: type)
                let cta = type == .terms ? (banner.ctaLink ?? "") : (banner.ctaTitle ?? "")
                self.trackEvent(bannerName: banner.title ?? "",
                                index: indexPath.row,
                                cta: cta,
                                isEmbeddBanner: true)
            }
        } else {
            guard self.teasersContentModel.count > indexPath.row else { return }
            let teaser = self.teasersContentModel[indexPath.row]
            EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .teasers(teaser), buttonType: type)
            let cta = type == .terms ? (teaser.ctaLink ?? "") : (teaser.ctaTitle ?? "")
            self.trackEvent(bannerName: teaser.title ?? "",
                            index: indexPath.row,
                            cta: cta)
        }
    }
    
    /// it will invalidate the timer.
    func stopCarouselTimer() {
        NSObject.cancelPreviousPerformRequests(withTarget: self,
                                               selector: #selector(self.startScrollAnimation),
                                               object: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            self.setupCarouselTimer()
        }
    }
}

extension ImmersiveLobbyCollectionViewController: EpcotSectionHeaderDelegate {
    func didTapOnHeaderElement(of type: SectionHeaderElementType) {
        switch type {
        case .seeMore(let subCategoryId):
            self.didTapOnSeeMoreSection(with: subCategoryId)
        case .info(let subCategoryId, let route):
            self.didTaponInfoView(with: subCategoryId, route: route)
        }
    }
    /// See more section view controller will be displayed on button action of see more.
    /// - Parameter subCategoryId: subCategory ID for which the games will be shown.
    private func didTapOnSeeMoreSection(with subCategoryId: String?) {
        if let category = self.selectedCategory, let subCategoryId = subCategoryId, let subCategory = self.feedViewModel?.getSubCategory(for: subCategoryId, in: category) {
            if let linkedCategory = subCategory.linkedCategory,
               !linkedCategory.isEmpty, self.feedViewModel?.categoryIds?.contains(linkedCategory) ?? false {
                self.onClickLinkedCategory?(linkedCategory)
            } else {
                if isEpcotEnabled {
                    self.onClickSubCategorySeeMore?(category, subCategoryId)
                } else {
                    if let games = self.datasource?.feedViewModel?.getSubCategoryGames(for: subCategoryId, in: category) {
                        let name = self.datasource?.feedViewModel?.getCategoryName(for: subCategoryId, isSubCategory: true)
                        self.seeMoreController = SeeMoreSectionViewController.show(subCatgoryName: name,
                                                                                   with: games,
                                                                                   dataSource: self,
                                                                                   on: self)
                        self.seeMoreController?.onClickedGamePlay = { (selectedGame, additionalParams) in
                            self.onClickGameplay?(selectedGame, additionalParams)
                        }
                        self.seeMoreController?.delegate = self
                    }
                }
            }
        } else if let subCategoryId = subCategoryId, let games = self.feedViewModel?.getJackpotBasedGames(for: subCategoryId) {
            let subCategoryName = self.immersiveElements.first(where: {$0.subCategoryId == subCategoryId})?.jackpotName ?? Localize.qualifyingGames
            self.seeMoreController = SeeMoreSectionViewController.show(subCatgoryName: subCategoryName,
                                                                       with: games,
                                                                       dataSource: self,
                                                                       isJackpotWidget: true,
                                                                       on: self)
            self.seeMoreController?.onClickedGamePlay = { (selectedGame, additionalParams) in
                let name = self.datasource?.feedViewModel?.getCategoryName(for: additionalParams?.subCategoryID ?? "") ?? ""
                self.onClickGameplay?(selectedGame, additionalParams)
            }
            self.seeMoreController?.delegate = self
        }
    }
    
    private func didTaponInfoView(with subCategoryId: String?, route: String?) {
        
        func closeInfoView(completion: (() -> Void)? = nil) {
            let presenter = AlertPresenter(vc: self.jackpotFusionInfoView ?? UIViewController())
            AlertCoordinator.removeView(presenter, completion: completion)
        }
        
        guard let subCategoryId,
              let title = self.datasource?.feedViewModel?.getCategoryName(for: subCategoryId, isSubCategory: true),
              let route,
              let content = self.jackpotFusion[route]?.jackpotInfo else {
            return
        }
        let badge = self.jackpotFusion[route]?.jackpotBadgeStatus
        jackpotFusionInfoView = UIHostingController.init(rootView: JackpotFusionInfoView(jackpotFusionInfoModel: JackpotFusionInfoModel(title: title, content: content,badge: badge, isSeeAllAvailable: true), closeAction: { closeInfoView()
        },seeAllGamesAction: {
            closeInfoView {
                self.didTapOnSeeMoreSection(with: subCategoryId)
            }
        }))
        guard let topVC = EpcotLobbyManager.shared?.delegate?.lobbyViewController ?? UIApplication.shared.keyWindow?.rootViewController else { return }
        jackpotFusionInfoView?.view.frame = topVC.view.frame ?? self.view.frame
        jackpotFusionInfoView?.view.backgroundColor = UIColor.clear
        jackpotFusionInfoView?.modalPresentationStyle = .overFullScreen
        if let jackpotFusionInfoView {
            let presenter = AlertPresenter(vc: jackpotFusionInfoView)
            AlertCoordinator.showView(presenter)
        }
    }
}

//MARK: - Lobby Feed Datasource implementation.
extension ImmersiveLobbyCollectionViewController: LobbyFeedDataSource {
    
    /// will return the Feed view model
    var feedViewModel: FeedViewModel? {
        self.datasource?.feedViewModel
    }
}

extension ImmersiveLobbyCollectionViewController {
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentOffset = scrollView.contentOffset.y
        let contentSize = scrollView.contentSize.height
        if currentOffset > self.previousOffset { //scrolled up
            let scrollPercentage = (currentOffset/contentSize)*100
            if scrollPercentage > 90 && self.scollEventNumber == 3 {
                self.trackEvent(scrollPercentage: 100)
                self.scollEventNumber = 0
            } else if scrollPercentage >= 75 && scrollPercentage <= 80 && self.scollEventNumber == 2 {
                self.trackEvent(scrollPercentage: 75)
                self.scollEventNumber += 1
            } else if scrollPercentage >= 50 && scrollPercentage <= 55 && self.scollEventNumber == 1 {
                self.trackEvent(scrollPercentage: 50)
                self.scollEventNumber += 1
            } else if scrollPercentage >= 25 && scrollPercentage <= 30 && self.scollEventNumber == 0 {
                self.trackEvent(scrollPercentage: 25)
                self.scollEventNumber += 1
            }
        }
        self.previousOffset = currentOffset
        if currentOffset == 0 {
            self.scollEventNumber = 0
        }
    }
}
extension ImmersiveLobbyCollectionViewController {
    private func trackEvent(bannerName: String,
                            index: Int,
                            cta: String,
                            isEmbeddBanner: Bool = false) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.banner.rawValue,
                                     actionEvent:EpcotEventAction.click.rawValue,
                                     labelEvent: bannerName,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: cta,
                                     positionEvent: isEmbeddBanner ? EmbeddedBannerContainerName.all_games.rawValue : "\(index)")
            
            let event = TrackerEvent(type: .bannerClick, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
    private func trackEvent(scrollPercentage: Int) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.scroll.rawValue,
                                     actionEvent:EpcotEventAction.click.rawValue,
                                     labelEvent: EpcotEventLabel.scroll.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: "\(scrollPercentage)")
            
            let event = TrackerEvent(type: .scroll, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
    private func trackJackpotWidgetsEvent(jackpotName: String, jackpotSectionTitle: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.jackpotWidgets.rawValue,
                                     actionEvent:EpcotEventAction.click.rawValue,
                                     labelEvent: EpcotEventLabel.topNavBar.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: jackpotName,
                                     positionEvent: jackpotSectionTitle)
            
            let event = TrackerEvent(type: .jackpotWidgets, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
    private func trackFavouritesClickEvent(gameName: String, action: String, section: String, type: EventType) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.casinoFavourites.rawValue,
                                     actionEvent: action,
                                     labelEvent: ScreenName.casino.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: gameName,
                                     positionEvent: section)
            
            let event = TrackerEvent(type: type, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}
//MARK: - Teasers and Jackpot widget changes included.
extension ImmersiveLobbyCollectionViewController {
    
    private func updateTeasersScroll(layoutEnvironment:NSCollectionLayoutEnvironment, scrollOffset: CGPoint, sectionIndex: Int ) {
        guard let teasersConfig = self.teaserDynaconConfig,
                teasersConfig.shouldDisplayPageControl,
                !UIDevice.isIPad() else { return }
        let width = CGFloat(280 - 16)
        let currentItem = Int(round(scrollOffset.x / width))
        if !self.teasersContentModel.isEmpty {
            let indexpath = IndexPath(item: currentItem, section: sectionIndex)
            self.pagingInfoSubject.send(indexpath)
            self.teaserCurrentIndex = currentItem
        }
    }
    private func updateJackpotWidgetScroll(layoutEnvironment:NSCollectionLayoutEnvironment, scrollOffset: CGPoint, sectionIndex: Int) {
        let width = layoutEnvironment.container.contentSize.width
        let currentItem = Int(round(scrollOffset.x / width))
        let indexpath = IndexPath(item: currentItem, section: sectionIndex)
        let totalItems = self.immersiveElements[sectionIndex].jackpotWidget?.count ?? 0
        if totalItems > currentItem {
            self.pagingInfoSubject.send(indexpath)
            ///when jackpot price updated snapshot will reload
            ///this visible items of this section gets called everytime of reloading the snapshot
            if self.multipleJackpotsCurrentIndexPath.section != indexpath.section || self.multipleJackpotsCurrentIndexPath.row != indexpath.row {
                ///if we don't store indexpath, it gives deadlock beacuse of reload
                self.stopJackpotTimer()
                self.stopJackpotWidgetScrollTimer()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {[weak self] in
                    self?.multipleJackpotsCurrentIndexPath = indexpath
                }
            } else {
                self.startJackpotTimer()
                self.startJackpotScrollTimer()
            }
        }
    }
    
    private func checkForJackpotWidgetSections() -> Bool {
        let jackpotWidgetSections = self.immersiveElements.filter({$0.jackpotWidget != nil})
        if jackpotWidgetSections.isEmpty, !self.jackpotWidgets.isEmpty {
            if let category = self.selectedCategory,
                let routes = self.feedViewModel?.getSubCategories(for: category)?.compactMap({ $0.route }) {
                let categoryRoutes = Set(routes.compactMap({ $0.lowercased() }))
                let jackpotRoutes = Set(self.jackpotWidgets.keys)
                let commonRoutes = categoryRoutes.intersection(jackpotRoutes)
                if !commonRoutes.isEmpty {
                    var isGamesAvailable = false
                    commonRoutes.forEach { route in
                        if let gamesList = self.feedViewModel?.getSubCategoryRouteGames(for: route, in: category), !gamesList.isEmpty {
                            isGamesAvailable = true
                        }
                    }
                    if isGamesAvailable {
                        return self.didUpdateTilesForJackpotAmount()
                    }
                }
            }
        }
        return false
    }
    
    @discardableResult
    private func didUpdateTilesForJackpotAmount() -> Bool {
        guard var snapShot = self.diffDatasource?.snapshot() else { return false}
        guard self.collectionView != nil else { return false}
        
        if updatedJackpotTiles != nil, snapShot.sectionIdentifiers.first(where: {$0.layoutType == .jackpotTiles}) == nil {
            self.applySnapshot(with: self.selectedCategory, for: true)
            return true
        }
        
        guard !self.collectionView.isTracking,
              !self.collectionView.isDragging else { return false}
        self.stopJackpotTimer()
        self.stopJackpotWidgetScrollTimer()
        self.seeMoreController?.seeMoreCollectionView?.reloadItems()
        
        let sectionIdentifers = snapShot.sectionIdentifiers.filter({ !($0.layoutType == .teasers || $0.layoutType == .embeddedBanner || $0.layoutType.isFooterLayoutType || $0.layoutType == .jackpotTiles || $0.layoutType == .playerStatsWidget) })
        
        sectionIdentifers.forEach { section in
            let items = snapShot.itemIdentifiers(inSection: section)
            snapShot.reloadItems(items)
        }
        DispatchQueue.main.async {
            self.diffDatasource?.apply(snapShot,
                                       animatingDifferences: false,
                                       completion: {[weak self] in
                self?.startJackpotTimer()
                self?.startJackpotScrollTimer()
            })
        }
        return true
    }
}

//MARK: - Footer Data Updates
extension ImmersiveLobbyCollectionViewController {
    
    func onSitecoreDataUpdated() {
        self.updateFooterStateSwitcherModel()
        //reload footer
        self.immersiveFooterElements.removeAll()
        self.applySnapshot()
    }
    
    private func updateFooterStateSwitcherModel() -> Bool {
        guard (EntainContext.user?.isLoggedIn() ?? false),
              let _ = EpcotLobbyManager.shared?.datasource?.loggedInTime,
              let stateModel = POSAPI.shared?.footerStateSwitcher,
              stateModel.hideTimer == false else {
            return false
        }
        self.stateSwitcherModel = stateModel
        return true
    }
    
    private func reloadImmersiveSection(of type: LayoutType) {
        guard var snapShot = self.diffDatasource?.snapshot() else { return }
        if var reloadSection = snapShot.sectionIdentifiers.first(where: {$0.layoutType == type}) {
            snapShot.reloadSections([reloadSection])
            DispatchQueue.main.async {
                self.diffDatasource?.apply(snapShot, animatingDifferences: false)
            }
        }
    }
}

//MARK: - Footer State Changer selection
extension ImmersiveLobbyCollectionViewController {
    
    private func startFooterTimer() {
        if self.footerTimer == nil {
            self.footerTimer = DispatchTimer(interval: 1, handler: self.updateFooterTimer)
        }
    }
    
    private func stopFooterTimer() {
        if self.footerTimer != nil {
            self.footerTimer?.cancel()
            self.footerTimer = nil
        }
        self.loggedInInfoSubject.send(nil)
        self.currentDateInfoSubject.send()
    }
    
    @objc private func updateFooterTimer() {
        ///Footer State Switcher login duration update
        if let hideTimer = self.stateSwitcherModel?.hideTimer,
           hideTimer == false,
           let loggedInTime = EpcotLobbyManager.shared?.datasource?.loggedInTime {
            self.loggedInInfoSubject.send(loggedInTime)
        }
        ///Footer copyRight current time update
        if let copyRightContent = POSAPI.shared?.footerCopyRight,
           copyRightContent.timerEnabled {
            self.currentDateInfoSubject.send()
        }
    }
}

extension ImmersiveLobbyCollectionViewController: NativeFooterStateChangerDelegate, StateChangerListDelegate {
    
    func openStateChangeView(with cell: NativeFooterStateChangerCell) {
        ///close if any previous view is available
        guard self.collectionView != nil,
                let indexPath = self.collectionView.indexPath(for: cell) else { return }
        guard let theAttributes = self.collectionView.layoutAttributesForItem(at: indexPath) else { return }
        ///cell frame w.r.t collection view
        let topViewController = EpcotLobbyManager.shared?.datasource?.controllerForLoadGame() ?? self
        
        let cellFrameInSuperview = self.collectionView.convert(theAttributes.frame,
                                                               to: topViewController.view)
        
        ///states pop up calculated y-position
        var yPos = cellFrameInSuperview.origin.y + cellFrameInSuperview.size.height + 10
        
        let statesInfo = EpcotLobbyManager.shared?.datasource?.didRequestforFooterStates()
        let switcherConfigs = StateSwitchConfigs(selectedState: statesInfo?.selectedState,
                                                 states: statesInfo?.states,
                                                 yPosition: yPos,
                                                 switcherPositionY: cellFrameInSuperview.origin.y - 10)
        NativeFooterStateChangerViewController.showOn(presentingController: topViewController,
                                                      delegate: self,
                                                      configs: switcherConfigs)
        self.stateSwitcherInfoSubject.send(true)
        self.collectionView.isScrollEnabled = false
    }
    
    func updateStateView(selectedState: String?) {
        EpcotLobbyManager.shared?.delegate?.didClicked(item: NativeFooterItem(type: .stateSelect,
                                                                              referenceLink: nil,
                                                                              nativeActionCategory: 0,
                                                                              selectedState: selectedState))
        self.stateSwitcherInfoSubject.send(false)
        self.collectionView.isScrollEnabled = true
        self.reloadImmersiveSection(of: .footerStateswitcher)
    }
}

extension ImmersiveLobbyCollectionViewController: ImmersiveLobbyCollectionControllerDelegate {
    func didTappedOnFavourites(gameVariant: String, state: Bool, from seeMoreSection: Bool) {
        self.delegate?.didTappedOnFavourites(gameVariant: gameVariant, state: state,from: seeMoreSection)
    }
}
