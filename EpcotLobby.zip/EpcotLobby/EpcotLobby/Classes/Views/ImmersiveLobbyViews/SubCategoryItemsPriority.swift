//
//  SubCategoryItemsPriority.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 10/07/23.
//

import Foundation

enum SubCategoryItemsPriority: Int {
    case games
    case jackpotWidgets
    case videoTeaser
    case freeSpinWidgets
    case playerStatsWidget
    case jackpotTiles
    case originalsWidget
    case engagementTools // 6
}
