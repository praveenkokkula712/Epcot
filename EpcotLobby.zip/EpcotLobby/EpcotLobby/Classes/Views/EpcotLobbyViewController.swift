//
//  EpcotLobbyViewController.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 31/03/22.
//

import Foundation
import UIKit
import CasinoAPI
import Utility
import TrackerClient
import SwiftUI
import Combine
import ConfigModule
import Kingfisher
import AVFoundation

fileprivate let pageTrackerID = "NEW"
fileprivate let notApplicable = "not applicable"
fileprivate let pageName = "Native Casino Lobby"
fileprivate let start = "Start"
fileprivate let eventKey = "event"

class EpcotLobbyViewController: EpcotBaseViewController {
    
    /// IBOutlet connections.
    @IBOutlet private weak var searchContainerView: UIView!
    @IBOutlet private weak var filterContainerView: UIView!
    @IBOutlet private weak var mainContentView: UIView!
    @IBOutlet private(set) weak var categoryContentView: UIView!
    @IBOutlet private(set) weak var favoriteToastView: UIView!
    @IBOutlet private(set) weak var gameStoriesContainerView: UIView!
    @IBOutlet weak var gameStoriesContainerViewHeight: NSLayoutConstraint!

    @IBOutlet private weak var categoriesHeightConstraint: NSLayoutConstraint!
    @IBOutlet private weak var searchBottomConstraint: NSLayoutConstraint!
    @IBOutlet private weak var searchContainerHeightConstraint: NSLayoutConstraint!
    @IBOutlet private(set) weak var bottomSearchContainerView: UIView!
    @IBOutlet private weak var searchBottomButton: CustomSearchButton!
    @IBOutlet private weak var searchButtonBottomConstraint: NSLayoutConstraint!
    @IBOutlet private weak var searchButtonWidthConstraint: NSLayoutConstraint!
    @IBOutlet private(set) weak var favoriteToastViewBottom: NSLayoutConstraint!
    
    // MARK: -  Private properties.
    private var isCGLoaded = false
    private var isSiteCoreDataUpdated = false
    @Atomic private(set) var feedModel: FeedViewModel?
    private(set) var immersiveGamesCollectionViewController: ImmersiveLobbyCollectionViewController?
    private var seeMoreGamesCollectionViewController: SeeMoreSectionCollectionViewController?

    private var switcherCategoriesHeaderView: SwitcherCategoryHeaderView?
    
    private(set) weak var searchController: EpcotSearchViewController?
    private(set) weak var casinoSearchController: SearchViewController?
    var enhancedSearchController: UIHostingController<SearchDashboardView>?
    var gamePremiereViewController: UIHostingController<GamePremiereOverlay>?
    private var menuController: EpcotMenuViewController?
    private weak var epcotLobbySearchView: EpcotLobbySearchView?
    private weak var lobbySearchView: LobbySearchView?

    private var viewShimmer: UIView?
    private var epcotShimmerController: EpcotShimmerCollectionViewController?
    private var immersiveShimmerController: ImmersiveShimmerCollectionViewController?
    ///Based on responses received, will check to show or remove Shimmer effect
    private var shimmerResponseType: [ShimmerReceivedResponseType: Bool] = [:]
    
    ///for See More Collection View
    private var seeMoreCollectionViewGridLayout = GridCollectionViewLayout()
    private var seeMoreCollectionViewListLayout = ListCollectionViewLayout()
    private(set) var subNavigationItems: SubNavigationItems?
    private var siteCoreMenuItems: BurgerMenuItems?
        
    private var searchSuggestions: [EntainSiteCoreItem]?
    private var selectedCategory: String? {
        didSet {
            withAnimation {
                self.categoryPublishedModel.currentId = self.categoryPublishedModel.siteCoreItems.first(where: {$0.parameters?.id == selectedCategory})?.uuid ?? UUID()
            }
        }
    }
    
    var welcomeScreen : UIHostingController<UserOnboardingWelcomeView>?
    var playBreakScreen: UIHostingController<PlayBreakView>?
    var originalsOverlayController: UIHostingController<OriginalsOverlayView>?
    var welcomeScreenLocalizedModel: WelcomeScreenLocalizedModel = WelcomeScreenLocalizedModel(title: Localize.onboardingWelcomeScreenTitle, description: Localize.onboardingWelcomeScreenDescription, getStarted: Localize.onboardingWelcomeScreenGetStartedTitle, skip: Localize.onboardingWelcomeScreenSkipNowTitle)
    
    private var isFavouriteSelected: Bool = false
    var toastFavoriteView: FavoriteToasterView?
    
    let categoryPublishedModel = CategoryPublishedModel()
    let epcotCategoryModel = EpcotCategoryPublishedModel()
    
    private var css : LobbyCSS? {
        return EpcotLobbyManager.shared?.css
    }
    private var lobbyheaderViewType: LobbyHeaderType? {
        return self.css?.lobbyheaderViewType
    }
    
    private var shimmerCss: ShimmerViewCSS? {
        EpcotLobbyManager.shared?.css.shimmerViewCSS
    }
    
    private var isImmersiveEnabled: Bool {
        ImmersiveInstance.shared.isEnabled
    }
        
    private let isBottomSearchEnabled: Bool = {
        return EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .searchButtonEnabled) ?? false
    }()
    
    private var isHomePillNeeded: Bool {
        EntainContext.app?.isHomePillNeeded ?? false
    }
    
    var searchButtonInitialFrame: CGRect?
    
    private var gameStoriesConfig: GameStoriesConfig? {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.gameStoriesConfigurations
    }
    private var onSearchGameTap: ((Game) -> Void)?

    private(set) var favoriteViewModel = FavoriteToastViewModel()
    
    var pposLayer = EntainServiceManager.shared.pposLayer

    
    var toasterVC: UIHostingController<ToastersStackView>?
    private(set) var gameStoriesViewModel: GameStoriesViewModel!
    var gameStoryViewFrame: CGRect!
    let gameStoryViewTransition = CircularTransition()
    var overlaysVC: UIHostingController<OverlaysStackView>?
    
    private var overlaysCancellable: AnyCancellable?
    private var toasterCancellable: AnyCancellable?
    var pagingInfoToken: AnyCancellable?
    
    private var isEpcotEnabled: Bool {
        return CasinoCSS.lobby?.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false
    }
    private var categorySelected = false
    
    private var deepLinkUrl : String?
    
    //Free Spins
    var freeSpinsOverlayController: UIHostingController<FreeSpinsOverlayView>?
    
    //MARK: - Helper
    private var immersiveJackpotTiles: [String: NativeWidgetsModel] {
        self.immersiveGamesCollectionViewController?.jackpotTiles ?? [:]
    }
    //Most searched view model
    private(set) var mostSearchedViewModel: MostSearchedGamesViewModel?
    
    private var isLmtResponseLoaded = false

    //MARK: -  ViewController lifecycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addObservers()
        self.setupViews()
        self.refreshLobbyMetaData()
        self.getPublishedToasterData()
        self.getPublishedOverlaysData()
        EpcotLobbyManager.shared?.setupAudioSessionForBackgroundAudio()
        self.addAccessibilityIdentifiers()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isHidden = true
        self.feedModel?.startFeedTimers()
        self.immersiveGamesCollectionViewController?.reloadVideoTeaserOnGamePlayDismiss(isPresenting: false)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UserOnboardingViewModel.shared?.subscribeTo(view: self)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if let _ = UIApplication.topViewController() as? SeeMoreSectionViewController {
            return
        }
        self.feedModel?.stopFeedTimers()
        self.immersiveGamesCollectionViewController?.reloadVideoTeaserOnGamePlayDismiss(isPresenting: true)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if self.lobbyheaderViewType == .gamesCategories {
            self.categoryContentView.updateShadow()
       }
    }
    
    deinit {
        Feed.removeObserver(observer: self,
                            notification: .didUpdateSitecoreModels)
        NotificationCenter.default.removeObserver(self)
    }
    
    private func getPublishedToasterData() {
        toasterCancellable = pposLayer.$toasterModel.receive(on: DispatchQueue.main).sink { toasterData in
            guard let toasterModel = toasterData else {
                return
            }
            if !toasterModel.imageUrl.isEmpty,
               let url = URL(string: toasterModel.imageUrl) {
                KingfisherManager.shared.retrieveImage(with: KF.ImageResource(downloadURL: url)) { kfResult in
                    toasterModel.diskImage = try? kfResult.get().image
                    self.showToastersController(toasterModel: toasterModel)
                }
            }
            self.trackToasterAndOverlaysEvents(categoryEvent: EpcotEventCategory.toaster.rawValue,
                                               title: toasterModel.toasterTitle ?? "",
                                               positionEvent: EpcotEventPosition.unstacked_toasters.rawValue,
                                               eventType: .toaster_load)
        }
    }
    
    private func getPublishedOverlaysData() {
        overlaysCancellable = pposLayer.$overlayModel.receive(on: DispatchQueue.main).sink { overlaysData in
            guard let overlayModel = overlaysData else {
                return
            }
            if !overlayModel.imageUrl.isEmpty,
               let url = URL(string: overlayModel.imageUrl) {
                KingfisherManager.shared.retrieveImage(with: KF.ImageResource(downloadURL: url)) { kfResult in
                    overlayModel.diskImage = try? kfResult.get().image
                    self.showOverlaysController(overlayModel: overlayModel)
                }
            }
            self.trackToasterAndOverlaysEvents(categoryEvent: EpcotEventCategory.overlay.rawValue,
                                               title: overlayModel.overlayTitle ?? "",
                                               positionEvent: EpcotEventPosition.unstacked_toasters.rawValue,
                                               eventType: .overlays_load)
        }
    }

    private func addObservers() {
        Feed.addObserver(observer: self,
                         selector: #selector(self.didUpdateSitecoreModels),
                         notification: .didUpdateSitecoreModels)
        
        Feed.addObserver(observer: self,
                         selector: #selector(self.didUpdateLocalizedStrings),
                         notification: .didUpdateLocalizedStrings)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(resetSearchButtonFrame),
                                               name: Notification.Name(kResetBottomSearchLayout),
                                               object: nil)

        if UIDevice.isIPad() {
            NotificationCenter.default.addObserver(self,
                                                   selector: #selector(didDeviceRotated),
                                                   name: UIDevice.orientationDidChangeNotification,
                                                   object: nil)
        }
    }
    
    @objc private func didDeviceRotated() {
        if let currentJourney = UserOnboardingViewModel.shared?.currentUserJourney {
            if currentJourney.type == .search || currentJourney.type == .seeAll {
                UserOnboardingViewModel.shared?.updateViewsOnRotation()
            }
        }
    }
    
    @objc private func didUpdateLocalizedStrings() {
        self.welcomeScreenLocalizedModel.updateLocalizeStrings()
        let content = POSAPI.shared?.casinoStoriesContent
        if gameStoriesConfig?.isGameStoriesEnabled ?? false, content != nil {
            self.fetchGameStoriesContent()
        }
    }
    
    var isOriginalWidgetExpired: Bool = true
    
    @objc private func didUpdateSitecoreModels() {
        if self.isImmersiveEnabled {
            JackpotWidgetsViewModel.shared.getNativeWidgetBasedOnRoute()
            JackpotWidgetsViewModel.shared.getJackpotFusionWidgets()
            JackpotTileOrderViewModel.shared.getNativeWidgetsBasedOnRoute(feedDatasource: self)
        }
        self.updateOnSitecoreResponseReceived()
        
        // get jackpot feed from cache
        if self.isImmersiveEnabled,
           !self.immersiveJackpotTiles.isEmpty {
            self.feedViewModel?.updateJackpotInfoFromCache()
        }
    }
    
    var originalWidgetViewModel: OriginalsWidgetViewModel?
    
    func updateOnSitecoreResponseReceived() {
        if self.immersiveGamesCollectionViewController?.isCategorySelected ?? false {
            self.immersiveGamesCollectionViewController?.isCategorySelected = false
        }
        self.updateBurgerMenuandSubNavigationContent()
        self.immersiveGamesCollectionViewController?.onSitecoreDataUpdated()
        self.isSiteCoreDataUpdated = true
        if isShimmerRemoved {
            self.presentOverLays()
        }
        guard let content = POSAPI.shared?.originalsWidgetConfigurations else { return }
        originalWidgetViewModel = OriginalsWidgetViewModel(content: content, delegate: self)
    }
    
    func presentOverLays() {
        if EntainContext.user?.isLoggedIn() ?? false {
            let iswebViewVisible = EpcotLobbyManager.shared?.datasource?.isWebViewVisisble ?? true
            if let gamePremiereModel = POSAPI.shared?.gamePremiereModel {
                if !iswebViewVisible {
                    self.presentGamePremiereView {
                        if let gamePremiereViewController = self.gamePremiereViewController {
                            let presenter = AlertPresenter(vc: gamePremiereViewController)
                            AlertCoordinator.removeView(presenter) {
                                self.gamePremiereViewController?.rootView.viewModel.clean()
                                self.gamePremiereViewController = nil
                                self.showOnBoardingWelcomeScreenIfNeeded()
                            }
                        } else {
                            self.showOnBoardingWelcomeScreenIfNeeded()
                        }
                    }
                    EpcotLobbyAccessor.removeObserver(observer: self, notification: .didClosedWebView)
                } else {
                    EpcotLobbyAccessor.addObserver(observer: self,
                                                   selector: #selector(didClosewebView),
                                                   notification: .didClosedWebView)
                }
            } else {
                self.showOnBoardingWelcomeScreenIfNeeded()
            }
        } else {
            UserOnboardingViewModel.shared?.setupData(isSeeAllAvailable: self.isSeeAllVisibile, isJacpotFusionInfoAvailable: self.isJacpotFusionInfoAvailable)
        }
    }
}

//MARK: - Configure views
extension EpcotLobbyViewController {
    
    private func setupViews() {
        self.mainContentView.clipsToBounds = true
        self.configureSearchView()
        self.configureCategoriesHeaderView()
        self.setupGamesWindow()
        self.addShimmerView()
        if favoriteToastConfig?.isFavoriteToastEnabled ?? false {
            setupFavoriteToastView(viewModel: favoriteViewModel)
        }
        setupCasinoGameStoriesView()
    }
    
    private func configureSearchView() {
        switch self.css?.type {
        case .epcotLobby:
            self.searchBottomConstraint.constant = 0
            self.view.backgroundColor = self.css?.epcotLobbyCSS?.searchMenuContainerViewBGColor
            self.configureEpcotSearchView()
        default:
            if isBottomSearchEnabled {
                self.addSearchButton()
                self.searchContainerHeightConstraint.constant = 0
            } else {
                self.bottomSearchContainerView.isHidden = true
                self.searchBottomConstraint.constant = 8
                self.view.backgroundColor = self.css?.searchView?.searchParentContainerBGColor ?? UIColor.white
                self.configureCommonSearchView()
            }
        }
        self.configureSearchGameAction()
    }
    
    ///Configure SearchView for Epcot
    private func configureEpcotSearchView() {
        self.epcotLobbySearchView = EpcotLobbySearchView.load(on: self.searchContainerView)
        self.epcotLobbySearchView?.didTappedOnMenu = {
            self.loadMenuView()
            self.didGameUnloadedOnDownloadFailOrCancel()
        }
        self.epcotLobbySearchView?.didTappedOnSearch = { [weak self] isSpeechToTextEnabled in
            let searchVersion = EpcotLobbyManager.shared?.datasource?.searchVersion ?? .v1
            switch searchVersion {
            case .v1:
                self?.loadEpcotSearchViewController(with: isSpeechToTextEnabled)
            case .v2:
                self?.presentCasinoSearchView(isEpcot: true,
                                              isVoiceCommand: isSpeechToTextEnabled,
                                              onGameTap: self?.onSearchGameTap)
            }
            self?.didGameUnloadedOnDownloadFailOrCancel()
        }
    }
    
    private func addSearchButton() {
        self.bottomSearchContainerView.isHidden = false
        self.view.bringSubviewToFront(self.bottomSearchContainerView)
        self.bottomSearchContainerView.layer.cornerRadius = kBottomSearchkButtonCornerRadius
        self.searchBottomButton.layer.cornerRadius = kBottomSearchkButtonCornerRadius
        self.searchBottomButton.updateButtonTheming(with: EpcotLobbyManager.shared?.css.searchInputAccessoryViewCSS)
        self.bottomSearchContainerView.clipsToBounds = true
    }
    
    ///Configure Common SearchHeaderView
    private func configureCommonSearchView() {
        self.lobbySearchView = LobbySearchView.load(on: self.searchContainerView)
        self.lobbySearchView?.didTappedOnMenu = {
            self.didGameUnloadedOnDownloadFailOrCancel()
            self.loadMenuView()
        }
        self.lobbySearchView?.didTappedOnSearch = { [weak self] isSpeechToTextEnabled in
            let searchVersion = EpcotLobbyManager.shared?.datasource?.searchVersion ?? .v1
            switch searchVersion {
            case .v1:
                self?.loadCommonSearchViewController(with: isSpeechToTextEnabled)
            case .v2:
                self?.presentCasinoSearchView(isVoiceCommand: isSpeechToTextEnabled,
                                             onGameTap: self?.onSearchGameTap)
            }
            self?.didGameUnloadedOnDownloadFailOrCancel()
        }
    }
    
    private func updateMostSearchedGames() {
        if EpcotLobbyManager.shared?.datasource?.searchVersion == .v2 {
            if self.mostSearchedViewModel == nil {
                self.mostSearchedViewModel = MostSearchedGamesViewModel()
            }
            self.mostSearchedViewModel?.fetchIfNeeded(with: self)
        }
    }
    
    private func configureSearchGameAction() {
        //V2 Search game Tap Call back
        self.onSearchGameTap = { [weak self] game in
            guard let gameVariant = game.game else { return }
            var additionalParameters = AdditionalParameters()
            additionalParameters.location = GameSection.search.name
            additionalParameters.categoryID = kGlobalSearch
            self?.presentedViewController?.dismiss(animated: true, completion: {
                self?.didClickedPlay(with: gameVariant,
                                     additionalParams: additionalParameters)
            })
        }
    }
    
    private func setupGamesWindow() {
        self.clearLobby()
        if self.immersiveGamesCollectionViewController == nil {
            self.immersiveGamesCollectionViewController = ImmersiveLobbyCollectionViewController(datasource: self)
            self.immersiveGamesCollectionViewController?.delegate = self

            self.immersiveGamesCollectionViewController?.onClickGameplay = { game, additionalParams in
                self.didClickedPlay(with: game, additionalParams: additionalParams)
            }
        
            self.immersiveGamesCollectionViewController?.onClickSubCategorySeeMore = { (category, subCategoryId) in
                self.didClickedSeeMore(with: category, subCategoryId: subCategoryId, saveItem: true)
                self.epcotCategoryModel.isLinkedCategory = true
            }
            self.immersiveGamesCollectionViewController?.onClickLinkedCategory = { linkedCategory in
                if let items = self.subNavigationItems?[.categories],
                   let category = items.first(where: {$0.parameters?.id == linkedCategory}) {
                    self.updateCategorySelection(with: category, saveItem: true)
                }
            }
            
            self.immersiveGamesCollectionViewController?.onClickFreeSpinsWidget = { (freeSpin, gameNames) in
                self.presentFreeSpinsOverlayView(with: freeSpin,
                                                 gameNames: gameNames,
                                                 onGameTap: { [weak self] game in
                    guard let gameVariant = game.game else { return }
                    self?.freeSpinsOverlayController?.dismiss(animated: true, completion: {
                        self?.didClickedPlay(
                            with: gameVariant,
                            additionalParams: AdditionalParameters(
                                mode: kReal,
                                location: GameSection.freeSpins.name
                            )
                        )
                        self?.freeSpinsOverlayController = nil
                    })
                })
            }
            
            self.immersiveGamesCollectionViewController?.onClickJackpotTile = { model in
                self.didClickedOnJackpotTile(with: model, saveItem: true)
            }
            
            self.immersiveGamesCollectionViewController?.onClickSeeDeailsBtn = { [weak self] in
                self?.presentOriginalsOverlayView()
            }
            
            self.configureChildViewController(childController: immersiveGamesCollectionViewController ?? UIViewController(), onView: self.mainContentView)
            if self.isImmersiveEnabled {
                JackpotWidgetsViewModel.shared.getNativeWidgetBasedOnRoute()
                JackpotWidgetsViewModel.shared.getJackpotFusionWidgets()
                JackpotTileOrderViewModel.shared.getNativeWidgetsBasedOnRoute(feedDatasource: self)
            }
        }
    }

    private func setupCasinoGameStoriesView() {
        gameStoriesContainerViewHeight.constant = 0
        self.view.layoutIfNeeded()
        if gameStoriesConfig?.isGameStoriesEnabled ?? false {
            //NOTE: We are not comparing the showHeaderTitle key for iPad device
            // since the Dynacon does not have the support of differentiate device types.
            let showHeaderTitle = UIDevice.isIPad() ? true : self.gameStoriesConfig?.showHeaderTitle
            gameStoriesViewModel = GameStoriesViewModel(showHeaderTitle: showHeaderTitle)
            setupGameStoriesView(viewModel: gameStoriesViewModel)
        }
    }

    private func clearLobby() {
        self.immersiveGamesCollectionViewController?.clean()
        self.immersiveGamesCollectionViewController?.removeChildrenView()
        self.immersiveGamesCollectionViewController = nil
    }
}

//MARK: - Shimmer Layer
extension EpcotLobbyViewController {
    private func addShimmerView() {
        if self.viewShimmer == nil {
            self.viewShimmer = UIView()
            self.viewShimmer?.backgroundColor = shimmerCss?.backgroundColor ?? .black
            self.viewShimmer?.translatesAutoresizingMaskIntoConstraints = false
            if let shimmerView = self.viewShimmer {
                self.view.addSubview(shimmerView)
                NSLayoutConstraint.activate([
                    shimmerView.leadingAnchor.constraint(equalTo: self.mainContentView.leadingAnchor, constant: 0),
                    shimmerView.trailingAnchor.constraint(equalTo: self.mainContentView.trailingAnchor, constant: 0),
                    shimmerView.topAnchor.constraint(equalTo: self.filterContainerView.topAnchor, constant: 0),
                    shimmerView.bottomAnchor.constraint(equalTo: self.mainContentView.bottomAnchor, constant: 0)
                ])
                if CasinoCSS.lobby?.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false {
                    self.epcotShimmerController = EpcotShimmerCollectionViewController()
                    self.configureChildViewController(childController: self.epcotShimmerController ?? UIViewController(), onView: shimmerView)
                } else {
                    self.immersiveShimmerController = ImmersiveShimmerCollectionViewController()
                    self.configureChildViewController(childController: self.immersiveShimmerController ?? UIViewController(), onView: shimmerView)
                }
            }
        }
    }
    
    private func removeShimmerWindowIfNotRequired() {
        if self.shimmerResponseType[.categories] ?? false,
            self.shimmerResponseType[.games] ?? false {
            DispatchQueue.main.asyncAfter(deadline: .now()+0.5) {
                self.removeShimmerWindow()
            }
        }
    }
    
    var isShimmerRemoved: Bool {
        self.viewShimmer == nil
    }
    
    private func removeShimmerWindow() {
        self.immersiveShimmerController?.removeChildrenView()
        self.immersiveShimmerController = nil
        self.epcotShimmerController?.removeChildrenView()
        self.epcotShimmerController = nil
        self.viewShimmer?.removeFromSuperview()
        self.viewShimmer = nil
        for type in ShimmerReceivedResponseType.allCases {
            self.shimmerResponseType[type] = false
        }
        if isSiteCoreDataUpdated, isCGLoaded {
            self.presentOverLays()
        }
    }
}


//MARK: - Menu view initialization and call back implementation.
extension EpcotLobbyViewController {
    private func loadMenuView() {
        guard let siteCoreMenuItems = self.siteCoreMenuItems, !siteCoreMenuItems.isEmpty else { return }
        let controller = EpcotMenuViewController()
        controller.modalPresentationStyle =  UIDevice.isIPad() ? .formSheet : .overCurrentContext
        controller.modalPresentationCapturesStatusBarAppearance = true
        self.menuController = controller
        self.handleMenuCategorySelection()
        self.handleWebCategorySelection()
        self.handleMenuPageDismiss()
        if let menuItems = self.siteCoreMenuItems {
            self.menuController?.burgerMenuItems = menuItems
        }
        let topController = UIApplication.topViewController() ?? self
        topController.definesPresentationContext = true
        topController.present(controller, animated: true, completion:nil)
    }
    
    private func handleMenuCategorySelection() {
        self.menuController?.categorySelected = { [weak self] item, location in
            guard let self = self else { return false }
            self.menuController?.dismiss(animated: true, completion: {
                let categoryUpdateVariant = self.updateView(with: item)
                if categoryUpdateVariant.isUpdated,
                    let selectedItem = self.subNavigationItems?[.categories]?.first(where: {$0.parameters?.id == item.parameters?.id}) {
                    
                    let isLastPageIsSeemore = self.epcotCategoryModel.selectedItems.last?.isSeeMoreItem ?? false
                    
                    self.updateSelectedCategory(item: selectedItem,
                                                categoryId: categoryUpdateVariant.categoryId)
                    if isLastPageIsSeemore {
                        self.removeSeeMoreGamesCollectionViewController(applyNewSnapshot: false)
                    }
                }
                self.epcotCategoryModel.isLinkedCategory = false
                self.menuController?.clearView()
                self.menuController = nil
                self.trackeEvent(location: location)
            })
            return true
        }
    }
    
    private func handleWebCategorySelection() {
        self.menuController?.onWebCategorySelection = { [weak self] item in
            guard let self = self else { return }
            self.menuController?.dismiss(animated: true, completion: {
                EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .categories(item), buttonType: nil)
                self.menuController?.clearView()
                self.menuController = nil
            })
        }
    }
    
    private func handleMenuPageDismiss() {
        self.menuController?.onDismiss = { [weak self] in
            guard let self = self else { return }
            self.menuController?.dismiss(animated: true, completion: {
                self.didGameUnloadedOnDownloadFailOrCancel()
                self.menuController?.clearView()
                self.menuController = nil
            })
        }
    }

    func scrollCollectionViewtoTop() {
        if isEpcotEnabled, categorySelected {
            self.epcotCategoryModel.selectedItems.removeAll()
            self.loadLobbyPage()
        } else if !isEpcotEnabled, let firstId = self.subNavigationItems?[.categories]?.first,
                  let selectedCategory = self.selectedCategory, selectedCategory != firstId.parameters?.id {
            self.updateCategorySelection(with: firstId)
        } else {
            self.immersiveGamesCollectionViewController?.collectionView.setContentOffset(kCollectionViewOffSet,
                                                                                         animated: true)
        }
        self.immersiveGamesCollectionViewController?
            .originalsWidgetViewModel?
            .getOptinStatus()
    }
}

//MARK: - Search view controller initialisation and call backs implementation
extension EpcotLobbyViewController {
    ///Loads Epcot Search viewcontroller
    private func loadEpcotSearchViewController(with voiceSearchEnabled: Bool) {
        self.searchController = EpcotSearchViewController.show(dataSource: self,
                                                               isEnabledSpeech: voiceSearchEnabled,
                                                               on: self)
        self.searchController?.didDismissed = {[weak self] in
            guard let self = self else { return }
            self.didGameUnloadedOnDownloadFailOrCancel()
            self.searchController?.removeChildrenView()
            self.searchController = nil
        }
        /// checking whether selected category from suggestions is of type webcategory or not
        /// if it is webcategory then we are closing the search controller otherwise updating the games in the result colletionview
        self.searchController?.onClickCategory = {[weak self] item in
            guard let self = self else { return true }
            let result = self.updateView(with: item, isFromSearch: true).isUpdated
            if !result {
                self.searchController?.dismiss(animated: false)
                self.searchController?.removeChildrenView()
                self.searchController = nil
            }
            return result
        }
        self.searchController?.favouriteDelegate = self
        self.searchController?.onClickGameplay = { game,additionalParams in
            self.didClickedPlay(with: game, additionalParams: additionalParams)
        }
        if let searchSuggestions = self.searchSuggestions {
            self.searchController?.searchSuggestions = searchSuggestions
        }
        if let webCategories = self.subNavigationItems?[.webCategories]?.compactMap({ $0.title }) {
            self.searchController?.searchWebCategories = webCategories
        }
    }
    
    private func loadCommonSearchViewController(with voiceSearchEnabled: Bool) {
        self.casinoSearchController = SearchViewController.show(dataSource: self, isEnabledSpeech: voiceSearchEnabled, on: self)
        self.casinoSearchController?.didDismissed = { [weak self] in
            guard let self = self else { return }
            self.didGameUnloadedOnDownloadFailOrCancel()
            self.casinoSearchController?.removeChildrenView()
            self.casinoSearchController = nil
        }
        /// checking whether selected category from suggestions is of type webcategory or not
        /// if it is webcategory then we are closing the search controller otherwise updating the games in the result colletionview
        self.casinoSearchController?.onClickCategory = {[weak self] item in
            guard let self = self else { return true }
            let result = self.updateView(with: item, isFromSearch: true).isUpdated
            if !result {
                self.casinoSearchController?.dismiss(animated: false)
                self.casinoSearchController?.removeChildrenView()
                self.casinoSearchController = nil
            }
            return result
        }
        self.casinoSearchController?.favouriteDelegate = self
        self.casinoSearchController?.onClickGameplay = { game, additionalParams in
            self.didClickedPlay(with: game, additionalParams: additionalParams)
        }
        if let searchSuggestions = self.searchSuggestions {
            self.casinoSearchController?.searchSuggestions = searchSuggestions
        }
    }
    
    @objc private func resetSearchButtonFrame() {
        UIView.animate(withDuration: 0.3, delay: 0, options: [.curveLinear]) {
            self.searchButtonBottomConstraint.constant = kBottomSearchButtonBottomConstraint
            self.searchButtonWidthConstraint.constant = kBottomSearchButtonWidthConstraint
            self.bottomSearchContainerView.alpha = 1
            self.view.layoutIfNeeded()
        }
    }
    
    private func loadLobbyPage() {
        self.categorySelected = false
        self.epcotCategoryModel.isLinkedCategory = false
        self.removeSeeMoreGamesCollectionViewController()
        self.immersiveGamesCollectionViewController?.isCategorySelected = false
        self.immersiveGamesCollectionViewController?.showJackpotTileDetails = (false, nil)
        self.epcotCategoryModel.selectedItems.removeAll()
        if self.isFavouriteSelected {
            self.updateBurgerMenuandSubNavigationContent()
            self.isFavouriteSelected = false
        } else {
            if var subNavigationCategories = self.subNavigationItems?[.categories] {
                let selectedItem = subNavigationCategories.filter({ $0.isSelected == true })
                selectedItem.forEach({ $0.isSelected = false })
                if !self.isHomePillNeeded, !subNavigationCategories.isEmpty {
                    //MARK: - Removing first category item for epcot category section
                    subNavigationCategories.removeFirst()
                }
                self.epcotCategoryModel.items = subNavigationCategories
            }
        }
        if let homeCategory = self.feedModel?.firstCategory {
            self.updateLobbyGames(with: homeCategory)
        }
    }
}

//MARK: - View controller button action method implementation.
extension EpcotLobbyViewController {
    @IBAction func didClickOnBottomSearchButton(_ sender: UIButton) {
        sender.tapAnimation {
            self.didGameUnloadedOnDownloadFailOrCancel()
            self.searchButtonInitialFrame = self.bottomSearchContainerView.frame
            UIView.animate(withDuration: 0.4, delay: 0, options: [.curveLinear]) {
                self.searchButtonBottomConstraint.constant += kDefaultKeyBoardHeight
                self.searchButtonWidthConstraint.constant = self.view.frame.width
                self.bottomSearchContainerView.alpha = 0.6
                self.view.layoutIfNeeded()
                let searchVersion = EpcotLobbyManager.shared?.datasource?.searchVersion ?? .v1
                switch searchVersion {
                case .v1:
                    self.loadCommonSearchViewController(with: false)
                case .v2:
                    self.presentCasinoSearchView(isVoiceCommand: false,
                                                 onGameTap: self.onSearchGameTap)
                }
            }
        }
        UserDefaults.userOnboardingSearch = true
        Haptics.play(.light)
    }
}

    //MARK: - reload will be called on succesfull response from feed service and Game controller download from AWS
extension EpcotLobbyViewController {
    ///Reload LobbyPage
    /// -Parameters:
    ///   - shouldRefetchData: Accepts bool to check if
    func reload(shouldRefetchData: Bool = false) {
        self.trackLobbyEventIfNeeded()
        if shouldRefetchData {
            self.siteCoreMenuItems?.removeAll()
            self.epcotCategoryModel.items.removeAll()
            self.epcotCategoryModel.selectedItems.removeAll()
            self.menuController?.removeChildrenView()
            self.menuController = nil
            self.refreshLobbyMetaData()
            self.addShimmerView()
            self.removeSeeMoreGamesCollectionViewController()
        } else {
            DispatchQueue.main.async {
                self.epcotCategoryModel.selectedItems.removeAll()
                self.immersiveGamesCollectionViewController?.reload()
                self.updateBurgerMenuandSubNavigationContent()
                self.shimmerReceivedResponse(with: .games)
                self.updateMostSearchedGames()
            }
        }
    }
    
    func onLogout() {
        self.gamePremiereViewController?.rootView.viewModel.clean()
        self.gamePremiereViewController = nil
    }
    
    private func trackLobbyEventIfNeeded() {
        if let _ = EntainContext.user?.ssoKey {
            let log = GtmLog(pageViewLog: PageViewLog(accountID: EntainContext.user?.accountId ?? "",
                                                      country: EntainContext.user?.countryCode ?? "",
                                                      pageTrackerID: pageTrackerID,
                                                      pageName: pageName,
                                                      pageLanguage: EntainContext.app?.lang ?? "",
                                                      labelName: EntainContext.app?.brandTitle ?? ""))
            let event = TrackerEvent(type: .pageView, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
    ///This method fetch menu and categories data from sitecore
    ///Assigns sitecoreItems to searchcontroller
    private func updateBurgerMenuandSubNavigationContent() {
        if let categoryNames = self.feedModel?.categoryIds {
            let siteCoreViewModel = SiteCoreCategoriesViewModel(categories: categoryNames)
            siteCoreViewModel.onRequestCategoryName = { [weak self] id in
                return self?.feedModel?.getCategoryName(for: id) ?? ""
            }
            siteCoreViewModel.gamesCountHandler = { [weak self] catgoryId,stickerId in
                self?.feedModel?.getGameCount(cateogryId: catgoryId, stickerId: stickerId)
            }
            let (subNavItems, burgerItems) = siteCoreViewModel.fetchSiteCoreItems()
            if let subNavItems = subNavItems, let categories = subNavItems[.categories], !(categories.isEmpty) {
                let selectedItem = categories.filter({ $0.isSelected == true })
                selectedItem.forEach({ $0.isSelected = false })
                self.setupSubNavigationItems(with: subNavItems)
            } else {
                self.setupSubNavigationItems(with: [.categories : siteCoreViewModel.defaultSubNavigationItems])
            }
            if let burgerItems = burgerItems {
                self.siteCoreMenuItems = burgerItems
            }
        }
    }
    
    private func setupSubNavigationItems(with items: SubNavigationItems) {
        self.subNavigationItems = items
        if let categories = items[.categories] {
            self.epcotCategoryModel.selectedItems.removeAll()
            self.epcotCategoryModel.items = categories
            var sitecoreCategories = categories
            if let webCategories = items[.webCategories] {
                webCategories.forEach { item in
                    sitecoreCategories.removeAll(where: { $0.parameters?.id == item.parameters?.id })
                }
                self.searchController?.searchWebCategories = webCategories.compactMap({ $0.title })
            }
            self.updateSearchSuggestions(with: sitecoreCategories)
            self.switcherCategoriesHeaderView?.selectedCategory = sitecoreCategories.first
            self.selectedCategory = nil
            if let firstCategory = sitecoreCategories.first?.parameters?.id {
                self.updateSelctedCateogrytoAPP(categoryId: firstCategory)
            }
            self.shimmerReceivedResponse(with: .categories)
            categoryPublishedModel.siteCoreItems = sitecoreCategories
            var entainItems = sitecoreCategories
            if !isHomePillNeeded, !entainItems.isEmpty {
                //MARK: - Removing first category item for epcot category section
                entainItems.removeFirst()
            }
            epcotCategoryModel.items = entainItems
            epcotCategoryModel.isLinkedCategory = false
            categoryPublishedModel.currentId = sitecoreCategories.first(where: {$0.parameters?.id == self.selectedCategory})?.uuid ?? sitecoreCategories.first?.uuid ?? UUID()
            loadDeepLinkForCategoriesSelectionIfAny()
        }
    }
    
    private func updateSearchSuggestions(with items: [EntainSiteCoreItem]) {
        self.searchSuggestions = items
        self.searchController?.searchSuggestions = items
        self.casinoSearchController?.searchSuggestions = items
    }
}

//MARK: - Feed view model call back methods
extension EpcotLobbyViewController {
    
    // MARK: - Feed service fetch call on view did Load and some certain condtions.
    final func refreshLobbyMetaData() {
        /// Initiating the jackpot tiles view model, so that subscriber will be included on launch itself.
        JackpotTileOrderViewModel.shared.getNativeWidgetsBasedOnRoute(feedDatasource: self)
        self.feedModel?.clean()
        /// Hide close button if previously selected, since feed is reloaded
        self.feedModel = nil
        self.feedModel = FeedViewModel()
        self.feedModel?.didUpdateJackpotAmount = {
            self.reloadItems()
        }
        
        if let result = feedModel?.fetchCachedResponse() {
            self.didFinish(error: nil)
        }
        
        self.feedModel?.didUpdateLiveFeedData = { [weak self] liveFeed in
            self?.immersiveGamesCollectionViewController?.liveFeedInfoSubject.send(liveFeed)
        }
        
        Task(priority: .high, operation: {
            let result = try await self.feedModel?.refreshLobbyMetaData()
            let error = result?.error
            if error == nil {
                self.isLmtResponseLoaded = true
            }
            if result?.isLoadingNeeded ?? true {
                self.didFinish(error: error)
            }
        })
    }
    
    final func onLoggedIn() {
        DispatchQueue.global().asyncAfter(deadline: .now() + 0.2) {
            Task(priority: .high, operation: {
                if let userName = EntainContext.user?.accountName {
                    UserDefaults.standard.set("\(userName)", forKey: "UserName")
                }
                try await self.feedModel?.refreshLobbyMetaData()
                DispatchQueue.main.async {
                    self.epcotCategoryModel.selectedItems.removeAll()
                    self.immersiveGamesCollectionViewController?.reload()
                    self.updateBurgerMenuandSubNavigationContent()
                    self.shimmerReceivedResponse(with: .games)
                }
            })
        }
    }
    
    /// This method will get called on successful downloading of the game controller from AWS.
    final func onFinishLoadingCasinoGames() {
        self.isCGLoaded = true
        if self.feedModel != nil, self.feedViewModel?.feedModel != nil {
            self.reload()
        }
    }
    
    ///This method will get called on successful downloading of game (gets called from EpcotLobbyManager)
    /// - Parameters:
    ///   - game: Game variant name which user selected in the lobby
    ///   - state: game downloaded state
    func didFinishDownloadingGame(game: String, state: Bool) {
        if self.feedViewModel?.didUpdatedGameInCache(game: game, value: state) ?? false {
            self.reloadItems(game)
        }
    }
    
    func didFinishedGamePlay() {
        self.immersiveGamesCollectionViewController?.reloadVideoTeaserOnGamePlayDismiss(isPresenting: false)
        if self.feedViewModel?.isRPGamesFetchEnabled ?? false {
            Task {
                do {
                    try await self.feedViewModel?.fetchAndUpdateRecentlyPlayedGames()
                    if let rpGames = self.feedViewModel?.recentlyPlayedGames {
                        if let siteCoreCategoryItems = self.subNavigationItems?[.categories], !siteCoreCategoryItems.contains(where:{ $0.parameters?.id == kLmcRecentlyPlay }) {
                            self.updateBurgerMenuandSubNavigationContent()
                        }
                        self.immersiveGamesCollectionViewController?.reloadRecentlyPlayedGamesSection()
                    }
                } catch {
                    ETLogger.debug(error.localizedDescription)
                }
            }
        }
    }
    
    func didGameUnloadedOnDownloadFailOrCancel() {
        self.immersiveGamesCollectionViewController?.reloadVideoTeaserOnGamePlayDismiss()
    }
}

//MARK: - Feed view model update methods
extension EpcotLobbyViewController {
    
    private func didFinish(error: Error?) {
        guard error == nil else {
            if let _error = error as? NSError,
               _error.code == NSURLErrorCancelled {
                return
            } else if error?.localizedDescription == "Lobby url missing." {
                return
            } else if error?.localizedDescription == "request_in_progress" {
                return
            } else {
                self.showErrorAlert(with: error)
            }
            self.sendErrorLog(with: error)
            return
        }
        let content = POSAPI.shared?.casinoStoriesContent
        if gameStoriesConfig?.isGameStoriesEnabled ?? false, content != nil {
            self.fetchGameStoriesContent()
        }
        self.setupGamesWindow()
        self.updateLobby()
        if isLmtResponseLoaded {
            self.loadDeeplinkForCategories(urlStr: deepLinkUrl ?? "")
        }
    }
    
    /// It will display the error alert to the user on fetching the lmt data from the API service. on Reload action, it will fetch the service response again and on cancel action it will close the alert window.
    private func showErrorAlert(with error: Error?) {
        if Reachability.isConnectedToNetwork() {
            DispatchQueue.main.async {
                EpcotLobbyManager.shared?.delegate?.didLobbyLoaded()
                var descpription = Localize.reloadLobby
                if let errorMessage = error?.localizedDescription {
                    descpription += "\n" + errorMessage
                }
                if EntainContext.app?.isCustomThemeEnabled ?? false {
                    EpcotLobbyManager.shared?.delegate?.showAlertViewWith(title: Localize.error,
                                                                          description: descpription,
                                                                          buttons: [Localize.reload, Localize.cancelButtonTitle.capitalizingFirstLetter()],
                                                                          attributedDescription: nil,
                                                                          completion: { index, action in
                        if index == 1 {
                            self.refreshLobbyMetaData()
                        }
                    })
                } else if let topViewController = UIApplication.topViewController() {
                    let okAction = UIAlertAction(title: Localize.reload,
                                                 style: .default) { action in
                        self.refreshLobbyMetaData()
                    }
                    let cancelAction = UIAlertAction(title: Localize.cancelButtonTitle.capitalizingFirstLetter(),
                                                     style: .cancel)
                    topViewController.showAlert(Localize.error,
                                                descpription,
                                                [okAction, cancelAction])
                }
            }
        }
    }
    
    /// Method will send the error log to the dashboard
    /// - Parameter error: Error description.
    private func sendErrorLog(with error: Error?) {
        let lobbyLog = LobbyLog(message: "Error on retriving the lobby Feed",
                                errorMsg: "\(String(describing: error?.localizedDescription))",
                                screen: "\(#file)")
        let webViewError = WebViewErrorsLogs(url: "Error",
                                             errorCode: "\(#file) FeedService Error",
                                             errorMsg: "\(String(describing: error?.localizedDescription))")
        KibanaLogManager.sendLogs(of: .webviewError, with: webViewError)
    }
    
    /// Method will update the lobby with new loaded games and it will remove the loader from the view.
    private func updateLobby() {
        guard self.isCGLoaded else { return }
        self.reload()
        self.removeLoader()
        if EntainContext.user?.ssoKey != nil {
            CasinoGamesAccessor.instance?.loadPreLoginGamesIfAny()
        }
    }
    
    private func reloadItems(_ gameVariant: String? = nil) {
        DispatchQueue.main.async {
            self.immersiveGamesCollectionViewController?.reloadItem(gameVariant)
            self.searchController?.searchResultsGridViewController?.reloadItem(gameVariant)
            self.casinoSearchController?.searchResultsGridViewController?.reloadItem(gameVariant)
            if let _ = self.seeMoreGamesCollectionViewController {
                self.immersiveGamesCollectionViewController?.view.isHidden = true
                self.seeMoreGamesCollectionViewController?.view.isHidden = false
                self.seeMoreGamesCollectionViewController?.applySnapshot()
            } else {
                self.immersiveGamesCollectionViewController?.view.isHidden = false
            }
        }
    }
    
}

// MARK: - CleanProtocol
extension EpcotLobbyViewController: CleanProtocol {
    func clean() {
        ETLogger.debug("cleaning \(self)")
        self.feedModel?.stopFeedTimers()
        self.feedModel = nil
        NotificationCenter.default.removeObserver(self)
        self.removeCategoryHeaderViews()
        self.epcotLobbySearchView?.didTappedOnMenu = nil
        self.epcotLobbySearchView?.didTappedOnSearch = nil
        self.epcotLobbySearchView?.removeFromSuperview()
        self.epcotLobbySearchView = nil
        self.lobbySearchView?.didTappedOnMenu = nil
        self.lobbySearchView?.didTappedOnSearch = nil
        self.lobbySearchView?.removeFromSuperview()
        self.lobbySearchView = nil
        self.searchController?.removeChildrenView()
        self.searchController = nil
        self.casinoSearchController?.removeChildrenView()
        self.casinoSearchController = nil
        self.menuController?.removeChildrenView()
        self.menuController = nil
        self.viewShimmer?.removeFromSuperview()
        self.viewShimmer = nil
        self.epcotShimmerController?.removeChildrenView()
        self.epcotShimmerController = nil
        self.immersiveShimmerController?.removeChildrenView()
        self.immersiveShimmerController = nil
        self.seeMoreGamesCollectionViewController?.removeChildrenView()
        self.seeMoreGamesCollectionViewController = nil
        self.mostSearchedViewModel = nil
        self.clearLobby()
    }
    
    func dismissChildViewsIfAny() {
        self.searchController?.dismiss(animated: false)
        self.casinoSearchController?.dismiss(animated: false)
        self.menuController?.dismiss(animated: false)
    }
    
    /// remove and clean method remove all the instances for child subviews and removes from view heirerachy as well.
    final func removeAndClean() {
        self.cleanAll()
        self.removeChild()
        self.willMove(toParent: nil)
        self.removeFromParent()
        self.view.removeFromSuperview()
    }
}

// MARK: - Game play action call back method
extension EpcotLobbyViewController {
    private func didClickedPlay(with game: String, additionalParams:AdditionalParameters?) {
        if var metaData = self.feedModel?.getGameMetadata(for: game), let gameVariant = metaData.game {
            self.trackLobbyClickEvent(scrollPercentage: self.immersiveGamesCollectionViewController?.collectionView?.scrollPercentage ?? 0 , gameName: metaData.game ?? "", sectionName: selectedCategory ?? self.subNavigationItems?[.categories]?.first(where: { $0.isSelected == true })?.title ?? "")
            ETLogger.log("Play action invoked, for the game:\(String(describing: metaData.name))")
            metaData.mode = additionalParams?.mode
            KibanaLogManager.sendButtonAction(feature: .lobbyView,
                                              function: #function,
                                              fileName: #file,
                                              remarks: "Play action invoked, for the game:\(String(describing: metaData.name)) provider: \(metaData.provider ?? ""), variantName: \(metaData.game ?? "")")
            DispatchQueue.main.async {
                EpcotLobbyManager.shared?.load(game: gameVariant, additionalParams: additionalParams)
                var categoryName = additionalParams?.location
                if additionalParams?.location != GameSection.search.name {
                    if let categoryId = self.selectedCategory {
                        categoryName = self.feedModel?.getCategoryName(for: categoryId) ?? categoryId
                    } else if let selectedCategoryName = self.subNavigationItems?[.categories]?.first(where: { $0.isSelected == true
                    })?.title {
                        categoryName = selectedCategoryName
                    }
                }
                var location = additionalParams?.location
                if self.immersiveGamesCollectionViewController?.showJackpotTileDetails.show ?? false {
                    location = GameSection.jackptoTiles.name
                }
                self.trackGameLaunchEvent(game: metaData, categoryType: categoryName ?? "", subCategoryType: additionalParams?.subCategoryID ?? "", location: location ?? "")
            }
        }
    }
}

// MARK: - EpcotLobbyGamesDataSource
extension EpcotLobbyViewController: LobbyFeedDataSource  {
    var feedViewModel: FeedViewModel? {
        self.feedModel
    }
}

//MARK: - Update view based on category selection.
extension EpcotLobbyViewController {
    /// method will update the view based on categoryId, if categoryId is empty or not available in LMT response it will redirect to webview otherwise it will update the category selection window and games
    /// - Parameters:
    ///   - category: EntainSiteCoreItem
    ///   - isFromSearch: boolen value to update the categoty selection
    /// - Returns: return tuple, isUpdated: if webcategory is selected value is false  otherwise true, categoryId from LMT/Sitecore
    private func updateView(with category: EntainSiteCoreItem, isFromSearch: Bool = false) -> (isUpdated: Bool,categoryId: String?) {
        if let webCategories = self.subNavigationItems?[.webCategories],
           let webCategory = webCategories.first(where: {$0.parameters?.id == category.parameters?.id}) {
            EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .categories(webCategory), buttonType: nil)
            return (false,nil)
        } else {
            guard let categoryId = category.parameters?.id, (self.feedModel?.categoryIds?.contains(categoryId) ?? false) || (categoryId == kLmcLiveCasino) else {
                EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .categories(category), buttonType: nil)
                return (false,nil)
            }
            if !isFromSearch {
                if self.lobbyheaderViewType != .lobbyExploreSwitcher, self.subNavigationItems?[.categories]?.first(where: { $0.isSelected == true })?.parameters?.id == categoryId {
                    return(false, categoryId)
                }
                self.updateSelctedCateogrytoAPP(categoryId: categoryId)
            }
            return (true,categoryId)
        }
    }
}

//MARK: - Categories Header Setup
extension EpcotLobbyViewController {
    ///Configure headerView
    ///Add headerView w.r.t lobbyHeaderType
    private func configureCategoriesHeaderView() {
        self.removeCategoryHeaderViews()
        self.filterContainerView.backgroundColor = css?.navigationView?.backgroundColor
        self.categoriesHeightConstraint.constant = self.lobbyheaderViewType?.height ?? 44.0
        switch self.lobbyheaderViewType {
        case .gamesCategories, .wheelOfFortuneCategories:
            self.setupGamesCategoriesView(isShadowRequired: self.lobbyheaderViewType == .gamesCategories)
        case .lobbyExploreSwitcher:
            self.setupSwitcherCategoriesView()
        case .epcotCategoryPills:
            self.setupEpcotCategoriesView()
        default:
            self.setupGamesCategoriesView()
        }
        categoryPublishedModel.headerType = self.lobbyheaderViewType ?? .gamesCategories
    }
    
    private func removeCategoryHeaderViews() {
        self.switcherCategoriesHeaderView?.removeFromSuperview()
        self.switcherCategoriesHeaderView = nil
    }
    
    /// Setup Games categoryView
    ///Implements common Games category view
    private func setupGamesCategoriesView(isShadowRequired: Bool = false) {
        func updateItems(with categoryId: String?) {
            let isFirstCategory = (self.categoryPublishedModel.siteCoreItems.first?.parameters?.id ?? "")  == categoryId
            self.immersiveGamesCollectionViewController?.isCategorySelected = !isFirstCategory
            self.selectedCategory = categoryId
            self.updateSelctedCateogrytoAPP(categoryId: categoryId ?? "")
            self.updateLobbyGames(with: categoryId)
            self.subNavigationItems?[.categories]?.compactMap({$0.isSelected = false})
            self.subNavigationItems?[.categories]?.first(where: {$0.parameters?.id == categoryId})?.isSelected = true
            if !isFirstCategory {
                self.immersiveGamesCollectionViewController?.reloadVideoTeaserOnGamePlayDismiss(isPresenting: false)
            }
        }
        
        if self.lobbyheaderViewType == .wheelOfFortuneCategories {
            let hostingView = UIHostingController(rootView: WOFCategoryView(order: self.categoryPublishedModel, onClickCategory: { categoryItem in
                var isLobbyUpdated = false
                if let siteCoreItem = categoryItem, self.updateView(with: siteCoreItem).isUpdated {
                    updateItems(with: siteCoreItem.parameters?.id)
                    isLobbyUpdated = true
                }
                return isLobbyUpdated
            }))
            hostingView.view.backgroundColor = .clear
            self.configureChildViewController(childController: hostingView, onView: self.categoryContentView)
        } else {
            let hostingView = UIHostingController(rootView: GamesCategoryView(order: self.categoryPublishedModel, onClickCategory: { categoryItem in
                UserDefaults.userOnboardingCategory = true
                var isLobbyUpdated = false
                if let siteCoreItem = categoryItem, self.updateView(with: siteCoreItem).isUpdated {
                    updateItems(with: siteCoreItem.parameters?.id)
                    isLobbyUpdated = true
                }
                return isLobbyUpdated
            }))
            hostingView.view.backgroundColor = .clear
            self.configureChildViewController(childController: hostingView, onView: self.categoryContentView)
        }
        self.categoryContentView.backgroundColor = css?.gridView?.categoryViewbackgroundColor
        if isShadowRequired {
            self.categoryContentView.dropShadow(color: css?.navigationView?.shadowColor ?? .black, offSet: CGSize(width: 3, height: 3), shadowRadius: 5)
            self.categoryContentView.superview?.bringSubviewToFront(self.filterContainerView)
        }
    }
    
    /// Configure Switcher type Categories
    private func setupSwitcherCategoriesView() {
        if self.switcherCategoriesHeaderView == nil {
            self.switcherCategoriesHeaderView = SwitcherCategoryHeaderView.load(delegate: self)
        }
        self.switcherCategoriesHeaderView?.configure(on: self.filterContainerView)
        self.switcherCategoriesHeaderView?.selectedCategory = EntainSiteCoreItem()
    }
    
    ///Configure Categories for Epcot
    ///Displays categories in pill layout
    private func setupEpcotCategoriesView() {
        let categoryView = EpcotCategoriesView(viewModel: epcotCategoryModel) { action in
            switch action {
            case .close(let entainSiteCoreItem):
                self.epcotCategoryModel.isLinkedCategory = false
                if self.immersiveGamesCollectionViewController?.showJackpotTileDetails.show ?? false {
                    let model = self.immersiveGamesCollectionViewController?.showJackpotTileDetails.model
                    self.trackSliderEvent(categoryEvent: EpcotEventCategory.jackpotTiles.rawValue,
                                          actionEvent: EpcotEventAction.backNavigation.rawValue,
                                          labelEvent: model?.titleText ?? "",
                                          eventDetails: EpcotEventDetails.jackpot_tiles_interaction.rawValue,
                                          eventType: .click)
                }
                self.loadPagesOnEpcotCloseAction()
                // originals widget event
                if let categoryId = entainSiteCoreItem.parameters?.id,
                   let linkedCategoryId = POSAPI.shared?.originalsWidgetConfigurations?.linkedCategory,
                   linkedCategoryId == categoryId {
                    self.trackOriginalsNavigationEvent(.categoryPill(categoryId, 0, true))
                }
            case .categorySelection(let entainSiteCoreItem):
                // Need to update the view
                self.immersiveGamesCollectionViewController?.reloadVideoTeaserOnGamePlayDismiss(isPresenting: false)
                self.epcotCategoryModel.isLinkedCategory = false
                self.trackeEvent(location: GtmLogConstants.GeneralConstants.epcotCatgory.rawValue)
                self.selectCategory(entainSiteCoreItem: entainSiteCoreItem,
                                    saveItem: true)
                // originals widget event
                if let categoryId = entainSiteCoreItem.parameters?.id,
                   let linkedCategoryId = POSAPI.shared?.originalsWidgetConfigurations?.linkedCategory,
                   linkedCategoryId == categoryId {
                    let categoryIdIndex = self.epcotCategoryModel.items.firstIndex(where: { $0.parameters?.id == categoryId }) ?? 0
                    self.trackOriginalsNavigationEvent(.categoryPill(categoryId, categoryIdIndex, false))
                }
            case .grid(_), .list(_):
                self.switchCollectionViewLayout(with: action)
            }
        }
        let hostingView = UIHostingController(rootView: categoryView)
        hostingView.view.backgroundColor = .clear
        self.configureChildViewController(childController: hostingView,
                                          onView: self.categoryContentView)
        self.categoryContentView.backgroundColor = css?.epcotLobbyCSS?.categoriesViewBGColor
    }
    
    private func selectCategory(entainSiteCoreItem: EntainSiteCoreItem, saveItem: Bool = false) {
        self.epcotCategoryModel.isLinkedCategory = false
        self.categorySelected = true
        let result = self.updateCategorySelection(with: entainSiteCoreItem,
                                                  saveItem: saveItem)
        if result {
            if let items = self.subNavigationItems?[.categories],
                var selectedItem = items.first(where: {$0.parameters?.id == entainSiteCoreItem.parameters?.id}) {
                selectedItem.isSelected = true
                self.epcotCategoryModel.items = [selectedItem]
            }
        }
    }
    
    private func loadPagesOnEpcotCloseAction() {
        var isRemovedPageIsSeemore: Bool = false
        
        if !self.epcotCategoryModel.selectedItems.isEmpty {
            isRemovedPageIsSeemore = self.epcotCategoryModel.selectedItems.last?.isSeeMoreItem ?? false
            self.epcotCategoryModel.selectedItems.removeLast()
        }
        if !self.epcotCategoryModel.selectedItems.isEmpty,
           let previousPage = self.epcotCategoryModel.selectedItems.last {
            if previousPage.isSeeMoreItem ?? false,
               let categoryId = previousPage.categoryId,
               let subCategoryId = previousPage.subCategoryId {
                //See more page
                self.didClickedSeeMore(with: categoryId, subCategoryId: subCategoryId)
                self.epcotCategoryModel.isLinkedCategory = true
            } else if let model = previousPage.jackpotModel {
                //Jackpot Page
                self.didClickedOnJackpotTile(with: model)
            } else {
                self.selectCategory(entainSiteCoreItem: previousPage.item)
            }
            if isRemovedPageIsSeemore {
                self.removeSeeMoreGamesCollectionViewController(applyNewSnapshot: false)
            }
        } else {
            self.loadLobbyPage()
        }
    }
}

//MARK: - Favourites reload notification
extension EpcotLobbyViewController {
    func didUpdateCategoriesCollectionOnFavouritesUpdate(gameVariant: String? = nil, is seeMoreSection: Bool = false) {
        if let isCategorySelected = self.immersiveGamesCollectionViewController?.isCategorySelected, isCategorySelected {
            if self.selectedCategory == kLmcFavourites {
                if let favGames = self.feedViewModel?.favouriteGames, favGames.isEmpty {
                    self.immersiveGamesCollectionViewController?.isCategorySelected = false
                    self.updateBurgerMenuandSubNavigationContent()
                }
                self.immersiveGamesCollectionViewController?.applySnapshot(with: self.selectedCategory, for: true)
            } else {
                self.isFavouriteSelected = true
                if let categoryNames = self.feedModel?.categoryIds,
                    let currentSubNavItems = self.subNavigationItems?[.categories] {
                    let currentCategories = currentSubNavItems.map({ $0.parameters?.id })
                    if categoryNames != currentCategories {
                        self.refreshSubNavigationItemsForSwitcherPopUp(is: seeMoreSection)
                    }
                }
                self.immersiveGamesCollectionViewController?.reloadItem(gameVariant)
            }
        } else {
            self.immersiveGamesCollectionViewController?.reloadItem(gameVariant)
            guard let favGames = self.feedViewModel?.favouriteGames, !favGames.isEmpty else {
                self.updateBurgerMenuandSubNavigationContent()
                return
            }
            if let siteCoreCategoryItems = self.subNavigationItems?[.categories], !siteCoreCategoryItems.contains(where:{ $0.parameters?.id == kLmcFavourites }) {
                self.updateBurgerMenuandSubNavigationContent()
            }
        }
    }
    
}

//MARK: - ImmersiveCollection Delegate
extension EpcotLobbyViewController: ImmersiveLobbyCollectionControllerDelegate {
    func didTappedOnFavourites(gameVariant: String, state: Bool,from seeMoreSection: Bool) {
        guard let isLoggedIn = EntainContext.user?.isLoggedIn(), isLoggedIn else { return }
        Task {
            if let _ = try? await self.feedViewModel?.updateFavouriteState(with: state, for: gameVariant) {
                self.immersiveGamesCollectionViewController?.reloadItem(gameVariant, isFavouriteUpdate: true)
                self.didUpdateCategoriesCollectionOnFavouritesUpdate(is: seeMoreSection)
                var favState: FavouriteState = state ? .selected : .unselected
                self.didUpdateFavourite(gameVariant: gameVariant, state: favState, from: seeMoreSection)
            }
        }
    }
    
    func didOriginalWidgetExpired() -> Bool {
        return isOriginalWidgetExpired
    }
    
    func didUpdateFavourite(gameVariant: String, state: FavouriteState, from seeMoreSection: Bool) {
        self.didUpdateCategoriesCollectionOnFavouritesUpdate(gameVariant: gameVariant, is: seeMoreSection)
        guard
            let config = favoriteToastConfig,
            config.isFavoriteToastEnabled else {
            return
        }
        let gameInfo = feedViewModel?.getImmersiveInfo(for: gameVariant, with: "\(LayoutType.verticalImmersiveGrid.rawValue)")
        var isCtaEnabled = config.isCTAEnabled
        if seeMoreGamesCollectionViewController != nil || seeMoreSection {
            isCtaEnabled = false
        }
        if state == .selected {
            favoriteViewModel.update(gameInfo: gameInfo,
                                     enableCTA: isCtaEnabled)
        }
        self.searchController?.displayFavoriteToastView(with: favoriteViewModel, state: state)
        self.casinoSearchController?.displayFavoriteToastView(with: favoriteViewModel, state: state)
        self.immersiveGamesCollectionViewController?.seeMoreController?.displayFavoriteToastView(with: favoriteViewModel, state: state)
        displayFavoriteToastView(state: state)
    }
}

//MARK: - Switcher Header Delegate
extension EpcotLobbyViewController: SwitcherCategoryHeaderViewDelegate {
        
    func didClickedOnCategoryButton(sender: UIButton) {
        if let items = self.subNavigationItems?[.categories] {
            let switcherPopup = SwitcherCategoriesPopupView.show(on: sender,
                                                                 siteCoreCategories: items)
            switcherPopup?.onCategorySelection = { [weak self] item, location in
                self?.trackeEvent(location: location)
                self?.updateCategorySelection(with: item)
                return true
            }
        }
    }
    /// Refresh Categories Header on favourites update
    func refreshSubNavigationItemsForSwitcherPopUp(is seeMoreSection: Bool = false) {
        let topController = UIApplication.topViewController() as? SeeMoreSectionViewController
        guard !seeMoreSection || topController != nil else { return }
        if isFavouriteSelected, let categoryNames = self.feedModel?.categoryIds {
            self.isFavouriteSelected = false
            
            var siteCoreViewModel = SiteCoreCategoriesViewModel(categories: categoryNames)
            siteCoreViewModel.onRequestCategoryName = { [weak self] id in
                return self?.feedModel?.getCategoryName(for: id) ?? ""
            }
            siteCoreViewModel.gamesCountHandler = { [weak self] categoryId, stickerId in
                self?.feedModel?.getGameCount(cateogryId: categoryId, stickerId: stickerId)
            }
            let (subNavItems, burgerItems) = siteCoreViewModel.fetchSiteCoreItems()
            if let subNavItems = subNavItems, let categories = subNavItems[.categories], !(categories.isEmpty) {
                self.subNavigationItems = subNavItems
            } else {
                self.subNavigationItems = [.categories : siteCoreViewModel.defaultSubNavigationItems]
            }
            if let burgerItems = burgerItems {
                self.siteCoreMenuItems = burgerItems
            }
            
            guard var subNavItems = self.subNavigationItems?[.categories] else {
                return
            }
            subNavItems.first(where: {$0.parameters?.id == self.selectedCategory})?.isSelected = true
           
            self.categoryPublishedModel.siteCoreItems = subNavItems
            
            if let selectedEntainItem = subNavItems.first(where: {$0.isSelected == true}) {
                self.epcotCategoryModel.items = [selectedEntainItem]
            } else {
                var subNavItems = subNavItems
                if !self.isHomePillNeeded, !subNavItems.isEmpty {
                    //MARK: - Removing first category item for epcot category section
                    subNavItems.removeFirst()
                }
                self.epcotCategoryModel.items = subNavItems
            }
            
            let selectedItem = self.categoryPublishedModel.siteCoreItems.first(where: {$0.parameters?.id == self.selectedCategory})?.uuid ?? subNavItems.first(where: {$0.parameters?.id == self.selectedCategory})?.uuid ?? UUID()
            self.categoryPublishedModel.currentId = selectedItem
            if let categories = subNavigationItems?[.categories] {
                var sitecoreCategories = categories
                if let webCategories = subNavigationItems?[.webCategories] {
                    webCategories.forEach { item in
                        sitecoreCategories.removeAll(where: { $0.parameters?.id == item.parameters?.id })
                    }
                    self.searchController?.searchWebCategories = webCategories.compactMap({ $0.title })
                }
                self.updateSearchSuggestions(with: sitecoreCategories)
            }
        }
    }
    
    func didClickedSwitcherToggle() { }
}

extension EpcotLobbyViewController {
    func didClickCategoryFromMenu(category: String?) {
        if let category = category {
            if let item = self.subNavigationItems?[.categories]?.first(where: { $0.parameters?.id == category }) {
                self.updateCategorySelection(with: item)
            }
        }
    }
}

extension EpcotLobbyViewController {
    func loadDeeplinkForCategories(urlStr: String) {
        deepLinkUrl = urlStr
        guard isLmtResponseLoaded else { return }
        if let categories = self.subNavigationItems?[.categories], !categories.isEmpty {
            loadDeepLinkForCategoriesSelectionIfAny()
        }
    }
    
    private func loadDeepLinkForCategoriesSelectionIfAny() {
        guard let urlStr = deepLinkUrl else {
            return
        }
        if let entainSiteCoreItem = self.subNavigationItems?[.categories]?.first(where: { item in
            if let deepLink = item.parameters?.deepLinkUrl, !deepLink.isEmpty {
                return urlStr.hasSuffix(deepLink)
            }
            return false
        }) {
            self.updateSelectedCategory(item: entainSiteCoreItem,
                                        categoryId: entainSiteCoreItem.parameters?.id)

        }
        deepLinkUrl = nil
    }
}

//MARK: - Category selection updates
extension EpcotLobbyViewController {
    /// Updates the selection of Item, if it is not webcategory
    /// - Parameters:
    ///   - item: selected Category Item
    ///   - saveItem: save selected Category Item to not to break the push
    /// - Returns: Boolean whether to highlight the item selection or not
    @discardableResult
    func updateCategorySelection(with item: EntainSiteCoreItem, saveItem: Bool = false) -> Bool {
        let categoryUpdateVariant = self.updateView(with: item)
        if categoryUpdateVariant.isUpdated {
            self.updateSelectedCategory(item: item,
                                        categoryId: categoryUpdateVariant.categoryId,
                                        saveItem: saveItem)
        }
        return categoryUpdateVariant.isUpdated
    }
    /// update Selcted category on Categories Header
    /// - Parameters:
    ///   - item: EntainSiteCoreItem -- category Item
    ///   - categoryId: String -- Category Id
    ///   - subCategoryId: String -- subCategoryId
    ///   - updateLobbyGames: Bool  --  whether to refresh/apply snapshot or not
    ///   - saveItem: save selected Category Item to not to break the push
    private func updateSelectedCategory(item: EntainSiteCoreItem,
                                        categoryId: String?,
                                        subCategoryId: String? = nil,
                                        updateLobbyGames: Bool = true,
                                        saveItem: Bool = true) {
        let previousSelectedItem = self.subNavigationItems?[.categories]?.first(where: { $0.isSelected == true })
        previousSelectedItem?.isSelected = false
        item.isSelected = true
        
        if saveItem {
            let categorySelection = EpcotCategorySelection(item: item, 
                                                           categoryId: categoryId,
                                                           subCategoryId: subCategoryId)
            self.epcotCategoryModel.selectedItems.append(categorySelection)
        }
        //Category Selection Update for Epcot Categories//
        self.epcotCategoryModel.items = [item]
        //Category Selection Update for Switcher Category Header//
        self.switcherCategoriesHeaderView?.selectedCategory = item
        
        //LobbyGamesCollectionViewController Update based on Category//
        self.immersiveGamesCollectionViewController?.isCategorySelected = true
        self.immersiveGamesCollectionViewController?.showJackpotTileDetails = (false, nil)
        
        if let category = categoryId ?? item.parameters?.id {
            if updateLobbyGames {
                self.updateLobbyGames(with: category)
            }
            self.selectedCategory = subCategoryId ?? category
        }
        if let categoryItems = self.subNavigationItems?[.categories] {
            categoryPublishedModel.siteCoreItems = categoryItems
            let selectedUUid = self.categoryPublishedModel.siteCoreItems.first(where: {$0.parameters?.id == categoryId})?.uuid ?? item.uuid
            categoryPublishedModel.currentId = selectedUUid
        }
    }

    private func updateLobbyGames(with category: String?) {
        guard let category = category else { return }
        self.immersiveGamesCollectionViewController?.applySnapshot(with: category)
    }
 
    private func updateSelctedCateogrytoAPP(categoryId: String) {
        if self.lobbyheaderViewType == .wheelOfFortuneCategories {
            EpcotLobbyManager.shared?.delegate?.didSelectWOFCategory(categoryId)
        }
    }
}

extension EpcotLobbyViewController {
    
    private func didClickedOnJackpotTile(with model: JackPotModel, saveItem: Bool = false) {
        let title = model.titleText
        let sitecoreItems = SiteCoreCategoriesViewModel(categories: [title]).fetchSiteCoreItems()
        if var item = sitecoreItems.subNavigationItems?[.categories]?.first(where: {$0.parameters?.id == title}) {
            item.isSelected = true
            item.title = title
            let previousSelectedItem = self.subNavigationItems?[.categories]?.first(where: { $0.isSelected == true })
            previousSelectedItem?.isSelected = false
            
            if saveItem {
                let categoryItem = EpcotCategorySelection(item: item, jackpotModel: model)
                self.epcotCategoryModel.selectedItems.append(categoryItem)
            } else {
                self.immersiveGamesCollectionViewController?.showJackpotTileDetails = (true, model)
            }
            
            //Category Selection Update for Epcot Categories//
            self.epcotCategoryModel.items = [item]
            
            self.categorySelected = true
            self.epcotCategoryModel.isLinkedCategory = false
            self.immersiveGamesCollectionViewController?.applySnapshot()
        }
    }
    
    private func didClickedSeeMore(with category: String, subCategoryId: String, saveItem: Bool = false) {
        self.categorySelected = true
        let name = self.feedViewModel?.getCategoryName(for: subCategoryId) ?? subCategoryId
        guard let games = self.feedViewModel?.getSubCategoryGames(for: subCategoryId, in: category), !games.isEmpty else { return }
        let sitecoreItems = SiteCoreCategoriesViewModel(categories: [subCategoryId]).fetchSiteCoreItems()
        let categories = sitecoreItems.subNavigationItems?[.categories]
        
        if var entainItem = categories?.first(where: { $0.parameters?.id == subCategoryId }) {
            ///making previously selected categories as unselected
            self.subNavigationItems?[.categories]?.forEach({ $0.isSelected == false })
            ///making the see All category as selected
            entainItem.title = name
            entainItem.isSelected = true
            self.updateSelectedCategory(item: entainItem,
                                        categoryId: category,
                                        subCategoryId: subCategoryId,
                                        updateLobbyGames: false,
                                        saveItem: false)
            self.immersiveGamesCollectionViewController?.view.isHidden = true
            self.setupSeeMoreCollectionView(with: games)
            
            if saveItem {
                let categorySelection = EpcotCategorySelection(item: entainItem,
                                                               categoryId: category,
                                                               subCategoryId: subCategoryId,
                                                               isSeeMoreItem: true)
                self.epcotCategoryModel.selectedItems.append(categorySelection)
            }
        }
    }
        
    private func switchCollectionViewLayout(with type: CategoryViewAction) {
        let currentLayoutType: SwitcherCategoryType = EpcotLobbyManager.shared?.lobbySwitcherType ?? .grid
        switch type {
        case .grid(let string):
            guard currentLayoutType == SwitcherCategoryType.list else { return }
            UserDefaults.lobbySwitcherType = SwitcherCategoryType.grid.rawValue
        case .list(let string):
            guard currentLayoutType == SwitcherCategoryType.grid else { return }
            UserDefaults.lobbySwitcherType = SwitcherCategoryType.list.rawValue
        default:
            ETLogger.debug("unknown action")
        }
        let newLayout = currentLayoutType.swappedValue
        self.seeMoreGamesCollectionViewController?.collectionView.setContentOffset(.zero, animated: false)
        self.seeMoreGamesCollectionViewController?.applySnapshot(isFromSwitcher: true)
        self.updateCollectionViewLayoutAppearance(with: newLayout)
    }
    
    private func setupSeeMoreCollectionView(with games: [Game]) {
        self.seeMoreGamesCollectionViewController = SeeMoreSectionCollectionViewController(games: games,
                                                                            datasource: self, cleanOnDisappear: false)
        self.seeMoreGamesCollectionViewController?.onClickGameplay = { (selectedGame, additionalParams) in
            self.didClickedPlay(with: selectedGame, additionalParams: additionalParams)
        }
        self.seeMoreGamesCollectionViewController?.delegate = self
        self.configureChildViewController(childController: self.seeMoreGamesCollectionViewController ?? UIViewController(),
                                          onView: self.mainContentView)
    }
    
    private func updateCollectionViewLayoutAppearance(with layoutType: SwitcherCategoryType) {
        let layout = layoutType == .grid ? seeMoreCollectionViewGridLayout : seeMoreCollectionViewListLayout
        UIView.animate(withDuration: 0.2) { () -> Void in
            self.seeMoreGamesCollectionViewController?.collectionViewLayout.invalidateLayout()
            self.seeMoreGamesCollectionViewController?.collectionView.setCollectionViewLayout(layout, animated: true)
        }
    }
    
    private func removeSeeMoreGamesCollectionViewController(applyNewSnapshot: Bool = true) {
        if let _ = self.seeMoreGamesCollectionViewController {
            self.seeMoreGamesCollectionViewController?.removeChildrenView()
            self.seeMoreGamesCollectionViewController = nil
            self.immersiveGamesCollectionViewController?.view.isHidden = false
            if applyNewSnapshot {
                self.immersiveGamesCollectionViewController?.applySnapshot()
            }
        }
    }

}

extension EpcotLobbyViewController {
    private func trackeEvent(location: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = PageViewLog(categoryEvent: GtmLogConstants.GeneralConstants.epcotLobby.rawValue,
                                  labelEvent: GtmLogConstants.GeneralConstants.epcotLobby.rawValue,
                                  actionEvent: GtmLogConstants.GeneralConstants.categoryClick.rawValue,
                                  positionEvent: GtmLogConstants.PageViewLogConstants.categorySelectionAction.rawValue,
                                  locationEvent: GtmLogConstants.GeneralConstants.epcotLobby.rawValue,
                                  eventDetails: location,
                                  urlClicked: GtmLogConstants.GeneralConstants.notApplicable.rawValue)
            
            let event = TrackerEvent(type: .click, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
    private func trackLobbyClickEvent(scrollPercentage: Int, gameName: String, sectionName: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.nativeCasinoLobby.rawValue,
                                     actionEvent:EpcotEventAction.click.rawValue,
                                     labelEvent: "\(scrollPercentage)",
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: gameName,
                                     positionEvent: sectionName)
            
            let event = TrackerEvent(type: .lobbyClicks, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
    private func trackGameLaunchEvent(game: GameMetaData, categoryType: String, subCategoryType: String, location: String) {
        let newGameIndex: Int = self.feedViewModel?.getIndex(for: game.game) ?? 0
        if let gameVariant = game.game,
           let gameInfo = self.feedViewModel?.getGameInfo(with: gameVariant) {
            let favouriteState = gameInfo.userGameInfo?.favouriteState ?? false
            let downloadState = gameInfo.userGameInfo?.localDownloadState ?? false
            let log = GameLaunchLog(name: game.name ?? "",
                                    position: "\(newGameIndex)",
                                    category: location,
                                    grid: GameEvents.GameGrid.not_applicable.rawValue,
                                    type: game.provider ?? "",
                                    favourite: favouriteState == true ? GameEvents.GameFavourite.favourite.rawValue : GameEvents.GameFavourite.non_favourite.rawValue,
                                    gameId: game.game ?? "",
                                    status: downloadState ? GameEvents.GameStatus.existing.rawValue : GameEvents.GameStatus.new.rawValue,
                                    containerloc: location == GameSection.search.name ? GameEvents.GameContainerlocation.search.rawValue : GameEvents.GameContainerlocation.lobby.rawValue,
                                    containerdesc: GameEvents.GameContainerdesc.not_applicable.rawValue,
                                    categoryType: categoryType,
                                    categorySubtype: subCategoryType,
                                    playingStatus: GameEvents.GamePlayingStatus.start.rawValue)
            
            let event = TrackerEvent(type: .gameOpen, log: log, tracker: .gtm)
            let gameLog = GameLog(play: String(true),
                                  favourite: String(favouriteState),
                                  name: game.name,
                                  provider: game.provider)
            let lobbyLogs = LobbyLog(game: gameLog,
                                     screen: location)
            KibanaLogManager.sendLogs(of: .lobbyLogs,
                                      with: lobbyLogs)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
    private func trackToasterAndOverlaysEvents(categoryEvent: String, title: String, positionEvent: String, eventType: EventType) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = PageViewLog(categoryEvent: categoryEvent,
                                  labelEvent: title,
                                  actionEvent: EpcotEventAction.load.rawValue,
                                  positionEvent: positionEvent,
                                  locationEvent: ScreenName.casino.rawValue,
                                  eventDetails: GtmLogConstants.GeneralConstants.notApplicable.rawValue)
            
            let event = TrackerEvent(type: eventType, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}

extension EpcotLobbyViewController {
    
    func showToastersController(toasterModel: ToasterModel) {
        let toasterVC = ToastersHostingController(toaster: toasterModel)
        if let toasterView = toasterVC.view {
            toasterView.backgroundColor = .clear
            toasterView.translatesAutoresizingMaskIntoConstraints = false
            toasterView.accessibilityIdentifier = kToasterAccessibility
            AlertCoordinator.showView(toasterView)
        }
    }
    
    func showOverlaysController(overlayModel: OverlayModel) {
        let overlaysCSS = OverlaysCSSModel()
        let overlaysVC = OverlaysHostingController(overlay: overlayModel)
        overlaysVC.view.backgroundColor = UIColor(overlaysCSS.overlayBgColor)
        overlaysVC.modalPresentationStyle = .overFullScreen
        AlertCoordinator.showView(overlaysVC)
    }
    
}


extension EpcotLobbyViewController {
    func shimmerReceivedResponse(with type: ShimmerReceivedResponseType) {
        self.shimmerResponseType[type] = true
        self.removeShimmerWindowIfNotRequired()
    }
}

//MARK: Adding Accessibility Identifiers
extension EpcotLobbyViewController {
    private func addAccessibilityIdentifiers() {
        searchContainerView.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobby_searchContainerView.rawValue
        filterContainerView.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobby_filterContainerView.rawValue
        mainContentView.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobby_mainContentView.rawValue
        categoryContentView.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobby_categoryContentView.rawValue
        favoriteToastView.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobby_favoriteToastView.rawValue
        bottomSearchContainerView.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobby_bottomSearchContainerView.rawValue
        searchBottomButton.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobby_searchBottomButton.rawValue
    }
}

extension EpcotLobbyViewController: OriginalsWidgetDelegate {
    func didUpdateExpiryStatus(with status: Bool) {
        self.isOriginalWidgetExpired = status
        self.immersiveGamesCollectionViewController?.isOriginalsWidgetExpired = status
        DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
            if status {
                self.originalsOverlayController?.dismiss(animated: true)
                self.originalsOverlayController = nil
                self.originalWidgetViewModel?.dispose()
                self.originalWidgetViewModel = nil
            }
        })
    }
}
