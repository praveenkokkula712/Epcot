//
//  TeaserVideosCustomCell.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 26/06/23.
//

import UIKit
import CoreMedia
import GSPlayer
import AVFoundation
import Combine

fileprivate let kshimmerLayer = "shimmerLayer"

protocol TeaserVideosCustomCellDelegate: AnyObject {
    func didTapOnPlayButton(videoCell: TeaserVideosCustomCell)
}

class TeaserVideosCustomCell: EpcotBaseCollectionViewCell {
    weak var teaserVideoDelegate: TeaserVideosCustomCellDelegate?

    @IBOutlet private weak var containerView: UIView!
    @IBOutlet private weak var speakerButton: UIButton!
    @IBOutlet private weak var playNowButton: UIButton!
    @IBOutlet private weak var videoPlayerView: VideoPlayerView!
    @IBOutlet private weak var imageView: UIImageView!
    @IBOutlet private weak var playButton: UIButton!
   
    private var pagingInfoToken: AnyCancellable?

    private var isFirstTimeLoading = true
    var isPlaying = false {
        didSet {
            playButton.isSelected = isPlaying
        }
    }
    
    private var isVideoPlayingFirstTime: Bool = true
    
    var teaserInfo: NativeWidgetsModel? {
        didSet {
            guard let teaserWidgetInfo = teaserInfo,
                  let teaserVideoString = teaserWidgetInfo.imageOrVideoUrl,
                  let teaserVideoUrl = URL(string: teaserVideoString) else { return }
            if UIDevice.isIPad() {
                self.imageThumbnailUrl =  teaserInfo?.imageThumbnail
            } else {
                self.playTeaserVideo(videoUrl: teaserVideoUrl)
            }
        }
    }
    
    private var imageThumbnailUrl: String? {
        didSet {
            if let imageUrl = imageThumbnailUrl {
                self.imageView.loadImage(withUrl: imageUrl)
            }
        }
    }
    // AVPlayer
    var isMuted:Bool = true {
        didSet {
            videoPlayerView?.player?.isMuted = self.isMuted
            speakerButton.isSelected = isMuted
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.setPlayerView()
        self.updateView()
        TeaserVideosCacheManager.clearCacheIfNeeded()
        if !UIDevice.isIPad() {
            NotificationCenter.default.addObserver(self,
                                                   selector: #selector(reloadVideo),
                                                   name: NSNotification.Name.AVPlayerItemDidPlayToEndTime,
                                                   object: videoPlayerView?.player?.currentItem)
        }
        self.addAccessibilityIdentifiers()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    //MARK: - update View
    private func updateView() {
        self.playButton.isHidden = !UIDevice.isIPad() 
        let shimmerColor = CasinoCSS.lobby?.epcotLobbyCSS?.shimmerGradients ?? ShimmerGradients()
        self.applyShimmerLayer(with: shimmerColor)
        self.getRoundedCorners(OfRadius: 16)
        
        self.containerView.layer.cornerRadius = 16
        self.containerView.layer.masksToBounds = true
        
        let gameCellCSS = EpcotLobbyManager.shared?.css.gamesCell
        self.speakerButton.layer.cornerRadius = gameCellCSS?.speakerButtonCornerRadius ?? 17.5
        self.speakerButton.backgroundColor = gameCellCSS?.speakerButtonBackgroundColor
        self.speakerButton.tintColor = gameCellCSS?.speakerButtonTintColor
        self.playButton.layer.cornerRadius = gameCellCSS?.speakerButtonCornerRadius ?? 17.5
        self.playButton.backgroundColor = gameCellCSS?.speakerButtonBackgroundColor
        self.playButton.tintColor = gameCellCSS?.speakerButtonTintColor

        if CasinoCSS.lobby?.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false {
            self.playNowButton.applyEpcotGradientBgColor()
        } else {
            let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS?.immersiveCSS
            self.playNowButton.backgroundColor = gameCellCSS?.playButton?.normal
            self.playNowButton.titleLabel?.font =  gameCellCSS?.downloadButton?.title?.font
            self.playNowButton.setTitleColor(gameCellCSS?.playButton?.title?.color, for: .normal)
            self.playNowButton.getRoundedCorners(OfRadius: css?.downloadIconCornerRdius ?? 4.0)
        }
    }
    
    // MARK: - Setup AVVideoPlayer View
    private func setPlayerView() {
        videoPlayerView.contentMode = .scaleAspectFill
        videoPlayerView.isAutoReplay = true
        videoPlayerView.stateDidChanged = { [weak self] state in
            guard let self = self else { return }
            if self.isFirstTimeLoading {
                self.isMuted = true
                self.isFirstTimeLoading = false
            }
        }
        
    }
    
    private func playTeaserVideo(videoUrl: URL) {
        VideoPreloadManager.shared.set(waiting: [videoUrl])
        videoPlayerView.play(for: videoUrl)
    }
    
    // MARK: - Play Video
    func playVideo() {
        isPlaying = true
        self.removeShimmerLayers()
        self.videoPlayerView?.resume()
        playButton.isSelected = true
    }
    
    // MARK: - Pause Video
    func pauseVideo() {
        if videoPlayerView.state == .playing {
            isPlaying = false
            self.isMuted = true
            videoPlayerView.pause(reason: .userInteraction)
            playButton.isSelected = false
        }
    }
    
    // MARK: - reloadVideo
    @objc func reloadVideo() {
        self.videoPlayerView?.player?.seek(to: CMTime.zero)
        self.videoPlayerView?.player?.play()
    }
    
    //MARK: - Speaker Action
    @IBAction private func didTapOnSpeakerButton(_ sender: UIButton) {
        self.isMuted.toggle()
    }
    
    //MARK: - PlayButton Action(Video play button)
    @IBAction private func didTapOnPlayButton(_ sender: UIButton) {
        self.teaserVideoDelegate?.didTapOnPlayButton(videoCell: self)
        DispatchQueue.main.async {
            sender.isSelected = !sender.isSelected
            guard self.isVideoPlayingFirstTime else {
                self.isPlaying ? self.pauseVideo() : self.playVideo()
                return
            }
            guard let teaserVideoString = self.teaserInfo?.imageOrVideoUrl,
                  let teaserVideoUrl = URL(string: teaserVideoString) else { return }
            self.playTeaserVideo(videoUrl: teaserVideoUrl)
            self.isVideoPlayingFirstTime = false
            self.isPlaying = true
        }
    }
    //MARK: - PlayNow Action
    @IBAction private func didTapOnPlayNowButton(_ sender: UIButton) {
        let instantInteraction = InteractionType.overLay40.interaction
        sender.tapAnimation(type: instantInteraction) {
            if let launchUrl = self.teaserInfo?.videoLaunchUrl {
                self.pauseVideo()
                EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .teaserVideos(launchUrl), buttonType: nil)
            }
        }
    }
    
    private func applyShimmerLayer(with gradients : ShimmerGradients) {
        self.removeShimmerLayers()
        let shimmer = CAGradientLayer.applyShimmerGradient(with: gradients, on: self.videoPlayerView)
        shimmer.name = kshimmerLayer
    }
    
    private func removeShimmerLayers() {
        self.videoPlayerView.layer.sublayers?.forEach({
            if $0.name == kshimmerLayer {
                $0.removeFromSuperlayer()
            }
        })
    }
    
    func subscribeTo(subject: PassthroughSubject<Bool, Never>) {
        pagingInfoToken = subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] startVideoPlay in
                if UIDevice.isIPad() {
                    startVideoPlay ? self?.playVideo() : self?.pauseVideo()
                }
                self?.isMuted = true
            }
    }
}

//MARK: Adding Accessibility Identifiers
extension TeaserVideosCustomCell {
    private func addAccessibilityIdentifiers() {
        containerView.accessibilityIdentifier = AccessibilityIdentifiers.teaservideo_containerView.rawValue
        speakerButton.accessibilityIdentifier = AccessibilityIdentifiers.teaservideo_speakerButton.rawValue
        playNowButton.accessibilityIdentifier = AccessibilityIdentifiers.teaservideo_playNowButton.rawValue
        imageView.accessibilityIdentifier = AccessibilityIdentifiers.teaservideo_imageView.rawValue
        playButton.accessibilityIdentifier = AccessibilityIdentifiers.teaservideo_playVideoButton.rawValue

    }
}
