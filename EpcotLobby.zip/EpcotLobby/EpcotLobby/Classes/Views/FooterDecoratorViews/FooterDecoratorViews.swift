//
//  FooterDecoratorViews.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 29/12/22.
//

import Foundation
import Utility
import UIKit

class FooterBaseDecoratorView: WidgetDecoratorView {
    override var bgColor: UIColor {
        EpcotLobbyManager.shared?.css.nativeFooterViewCSS?.backgroundColor ?? .black
    }
    
    override var topInset: CGFloat {
        return 0.0
    }
    
    override var bottomInset: CGFloat {
        return 0.0
    }
}

class FooterStateDecoratorView: FooterBaseDecoratorView {
    override var bgColor: UIColor {
        EpcotLobbyManager.shared?.css.nativeFooterViewCSS?.stateView?.backgroundColor ?? .black
    }
}

class FooterSeoLinksDecoratorView: FooterBaseDecoratorView {
    override var bgColor: UIColor {
        EpcotLobbyManager.shared?.css.nativeFooterViewCSS?.seolinks?.backgroundColor ?? .black
    }
}

class FooterDivideLineDecoratorView: FooterSeoLinksDecoratorView {

}

class FooterAboutUsDecoratorView: FooterBaseDecoratorView {
    override var bgColor: UIColor {
        EpcotLobbyManager.shared?.css.nativeFooterViewCSS?.aboutUs?.backgroundColor ?? .black
    }
}

class FooterLogosDecoratorView: FooterBaseDecoratorView {

}

class FooterContentDecoratorView: FooterBaseDecoratorView {

}

class FooterCopyRightDecoratorView: FooterBaseDecoratorView {

}
