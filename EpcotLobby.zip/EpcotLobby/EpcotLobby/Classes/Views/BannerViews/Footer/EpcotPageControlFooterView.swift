//
//  EpcotPageControlFooterView.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 09/05/22.
//

import Foundation
import Combine
import UIKit

class EpcotPageControlFooterView: UICollectionReusableView {
    
   let pageControl : PageControlView = {
        var pageControl = PageControlView()
       let dotsColor = EpcotLobbyManager.shared?.css.epcotLobbyCSS?.pageControllerDotsColor ?? UIColor.lightGray
       let selectedDotColor = EpcotLobbyManager.shared?.css.epcotLobbyCSS?.pageControllerDotSelectedColor ?? UIColor.white
       pageControl.drawer = ScaleDrawer(dotsColor: dotsColor, selectedColor: selectedDotColor)
       pageControl.setPage(0)
        return pageControl
    }()
    
    private var pagingInfoToken: AnyCancellable?
    var currentIndex: Int? {
        didSet {
            DispatchQueue.main.async { [weak self] in
                self?.pageControl.setPage(self?.currentIndex ?? 0)
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .clear
        self.pageControl.configure(on: self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func subscribeTo(subject: PassthroughSubject<IndexPath, Never>) {
        pagingInfoToken = subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] page in
                if let row = page.row as? Int {
                    self?.pageControl.setPage(row)
                }
            }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.pagingInfoToken?.cancel()
        self.pagingInfoToken = nil
    }
    
    func updateContentTheme(normalColor: UIColor?, selectedColor: UIColor?) {
        pageControl.drawer.dotsColor = normalColor ?? EpcotLobbyManager.shared?.css.epcotLobbyCSS?.pageControllerDotsColor ?? UIColor.lightGray
        pageControl.drawer.dotSelectedColor = selectedColor ?? EpcotLobbyManager.shared?.css.epcotLobbyCSS?.pageControllerDotSelectedColor ?? UIColor.white
    }
}
