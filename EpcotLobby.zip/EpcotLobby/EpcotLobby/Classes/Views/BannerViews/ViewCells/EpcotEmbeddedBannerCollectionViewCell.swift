//
//  EpcotEmbeddedBannerCollectionViewCell.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 19/05/22.
//

import UIKit
import CasinoAPI

class EpcotEmbeddedBannerCollectionViewCell: EpcotBaseCollectionViewCell {

    @IBOutlet private weak var containerView: UIView!
    @IBOutlet private weak var imageView: UIImageView!
    @IBOutlet private weak var labelTitle: UILabel!
    @IBOutlet private weak var labelSubTitle: UILabel!
    @IBOutlet private weak var buttonBanner: UIButton!
    
    weak var delegate: EpcotBannerCollectionViewCellDelegate?
    
    private var css: EpcotTeasersCSS? {
        EpcotLobbyManager.shared?.css.epcotLobbyCSS?.teasersViewCSS
    }
    
    var globalTeaserInfo: TeaserContentModel?
    
    var bannerInfo: TeaserContentModel? {
        didSet {
            guard let bannerInfo = bannerInfo else {
                return
            }
            self.containerView.backgroundColor = bannerInfo.embeddedBannerBGColor
            bannerInfo.getTitleAttributedText(with: globalTeaserInfo) { text in
                DispatchQueue.main.async {
                    self.labelTitle.attributedText = text
                }
            }
            bannerInfo.getSubTitleAttributedText(with: globalTeaserInfo) { text in
                DispatchQueue.main.async {
                    self.labelSubTitle.attributedText = text
                }
            }
            self.configureBannerButtonContent(with: bannerInfo)
            if let imageUrl = bannerInfo.image {
                self.imageView.loadImage(withUrl: imageUrl)
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.updateView()
        self.addAccessibilityIdentifiers()
    }
    
    //MARK: - update View
    private func updateView(with attributes: Attributes? = nil) {
        self.containerView.layer.cornerRadius = 16
        self.buttonBanner.layer.cornerRadius = 3
        self.containerView.layer.masksToBounds = true
        self.getRoundedCorners(OfRadius: 16)
    }
    
    private func configureBannerButtonContent(with info: TeaserContentModel) {
        self.buttonBanner.isHidden = info.ctaTitle?.isEmpty ?? true
        guard !(info.ctaTitle?.isEmpty ?? true) else { return }
        if EpcotLobbyManager.shared?.css.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false {
            self.buttonBanner.applyEpcotGradientBgColor()
        } else {
            self.buttonBanner.setTitleColor(globalTeaserInfo?.attributes?.teaserCTADefaultFontColor?.hexColor ?? info.ctaButtonTitleColor, for: .normal)
            self.buttonBanner.backgroundColor = globalTeaserInfo?.attributes?.teaserCTADefaultButtonColor?.hexColor ??  info.ctaButtonBackgroundColor
            self.buttonBanner.titleLabel?.font = info.ctaButtonFont
        }
        self.buttonBanner.setTitle(info.ctaTitle, for: .normal)
        if EpcotLobbyManager.shared?.css.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false {
            self.buttonBanner.applyEpcotGradientBgColor()
        }
    }
    
    //MARK: - Action
    @IBAction private func actionBannerButton(_ sender: UIButton) {
        let instantInteraction = InteractionType.overLay40.interaction
        sender.tapAnimation(type: instantInteraction) {
            self.delegate?.didTapped(on: self, type: .cta)
        }
    }
}

//MARK: Adding Accessibility Identifiers
extension EpcotEmbeddedBannerCollectionViewCell {
    private func addAccessibilityIdentifiers() {
        containerView.accessibilityIdentifier = AccessibilityIdentifiers.epcotEmbeddedBanner_containerView.rawValue
        imageView.accessibilityIdentifier = AccessibilityIdentifiers.epcotEmbeddedBanner_imageView.rawValue
        labelTitle.accessibilityIdentifier = AccessibilityIdentifiers.epcotEmbeddedBanner_labelTitle.rawValue
        labelSubTitle.accessibilityIdentifier = AccessibilityIdentifiers.epcotEmbeddedBanner_labelSubTitle.rawValue
        buttonBanner.accessibilityIdentifier = AccessibilityIdentifiers.epcotEmbeddedBanner_buttonBanner.rawValue
    }
}
