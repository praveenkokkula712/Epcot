//
//  EpcotBannerCollectionViewCell.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 29/04/22.
//

import Foundation
import UIKit
import CasinoAPI
import Utility

public enum TeaserButtonType {
    case teaser, cta, terms
}

protocol EpcotBannerCollectionViewCellDelegate: AnyObject {
    func didTapped(on cell: EpcotBaseCollectionViewCell, type: TeaserButtonType)
}

class EpcotBannerCollectionViewCell: EpcotBaseCollectionViewCell {
    
    @IBOutlet private weak var backgroundImageView : UIImageView!
    @IBOutlet private weak var containerView : UIView!
    @IBOutlet private weak var stackViewImageTextHolder : UIStackView!
    @IBOutlet private weak var teaserImageView : UIImageView!
    @IBOutlet private weak var viewTextHolder: UIView!
    @IBOutlet private weak var teaserTitleLabel : UILabel!
    @IBOutlet private weak var teaserSubTitleLabel : UILabel!
    @IBOutlet private weak var teaserCtaButton : UIButton!
    @IBOutlet private weak var labelTerms: UILabel!
    @IBOutlet weak var stackViewTextContent: UIStackView!
    
    weak var delegate: EpcotBannerCollectionViewCellDelegate?
    
    private var css: EpcotTeasersCSS? {
        EpcotLobbyManager.shared?.css.epcotLobbyCSS?.teasersViewCSS
    }
    
    var globalTeaserInfo: TeaserContentModel?
    
    var teaserInfo: TeaserContentModel? {
        didSet {
            guard let teaserInfo = teaserInfo else { return }
            teaserInfo.getTitleAttributedText(with: globalTeaserInfo) { text in
                DispatchQueue.main.async {
                    self.teaserTitleLabel.attributedText = text
                }
            }
            teaserInfo.getSubTitleAttributedText(with: globalTeaserInfo) { text in
                DispatchQueue.main.async {
                    self.teaserSubTitleLabel.attributedText = text
                }
            }
            self.configureImageContent(with: teaserInfo)
            self.configureCtaButtonContent(with: teaserInfo)
            self.configureViews(with: (teaserInfo.teaserImageAlignment ?? teaserInfo.teaserDefaultImageAlignment) ?? .left)
            self.configureTermsButton()
            self.configureStackTextContent(with: teaserInfo)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.updateView()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTermsButtonAction(_:)))
        self.labelTerms.addGestureRecognizer(tapGesture)
        self.addAccessibilityIdentifiers()
    }
    
    @objc private func handleTermsButtonAction(_ tapGesture: UITapGestureRecognizer) {
        self.labelTerms.tapAnimation {
            self.delegate?.didTapped(on: self, type: .terms)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.updateShadow(cornerRadius: 0)
    }
    
    private func updateView() {
        self.contentView.backgroundColor = .clear
        self.contentView.layer.cornerRadius = 10.0
        self.contentView.layer.masksToBounds = true
        self.labelTerms.backgroundColor = self.globalTeaserInfo?.attributes?.teaserDefaultTermsTextBgColor?.hexColor ?? self.css?.termsBackgroundColor
        self.labelTerms.numberOfLines = 2
        self.labelTerms.textColor = self.css?.termsTextColor
        self.labelTerms.font = self.css?.termsTextFont
    }
}

extension EpcotBannerCollectionViewCell {
    
    private func configureViews(with position: TeaserImageAlignment) {
        switch position {
        case .right:
            self.stackViewImageTextHolder.insertArrangedSubview(self.viewTextHolder, at: 0)
            self.stackViewImageTextHolder.insertArrangedSubview(self.teaserImageView, at: 1)
        default:
            self.stackViewImageTextHolder.insertArrangedSubview(self.teaserImageView, at: 0)
            self.stackViewImageTextHolder.insertArrangedSubview(self.viewTextHolder, at: 1)
        }
    }
    
    private func configureCtaButtonContent(with info: TeaserContentModel) {
        self.teaserCtaButton.isHidden = info.ctaTitle?.isEmpty ?? true
        guard !(info.ctaTitle?.isEmpty ?? true) else { return }
        self.teaserCtaButton.setTitle(info.ctaTitle, for: .normal)
        if EpcotLobbyManager.shared?.css.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false {
            self.teaserCtaButton.applyEpcotGradientBgColor()
        } else {
            self.teaserCtaButton.setTitleColor(globalTeaserInfo?.attributes?.teaserCTADefaultFontColor?.hexColor ?? info.ctaButtonTitleColor, for: .normal)
            self.teaserCtaButton.backgroundColor = globalTeaserInfo?.attributes?.teaserCTADefaultButtonColor?.hexColor ?? info.ctaButtonBackgroundColor
            self.teaserCtaButton.titleLabel?.font = info.ctaButtonFont
        }
        self.teaserCtaButton.layer.cornerRadius = self.teaserCtaButton.frame.height/2
        if EpcotLobbyManager.shared?.css.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false {
            self.teaserCtaButton.applyEpcotGradientBgColor()
        }
    }
    
    private func configureImageContent(with info: TeaserContentModel) {
        self.teaserImageView.image = nil
        self.backgroundImageView.image = nil
        if let imageUrl = info.image {
            self.teaserImageView.loadImage(withUrl: imageUrl)
        }
        guard let backgroundImgEnabled = info.showBackgroundImage?.bool, backgroundImgEnabled else {
            let bgColor = (info.backgroundColor?.hexColor ?? globalTeaserInfo?.attributes?.teaserDefaultBgColor?.hexColor) ?? self.css?.teaserBGColor ?? .darkGray
            self.backgroundImageView.backgroundColor = bgColor
            return
        }
        if let imageUrl = info.backgroundImage {
            self.backgroundImageView.loadImage(withUrl: imageUrl)
        }
    }
    
    private func configureTermsButton() {
        guard !(self.teaserInfo?.termstext?.isEmpty ?? true) else {
            self.labelTerms.isHidden = true
            return
        }
        self.labelTerms.isHidden = false
        self.labelTerms.numberOfLines = 2
        self.teaserInfo?.getTermsAttributedText(with: globalTeaserInfo, completion: { text in
            DispatchQueue.main.async {
                self.labelTerms.attributedText = text
            }
        })
        self.labelTerms.sizeToFit()
    }
    
    private func configureStackTextContent(with info: TeaserContentModel) {
        let alignment = (info.titleAlignment ?? globalTeaserInfo?.teaserDefaultTitleAlignment) ?? .center
        switch alignment {
        case .left:
            stackViewTextContent.alignment = .leading
        case .center, .justified, .natural:
            stackViewTextContent.alignment = .center
        case .right:
            stackViewTextContent.alignment = .trailing
        }
    }
    
    @IBAction func didClickOnTeasersCtaButton(_ sender: UIButton) {
        sender.tapAnimation {
            self.delegate?.didTapped(on: self, type: .cta)
        }
    }
}

extension EpcotBannerCollectionViewCell: UIGestureRecognizerDelegate {
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
}

//MARK: Adding Accessibility Identifiers
extension EpcotBannerCollectionViewCell {
    private func addAccessibilityIdentifiers() {
        backgroundImageView.accessibilityIdentifier = AccessibilityIdentifiers.epcotBanner_backgroundImageView.rawValue
        containerView.accessibilityIdentifier = AccessibilityIdentifiers.epcotBanner_containerView.rawValue
        stackViewImageTextHolder.accessibilityIdentifier = AccessibilityIdentifiers.epcotBanner_stackViewImageTextHolder.rawValue
        teaserImageView.accessibilityIdentifier = AccessibilityIdentifiers.epcotBanner_teaserImageView.rawValue
        viewTextHolder.accessibilityIdentifier = AccessibilityIdentifiers.epcotBanner_viewTextHolder.rawValue
        teaserTitleLabel.accessibilityIdentifier = AccessibilityIdentifiers.epcotBanner_teaserTitleLabel.rawValue
        teaserSubTitleLabel.accessibilityIdentifier = AccessibilityIdentifiers.epcotBanner_teaserSubTitleLabel.rawValue
        teaserCtaButton.accessibilityIdentifier = AccessibilityIdentifiers.epcotBanner_teaserCtaButton.rawValue
        labelTerms.accessibilityIdentifier = AccessibilityIdentifiers.epcotBanner_labelTerms.rawValue
        stackViewTextContent.accessibilityIdentifier = AccessibilityIdentifiers.epcotBanner_stackViewTextContent.rawValue

    }
}
