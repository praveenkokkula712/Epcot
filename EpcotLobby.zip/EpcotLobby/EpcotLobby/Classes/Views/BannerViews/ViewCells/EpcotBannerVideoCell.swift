//
//  EpcotBannerVideoCell.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 29/11/23.
//

import UIKit
import CoreMedia
import GSPlayer
import AVFoundation
import Combine
import CasinoAPI
import Utility

protocol EpcotVideoBannerDelegate: AnyObject {
    func didUpdateVideoDuration(duration: Double, urlString: String?)
    func didTapOnPlayButton(videoCell: EpcotBannerVideoCell)
}

fileprivate let kshimmerLayer = "shimmerLayer"
class EpcotBannerVideoCell: EpcotBaseCollectionViewCell {
   
    @IBOutlet private weak var containerView: UIView!
    @IBOutlet private weak var speakerButton: UIButton!
    @IBOutlet private weak var playButton: UIButton!
    @IBOutlet private(set) weak var videoPlayerView: VideoPlayerView!
    @IBOutlet private weak var backgroundImageView: UIImageView!
    
    private var pagingInfoToken: AnyCancellable?

    weak var videoDelegate: EpcotVideoBannerDelegate?
    
    var isPlaying = false {
        didSet {
            playButton.isSelected = isPlaying
        }
    }
    
    var isMuted:Bool = true {
        didSet {
            videoPlayerView?.player?.isMuted = self.isMuted
            speakerButton.isSelected = !isMuted
        }
    }
    var globalTeaserInfo: TeaserContentModel?

    var teaserInfo: TeaserContentModel? {
        didSet {
            guard let teaserInfo = teaserInfo else { return }
            self.configureImageContent(with: teaserInfo)
        }
    }
    
    var index: Int?
    
    private var css: EpcotTeasersCSS? {
        EpcotLobbyManager.shared?.css.epcotLobbyCSS?.teasersViewCSS
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.setPlayerView()
        self.updateView()
        TeaserVideosCacheManager.clearCacheIfNeeded()
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(reloadVideoOnVideoEnd),
                                               name: NSNotification.Name.AVPlayerItemDidPlayToEndTime,
                                               object: videoPlayerView?.player?.currentItem)
        addAccessibilityIdentifiers()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Setup AVVideoPlayer View
    private func setPlayerView() {
        videoPlayerView.contentMode = .scaleAspectFill
        videoPlayerView.isAutoReplay = false
        videoPlayerView.isMuted = true
        videoPlayerView.stateDidChanged = { [weak self] state in
            guard let self = self else { return }
            if case .playing = state {
                let duration = videoPlayerView.totalDuration
                self.videoDelegate?.didUpdateVideoDuration(duration: duration, urlString: videoPlayerView.playerURL?.absoluteString)
            }
        }
    }
    
    //MARK: - update View
    private func updateView() {
        self.playButton.isHidden = !UIDevice.isIPad() 
        let shimmerColor = CasinoCSS.lobby?.epcotLobbyCSS?.shimmerGradients ?? ShimmerGradients()
        self.applyShimmerLayer(with: shimmerColor)
        self.getRoundedCorners(OfRadius: 16)
        
        self.containerView.layer.cornerRadius = 16
        self.containerView.layer.masksToBounds = true
        
        let gameCellCSS = EpcotLobbyManager.shared?.css.gamesCell
        self.speakerButton.layer.cornerRadius = gameCellCSS?.speakerButtonCornerRadius ?? 17.5
        self.speakerButton.backgroundColor = gameCellCSS?.speakerButtonBackgroundColor
        self.speakerButton.tintColor = gameCellCSS?.speakerButtonTintColor
        self.playButton.layer.cornerRadius = gameCellCSS?.speakerButtonCornerRadius ?? 17.5
        self.playButton.backgroundColor = gameCellCSS?.speakerButtonBackgroundColor
        self.playButton.tintColor = gameCellCSS?.speakerButtonTintColor

    }
    // MARK: - reloadVideo
    @objc func reloadVideoOnVideoEnd() {
        self.videoPlayerView?.player?.seek(to: CMTime.zero)
        self.isPlaying = false
    }
    
    func playTeaserVideo(videoUrl: URL) {
        VideoPreloadManager.shared.set(waiting: [videoUrl])
        self.videoPlayerView?.player?.seek(to: CMTime.zero)
        self.videoPlayerView.play(for: videoUrl)
        self.videoPlayerView.player?.isMuted = true
    }
    
    func playVideo() {
        isPlaying = true
        self.removeShimmerLayers()
        self.videoPlayerView?.player?.seek(to: CMTime.zero)
        self.videoPlayerView?.player?.play()
    }
    // MARK: - Pause Video
    func pauseVideo() {
        if videoPlayerView.state == .playing {
            isPlaying = false
            self.isMuted = true
            videoPlayerView.pause(reason: .userInteraction)
        }
    }
    
    func reloadVideoPlayer() {
        if videoPlayerView.state == .playing {
            self.pauseVideo()
        } else {
            self.playVideo()
        }
    }
    
    private func configureImageContent(with info: TeaserContentModel) {
        self.backgroundImageView.image = nil
        guard let backgroundImgEnabled = info.showBackgroundImage?.bool, backgroundImgEnabled else {
            let bgColor = (info.backgroundColor?.hexColor ?? globalTeaserInfo?.attributes?.teaserDefaultBgColor?.hexColor) ?? self.css?.teaserBGColor ?? .darkGray
            self.backgroundImageView.backgroundColor = bgColor
            return
        }
        if let imageUrl = info.backgroundImage {
            self.backgroundImageView.loadImage(withUrl: imageUrl)
        }
    }
    
    //MARK: - Speaker Action
    @IBAction private func didTapOnSpeakerButton(_ sender: UIButton) {
        self.isMuted.toggle()
    }
    
    @IBAction private func didTapOnPlayButton(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        self.videoDelegate?.didTapOnPlayButton(videoCell: self)
    }
    
    func subscribeTo(subject: PassthroughSubject<(Int,URL?), Never>) {
        pagingInfoToken = subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] (index,videoUrl) in
                if UIDevice.isIPad() {
                    self?.pauseVideo()
                    return
                }
                if self?.index == index {
                    if let videoUrl {
                        if self?.videoPlayerView.state != .playing {
                            self?.playTeaserVideo(videoUrl: videoUrl)
                        }
                    } else {
                        self?.pauseVideo()
                    }
                }
                self?.isMuted = true
            }
    }
    
    override func prepareForReuse() {
        self.pagingInfoToken?.cancel()
        self.pagingInfoToken = nil
        self.videoPlayerView.player?.pause()
        self.isMuted = true
        if let teaserInfo {
            self.configureImageContent(with: teaserInfo)
        }
        super.prepareForReuse()
    }
    
    private func applyShimmerLayer(with gradients : ShimmerGradients) {
        self.removeShimmerLayers()
        let shimmer = CAGradientLayer.applyShimmerGradient(with: gradients, on: self.videoPlayerView)
        shimmer.name = kshimmerLayer
    }
    
    private func removeShimmerLayers() {
        self.videoPlayerView.layer.sublayers?.forEach({
            if $0.name == kshimmerLayer {
                $0.removeFromSuperlayer()
            }
        })
    }
}


//MARK: Adding Accessibility Identifiers
extension EpcotBannerVideoCell {
    private func addAccessibilityIdentifiers() {
        containerView.accessibilityIdentifier = AccessibilityIdentifiers.epcotBannerVideo_containerView.rawValue
        speakerButton.accessibilityIdentifier = AccessibilityIdentifiers.epcotBannerVideo_speakerButton.rawValue
        playButton.accessibilityIdentifier = AccessibilityIdentifiers.epcotBannerVideo_playVideoButton.rawValue
        videoPlayerView.accessibilityIdentifier = AccessibilityIdentifiers.epcotBannerVideo_videoPlayerView.rawValue
        backgroundImageView.accessibilityIdentifier = AccessibilityIdentifiers.epcotBannerVideo_imageView.rawValue

    }
}
