//
//  EpcotRecentlyPlayedHeader.swift
//  ARAMessageFactory
//
//  Created by Gostu Bhargavi on 21/04/22.
//

import UIKit

class EpcotSectionHeader: EpcotBaseHeaderView {
    
    var css: LobbyCSS? {
        EpcotLobbyManager.shared?.css
    }
    
    var layoutType: LayoutType? {
        didSet {
            if let layoutType {
                self.configureViewsForJackpotWidgets(with: layoutType)
            }
        }
    }
    
    var route: String? {
        didSet {
            guard let route else { return }
            let jackpotViewModel = JackpotWidgetsViewModel.shared
            let colorAttributes = jackpotViewModel.attributes[route] as? [String: Any]
            if let titleHexCode = colorAttributes?[kTitleDisplayColor] as? String, !titleHexCode.isEmpty,
                let titleColor = titleHexCode.hexColor {
                self.titleLabel.textColor = titleColor
            }
        }
    }
    
    override func configureView() {
        self.titleLabel.textColor = self.css?.recentlyPlayedView?.title?.color
        self.titleLabel.font = self.css?.recentlyPlayedView?.title?.font
    }
    
    private func configureViewsForJackpotWidgets(with layoutType: LayoutType) {
        var title = self.css?.recentlyPlayedView?.title
        switch layoutType {
        case .jackpotMustGoWidget:
            title = self.css?.jackpotWidgets?.mustGoJackpotHeaderCss?.title
        case .multipleJackpotWidget:
            title = self.css?.jackpotWidgets?.multipleJackpotsHeaderCss?.title
        case .jackpotWidget:
            title = self.css?.jackpotWidgets?.singleJackpotHeaderCss?.title
        default:
            title = self.css?.recentlyPlayedView?.title
        }
        self.titleLabel.textColor = title?.color
        self.titleLabel.font = title?.font
    }
}
