//
//  SearchViewController.swift
//  CasinoLobby
//
//  Created by Sumeet Bajaj on 05/03/2020.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import UIKit
import CasinoAPI
import TrackerClient
import Combine

fileprivate let MaxSearchTextFiledLength = 200
fileprivate let SearchTopSpaceValue:CGFloat = 24
fileprivate let erase = "erase"
fileprivate let noResults = "noResults"

protocol SearchViewControllerDelegate {
    func didStartAnimating(sender:Any?)
    func didFinishAnimating(sender:Any?)
}

class SearchViewController: EpcotBaseViewController {
    
    private enum SearchContent {
        case nodata
        case suggestion
        case results
    }
        
    private lazy var searchInputView: NewSearchInputHeaderView? = {
        return NewSearchInputHeaderView.loadSearchInputView(delegate: self)
    }()
    
    @IBOutlet private weak var searchVeiwTopConstraint: NSLayoutConstraint!
    @IBOutlet private weak var containerViewBottomConstraint: NSLayoutConstraint!
    @IBOutlet private weak var hintLabelTopConstraint: NSLayoutConstraint!
    @IBOutlet private weak var hintLabelBottomConstraint: NSLayoutConstraint!
    @IBOutlet private weak var hintLabelHeightConstraint: NSLayoutConstraint!
    @IBOutlet private weak var hintLabelTopConstraintInSearchInputView: NSLayoutConstraint!
    
    @IBOutlet private weak var clearButton : UIButton!
    @IBOutlet private weak var textField : UITextField!
    @IBOutlet private weak var searchView : UIView!
    @IBOutlet private weak var container: UIView!
    @IBOutlet private weak var hintLabel: UILabel!
    @IBOutlet private weak var resultLabel: UILabel!
    @IBOutlet private weak var noDataView: UIView!
    @IBOutlet private weak var noDataIcon: UIButton!
    @IBOutlet private weak var noDataLabel: UILabel!
    @IBOutlet private weak var backButton: UIButton!
    @IBOutlet private weak var shadowView: UIView!
    
    @IBOutlet private weak var headerTitleView : UIView!
    @IBOutlet private weak var searchLabel: UILabel!
    @IBOutlet private weak var titleHeaderBackButton: UIButton!
    @IBOutlet private weak var resultsView : UIView!
    @IBOutlet private weak var resultViewTopConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var favouriteToastBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var favouriteToastView: UIView!
    private var speechRecognizerManager: SpeechRecognizerManager?
    
    private var frame:CGRect = .zero
    private var currentContent: SearchContent! {
        willSet {
            self.removeChild()
        }
        didSet {
            self.noDataView.isHidden = self.currentContent != .nodata
            self.refreshViews()
        }
    }

    private var dataSource: LobbyFeedDataSource?

    var searchSuggestions: [EntainSiteCoreItem] = [EntainSiteCoreItem()] {
        didSet {
            self.suggestionController?.suggestions = self.searchSuggestions
        }
    }
    
    var searchResultsGridViewController: EpcotSearchResultViewController?
    private var searchSubject = PassthroughSubject<String, Never>()
    private var anyCancellable: AnyCancellable?
    
    var didDismissed: (() -> Void)?
    var onClickCategory: ((_ item: EntainSiteCoreItem) -> Bool)?
    var onClickGameplay: GamePlayHandler?
    var toastFavoriteView: FavoriteToasterView?
    
    private var suggestionController: SuggestionViewController?
    
    var delegate:SearchViewControllerDelegate?
    weak var favouriteDelegate: ImmersiveLobbyCollectionControllerDelegate?
    var speechStatus = false
    private var isFavouriteSelected: Bool = false

    fileprivate let isVoiceSearchEnabled: Bool = {
        return EpcotLobbyManager.shared?.datasource?.enableVoiceSearch() ?? false
    }()
    
    private let isBottomSearchEnabled: Bool = {
        return EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .searchButtonEnabled) ?? false
    }()
    
    @discardableResult
    class func show(dataSource: LobbyFeedDataSource,
                    isEnabledSpeech: Bool, on presentingController: UIViewController) -> SearchViewController? {
        let controller = SearchViewController.loadFromNib()
        controller.dataSource = dataSource
        controller.speechStatus = isEnabledSpeech
        controller.modalPresentationStyle = .overFullScreen
        controller.modalPresentationCapturesStatusBarAppearance = true

        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       options: UIView.AnimationOptions.curveEaseInOut,
                       animations: {
            controller.view.transform = CGAffineTransform(translationX: 0, y: 0)
        },completion: { _ in
            if controller.isBottomSearchEnabled {
                presentingController.presentDetail(controller, transitionType: CATransitionType.fade) {
                    if isEnabledSpeech {
                        controller.textField.resignFirstResponder()
                    }
                }
            } else {
                presentingController.present(controller, animated: true) {
                    if isEnabledSpeech {
                        controller.textField.resignFirstResponder()
                    } else if !controller.isBottomSearchEnabled {
                        controller.textField.becomeFirstResponder()
                    }
                }
            }
        })
        return controller
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = EpcotLobbyManager.shared?.css.suggestionView?.backgroundColor
        self.setupViews()
        self.addObservers()
        self.addAccessibilityIdentifiers()
        self.setupPublisher()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if speechStatus {
            self.setUpVoiceRecognizer()
        }
        if isBottomSearchEnabled {
            if UserOnboardingViewModel.shared?.isVoiceSearchJourneyTobeDisplayed ?? false {
                self.textField.resignFirstResponder()
            } else {
                self.searchInputView?.isUserInteractionEnabled = true
                self.searchInputView?.firstResponder = true
                return
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.searchInputView?.showOnBoardingViewIfNeeded()
            }
        }
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        ETLogger.debug("Deinit \(type(of: self))")
    }
    
    private func addObservers() {
        if UIDevice.isIPad() {
            NotificationCenter.default.addObserver(self,
                                                   selector: #selector(didDeviceRotated),
                                                   name: UIDevice.orientationDidChangeNotification,
                                                   object: nil)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if !isBottomSearchEnabled {
            self.setupContainerView()
        }
    }
    
    // MARK: - Custom keyboard input view
    override var inputAccessoryView: UIView? {
        return isBottomSearchEnabled ? searchInputView : nil
    }
    
    override var canBecomeFirstResponder: Bool {
        return isBottomSearchEnabled ? true : false
    }
    
    func setupViews() {
        if isBottomSearchEnabled {
            // Hack to open keypad along with the screen
            self.textField.becomeFirstResponder()
            /// 70 height indicates search input header view height
            self.containerViewBottomConstraint.constant = 70
            self.setupTitleHeaderView()
        } else {
            self.setupSearchView()
            self.setupSearchIcons()
            self.setupTextField()
        }
        self.setupSuggestionController()
        self.setupNoDataView()
        self.setupHintLabel()
        self.setupResultLabel()
    }
    
    @objc private func didDeviceRotated() {
        UserOnboardingViewModel.shared?.hidePopTipViewIfAny()
        self.searchInputView?.showOnBoardingViewIfNeeded()
    }
    
    private func setupPublisher() {
        guard anyCancellable == nil else { return }
        anyCancellable = searchSubject
        // Applying the debounce of 300 milli seconds to recieve the input from the publisher
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
        // Subscribing the upstream on the background thread.
            .subscribe(on: DispatchQueue(label: "search queue"))
        // Converting the string received from upstream to games list
            .flatMap({ value  in
                if let games = self.feedViewModel?.getSearchedGames(with: value) {
                    return Just(games)
                        .eraseToAnyPublisher()
                }
                return Just([Game]())
                    .eraseToAnyPublisher()
            })
        // Receiving the games list on main thread, so that downstream events will be received on main thread.
            .receive(on: RunLoop.main)
        // Updating the UI based on the games.
            .sink(receiveValue: { games in
                self.updateResultController(with: games)
            })
    }
    
    private func clearPublisher() {
        self.anyCancellable?.cancel()
        self.anyCancellable = nil
    }
    
    private func setUpVoiceRecognizer() {
        self.clearButton.isEnabled = false
        self.speechRecognizerManager = SpeechRecognizerManager()
        self.speechRecognizerManager?.setUpSpeechRecognizer { status in
            DispatchQueue.main.async { [weak self] in
                if status {
                    self?.startSpeechRecognizer()
                } else {
                    let title = Localize.alertSpeechTitle
                    let description = Localize.alertMessageForSpeech
                    self?.showPopUpView(alertTitle: title, alertDescription: description)
                    ETLogger.debug("User denied access to speech recognition")
                }
                self?.clearButton.isEnabled = true
            }
        }
        self.speechRecognizerManager?.didFailedToAccessMicrophone = {
            self.didFailedToAccessMicrophone()
        }
        self.speechRecognizerManager?.status = { status in
            self.updateSpeechRecognizerStatus(status)
        }
    }
    
    private func startSpeechRecognizer() {
        self.textField.resignFirstResponder()
        self.speechRecognizerManager?.startRecording(){ [weak self] searchText, isFinal in
            if let text = searchText {
                self?.textField.text = text
                self?.searchInputView?.speechText = text
                if isFinal {
                    self?.search(text: text)
                    self?.trackEvent(searchText: text,
                                     action: EpcotEventAction.voice_search.rawValue,
                                     event: EpcotEventDetails.voice_search.rawValue)
                }
            }
        }
    }
    
    private func showPopUpView(alertTitle: String, alertDescription: String) {
        let okText = Localize.okButtonTitle
        let okAction = UIAlertAction(title: okText, style: .default) { (action) in
            if let settings = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(settings)
            }
        }
        if EntainContext.app?.isCustomThemeEnabled ?? false {
            SpeechRecognitionAccessModel().showVoiceSearchPopUpView(alertTitle: alertTitle, alertDescription: alertDescription)
        } else {
            self.showAlert(alertTitle, alertDescription, [okAction])
        }
    }
    
    private func setupSearchView() {
        self.headerTitleView.isHidden = true
        self.searchView.layer.cornerRadius = .cornerRadius
        self.searchView.layer.borderColor = EpcotLobbyManager.shared?.css.searchView?.layerColor?.cgColor ?? UIColor.clear.cgColor
        self.searchView.layer.borderWidth = 1.0
        self.searchView.layer.masksToBounds = true
        self.searchView.backgroundColor = EpcotLobbyManager.shared?.css.searchView?.backgroundColor ?? UIColor.clear
        self.searchVeiwTopConstraint.constant = frame.origin.y - 20
        self.animateSearchView(value: SearchTopSpaceValue)
        
        self.hintLabelTopConstraintInSearchInputView.constant = 0
        self.hintLabelTopConstraintInSearchInputView.isActive = false
        self.hintLabelTopConstraintInSearchInputView = nil

    }
    
    private func setupTitleHeaderView() {
        self.searchView.isHidden = true
        let css : SearchInputAccessoryViewCSS? = EpcotLobbyManager.shared?.css.searchInputAccessoryViewCSS

        self.headerTitleView.backgroundColor = css?.searchInputHeaderBgColor
        self.titleHeaderBackButton.tintColor = css?.searchInputHeaderBackButtonTintColor
        self.searchLabel.textColor = css?.searchInputHeaderTitleFont?.color
        self.searchLabel.font = css?.searchInputHeaderTitleFont?.font
        
        self.hintLabel.isHidden = true
        self.container.isHidden = false
        self.resultLabel.isHidden = false
        self.shadowView.isHidden = true
        
        self.hintLabelTopConstraint.constant = 0
        self.hintLabelTopConstraint.isActive = false
        self.hintLabelTopConstraint = nil
        self.hintLabelTopConstraintInSearchInputView.isActive = true
        self.hintLabelTopConstraintInSearchInputView.constant = 0
        self.hintLabelBottomConstraint.constant = 0
        self.hintLabelHeightConstraint.constant = 0
        self.resultViewTopConstraint.constant = 0
        self.view.layoutIfNeeded()
    }
    
    private func setupSearchIcons() {
        if isVoiceSearchEnabled {
            self.clearButton.setImage(UIImage(named: microphone,
                                              in: Bundle(for: SearchViewController.self),
                                              compatibleWith: nil)?.withRenderingMode(.alwaysTemplate),
                                      for: .normal)
            
        }
        self.clearButton.tintColor = EpcotLobbyManager.shared?.css.searchView?.backIconColor ?? UIColor.white
        self.backButton.setImage(UIImage(named: kBack,
                                         in: Bundle(for: SearchViewController.self),
                                         compatibleWith: nil)?.withRenderingMode(.alwaysTemplate),
                                 for: .normal)
        
        self.backButton.tintColor = EpcotLobbyManager.shared?.css.searchView?.backIconColor ?? UIColor.black
    }
    
    private func setupContainerView() {
        let shadowPath = UIBezierPath(rect: CGRect(x: 0, y: 0, width: UIDevice.screenSize.width, height: 2))
        self.shadowView.layer.shadowColor = EpcotLobbyManager.shared?.css.suggestionView?.shadowColor?.cgColor ?? UIColor.clear.cgColor
        self.shadowView.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        self.shadowView.layer.shadowOpacity = 1
        self.shadowView.layer.masksToBounds = false
        self.shadowView.layer.shadowRadius = 0
        self.shadowView.layer.shadowPath = shadowPath.cgPath
    }
    
    private func setupTextField() {
        self.textField.textColor = EpcotLobbyManager.shared?.css.titleView?.searchText.color
        self.textField.font = EpcotLobbyManager.shared?.css.titleView?.searchPlacehoder.font
        self.textField.attributedPlaceholder = NSAttributedString(string:Localize.searchTitle, attributes: [NSAttributedString.Key.foregroundColor: EpcotLobbyManager.shared?.css.searchInputAccessoryViewCSS?.searchInputPlaceHolderTextColor])
        self.textField.addTarget(self,
                                 action: #selector(textFieldDidChange(_:)),
                                 for: .editingChanged)
        self.textField.addTarget(self,
                                 action: #selector(textFieldDidEndEditing(_ :)),
                                 for: .editingDidEndOnExit)
    }
    
    private func setupResultLabel() {
        let css = EpcotLobbyManager.shared?.css.suggestionView
        self.resultLabel.font = css?.resultTitle?.font
        self.resultLabel.textColor = css?.resultTitle?.color
        self.resultLabel.textAlignment = .left
        self.resultLabel.backgroundColor = .clear
        self.resultsView.backgroundColor = css?.resultViewBgColor
    }
    
    private func setupHintLabel() {
        let css = EpcotLobbyManager.shared?.css.suggestionView
        self.hintLabel.font = css?.hintTitle?.font
        self.hintLabel.textColor = css?.hintTitle?.color
        self.hintLabel.textAlignment = .left
        self.hintLabel.backgroundColor = .clear
    }
    
    
    private func setupSuggestionController() {
        self.suggestionController = SuggestionViewController()
        self.showSuggestionController()
    }
    
    private func setupNoDataView() {
        let css = EpcotLobbyManager.shared?.css.noDataView
        let gameName = self.feedViewModel?.firstGameName ?? ""
        let categoryId = self.feedViewModel?.firstCategory ?? ""
        let categoryName = self.feedViewModel?.getCategoryName(for: categoryId) ?? ""
        let noGameText = String(format: Localize.oopsNoGame, gameName,categoryName)
        self.noDataLabel.text = noGameText
        self.noDataLabel.textColor = css?.color
        self.noDataLabel.font = css?.font
        self.noDataLabel.textAlignment = .center
        let tintColor = EpcotLobbyManager.shared?.css.suggestionView?.searchIconColor ?? UIColor.white

        self.noDataIcon.setImage(with: kNoResults, tintColor: tintColor, bundle: kEpcotBundle)
    }
    
    private func refreshViews() {
        self.noDataView.isHidden = self.currentContent != .nodata
        self.updateHintLabel()
        self.updateResultLabel()
    }
    
    private func updateResultLabel() {
        self.resultLabel.isHidden = self.currentContent == .nodata || self.searchVeiwTopConstraint.constant != SearchTopSpaceValue
        switch self.currentContent {
        case .suggestion:
            guard let categories = self.feedViewModel?.categoryIds, categories.count > 0 else {
                self.resultLabel.text = ""
                return
            }
            self.resultLabel.text = Localize.someSuggestions
            break
        case .results:
            self.resultLabel.text = Localize.results
            break
        default:
            self.resultLabel.text = ""
            break
        }
    }
    
    private func updateHintLabel() {
        switch currentContent {
        case .nodata:
            let hintLabelHiddenStatus = self.searchVeiwTopConstraint.constant != SearchTopSpaceValue
            self.hintLabel.isHidden = hintLabelHiddenStatus
        case .suggestion:
            let gameName = self.feedViewModel?.firstGameName ?? ""
            let categoryId = self.feedViewModel?.firstCategory ?? ""
            let categoryName = self.feedViewModel?.getCategoryName(for: categoryId) ?? ""
            guard let categories = self.feedViewModel?.categoryIds,
                  categories.count > 0 else {
                      self.hintLabel.text = ""
                      return
                  }
            self.hintLabel.text = String(format: Localize.startTyping, gameName,categoryName)
        case .results:
            self.hintLabel.text = Localize.launchGame
        case .none:
            break
        }
    }
    
    private func animateSearchView(value:CGFloat) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {[weak self] in
            self?.onAnimationStart()
            self?.searchVeiwTopConstraint.constant = value
            UIView.animate(withDuration: 0.35, animations: { [weak self] in
                let alpha = value == SearchTopSpaceValue ? 1 : 0
                self?.view.backgroundColor = EpcotLobbyManager.shared?.css.suggestionView?.backgroundColor?.withAlphaComponent(CGFloat(alpha))
                self?.view.layoutIfNeeded()
            })
            { [weak self] (state) in
                self?.onAnimationComplete()
                if value != SearchTopSpaceValue {
                    self?.dismiss(animated: true, completion: nil)
                }
            }
        }
    }
    
    private func onAnimationStart() {
        self.delegate?.didStartAnimating(sender: self)
        DispatchQueue.main.async {
            self.hintLabel.isHidden = true
            self.container.isHidden = true
            self.resultLabel.isHidden = true
        }
    }
    
    private func onAnimationComplete() {
        if self.searchVeiwTopConstraint.constant == SearchTopSpaceValue {
            DispatchQueue.main.async {
                if self.speechStatus {
                    self.textField.resignFirstResponder()
                }else {
                    self.textField.becomeFirstResponder()
                }
                self.hintLabel.isHidden = false
                self.container.isHidden = false
                self.resultLabel.isHidden = false
            }
        }
        self.delegate?.didFinishAnimating(sender: self)
    }
    
    private func search(text:String?, isFromSuggestion: Bool = false) {
        self.setupPublisher()
        let imageName = text?.count ?? 0 > 0 ? kErase : (isVoiceSearchEnabled ? microphone : "")
        let tintColor = EpcotLobbyManager.shared?.css.searchView?.backIconColor ?? UIColor.white
        self.clearButton.setImage(with: imageName,
                                  tintColor: tintColor,
                                  bundle: kEpcotBundle)
        self.searchInputView?.isMicEnabled = !(text?.count ?? 0 > 0)
        guard let _text = text, _text.count > 0 else {
            // show suggestion view here
            self.showSuggestionController()
            self.clearPublisher()
            return
        }
        
        if isFromSuggestion {
            let games = self.feedViewModel?.getGames(for: text ?? "")
            updateResultController(with: games)
        } else {
            self.searchSubject.send(_text)
        }
    }
    
        /// Will update the view with either result view or no data view based on the games list
        /// - Parameter games: games list fetched from lobby feed object.
    func updateResultController(with games: [Game]?) {
        if  let games, games.count > 0 {
            self.showResultNewGridCVController(games: games)
        } else {
            self.showNoDataController()
        }
    }
    
    private func showResultNewGridCVController(games: [Game]) {
        self.clearSuggestionView()
        if self.currentContent != .results {
            self.searchResultsGridViewController = EpcotSearchResultViewController(datasource: self)
            self.searchResultsGridViewController?.delegate = self
            self.currentContent = .results
            if let controler = self.searchResultsGridViewController {
                self.configureChildViewController(childController: controler, onView: self.container)
            }
        }
        self.searchResultsGridViewController?.didScrolled = { scrollView in
            self.resignResponderIfNeeded(for: scrollView)
            self.searchInputView?.firstResponder = false
        }
        self.searchResultsGridViewController?.onClickGameplay = { game, additionalParams in
            self.onClickGameplay?(game, additionalParams)
            self.resignSearchInputView()
            self.dismissSearchView()
        }
        self.searchResultsGridViewController?.delegate = self
        self.searchResultsGridViewController?.update(games: games)
    }
    
    private func clearSuggestionView() {
        self.suggestionController?.removeChildrenView()
        self.suggestionController?.didCategorySelected = nil
        self.suggestionController?.didScrolled = nil
        self.suggestionController = nil
    }
    
    private func showSuggestionController() {
        self.clearSearchResultGridView()
        self.suggestionController = SuggestionViewController()
        self.suggestionController?.suggestions = self.searchSuggestions
        if self.currentContent != .suggestion, let controller = self.suggestionController {
            self.currentContent = .suggestion
            self.configureChildViewController(childController: controller, onView: self.container)
            controller.didCategorySelected = { [weak self] category in
                guard let self else { return }
                if let result = self.onClickCategory?(category),result,
                    let categoryId = category.parameters?.id,
                    !categoryId.isEmpty  {
                    self.didCategorySelected(with: categoryId)
                }
            }
            controller.didScrolled = {[weak self] scrollView in
                guard let self else { return }
                self.resignResponderIfNeeded(for: scrollView)
                self.searchInputView?.firstResponder = false
            }
        }
    }
    
    private func clearSearchResultGridView() {
        self.searchResultsGridViewController?.clean()
        self.searchResultsGridViewController?.removeChildrenView()
        self.searchResultsGridViewController = nil
    }
    
    private func showNoDataController() {
        if self.currentContent != .nodata {
            self.clearSuggestionView()
            self.clearSearchResultGridView()
            self.currentContent = .nodata
            self.noDataView.isHidden = false
        }
    }
    
    ///method will pop the current visible view controller
    @IBAction private func backButtonAction(_ sender: Any) {
        self.resignSearchInputView()
        self.dismissSearchView()
    }
    
    private func resignSearchInputView() {
        if self.isBottomSearchEnabled {
            self.searchInputView?.firstResponder = false
            self.searchInputView?.searchTextField.inputAccessoryView = nil
            self.searchInputView?.removeFromSuperview()
            self.searchInputView?.removeAllSubViews()
            self.searchInputView?.isHidden = true
            self.searchInputView = nil
            NotificationCenter.default.post(name: Notification.Name(rawValue: kResetBottomSearchLayout), object: nil)
        }
    }
    
    private func dismissSearchView() {
        EpcotLobbyManager.shared?.setupAudioSessionForBackgroundAudio()
        self.textField.resignFirstResponder()
        self.textField.text = nil
        self.shadowView.layer.shadowColor = UIColor.clear.cgColor
        self.clearSearchResultGridView()
        self.clearSuggestionView()
        self.speechRecognizerManager?.stopRecording()
        self.speechRecognizerManager = nil
        
        self.dismiss(animated: isBottomSearchEnabled) { [weak self] in
            guard let self = self else { return }
            self.didDismissed?()
            self.clean()
        }
    }
    
    private func clean() {
        self.dataSource = nil
        self.didDismissed = nil
        self.onClickGameplay = nil
        self.delegate = nil
        self.favouriteDelegate = nil
        self.onClickCategory = nil
        self.clearPublisher()
    }
    
    /// Methods will clears the entered text
    @IBAction private func clearButtonAction(_ sender: Any) {
        if isVoiceSearchEnabled {
            if let text = self.textField.text, !(text.isEmpty) {
                self.textField.text = nil
                self.search(text: nil)
            } else {
                self.setUpVoiceRecognizer()
                KibanaLogManager.sendButtonAction(feature: .searchView,
                                                  function: #function,
                                                  fileName: #file,
                                                  remarks: "search games in search window from Voice Search:\(self.textField.text ?? "")")
            }
        } else {
            self.textField.text = nil
            self.search(text: nil)
        }
    }
    
    private func resignResponderIfNeeded(for scrollView: UIScrollView) {
        if scrollView.isTracking, self.textField.isFirstResponder {
            self.textField.resignFirstResponder()
        }
    }
    
}
// MARK: - EpcotLobbyCollectionViewDelegate & EpcotLobbyFeedDataSource

extension SearchViewController: LobbyFeedDataSource {
    
    var feedViewModel: FeedViewModel? {
        self.dataSource?.feedViewModel
    }
}

extension SearchViewController:UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        self.search(text: textField.text)
    }
    
    @objc func textFieldDidEndEditing(_ textField: UITextField) {
        if let text = textField.text, !text.isEmpty {
            ETLogger.debug("###### tracker called: text: \(text)")
            self.trackTextChange(with: text)
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return (range.location < MaxSearchTextFiledLength) && (string.count < MaxSearchTextFiledLength)
    }
}

// MARK: - EpcotLobbyCollectionViewDelegate
extension SearchViewController: ImmersiveLobbyCollectionControllerDelegate {
    func didTappedOnFavourites(gameVariant: String, state: Bool, from seeMoreSection: Bool) {
        self.favouriteDelegate?.didTappedOnFavourites(gameVariant: gameVariant, state: state,from: seeMoreSection)
    }
}

extension SearchViewController {
    func didCategorySelected(with id: String) {
        KibanaLogManager.sendButtonAction(feature: .searchView,
                                          function: #function,
                                          fileName: #file,
                                          remarks: "Category games selected from search window for the category:\(id)")
        let categoryName = self.feedViewModel?.getCategoryName(for: id)
        if isBottomSearchEnabled {
            self.searchInputView?.selectedCategory = categoryName ?? ""
            self.searchInputView?.firstResponder = false
        } else {
            self.textField.text = categoryName
            self.textField.resignFirstResponder()
        }
        self.search(text: id, isFromSuggestion: true)
        self.trackEvent(categoryName: categoryName ?? "")
    }
}

// MARK: - SearchInputViewDelegate
extension SearchViewController: NewSearchInputHeaderViewDelegate {
    func didTapOnMicButton(isVoiceEnabled: Bool) {
        UserOnboardingViewModel.shared?.hidePopTipViewIfAny()
        if isVoiceEnabled {
            self.speechStatus = true
            self.setUpVoiceRecognizer()
            
            if isVoiceSearchEnabled {
                self.clearButton.setImage(UIImage(named: microphone,
                                                  in: Bundle(for: SearchViewController.self),
                                                  compatibleWith: nil)?.withRenderingMode(.alwaysTemplate),
                                          for: .normal)
                
            }
        }
    }
    
    func didChangeSearchText(inputString: String) {
        self.search(text: inputString)
    }
    
    func didChageSearchTextTracker(inputString: String) {
        ETLogger.debug("#### Tracker for text : \(inputString)")
        self.trackTextChange(with: inputString)
    }
    
    private func trackTextChange(with text: String) {
        self.trackEvent(searchText: text,
                        action: EpcotEventAction.manual_search.rawValue,
                        event: EpcotEventDetails.manual_search.rawValue)
    }
}

extension SearchViewController {
    
    func updateSpeechRecognizerStatus(_ status: SpeechRecognizerStatus) {
        self.searchInputView?.isVoiceSearchStarted = status == .start
        let micIconColor = EpcotLobbyManager.shared?.css.searchView?.searchMicIcon ?? UIColor.blue
        let backIconColor = EpcotLobbyManager.shared?.css.searchView?.backIconColor ?? UIColor.white
        self.clearButton.tintColor = status == .start ? micIconColor : backIconColor
    }
    
    func didFailedToAccessMicrophone() {
        let title = Localize.alertMicrophoneTitle
        let description = Localize.alertMessageForMicrophone
        self.showPopUpView(alertTitle: title, alertDescription: description)
        ETLogger.debug("User denied access to speech recognition")
        KibanaLogManager.sendButtonAction(feature: .searchView,
                                          function: #function,
                                          fileName: #file,
                                          remarks: Localize.alertMessageForMicrophone)
    }
}

extension SearchViewController {
    private func trackEvent(searchText: String,
                            action: String,
                            event: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.globalSearch.rawValue,
                                     actionEvent: action,
                                     labelEvent: EpcotEventLabel.globalSearch.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: event,
                                     positionEvent: EpcotEventPosition.navigationTopBar.rawValue,
                                     termSearch: searchText)
            
            let event = TrackerEvent(type: .globalSearch, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
    private func trackEvent(categoryName: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.globalSearch.rawValue,
                                     actionEvent:EpcotEventAction.click.rawValue,
                                     labelEvent: EpcotEventLabel.search_interaction.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: categoryName,
                                     positionEvent: EpcotEventPosition.suggested_search_result.rawValue)
            
            let event = TrackerEvent(type: .globalSearch, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}

//MARK: Adding Accessibility Identifiers
extension SearchViewController {
    private func addAccessibilityIdentifiers() {
        clearButton.accessibilityIdentifier = AccessibilityIdentifiers.search_clearButton.rawValue
        textField.accessibilityIdentifier = AccessibilityIdentifiers.search_textField.rawValue
        searchView.accessibilityIdentifier = AccessibilityIdentifiers.search_searchView.rawValue
        container.accessibilityIdentifier = AccessibilityIdentifiers.search_container.rawValue
        hintLabel.accessibilityIdentifier = AccessibilityIdentifiers.search_hintLabel.rawValue
        resultLabel.accessibilityIdentifier = AccessibilityIdentifiers.search_resultLabel.rawValue
        noDataView.accessibilityIdentifier = AccessibilityIdentifiers.search_noDataView.rawValue
        noDataIcon.accessibilityIdentifier = AccessibilityIdentifiers.search_noDataIcon.rawValue
        noDataLabel.accessibilityIdentifier = AccessibilityIdentifiers.search_noDataLabel.rawValue
        backButton.accessibilityIdentifier = AccessibilityIdentifiers.search_backButton.rawValue
        shadowView.accessibilityIdentifier = AccessibilityIdentifiers.search_shadowView.rawValue
        headerTitleView.accessibilityIdentifier = AccessibilityIdentifiers.search_headerTitleView.rawValue
        searchLabel.accessibilityIdentifier = AccessibilityIdentifiers.search_searchLabel.rawValue
        titleHeaderBackButton.accessibilityIdentifier = AccessibilityIdentifiers.search_titleHeaderBackButton.rawValue
        resultsView.accessibilityIdentifier = AccessibilityIdentifiers.search_resultsView.rawValue
        favouriteToastView.accessibilityIdentifier = AccessibilityIdentifiers.search_favouriteToastView.rawValue
    }
}
