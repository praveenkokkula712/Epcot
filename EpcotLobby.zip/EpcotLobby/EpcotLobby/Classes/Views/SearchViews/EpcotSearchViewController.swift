//
//  SearchViewController.swift
//  EpcotLobby
//
//  Created by Challa Venkata Narasimha Karthik on 31/03/22.
//

import UIKit
import CasinoAPI
import TrackerClient
import Combine

/// Epcot search view, Includes serach suggestions, search, results and hint
class EpcotSearchViewController: EpcotBaseViewController {
    
    private enum SearchContent {
        case nodata
        case suggestion
        case results
    }
    
    @IBOutlet private weak var viewTitle: UIView!
    @IBOutlet private weak var labelTitle: UILabel!
    @IBOutlet private weak var buttonDone: UIButton!
    @IBOutlet private weak var clearButton: UIButton!
    @IBOutlet private weak var textField: UITextField!
    @IBOutlet private weak var searchView: UIView!
    @IBOutlet private weak var container: UIView!
    @IBOutlet private weak var noDataView: UIView!
    @IBOutlet private weak var noDataIcon: UIButton!
    @IBOutlet private weak var noDataLabel: UILabel!
    @IBOutlet private weak var iconSearch: UIButton!
    @IBOutlet weak var headerSeperatorView: UIView!
    @IBOutlet weak var topContainerView: UIView!
    @IBOutlet weak var searchResultLabel: UILabel!
    
    @IBOutlet weak var favouriteToastBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var favouriteToastView: UIView!
    
    var toastViewFavorite: FavoriteToasterView?
    
    var searchSuggestions: [EntainSiteCoreItem] = [EntainSiteCoreItem()] {
        didSet {
            self.suggestionController?.suggestions = self.searchSuggestions
            self.searchResultLabel.isHidden = false
            if self.currentContent == .suggestion {
                self.searchResultLabel.text = Localize.allCategories + " (\(self.searchSuggestions.count))"
            }
        }
    }
    var searchWebCategories: [String]?
    private var anyCancellable: AnyCancellable?
    private var searchSubject = PassthroughSubject<String,Never>()
    
    var speechStatus = false
    private var speechRecognizerManager: SpeechRecognizerManager?
    private var frame: CGRect = .zero
    
    private var currentContent: SearchContent? {
        willSet {
            self.removeChild()
        }
        didSet {
            self.noDataView.isHidden = self.currentContent != .nodata
        }
    }
    
    fileprivate let isVoiceSearchEnabled: Bool = {
        return EpcotLobbyManager.shared?.datasource?.enableVoiceSearch() ?? false
    }()
    
    private var hideLabels: Bool = true {
        didSet {
            self.container.isHidden = hideLabels
        }
    }
    
    var didDismissed: (( ) -> Void)?
    var onClickCategory: ((_ item: EntainSiteCoreItem) -> Bool)?
    var onClickGameplay: GamePlayHandler?
    
    var searchResultsGridViewController: EpcotSearchResultViewController?
    weak var favouriteDelegate: ImmersiveLobbyCollectionControllerDelegate?
    private var suggestionController: EpcotSearchSuggestionViewController?
    private var dataSource: LobbyFeedDataSource?

    private var searchCSS: EpcotSearchContentCSS? {
        EpcotLobbyManager.shared?.css.epcotLobbyCSS?.epcotSearchViewCSS
    }
    
    /// Class func to present view from given frame and data source to load data
    /// - Parameters:
    ///   - frame: Frame of the view
    ///   - dataSource: SearchViewControllerDataSource, to request for feed data
    /// - Returns: EpcotSearchViewController
    @discardableResult
    class func show(dataSource: LobbyFeedDataSource,
                    isEnabledSpeech: Bool, on presentingController: UIViewController) -> EpcotSearchViewController? {
        let controller = EpcotSearchViewController.loadFromNib()
        controller.dataSource = dataSource
        controller.speechStatus = isEnabledSpeech
        controller.modalPresentationStyle = UIDevice.isIPad() ? .automatic : .formSheet
        controller.modalPresentationCapturesStatusBarAppearance = true
        presentingController.present(controller, animated: true) {
            if isEnabledSpeech {
                controller.textField.resignFirstResponder()
            }else {
                controller.textField.becomeFirstResponder()
            }
        }
        return controller
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupViews()
        self.addAccessibilityIdentifiers()
    }
    
    deinit {
        ETLogger.debug("Deinit \(type(of: self))")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.dismiss(animated: false)
    }
    
    // MARK: - View setup and presentation
    
    private func setupViews() {
        self.setupTitleView()
        self.setupSearchView()
        self.setupTextField()
        self.showSuggestionController()
        self.setupNoDataView()
        self.setupResultsLabel()
    }
    
    private func setupTitleView() {
        if UIDevice.isIPad() {
            self.view.backgroundColor = self.searchCSS?.suggestionsBackgroundColor
        } else {
            let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS?.menuViewCSS
            self.viewTitle.roundCorners(corners: [.topLeft, .topRight], radius: css?.headerCornerRadius ?? 10.0)
            self.viewTitle.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            self.viewTitle.layer.masksToBounds = true
        }
        let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS
        self.buttonDone.titleLabel?.font = css?.menuViewCSS?.doneTitle?.font
        self.buttonDone.setTitleColor(css?.menuViewCSS?.doneTitle?.color, for: .normal)
        self.viewTitle.backgroundColor = css?.menuViewCSS?.headerBGColor
        self.labelTitle.font = css?.menuViewCSS?.headerTitle?.font
        self.labelTitle.textColor = css?.menuViewCSS?.headerTitle?.color
    }
    
    private func setupSearchView() {
        self.searchView.layer.cornerRadius = self.searchView.frame.size.height/2
        self.searchView.clipsToBounds = true
        self.searchView.layer.masksToBounds = true
        self.searchView.backgroundColor =  self.searchCSS?.backgroundColor ?? UIColor.hexStringToUIColor(hex: "F3F4F5")
        self.animateSearchView(value: kSearchTopSpaceValue)
        let tintColor = self.searchCSS?.clearIconColor ?? UIColor.white
        if speechStatus {
            self.setUpVoiceRecognizer()
        }
        if isVoiceSearchEnabled {
            self.clearButton.setImage(with: microphone, tintColor: tintColor, bundle: kEpcotBundle)
        }
        self.iconSearch.setImage(with: kSearchIcon, tintColor: tintColor, bundle: kEpcotBundle)
    }
    
    private func setupTextField() {
        self.textField.textColor = self.searchCSS?.searchText?.color
        self.textField.font = self.searchCSS?.searchText?.font
        self.textField.placeholder = Localize.searchTitle
        self.textField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        self.textField.addTarget(self, action: #selector(textFieldDidEndTextEdit(_ :)), for: .editingDidEndOnExit)
    }
     
    private func didCategorySelected(for id: String) {
        KibanaLogManager.sendButtonAction(feature: .searchView,
                                          function: #function,
                                          fileName: #file,
                                          remarks: "Category games selected from search window for the category:\(id)")
        let categoryName = self.feedViewModel?.getCategoryName(for: id)
        self.textField.text = categoryName
        self.search(text: id, isFromSuggestion: true)
        self.trackEvent(categoryName: categoryName ?? "")
        self.textField.resignFirstResponder()
    }
    
    // MARK: - setup VoiceRecognizer
    private func setUpVoiceRecognizer() {
        self.clearButton.isEnabled = false
        self.speechRecognizerManager = SpeechRecognizerManager()
        self.speechRecognizerManager?.setUpSpeechRecognizer { status in
            DispatchQueue.main.async { [weak self] in
                if status {
                    self?.startSpeechRecognizer()
                } else {
                    let title = Localize.alertSpeechTitle
                    let description = Localize.alertMessageForSpeech
                    self?.showPopUpView(alertTitle: title, alertDescription: description)
                    ETLogger.debug("User denied access to speech recognition")
                }
                self?.clearButton.isEnabled = true
            }
        }
        self.speechRecognizerManager?.didFailedToAccessMicrophone = {
            self.didFailedToAccessMicrophone()
        }
        self.speechRecognizerManager?.status = { status in
            self.updateSpeechRecognizerStatus(status)
        }
    }
    
    private func startSpeechRecognizer() {
        self.textField.resignFirstResponder()
        self.speechRecognizerManager?.startRecording(){ [weak self] searchText, isFinal in
            if let text = searchText {
                self?.textField.text = text
                if isFinal {
                    self?.search(text: text)
                    self?.trackEvent(searchText: text,
                                     action: EpcotEventAction.voice_search.rawValue,
                                     event: EpcotEventDetails.voice_search.rawValue)
                }
            }
        }
    }
    
    private func showPopUpView(alertTitle: String, alertDescription: String) {
        let okText = Localize.okButtonTitle
        let okAction = UIAlertAction(title: okText, style: .default) { (action) in
            if let settings = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(settings)
            }
        }
        if EntainContext.app?.isCustomThemeEnabled ?? false {
            SpeechRecognitionAccessModel().showVoiceSearchPopUpView(alertTitle: alertTitle, alertDescription: alertDescription)
        } else {
            self.showAlert(alertTitle, alertDescription, [okAction])
        }
    }
    
    private func setupNoDataView() {
        self.noDataLabel.setupLabel(with: self.searchCSS?.nodataTitle?.color,
                                    font: self.searchCSS?.nodataTitle?.font,
                                    textAlignment: .center)
        let tintColor = self.searchCSS?.nodataTitle?.color ?? UIColor.black
        self.noDataIcon.setImage(with: kNoResults, tintColor: tintColor, bundle: kEpcotBundle)
    }
    
    private func setupResultsLabel() {
        let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS?.menuViewCSS?.sectionHeaderTitle
        self.searchResultLabel.font = css?.font
        self.searchResultLabel.textColor = css?.color
    }
    
    private func showSuggestionController() {
        
        self.clearResultGridView()
        
        self.suggestionController = EpcotSearchSuggestionViewController()
        self.suggestionController?.suggestions = self.searchSuggestions
        
        if self.currentContent != .suggestion, let controller = self.suggestionController {
            self.currentContent = .suggestion
            self.configureChildViewController(childController: controller, onView: self.container)
            self.searchResultLabel.isHidden = false
            self.searchResultLabel.text = Localize.allCategories + " (\(self.searchSuggestions.count))"
            self.suggestionController?.didCategorySelected = { [weak self] category in
                guard let self else { return }
                if let result = self.onClickCategory?(category),
                    result, let categoryId = category.parameters?.id,
                    !categoryId.isEmpty  {
                    self.didCategorySelected(for: categoryId)
                }
            }
            self.suggestionController?.didScrolled = { scrollView in
                self.resignResponderIfNeeded(for: scrollView)
            }
        }
    }
    
    private func clearResultGridView() {
        self.searchResultsGridViewController?.clean()
        self.searchResultsGridViewController?.removeChildrenView()
        self.searchResultsGridViewController = nil
    }
    
    private func showNoDataController() {
        if self.currentContent != .nodata {
            self.clearSuggestionView()
            self.clearResultGridView()
            self.currentContent = .nodata
            self.noDataView.isHidden = false
            self.searchResultLabel.isHidden = true
            let gameName = self.feedViewModel?.firstGameName ?? ""
            let categoryId = self.feedViewModel?.firstCategory ?? ""
            let categoryName = self.feedViewModel?.getCategoryName(for: categoryId) ?? ""
            let noGameText = String(format: Localize.oopsNoGame, gameName, categoryName)
            self.noDataLabel.text = noGameText
        }
    }
    
    private func showResultNewGridCVController(games: [Game]) {
        self.clearSuggestionView()
        if self.currentContent != .results {
            self.searchResultsGridViewController = EpcotSearchResultViewController(datasource: self)
            self.searchResultsGridViewController?.delegate = self
            self.currentContent = .results
            if let controller = self.searchResultsGridViewController {
                self.configureChildViewController(childController: controller, onView: self.container)
            }
        }
        self.searchResultsGridViewController?.didScrolled = { scrollView in
            self.resignResponderIfNeeded(for: scrollView)
        }
        self.searchResultsGridViewController?.onClickGameplay = { game, additionalParams in
            self.onClickGameplay?(game, additionalParams)
            self.dismiss(animated: false)
        }
        self.searchResultsGridViewController?.delegate = self
        self.searchResultLabel.isHidden = false
        self.searchResultLabel.text = Localize.results + " (\(games.count))"
        self.searchResultsGridViewController?.update(games: games)
    }
    
    private func clearSuggestionView() {
        self.suggestionController?.cleanController()
        self.suggestionController?.removeChildrenView()
        self.suggestionController = nil
    }
    
    // MARK: - Animations
    private func animateSearchView(value:CGFloat) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {[weak self] in
            self?.hideLabels = true
            UIView.animate(withDuration: 0.35, animations: { [weak self] in
                self?.topContainerView.backgroundColor = self?.searchCSS?.suggestionsBackgroundColor
                self?.view.layoutIfNeeded()
            })
            { [weak self] (state) in
                self?.onAnimationComplete()
                if value != kSearchTopSpaceValue {
                    self?.dismiss(animated: true, completion: nil)
                }
            }
        }
    }
    
    private func onAnimationComplete() {
        DispatchQueue.main.async {
            if self.speechStatus {
                self.textField.resignFirstResponder()
            } else {
                self.textField.becomeFirstResponder()
            }
            self.hideLabels = false
        }
    }
    
    private func resignResponderIfNeeded(for scrollView: UIScrollView) {
        if scrollView.isTracking, self.textField.isFirstResponder {
            self.textField.resignFirstResponder()
            if let text = self.textField.text, !text.isEmpty {
                self.trackTextEntered(with: text)
            }
        }
    }
    
    // MARK: - Search and filter
    
    private func search(text:String?, isFromSuggestion: Bool = false) {
        self.setupPublisher()
        let imageName = text?.count ?? 0 > 0 ? kErase : (isVoiceSearchEnabled ? microphone : "")
        let tintColor = searchCSS?.clearIconColor ?? UIColor.white
        self.clearButton.setImage(with: imageName,
                                  tintColor: tintColor,
                                  bundle: kEpcotBundle)
        guard let _text = text, _text.count > 0 else {
            // show suggestion view here
            self.showSuggestionController()
            self.clearPublisher()
            return
        }
        
        if isFromSuggestion {
            let games = self.feedViewModel?.getGames(for: text ?? "")
            updateResultController(with: games)
        } else {
            guard !(self.searchWebCategories?.contains(where: { $0.lowercased() == _text.lowercased() }) ?? false) else {
                self.showNoDataController()
                return
            }
            self.searchSubject.send(_text)
        }
    }
    
    func updateResultController(with games: [Game]?) {
        if let games, games.count > 0 {
            self.showResultNewGridCVController(games: games)
        } else {
            self.showNoDataController()
        }
    }
    
    // MARK: - Button Actions
    
    ///method will pop the current visible view controller
    @IBAction private func actionDone(_ sender: UIButton) {
        let instantInteraction = InteractionType.opacity.interaction
        sender.tapAnimation(type: instantInteraction) {
            self.textField.resignFirstResponder()
            self.textField.text = nil
            self.clearButton.isHidden = true
            self.dismiss(animated: false)
        }
    }       
    
    /// Methods will clears the entered text
    @IBAction private func actionClear(_ sender: UIButton) {
        let instantInteraction = InteractionType.opacity.interaction
        sender.tapAnimation(type: instantInteraction) {
            if self.isVoiceSearchEnabled {
                if let text = self.textField.text, !(text.isEmpty) {
                    self.textField.text = nil
                    self.search(text: nil)
                } else {
                    self.setUpVoiceRecognizer()
                    KibanaLogManager.sendButtonAction(feature: .searchView,
                                                      function: #function,
                                                      fileName: #file,
                                                      remarks: "search games in search window from Voice Search:\(String(describing: self.textField.text))")
                }
            } else {
                self.textField.text = nil
                self.textField.becomeFirstResponder()
                self.search(text: nil)
            }

        }
    }
    
    override func dismiss(animated flag: Bool, completion: (() -> Void)? = nil) {
        EpcotLobbyManager.shared?.setupAudioSessionForBackgroundAudio()
        self.textField.resignFirstResponder()
        if let text = self.textField.text, !text.isEmpty {
            self.trackTextEntered(with: text)
        }
        self.textField.text = nil
        self.speechRecognizerManager?.stopRecording()
        self.speechRecognizerManager = nil
        self.dataSource = nil
        self.onClickGameplay = nil
        self.clearPublisher()
        
        super.dismiss(animated: true) { [weak self] in
            guard let self = self else { return }
            self.didDismissed?()
            self.clearSuggestionView()
            self.clearResultGridView()
            self.didDismissed = nil
            self.favouriteDelegate = nil
            self.onClickCategory = nil
            ETLogger.debug("####### favourite delegate deinit")
        }
    }
}

// MARK: - UITextFieldDelegate

extension EpcotSearchViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        if let text = self.textField.text, !text.isEmpty {
            self.trackTextEntered(with: text)
        }
        return true
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        self.search(text: textField.text)
    }
    
    @objc func textFieldDidEndTextEdit(_ textField: UITextField) {
        if let text = textField.text, !text.isEmpty {
            self.trackTextEntered(with: text)
        }
    }
    
    func trackTextEntered(with text: String) {
        ETLogger.debug("##### tracker text: \(text)")
        self.trackEvent(searchText: text,
                        action: EpcotEventAction.manual_search.rawValue,
                        event: EpcotEventDetails.manual_search.rawValue)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let isRangeExceeded = range.location < kMaxSearchTextFiledLength
        let strintCountExceeded = string.count < kMaxSearchTextFiledLength
        return isRangeExceeded && strintCountExceeded
    }
}

// MARK: - EpcotLobbyCollectionViewDelegate & EpcotLobbyFeedDataSource

extension EpcotSearchViewController: LobbyFeedDataSource {
    
    var feedViewModel: FeedViewModel? {
        self.dataSource?.feedViewModel
    }
}

extension EpcotSearchViewController: ImmersiveLobbyCollectionControllerDelegate {
    func didTappedOnFavourites(gameVariant: String, state: Bool, from seeMoreSection: Bool) {
        self.favouriteDelegate?.didTappedOnFavourites(gameVariant: gameVariant, state: state, from: seeMoreSection)
        ETLogger.debug("####### favourite delegate called")
    }
}

// MARK: - SpeechRecognizer Methods.

extension EpcotSearchViewController {
    
    private func updateSpeechRecognizerStatus(_ status: SpeechRecognizerStatus) {
        let micIconColor = self.searchCSS?.micIconColor ?? UIColor.blue
        let backIconColor = self.searchCSS?.clearIconColor ?? UIColor.white
        self.clearButton.tintColor = status == .start ? micIconColor : backIconColor
    }
    
    private func didFailedToAccessMicrophone() {
        let title =  Localize.alertMicrophoneTitle
        let description = Localize.alertMessageForMicrophone
        self.showPopUpView(alertTitle: title, alertDescription: description)
        ETLogger.debug("User denied access to speech recognition")
        KibanaLogManager.sendButtonAction(feature: .searchView,
                                          function: #function,
                                          fileName: #file,
                                          remarks: Localize.alertMessageForMicrophone)
    }
}

extension EpcotSearchViewController {
    private func trackEvent(searchText: String,
                            action: String,
                            event: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.globalSearch.rawValue,
                                     actionEvent: action,
                                     labelEvent: EpcotEventLabel.globalSearch.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: event,
                                     positionEvent: EpcotEventPosition.navigationTopBar.rawValue,
                                     termSearch: searchText)
            
            let event = TrackerEvent(type: .globalSearch, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
    private func trackEvent(categoryName: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.globalSearch.rawValue,
                                     actionEvent:EpcotEventAction.click.rawValue,
                                     labelEvent: EpcotEventLabel.search_interaction.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: categoryName,
                                     positionEvent: EpcotEventPosition.suggested_search_result.rawValue)
            
            let event = TrackerEvent(type: .globalSearch, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}

//MARK: Adding Accessibility Identifiers
extension EpcotSearchViewController {
    private func addAccessibilityIdentifiers() {
        viewTitle.accessibilityIdentifier = AccessibilityIdentifiers.search_clearButton.rawValue
        labelTitle.accessibilityIdentifier = AccessibilityIdentifiers.search_clearButton.rawValue
        buttonDone.accessibilityIdentifier = AccessibilityIdentifiers.search_clearButton.rawValue
        clearButton.accessibilityIdentifier = AccessibilityIdentifiers.search_clearButton.rawValue
        textField.accessibilityIdentifier = AccessibilityIdentifiers.search_textField.rawValue
        searchView.accessibilityIdentifier = AccessibilityIdentifiers.search_searchView.rawValue
        container.accessibilityIdentifier = AccessibilityIdentifiers.search_container.rawValue
        noDataView.accessibilityIdentifier = AccessibilityIdentifiers.search_noDataView.rawValue
        noDataIcon.accessibilityIdentifier = AccessibilityIdentifiers.search_noDataIcon.rawValue
        noDataLabel.accessibilityIdentifier = AccessibilityIdentifiers.search_noDataLabel.rawValue
        iconSearch.accessibilityIdentifier = AccessibilityIdentifiers.search_favouriteToastView.rawValue
        headerSeperatorView.accessibilityIdentifier = AccessibilityIdentifiers.search_favouriteToastView.rawValue
        topContainerView.accessibilityIdentifier = AccessibilityIdentifiers.search_favouriteToastView.rawValue
        searchResultLabel.accessibilityIdentifier = AccessibilityIdentifiers.search_favouriteToastView.rawValue
        favouriteToastView.accessibilityIdentifier = AccessibilityIdentifiers.search_favouriteToastView.rawValue
    }
}

extension EpcotSearchViewController {
    private func setupPublisher() {
        guard anyCancellable == nil else { return }
        anyCancellable = searchSubject
        // Applying the debounce of 300 milli seconds to recieve the input from the publisher
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
        // Subscribing the upstream on the background thread.
            .subscribe(on: DispatchQueue(label: "search queue"))
        // Converting the string received from upstream to games list
            .flatMap({ value  in
                if let games = self.feedViewModel?.getSearchedGames(with: value) {
                    return Just(games)
                        .eraseToAnyPublisher()
                }
                return Just([Game]())
                    .eraseToAnyPublisher()
            })
        // Receiving the games list on main thread, so that downstream events will be received on main thread.
            .receive(on: RunLoop.main)
        // Updating the UI based on the games.
            .sink(receiveValue: { games in
                self.updateResultController(with: games)
            })
    }
    
    private func clearPublisher() {
        self.anyCancellable?.cancel()
        self.anyCancellable = nil
    }
}
