//
//  SuggestionViewController.swift
//  CasinoLobby
//
//  Created by Praveen Kokkula on 06/03/20.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import UIKit
import CasinoAPI
import Utility

class SuggestionViewController: UITableViewController {

    var suggestions: [EntainSiteCoreItem] = [EntainSiteCoreItem()] {
        didSet {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    var didCategorySelected: ((_ item: EntainSiteCoreItem) -> Void)?
    var didScrolled: ((UIScrollView) -> Void)?
    
    convenience init() {
        self.init(style: .plain)
//        self.suggestions = suggestions
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .clear
        self.setupTableView()
    }
    
    func setupTableView() {
        self.tableView.registerNibCells(withCells: "SuggestionTableViewCell", bundle: kEpcotBundle)
        self.tableView.backgroundColor = .clear
        self.tableView.separatorColor = .clear
        self.tableView.reloadData()
    }
    
    private  func headerView(title: String?) -> UIView {
        let aView = UIView(frame: CGRect(x: 0, y: 0, width: UIDevice.screenSize.width, height: 30))
        aView.backgroundColor = .clear
        let label = UILabel(frame: .zero)
        aView.addSubview(label)
        let left: CGFloat = UIDevice.isIPad() ? 24 : 16
        label.constraintPinAllEdges(holderView: aView, edgeInsets: UIEdgeInsets(top: 0, left: left, bottom: 0, right: 0))
        let css = EpcotLobbyManager.shared?.css.suggestionView
        label.font = css?.resultTitle?.font
        label.textColor = css?.resultTitle?.color
        label.textAlignment = .left
        label.backgroundColor = .clear
        label.text = title
        return aView
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.suggestions.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return .suggestionCellHeight
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "SuggestionTableViewCell") as? SuggestionTableViewCell else {
            preconditionFailure("Suggestion TableView Cell is not registered/ Not found")
        }
        let category = self.suggestions[indexPath.row]
        cell.suggestionLabel.text = category.title
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         let category = self.suggestions[indexPath.row]
         self.didCategorySelected?(category)
    }
    
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        self.didScrolled?(scrollView)
    }
    
    deinit {
        ETLogger.debug("Deinit called epcot search suggestion view controller")
    }
}


