//
//  SuggestionTableViewCell.swift
//  CasinoGames
//
//  Created by Praveen Kokkula on 13/01/20.
//  Copyright © 2020 Ivy Comptech. All rights reserved.
//

import UIKit

extension CGFloat {
    
    static let lobbyCellHeight: CGFloat = UIDevice.isIPad() ? 165 : 135
    static let suggestionCellHeight: CGFloat = 66.0
    static let cornerRadius: CGFloat = 4.0
    
}

class SuggestionTableViewCell: UITableViewCell {
    
    @IBOutlet weak var suggestionLabel: UILabel!
    @IBOutlet private weak var searchButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        let cellCSS = EpcotLobbyManager.shared?.css.suggestionView
        self.contentView.backgroundColor = cellCSS?.contentBGColor
        self.suggestionLabel.font = cellCSS?.title?.font
        self.suggestionLabel.textColor = cellCSS?.title?.color
        self.searchButton.setImage(UIImage(named: kSearchWhite,
                                           in: Bundle(for: SuggestionTableViewCell.self),
                                           compatibleWith: nil)?.withRenderingMode(.alwaysTemplate),
                                   for: .normal)
        self.searchButton.tintColor = cellCSS?.searchIconColor ?? UIColor.white
        self.addAccessibilityIdentifiers()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        let offset : CGFloat = UIDevice.isIPad() ? 24.0 : 16.0
        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 4, left: offset, bottom: 4, right: offset))
        contentView.layer.cornerRadius = .cornerRadius
    }
}

//MARK: Adding Accessibility Identifiers
extension SuggestionTableViewCell {
    private func addAccessibilityIdentifiers() {
        suggestionLabel.accessibilityIdentifier = AccessibilityIdentifiers.suggestioncell_suggestionLabel.rawValue
        searchButton.accessibilityIdentifier = AccessibilityIdentifiers.suggestioncell_searchButton.rawValue
    }
}
