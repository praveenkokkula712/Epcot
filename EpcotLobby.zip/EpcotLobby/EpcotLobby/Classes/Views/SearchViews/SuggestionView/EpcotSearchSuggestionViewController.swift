//
//  File.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 13/06/22.
//

import Foundation
import CasinoAPI

enum EpcotSearchSection: Int, CaseIterable {
    case suggestion
}

enum SearchItem: Hashable {
    case loading(UUID)
    case suggestion(EntainSiteCoreItem)
    
    static var loadingItems: [SearchItem] {
        return Array(repeatingExpression: SearchItem.loading(UUID()), count: 8)
    }
}

class EpcotSearchSuggestionViewController: UICollectionViewController {
    
    private var diffDatasource: SearchDatasource?
    private var snapShot: SearchSnapshot?
    
    var didCategorySelected: ((_ item: EntainSiteCoreItem) -> Void)?
    var didScrolled: ((UIScrollView) -> Void)?
    
    var suggestions: [EntainSiteCoreItem] = [EntainSiteCoreItem()] {
        didSet {
            DispatchQueue.main.async {
                if !self.suggestions.isEmpty {
                    self.applySnapShot()
                }
            }
        }
    }
    
    deinit {
        ETLogger.debug(" Deinit Suggestion view controller")
    }
    
    func cleanController() {
        self.diffDatasource = nil
        self.snapShot = nil
        self.didCategorySelected = nil
        self.didScrolled = nil
        guard self.collectionView != nil else { return }
        self.collectionView.removeFromSuperview()
        self.collectionView = nil
    }
    
    /// Customised init, to setup default layout
    convenience init() {
        self.init(collectionViewLayout: UICollectionViewFlowLayout())
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupCollectionView()
    }


    //MARK: - Datasource and snapshot setup.
    private func configureDatasource() {
        guard self.collectionView != nil else { return }
        diffDatasource = SearchDatasource(collectionView: self.collectionView, cellProvider: { collectionView, indexPath, itemIdentifier in
            self.cell(collectionView: collectionView, indexPath: indexPath, itemIdentifier: itemIdentifier)
        })
        applySnapShot()
    }
    
    /// Cell setup based on the datasourcce
    /// - Parameters:
    ///   - collectionView: collection view
    ///   - indexPath: indexPath of the item to be dispalyed.
    ///   - itemIdentifier: item Id for dispalying purpose which will hold either category Item or loading item
    /// - Returns: UIcollectionView cell.
    private func cell(collectionView: UICollectionView, indexPath: IndexPath, itemIdentifier: SearchItem) -> UICollectionViewCell? {
        switch itemIdentifier {
        case .loading( _):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.categoriesCell, for: indexPath) as? EpcotMenuCustomCell
            cell?.showLoading()
            return cell
        case .suggestion(let suggestion):
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.categoriesCell, for: indexPath) as? EpcotMenuCustomCell
            cell?.configureView(with: suggestion, type: .suggestion)
            return cell
        }
    }
    
    /// will apply the snapshot
    private func applySnapShot() {
        snapShot = SearchSnapshot()
        snapShot?.appendSections([.suggestion])
        if self.suggestions.isEmpty {
            snapShot?.appendItems(SearchItem.loadingItems, toSection: .suggestion)
        } else {
            snapShot?.appendItems(suggestions.map(SearchItem.suggestion), toSection: .suggestion)
        }
        guard let snapShot = snapShot else { return }
        diffDatasource?.apply(snapShot, animatingDifferences: true)
    }
}


//MARK: - Collection View Setup
extension EpcotSearchSuggestionViewController {
        
    private func setupCollectionView() {
        self.collectionView.backgroundColor = UIColor.clear
        self.collectionView.collectionViewLayout = UICollectionViewCompositionalLayout(section: CustomLayoutSection.listLayoutSection(isHeaderEnabled: false))
        // Registering cell
        self.collectionView.registerNibCells(withCells: CellIdentifier.categoriesCell, bundle: kEpcotBundle)
        self.collectionView.delegate = self
        self.configureDatasource()
    }
}

//MARK: - Collection View Delegates
extension EpcotSearchSuggestionViewController  {
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let item = diffDatasource?.itemIdentifier(for: indexPath) else { return }
        switch item {
        case .suggestion:
            if let cell = collectionView.cellForItem(at: indexPath) {
                let category = self.suggestions[indexPath.row]
                cell.tapAnimation {
                    self.didCategorySelected?(category)
                }
            }
        default: break
        }
    }
}

extension EpcotSearchSuggestionViewController {
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.didScrolled?(scrollView)
    }
}
