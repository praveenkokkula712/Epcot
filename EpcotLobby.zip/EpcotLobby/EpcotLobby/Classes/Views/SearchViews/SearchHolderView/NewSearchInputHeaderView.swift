//
//  NewSearchInputHeaderView.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 20/02/23.
//

import UIKit

protocol NewSearchInputHeaderViewDelegate: AnyObject {
    func didTapOnMicButton(isVoiceEnabled: Bool)
    func didChangeSearchText(inputString: String)
    func didChageSearchTextTracker(inputString: String)
}

class NewSearchInputHeaderView: UIView {
    
    private let menuContainerHeight: CGFloat = 32.0
    private let searchPadding: CGFloat = 8.0
    private let searchBottompadding: CGFloat = 6.0
    private(set) weak var delegate: NewSearchInputHeaderViewDelegate?

    @IBOutlet private(set) weak var searchTextField: UITextField!
    @IBOutlet private(set) weak var buttonMic: UIButton!
    @IBOutlet private weak var searchButton: UIButton!
    @IBOutlet private weak var viewSearchContainer: UIView!
    
    var firstResponder: Bool = false {
        didSet {
            if firstResponder {
                self.searchTextField.becomeFirstResponder()
            } else {
                if self.searchTextField.isFirstResponder {
                    self.searchTextField.resignFirstResponder()
                    if let text = self.searchTextField.text, !text.isEmpty {
                        self.delegate?.didChageSearchTextTracker(inputString: text)
                    }
                }
            }
        }
    }
    
    var isMicEnabled: Bool = false {
        didSet {
            self.updateMicButtonIcon()
        }
    }
    
    var isVoiceSearchStarted: Bool = false {
        didSet {
            let micIconColor = EpcotLobbyManager.shared?.css.searchInputAccessoryViewCSS?.searchButtonTintColor ?? UIColor.white
            self.buttonMic.tintColor = isVoiceSearchStarted ? .blue : micIconColor
        }
    }
    
    var selectedCategory: String = "" {
        didSet {
            self.searchTextField.text = selectedCategory
            self.searchTextField.becomeFirstResponder()
            self.firstResponder = false
            self.isMicEnabled = false
        }
    }
    
    var speechText: String = "" {
        didSet {
            self.searchTextField.text = speechText
        }
    }

    fileprivate let isVoiceSearchEnabled: Bool = {
        EpcotLobbyManager.shared?.datasource?.enableVoiceSearch() ?? false
    }()
    
    private var css : SearchInputAccessoryViewCSS?{
        EpcotLobbyManager.shared?.css.searchInputAccessoryViewCSS
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setUpSearchViewCSS()
        self.addAccessibilityIdentifiers()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override var canBecomeFirstResponder: Bool {
        return firstResponder
    }
    
    @discardableResult
    class func loadSearchInputView(delegate: NewSearchInputHeaderViewDelegate? =  nil) -> NewSearchInputHeaderView  {
        let searchView = NewSearchInputHeaderView.loadFromNib(String(describing: NewSearchInputHeaderView.self),
                                    Bundle(for: NewSearchInputHeaderView.self)) ?? NewSearchInputHeaderView()
        searchView.delegate = delegate
        return searchView
    }
    
    private func setUpSearchViewCSS() {
        self.backgroundColor = css?.searchInputContainerViewBgColor ?? UIColor.black
        self.viewSearchContainer.backgroundColor = css?.searchInputTextfieldBgColor ?? kSearchContainerBGColor
        self.searchTextField.font = css?.searchInputTextFieldFont?.font
        self.searchTextField.textColor = css?.searchInputTextFieldFont?.color
        self.searchTextField.attributedPlaceholder = NSAttributedString(string:Localize.searchTitle, attributes: [NSAttributedString.Key.foregroundColor: css?.searchInputPlaceHolderTextColor])

        self.buttonMic.isHidden = !isVoiceSearchEnabled
        isMicEnabled = self.searchTextField.text?.count ?? 0 > 0 ? false : true
        self.buttonMic.tintColor = css?.micButtonTintColor ?? UIColor.white

        self.searchButton.setImage(with: kSearchWhite, tintColor: css?.searchButtonTintColor, bundle: kEpcotBundle)
    }
    
    private func updateMicButtonIcon() {
        let imageName = self.searchTextField.text?.count ?? 0 > 0 ? kErase : (isVoiceSearchEnabled ? microphone : "")

        self.buttonMic.setImage(UIImage(named: imageName,
                                          in: kEpcotBundle,
                                          compatibleWith: nil)?.withRenderingMode(.alwaysTemplate),
                                  for: .normal)
    }
    
    /// MIc button Action
    /// - Parameter sender: button sender
    @IBAction private func micAction(_ sender: UIButton) {
        sender.tapAnimation {
            if self.isMicEnabled {
                UserDefaults.userOnboardingVoiceSearch = true
                self.firstResponder = false
                self.delegate?.didTapOnMicButton(isVoiceEnabled: self.isMicEnabled)
            } else {
                self.searchTextField.text = nil
                self.delegate?.didChangeSearchText(inputString: self.searchTextField.text ?? "")
                self.firstResponder = true
                self.isMicEnabled = true
            }
        }
    }
    
    @IBAction private func searchAction(_ sender: Any) {
        self.firstResponder = true
    }
    
    @IBAction private func textFieldDidChange(_ textField: UITextField) {
        self.isMicEnabled = self.searchTextField.text?.count ?? 0 > 0 ? false : true
        UserOnboardingViewModel.shared?.hidePopTipViewIfAny()
        self.delegate?.didChangeSearchText(inputString: textField.text ?? "")
    }
}

extension NewSearchInputHeaderView: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.firstResponder = false
        return true
    }
        
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return (range.location < kMaxSearchTextFiledLength) && (string.count < kMaxSearchTextFiledLength)
    }
}

extension NewSearchInputHeaderView {
    
    func showOnBoardingViewIfNeeded() {
        let result = UserOnboardingViewModel.shared?.show(with: self.buttonMic.globalFrameFromLobbyView,
                                                          of: .voiceSearch,
                                                          action: {
            self.isUserInteractionEnabled = true
            self.firstResponder = true
        }) ?? false
        self.isUserInteractionEnabled = !result
        self.firstResponder = !result
    }
}

//MARK: Adding Accessibility Identifiers
extension NewSearchInputHeaderView {
    private func addAccessibilityIdentifiers() {
        searchTextField.accessibilityIdentifier = AccessibilityIdentifiers.newsearchinput_searchTextField.rawValue
        buttonMic.accessibilityIdentifier = AccessibilityIdentifiers.newsearchinput_buttonMic.rawValue
        searchButton.accessibilityIdentifier = AccessibilityIdentifiers.newsearchinput_searchButton.rawValue
        viewSearchContainer.accessibilityIdentifier = AccessibilityIdentifiers.newsearchinput_viewSearchContainer.rawValue
    }
}
