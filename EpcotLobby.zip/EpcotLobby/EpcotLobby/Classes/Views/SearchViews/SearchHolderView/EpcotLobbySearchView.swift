//
//  EpcotLobbySearchView.swift
//  EpcotLobby
//
//  Created by Challa Venkata Narasimha Karthik on 06/04/22.
//  Copyright © 2022 Ivy Comptech. All rights reserved.
//

import UIKit

/// Lobby Menu & Search button view class
class EpcotLobbySearchView: UIView {
    
    @IBOutlet private weak var viewContainer: UIView!
    @IBOutlet private weak var stackViewContainer: UIStackView!
    @IBOutlet private weak var buttonSearch: UIButton!
    @IBOutlet private weak var buttonMenu: UIButton!
    @IBOutlet private weak var buttonMic: UIButton!
    @IBOutlet private weak var menuButtonWidthConstraint: NSLayoutConstraint!
    
    fileprivate let isVoiceSearchEnabled: Bool = {
        EpcotLobbyManager.shared?.datasource?.enableVoiceSearch() ?? false
    }()
    
    fileprivate let isSearchWithMenuEnabled: Bool = {
        EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .searchBarWithMenu) ?? false
    }()
    
    var didTappedOnMenu: (() -> Void)?
    var didTappedOnSearch: ((Bool) -> Void)?
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layoutIfNeeded()
        if isVoiceSearchEnabled {
            let searchHeight = buttonSearch.frame.height
            buttonSearch.roundCorners(corners: [.topLeft, .bottomLeft], radius: searchHeight / 2)
            let micHeight = buttonSearch.frame.height
            buttonMic.roundCorners(corners: [.topRight, .bottomRight], radius: micHeight / 2)
        } else {
            let searchHeight = buttonSearch.frame.height
            buttonSearch.getRoundedCorners(OfRadius: searchHeight / 2)
        }
        let menuHeight = buttonMenu.frame.height
        buttonMenu.getRoundedCorners(OfRadius: menuHeight / 2)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.addObservers()
        let searchViewCSS = EpcotLobbyManager.shared?.css.epcotLobbyCSS
        setupContainerView(with: searchViewCSS)
        setUpSearchView(with: searchViewCSS)
        setupMenuView(with: searchViewCSS)
        self.addAccessibilityIdentifiers()
    }
    
    /// Loads the current view on a given view
    /// - Parameters:
    ///   - aView: Receiver's view
    ///   - delegate: Delegate to receive actions
    /// - Returns: EpcotLobbySearchView configured on the given view
    @discardableResult
    class func load(on aView: UIView) -> EpcotLobbySearchView  {
        let searchView = EpcotLobbySearchView.loadFromNib(String(describing: EpcotLobbySearchView.self),
                                                          Bundle(for: EpcotLobbySearchView.self)) ?? EpcotLobbySearchView()
        searchView.configure(on: aView)
        return searchView
    }
    
    /// Setup main container view
    /// - Parameter css: Container theme
    private func setupContainerView(with css: EpcotLobbyCSS?) {
            // Setup Main Container View

        viewContainer.backgroundColor = css?.searchMenuContainerViewBGColor
        stackViewContainer.isLayoutMarginsRelativeArrangement = true
        stackViewContainer.directionalLayoutMargins = NSDirectionalEdgeInsets(top: kMainViewPadding,
                                                                              leading: kMainViewPadding,
                                                                              bottom: kMainViewPadding,
                                                                              trailing: 0)
        stackViewContainer.spacing = kMainViewPadding
    }
    
    /// Setup search button view
    /// - Parameter css: Search Button theme
    private func setUpSearchView(with css: EpcotLobbyCSS?) {
        buttonSearch.backgroundColor = css?.searchViewBGColor
        self.buttonMic.isHidden = !isVoiceSearchEnabled
        self.buttonMic.backgroundColor = css?.searchViewBGColor
        buttonSearch.setTitleColor(css?.searchViewTitle?.color, for: .normal)
        buttonSearch.setTitle(Localize.searchCasino, for: .normal)
        buttonSearch.titleLabel?.font = css?.searchViewTitle?.font
        let tintColor = css?.searchViewTitle?.color
        self.buttonSearch.setImage(with: kSearchIcon, tintColor: tintColor, bundle: kEpcotBundle)
        self.buttonMic.setImage(with: microphone, tintColor: tintColor, bundle: kEpcotBundle)
    }

    deinit {
        Feed.removeObserver(observer: self,
                            notification: .didUpdateLocalizedStrings)
    }
    
    private func addObservers() {
        Feed.addObserver(observer: self,
                         selector: #selector(self.didUpdateLocalizedStrings),
                         notification: .didUpdateLocalizedStrings)
    }
    
    @objc private func didUpdateLocalizedStrings() {
        DispatchQueue.main.async {
            self.buttonMenu.setTitle(Localize.casino, for: .normal)
            self.buttonSearch.setTitle(Localize.searchCasino, for: .normal)
        }
    }
    
    /// Setup Menu button view
    /// - Parameter css: Menu Button theme
    private func setupMenuView(with css : EpcotLobbyCSS?) {
        buttonMenu.backgroundColor = css?.menuViewBGColor
        buttonMenu.setTitleColor(css?.menuViewTitle?.color, for: .normal)
        buttonMenu.setTitle(Localize.casino, for: .normal)
        buttonMenu.titleLabel?.font =  css?.menuViewTitle?.font
        buttonMenu.layer.borderColor = css?.epcotMenuButtonBorderColor?.cgColor
        buttonMenu.layer.borderWidth = 1
        let tintColor = css?.menuViewTitle?.color
        self.buttonMenu.setImage(with: kMenuIcon, tintColor: tintColor, bundle: kEpcotBundle)
        menuButtonWidthConstraint.constant = kMenuContainerWidth
    }

    
    /// Search button Action
    /// - Parameter sender: Button sender
    @IBAction private func actionSearch(_ sender: UIButton) {
        self.didTappedOnSearch?(false)
    }
    
    /// Menu Button Action
    /// - Parameter sender: Button sender
    @IBAction private func actionMenu(_ sender: UIButton) {
        let instantInteraction = InteractionType.overLay40.interaction
        sender.tapAnimation(type: instantInteraction) {
            self.didTappedOnMenu?()
        }
    }
    
    /// Mic Button Action
    /// - Parameter sender: Button sender
    @IBAction private func actionMic(_ sender: UIButton) {
        self.didTappedOnSearch?(true)
    }
}

//MARK: Adding Accessibility Identifiers
extension EpcotLobbySearchView {
    private func addAccessibilityIdentifiers() {
        viewContainer.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobbysearch_viewContainer.rawValue
        stackViewContainer.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobbysearch_stackViewContainer.rawValue
        buttonSearch.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobbysearch_buttonSearch.rawValue
        buttonMenu.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobbysearch_buttonMenu.rawValue
        buttonMic.accessibilityIdentifier = AccessibilityIdentifiers.epcotlobbysearch_buttonMic.rawValue
    }
}
