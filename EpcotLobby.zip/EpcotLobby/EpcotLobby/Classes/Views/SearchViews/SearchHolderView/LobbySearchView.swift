//
//  LobbySearchView.swift
//  CasinoLobby
//
//  Created by Praveen Kokkula on 22/12/21.
//

import UIKit

class LobbySearchView: UIView {
    
    private let menuContainerHeight: CGFloat = 32.0
    private let searchPadding: CGFloat = 8.0
    private let searchBottompadding: CGFloat = 6.0
    
    @IBOutlet private weak var viewContainer: UIView!
    @IBOutlet private weak var buttonMic: UIButton!
    @IBOutlet private weak var viewSearchContainer: UIView!
    @IBOutlet private weak var buttonSearchHolder: UIButton!
    @IBOutlet private weak var menuButton: UIButton!
    @IBOutlet private weak var menuViewContainer: UIView!
    @IBOutlet private weak var searchHeightConstraint: NSLayoutConstraint!
    @IBOutlet private weak var searchBottomConstraint: NSLayoutConstraint!
    @IBOutlet private weak var searchTrailingConstraint: NSLayoutConstraint!
    @IBOutlet private weak var menuHeightConstraint: NSLayoutConstraint!
    @IBOutlet private weak var menuWidthConstraint: NSLayoutConstraint!
    @IBOutlet private weak var searchBarHeightConstraint: NSLayoutConstraint!
    
    fileprivate let isVoiceSearchEnabled: Bool = {
        EpcotLobbyManager.shared?.datasource?.enableVoiceSearch() ?? false
    }()
    
    fileprivate let isSearchWithMenuEnabled: Bool = {
       EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .searchBarWithMenu) ?? false
    }()
    
    private var css : LobbyCSS? {
        EpcotLobbyManager.shared?.css
    }
    
    var didTappedOnMenu: (() -> Void)?
    var didTappedOnSearch: ((Bool) -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setUpSearchViewCSS()
        self.addObservers()
        self.addAccessibilityIdentifiers()
    }
    
    deinit {
        Feed.removeObserver(observer: self,
                            notification: .didUpdateLocalizedStrings)
    }
    
    private func addObservers() {
        Feed.addObserver(observer: self,
                         selector: #selector(self.didUpdateLocalizedStrings),
                         notification: .didUpdateLocalizedStrings)
    }
    
    @objc private func didUpdateLocalizedStrings() {
        DispatchQueue.main.async {
            self.buttonSearchHolder.setTitle(Localize.searchTitle, for: .normal)
        }
    }
    
    @discardableResult
    class func load(on aView: UIView) -> LobbySearchView  {
        let searchView = LobbySearchView.loadFromNib(String(describing: LobbySearchView.self),
                                                          Bundle(for: LobbySearchView.self)) ?? LobbySearchView()
        searchView.configure(on: aView)
        return searchView
    }
    
    func setUpSearchViewCSS() {
        self.viewContainer.backgroundColor = self.css?.searchView?.searchParentContainerBGColor ?? UIColor.white
        self.viewSearchContainer.backgroundColor = self.css?.searchView?.searchContainerBGColor ?? kSearchContainerBGColor
        self.buttonSearchHolder.setTitleColor(self.css?.searchView?.searchContainerTitleColor, for: .normal)
        self.buttonSearchHolder.setTitle(Localize.searchTitle, for: .normal)
        self.buttonSearchHolder.titleLabel?.font =  EpcotLobbyManager.shared?.css.searchView?.searchPlaceHolderFont?.font
        let tintColor = self.css?.searchView?.searchContainerTitleColor
        self.buttonSearchHolder.setImage(with: kSearchWhite, tintColor: tintColor, bundle: kEpcotBundle)
        self.buttonMic.isHidden = !isVoiceSearchEnabled
        self.buttonMic.setImage(with: microphone, tintColor: tintColor, bundle: kEpcotBundle)
        let css = self.css?.navigationView
        self.viewContainer.dropShadow(color: css?.shadowColor ?? .black, offSet: CGSize(width: 3, height: 3))
        self.searchHeightConstraint.constant = searchContainerHeight
        self.menuViewContainer.translatesAutoresizingMaskIntoConstraints = false
        self.menuWidthConstraint.constant = 0

        if isSearchWithMenuEnabled
        {
            self.updateMenuCSS()
        }
    }
    
    private func updateMenuCSS() {
        self.menuViewContainer.isHidden = !isSearchWithMenuEnabled
        let menuImage = UIImage(named: kMenuIcon, in: Bundle(for: type(of: self)), compatibleWith: nil)?.withRenderingMode(.alwaysTemplate)
        self.menuButton.setImage(menuImage, for: .normal)
        self.menuViewContainer.backgroundColor = self.css?.searchView?.searchContainerBGColor ?? kSearchContainerBGColor
        self.viewContainer.backgroundColor = self.css?.searchView?.menuButtonContainerBgColor ?? UIColor.white
        self.menuButton.titleLabel?.font =  self.css?.searchView?.menuButtonFont?.title?.font
        self.menuWidthConstraint.constant = kMenuContainerWidth
        self.menuHeightConstraint.constant = menuContainerHeight
        
        self.searchBarHeightConstraint.constant = menuContainerHeight
        self.searchHeightConstraint.constant = 44
        self.searchTrailingConstraint.constant = searchPadding
        self.searchBottomConstraint.constant = searchBottompadding
        self.menuViewContainer.layer.masksToBounds = true
        self.menuViewContainer.layer.cornerRadius = self.css?.searchView?.menuButtonCornerRadius ?? kButtonCornerRadius
        self.viewSearchContainer.layer.cornerRadius = self.css?.searchView?.menuButtonCornerRadius ?? kButtonCornerRadius

        self.menuButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: searchPadding, bottom: 0, right: searchPadding)
        self.menuButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: searchPadding, bottom: 0, right: 0)

    }
    
    /// Search button Action
    /// - Parameter sender: button sender
    @IBAction private func searchBtnAction(_ sender: Any) {
        self.didTappedOnSearch?(false)
    }
    
    @IBAction private func micAction(_ sender: Any) {
        self.didTappedOnSearch?(true)
    }
    
    /// Menu Button Action
    /// - Parameter sender: Button sender
    @IBAction private func actionMenu(_ sender: UIButton) {
        sender.tapAnimation {
            self.didTappedOnMenu?()
        }
    }
    
    /// Update shadow for iPad
    override func layoutSubviews() {
        super.layoutSubviews()
        self.viewContainer.updateShadow()
    }
    
}
extension LobbySearchView: Notifier {
    public enum Notification: String {
        case DidUpdatedSearchView
    }
}

//MARK: Adding Accessibility Identifiers
extension LobbySearchView {
    private func addAccessibilityIdentifiers() {
        viewContainer.accessibilityIdentifier = AccessibilityIdentifiers.lobbysearch_viewContainer.rawValue
        buttonMic.accessibilityIdentifier = AccessibilityIdentifiers.lobbysearch_buttonMic.rawValue
        viewSearchContainer.accessibilityIdentifier = AccessibilityIdentifiers.lobbysearch_viewSearchContainer.rawValue
        buttonSearchHolder.accessibilityIdentifier = AccessibilityIdentifiers.lobbysearch_buttonSearchHolder.rawValue
        menuButton.accessibilityIdentifier = AccessibilityIdentifiers.lobbysearch_menuButton.rawValue
        menuViewContainer.accessibilityIdentifier = AccessibilityIdentifiers.lobbysearch_menuViewContainer.rawValue
    }
}
