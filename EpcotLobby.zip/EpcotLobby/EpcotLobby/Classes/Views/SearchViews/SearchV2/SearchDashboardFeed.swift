//
//  SearchDashboardFeed.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 24/08/23.
//

import Foundation
import Combine
import CasinoAPI

class SearchDashboardFeed: ObservableObject {
    
    // MARK: Properties
    var feedDatasource: LobbyFeedDataSource?
    private var mostSearchedViewModel: MostSearchedGamesViewModel?
    private(set) var immersiveInfo: ((Game) -> ImmersiveGameInfo?)?
    private(set) var blurImagePath: ((Game) -> String?)?
    private(set) var onFavoriteGameTap: ((Game) -> Void)?
    private(set) var sticker: ((Game) -> String?)?
    
    @Published private(set) var categories: [SearchCategory]?
    @Published private(set) var stickerGames: [Game]?
    @Published private(set) var recommendedGames: [Game]?
    @Published private(set) var vendorGames: [VendorGames]?
    @Published private(set) var mostSearchedGames: [Game]?
    @Published private(set) var siteCoreGames: [Game]?
    @Published private(set) var refreshContainer = false
    
    private var subscribers = Set<AnyCancellable>()
    private var jackpotTimer: DispatchTimer?
    private(set) var gameTilePublisher: GameTilePublisher?
    
    // MARK: Init
    init(datasource: LobbyFeedDataSource? = nil,
         mostSearchedViewModel: MostSearchedGamesViewModel? = nil) {
        self.mostSearchedViewModel = mostSearchedViewModel
        self.feedDatasource = datasource
        self.allocateDataFields()
        self.cofigureBlurImagePath()
        self.configureImmersiveInfo()
        self.cofigureSticker()
        self.configureFavorite()
        self.subscribeToRefresh()
        self.subscribeToMostSearchedGames()
        self.startJackpotTimer()
    }
    
    private func allocateDataFields() {
        categories = [SearchCategory]()
        stickerGames = [Game]()
        recommendedGames = [Game]()
        vendorGames = [VendorGames]()
        mostSearchedGames = [Game]()
        siteCoreGames = [Game]()
        gameTilePublisher = GameTilePublisher()
    }
    
    // MARK: Subscriptions
    private func subscribeToRefresh() {
        self.feedDatasource?.feedViewModel?.refreshLobby
            .subscribe(on: DispatchQueue.main)
            .sink { [weak self] shouldRefresh in
                guard let self else { return }
                if shouldRefresh {
                    self.stopJackpotTimer()
                    self.updateSections()
                    self.startJackpotTimer()
                } else {
                    //No need to call this if sholud refresh is true, because it atomatically updates the view
                    self.refreshJackporPrices()
                }
            }
            .store(in: &subscribers)
    }
    
    private func subscribeToMostSearchedGames() {
        self.mostSearchedViewModel?.gamesUpdated
            .subscribe(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.refreshContainer = true
            }
            .store(in: &subscribers)
    }
    
    // MARK: Update
    private func updateSections() {
        fetchCategories()
        fetchStickerGames()
        fetchRecommendedGames()
        fetchMostSearchedGames()
        fetchSiteCoreGames()
        fetchVendorGames()
        refreshContainer = true
    }
    
    // MARK: Configure section data
    //MARK: Categories
    private func fetchCategories() {
        let categoryIdList = self.feedViewModel?.categoryIds
        categories = categoryIdList?.compactMap { id in
            guard !id.isEmpty else { return nil }
            let name = self.feedViewModel?.getCategoryName(for: id)
            if let name, !name.isEmpty {
                return SearchCategory(id: id, name: name)
            }
            return nil
        } ?? []
    }
    
    //MARK: LMT Games
    private func fetchStickerGames() {
        let section = sections.first { $0.sectionType == .lmtNewGames }
        guard let section else { return }
        stickerGames = feedViewModel?.getStickerGames(
            for: section.stickers,
            limit: section.limit
        ) ?? []
    }
    
    //MARK: Recommended Games
    private func fetchRecommendedGames() {
        let section = sections.first { $0.sectionType == .lmtRecommendedGames }
        guard let section else { return }
        recommendedGames = feedViewModel?.getRecommendedGames(limit: section.limit) ?? []
    }
    
    //MARK: Sitecore Games
    private func fetchSiteCoreGames() {
        let section = sections.first { $0.sectionType == .siteCoreGames }
        guard section != nil else { return }
        if let items = POSAPI.shared?.subNavigationMenu {
            items.forEach { item in
                let gameVaraiants = searchGames(with: item)
                self.siteCoreGames = gameVaraiants.compactMap { game in
                    let siteCoreGame = game.trimmingCharacters(in: .whitespaces)
                    let game = Game(game: siteCoreGame)
                    guard let imagePath = self.immersiveInfo?(game)?.imagePath else {
                        return nil
                    }
                    return game
                }
            }
        }
    }
    
    private func searchGames(with item: EntainSiteCoreMenuItemModel) -> [String] {
        let items = item.menuItem[.categories]?.items
        let firstItem = items?.first(where: {$0.title == "SearchScreenGames"})
        let gamesList = firstItem?.parameters?.gamesList ?? []
        return gamesList
    }

    //MARK: MostSearched Games
    private func fetchMostSearchedGames() {
        let section = sections.first { $0.sectionType == .mostSearchedGames }
        guard let section else { return }
        let games = self.mostSearchedViewModel?.gameVariants
        let filteredGames: [String] = games?.reduce(into: [String](), { partialResult, gameVariant in
            let game = Game(game: gameVariant)
            if let gameImmersiveInfo = self.immersiveInfo?(game),
               !(gameImmersiveInfo.imagePath ?? gameImmersiveInfo.gameInfo.imagePath).isEmpty,
               let blurImagePath = self.blurImagePath?(game),
               !blurImagePath.isEmpty {
                partialResult.append(gameVariant)
            }
        }) ?? []
        self.mostSearchedGames = filteredGames.prefix(section.limit).compactMap({ Game(game: $0) })
    }
    
    //MARK: Vendor Games
    private func fetchVendorGames() {
        let section = sections.first { $0.sectionType == .lmtGameProvider }
        guard section != nil else { return }
        let providerGames: [VendorGames] = feedViewModel?.vendorGames.compactMap({
            let name = $0.key
            let games = $0.value
            guard
                let dns = feedViewModel?.feedModel?.brandDNS,
                let imagePath = ETCasinoAPI.routes?[ETCasinoAPI.VendorImagePath],
                let providerId = feedViewModel?.vendorGameIds[name]
            else { return nil }
            let logo = "\(dns)\(imagePath)/\(providerId).jpg"
            return VendorGames(
                name: name,
                logo: logo,
                games: games
            )
        }) ?? []
        vendorGames = providerGames.sorted(by: { $0.games.count > $1.games.count })
    }

    // MARK: Helper
    var feedViewModel: FeedViewModel? {
        self.feedDatasource?.feedViewModel
    }
    
    private var sections: [SearchSection] {
        SearchSectionConfiguration().sections
    }
    
    func getGames(for section: SearchSection.SectionType) -> [Game] {
        switch section {
        case .lmtRecommendedGames: return recommendedGames ?? []
        case .mostSearchedGames: return mostSearchedGames ?? []
        case .lmtNewGames: return stickerGames ?? []
        case .siteCoreGames: return siteCoreGames ?? []
        // We are NOT going to handle the sections
        // - recent searches/categories/game providers
        default: return []
        }
    }
}

//MARK: - GameInfo
extension SearchDashboardFeed {
    private func cofigureBlurImagePath() {
        self.blurImagePath = { [weak self] game in
            guard let gameVariant = game.game else { return nil }
            return self?.feedViewModel?.getListCellBlurImagePath(for: gameVariant)
        }
    }
    
    private func cofigureSticker() {
        self.sticker = { [weak self] game in
            guard let gameVariant = game.sticker else { return nil }
            return self?.feedViewModel?.getCategoryName(for: gameVariant)
        }
    }

    private func configureImmersiveInfo() {
        self.immersiveInfo = { [weak self] game in
            guard let gameVariant = game.game else { return nil }
            return self?.feedViewModel?.getImmersiveInfo(for: gameVariant,
                                                         with: "\(LayoutType.verticalImmersiveGrid.rawValue)")
        }
    }
}

extension SearchDashboardFeed {
    private func configureFavorite() {
        self.onFavoriteGameTap = { [weak self] game in
            guard let gameVariant = game.game else { return }
            //Fetch local game info
            let gameFav = self?.immersiveInfo?(game)?.gameInfo.isFavouriteGame ?? false
            self?.updateFavorite(selected: !gameFav,
                                 for: gameVariant)
        }
    }
    
    private func updateFavorite(selected: Bool, for game: String) {
        
        //Updating local Feed
        self.feedViewModel?.updateFavouriteStateInFeed(with: selected,
                                                       for: game)
        //API
        Task {
            _ = try await self.feedViewModel?.updateFavouriteState(with: selected,
                                                                              for: game)
            let favoriteGames = self.feedDatasource?.feedViewModel?.favouriteGames?
                .reduce(into: [String: Bool](), { partialResult, favGame in
                    if let name = favGame.game {
                        partialResult[name] = true
                    }
                })
            //updating favorites through subscriber after API is completed 
            let favorites = GameTileReceiver(favorite: favoriteGames)
            self.gameTilePublisher?.send(favorites)
        }
    }
}

//MARK: - Jackpot
extension SearchDashboardFeed {
    private func startJackpotTimer() {
        guard  self.jackpotTimer == nil else { return }
        let randomInterval = Double.random(in: 1...6)
        self.jackpotTimer =  DispatchTimer(interval: randomInterval, handler: self.refreshJackpot)
    }
    
    func stopJackpotTimer() {
        guard self.jackpotTimer != nil else { return }
        self.jackpotTimer?.cancel()
        self.jackpotTimer = nil
    }
    
    private func refreshJackpot() {
        self.stopJackpotTimer()
        ///counter jackpot time update
        self.gameTilePublisher?.send(nil)
        self.startJackpotTimer()
    }
    
    private func refreshJackporPrices () {
        if let jpPrices = self.feedViewModel?.getAllJackpotAmounts() {
            let jackpots = GameTileReceiver(jackpot: jpPrices)
            gameTilePublisher?.send(jackpots)
        }
    }
}

extension SearchDashboardFeed: CleanProtocol {
    func clean() {
        self.feedDatasource = nil
        self.immersiveInfo = nil
        self.blurImagePath = nil
        self.onFavoriteGameTap = nil
        self.sticker = nil
        
        self.categories = nil
        self.stickerGames = nil
        self.recommendedGames = nil
        self.vendorGames = nil
        self.mostSearchedGames = nil
        self.siteCoreGames = nil

        self.subscribers.forEach { subscriber in
            subscriber.cancel()
        }
        self.subscribers.removeAll()
        
        self.gameTilePublisher = nil
        
        self.stopJackpotTimer()
    }
}
