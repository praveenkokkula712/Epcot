//
//  SearchContainerConfiguration.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 17/08/23.
//

import Foundation
import Utility

struct SearchSectionConfiguration {
    private let config: SearchConfiguration?
    let showCategories: Bool
    let sections: [SearchSection]
    let resultsLayoutType: Int
    let isFavouriteEnabled: Bool
    let isDownloadIconEnabled: Bool
    let isPlayButtonEnabled: Bool
    let isStickerEnabled: Bool
    let isJackpotAmountEnabled: Bool

    init(config: SearchConfiguration? = nil) {
        self.config = config ?? Self.datasource?.searchConfiguration
        showCategories = self.config?.showCategories ?? false
        sections = self.config?.sections.map { SearchSection(data: $0) } ?? []
        resultsLayoutType = self.config?.resultsLayoutType ?? 1
        isFavouriteEnabled = self.config?.favouriteEnabled ?? false
        isDownloadIconEnabled = self.config?.downloadIconEnabled ?? false
        isPlayButtonEnabled = self.config?.playButtonEnabled ?? false
        isStickerEnabled = self.config?.stickerEnabled ?? false
        isJackpotAmountEnabled = self.config?.jackpotEnabled ?? false
    }
}

extension SearchSectionConfiguration: LobbyDataSourceable {}
