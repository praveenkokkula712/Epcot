//
//  SearchSection.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 17/08/23.
//

import Foundation
import Utility

struct SearchSection: Hashable {
    let uuid = UUID()
    let title: String
    var layoutType: Layout
    let headerType: HeaderType
    let sectionType: SectionType
    let limit: Int
    let stickers: [String]
    
    init(data: SearchSectionData? = nil) {
        self.title = data?.title ?? ""
        self.layoutType = Layout(rawValue: data?.layoutType ?? 0) ?? .none
        self.headerType = HeaderType(rawValue: data?.headerType ?? 1) ?? .text
        self.sectionType = SectionType(rawValue: data?.dataSourceType ?? 0) ?? .none
        self.limit = data?.limit ?? 0
        self.stickers = data?.stickers ?? []
        if self.sectionType != .none && (self.layoutType == .none || !self.layoutType.isValid(self.sectionType)) {
            self.layoutType = self.defaultLayoutFor(self.sectionType)
        }
    }
    
    private func defaultLayoutFor(_ sectionType: SectionType) -> Layout {
        switch sectionType {
        case .recentSearch:
            return Self.isEpcot ? .listWithClose : .pillsWithClose
        case .lmtRecommendedGames, .mostSearchedGames, .lmtNewGames, .siteCoreGames:
            return Self.isEpcot ? .gamesList : .horizontalTiles
        case .lmtGameProvider:
            return .horizontalTiles
        case .lmtCategoryNames:
            return .pills
        default:
            return .none
        }
    }
}

extension SearchSection {
    enum Layout: Int {
        case none = 0
        // Recent search
        case pillsWithClose = 1
        case pills
        case listWithIconAndClose // ROW
        case listWithClose // Epcot
        case listWithArrow // Epcot & ROW
        
        // Categories
        case pillsContinuous = 6
        
        // Games
        case horizontalTiles = 7
        case gridTiles
        case doublePattyTilesWithBackground
        case doublePattyTiles
        case gamesList // Epcot
    }
    
    enum SectionType: Int {
        case none = 0
        case recentSearch = 1
        case lmtRecommendedGames // Pick category and sub from response based cat Featuremedata
        case mostSearchedGames
        case lmtNewGames
        case siteCoreGames // SitecoreList —- sitecorelist and LMT game variant intersection
        case lmtGameProvider
        case lmtCategoryNames
    }
    
    enum HeaderType: Int {
        case text = 1
        case textWithClear = 2
        case textWithClearAndIcon = 3
    }
}

extension SearchSection.SectionType {
    func sectionNameforEvent() -> String {
        switch self {
        case .mostSearchedGames:
            return EpcotEventPosition.most_searched.rawValue
        default:
            return EpcotEventPosition.search_result.rawValue
        }
    }
}

extension SearchSection.Layout {
    func isValid(_ sectionType: SearchSection.SectionType) -> Bool {
        switch sectionType {
        case .recentSearch:
            return Self.isEpcot ? rawValue == 4 : (1...3).contains(rawValue) || rawValue == 5
        case .lmtRecommendedGames, .mostSearchedGames, .lmtNewGames, .siteCoreGames:
            return (7...11).contains(rawValue)
        case .lmtGameProvider:
            return rawValue == 7
        case .lmtCategoryNames:
            return rawValue == 2 || rawValue == 6
        default:
            return true
        }
    }
}

extension SearchSection: EpcotCheckable { }

extension SearchSection.Layout: EpcotCheckable { }

//MARK: - static data for previews
extension SearchSection {
    
    static var recentlySearched: [String] {
        ["Casino", "Slingo", "Slots", "Pirates’ Plenty", "Lucky Little Devil", "Exclusive"]
    }
    
    static var gamesRecommended: [Game] {
        [
            Game(game: "Reel King", sticker:"reel-king-mega"),
            Game(game: "Pirates Plenty", sticker: "pirates-plenty"),
            Game(game: "Lucky Little Devil", sticker: "lucky-little-devil"),
            Game(game: "Esqueleto Mariachi", sticker: "lucky-little-devil-2"),
            Game(game: "Flaming Fox", sticker: "flaming-fox"),
            Game(game: "Dragons Luck", sticker: "dragons-luck"),
            Game(game: "Reel King", sticker:"reel-king-mega"),
            Game(game: "Pirates Plenty", sticker: "pirates-plenty"),
            Game(game: "Lucky Little Devil", sticker: "lucky-little-devil")
        ]
    }
    
    static var recentSearchSections: SearchSection {
        SearchSection(
            data: SearchSectionData(
                sectionData: [
                    "title": "Recent Searches",
                    "layoutType" : 3,
                    "dataSourceType" : 1,
                    "limit": 10,
                    "headerType" : 3,
                    "stickers": []
                ]
            )
        )
    }

    static var recommendedSections: SearchSection {
        SearchSection(
            data: SearchSectionData(
                sectionData: [
                    "title": "Recent Searches",
                    "layoutType" : 9,
                    "dataSourceType" : 2,
                    "limit": 10,
                    "headerType" : 1,
                    "stickers": []
                ]
            )
        )
    }

    static var mostSearchedSection: SearchSection {
        SearchSection(
            data: SearchSectionData(
                sectionData: [
                    "title": "Recent Searches",
                    "layoutType" : 7,
                    "dataSourceType" : 2,
                    "limit": 10,
                    "headerType" : 1,
                    "stickers": []
                ]
            )
        )
    }

    static var newGamesSection: SearchSection {
        SearchSection(
            data: SearchSectionData(
                sectionData: [
                    "title": "Recent Searches",
                    "layoutType" : 9,
                    "dataSourceType" : 4,
                    "limit": 10,
                    "headerType" : 1,
                    "stickers": []
                ]
            )
        )
    }

    static var categories: SearchSection {
        SearchSection(
            data: SearchSectionData(
                sectionData: [
                    "title": "Categories",
                    "layoutType" : 6,
                    "dataSourceType" : 7,
                    "limit": 10,
                    "headerType" : 1,
                    "stickers": []
                ]
            )
        )
    }

    static var sections: [SearchSection] {
        [
            //1
            SearchSection.recentSearchSections,
            //2
            SearchSection.recommendedSections,
            //3
            SearchSection.mostSearchedSection,
            //4
            SearchSection.newGamesSection,
            //5
            SearchSection.categories
        ]
    }
}
