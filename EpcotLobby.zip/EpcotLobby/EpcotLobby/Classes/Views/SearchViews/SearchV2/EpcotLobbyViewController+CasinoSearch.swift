//
//  CasinoSearchViewPresenter.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 08/08/23.
//

import UIKit
import SwiftUI
import Utility

extension EpcotLobbyViewController {
    func presentCasinoSearchView(isEpcot: Bool = false,
                                 isVoiceCommand: Bool,
                                 onGameTap: ((Game) -> Void)? = nil) {
        let feed = SearchDashboardFeed(datasource: self,
                                       mostSearchedViewModel: self.mostSearchedViewModel)
        let viewModel = SearchDashboardViewModel(
            isEpcot: isEpcot,
            isVoiceCommand: isVoiceCommand,
            feed: feed,
            onGameTap: onGameTap
        ) { [weak self] in
            NotificationCenter.default.post(name: Notification.Name(rawValue: kResetBottomSearchLayout), object: nil)
            self?.presentedViewController?.dismiss(animated: true)
            // to update favourites in lobby page,
            // when they are added from searchResults/searchdashboard
            self?.didUpdateCategoriesCollectionOnFavouritesUpdate()
        }
        let searchDashboardView = SearchDashboardView(viewModel: viewModel)
        self.enhancedSearchController = UIHostingController(rootView: searchDashboardView)
        self.enhancedSearchController?.presentWithAnimation()
        self.enhancedSearchController?.view.accessibilityIdentifier = SearchV2AccessibilityIdentifiers().dashboardView
        self.enhancedSearchController?.modalTransitionStyle = .crossDissolve
        self.enhancedSearchController?.modalPresentationStyle = .overFullScreen
        self.enhancedSearchController?.modalPresentationCapturesStatusBarAppearance = true
        self.enhancedSearchController?.view.layer.speed = 0.75
        self.enhancedSearchController?.view.backgroundColor = .black
        if let enhancedSearchController {
            self.present(enhancedSearchController, animated: true)
        }
    }
}
