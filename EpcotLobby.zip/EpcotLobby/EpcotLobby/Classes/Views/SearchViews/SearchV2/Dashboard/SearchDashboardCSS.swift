//
//  SearchDashboardCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 10/08/23.
//

import SwiftUI
import Utility

struct SearchDashboardCSS {

    // MARK: Properties
    let backgroundColor: Color
    
    // MARK: Init
    init(searchV2CSS: SearchV2CSS? = nil) {
        let css = searchV2CSS ?? Self.lobbyCSS?.searchV2CSS
        backgroundColor = Color(
            css?.backgroundColor ?? Self.defaultBackgroundColor
        )
    }
}

// MARK: - Helper
extension SearchDashboardCSS: EpcotCheckable, LobbyStylable { }

extension SearchDashboardCSS {
    private static var defaultBackgroundColor: UIColor {
        isEpcot ? .init(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0) : .black
    }
}
