//
//  RecentSearchView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 08/08/23.
//

import SwiftUI

struct RecentSearchView: View {
    @ObservedObject var viewModel: RecentSearchViewModel

    var body: some View {
        VStack {
            CasinoSearchContainerHeaderView(
                viewModel: CasinoSearchContainerHeaderViewModel(
                    searchSection: viewModel.section,
                    onClearTap: viewModel.onClearAll
                )
            )
            .padding(.trailing, 16)
        
            switch viewModel.layoutType {
            case .listWithIconAndClose, .listWithClose, .listWithArrow:
                let viewModel = ListLayoutViewModel<ListItem>(
                    listItems: viewModel.listItems ?? []
                )
                ListLayoutView(viewModel: viewModel)
            case .pills, .pillsWithClose, .pillsContinuous:
                let pillsViewModel = PillLayoutViewModel<Pill>(
                    layout: viewModel.section.layoutType,
                    pills: viewModel.pills ?? []
                )
                PillLayoutView(viewModel: pillsViewModel)
            default:
                EmptyView()
            }
        }
        .padding(.bottom, 8)
    }
}

struct RecentSearchView_Previews: PreviewProvider {
    static var previews: some View {
        RecentSearchView(
            viewModel: RecentSearchViewModel(
                section: SearchSection.recentSearchSections
            )
        )
        .background(Color.black.opacity(0.8))
    }
}
