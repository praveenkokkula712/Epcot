//
//  GameTileFavoriteIconView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 12/09/23.
//

import SwiftUI
import Utility

struct GameTileFavoriteIconView: View {
    let selected: Bool
    var onTap: (() -> Void)?
    let styles = SearchSectionsCSS()
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
    
    var body: some View {
        HStack() {
            Button {
                onTap?()
            } label: {
                Text(favoriteIcon)
                    .foregroundColor(styles.favouriteTintColor)
                    .font(favoriteIconFont)
                    .frame(width: 30, height: 30)
                    .background(styles.favouriteBackgroundColor)
                    .cornerRadius(15)
                    .clipped()
            }
            .accessibilityIdentifier(favoriteIconIdentifier)
        }
    }
}

extension GameTileFavoriteIconView {
    private var iconVariant: IconVariant? {
        let imageName = selected ? styles.favouriteIconSelected : styles.favouriteIconUnselected
        let iconVariant = EpcotLobbyManager.shared?.datasource?.didRequestForIconVariant(with: imageName,
                                                                                         fontSize: styles.favouritesIconFontSize)
        return iconVariant
    }
    
    private var favoriteIcon: String {
        return iconVariant?.icon ?? ""
    }
        
    private var favoriteIconFont: Font {
        Font(iconVariant?.font ?? .systemFont(ofSize: 14))
    }
}

// MARK: - Accessibility Identifiers
extension GameTileFavoriteIconView {
    
    private var favoriteIconIdentifier : String {
        accessibilityIdentifiers.favouriteIcon
    }
}

struct GameTileFavoriteIconView_Previews: PreviewProvider {
    static var previews: some View {
        GameTileFavoriteIconView(
            selected: false,
            onTap: nil
        )
    }
}
