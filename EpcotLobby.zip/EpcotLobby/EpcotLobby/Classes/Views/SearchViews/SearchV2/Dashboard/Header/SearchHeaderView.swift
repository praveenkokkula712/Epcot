//
//  SearchHeaderView.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 08/08/23.
//

import SwiftUI
import Utility

struct SearchHeaderView: View {

    // MARK: Properties
    private let enableClose: Bool
    private let styles = SearchHeaderCSS()
    private let screenStyle = SearchDashboardCSS()
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
    private let backAction: () -> Void
    private let closeAction: () -> Void

    // MARK: Init
    init(backAction: @escaping () -> Void,
         enableClose: Bool,
         closeAction: @escaping () -> Void) {
        self.backAction = backAction
        self.enableClose = enableClose
        self.closeAction = closeAction
    }

    // MARK: Body
    var body: some View {
        HStack {
            ImageButton(icon: backImage, action: backAction)
                .accessibilityIdentifier(backButtonIdentifier)

            Spacer()

            Text("search".localized)
                .font(styles.titleFont)
                .foregroundColor(styles.titleColor)
                .padding(.trailing, enableClose ? 0.0 : headerHeight)
                .accessibilityIdentifier(textIdentifier)

            Spacer()

            if enableClose {
                ImageButton(icon: closeImage, action: closeAction)
                    .accessibilityIdentifier(closeButtonIdentifier)
            }
        }
        .frame(height: headerHeight)
        .background(screenStyle.backgroundColor)
        .padding(.top, headerTop)
    }
}

// MARK: Previews
struct SearchHeaderView_Previews: PreviewProvider {
    static var previews: some View {
        SearchHeaderView(backAction: {}, enableClose: true, closeAction: {})
    }
}

// MARK: Design Constants
extension SearchHeaderView {
    private var headerTop: CGFloat { 8 }
    private var headerHeight: CGFloat { styles.height }
    private var imageSize: CGFloat { styles.backIconSize }
    private var backImage: UIImage {
        .init(named: kBack, in: kEpcotBundle, with: nil) ?? UIImage()
    }
    private var closeImage: UIImage {
        .init(named: "closeWhite", in: kEpcotBundle, with: nil) ?? UIImage()
    }
}

// MARK: Helper
extension SearchHeaderView {
    @ViewBuilder
    func ImageButton(icon: UIImage, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(uiImage: icon)
                .resizable()
                .scaledToFit()
                .frame(width: imageSize, height: imageSize)
        }
        .frame(width: headerHeight, height: headerHeight)
    }
}

// MARK: - Accessibility Identifiers
extension SearchHeaderView {
    private var backButtonIdentifier : String {
        accessibilityIdentifiers.headerBackButton
    }
    private var textIdentifier : String {
        accessibilityIdentifiers.headerTitle
    }
    private var closeButtonIdentifier : String {
        accessibilityIdentifiers.headerCloseButton
    }
}
