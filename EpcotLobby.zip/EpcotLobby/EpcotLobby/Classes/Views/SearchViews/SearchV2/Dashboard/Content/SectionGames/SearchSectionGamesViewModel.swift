//
//  SearchSectionGamesViewModel.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 24/08/23.
//

import Foundation
import Combine
import CasinoAPI

class SearchSectionGamesViewModel: ObservableObject {
    
    // MARK: Properties
    let section: SearchSection
    @Published private(set) var sectionGames = [GameTile]()
    
    private var games: [Game]
    private var sticker: ((Game) -> String?)?
    private var blurImagePath: ((Game) -> String?)?
    private var immersiveInfo: ((Game) -> ImmersiveGameInfo?)?
    private var onGameTap: ((Game) -> Void)?
    private var onFavoriteTap: ((Game) -> Void)?
    private var gameTilePublisher: GameTilePublisher?
    
    // MARK: Init
    init(section: SearchSection = SearchSection(),
         games: [Game] = [],
         blurImagePath: ((Game) -> String?)? = nil,
         sticker: ((Game) -> String?)? = nil,
         immersiveInfo: ((Game) -> ImmersiveGameInfo?)? = nil,
         publisher: GameTilePublisher? = nil,
         onGameTap: ((Game) -> Void)? = nil,
         onFavoriteTap: ((Game) -> Void)? = nil) {
        self.section = section
        self.games = games
        self.blurImagePath = blurImagePath
        self.sticker = sticker
        self.immersiveInfo = immersiveInfo
        self.gameTilePublisher = publisher
        self.onGameTap = onGameTap
        self.onFavoriteTap = onFavoriteTap
        self.configureContent()
    }
    
    // MARK: - Helper
    private func configureContent() {
        self.sectionGames = games.map { game in
            GameTile(
                game: game,
                sticker: sticker?(game),
                blurImagePath: blurImagePath?(game),
                immersiveInfo: immersiveInfo?(game),
                publisher: gameTilePublisher,
                onTap: { [weak self] gameTile in
                    self?.onGameTap?(gameTile.game)
                },
                onFavoriteTap: { [weak self] gameTile in
                    self?.onFavoriteTap?(gameTile.game)
                }
            )
        }
    }
}

extension SearchSectionGamesViewModel: CleanProtocol {
    func clean() {
        self.games.removeAll()
        
        self.sticker = nil
        self.blurImagePath = nil
        self.immersiveInfo = nil
        
        self.onGameTap = nil
        self.onFavoriteTap = nil
        self.gameTilePublisher = nil
    }
}
