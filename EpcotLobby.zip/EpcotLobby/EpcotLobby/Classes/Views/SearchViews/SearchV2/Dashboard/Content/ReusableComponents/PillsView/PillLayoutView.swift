//
//  PillLayoutView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 08/08/23.
//

import SwiftUI

struct PillLayoutView<PillConfig: PillViewConfigurable>: View {

    // MARK: Properties
    private let viewModel: PillLayoutViewModel<PillConfig>
    private let pills: [PillConfig]

    // MARK: Init
    init(viewModel: PillLayoutViewModel<PillConfig>) {
        self.viewModel = viewModel
        let sections = SearchSectionConfiguration().sections
        let limit = sections.first(where: { $0.sectionType == .recentSearch })?.limit ?? 5
        pills = viewModel.pills.prefix(limit).compactMap { $0 }
    }

    // MARK: Body
    var body: some View {
        switch viewModel.layout {
        case .pillsContinuous:
            HorizontalPillsView(pills: pills)
        case .pills, .pillsWithClose:
            GridPillsView(pills: pills)
        default:
            EmptyView()
        }
    }
}

// MARK: - Previews
struct PillLayoutView_Previews: PreviewProvider {
    static var previews: some View {
        let pills = [
            PillViewModel_Preview(title: "Casino"),
            PillViewModel_Preview(title: "New")
        ]
        let viewModel = PillLayoutViewModel<PillViewModel_Preview>(
            layout: .pills,
            pills: pills
        )
        PillLayoutView(viewModel: viewModel)
    }
}
