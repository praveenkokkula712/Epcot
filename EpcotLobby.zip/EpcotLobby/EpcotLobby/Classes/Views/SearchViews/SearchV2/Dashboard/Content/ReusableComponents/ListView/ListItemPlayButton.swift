//
//  ListItemPlayButton.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 05/12/23.
//

import SwiftUI
import Utility

struct ListItemPlayButton: View {
    
    // MARK: Properties
    private var styles = SearchSectionsCSS()
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
    
    // MARK: Body
    var body: some View {
        HStack {
            Text(Localize.kPlay)
                .frame(width: 50, height: 30)
                .padding(.horizontal, 12)
                .applyEpcotGradientBgColor(backgroundColor: styles.playIconBGColor,
                                           font: styles.downloadIconTitleFont,
                                           textColor: styles.playIconTitleColor,
                                           cornerRadius: 4,
                                           isEpcotEnabled: CasinoCSS.lobby?.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false)
                .accessibilityIdentifier(playButtonIdentifier)
            
        }
    }
}

extension ListItemPlayButton {
    
    private var playButtonIdentifier : String {
        accessibilityIdentifiers.listViewPlayButton
    }
}


// MARK: - Previews
struct ListItemPlayButton_Previews: PreviewProvider {
    static var previews: some View {
        ListItemPlayButton()
    }
}


