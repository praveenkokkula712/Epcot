//
//  GameTileListItemViewWithPlayButton.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 01/12/23.
//

import SwiftUI
import Utility

struct GameTileListItemViewWithPlayButton<GameConfig>: View
where GameConfig: GameTileConfigurable {
    
    // MARK: Properties
    let game: GameConfig
    private let searchText: String
    @ObservedObject private var viewModel: GameTileViewModel
    
    init(game: GameConfig, searchText: String = "") {
        self.game = game
        self.searchText = searchText
        self.viewModel = GameTileViewModel(self.game)
    }
    
    // MARK: Body
    var body: some View {
        ZStack(alignment: .top) {
            HStack {
                GameTileImageView(
                    path: game.imagePath,
                    width: imageTileWidth,
                    height: imageTileWidth,
                    cornerRadius: styles.gameTileCornerRadius
                )
                .shadow(
                    color: styles.shadowColor,
                    radius: styles.gameTileCornerRadius,
                    x: 5, y: 10
                )
                
                Spacer()
                    .frame(width: 8)
                
                VStack(alignment: .leading, spacing: 2.0) {
                    HighlightedText(
                        game.name,
                        matching: searchText,
                        caseInsensitive: true,
                        color: searchText.isEmpty ? highLightedTextColor : listItemStyles.listItemTitleColor,
                        highlightTextColor: highLightedTextColor
                    )
                    .font(listItemStyles.listItemTitleFont)
                    
                    if viewModel.isJackpotAmountEnabled, let jackpotAmount = self.viewModel.jackpotAmount {
                        Text(jackpotAmount)
                            .foregroundColor(styles.jpPriceColor)
                            .font(styles.jpPriceFont)
                    }
                }
                
                Spacer(minLength: 16)
                
                if viewModel.isPlayButtonEnabled && game.immersiveInfo?.gameInfo.localGameDownLoadState ?? false {
                    VStack {
                        ListItemPlayButton()
                    }
                }
            }
            .background(backgroundView)
            .padding([.leading , .vertical], 8)
            .padding(.trailing, 16)
            .onTapGesture {
                game.onTap(game)
            }
            
            HStack {
                //Sticker
                if viewModel.isStickerEnabled {
                    if let sticker = game.sticker, !sticker.isEmpty {
                        StickerView(stickerLabel: sticker)
                            .padding(.top, 4)
                    }
                }
                
                Spacer()
                
                //Favorite Icon
                if viewModel.isFavouriteEnabled {
                    GameTileFavoriteIconView(
                        selected: viewModel.isFavorited
                    ) {
                        viewModel.isFavorited = !viewModel.isFavorited
                        game.onFavoriteTap(game)
                    }
                    .padding(.top, 4)
                }
            }
            .padding(.trailing, 16)
            .padding(.leading, 6)
        }
    }
}
          
extension GameTileListItemViewWithPlayButton {
    private var styles: SearchSectionsCSS {
        viewModel.styles
    }
    
    private var listItemStyles: SearchResultsCSS {
        viewModel.resultsStyles
    }
    
    private var highLightedTextColor: Color {
        return Color(listItemStyles.highlightedSearchTextColor)
    }
}

// MARK: Helper
extension GameTileListItemViewWithPlayButton {
    private var backgroundView: some View {
        guard
            let blurImagePath = game.blurImagePath,
            !blurImagePath.isEmpty else {
            return AnyView(
                Color.gray.opacity(0.6)
                    .cornerRadius(styles.gameTileCornerRadius)
                    .clipped()
            )
        }
        
        return AnyView(
            GameTileImageView(
                path: game.blurImagePath ?? "",
                width: tileWidth,
                height: tileHeight,
                cornerRadius: styles.gameTileCornerRadius
            )
            .opacity(0.2)
        )
    }
}

extension GameTileListItemViewWithPlayButton {
    private var imageTileWidth: CGFloat { 84 }
    private var tileWidth: Double {
        return UIApplication.screenSize.width - 32.0
    }
    private var tileHeight: CGFloat { 98 }
}

struct GameTileListItemViewWithPlayButton_Previews: PreviewProvider {
    static var previews: some View {
        GameTileListItemViewWithPlayButton(
            game: GameTile(
                game: SearchSection.gamesRecommended[0],
                onTap: { _ in },
                onFavoriteTap: { _ in })
        )
        .background(Color.black.opacity(0.8))
    }
}
