//
//  SearchBarViewModel.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 08/08/23.
//

import Foundation
import Combine

class SearchBarViewModel: ObservableObject {
    
    //MARK: Properties
    @Published var searchText: String = ""
    var voiceCommandAction: () -> Void = {}
    var cancelAction: () -> Void = {}
    var preferences: RecentSearchPreferences?
    @Published var speechStatus = false
    @Published var isOnboardingJourneyCompleted = false
    
    var isClearButtonEnabled: Bool {
        return !searchText.isEmpty && !speechStatus
    }
   
    var isTextNotEmpty: Bool { !searchText.isEmpty }

    // MARK: Init
    init(preferences: RecentSearchPreferences = RecentSearchPreferences(),
         voiceCommandAction: @escaping () -> Void = {},
         cancelAction: @escaping () -> Void = {}) {
        self.preferences = preferences
        self.voiceCommandAction = voiceCommandAction
        self.cancelAction = cancelAction
    }
    
    // MARK: Save Preferences
    func savePreference() {
        if !searchText.isEmpty {
            preferences?.append(searchText)
        }
    }
    
    //MARK: Dismiss Keyboard
    func dismissKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),
                                        to: nil,
                                        from: nil,
                                        for: nil
        )
    }
}

extension SearchBarViewModel: EpcotCheckable {}
