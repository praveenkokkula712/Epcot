//
//  RecentSearchViewModel.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 17/08/23.
//

import Foundation
import Combine

class RecentSearchViewModel: ObservableObject {
    
    // MARK: Properties
    let section: SearchSection
    private var preferences: RecentSearchPreferences?
    lazy var layoutType: SearchSection.Layout = {
        section.layoutType
    }()

    @Published var pills: [Pill]?
    @Published var listItems: [ListItem]?
    private var cancellables = Set<AnyCancellable>()

    // MARK: Init
    init(section: SearchSection = SearchSection(),
         preferences: RecentSearchPreferences = RecentSearchPreferences()) {
        self.section = section
        self.preferences = preferences
        self.subscribeToPreferences()
    }
    
    // MARK: Subscriptions
    private func subscribeToPreferences() {
        preferences?.$searchWords
            .subscribe(on: DispatchQueue.main)
            .sink { [weak self] words in
                guard let self else { return }
                self.configureContent(from: words)
            }
            .store(in: &cancellables)
    }
    
    // MARK: Actions
    private func onPillTap(_ pill: any PillViewConfigurable) {
        preferences?.onTapRecentSearch?(pill.title)
    }

    private func onRemove(_ pill: any PillViewConfigurable) {
        preferences?.remove(pill.title)
        //TODO: check and remove the subscriber if possible
    }
    
    func onClearAll() {
        preferences?.removeAll()
        self.clearAllSubscribers()
    }
    
    // MARK: - Helper
    private func configureContent(from words: [String]) {
        pills = words.map { word in
            Pill(
                title: word,
                isRemoveEnabled: isRemoveEnabled,
                onTap: { [weak self] pill in
                    self?.onPillTap(pill)
                },
                onRemove: { [weak self] pill in
                    self?.onRemove(pill)
                }
            )
        }

        listItems = words.map { word in
            ListItem(
                title: word,
                isRemoveEnabled: isRemoveEnabled,
                onTap: { [weak self] listItem in
                    self?.onPillTap(listItem)
                }, onRemove: { [weak self] listItem in
                    self?.onRemove(listItem)
                },
                showLeadingAccessoryIcon: showLeadingAccessoryIcon,
                showTrailingAccessoryIcon: showTrailingAccessoryIcon
            )
        }
    }
}

extension RecentSearchViewModel {
    var showLeadingAccessoryIcon: Bool {
        layoutType == .listWithIconAndClose
    }

    private var isRemoveEnabled: Bool {
        layoutType == .pillsWithClose ||
        layoutType == .listWithIconAndClose ||
        layoutType == .listWithClose
    }
    
    var showTrailingAccessoryIcon: Bool {
        layoutType == .listWithArrow
    }
}

extension RecentSearchViewModel: CleanProtocol {
    func clean() {
        self.clearAllSubscribers()
    }
    
    private func clearAllSubscribers() {
        self.cancellables.forEach { subscriber in
            subscriber.cancel()
        }
        self.cancellables.removeAll()
    }
}
