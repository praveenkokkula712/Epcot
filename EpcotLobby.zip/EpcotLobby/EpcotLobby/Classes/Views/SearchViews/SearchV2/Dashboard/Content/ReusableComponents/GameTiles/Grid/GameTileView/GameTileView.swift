//
//  GameTileView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 09/08/23.
//

import SwiftUI
import Utility

var GameTileImageSize: CGFloat {
    let multiplier = UIDevice.isIPad() ? 0.18 : 0.29
    return UIApplication.screenSize.width * multiplier
}

struct GameTileView<GameTileConfig>: View
where GameTileConfig: GameTileConfigurable {
    
    // MARK: Properties
    let game: GameTileConfig
    let size: CGSize
    @ObservedObject private var viewModel: GameTileViewModel
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()

    init(game: GameTileConfig,
         isFromSearch: Bool = true,
         size: CGSize = .init(
            width: GameTileImageSize,
            height: GameTileImageSize
         )
    ) {
        self.game = game
        self.size = size
        self.viewModel = GameTileViewModel(self.game,
                                           isFromSearch: isFromSearch)
    }
    
    // MARK: Body
    var body: some View {
        ZStack {
            //Game Image
            Button {
                game.onTap(game)
            } label: {
                GameTileImageView(
                    path: game.imagePath,
                    width: size.width,
                    height: size.height,
                    cornerRadius: styles.gameTileCornerRadius
                )
                .shadow(
                    color: styles.shadowColor,
                    radius: styles.gameTileCornerRadius,
                    x: 5, y: 10
                )
            }
            
            VStack(spacing: 0) {
                HStack {
                    
                    //Sticker
                    if viewModel.isStickerEnabled {
                        if let sticker = game.sticker, !sticker.isEmpty {
                            StickerView(stickerLabel: sticker)
                                .padding([.top, .leading], 4)
                        }
                    }
                    
                    Spacer()
                    
                    //Favorite Icon
                    if viewModel.isFavouriteEnabled {
                        GameTileFavoriteIconView(
                            selected: viewModel.isFavorited
                        ) {
                            viewModel.isFavorited = !viewModel.isFavorited
                            game.onFavoriteTap(game)
                        }
                        .padding([.top, .trailing], 4)
                    }
                }
                
                Spacer(minLength: 4)
                
                if viewModel.isDownloadIconEnabled, game.immersiveInfo?.gameInfo.localGameDownLoadState ?? false,
                   let uiimage = playIcon {
                    //Play icon
                    HStack {
                        Spacer()
                        Image(uiImage: uiimage)
                            .padding([.bottom, .trailing], 8)
                            .frame(width: 24, height: 24)
                            .accessibilityIdentifier(playIconIdentifier)
                    }
                }
                
                //Jackpot Amount
                if let jpAmount = self.viewModel.jackpotAmount {
                    GameTileJackpotView(
                        value: jpAmount,
                        isIconEnabled: viewModel.isHotJackpotGame ?? false,
                        jackpotFireIconImagePath: viewModel.jackpotFireImagePath
                    )
                }
            }
            .cornerRadius(styles.gameTileCornerRadius)
        }
        .frame(width: size.width, height: size.height)
    }
}

extension GameTileView {
    private var styles: SearchSectionsCSS {
        viewModel.styles
    }
}

// MARK: Design Constants
extension GameTileView {
    private var playIcon: UIImage? {
        UIImage(named: kRecentPlayIcon,
                in: Bundle(for: GameTileViewModel.self),
                with: .none)
    }
}

// MARK: - Accessibility Identifiers
extension GameTileView {
    
    private var playIconIdentifier : String {
        accessibilityIdentifiers.playIcon
    }
}

// MARK: - Previews
struct GameTileView_Previews: PreviewProvider {
    static var previews: some View {
        GameTileView(
            game: GameTile(
                game: SearchSection.gamesRecommended[0],
                onTap: { _ in },
                onFavoriteTap: { _ in }
            )
        )
        .background(Color.blue)
    }
}
