//
//  SearchedCategory.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 28/08/23.
//

import Foundation

struct SearchCategory: Identifiable {
    
    // MARK: Properties
    var id: String
    var name: String
}
