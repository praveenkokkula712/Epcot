//
//  GameTileLayoutView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 24/08/23.
//

import SwiftUI

struct GameTileLayoutView: View {

    // MARK: Properties
    let layoutType: SearchSection.Layout
    let games: [GameTile]

    // MARK: Body
    var body: some View {
        switch layoutType {
        case .horizontalTiles:
            HorizontalGameTileContainerView(games: games)
        case .gridTiles:
            HorizontalGameTileContainerView(stack: .double, games: games)
        case .doublePattyTiles, .doublePattyTilesWithBackground:
            HorizontalDoubleStackRectangleGameTileView(games: games)
        case .gamesList:
            GameTileListView(games: games)
        default:
            EmptyView()
        }
    }
}
