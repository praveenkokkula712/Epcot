//
//  CasinoSearchContainerHeaderViewModel.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 18/08/23.
//

import Foundation

class CasinoSearchContainerHeaderViewModel {
    let searchSection: SearchSection
    let vendorsCount: Int
    private let vendorsMinCount: Int
    let showViewAll: Bool
    var onClearTap: (() -> Void)?

    init(searchSection: SearchSection,
         vendorsCount: Int = 0,
         vendorsMinCount: Int = 0,
         showViewAll: Bool = false,
         onClearTap: (() -> Void)? = nil) {
        self.searchSection = searchSection
        self.vendorsCount = vendorsCount
        self.vendorsMinCount = vendorsMinCount
        self.showViewAll = showViewAll
        self.onClearTap = onClearTap
    }
}

//MARK: Helper
extension CasinoSearchContainerHeaderViewModel {
    
    var showClearAll: Bool {
        searchSection.headerType != .text
    }
    
    var showClearIcon: Bool {
        searchSection.headerType == .textWithClearAndIcon
    }

    //For Vendors
    var showViewAllEnabled: Bool {
        vendorsCount > vendorsMinCount
    }
}
