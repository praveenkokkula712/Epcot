//
//  CasinoSearchContainerHeaderView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 08/08/23.
//

import SwiftUI
import Utility

struct CasinoSearchContainerHeaderView: View {
    let viewModel: CasinoSearchContainerHeaderViewModel
    private let styles = SearchSectionsCSS()
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
    
    var body: some View {
        HStack (spacing: 8) {
            Text(viewModel.searchSection.title.localized)
                .font(styles.headerTitleFont)
                .foregroundColor(styles.headerTitleColor)
                .accessibilityIdentifier(headerTitleIdentifier)
            Spacer()
            if viewModel.showClearIcon {
                Button {
                    viewModel.onClearTap?()
                } label: {
                    Image(uiImage: trash)
                }
                .accessibilityIdentifier(trashIconIdentifier)
            }
            if viewModel.showClearAll {
                Button {
                    viewModel.onClearTap?()
                } label: {
                    Text("clear_all".localized)
                        .font(styles.clearAllTitleFont)
                        .foregroundColor(styles.clearAllTitleColor)
                        .accessibilityIdentifier(clearAllTextIdentifier)
                }
            }
            if viewModel.showViewAllEnabled {
                Button {
                    viewModel.onClearTap?()
                } label: {                    
                    let vendorsText = viewModel.showViewAll ? "view_all" : "hide"
                    let vendorsCount = viewModel.showViewAll ? "(\(viewModel.vendorsCount))" : ""
                    Text("\(vendorsText.localized) \(vendorsCount)")
                        .font(styles.clearAllTitleFont)
                        .foregroundColor(styles.clearAllTitleColor)
                        .underline(true, color: styles.clearAllTitleColor)
                }
                .accessibilityIdentifier(viewModel.showViewAll ? viewAllTextIdentifier : hideTextIdentifier)
            }
        }
        .padding(.vertical, 12)
        .frame(height: frameHeight)
    }
}

struct CasinoSearchContainerHeaderView_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            CasinoSearchContainerHeaderView(
                viewModel: CasinoSearchContainerHeaderViewModel(
                    searchSection: SearchSection.recentSearchSections
                )
            )
            CasinoSearchContainerHeaderView(
                viewModel: CasinoSearchContainerHeaderViewModel(
                    searchSection: SearchSection.recommendedSections
                )
            )
        }
        .padding(.horizontal, 16)
        .background(Color.black.opacity(0.8))
    }
}

extension CasinoSearchContainerHeaderView {
    private var frameHeight: CGFloat { 56 }
    private var trash: UIImage {
        return .init(named: "gray-trash", in: kEpcotBundle, with: nil) ?? UIImage()
    }
}

// MARK: - Accessibility Identifiers
extension CasinoSearchContainerHeaderView {
    
    private var headerTitleIdentifier : String {
        accessibilityIdentifiers.categoryTitle
    }
    private var trashIconIdentifier : String {
        accessibilityIdentifiers.trashIcon
    }
    private var clearAllTextIdentifier : String {
        accessibilityIdentifiers.clearAllText
    }
    private var viewAllTextIdentifier : String {
        accessibilityIdentifiers.viewAllText
    }
    private var hideTextIdentifier : String {
        accessibilityIdentifiers.hideText
    }
}
