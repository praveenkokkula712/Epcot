//
//  ListLayoutView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 08/08/23.
//

import SwiftUI

struct ListLayoutView<ListItem: ListItemConfigurable>: View {
    
    // MARK: Properties
    private let viewModel: ListLayoutViewModel<ListItem>
    private let items: [ListItem]

    // MARK: Init
    init(viewModel: ListLayoutViewModel<ListItem>) {
        self.viewModel = viewModel
        let sections = SearchSectionConfiguration().sections
        let limit = sections.first(where: { $0.sectionType == .recentSearch })?.limit ?? 5
        items = viewModel.listItems.prefix(limit).compactMap { $0 }
    }
    
    // MARK: Body
    var body: some View {
        ScrollView(showsIndicators: false) {
            ForEach(items) { item in
                ListItemView(item: item)
            }
        }
        .padding(.trailing, 16)
    }
}

struct ListLayoutView_Previews: PreviewProvider {
    static var previews: some View {
        let items = [
            ListItem_Preview(title: "Casino"),
            ListItem_Preview(title: "Home")
        ]
        let viewModel = ListLayoutViewModel(listItems: items)
        ListLayoutView(viewModel: viewModel)
            .background(Color.black.opacity(0.8))
    }
}
