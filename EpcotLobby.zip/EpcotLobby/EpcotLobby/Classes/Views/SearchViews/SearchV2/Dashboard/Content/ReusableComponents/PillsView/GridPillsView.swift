//
//  GridPillsView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 08/08/23.
//

import SwiftUI

struct GridPillsView<PillConfig: PillViewConfigurable>: View {

    // MARK: Properties
    private let pills: [PillConfig]
    private let pillsTitles: [String]

    // MARK: Init
    init(pills: [PillConfig]) {
        self.pills = pills
        self.pillsTitles = pills.compactMap { $0.title }
    }

    // MARK: Body
    var body: some View {
        FlexibleView(
            data: pillsTitles,
            spacing: 8,
            alignment: .leading
        ) { pillTitle -> PillView<PillConfig> in
            if let pill = pills.first(where: { $0.title == pillTitle }) {
                return PillView(pill: pill)
            }
            return PillView(pill: nil)
        }
        .padding(.trailing, 16)
    }
}

// MARK: - Previews
struct GridPillsView_Previews: PreviewProvider {
    static var previews: some View {
        let pills = [
            PillViewModel_Preview(title: "Casino"),
            PillViewModel_Preview(title: "New")
        ]
        GridPillsView(pills: pills)
        .background(Color.black.opacity(0.8))
    }
}
