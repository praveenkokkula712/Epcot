//
//  GameCategoryTabView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 20/09/23.
//

import SwiftUI
import CasinoAPI

struct GameCategoryTabView: View {

    // MARK: Properties
    @ObservedObject var viewModel: GameCategoryTabViewModel
    private let styles = SearchResultsCSS()
    private let sectionStyles =  SearchSectionsCSS()
    @Namespace var namespace

    // MARK: Body
    var body: some View {
        VStack {
            ScrollViewReader { scrollView in
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(viewModel.tabs, id: \.1.uuid ) { index, tab in
                            let id = tab.title
                            VStack {
                                Button {
                                    withAnimation {
                                        if viewModel.onSelectGameCategoryTab(tab) {
                                            viewModel.currentId = tab.uuid
                                            scrollView.scrollTo(viewModel.currentId, anchor: anchor)
                                        }
                                    }
                                } label: {
                                    let isSelected = viewModel.currentId == tab.uuid
                                    Text(tab.title)
                                        .padding(.top, 12)
                                        .font(isSelected ? styles.selectedTabTextFont : styles.unSelectedTabTextFont)
                                        .foregroundColor(isSelected ? styles.selectedTabTextColor : styles.unselectedTabTextColor)
                                        .if(shouldApplyPadding) { view in
                                            view.fixedSize(horizontal: true, vertical: false)
                                        }
                                }
                                .accessibility(identifier: id)
                                .buttonStyle(GradientButtonStyle())
                                .padding(.horizontal, 10)
                                
                                if viewModel.currentId == tab.uuid {
                                    Color(styles.hairLineColor)
                                        .frame(height: hairLineHeight)
                                        .cornerRadius(hairLineHeight / 2)
                                        .matchedGeometryEffect(id: "animation", in: namespace)
                                } else {
                                    Color.clear
                                        .frame(height: hairLineHeight)
                                        .cornerRadius(hairLineHeight / 2)
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                }
                .onChange(of: viewModel.categoryTabs) { _ in
                    withAnimation {
                        scrollView.scrollTo(viewModel.currentId, anchor: anchor)
                    }
                }
                .onReceive(viewModel.$categoryTabs) { _ in
                    withAnimation {
                        scrollView.scrollTo(viewModel.currentId, anchor: anchor)
                    }
                }
            }
        }
    }
}

// MARK: Helper
extension GameCategoryTabView {
    private var hairLineHeight: CGFloat { styles.hairLineHeight }
}

// MARK: - Previews
struct GameCategoryTabView_Previews: PreviewProvider {
    static var previews: some View {
        let tabs = ["Home", "Casino"]
        GameCategoryTabView(
            viewModel: GameCategoryTabViewModel(
                categories: tabs,
                selectedCategory: "",
                onSelectGameCategoryTab: { _ in true }
            )
        )
    }
}
