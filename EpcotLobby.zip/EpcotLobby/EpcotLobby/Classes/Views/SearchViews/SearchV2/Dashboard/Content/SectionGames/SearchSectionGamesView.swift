//
//  SearchSectionGamesView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 09/08/23.
//

import SwiftUI

struct SearchSectionGamesView: View {
    @ObservedObject var viewModel: SearchSectionGamesViewModel

    var body: some View {
        VStack {
            CasinoSearchContainerHeaderView(
                viewModel: CasinoSearchContainerHeaderViewModel(
                    searchSection: viewModel.section
                )
            )

            GameTileLayoutView(
                layoutType: viewModel.section.layoutType,
                games: viewModel.sectionGames
            )
        }
        .padding(.bottom, 8)
    }
}

struct SearchSectionGamesView_Previews: PreviewProvider {
    static var previews: some View {
        SearchSectionGamesView(viewModel: SearchSectionGamesViewModel())
            .background(Color.black.opacity(0.8))
    }
}
