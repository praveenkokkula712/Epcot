//
//  HorizontalPillsView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 08/08/23.
//

import SwiftUI

struct HorizontalPillsView<PillConfig: PillViewConfigurable>: View {

    // MARK: Properties
    private let pills: [PillConfig]

    // MARK: Init
    init(pills: [PillConfig]) {
        self.pills = pills
    }

    // MARK: Body
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(pills, id: \.id) { pill in
                    PillView(pill: pill)
                }
            }
            .padding(.trailing, 16)
        }
    }
}

// MARK: - Previews
struct HorizontalPillsView_Previews: PreviewProvider {
    static var previews: some View {
        let pills = [
            PillViewModel_Preview(title: "Casino"),
            PillViewModel_Preview(title: "New")
        ]
        HorizontalPillsView(pills: pills)
        .background(Color.black.opacity(0.8))
    }
}
