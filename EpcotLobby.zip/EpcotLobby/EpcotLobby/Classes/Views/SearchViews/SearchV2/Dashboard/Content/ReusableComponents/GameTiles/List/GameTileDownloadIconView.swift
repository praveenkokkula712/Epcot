//
//  GameTileDownloadIconView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 12/09/23.
//

import SwiftUI
import Utility

struct GameTileDownloadIconView: View {
    let isGameDownloaded: Bool
    let onTap: (() -> Void)?
    let styles = SearchSectionsCSS()
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
    
    var body: some View {
        Button {
            onTap?()
        } label: {
            if isGameDownloaded {
                Text(Localize.kPlay)
                    .frame(width: 40, height: 30)
                    .applyEpcotGradientBgColor(backgroundColor: styles.playIconBGColor,
                                               font: styles.downloadIconTitleFont,
                                               textColor: styles.playIconTitleColor,
                                               cornerRadius: styles.downloadIconCornerRadius,
                                               isEpcotEnabled: CasinoCSS.lobby?.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false)
                    .accessibilityIdentifier(playButtonIdentifier)
            } else {
                if ImmersiveInstance.shared.isEnabled {
                    if let image = UIImage(named: kDownloadIcon,
                                           in: Bundle(for: GameTileViewModel.self),
                                           with: .none) {
                        Image(uiImage: image)
                            .frame(width: 32, height: 32)
                            .background(styles.downloadIconBGColor)
                            .accessibilityIdentifier(downloadIconIdentifier)
                    }
                } else {
                    Text(Localize.kDownload)
                        .foregroundColor(styles.downloadIconTitleColor)
                        .font(styles.downloadIconTitleFont)
                        .frame(width: 32, height: 32)
                        .border(styles.downloadIconBorderColor, width: 2.0)
                        .accessibilityIdentifier(downloadButtonIdentifier)
                }
            }
        }
        .cornerRadius(styles.downloadIconCornerRadius)
    }
}

// MARK: - Accessibility Identifiers
extension GameTileDownloadIconView {
    
    private var playButtonIdentifier : String {
        accessibilityIdentifiers.playButton
    }
    private var downloadButtonIdentifier : String {
        accessibilityIdentifiers.downloadButton
    }
    private var downloadIconIdentifier : String {
        accessibilityIdentifiers.downloadIcon
    }
}

struct GameTileDownloadIconView_Previews: PreviewProvider {
    static var previews: some View {
        GameTileDownloadIconView(
            isGameDownloaded: true,
            onTap: nil
        )
    }
}
