//
//  GameTileViewModel.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 07/09/23.
//

import Foundation
import Combine
import ConfigModule

class GameTileViewModel: ObservableObject {
    private let game: String
    let styles = SearchSectionsCSS()
    let resultsStyles = SearchResultsCSS()
    private let isFromSearch: Bool
    @Published var jackpotAmount: String?
    @Published var isFavorited: Bool
    private var subscriber: AnyCancellable?
    @Published var jackpotFireImagePath: String?
    @Published var isHotJackpotGame: Bool?

    init(_ gameConfig: any GameTileConfigurable,
         isFromSearch: Bool = true) {
        self.game = gameConfig.gameVariant
        self.isFromSearch = isFromSearch
        self.jackpotAmount = gameConfig.immersiveInfo?.gameInfo.jpPrice?.trimmingCharacters(in: .whitespaces)
        self.isFavorited = gameConfig.immersiveInfo?.gameInfo.isFavouriteGame ?? false
        self.jackpotFireImagePath = gameConfig.immersiveInfo?.fireIconImagePath
        self.isHotJackpotGame = gameConfig.immersiveInfo?.gameInfo.isHotJackpotGame ?? false
        self.subscribeTo(publisher: gameConfig.publisher)
    }
}

//Helper
extension GameTileViewModel {
    
    private var isLoggedIn: Bool {
        EntainContext.user?.isLoggedIn() ?? false
    }
    
    var isHTMLGamesEnabled: Bool { 
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.liveCasinoLMTConfig?.isHTMLGamesEnabled ?? false
    }
    
    var isFavouriteEnabled: Bool {
        let favouriteEnabled = (isLoggedIn && EpcotLobbyManager.shared?.datasource?.shouldDisplayView(of: .favouriteGamesView) ?? false)
        guard isFromSearch else {
            return favouriteEnabled
        }
         return favouriteEnabled && SearchSectionConfiguration().isFavouriteEnabled
    }
    
    var isDownloadIconEnabled: Bool {
        let downloadIconEnabled = isLoggedIn && !isHTMLGamesEnabled
        guard isFromSearch else {
            return downloadIconEnabled
        }
        return downloadIconEnabled && SearchSectionConfiguration().isDownloadIconEnabled
    }
    
    var isPlayButtonEnabled: Bool {
        let playButtonEnabled = isLoggedIn && !isHTMLGamesEnabled
        guard isFromSearch else {
            return playButtonEnabled
        }
        return playButtonEnabled && SearchSectionConfiguration().isPlayButtonEnabled
    }
    
    var isStickerEnabled: Bool {
        guard isFromSearch else {
            return true
        }
        return SearchSectionConfiguration().isStickerEnabled
    }
    
    var isJackpotAmountEnabled: Bool {
        guard isFromSearch else {
            return true
        }
        return SearchSectionConfiguration().isJackpotAmountEnabled
    }
}

extension GameTileViewModel {
    private func subscribeTo(publisher: GameTilePublisher?) {
        subscriber = publisher?
            .receive(on: DispatchQueue.main)
            .sink { [weak self] values in
                if let favoriteInfo = values?.favorite {
                    // if FavInfo is available it's only Fav update
                    self?.updateFavorite(with: favoriteInfo)
                } else {
                    self?.updateJackpot(with: values?.jackpot)
                }
            }
    }
    
    private func updateJackpot(with jackpotInfo: [String: String]?) {
        guard let jackpotsValues = jackpotInfo else {
            guard let amount = self.jackpotAmount?.jackpotCounterAmount else { return }
            self.jackpotAmount = amount
            return
        }
        let gameVariantName = self.game
        if !gameVariantName.isEmpty,
           let jpPrice = jackpotsValues[gameVariantName] {
            self.jackpotAmount = jpPrice
        }
    }
    
    private func updateFavorite(with favoriteInfo: [String: Bool]) {
        let gameVariantName = self.game
        if !gameVariantName.isEmpty,
           let favState = favoriteInfo[gameVariantName] {
            self.isFavorited = favState
        }
    }
}
