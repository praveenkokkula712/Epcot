//
//  HorizontalDoubleStackRectangleGameTileView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 09/08/23.
//

import SwiftUI
import UIKit
import CasinoAPI

struct HorizontalDoubleStackRectangleGameTileView<GameConfig>: View
where GameConfig: GameTileConfigurable {
    
    // MARK: Properties
    let games: [GameConfig]
    private let rows = Array(
        repeating: GridItem(.fixed(80), spacing: 8),
        count: 2
    )

    // MARK: Body
    var body: some View {
        ScrollView (.horizontal, showsIndicators: false) {
            LazyHGrid (rows: rows) {
                ForEach(games, id: \.game.uuid) { game in
                    GameRectangleTileView(game: game)
                }
            }
            .padding(.trailing, 16)
        }
    }
}

// MARK: - Previews
struct HorizontalDoubleStackRectangleGameTileView_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            HorizontalDoubleStackRectangleGameTileView(
                games: [
                    GameTile(
                        game: SearchSection.gamesRecommended[0],
                        onTap: { _ in },
                        onFavoriteTap: { _ in }
                    )
                ]
            )
        }
        .background(Color.black.opacity(0.8))
    }
}
