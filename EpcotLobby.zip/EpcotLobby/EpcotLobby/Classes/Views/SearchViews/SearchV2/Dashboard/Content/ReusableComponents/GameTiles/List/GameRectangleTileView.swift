//
//  GameRectangleTileView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 09/08/23.
//

import SwiftUI
import Utility

struct GameRectangleTileView<GameConfig>: View
where GameConfig: GameTileConfigurable {
    
    // MARK: Properties
    let game: GameConfig
    @ObservedObject private var viewModel: GameTileViewModel
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()

    init(game: GameConfig) {
        self.game = game
        self.viewModel = GameTileViewModel(self.game)
    }

    // MARK: Body
    var body: some View {
        ZStack(alignment: .top) {
            HStack() {
                GameTileImageView(
                    path: game.imagePath,
                    width: imageTileWidth,
                    height: imageTileWidth,
                    cornerRadius: styles.gameTileCornerRadius
                )
                .shadow(
                    color: styles.shadowColor,
                    radius: styles.gameTileCornerRadius,
                    x: 5, y: 10
                )
                
                Spacer()
                    .frame(width: 8)
                
                VStack(alignment: .leading, spacing: 2.0) {
                    Text(game.name)
                        .foregroundColor(styles.listTitleColor)
                        .font(styles.listTitleFont)
                        .accessibilityIdentifier(textdentifier)
                    
                    if viewModel.isJackpotAmountEnabled, let jackpotAmount = self.viewModel.jackpotAmount {
                        Text(jackpotAmount)
                            .foregroundColor(styles.jpPriceColor)
                            .font(styles.jpPriceFont)
                            .accessibilityIdentifier(jacpotAmountIdentifier)
                    }
                }
                
                Spacer(minLength: 4)
                
                //Download icon
                if viewModel.isDownloadIconEnabled {
                    VStack () {
                        Spacer()
                        GameTileDownloadIconView(
                            isGameDownloaded: game.immersiveInfo?.gameInfo.localGameDownLoadState ?? false
                        ) {
                            game.onTap(game)
                        }
                    }
                }
            }
            .padding(.all, 8)
            .padding(.top, 2)
            .background(backgroundView)
            .onTapGesture {
                game.onTap(game)
            }
            
            HStack {
                if viewModel.isStickerEnabled {
                    if let sticker = game.sticker, !sticker.isEmpty {
                        StickerView(stickerLabel: sticker)
                            .padding(.top, 4)
                            .padding(.leading, 6)
                    }
                }
                
                Spacer()
                
                //Favorite Icon
                if viewModel.isFavouriteEnabled {
                    GameTileFavoriteIconView(
                        selected: viewModel.isFavorited
                    ) {
                        viewModel.isFavorited = !viewModel.isFavorited
                        game.onFavoriteTap(game)
                    }
                    .padding([.top, .trailing], 8)
                }
            }
        }
        .frame(width: tileWidth, height: tileHeight)
    }
}

extension GameRectangleTileView {
    private var styles: SearchSectionsCSS {
        viewModel.styles
    }
}

// MARK: Helper
extension GameRectangleTileView {
    private var backgroundView: some View {
        guard
            let blurImagePath = game.blurImagePath,
            !blurImagePath.isEmpty else {
            return AnyView(
                Color.gray.opacity(0.6)
                    .cornerRadius(styles.gameTileCornerRadius)
                    .clipped()
            )
        }

        return AnyView(
            GameTileImageView(
                path: blurImagePath,
                width: tileWidth,
                height: tileHeight,
                cornerRadius: styles.gameTileCornerRadius
            )
            .opacity(0.2)
        )
    }
}

// MARK: Design Constants
extension GameRectangleTileView {
    private var imageTileWidth: CGFloat { 64 }
    private var tileWidth: Double {
        let multiplier = 0.64
        return UIApplication.screenSize.width * multiplier
    }
    private var tileHeight: CGFloat { 80 }
}

// MARK: - Accessibility Identifiers
extension GameRectangleTileView {
    
    private var textdentifier : String {
        accessibilityIdentifiers.rectangle_gameTileViewTitle
    }
    private var jacpotAmountIdentifier : String {
        accessibilityIdentifiers.rectangle_gameTileJackpotAmount
    }
}

// MARK: - Previews
struct GameRectangleTileView_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            GameRectangleTileView(
                game: GameTile(
                    game: SearchSection.gamesRecommended[0],
                    onTap: { _ in },
                    onFavoriteTap: { _ in })
            )
            GameRectangleTileView(
                game: GameTile(
                    game: SearchSection.gamesRecommended[1],
                    onTap: { _ in },
                    onFavoriteTap: { _ in })
            )
        }
        .background(Color.black.opacity(0.8))
    }
}
