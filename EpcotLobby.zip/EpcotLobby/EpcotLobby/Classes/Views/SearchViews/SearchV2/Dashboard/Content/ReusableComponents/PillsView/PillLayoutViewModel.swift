//
//  PillLayoutViewModel.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 21/08/23.
//

import Foundation

struct PillLayoutViewModel<PillConfig: PillViewConfigurable> {

    // MARK: Properties
    let layout: SearchSection.Layout
    let pills: [PillConfig]

    // MARK: Init
    init(layout: SearchSection.Layout, pills: [PillConfig]) {
        self.layout = layout
        self.pills = pills
    }
}
