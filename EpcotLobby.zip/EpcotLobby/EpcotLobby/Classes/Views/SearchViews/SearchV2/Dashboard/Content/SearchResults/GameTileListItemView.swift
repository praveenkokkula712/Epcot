//
//  GameTileListItemView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 13/09/23.
//

import SwiftUI
import Utility

struct GameTileListItemView<GameConfig>: View
where GameConfig: GameTileConfigurable {
    
    // MARK: Properties
    private let game: GameConfig
    private let searchText: String
    @ObservedObject private var viewModel: GameTileViewModel
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
    
    init(game: GameConfig, searchText: String = "") {
        self.game = game
        self.searchText = searchText
        self.viewModel = GameTileViewModel(self.game)
    }
    
    // MARK: Body
    var body: some View {
        ZStack(alignment: .top) {
            HStack {
                GameTileImageView(
                    path: game.imagePath,
                    width: gameTileImageSize,
                    height: gameTileImageSize,
                    cornerRadius: styles.gameTileCornerRadius
                )
                .padding(.trailing, 11)
                
                VStack(alignment: .leading, spacing: 2.0) {
                    HighlightedText(
                        game.name,
                        matching: searchText,
                        caseInsensitive: true,
                        color: searchText.isEmpty ? highLightedTextColor : listItemStyles.listItemTitleColor,
                        highlightTextColor: highLightedTextColor
                    )
                    .font(listItemStyles.listItemTitleFont)
                    .accessibilityIdentifier(searchText.isEmpty ? hilightedTextIdentifier : normalTextIdentifier)
                    
                    if viewModel.isJackpotAmountEnabled, let jackpotAmount = self.viewModel.jackpotAmount {
                        Text(jackpotAmount)
                            .foregroundColor(styles.jpPriceColor)
                            .font(styles.jpPriceFont)
                            .accessibilityIdentifier(jackpotIdentifier)
                    }
                }
                
                Spacer()
                
                if viewModel.isPlayButtonEnabled, let isGameDownloaded = game.immersiveInfo?.gameInfo.localGameDownLoadState, isGameDownloaded {
                    ListItemPlayButton()
                        .padding(.trailing, 2)
                } else {
                    Image(uiImage: arrow)
                        .frame(width: arrowIconSize, height: arrowIconSize)
                        .colorMultiply(listItemStyles.listItemArrowIconColor)
                        .accessibilityIdentifier(arrowIdentifier)
                }
            }
            .padding([.top, .trailing], 4)
            .contentShape(Rectangle())
            .onTapGesture {
                game.onTap(game)
            }
            
            HStack {
                
                //Sticker
                if viewModel.isStickerEnabled {
                    if let sticker = game.sticker, !sticker.isEmpty {
                        StickerView(stickerLabel: sticker)
                    }
                }
                
                Spacer()
                
                //Favorite Icon
                if viewModel.isFavouriteEnabled {
                    GameTileFavoriteIconView(
                        selected: viewModel.isFavorited
                    ) {
                        viewModel.isFavorited = !viewModel.isFavorited
                        game.onFavoriteTap(game)
                    }
                    .padding(.trailing, 2)
                }
            }
        }
        Divider()
            .frame(height: styles.height)
            .background(Color(listItemStyles.dividerColor))
    }
}

// MARK: Helper
extension GameTileListItemView: EpcotCheckable, LobbyStylable { }

extension GameTileListItemView {
    private var styles: SearchSectionsCSS {
        viewModel.styles
    }
    
    private var listItemStyles: SearchResultsCSS {
        viewModel.resultsStyles
    }
    
    private var arrow: UIImage {
        let name = Self.isEpcot ? "blue-arrow" : "gray-arrow"
        return .init(named: name, in: kEpcotBundle, with: nil) ?? UIImage()
    }
}

// MARK: Design Constants
extension GameTileListItemView {
    
    var gameTileImageSize: CGFloat { viewModel.isFavouriteEnabled ? 85 : 60 }
    private var arrowIconSize: CGFloat { listItemStyles.listItemArrowIconSize }
    private var highLightedTextColor: Color {
        return Color(listItemStyles.highlightedSearchTextColor)
    }
}

// MARK: - Accessibility Identifiers
extension GameTileListItemView {
    private var hilightedTextIdentifier : String {
        accessibilityIdentifiers.highlightedText
    }
    private var normalTextIdentifier : String {
        accessibilityIdentifiers.normalText
    }
    private var jackpotIdentifier : String {
        accessibilityIdentifiers.jackpot
    }
    private var arrowIdentifier : String {
        accessibilityIdentifiers.rightArrow
    }
}

struct GameTileListItemView_Previews: PreviewProvider {
    static var previews: some View {
        GameTileListItemView(
            game: GameTile(
                game: SearchSection.gamesRecommended[0],
                onTap: { _ in },
                onFavoriteTap: { _ in })
        )
    }
}
