//
//  HorizontalGridGameTileview.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 09/08/23.
//

import SwiftUI
import CasinoAPI
import SDWebImageSwiftUI
import SDWebImageSVGKitPlugin


// MARK: Helper
enum ContainerStack: Int {
    case single = 1
    case double

    var rows: [GridItem] {
        .init(repeating: GridItem(.fixed(GameTileImageSize)), count: self.rawValue)
    }
}

struct HorizontalGameTileContainerView<GameTileConfig>: View
where GameTileConfig: GameTileConfigurable {

    // MARK: Properties
    private let stack: ContainerStack
    private let games: [GameTileConfig]

    // MARK: Init
    init(stack: ContainerStack = .single, games: [GameTileConfig]) {
        self.stack = stack
        self.games = games
        SDImageCodersManager.shared.addCoder(SDImageSVGKCoder.shared)
    }

    // MARK: Body
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHGrid(rows: stack.rows) {
                ForEach(games, id: \.game.uuid) { game in
                    GameTileView(game: game)
                }
            }
            .padding(.trailing, 16)
        }
    }
}

// MARK: - Previews
struct HorizontalGameTileContainerView_Previews: PreviewProvider {
    static var previews: some View {
        HorizontalGameTileContainerView(
            games: [
                GameTile(
                    game: SearchSection.gamesRecommended[0],
                    onTap: { _ in },
                    onFavoriteTap: { _ in }
                )
            ]
        )
        .background(Color.black.opacity(0.8))
    }
}
