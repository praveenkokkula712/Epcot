//
//  SearchBarView.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 08/08/23.
//

import SwiftUI
import Utility

struct SearchBarView: View {

    // MARK: Properties
    @ObservedObject var viewModel: SearchBarViewModel
    private let styles = SearchBarCSS()
    private let screenStyle = SearchDashboardCSS()
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
    @Binding var micButtonFrame: FrameReference
    @State var keyboardFocused: Bool = true

    // MARK: Body
    var body: some View {
        HStack(spacing: -4) {
            HStack(spacing: 12) {
                Image(uiImage: searchIcon)
                    .frame(width: iconSize)
                    .padding(.leading, Self.isEpcot ? 12 : 16)
                    .accessibilityIdentifier(searchIconIdentifier)
                TextField("", text: $viewModel.searchText, onCommit: {
                    viewModel.savePreference()
                })
                .focused($keyboardFocused)
                .disableAutocorrection(true)
                .font(styles.titleFont)
                .foregroundColor(styles.titleColor)
                .accentColor(styles.titleColor)
                .accessibilityIdentifier(textFieldIdentifier)
                .placeHolder(
                    Text(Self.isEpcot ? "epcot_placeholder".localized : "placeholder".localized)
                        .font(styles.titleFont)
                        .foregroundColor(styles.placeholderColor)
                        .accessibilityIdentifier(textIdentifier),
                    show: viewModel.searchText.isEmpty
                )
                .showClearButton($viewModel.searchText, image: cross, isClearButtonEnabled: isClearButtonEnabled)
                
                if isVoiceSearchEnabled && !isClearButtonEnabled {
                    Button(action: {
                        viewModel.voiceCommandAction()
                    }) {
                        Image(uiImage: mic)
                            .padding(.trailing, Self.isEpcot ? 12 : 16)
                            .colorMultiply(viewModel.speechStatus ? micActiveColor : micInactiveColor)
                    }
                    .frame(width: voiceIconSize, height: voiceIconSize)
                    .accessibilityIdentifier(viewModel.speechStatus ? activeMicIconIdentifier: inActiveMicIconIdentifier )
                    .savePrimaryViewFrame(in: $micButtonFrame)
                }
            }
            .frame(height: barHeight)
            .background(backgroundColor)
            .cornerRadius(barHeight / 2)
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .shadow(color: styles.shadowColor, radius: styles.shadowRadius)

            if Self.isEpcot {
                VStack {
                    Button(action: viewModel.cancelAction) {
                        Text("cancel".localized)
                            .font(styles.cancelFont)
                            .foregroundColor(styles.cancelColor)
                            .accessibilityIdentifier(cancelTextIdentifier)
                    }
                    .padding(.horizontal, 6)
                    .frame(height: barHeight)
                    .accessibilityIdentifier(cancelButtonIdentifier)
                }
                .padding(.trailing, 16)
            }
        }
        .onAppear {
            showOnBoardingViewIfNeeded()
        }
        .onChange(of: keyboardFocused) { focused in
            if !focused {
                viewModel.savePreference()
            }
        }
        .background(screenColor)
    }
}

// MARK: Previews
struct SearchBarView_Previews: PreviewProvider {
    static var previews: some View {
        SearchBarView(viewModel: SearchBarViewModel(), micButtonFrame: Binding.constant(FrameReference()))
    }
}

extension SearchBarView {
    func showOnBoardingViewIfNeeded() {
        let result = UserOnboardingViewModel.shared?.show(with: micButtonFrame.frameRef,
                                                          of: .voiceSearchEnhanced, action: {
            self.viewModel.isOnboardingJourneyCompleted = true
            self.keyboardFocused = true
        }) ?? false
        self.viewModel.isOnboardingJourneyCompleted = !result
        self.keyboardFocused = !result
    }
}

// MARK: - Design Constants
extension SearchBarView {
    private static var isEpcot: Bool { SearchBarViewModel.isEpcot }
    private var barHeight: CGFloat { styles.height }
    private var iconSize: CGFloat { styles.iconSize }
    private var voiceIconSize: CGFloat { styles.audioButtonSize }
    private var backgroundColor: Color { styles.backgroundColor }
    private var screenColor: Color { screenStyle.backgroundColor }
    private var searchIcon: UIImage {
        let name = Self.isEpcot ? "searchIcon" : "magnifyingglass"
        return .init(named: name, in: kEpcotBundle, with: nil) ?? UIImage()
    }
    private var mic: UIImage {
        .init(named: "microphone.2", in: kEpcotBundle, with: nil) ?? UIImage()
    }
    private var cross: UIImage {
        let name = Self.isEpcot ? "blue-cross" : "gray-cross"
        return .init(named: name, in: kEpcotBundle, with: nil) ?? UIImage()
    }
    var micActiveColor: Color { styles.micActiveColor }
    var micInactiveColor: Color { styles.micInactiveColor }
}

// MARK: - Helper
extension SearchBarView {
    fileprivate var isVoiceSearchEnabled: Bool {
        return EpcotLobbyManager.shared?.datasource?.enableVoiceSearch() ?? false
    }
    
    private var isClearButtonEnabled: Bool { viewModel.isClearButtonEnabled }
}

// MARK: - Accessibility Identifiers
extension SearchBarView {
    private var searchIconIdentifier : String {
        accessibilityIdentifiers.searchButton
    }
    private var textFieldIdentifier : String {
        accessibilityIdentifiers.textField
    }
    private var textIdentifier : String {
        accessibilityIdentifiers.placeHolderText
    }
    private var activeMicIconIdentifier : String {
        accessibilityIdentifiers.activeMicButton
    }
    private var inActiveMicIconIdentifier : String {
        accessibilityIdentifiers.inActiveMicButton
    }
    private var cancelTextIdentifier : String {
        accessibilityIdentifiers.epcotCancelText
    }
    private var cancelButtonIdentifier : String {
        accessibilityIdentifiers.epcotCancelButton
    }
}
    
private struct SearchBarTextFieldStyle: ViewModifier {
    
    // MARK: Properties
    var styles = SearchBarCSS()
    var isEpcot: Bool
    var crossImage: UIImage
    var isClearButtonEnabled: Bool
    @Binding var searchText: String
    
    
    func body(content: Content) -> some View {
        content
            .disableAutocorrection(true)
            .font(styles.titleFont)
            .foregroundColor(styles.titleColor)
            .accentColor(styles.titleColor)
            .placeHolder(
                Text(isEpcot ? "epcot_placeholder".localized : "placeholder".localized)
                    .font(styles.titleFont)
                    .foregroundColor(styles.placeholderColor),
                show: searchText.isEmpty
            )
            .showClearButton($searchText, image: crossImage, isClearButtonEnabled: isClearButtonEnabled)
    }
}

extension View {
    func textFieldStyle(isEpcot: Bool, crossImage: UIImage, searchText: Binding<String>, isClearButtonEnabled: Bool) -> some View {
        modifier(SearchBarTextFieldStyle(
            isEpcot: isEpcot,
            crossImage: crossImage,
            isClearButtonEnabled: isClearButtonEnabled,
            searchText: searchText
        ))
    }
}
