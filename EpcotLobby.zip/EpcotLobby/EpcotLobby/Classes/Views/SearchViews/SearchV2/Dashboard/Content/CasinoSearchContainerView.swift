//
//  CasinoSearchContainerView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 08/08/23.
//

import SwiftUI
import Utility

struct CasinoSearchContainerView: View {
    @ObservedObject var viewModel: CasinoSearchContainerViewModel
    private let styles = SearchSectionsCSS()
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                ForEach(viewModel.layouts, id: \.self) { section in
                    VStack {
                        //Content
                        switch section.sectionType {
                        case .recentSearch:
                            if viewModel.hideRecentSearch {
                                EmptyView()
                            } else {
                                if let recentSearchViewModel = sectionViewModels[section.sectionType] as? RecentSearchViewModel {
                                    RecentSearchView(
                                        viewModel: recentSearchViewModel
                                    )
                                }
                            }
                        case .lmtRecommendedGames, .mostSearchedGames, .lmtNewGames, .siteCoreGames:
                            if let gamesViewModel = sectionViewModels[section.sectionType] as? SearchSectionGamesViewModel {
                                SearchSectionGamesView(
                                    viewModel: gamesViewModel
                                )
                            }
                        case .lmtGameProvider:
                            if let vendorsViewModel = sectionViewModels[section.sectionType] as? VendorsViewModel {
                                VendorsView(
                                    viewModel: vendorsViewModel
                                )
                            }
                        case .lmtCategoryNames:
                            if let categoriesViewModel = sectionViewModels[section.sectionType] as? SearchCategoriesViewModel {
                                SearchCategoriesPillsView(
                                    viewModel: categoriesViewModel
                                )
                            }
                        case .none:
                            EmptyView()
                        }
                    }
                    .padding(.leading, 16)
                    .background(section.sectionType == .recentSearch ? Color(styles.recentSearchBackgroundColor) : Color.clear)
                }
            }
            .padding(.bottom, 16)
            .accessibilityIdentifier(containerIdentifier)
        }
        .background(Color(styles.backgroundColor))
        .resignKeyboardOnDragGesture()
    }
}

//MARK: - Helper
extension CasinoSearchContainerView {
    private var feed: SearchDashboardFeed {
        viewModel.feed ?? SearchDashboardFeed()
    }
    
    private var sectionViewModels: [SearchSection.SectionType: Any] {
        viewModel.sectionViewModels
    }
}

// MARK: - Accessibility Identifier
extension CasinoSearchContainerView {
    
    private var containerIdentifier : String {
        accessibilityIdentifiers.containerView
    }
}

struct CasinoSearchSuggestionsView_Previews: PreviewProvider {
    static var previews: some View {
        CasinoSearchContainerView(
            viewModel: CasinoSearchContainerViewModel(
                layouts: SearchSection.sections,
                feed: SearchDashboardFeed()
            )
        )
    }
}
