//
//  CasinoSearchContainerViewModel.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 16/08/23.
//

import Foundation
import Combine
import CasinoAPI

class CasinoSearchContainerViewModel: ObservableObject {
    
    // MARK: Properties
    let layouts: [SearchSection]
    var onSelectCategory: ((String) -> Void)?
    var onVendorTap: ((VendorGames) -> Void)?
    var onGameTap: ((Game, SearchSection) -> Void)?
    var feed: SearchDashboardFeed?
    @Published var searchPreferences: RecentSearchPreferences?
    @Published var hideRecentSearch = false
    private var cancellables = Set<AnyCancellable>()
    
    @Published private(set) var sectionViewModels: [SearchSection.SectionType : Any] = [:]
    
    // MARK: Init
    init(layouts: [SearchSection] = [],
         feed: SearchDashboardFeed = SearchDashboardFeed(),
         searchPreferences: RecentSearchPreferences = RecentSearchPreferences(),
         onSelectCategory: ((String) -> Void)? = nil,
         onVendorTap: ((VendorGames) -> Void)? = nil,
         onGameTap: ((Game, SearchSection) -> Void)? = nil) {
        let sections = SearchSectionConfiguration().sections
        self.layouts = layouts.isEmpty ? sections : layouts
        self.feed = feed
        self.onSelectCategory = onSelectCategory
        self.onVendorTap = onVendorTap
        self.onGameTap = onGameTap
        self.searchPreferences = searchPreferences
        self.subscribeToPreferences()
        self.subscribeToRefreshContainer()
        self.createSectionsViewmodels()
    }
    
    //MARK: Create View models
    private func createSectionsViewmodels() {
        var viewModels: [SearchSection.SectionType : Any] = [:]
        
        self.layouts.forEach { section in
            switch section.sectionType {
            case .recentSearch:
                let viewModel = RecentSearchViewModel(
                    section: section,
                    preferences: searchPreferences ?? RecentSearchPreferences()
                )
                viewModels[section.sectionType] = viewModel
                
            case .lmtRecommendedGames, .mostSearchedGames, .lmtNewGames, .siteCoreGames:
                
                let games = feed?.getGames(for: section.sectionType) ?? []
                if !games.isEmpty {
                    let viewModel = SearchSectionGamesViewModel(
                        section: section,
                        games: games,
                        blurImagePath: section.layoutType == .doublePattyTilesWithBackground ? feed?.blurImagePath : nil,
                        sticker: feed?.sticker,
                        immersiveInfo: feed?.immersiveInfo,
                        publisher: feed?.gameTilePublisher,
                        onGameTap: { [weak self] game in
                            self?.onGameTap?(game, section)
                        },
                        onFavoriteTap: feed?.onFavoriteGameTap
                    )
                    viewModels[section.sectionType] = viewModel
                }
            case .lmtGameProvider:
                
                if let vendorGames = feed?.vendorGames, !vendorGames.isEmpty {
                    let viewModel = VendorsViewModel(
                        section: section,
                        vendorsGames: vendorGames,
                        onVendorTap: onVendorTap
                    )
                    viewModels[section.sectionType] = viewModel
                }
                
            case .lmtCategoryNames:
                
                let viewModel = SearchCategoriesViewModel(
                    searchSection: section,
                    categories: feed?.categories ?? [],
                    onSelectCategory: onSelectCategory
                )
                viewModels[section.sectionType] = viewModel
                
            case .none: break
            }
        }
        
        self.sectionViewModels = viewModels
    }
    
    // MARK: Subscriptions
    private func subscribeToPreferences() {
        self.searchPreferences?.$searchWords
            .sink { [weak self] words in
                guard let self else { return }
                self.hideRecentSearch = words.isEmpty
            }
            .store(in: &cancellables)
    }
    
    private func subscribeToRefreshContainer() {
        self.feed?.$refreshContainer
            .receive(on: DispatchQueue.main)
            .sink { [weak self] refresh in
                guard let self else { return }
                self.createSectionsViewmodels()
                if refresh {
                    self.objectWillChange.send()
                }
            }
            .store(in: &cancellables)
    }
}

extension CasinoSearchContainerViewModel: CleanProtocol {
    func clean() {
        self.cancellables.forEach { subscriber in
            subscriber.cancel()
        }
        self.sectionViewModels.forEach { sectionViewModel in
            switch sectionViewModel.key {
            case .recentSearch:
                (sectionViewModel.value as? RecentSearchViewModel)?.clean()
            case .lmtRecommendedGames, .mostSearchedGames, .lmtNewGames, .siteCoreGames:
                (sectionViewModel.value as? SearchSectionGamesViewModel)?.clean()
            case .lmtGameProvider:
                (sectionViewModel.value as? VendorsViewModel)?.clean()
            case .lmtCategoryNames:
                (sectionViewModel.value as? SearchCategoriesViewModel)?.clean()
            case .none: break
            }
        }
        self.sectionViewModels.removeAll()

        self.searchPreferences = nil
    }
}
