//
//  PillViewConfigurable.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 21/08/23.
//

import Foundation

protocol PillViewConfigurable: Identifiable, Hashable, Equatable {
    var id: UUID { get }
    var title: String { get set }
    var isRemoveEnabled: Bool { get set }
    var onTap: (Self) -> Void { get }
    var onRemove: (Self) -> Void { get }
}

extension PillViewConfigurable {
    static func ==(lhs: Self, rhs: Self) -> Bool {
        lhs.id == rhs.id ||
        lhs.title == rhs.title ||
        lhs.isRemoveEnabled == rhs.isRemoveEnabled
    }
}

extension PillViewConfigurable {
    var id: UUID { return UUID() }
}

extension PillViewConfigurable {
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(title)
        hasher.combine(isRemoveEnabled)
    }
}
