//
//  GameCategoryTabViewModel.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 21/09/23.
//

import Foundation

class GameCategoryTabViewModel: ObservableObject {
    @Published var currentId: UUID = UUID()
    @Published var categoryTabs = [GameCategoryTab]()

    let onSelectGameCategoryTab: (GameCategoryTab) -> Bool

    init(
        categories: [String],
        selectedCategory: String,
        onSelectGameCategoryTab: @escaping (GameCategoryTab) -> Bool
    ) {
        self.categoryTabs = categories.map { GameCategoryTab(title: $0) }
        self.onSelectGameCategoryTab = onSelectGameCategoryTab
        self.updateSelectedGameCategoryTab(with: selectedCategory)
    }
    
    var tabs: [(Range<Array<GameCategoryTab>.Index>.Element, GameCategoryTab)] {
        Array(zip(categoryTabs.indices, categoryTabs))
    }

    private func updateSelectedGameCategoryTab(with category: String) {
        if let id = categoryTabs.first(where: { $0.title == category }) {
            currentId = id.uuid
        }
    }
}
