//
//  SearchResultsCSS.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 21/09/23.
//

import Foundation

import SwiftUI
import Utility

public struct SearchResultsCSS {
    
    // MARK: Properties
    let headerColor: Color
    let headerFont: Font
    let searchResultsBackgroundColor: UIColor
    
    let listItemTitleColor: Color
    let listItemTitleFont: Font
    let listItemArrowIconSize: CGFloat
    let listItemArrowIconColor: Color
    let listItemImageCornerRadius: CGFloat
    
    let noResultsFoundBackgroundColor: UIColor
    let noResultsTitleColor: Color
    let noResultsTitleFont: Font
    let noResultsSubTitleColor: Color
    let noResultsSubTitleFont: Font
    let noSearchResultsIconSize: CGFloat
    
    let categoryTabViewBackGroundColor: UIColor
    let selectedTabTextColor: Color
    let unselectedTabTextColor: Color
    let selectedTabTextFont: Font
    let unSelectedTabTextFont: Font
    let dividerColor: UIColor
    let hairLineHeight: CGFloat
    let hairLineColor: UIColor
    let highlightedSearchTextColor: UIColor
    
    
    // MARK: Init
    init(searchResultsCSS: SearchResultsV2CSS? = nil) {
        let css = searchResultsCSS ?? Self.lobbyCSS?.searchV2CSS?.searchResultsV2CSS
        headerColor = Color(css?.header?.color ?? Self.defaultTitleColor)
        headerFont = Font(css?.header?.font ?? Self.defaultHeaderFont)
        searchResultsBackgroundColor = css?.searchResultsBackgroundColor ?? Self.defaultSearchResultsBgColor
        listItemTitleColor = Color(css?.listItemTitle?.color ?? Self.defaultListItemTitleColor)
        listItemTitleFont = Font(css?.listItemTitle?.font ?? Self.defaultTitleFont)
        listItemArrowIconSize = css?.listItemArrowIcon ?? Self.defaultIconSize
        listItemArrowIconColor = Color(css?.listItemArrowIconColor ?? Self.defaultListItemArrowIconColor)
        listItemImageCornerRadius = css?.listItemImageCornerRadius ?? Self.defaultCornerRadius
        
        noResultsFoundBackgroundColor = css?.noResultsFoundBackgroundColor ?? Self.defaultSubTitleColor
        noResultsTitleColor = Color(css?.title?.color ?? Self.defaultTitleColor)
        noResultsTitleFont = Font(css?.title?.font ?? Self.defaultNoResultsTitleFont)
        noResultsSubTitleColor = Color(css?.subtitle?.color ?? Self.defaultSubTitleColor)
        noResultsSubTitleFont = Font(css?.subtitle?.font ?? Self.defaultSubTitleFont)
        noSearchResultsIconSize = css?.iconSize ?? Self.defaultNoResultsIconSize
        
        categoryTabViewBackGroundColor = css?.categoryTabViewBgColor ?? Self.defaultSearchResultsBgColor
        selectedTabTextColor = Color(css?.selectedTabTextColor ?? Self.defaultTitleColor)
        unselectedTabTextColor = Color(css?.unselectedTabTexColor ?? Self.defaultSubTitleColor)
        selectedTabTextFont = Font(css?.selectedTabTextFont ?? Self.defaultNoResultsTitleFont)
        unSelectedTabTextFont = Font(css?.unSelectedTabTextFont ?? Self.defaultSubTitleFont)
        dividerColor = css?.dividerColor ?? Self.defaultDividerColor
        hairLineColor = css?.hairLineColor ?? Self.defaultTitleColor
        hairLineHeight = css?.hairLineHeight ?? Self.defaultHairLineHeight
        highlightedSearchTextColor = css?.highlightedSearchTextColor ?? Self.defaultHighlightedTextColor
    }
}

// MARK: - Helper
extension SearchResultsCSS: LobbyStylable, EpcotCheckable { }

extension SearchResultsCSS {
    private static var defaultTitleColor: UIColor { .white }
    private static var defaultTitleFont: UIFont {
        .systemFont(ofSize: 14, weight: .bold)
    }
    private static var defaultHeaderFont: UIFont {
        .systemFont(ofSize: 16, weight: .bold)
    }
    private static var defaultListItemTitleColor: UIColor {
        UIColor.hexStringToUIColor(hex: "#8B8E95")
    }
    private static var defaultNoResultsTitleFont: UIFont {
        .systemFont(ofSize: 17, weight: .bold)
    }
    private static var defaultSubTitleColor: UIColor {
        UIColor.hexStringToUIColor(hex: "#C3C4C7")
    }
    private static var defaultSubTitleFont: UIFont {
        .systemFont(ofSize: 13, weight: .bold)
    }
    private static var defaultIconSize: CGFloat { 16 }
    private static var defaultCornerRadius: CGFloat { 4 }
    private static var defaultNoResultsIconSize: CGFloat { 55 }
    private static var defaultHairLineHeight: CGFloat { 4 }
    private static var defaultHighlightedTextColor: UIColor {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }
    private static var defaultDividerColor: UIColor {
        Self.isEpcot ? UIColor.hexStringToUIColor(hex: "#63656A") :
        UIColor.hexStringToUIColor(hex: "#858585")
    }
    private static var defaultSearchResultsBgColor: UIColor {
        Self.isEpcot ? UIColor.hexStringToUIColor(hex: "#191919") :
        UIColor.hexStringToUIColor(hex: "#050505")
    }
    private static var defaultListItemArrowIconColor: UIColor {
        Self.isEpcot ? UIColor.hexStringToUIColor(hex: "#D6D6D6") :
        UIColor.hexStringToUIColor(hex: "#79BFFF")
                                   
    }   
}


