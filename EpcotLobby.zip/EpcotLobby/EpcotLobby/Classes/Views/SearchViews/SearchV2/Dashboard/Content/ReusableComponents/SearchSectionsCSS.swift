//
//  SearchSectionsCSS.swift
//  ConfigModule
//
//  Created by Sindhuja Vedire on 24/08/23.
//

import SwiftUI
import Utility

struct SearchSectionsCSS {
    
    // MARK: Properties
    let backgroundColor: UIColor
    let recentSearchBackgroundColor: UIColor
    let pillsBackgroundColor: Color
    let headerTitleColor: Color
    let headerTitleFont: Font
    let clearAllTitleColor: Color
    let clearAllTitleFont: Font
    let clearAllIconSize: CGFloat
    let titleColor: Color
    let titleFont: Font
    let listTitleColor: Color
    let listTitleFont: Font
    let pillsCornerRadius: CGFloat
    let gameTileCornerRadius: CGFloat
    let shadowColor: Color
    let height: CGFloat
    let dividerColor: UIColor
    let closeIconSize: CGFloat
    let searchHistoryIconSize: CGFloat
    let arrowIconSize: CGFloat
    
    let listJpPriceFont: Font
    let jpPriceFont: Font
    let jpPriceColor: Color
    let jpPriceBGColor: Color
    
    let favouriteIconSelected: String
    let favouriteIconUnselected: String
    let favouriteTintColor: Color
    let favouriteBackgroundColor: Color
    let favouritesIconFontSize: CGFloat
    
    let downloadIconCornerRadius: CGFloat
    let downloadIconTitleColor: Color
    let downloadIconTitleFont: Font
    let downloadIconBGColor: Color
    let downloadIconBorderColor: Color
    let playIconBGColor: Color
    let playIconTitleColor: Color
    
    let stickerTextColor: Color
    let stickerTextFont: Font
    let stickerCornerRadius: CGFloat
    let stickerBackGroundColor: UIColor
    
    // MARK: Init
    init(searchSectionsCSS: SearchSectionsV2CSS? = nil) {
        let css = searchSectionsCSS ?? Self.lobbyCSS?.searchV2CSS?.searchSectionsV2CSS
        let gameTileCss = css?.gameTileCss
        let gameCellCss = Self.lobbyCSS?.gamesCell
        let immersiveCss = EpcotLobbyManager.shared?.css.epcotLobbyCSS?.immersiveCSS
        backgroundColor = css?.backgroundColor ?? Self.defaultBackgroundColor
        recentSearchBackgroundColor = css?.recentSearchBackgroundColor ?? Self.defaultBackgroundColor
        pillsBackgroundColor = Color( css?.pillsBackgroundColor ?? Self.defaultPillsBackgroundColor)
        headerTitleColor = Color(css?.sectionHeaderTitle?.color ?? Self.defaultHeaderColor)
        headerTitleFont = Font(css?.sectionHeaderTitle?.font ?? Self.defaultHeaderFont)
        clearAllTitleColor = Color(css?.clearAllTitle?.color ?? Self.defaultClearAllTitleColor)
        clearAllTitleFont = Font(css?.clearAllTitle?.font ?? Self.defaultClearAllTitleFont)
        clearAllIconSize = css?.clearAllIconSize ?? Self.defaultIconSize
        titleColor = (css?.title?.color ?? Self.defaultTitleColor).swiftUIColor
        titleFont = Font(css?.title?.font ?? Self.defaultTitleFont)
        listTitleColor = Color(css?.listTitle?.color ?? Self.defaultListTitleColor)
        listTitleFont = Font(css?.listTitle?.font ?? Self.defaultListTitleFont)
        pillsCornerRadius = css?.pillsCornerRadius ?? Self.defaultPillsCornerRadius
        gameTileCornerRadius = gameTileCss?.gameTileCornerRadius ?? Self.defaultGameTileCornerRadius
        shadowColor = Color(gameTileCss?.shadowColor ?? Self.defaultShadowColor)
        height = css?.height ?? Self.defaultHeight
        dividerColor = css?.dividerColor ?? Self.defaultDivederColor
        closeIconSize = css?.closeIconSize ?? Self.defaultSearchHistoryIconSize
        searchHistoryIconSize = css?.searchHistoryIconSize ?? Self.defaultSearchHistoryIconSize
        arrowIconSize =  css?.arrowIconSize ?? Self.defaultIconSize
        
        listJpPriceFont = Font(gameTileCss?.jpView?.listPriceAmount ?? .boldSystemFont(ofSize: 6.0))
        jpPriceFont = Font(gameTileCss?.jpView?.priceAmount?.font ?? .boldSystemFont(ofSize: 12.0))
        jpPriceColor = gameTileCss?.jpView?.priceAmount?.color?.swiftUIColor ?? .white
        jpPriceBGColor = (gameTileCss?.jpView?.jpBGColor ??
                          UIColor.hexStringToUIColor(hex: "333333", withAlpha: 0.8)).swiftUIColor
        
        favouriteIconSelected = gameTileCss?.favouriteButtonIconSelected ?? "heart-solid"
        favouriteIconUnselected = gameTileCss?.favouriteButtonIconUnselected ?? "heart-outline"
        favouriteTintColor = gameTileCss?.favouriteButtonTintColor?.swiftUIColor ?? .white
        favouriteBackgroundColor = gameTileCss?.favouriteButtonBackgroundColor?.swiftUIColor ?? UIColor(white: 0, alpha: 0.4).swiftUIColor
        favouritesIconFontSize = gameTileCss?.favouriteIconFontSize ?? 14.0
        
        downloadIconCornerRadius = immersiveCss?.downloadIconCornerRdius ?? 4.0
        downloadIconTitleColor = gameCellCss?.downloadButton?.title?.color?.swiftUIColor ?? .white
        downloadIconTitleFont = Font(gameCellCss?.downloadButton?.title?.font ?? .boldSystemFont(ofSize: 14))
        downloadIconBGColor = immersiveCss?.downloadIconBGColor?.swiftUIColor ?? .clear
        downloadIconBorderColor = gameCellCss?.downloadButtonBorderColor?.swiftUIColor ?? .white
        playIconBGColor = (gameCellCss?.playButton?.normal ??
                           UIColor(displayP3Red: 255/255, green: 204/255, blue: 0, alpha: 1.0)).swiftUIColor
        playIconTitleColor = (gameCellCss?.playButton?.title?.color ??
                              UIColor(displayP3Red: 25/255, green: 25/255, blue: 25/255, alpha: 1.0)).swiftUIColor
        
        stickerBackGroundColor = css?.stickerBackGroundColor ?? Self.defaultStickerBackgroundColor
        stickerTextColor = Color(css?.stickerText?.color ?? Self.defaulStickerTitleColor)
        stickerTextFont = Font(css?.stickerText?.font ?? Self.defaultStickerTitleFont)
        stickerCornerRadius = css?.stickerCornerRadius ?? Self.defaultStickerViewCornerRadius
        
    }
}

// MARK: - Helper
extension SearchSectionsCSS: EpcotCheckable, LobbyStylable { }

extension SearchSectionsCSS {
    private static var defaultBackgroundColor: UIColor {
        Self.isEpcot ? UIColor.hexStringToUIColor(hex: "#050505") :
        UIColor.hexStringToUIColor(hex: "#191919")
    }
    private static var defaultPillsBackgroundColor: UIColor {
        UIColor.hexStringToUIColor(hex: "#333333")
    }
    private static var defaultHeaderColor: UIColor {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }
    private static var defaultHeaderFont: UIFont {
        .systemFont(ofSize: 16, weight: .bold)
    }
    private static var defaultClearAllTitleColor: UIColor {
        Self.isEpcot ? UIColor.hexStringToUIColor(hex: "#79BFFF") :
        UIColor.hexStringToUIColor(hex: "#C1C1C1")
    }
    private static var defaultClearAllTitleFont: UIFont {
        Self.isEpcot ? .systemFont(ofSize: 11, weight: .medium) :
            .systemFont(ofSize: 12, weight: .bold)
    }
    private static var defaultTitleColor: UIColor {
        Self.isEpcot ? UIColor.hexStringToUIColor(hex: "#FFFFFF") :
        UIColor.hexStringToUIColor(hex: "#C1C1C1")
    }
    private static var defaultTitleFont: UIFont {
        Self.isEpcot ? .systemFont(ofSize: 14, weight: .bold) :
            .systemFont(ofSize: 14, weight: .regular)
    }
    private static var defaultListTitleColor: UIColor {
        UIColor.hexStringToUIColor(hex: "#FFFFFF")
    }
    private static var defaultListTitleFont: UIFont {
        .systemFont(ofSize: 14, weight: .bold)
    }
    private static var defaultPillsCornerRadius: CGFloat { 24 }
    private static var defaultGameTileCornerRadius: CGFloat { 8 }
    private static var defaultShadowColor: UIColor {
        .init(red: 0, green: 0, blue: 0, alpha: 0.4)
    }
    private static var defaultHeight: CGFloat { 1 }
    private static var defaultDivederColor: UIColor {
        Self.isEpcot ? UIColor.hexStringToUIColor(hex: "#63656A") :
        UIColor.hexStringToUIColor(hex: "#333333")
    }
    private static var defaultSearchHistoryIconSize: CGFloat { 20 }
    private static var defaultIconSize: CGFloat { 12 }
    
    private static var defaultStickerBackgroundColor: UIColor {
       UIColor.hexStringToUIColor(hex: "#D6BC68")
    }
    private static var defaulStickerTitleColor: UIColor {
        UIColor.hexStringToUIColor(hex: "#050505")
    }
    private static var defaultStickerTitleFont: UIFont {
        .systemFont(ofSize: 12, weight: .regular)
    }
    private static var defaultStickerViewCornerRadius: CGFloat { 4 }
    
}

