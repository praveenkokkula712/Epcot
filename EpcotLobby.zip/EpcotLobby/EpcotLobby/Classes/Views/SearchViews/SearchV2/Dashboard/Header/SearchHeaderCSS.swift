//
//  SearchHeaderCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 10/08/23.
//

import SwiftUI
import Utility

struct SearchHeaderCSS {
    
    // MARK: Properties
    let backgroundColor: Color
    let height: CGFloat
    let titleFont: Font
    let titleColor: Color
    let backIconSize: CGFloat

    // MARK: Init
    init(searchHeaderV2CSS: SearchHeaderV2CSS? = nil) {
        let css = searchHeaderV2CSS ?? Self.lobbyCSS?.searchV2CSS?.searchHeaderV2CSS
        self.backgroundColor = Color(
            css?.backgroundColor ?? Self.defaultBackgroundColor
        )
        height = css?.height ?? Self.defaultHeight
        titleFont = Font(css?.title?.font ?? Self.defaultTitleFont)
        titleColor = Color(css?.title?.color ?? Self.defaultTitleColor)
        backIconSize = css?.backIconSize ?? Self.defaultBackIconSize
    }
}

// MARK: - Helper
extension SearchHeaderCSS: LobbyStylable { }

extension SearchHeaderCSS {
    private static var defaultBackgroundColor: UIColor { .black }
    private static var defaultHeight: CGFloat { 56 }
    private static var defaultTitleFont: UIFont {
        UIFont(name: "Roboto-Bold", size: 16) ??
        .systemFont(ofSize: 16, weight: .bold)
    }
    private static var defaultTitleColor: UIColor { .white }
    private static var defaultBackIconSize: CGFloat { 16 }
}
