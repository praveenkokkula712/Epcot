//
//  ListItem.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 23/08/23.
//

import Foundation

struct ListItem: ListItemConfigurable {
    var title: String
    var isRemoveEnabled: Bool
    var onTap: (ListItem) -> Void
    var onRemove: (ListItem) -> Void
    var showLeadingAccessoryIcon: Bool
    var showTrailingAccessoryIcon: Bool
}
