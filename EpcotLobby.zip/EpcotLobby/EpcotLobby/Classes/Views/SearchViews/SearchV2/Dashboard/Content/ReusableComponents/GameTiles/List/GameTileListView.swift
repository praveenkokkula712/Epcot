//
//  GameTileListView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 29/09/23.
//

import SwiftUI

struct GameTileListView<GameConfig: GameTileConfigurable>: View {
    let games: [GameConfig]
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: [GridItem()])  {
                ForEach(games, id: \.self.game.uuid) { game in
                    GameTileListItemView(
                        game: game
                    )
                }
            }
        }
        .padding(.trailing, 16)
    }
}

struct GameTileListView_Previews: PreviewProvider {
    static var previews: some View {
        GameTileListView(
            games: [
                GameTile(
                    game: SearchSection.gamesRecommended[0],
                    onTap: { _ in },
                    onFavoriteTap: { _ in }
                )
            ]
        )
    }
}
