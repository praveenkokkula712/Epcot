//
//  SearchDashboardView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 08/08/23.
//

import SwiftUI
import Utility

struct SearchDashboardView: View {
    
    // MARK: Properties
    @ObservedObject private var viewModel: SearchDashboardViewModel
    private let styles = SearchDashboardCSS()
    
    // MARK: Init
    init(viewModel: SearchDashboardViewModel) {
        self.viewModel = viewModel
    }
    
    // MARK: Body
    var body: some View {
        ScreenContainer(color: styles.backgroundColor) {
            VStack(spacing: 0) {
                if !viewModel.isEpcot {
                    SearchHeaderView(
                        backAction: viewModel.backAction,
                        enableClose: viewModel.showSearchResults,
                        closeAction: viewModel.closeSearchPage
                    )
                } else {
                    SearchBarView(
                        viewModel: barViewModel, micButtonFrame: Binding.constant(FrameReference())
                    )
                }
                if viewModel.showSearchResults, let resultsModel = viewModel.resultsViewModel {
                    
                    SearchResultsView(
                        viewModel: resultsModel
                    )
                    
                } else {
                    if barViewModel.isTextNotEmpty {
                        NoResultsFoundView(
                            searchBarViewModel: barViewModel
                        )
                    }
                    CasinoSearchContainerView(
                        viewModel: viewModel.containerViewModel ?? CasinoSearchContainerViewModel()
                    )
                }
                
                //bottom Search
                if !viewModel.isEpcot {
                    SearchBarView(
                        viewModel: barViewModel, micButtonFrame: Binding.constant(FrameReference())
                    )
                }
            }
            .resignKeyboardOnDragGesture()
        }
        .allowsHitTesting(barViewModel.isOnboardingJourneyCompleted)
    }
}

//MARK: - Helper
extension SearchDashboardView {
    private var feed: SearchDashboardFeed {
        viewModel.feed ?? SearchDashboardFeed()
    }
    private var barViewModel: SearchBarViewModel {
        viewModel.barViewModel ?? SearchBarViewModel()
    }
}

// MARK: - Previews
struct SearchDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        let viewModel = SearchDashboardViewModel(
            isVoiceCommand: false,
            feed: SearchDashboardFeed()
        )
        SearchDashboardView(viewModel: viewModel)
    }
}
