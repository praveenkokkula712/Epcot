//
//  GameTileConfigurable.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 24/08/23.
//

import Foundation
import CasinoAPI

protocol GameTileConfigurable: Hashable, Equatable {
    var game: Game { get set }
    var sticker: String? { get }
    var blurImagePath: String? { get }
    var immersiveInfo: ImmersiveGameInfo? { get set }
    var publisher: GameTilePublisher? { get set }
    var onTap: (Self) -> Void { get }
    var onFavoriteTap: (Self) -> Void { get }
}

extension GameTileConfigurable {
    static func ==(lhs: Self, rhs: Self) -> Bool {
        lhs.game.uuid == rhs.game.uuid
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(game)
    }
}

extension GameTileConfigurable {
    var imagePath: String {
        immersiveInfo?.imagePath ??
        immersiveInfo?.gameInfo.imagePath ?? ""
    }

    var gameVariant: String {
        game.game ?? ""
    }
    
    var name: String {
        immersiveInfo?.gameInfo.gameMetadata.name ?? gameVariant
    }
    
    var isFavorite: Bool {
        immersiveInfo?.gameInfo.isFavouriteGame ?? false
    }
}
