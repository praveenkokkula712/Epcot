//
//  MostSearchedGamesViewModel.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 27/09/23.
//

import Foundation
import CasinoAPI
import Combine

class MostSearchedGamesViewModel {
    private var games: [String]?
    private(set) var gamesUpdated = PassthroughSubject<[String]?, Never>()
    
    deinit {
        ETLogger.debug("Deintialized Most Searched Games View Model")
    }
    
    func fetchIfNeeded(with feedDatasource: LobbyFeedDataSource?) {
        // Check if mostSearchedGames data is already available
        if gameVariants == nil {
            fetch(with: feedDatasource)
        }
    }
    
    private func fetch(with feedDatasource: LobbyFeedDataSource?) {
        Task {
            let gamesModel = try? await MostSearchedGamesService().fetch().get() as? MostSearchedGamesModel
            if !(gamesModel?.mostSearchedGamesSet?.isEmpty ?? true) {
                self.update(mostSearchedGames: gamesModel?.mostSearchedGamesSet,
                            with: feedDatasource)
                gamesUpdated.send(self.gameVariants)
            }
        }
    }

    private func update(mostSearchedGames: [String]?, with feedDatasource: LobbyFeedDataSource?) {
        var filteredGames = [String]()
        mostSearchedGames?.forEach({ gameVariant in
            if let _ = feedDatasource?.feedViewModel?.getMostSearchedGameMetadata(for: gameVariant) {
                filteredGames.append(gameVariant)
            }
        })
        self.games = filteredGames
    }
    
    var gameVariants: [String]? {
        self.games
    }
}
