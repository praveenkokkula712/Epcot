//
//  SearchResultLayout.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 22/09/23.
//

import Foundation

enum SearchResultsLayout: Int {
    case grid = 1
    case list = 2
    case listWithTabs = 3
    case listWithBlurImageAndPlayButton = 4

    static var currentLayout: Self {
        let layout = SearchSectionConfiguration().resultsLayoutType
        return SearchResultsLayout(rawValue: layout) ?? .grid
    }
}
