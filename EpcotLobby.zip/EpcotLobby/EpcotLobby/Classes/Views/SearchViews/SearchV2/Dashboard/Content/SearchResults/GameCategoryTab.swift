//
//  GameCategoryTab.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 21/09/23.
//

import Foundation

class GameCategoryTab: Identifiable {
    let uuid = UUID()
    let title: String

    init(title: String) {
        self.title = title
    }
}

extension GameCategoryTab: Hashable {
    func hash(into hasher: inout Hasher) {
        hasher.combine(self.uuid)
    }
}

extension GameCategoryTab: Equatable {
    static func ==(lhs: GameCategoryTab, rhs: GameCategoryTab) -> Bool {
        return lhs.uuid == rhs.uuid
    }
}
