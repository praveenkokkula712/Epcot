//
//  SearchResultsView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 08/09/23.
//

import SwiftUI

struct SearchResultsView: View {
    
    // MARK: Properties
    @ObservedObject var viewModel: SearchResultsViewModel
    private let sectionStyles = SearchSectionsCSS()
    
    // MARK: Body
    var body: some View {
        ScrollViewReader { proxy in
            if viewModel.shouldDisplayCategoryTabs {
                let tabViewModel = GameCategoryTabViewModel(
                    categories: viewModel.categories,
                    selectedCategory: viewModel.selectedCategory,
                    onSelectGameCategoryTab: viewModel.onSelectGameCategoryTab
                )
                VStack {
                    GameCategoryTabView(viewModel: tabViewModel)
                        .padding(.top, Self.isEpcot ? -4 : 12)
                        .background(Color(styles.categoryTabViewBackGroundColor))
                    if Self.isEpcot {
                        Divider()
                            .frame(height: sectionStyles.height)
                            .background(Color(sectionStyles.dividerColor))
                            .padding(.horizontal, 16)
                            .padding(.top, -8)
                    }
                }
            }
            if viewModel.shouldDisplayGamesCount {
                HStack {
                    let gamesCount = viewModel.gamesCount
                    Text(String(format: "results".localized,
                                String(gamesCount)))
                    .foregroundColor(styles.headerColor)
                    .font(styles.headerFont)
                    .padding(.leading, 16)
                    .padding(.top, 16)
                    .padding(.bottom, 16)
                    Spacer()
                }
            }
            ScrollView {
                LazyVGrid(columns: columns, spacing: 8)  {
                    ForEach(viewModel.games, id: \.self.game.uuid) { game in
                        switch viewModel.layout {
                        case .grid:
                            GameTileView(game: game)
                                .padding(.bottom, 4)
                                .id(game.game.uuid)
                        case .list, .listWithTabs:
                            GameTileListItemView(
                                game: game,
                                searchText: viewModel.searchText
                            )
                            .id(game.game.uuid)
                        case .listWithBlurImageAndPlayButton:
                            GameTileListItemViewWithPlayButton(
                                game: game,
                                searchText: viewModel.searchText
                            )
                            .id(game.game.uuid)
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            .animation(nil)
            .resignKeyboardOnDragGesture()
        }
        .background(Color(styles.searchResultsBackgroundColor))
    }
}
           
//MARK: Helper
extension SearchResultsView {
    
    private var columnsCount: Int {
        if UIDevice.isIPad() {
            return viewModel.layout == .grid ? 5 : 1
        } else {
            return viewModel.layout == .grid ? 3 : 1
        }
    }
    private var columns: [GridItem] {
        Array(repeating: .init(), count: columnsCount)
    }
    private var styles: SearchResultsCSS {
        viewModel.styles
    }
    private static var isEpcot: Bool { SearchResultsViewModel.isEpcot }
}

// MARK: - Previews
struct SearchResultsView_Previews: PreviewProvider {
    static var previews: some View {
        SearchResultsView(
            viewModel: SearchResultsViewModel()
        )
    }
}
