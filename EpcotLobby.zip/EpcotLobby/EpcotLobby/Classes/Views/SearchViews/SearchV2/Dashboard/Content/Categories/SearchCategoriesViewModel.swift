//
//  File.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 17/08/23.
//

import Foundation

class SearchCategoriesViewModel {
    
    // MARK: Properties
    let searchSection: SearchSection
    private var categories: [SearchCategory]?
    private let onSelectCategory: ((String) -> Void)?
    private(set) var pills: [Pill]?

    // MARK: Init
    init(searchSection: SearchSection,
         categories: [SearchCategory] = [],
         onSelectCategory: ((String) -> Void)? = nil) {
        self.searchSection = searchSection
        self.categories = categories
        self.onSelectCategory = onSelectCategory
        self.createPills()
    }

    // MARK: Helper
    private func createPills() {
        self.pills = categories?.map {
            Pill(
                key: $0.id,
                title: $0.name,
                isRemoveEnabled: false,
                onTap: { [weak self] in
                    self?.onSelectCategory?($0.key)
                },
                onRemove: { _ in }
            )
        } ?? []
    }
}

extension SearchCategoriesViewModel: CleanProtocol {
    func clean() {
        self.pills?.removeAll()
        self.pills = nil
    }
}
