//
//  ListItemConfigurable.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 23/08/23.
//

import Foundation

protocol ListItemConfigurable: PillViewConfigurable {
    var showLeadingAccessoryIcon: Bool { get set }
    var showTrailingAccessoryIcon: Bool { get set }
}
