//
//  SearchBarCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 10/08/23.
//

import SwiftUI
import Utility

struct SearchBarCSS {
    
    // MARK: Properties
    let backgroundColor: Color
    let height: CGFloat
    let cornerRadius: CGFloat
    let iconSize: CGFloat
    let placeholderColor: Color
    let titleFont: Font
    let titleColor: Color
    let clearSize: CGFloat
    let audioButtonSize: CGFloat
    let cancelFont: Font
    let cancelColor: Color
    let shadowRadius: CGFloat
    let shadowColor: Color
    let micActiveColor: Color
    let micInactiveColor: Color

    // MARK: Init
    init(searchBarV2CSS: SearchBarV2CSS? = nil) {
        let css = searchBarV2CSS ?? Self.lobbyCSS?.searchV2CSS?.searchBarV2CSS
        backgroundColor = Color(
            css?.backgroundColor ?? Self.defaultBackgroundColor
        )
        height = css?.height ?? Self.defaultHeight
        cornerRadius = css?.cornerRadius ?? Self.defaultCornerRadius
        iconSize = css?.iconSize ?? Self.defaultIconSize
        placeholderColor = Color(
            css?.placeholderColor ?? Self.defaultPlaceholderColor
        )
        titleFont = Font(css?.title?.font ?? Self.defaultTitleFont)
        titleColor = Color(css?.title?.color ?? Self.defaultTitleColor)
        clearSize = css?.clearSize ?? Self.defaultClearSize
        audioButtonSize = css?.audioButtonSize ?? Self.defaultAudioButtonSize
        cancelFont = Font(css?.cancelText?.font ?? Self.defaultCancelFont)
        cancelColor = Color(css?.cancelText?.color ?? Self.defaultCancelColor)
        shadowRadius = css?.shadowRadius ?? Self.defaultShadowRadius
        shadowColor = Color(css?.shadowColor ?? Self.defaultShadowColor)
        micActiveColor = Color(css?.micActiveColor ?? Self.defaultMicActiveColor)
        micInactiveColor = Color(css?.micInactiveColor ?? Self.defaultMicInActiveColor)
    }
}

// MARK: - Helper
extension SearchBarCSS: EpcotCheckable, LobbyStylable { }

extension SearchBarCSS {
    private static var defaultBackgroundColor: UIColor {
        isEpcot ? .init(red: 0.188, green: 0.188, blue: 0.188, alpha: 1.0) :
            .init(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
    } // #303030 : #333333
    private static var defaultHeight: CGFloat { isEpcot ? 32 : 38 }
    private static var defaultCornerRadius: CGFloat { isEpcot ? 16 : 32 }
    private static var defaultIconSize: CGFloat { 16 }
    private static var defaultPlaceholderColor: UIColor {
        isEpcot ? .init(red: 0.522, green: 0.522, blue: 0.522, alpha: 1.0) :
            .init(red: 0.188, green: 0.188, blue: 0.188, alpha: 1.0)
    } // #8B8E95 : #858585
    private static var defaultTitleFont: UIFont {
        let epcotFont = UIFont(name: "Poppins-Medium", size: 13) ??
            .systemFont(ofSize: 13, weight: .bold)
        let rowFont = UIFont(name: "Roboto-Regular", size: 16) ??
            .systemFont(ofSize: 16, weight: .regular)
        return isEpcot ? epcotFont : rowFont
    }
    private static var defaultTitleColor: UIColor { .white }
    private static var defaultClearSize: CGFloat { 16 }
    private static var defaultAudioButtonSize: CGFloat { 40 }
    private static var defaultCancelFont: UIFont {
        UIFont(name: "Poppins-Medium", size: 13) ??
            .systemFont(ofSize: 13, weight: .bold)
    }
    private static var defaultCancelColor: UIColor {
        .init(red: 0.475, green: 0.748, blue: 1, alpha: 1.0)
    } // #79BFFF
    private static var defaultShadowRadius: CGFloat { 12 }
    private static var defaultShadowColor: UIColor {
        .init(red: 0, green: 0, blue: 0, alpha: 0.4)
    } // #79BFFF
    private static var defaultMicInActiveColor: UIColor {
        UIColor.hexStringToUIColor(hex: "#C1C1C1")
    }
    private static var defaultMicActiveColor: UIColor {
        UIColor.hexStringToUIColor(hex: "#007AFF")
    }
}
