//
//  GameTileJackpotView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 12/09/23.
//

import SwiftUI
import Utility
import Kingfisher
import SDWebImageSVGKitPlugin
import SDWebImageSwiftUI
import ConfigModule

struct GameTileJackpotView: View {
    
    // MARK: Properties
    let value: String
    var isIconEnabled: Bool = true
    let styles = SearchSectionsCSS()
    let jackpotFireIconImagePath: String?
    let playerStatsStyles = PlayerStatsWidgetCss()
    var viewHeight: CGFloat = 0
    var fromPlayerStats: Bool = false
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
   
    private var textAllignmentForJackpot: JackpotTitleAlignment {
        EpcotLobbyManager.shared?.datasource?.textAllignmentForJackpot ?? .left
    }
    
    // MARK: Body
    var body: some View {
        HStack(alignment: .center, spacing: 4) {
            if textAllignmentForJackpot != .left {
                Spacer(minLength: 0)
            }
            if isIconEnabled, let jackpotFireIconImagePath, let imageURL = URL(string: jackpotFireIconImagePath) {
                if imageURL.absoluteString.isSVG {
                    SVGImageView(url: imageURL, size: CGSize(width: jackpotIconSize.width-3, height: jackpotIconSize.height))
                        .frame(width: jackpotIconSize.width-3, height: jackpotIconSize.height)
                        .padding(.leading, 6)
                } else {
                    KFImage(imageURL)
                        .placeholder {
                            PlaceHolderImage()
                        }
                        .resizable()
                        .frame(width: jackpotIconSize.width, height: jackpotIconSize.height)
                        .padding(.leading, 6)
                        .accessibilityIdentifier(jackpotImageIdentifier)
                }
            }
            Text(value)
                .foregroundColor(jackpotPriceColor)
                .font(jackpotFont)
                .padding(.leading, isIconEnabled ? 0 : 4)
                .accessibilityIdentifier(jackpotAmountIdentifier)
            if textAllignmentForJackpot != .right {
                Spacer(minLength: 0)
            }
        }
        .frame(height: jackpotHeight)
        .frame(maxWidth: .infinity)
        .background(jackpotPriceBgColor)
    }
}

extension GameTileJackpotView {
    
    private var jackpotPriceBgColor: Color {
        fromPlayerStats ? playerStatsStyles.jpPriceBgColor : styles.jpPriceBGColor
    }
    
    private var jackpotHeight: CGFloat {
        fromPlayerStats ? viewHeight : (isIconEnabled ? 24 : 12)
    }
    
    private var jackpotIconSize: CGSize {
        fromPlayerStats ? CGSize(width: 14 , height: viewHeight == 32 ? 16 : 12) : CGSize(width: 14, height: 16)
    }
    
    private var jackpotPriceColor: Color {
        fromPlayerStats ? playerStatsStyles.jpPriceColor : styles.jpPriceColor
    }
    
    private var jackpotFont: Font {
        fromPlayerStats ? (viewHeight == 32 ? playerStatsStyles.jpPriceFont : playerStatsStyles.jpPriceSecondFont) : (isIconEnabled ? styles.jpPriceFont : styles.listJpPriceFont)
    }
}

// MARK: - Accessibility Identifiers
extension GameTileJackpotView {
    
    private var jackpotImageIdentifier : String {
        accessibilityIdentifiers.jackpotImage
    }
    private var jackpotAmountIdentifier : String {
        accessibilityIdentifiers.jackpotAmount
    }
}

struct GameTileJackpotView_Previews: PreviewProvider {
    static var previews: some View {
        GameTileJackpotView(
            value: "$ 127,847.17", isIconEnabled: true, jackpotFireIconImagePath: "", viewHeight: 0, fromPlayerStats: false
        )
    }
}
