//
//  SearchResultsViewModel.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 20/09/23.
//

import SwiftUI
import Combine

class SearchResultsViewModel: ObservableObject {
    
    //MARK: Properties
    @Published private(set) var games = [GameTile]()
    private(set) var categories = [String]()
    private(set) var searchText: String = ""
    private(set) var immersiveInfo: ((Game) -> ImmersiveGameInfo?)?
    private(set) var blurImagePath: ((Game) -> String?)?
    private(set) var sticker: ((Game) -> String?)?
    private(set) var gameTilePublisher: GameTilePublisher?
    private(set) var onGameTap: ((Game) -> Void)?
    private(set) var onFavoriteGameTap: ((Game) -> Void)?

    private var gamesViewModel: SearchSectionGamesViewModel?
    private var categoryTabGames: [(categoryName: String, categoryGames: [Game])]?
    private(set) var selectedCategory: String = ""
    let styles = SearchResultsCSS()

    var layout: SearchResultsLayout { .currentLayout }
    var gamesCount: Int { games.count }

    var shouldDisplayCategoryTabs: Bool {
        return  layout == .listWithTabs ||  layout == .listWithBlurImageAndPlayButton
    }
    
    var shouldDisplayGamesCount: Bool {
        return layout == .grid || layout == .list || (shouldDisplayCategoryTabs && !Self.isEpcot)
    }

    //MARK: Init
    init(immersiveInfo: ((Game) -> ImmersiveGameInfo?)? = nil,
         blurImagePath: ((Game) -> String?)? = nil,
         sticker: ((Game) -> String?)? = nil,
         publisher: GameTilePublisher? = nil,
         onGameTap: ((Game) -> Void)? = nil,
         onFavoriteTap: ((Game) -> Void)? = nil) {
        self.immersiveInfo = immersiveInfo
        self.blurImagePath = blurImagePath
        self.sticker = sticker
        self.gameTilePublisher = publisher
        self.onGameTap = onGameTap
        self.onFavoriteGameTap = onFavoriteTap
    }
    
    // MARK: Tab Selection
    @discardableResult
    func onSelectGameCategoryTab(tab: GameCategoryTab) -> Bool {
        self.selectedCategory = tab.title
        let filteredGames = categoryTabGames?.first { $0.categoryName == tab.title }?.categoryGames ?? []
        formatGamesViewModel(filteredGames)
        return true
    }

    // MARK: Helper
    private func format(games: [Game]) {
        let layout = SearchResultsLayout.currentLayout
        var resultGames = [Game]()
        switch layout {
        case .grid, .list: resultGames = games
        case .listWithTabs, .listWithBlurImageAndPlayButton: resultGames = categoryTabGames?.first?.categoryGames ?? []
        }
        formatGamesViewModel(resultGames)
    }

    private func formatGamesViewModel(_ games: [Game]) {
        gamesViewModel = SearchSectionGamesViewModel(
            games: games,
            blurImagePath: self.blurImagePath,
            sticker: self.sticker,
            immersiveInfo: self.immersiveInfo,
            publisher: self.gameTilePublisher,
            onGameTap: self.onGameTap,
            onFavoriteTap: self.onFavoriteGameTap
        )
        self.games = gamesViewModel?.sectionGames ?? []
    }
}

//Update games and search text
extension SearchResultsViewModel {
    
    func update(searchedText: String = "",
                games: [Game] = [],
                categoryGames: [(String, [Game])] = []) {
        self.searchText = searchedText
        self.updateCategories(with: categoryGames, games: games)
    }
    
    private func updateCategories(with categoryGames: [(String, [Game])], games: [Game]) {
        self.categoryTabGames = categoryGames
        self.categories = self.categoryTabGames?.map { $0.categoryName } ?? []
        
        if let selectedCategoryIndex = categories.firstIndex(of: selectedCategory) {
            let selectedCategoryGames = categoryGames[selectedCategoryIndex].1
            formatGamesViewModel(selectedCategoryGames)
        } else {
            self.selectedCategory = categories.first ?? ""
            format(games: games)
        }
    }
    
    func resetSelectedCateory() {
        self.selectedCategory = ""
    }
}

extension SearchResultsViewModel: EpcotCheckable {}

extension SearchResultsViewModel: CleanProtocol {
    func clean() {
        self.games.removeAll()
        self.categories.removeAll()
        
        self.immersiveInfo = nil
        self.blurImagePath = nil
        self.sticker = nil
        self.gameTilePublisher = nil
        self.onGameTap = nil
        self.onFavoriteGameTap = nil
        
        self.gamesViewModel?.clean()
        self.gamesViewModel = nil
        
        self.categoryTabGames = nil
    }
}
