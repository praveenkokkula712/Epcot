//
//  PillView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 08/08/23.
//

import SwiftUI
import Utility

struct PillView<PillConfig: PillViewConfigurable>: View {

    // MARK: Properties
    private let pill: PillConfig?
    var styles = SearchSectionsCSS()
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
    
    // MARK: Init
    init(pill: PillConfig?) {
        self.pill = pill
    }

    // MARK: Body
    var body: some View {
        if let pill = pill {
            HStack (spacing: 0) {
                Text(pill.title)
                    .padding(.horizontal, 16)
                    .font(styles.titleFont)
                    .foregroundColor(styles.titleColor)
                    .accessibilityIdentifier(textIdentifier)
                if pill.isRemoveEnabled {
                    Button {
                        pill.onRemove(pill)
                    } label: {
                        Image(uiImage: close)
                            .frame(width: iconSize, height: iconSize)
                            .padding(.trailing, 8)
                            .accessibilityIdentifier(removeButtonImageIdentifier)
                    }
                    .accessibilityIdentifier(removeButtonIdentifier)
                }
            }
            .frame(height: frameHeight)
            .background(
                RoundedRectangle(cornerRadius: styles.pillsCornerRadius)
                    .fill(styles.pillsBackgroundColor)
            )
            .onTapGesture {
                pill.onTap(pill)
            }
        } else {
            EmptyView()
        }
    }
}

// MARK: Design Constants
extension PillView {
    private var iconSize: CGFloat { styles.closeIconSize }
    private var frameHeight: CGFloat { 36 }
    private var close: UIImage {
        return .init(named: "gray-close", in: kEpcotBundle, with: nil) ?? UIImage()
    }
}

// MARK: - Accessibility Identifiers
extension PillView {
    
    private var textIdentifier : String {
        accessibilityIdentifiers.pillViewTitle
    }
    private var removeButtonIdentifier : String {
        accessibilityIdentifiers.pillViewRemoveButton
    }
    private var removeButtonImageIdentifier : String {
        accessibilityIdentifiers.pillViewRemoveButtonImage
    }
}

// MARK: - Previews
struct PillView_Previews: PreviewProvider {
    static var previews: some View {
        PillView(pill: PillViewModel_Preview())
            .background(Color.black.opacity(0.8))
    }
}

struct PillViewModel_Preview: PillViewConfigurable {
    var title = "Casino"
    var isRemoveEnabled = false
    var onTap: (PillViewModel_Preview) -> Void = { _ in }
    var onRemove: (PillViewModel_Preview) -> Void = { _ in }
}
