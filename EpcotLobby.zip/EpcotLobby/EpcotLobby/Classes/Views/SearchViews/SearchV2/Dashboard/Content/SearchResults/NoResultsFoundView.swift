//
//  NoResultsFound.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 15/09/23.
//

import SwiftUI
import Utility

struct NoResultsFoundView: View {
    
    // MARK: Properties
    @ObservedObject var searchBarViewModel: SearchBarViewModel
    private let sectionStyles = SearchSectionsCSS()
    private let styles = SearchResultsCSS()
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()

    // MARK: Body
    var body: some View {
        VStack {
            Image(uiImage: noResultsFound)
                .padding(.top, Self.isEpcot ? 0 : 16)
            let searchText = searchBarViewModel.searchText
            Text(String(format: "no_results_found_title".localized,
                        searchText))
                .foregroundColor(styles.noResultsTitleColor)
                .font(styles.noResultsTitleFont)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 16)
                .accessibilityIdentifier(titleIdentifier)
            Text("no_results_found_subtitle".localized)
                .foregroundColor(styles.noResultsSubTitleColor)
                .font(styles.noResultsSubTitleFont)
                .multilineTextAlignment(.center)
                .padding([.horizontal, .bottom], 16)
                .accessibilityIdentifier(subTitleIdentifier)
            Divider()
                .frame(height: sectionStyles.height)
                .background(Color(sectionStyles.dividerColor))
                .padding(.horizontal, 16)
        }
        .background(Color(styles.noResultsFoundBackgroundColor))
    }
}

//MARK: - Helper
extension NoResultsFoundView: EpcotCheckable, LobbyStylable { }

extension NoResultsFoundView {
    
    private var noResultsFound: UIImage {
        return .init(named: "no-results", in: kEpcotBundle, with: nil) ?? UIImage()
    }
}

// MARK: - Accessibility Identifiers
extension NoResultsFoundView {
    private var titleIdentifier : String {
        accessibilityIdentifiers.title
    }
    private var subTitleIdentifier : String {
        accessibilityIdentifiers.subTitle
    }
}

// MARK: - Previews
struct NoResultsFoundView_Previews: PreviewProvider {
    static var previews: some View {
        let barViewModel = SearchBarViewModel()
        NoResultsFoundView(searchBarViewModel: barViewModel)
    }
}
    
   
