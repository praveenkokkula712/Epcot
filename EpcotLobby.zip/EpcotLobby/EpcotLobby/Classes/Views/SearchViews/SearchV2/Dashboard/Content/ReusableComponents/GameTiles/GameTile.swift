//
//  SearchGames.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 24/08/23.
//

import Foundation
import CasinoAPI

struct GameTile: GameTileConfigurable {    
    var game: Game
    var sticker: String?
    var blurImagePath: String?
    var immersiveInfo: ImmersiveGameInfo?
    var publisher: GameTilePublisher?
    var onTap: (GameTile) -> Void
    var onFavoriteTap: (GameTile) -> Void
}

struct GameTileReceiver {
    var jackpot: [String: String]?
    var favorite: [String: Bool]?
}
