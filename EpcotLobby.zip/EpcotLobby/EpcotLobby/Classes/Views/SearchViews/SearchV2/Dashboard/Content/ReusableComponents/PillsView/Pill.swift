//
//  Pill.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 22/08/23.
//

import Foundation

struct Pill: PillViewConfigurable {
    var key: String = ""
    var title: String
    var isRemoveEnabled: Bool
    var onTap: (Pill) -> Void
    var onRemove: (Pill) -> Void
}
