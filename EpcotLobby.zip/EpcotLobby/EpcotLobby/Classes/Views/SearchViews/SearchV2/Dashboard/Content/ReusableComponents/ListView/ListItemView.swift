//
//  ListView.swift
//  CasinoSearch
//
//  Created by Sreekanth Reddy Tadi on 08/08/23.
//

import SwiftUI
import Utility

struct ListItemView<ListItem: ListItemConfigurable>: View {
    
    // MARK: Properties
    private let item: ListItem
    let styles = SearchSectionsCSS()
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
    // MARK: Init
    init(item: ListItem) {
        self.item = item
    }
    
    // MARK: Body
    var body: some View {
        VStack {
            HStack (spacing: 8) {
                if item.showLeadingAccessoryIcon {
                    Image(uiImage: clock)
                        .frame(width: clockIconSize, height: clockIconSize)
                        .accessibilityIdentifier(historyIconIdentifier)
                }
                Text(item.title)
                    .foregroundColor(styles.titleColor)
                    .font(styles.titleFont)
                    .accessibilityIdentifier(textIdentifier)
                Spacer()
                if item.isRemoveEnabled {
                    Button {
                        item.onRemove(item)
                    } label: {
                        Image(uiImage: xmark)
                            .frame(width: closeIconSize, height: closeIconSize)
                    }
                    .accessibilityIdentifier(removeButtonIdentifier)
                } else if item.showTrailingAccessoryIcon {
                    Button {
                        item.onTap(item)
                    } label: {
                        Image(uiImage: arrow)
                            .frame(width: arrowIconSize, height: arrowIconSize)
                    }
                    .accessibilityIdentifier(arrowIconIdentifier)
                }
            }
            if item.showTrailingAccessoryIcon || Self.isEpcot {
                Divider()
                    .frame(height: styles.height)
                    .background(Color(styles.dividerColor))
            }
        }
        .padding(.horizontal, 4)
        .frame(height: 48)
        .contentShape(Rectangle())
        .onTapGesture {
            item.onTap(item)
        }
    }
}

struct ListItemView_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            ListItemView(item: ListItem_Preview())
        }
        .background(Color.black.opacity(0.8))
    }
}


struct ListItem_Preview: ListItemConfigurable {
    var title = "Casino"
    var isRemoveEnabled = false
    var showLeadingAccessoryIcon = true
    var showTrailingAccessoryIcon = true
    var onTap: (ListItem_Preview) -> Void = { _ in }
    var onRemove: (ListItem_Preview) -> Void = { _ in }
}

// MARK: Design Constants
extension ListItemView: EpcotCheckable, LobbyStylable { }

extension ListItemView {
    private var clockIconSize: CGFloat { styles.searchHistoryIconSize }
    private var closeIconSize: CGFloat { styles.closeIconSize }
    private var arrowIconSize: CGFloat { styles.arrowIconSize }
    private var clock: UIImage {
        return .init(named: "gray-clock", in: kEpcotBundle, with: nil) ?? UIImage()
    }
    private var xmark: UIImage {
        let name = Self.isEpcot ? "blue-cross" : "gray-xmark"
        return .init(named: name, in: kEpcotBundle, with: nil) ?? UIImage()
    }
    private var arrow: UIImage {
        return .init(named: "left-arrow", in: kEpcotBundle, with: nil) ?? UIImage()
    }
}

// MARK: - Accessibility Identifiers
extension ListItemView {
    
    private var historyIconIdentifier : String {
        accessibilityIdentifiers.listViewHistoryIcon
    }
    private var textIdentifier : String {
        accessibilityIdentifiers.listViewTitle
    }
    private var removeButtonIdentifier : String {
        accessibilityIdentifiers.listViewRemoveButton
    }
    private var arrowIconIdentifier : String {
        accessibilityIdentifiers.listViewArrow
    }
}
