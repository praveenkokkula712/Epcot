//
//  SearchCategoriesPillsView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 17/08/23.
//

import SwiftUI

struct SearchCategoriesPillsView: View {
    let viewModel: SearchCategoriesViewModel
    
    var body: some View {
        VStack {
            CasinoSearchContainerHeaderView(
                viewModel: CasinoSearchContainerHeaderViewModel(
                    searchSection: viewModel.searchSection
                )
            )
            switch viewModel.searchSection.layoutType {
            case .pillsContinuous:
                HorizontalPillsView(pills: viewModel.pills ?? [])
            case .pills:
                GridPillsView(pills: viewModel.pills ?? [])
            default: EmptyView()
            }
        }
        .padding(.bottom, 8)
    }
}

struct SearchCategoriesPillsView_Previews: PreviewProvider {
    static var previews: some View {
        SearchCategoriesPillsView(
            viewModel: SearchCategoriesViewModel(
                searchSection: SearchSection()
            )
        )
    }
}
