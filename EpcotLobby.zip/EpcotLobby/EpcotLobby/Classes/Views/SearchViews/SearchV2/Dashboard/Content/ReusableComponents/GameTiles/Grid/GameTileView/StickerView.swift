//
//  StickerView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 05/12/23.
//

import SwiftUI
import Utility

struct StickerView: View {
    
    // MARK: Properties
    var stickerLabel: String
    let styles = SearchSectionsCSS()
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()
    
    // MARK: Body
    var body: some View {
        HStack {
            Text(stickerLabel)
                .font(styles.stickerTextFont)
                .foregroundColor(styles.stickerTextColor)
                .lineLimit(1)
                .minimumScaleFactor(0.5)
                .padding(.horizontal, 2)
        }
        .fixedSize(horizontal: false, vertical: true)
        .frame(minHeight: 20)
        .background(Color(styles.stickerBackGroundColor))
        .cornerRadius(styles.stickerCornerRadius)
        .accessibilityIdentifier(stickerIdentifier)
    }
}

// MARK: - Accessibility Identifiers
extension StickerView {
    
    private var stickerIdentifier : String {
        accessibilityIdentifiers.stickerLabel
    }
}

// MARK: - Previews
struct StickerView_Previews: PreviewProvider {
    static var previews: some View {
        StickerView(stickerLabel: "")
    }
}
