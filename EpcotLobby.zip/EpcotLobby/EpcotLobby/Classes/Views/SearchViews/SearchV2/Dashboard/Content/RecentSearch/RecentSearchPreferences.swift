//
//  RecentSearchPreferences.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 21/08/23.
//

import Combine

class RecentSearchPreferences: ObservableObject {

    // MARK: Properties
    @Published var searchWords = [String]()
    
    @UserDefaultStandard(key: "Recent_Searches")
    private var storedWords: [String]?
    private var limitWords: Int
    var onTapRecentSearch: ((String) -> Void)?

    // MARK: Init
    init(limit: Int? = 5, onTapRecentSearch: ((String) -> Void)? = nil) {
        limitWords = limit ?? 5
        searchWords = Array(storedWords ?? [])
        self.onTapRecentSearch = onTapRecentSearch
    }

    // MARK: CRUD Operations
    func append(_ word: String) {
        if let words = storedWords {
            self.remove(word)
            storedWords?.insert(word, at: 0)
            self.storedWords = self.storedWords?
                .prefix(self.limitWords)
                .compactMap({ $0 })
            searchWords = storedWords ?? []
        } else {
            storedWords = [word]
            searchWords = storedWords ?? []
        }
    }

    func remove(_ word: String) {
        if var words = storedWords,
           let index = words.firstIndex(of: word) {
            words.remove(at: index)
            storedWords = words
        }
        searchWords = storedWords ?? []
    }

    func removeAll() {
        storedWords = []
        searchWords = []
    }
}
