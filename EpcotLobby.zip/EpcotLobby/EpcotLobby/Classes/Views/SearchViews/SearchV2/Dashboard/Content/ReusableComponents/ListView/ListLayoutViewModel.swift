//
//  ListLayoutViewModel.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 23/11/23.
//

import Foundation

struct ListLayoutViewModel<ListItem: ListItemConfigurable> {

    // MARK: Properties
    let listItems: [ListItem]

    // MARK: Init
    init(listItems: [ListItem]) {
        self.listItems = listItems
    }
}
