//
//  TextFieldClearButton.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 08/08/23.
//

import SwiftUI
import Utility

// From Hacking with Swift: https://www.hackingwithswift.com/forums/100-days-of-swift/adding-a-clear-button-to-a-textfield/12079

struct TextFieldClearButton: ViewModifier {
    
    // MARK: Properties
    @Binding var fieldText: String
    let image: UIImage
    var isClearButtonEnabled: Bool
    private let accessibilityIdentifiers = SearchV2AccessibilityIdentifiers()

    // MARK: Body
    func body(content: Content) -> some View {
        HStack {
            content

            if isClearButtonEnabled {
                HStack {
                    Button {
                        fieldText = ""
                    } label: {
                        Image(uiImage: image)
                    }
                    .padding(.trailing, 10)
                    .frame(width: 40, height: 40)
                    .accessibilityIdentifier(clearButtonIdentifier)
                }
            }
        }
    }
}

// MARK: - Accessibility Identifier
extension TextFieldClearButton {
    
    private var clearButtonIdentifier : String {
        accessibilityIdentifiers.clearButton
    }
}


// MARK: Show Clear Button View
extension View {
    func showClearButton(_ text: Binding<String>, image: UIImage, isClearButtonEnabled: Bool) -> some View {
        self.modifier(TextFieldClearButton(fieldText: text, image: image, isClearButtonEnabled: isClearButtonEnabled))
    }
}
