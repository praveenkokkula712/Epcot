//
//  SearchDashboardViewModel.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 08/08/23.
//

import Foundation
import CasinoAPI
import Combine
import TrackerClient
import Utility

enum selectedSection {
    case none
    case recentSearch
    case suggestedGames
    case provider
    case category
}

class SearchDashboardViewModel: ObservableObject {
    
    // MARK: Properties
    let isEpcot: Bool
    var isVoiceCommand: Bool
    var feed: SearchDashboardFeed?
    private var onGameTap: ((Game) -> Void)?
    private var closeDashboard: () -> Void
    
    @Published private(set) var searchResults: [Game]?
    @Published private(set) var categoryBasedSearchResults: [(String, [Game])]?
    @Published private(set) var barViewModel: SearchBarViewModel?
    @Published private(set) var resultsViewModel: SearchResultsViewModel?
    
    /// Search Preferences to store the recent words searched by the user.
    private var searchPreferences: RecentSearchPreferences?
    var containerViewModel: CasinoSearchContainerViewModel?
    
    private var subscriberSearchText: AnyCancellable?
    
    var showSearchResults: Bool {
        !(searchResults?.isEmpty ?? true) || !(categoryBasedSearchResults?.isEmpty ?? true)
    }
    private var speechRecognizerManager: SpeechRecognizerManager?
    //using for tracking events
    private var fromSection: selectedSection = .none
    
    // MARK: Init
    init(
        isEpcot: Bool = false,
        isVoiceCommand: Bool = false,
        feed: SearchDashboardFeed = SearchDashboardFeed(),
        onGameTap: ((Game) -> Void)? = nil,
        closeDashboard: @escaping () -> Void = { }
    ) {
        self.isEpcot = isEpcot
        self.isVoiceCommand = isVoiceCommand
        self.feed = feed
        self.onGameTap = onGameTap
        self.closeDashboard = closeDashboard
        self.allocateDataFields()
        self.createViewModels()
        self.subscribeToSearchText()
        if self.isVoiceCommand {
            self.setUpVoiceRecognizer()
        }
    }
    
    deinit {
        self.clean()
    }
    
    private func allocateDataFields() {
        searchResults = [Game]()
        categoryBasedSearchResults = [(String, [Game])]()
    }
    
    private func createViewModels() {
        let sections = SearchSectionConfiguration().sections
        let limitRecentSearches = sections.first(where: {
            $0.sectionType == .recentSearch
        })?.limit ?? 5
        self.searchPreferences = RecentSearchPreferences(
            limit: limitRecentSearches,
            onTapRecentSearch: { [weak self] text in
                self?.searchPreferences?.append(text)
                self?.updateSearchText(text)
                self?.fromSection = .recentSearch
            }
        )
        
        self.barViewModel = SearchBarViewModel(
            preferences: self.searchPreferences ?? RecentSearchPreferences(),
            voiceCommandAction: {
                UserDefaults.userOnboardingVoiceSearchEnhanced = true
                self.setUpVoiceRecognizer()
            },
            cancelAction: { [weak self] in
                self?.closeSearchPage()
            }
        )
        
        self.containerViewModel = CasinoSearchContainerViewModel(
            layouts: sections,
            feed: self.feed ?? SearchDashboardFeed(),
            searchPreferences: self.searchPreferences ?? RecentSearchPreferences(),
            onSelectCategory: { [weak self] category in
                let categoryName = self?.feed?.feedViewModel?.getCategoryName(for: category) ?? category
                self?.searchPreferences?.append(categoryName)
                self?.updateSearchText(categoryName)
                self?.fromSection = .category
            },
            onVendorTap: { [weak self] vendor in
                let vendorName = vendor.name
                self?.searchPreferences?.append(vendorName)
                self?.updateSearchText(vendorName)
                self?.fromSection = .provider
            },
            onGameTap: { [weak self] (game, section) in
                self?.onGameTap(game: game)
                self?.fromSection = .suggestedGames
                self?.trackEventOnGameTap(game: game,
                                          gamesSection: section.sectionType)
                NotificationCenter.default.post(name: Notification.Name(rawValue: kResetBottomSearchLayout), object: nil)
            }
        )
        
        self.resultsViewModel = SearchResultsViewModel(
            immersiveInfo: self.feed?.immersiveInfo,
            blurImagePath: self.feed?.blurImagePath,
            sticker: self.feed?.sticker,
            publisher: self.feed?.gameTilePublisher,
            onGameTap: { [weak self] game in
                self?.onGameTap(game: game)
                self?.trackEventOnGameTap(game: game)
                NotificationCenter.default.post(name: Notification.Name(rawValue: kResetBottomSearchLayout), object: nil)
            },
            onFavoriteTap: self.feed?.onFavoriteGameTap
        )
    }
}
 
//MARK: Action
extension SearchDashboardViewModel {
    
    func closeSearchPage() {
        self.closeDashboard()
        // To achieve animation, cleaning the view models after delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.clean()
        }
    }
    
    func backAction() {
        showSearchResults ? clearResults() : closeSearchPage()
    }
    
    private func onGameTap(game: Game) {
        if let searchedText = self.barViewModel?.searchText,
           !searchedText.isEmpty {
            ///if user searched something and in results tap on game, need to add the keyword to searched list
            self.searchPreferences?.append(searchedText)
        }
        self.onGameTap?(game)
    }
}

//MARK: Subscribe
extension SearchDashboardViewModel {

    private func subscribeToSearchText() {
        // Debounce
        // The query happens only if the user activity is idle for 0.5s while entering the search text, in this way we would be limiting a lot of redundant queries which results in app being responsive.
        self.subscriberSearchText = self.barViewModel?.$searchText
            .debounce(for: .milliseconds(500), scheduler: RunLoop.main)
            .sink { [weak self] searchText in
                //filter games with search text
                self?.filterGames(searchText: searchText)
                //only for track event
                self?.updateSectionForTrackEvent(searchText: searchText)
            }
    }
}

extension SearchDashboardViewModel {
    
    private func updateSearchText(_ text: String) {
        self.barViewModel?.searchText = text
    }
    
    private func filterGames(searchText: String) {
        if searchText.isEmpty {
            self.searchResults?.removeAll()
            self.categoryBasedSearchResults?.removeAll()
            self.fromSection = .none
            self.resultsViewModel?.resetSelectedCateory()
            return
        }
        self.searchResults = feed?.feedViewModel?.getSearchedGames(with: searchText,
                                                                  checkVendors: true) ?? []
        self.categoryBasedSearchResults = feed?.feedViewModel?.getCategoryBasedGames(with: searchText) ?? []
        
        if let results = searchResults, !results.isEmpty {
            if let categoryBasedSearchResults = self.categoryBasedSearchResults, 
                categoryBasedSearchResults.isEmpty {
                //we can get this condition for vendor
                self.categoryBasedSearchResults = [("top".localized.displayName(), results)]
            } else {
                //reversing the array as categpry and vendor games are adding first, which cannot match search string to highlight in results UI
                self.categoryBasedSearchResults?.insert(("top".localized.displayName(), results.reversed()), at: 0)
            }
        }
        self.resultsViewModel?.update(searchedText: searchText,
                                      games: self.searchResults ?? [],
                                      categoryGames: self.categoryBasedSearchResults ?? [])
        self.trackEvents(eventAction: EpcotEventAction.manual_search.rawValue,
                          eventLabel: EpcotEventLabel.globalSearch.rawValue,
                          eventLocation: ScreenName.casino.rawValue,
                          eventDetails: EpcotEventDetails.manual_search.rawValue,
                          eventPosition: EpcotEventPosition.navigationTopBar.rawValue,
                          searchText: searchText)
    }
    
    func clearResults() {
        self.updateSearchText("")
        self.barViewModel?.dismissKeyboard()
    }
}

extension SearchDashboardViewModel {
    
    private func setUpVoiceRecognizer() {
        self.speechRecognizerManager = SpeechRecognizerManager()
        self.speechRecognizerManager?.setUpSpeechRecognizer { status in
            DispatchQueue.main.async { [weak self] in
                if status {
                    self?.startSpeechRecognizer()
                } else {
                    let title = Localize.alertSpeechTitle
                    let description = Localize.alertMessageForSpeech
                    self?.showPopUpView(alertTitle: title, alertDescription: description)
                    ETLogger.debug("User denied access to speech recognition")
                }
            }
        }
        self.speechRecognizerManager?.didFailedToAccessMicrophone = {
            self.didFailedToAccessMicrophone()
        }
        self.speechRecognizerManager?.status = { [weak self] status in
            self?.barViewModel?.speechStatus = status == .start
        }
    }
    
    private func startSpeechRecognizer() {
        self.speechRecognizerManager?.startRecording() { [weak self] searchText, isFinal in
            if let text = searchText {
                self?.barViewModel?.searchText = text
                if isFinal {
                    self?.updateSearchText(text)
                    self?.searchPreferences?.append(text)
                }
            }
        }
    }
}

extension SearchDashboardViewModel {
    
    private func showPopUpView(alertTitle: String, alertDescription: String) {
        let okText = Localize.okButtonTitle
        let okAction = UIAlertAction(title: okText, style: .default) { (action) in
            if let settings = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(settings)
            }
        }
        if EntainContext.app?.isCustomThemeEnabled ?? false {
            SpeechRecognitionAccessModel().showVoiceSearchPopUpView(alertTitle: alertTitle, alertDescription: alertDescription)
        } else {
            let topViewController = UIApplication.topViewController()
            topViewController?.showAlert(alertTitle, alertDescription, [okAction])
        }
    }
    
    func didFailedToAccessMicrophone() {
        let title = Localize.alertMicrophoneTitle
        let description = Localize.alertMessageForMicrophone
        self.showPopUpView(alertTitle: title, alertDescription: description)
        ETLogger.debug("User denied access to speech recognition")
        KibanaLogManager.sendButtonAction(feature: .searchView,
                                          function: "MicroPhone access failed",
                                          fileName: #file,
                                          remarks: Localize.alertMessageForMicrophone)
    }
}

extension SearchDashboardViewModel {
    
    private func updateSectionForTrackEvent(searchText: String?) {
        switch self.fromSection {
        case .recentSearch, .provider, .category:
            if searchText?.isEmpty ?? true {
                self.fromSection = .none
            }
        default:
            self.fromSection = .none
        }
    }
    
    func trackEventOnGameTap(game: Game,
                             gamesSection: SearchSection.SectionType = .none) {
        var eventLocation = ""
        var eventPosition = ""
        var searchText = ""
        
        switch self.fromSection {
        case .suggestedGames: // all other categories (most searched, new, recommended, sitecore games)
            eventLocation = EpcotEventLocation.section.rawValue
            eventPosition = gamesSection.sectionNameforEvent()
        case .provider:
            eventLocation = EpcotEventLocation.provider.rawValue
            eventPosition = EpcotEventPosition.provider.rawValue
        case .recentSearch:
            eventLocation = EpcotEventLocation.section.rawValue
            eventPosition = EpcotEventPosition.recent.rawValue
        case .category:
            eventLocation = EpcotEventLocation.category.rawValue
            eventPosition = EpcotEventPosition.category.rawValue
        default:
            if let searchedText = self.barViewModel?.searchText,
               !searchedText.isEmpty {
                eventLocation = ScreenName.casino.rawValue
                eventPosition = EpcotEventPosition.search_result.rawValue
                searchText = searchedText
            }
        }
        if !eventLocation.isEmpty, !eventPosition.isEmpty {
            self.trackEvents(eventAction: EpcotEventAction.click.rawValue,
                             eventLabel: EpcotEventLabel.search_interaction.rawValue,
                             eventLocation: eventLocation,
                             eventDetails: game.game ?? "",
                             eventPosition: eventPosition,
                             searchText: searchText)
        }
    }
    
    func trackEvents(eventAction: String = EpcotEventAction.manual_search.rawValue,
                     eventLabel: String = EpcotEventLabel.globalSearch.rawValue,
                     eventLocation: String = ScreenName.casino.rawValue,
                     eventDetails: String = EpcotEventDetails.manual_search.rawValue,
                     eventPosition: String = EpcotEventPosition.navigationTopBar.rawValue,
                     searchText: String = "") {
        let log = InteractionLog(categoryEvent: EpcotEventCategory.globalSearch.rawValue,
                                 actionEvent: eventAction,
                                 labelEvent: eventLabel,
                                 locationEvent: eventLocation,
                                 eventDetails: eventDetails,
                                 positionEvent: eventPosition,
                                 termSearch: searchText)
        let event = TrackerEvent(type: EventType(rawValue: EventType.globalSearch.rawValue), log: log, tracker: .gtm)
        Tracker.postNotification(object: self, userInfo: [kEvent: event])
    }
}

extension SearchDashboardViewModel: CleanProtocol {
    func clean() {
        self.containerViewModel?.clean()
        self.feed?.clean()
        
        self.searchResults = nil
        self.categoryBasedSearchResults = nil
        
        self.barViewModel = nil
        self.resultsViewModel = nil
        
        self.searchPreferences = nil
        self.containerViewModel = nil
        
        self.subscriberSearchText?.cancel()
        
        self.speechRecognizerManager = nil
    }
}
