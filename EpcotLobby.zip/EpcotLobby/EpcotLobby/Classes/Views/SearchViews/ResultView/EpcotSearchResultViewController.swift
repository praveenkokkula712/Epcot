//
//  EpcotSearchResultViewController.swift
//  EpcotLobby
//
//  Created by Challa Venkata Narasimha Karthik on 07/04/22.
//  Copyright © 2022 Ivy Comptech. All rights reserved.
//

import UIKit
import Kingfisher
import TrackerClient

/// Search result view - Grid View
class EpcotSearchResultViewController: ImmersiveLobbyCollectionViewController {
        
    private var lobbyGames: [Game] = [Game]()
    
    private var lobbyType: SwitcherCategoryType {
        EpcotLobbyManager.shared?.lobbySwitcherType ?? .grid
    }
    
    var didScrolled:((UIScrollView) -> Void)?
    
        /// Update games and reload the view
        /// - Parameter games: List of games to be shown (search results)
    func update(games: [Game]) {
        self.lobbyGames = games
        self.applySnapshot()
    }
    
    override func setupCollectionView() {
        self.collectionViewLayout.invalidateLayout()
        self.collectionView.isPrefetchingEnabled = true
        self.collectionView.prefetchDataSource = self
        self.collectionView.collectionViewLayout = self.createCompositionalLayout()
        self.collectionView.setupDefaultConfiguration()
        self.collectionView.registerNibCells(withCells: CellIdentifier.gameCell,CellIdentifier.lobbyListCVCell,
                              bundle: kEpcotBundle)
        self.collectionView.backgroundColor = .clear
        self.collectionView.isPrefetchingEnabled = true
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.stopJackpotTimer()
    }
    
        /// Configure Diffable DataSource
    override func configureDatasource() {
        self.diffDatasource = ImmersiveDatasource(collectionView: collectionView, cellProvider: { collectionView, indexPath, itemIdentifier in
            self.cell(collectionView: collectionView, indexPath: indexPath, item: itemIdentifier)
        })
        self.applySnapshot()
    }
    
        /// Confiure CollectionView cells based on the existing state
        /// - Parameters:
        ///   - collectionView: UICollectionView
        ///   - indexPath: IndexPath from DataSource
        ///   - item: Item
        /// - Returns: UICollectionViewCell
    override func cell(collectionView: UICollectionView, indexPath: IndexPath, item: Item) -> UICollectionViewCell? {
        switch item {
        case .game(let game, _):
            let sticker = game.sticker
            let localizedStickerName = self.datasource?.feedViewModel?.getCategoryName(for: sticker ?? "")
            switch lobbyType {
            case .list:
                let listCell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.lobbyListCVCell, for: indexPath) as? GamesListViewCell
                if let gameVariant = game.game, let immersiveInfo = self.datasource?.feedViewModel?.getImmersiveInfo(for: gameVariant, with: "\(LayoutType.list.rawValue)") {
                    let blurImagePath = self.datasource?.feedViewModel?.getListCellBlurImagePath(for: gameVariant)
                    listCell?.configureCell(with: immersiveInfo,
                                            blurImagePath: blurImagePath,
                                            sticker: localizedStickerName)
                }
                listCell?.favouritesDelegate = self
                listCell?.subscribeTo(subject: self.jackpotInfoSubject)
                return listCell
            default:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.gameCell, for: indexPath) as? EpcotGameCollectionViewCell
                if let gameVariant = game.game,
                   let immersiveInfo = self.datasource?.feedViewModel?.getImmersiveInfo(for: gameVariant, with: "\(LayoutType.verticalImmersiveGrid.rawValue)") {
                    cell?.configureCell(with: immersiveInfo,
                                        sticker: localizedStickerName)
                }
                cell?.subscribeTo(subject: jackpotInfoSubject)
                cell?.favouritesDelegate = self
                return cell
            }
        default : return UICollectionViewCell()
        }
    }
    
    override func applySnapshot(with category: String? = nil, for isJackpotUpdate: Bool = false) {
        snapShot = ImmersiveSnapshot()
        self.immersiveElements = [ImmersiveLobbySection]()
        var layout: LayoutType = .verticalImmersiveGrid
        let isImmersiveEnabled = ImmersiveInstance.shared.isEnabled
        switch self.lobbyType {
        case .list: layout = .list
        case .grid: layout = isImmersiveEnabled ? .verticalImmersiveGrid : .verticalGrid
        }
        let isEpcotEnabled = EpcotLobbyManager.shared?.css.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false
        let immersiveSection = ImmersiveLobbySection(subCategoryId: nil,
                                                     games: self.lobbyGames,
                                                     layoutType: layout,
                                                     isHeaderAvailable: false,
                                                     isFromSearchController: !isEpcotEnabled)
        
        self.immersiveElements.append(immersiveSection)
        
        snapShot?.appendSections([immersiveSection])
        snapShot?.appendItems(self.lobbyGames.map({Item.game($0, UUID())}), toSection: immersiveSection)
        
        guard let snapShot = snapShot else { return }
        diffDatasource?.apply(snapShot, animatingDifferences: true)
        self.startJackpotTimer()
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let controller = self.parent, ((controller is EpcotSearchViewController) || (controller is SearchViewController)) {
            if let gameName = self.lobbyGames[indexPath.row].game {
                self.trackEvent(gameName: gameName)
            }
            super.collectionView(collectionView, didSelectItemAt: indexPath)
            self.stopJackpotTimer()
            return
        }
        super.collectionView(collectionView, didSelectItemAt: indexPath)
    }
    
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.didScrolled?(scrollView)
    }
    
    override func reloadItem(_ gameVariant: String? = nil, isFavouriteUpdate: Bool = false) {
        guard self.collectionView != nil, !self.collectionView.isTracking else { return }
        guard var snapShot = self.diffDatasource?.snapshot() else { return }
        if let gameVariant = gameVariant {
            if let items = self.snapShot?.itemIdentifiers {
                if let reloadedItem = items.first(where: { item in
                    guard case .game(let game, _) = item else {
                        return false
                    }
                    guard let variant = game.game else {
                        return false
                    }
                    return variant == gameVariant
                }) {
                    snapShot.reloadItems([reloadedItem])
                }
            }
        } else {
            if let items = self.snapShot?.sectionIdentifiers.filter({$0.layoutType != .teasers || $0.layoutType != .embeddedBanner || $0.layoutType != .videoLayout}) {
                snapShot.reloadSections(items)
            }
        }
        self.diffDatasource?.apply(snapShot, animatingDifferences: true)
    }
    
    
    override func dismiss(animated flag: Bool, completion: (() -> Void)? = nil) {
        super.dismiss(animated: flag, completion: completion)
        self.stopJackpotTimer()
    }
    
    override func clean() {
        super.clean()
        self.didScrolled = nil
    }
    
    override func didTappedOn(favourites cell: EpcotBaseCollectionViewCell, gameVariant: String, state: Bool) {
        let favouriteState: FavouriteState = state ? .selected : .unselected
        if let collectionCell = cell as? EpcotGameCollectionViewCell {
            collectionCell.isFavouriteGame = favouriteState
        } else if let listCell = cell as? GamesListViewCell {
            listCell.isFavouriteGame = favouriteState
        }
        self.delegate?.didTappedOnFavourites(gameVariant: gameVariant, state: state,from: false)
    }
    
    deinit {
        self.stopJackpotTimer()
        NotificationCenter.default.removeObserver(self)
        ETLogger.debug("Deinit \(type(of: self))")
    }
}

extension EpcotSearchResultViewController {
    private func trackEvent(gameName: String) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.globalSearch.rawValue,
                                     actionEvent:EpcotEventAction.click.rawValue,
                                     labelEvent: EpcotEventLabel.search_interaction.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: gameName,
                                     positionEvent: EpcotEventPosition.search_result.rawValue)
            
            let event = TrackerEvent(type: .globalSearch, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}
