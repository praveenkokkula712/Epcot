//
//  DialogBoxView.swift
//  DialogBox
//
//  Created by Naresh Banavath on 03/04/24.
//

import SwiftUI
import CasinoAPI
import Utility
import Kingfisher
import TrackerClient

struct PlayBreakView: View {
    
    @StateObject var viewModel = ARCRtmsViewModel()
    var cssModel = PlayBreakViewCSSModel()
    var duration: String
    var type: PlayBreakType = .gracePeriod
    @State private var size: CGFloat = .zero
    @State private var contactUsSize: CGFloat = .zero
    
    var clickAction: ((PlaybreakAction) -> ())?
    
    var body: some View {
        
        GeometryReader { geometry in
            ZStack {
                /// - Background Color
                cssModel.overlayBgColor
                
                VStack {
                    /// Title
                    HStack {
                        let title = String(format: viewModel.arcModel?.popupTitle ?? "", duration)
                        Text(title)
                            .font(cssModel.titleFont)
                            .foregroundStyle(cssModel.titleColor)
                            .frame(height: 32)
                        Spacer()
                        if type == .longSessionContinuous || type == .longSession24 {
                            lslCloseButton
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(cssModel.titleHeaderBgColor)
                    
                    /// Image & Description
                    ScrollView {
                        VStack {
                            VStack {
                                if let urlString = viewModel.arcModel?.popupImage,
                                   let url = URL(string: urlString) {
                                    KFImage.url(url)
                                        .placeholder {
                                            PlaceHolderImage()
                                        }
                                }
                            }
                            .padding(.top, 32)
                            VStack {
                                switch type {
                                case .gracePeriod, .playBreakStarted:
                                    HStack {
                                        let description = String(format: viewModel.arcModel?.popupDescription ?? "", duration)
                                        Text(description)
                                            .font(cssModel.descriptionFont)
                                            .foregroundStyle(cssModel.descriptionColor)
                                        Spacer()
                                    }
                                    .padding(.top, 12)
                                    .padding(.leading, 16)
                                    .padding(.bottom, 24)
                                    
                                    
                                case .longSessionContinuous, .longSession24, .longSession24Hard, .longSessionContinuousHard:
                                    if let popupDescription = viewModel.arcModel?.popupDescription,
                                       let accountName = EntainContext.user?.accountName {
                                        let description = String(format: popupDescription, accountName, duration)
                                        AttributedTextWebView(htmlContent: description,
                                                              height: $size,
                                                              fontName: cssModel.playBreakViewContentFontName,
                                                              fontSize: cssModel.playBreakViewContentFontSize,
                                                              textColor: cssModel.descriptionColor.uiColor
                                        )
                                        .frame(height: size)
                                        .padding()
                                    }
                                }
                                
                                /// Action Buttons
                                
                                switch type {
                                case .longSession24Hard, .longSessionContinuousHard:
                                    lslHardInterceptorViews
                                default:
                                    actionButtons
                                }
                            }
                        }
                    } // End of ScrollView
                    .frame(maxHeight: isofTypeHardInteceptor ? (geometry.size.height * 0.6) : .infinity)
                    .fixedSize(horizontal: false, vertical: true)
                    .scrollingDisabled(!(self.isofTypeHardInteceptor))
                    
                    /// Close Button only when type is `Long Session 24 Hard` or `Long Session Continuous Hard`
                    if type == .longSession24Hard || type == .longSessionContinuousHard {
                        closeButton()
                            .padding(16)
                    }
                    
                }
                .background(cssModel.contentViewBgColor)
                .frame(width: UIDevice.isIPad() ? geometry.frame(in: .global).width * 0.5 : geometry.size.width * 0.90)
            } // End Of ZStack
        } // End of Geometry Reader
        .onAppear {
            self.trackEvent(.load)
        }
    }

    
    
    
    var actionButtons : some View {
        HStack(spacing: 16) {
            Spacer()
            moreInfoButton
            okButton
                .padding(.trailing, 12)
        }
        .padding(.bottom, 12)
    }
    
    //MARK: - Action Buttons
    
    var moreInfoButton: some View {
        HapticsButton {
            let fillColor = (self.type == .longSession24 || self.type == .longSessionContinuous) ? Color.clear : cssModel.moreInfoButtonTextColor
            let texColor = cssModel.moreInfoButtonTextColor
            Text(viewModel.arcModel?.popupMoreInfo ?? "")
                .font(cssModel.moreInfoButtonTextFont)
                .foregroundStyle(texColor)
                .overlay(
                    Rectangle()
                        .fill(fillColor)
                        .frame(height: 1)
                    ,alignment: .bottom
                )
        } action: {
            if type == .longSession24 || type == .longSessionContinuous {
                clickAction?(.notNow)
            } else {
                clickAction?(.contact)
                EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .regulatoryItem(viewModel.arcModel?.nativeActionCategory ?? 0, viewModel.arcModel?.moreInfoLink ?? ""), buttonType: nil)
            }
            self.trackEvent(.moreInfoButtonClick)
        }
    }
    
    var okButton: some View {
        HapticsButton {
            Text(viewModel.arcModel?.popupOk ?? "")
                .font(cssModel.okButtonTextFont)
                .foregroundStyle(cssModel.okButtonTextColor)
                .padding(.horizontal, 24)
                .padding(.vertical, 8)
                .background {
                    RoundedRectangle(cornerRadius: cssModel.okButtonCornerRadius)
                        .fill(cssModel.okButtonBgColor)
                }
        } action: {
            (type == .longSession24 || type == .longSessionContinuous) ? clickAction?(.takeABreak) : clickAction?(.dismiss)
            self.trackEvent(.okButtonClick)
        }
    }
    
    var lslCloseButton : some View {
        HapticsButton {
            if let closeIcon = UIImage(
                named: kCloseWhite,
                in: kEpcotBundle,
                compatibleWith: nil
            ) {
                Image(uiImage: closeIcon)
                    .renderingMode(.template)
                    .foregroundColor(cssModel.lslCloseButtonColor)
                    .frame(width: 32, height: 32)
            }
        } action: {
            clickAction?(.notNow)
            self.trackEvent(.closeButtonClick)
        }
    }
    
}

//MARK: - LSL 24 Hard & LSL Continuous Hard Views

extension PlayBreakView {
    
    var lslHardInterceptorViews : some View {
        VStack(alignment: .leading) {
            HapticsButton {
                Text(viewModel.arcModel?.popupMoreInfo ?? "")
                    .font(cssModel.hardInterceptorMoreInfoButtonTextFont)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(cssModel.hardInterceptorMoreInfoButtonBgColor)
                    .foregroundColor(cssModel.hardInterceptorMoreInfoButtonTextColor)
                    .cornerRadius(10)
                    .frame(height: 32)
            } action:  {
                clickAction?(.contact)
                self.trackEvent(.moreInfoButtonClick)
                EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .regulatoryItem(viewModel.arcModel?.nativeActionCategory ?? 0, viewModel.arcModel?.moreInfoLink ?? ""), buttonType: nil)
            }
            
            AttributedTextWebView(htmlContent: viewModel.arcModel?.contactus ?? "",
                                  height: $contactUsSize,
                                  fontName: cssModel.playBreakViewContentFontName,
                                  fontSize: cssModel.playBreakViewContentFontSize,
                                  textColor: cssModel.descriptionColor.uiColor
            )
            .frame(height: contactUsSize)
            .padding(.top, -8)
            .onTapGesture {
                clickAction?(.contact)
                self.trackEvent(.contactUsClick)
                if let url = viewModel.arcModel?.contactMail {
                    EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .regulatoryItem(viewModel.arcModel?.nativeActionCategory ?? 0, url), buttonType: nil)
                }
            }
            
            HStack(spacing: 0) {
                Text(viewModel.arcModel?.phone ?? "")
                    .font(cssModel.descriptionFont)
                    .foregroundStyle(cssModel.descriptionColor)
                if let number = viewModel.arcModel?.phoneNumber {
                    Text(number)
                        .font(cssModel.descriptionFont)
                        .foregroundStyle(cssModel.descriptionColor)
                        .onTapGesture {
                            clickAction?(.contact)
                            guard let number = URL(string: "tel://\(number)"), UIApplication.shared.canOpenURL(number)  else { return }
                            UIApplication.shared.open(number)
                        }
                }
                
                Spacer()
            }
            .background(UIColor.clear.swiftUIColor)
            
        }
        .padding(.horizontal, 16)
    }
    
    func closeButton() -> some View {
        HapticsButton {
            Text(viewModel.arcModel?.close ?? "")
                .font(cssModel.okButtonTextFont)
                .frame(maxWidth: .infinity)
                .padding()
                .background(cssModel.okButtonBgColor)
                .foregroundColor(cssModel.okButtonTextColor)
                .cornerRadius(cssModel.okButtonCornerRadius)
        } action: {
            clickAction?(.dismiss)
            self.trackEvent(.closeButtonClick)
        }
    }
    
    var isofTypeHardInteceptor: Bool {
        self.type == .longSession24Hard || self.type == .longSessionContinuousHard
    }
}
struct PlayBreakView_Previews: PreviewProvider {
    static var previews: some View {
        PlayBreakView(duration: "5 hours")
    }
}


class ARCRtmsViewModel : ObservableObject {
    @Published var arcModel: ARCRTMSContent?
}
