//
//  PlayBreakView + TrackEvents.swift
//  EpcotLobby
//
//  Created by Naresh Banavath on 27/05/24.
//

import Foundation
import TrackerClient
import Utility
//MARK: - TrackEvents
extension PlayBreakView {
    
    enum PlayBreakViewEvents{
        case load
        case okButtonClick
        case closeButtonClick
        case moreInfoButtonClick
        case contactUsClick
    }

    func trackEvent(_ event : PlayBreakViewEvents) {
        switch event {
            
            ///** VIEW LOADED**
        case .load:
            switch type {
            case .gracePeriod, .longSessionContinuous:
                self.trackEvent(
                    eventDetails : .play_break_about_begin_overlay,
                    eventAction  : .load,
                    eventPosition: .soft_interceptor,
                    eventLocation: .play_break_about_begin_overlay,
                    eventType    : .gambling_controls_play_breaks_load
                )
                //TODO: - need to include this
            case .playBreakStarted:
                self.trackEvent(
                    eventDetails : .play_break_has_started_overlay,
                    eventAction  : .load,
                    eventPosition: .soft_interceptor,
                    eventLocation: .play_break_has_started_overlay,
                    eventType    : .gambling_controls_play_breaks_load
                )
            case .longSessionContinuousHard :
                self.trackEvent(
                    eventDetails :  .in_play_hard_interceptor,
                    eventAction  :  .load,
                    eventLocation:  .hard_interceptor,
                    eventType    :  .gambling_controls_play_breaks_load
                )
            case .longSession24:
                self.trackEvent(
                    eventDetails :  .play_break_about_begin_overlay_24,
                    eventAction  :  .load,
                    eventPosition: .hard_interceptor,
                    eventLocation:  .play_break_about_begin_overlay_24,
                    eventType    :  .gambling_controls_play_breaks_load
                )
            case .longSession24Hard:
                self.trackEvent(
                    eventDetails :  .in_play_hard_interceptor,
                    eventAction  :  .load,
                    eventLocation:  .hard_interceptor_lsl24,
                    eventType    :  .gambling_controls_play_breaks_load
                )
            }
            
            /// **OK BUTTON CLICKED**
            
        case .okButtonClick:
            switch type {
            case .gracePeriod:
                self.trackEvent(
                    eventDetails : .ok,
                    eventAction  : .click,
                    eventPosition: .soft_interceptor,
                    eventLocation: .play_break_about_begin_overlay,
                    eventType    : .gambling_controls_play_breaks_clicks
                )
                //TODO : - need to update this.
            case .playBreakStarted:
                self.trackEvent(
                    eventDetails : .ok,
                    eventAction  : .click,
                    eventPosition: .soft_interceptor,
                    eventLocation: .play_break_has_started_overlay,
                    eventType    : .gambling_controls_play_breaks_clicks
                )
            case .longSessionContinuousHard:
                self.trackEvent(
                    eventDetails : .ok,
                    eventAction  : .click,
                    eventPosition: .hard_interceptor,
                    eventLocation: .play_break_about_begin_overlay,
                    eventType    : .gambling_controls_play_breaks_clicks
                )
            case .longSession24Hard:
                self.trackEvent(
                    eventDetails : .ok,
                    eventAction  : .click,
                    eventPosition: .hard_interceptor,
                    eventLocation: .play_break_about_begin_overlay_24,
                    eventType    : .gambling_controls_play_breaks_clicks
                )
                //TODO:
            case .longSessionContinuous, .longSession24:
                self.trackEvent(
                    eventDetails : .take_short_break,
                    eventAction  : .click,
                    eventPosition: .no_play_breaks_set,
                    eventLocation: .in_play_soft_interceptor,
                    eventType    : .gambling_controls_play_breaks_clicks
                )
            }
            
        ///**CLOSE BUTTON CLICKED**
            
        case .closeButtonClick:
            switch type {
            case .longSessionContinuous, .longSession24:
                trackEvent(
                    eventDetails : .close_x,
                    eventAction  : .close,
                    eventPosition: .no_play_breaks_set,
                    eventLocation: .in_play_soft_interceptor,
                    eventType    : .gambling_controls_play_breaks_close
                )
            case .longSessionContinuousHard :
                self.trackEvent(
                    eventDetails :  .close_x,
                    eventAction  :  .click,
                    eventLocation:  .hard_interceptor,
                    eventType    :  .gambling_controls_play_breaks_close
                )
            case .longSession24Hard:
                self.trackEvent(
                    eventDetails :  .close_x,
                    eventAction  :  .click,
                    eventLocation:  .hard_interceptor_lsl24,
                    eventType    :  .gambling_controls_play_breaks_close
                )
                
                
            default: break
            }
   
        ///**MORE INFO BUTTON CLICKED**
            
        case .moreInfoButtonClick:
            switch type {
            case .gracePeriod:
                self.trackEvent(
                    eventDetails : .more_info,
                    eventAction  : .click,
                    eventPosition: .soft_interceptor,
                    eventLocation: .play_break_about_begin_overlay,
                    eventType    : .gambling_controls_play_breaks_clicks
                )
                //TODO:
            case .longSessionContinuous, .longSession24:
                self.trackEvent(
                    eventDetails : .not_right_now,
                    eventAction  : .click,
                    eventPosition: .no_play_breaks_set,
                    eventLocation: .in_play_soft_interceptor,
                    eventType    : .gambling_controls_play_breaks_clicks
                )
                //TODO:
            case .playBreakStarted:
                self.trackEvent(
                    eventDetails : .more_info,
                    eventAction  : .click,
                    eventPosition: .soft_interceptor,
                    eventLocation: .play_break_has_started_overlay,
                    eventType    : .gambling_controls_play_breaks_clicks
                )
            case .longSessionContinuousHard :
                self.trackEvent(
                    eventDetails :  .more_info,
                    eventAction  :  .click,
                    eventLocation:  .hard_interceptor,
                    eventType    :  .gambling_controls_play_breaks_clicks
                )
            case .longSession24Hard :
                self.trackEvent(
                    eventDetails :  .more_info,
                    eventAction  :  .click,
                    eventLocation:  .hard_interceptor_lsl24,
                    eventType    :  .gambling_controls_play_breaks_clicks
                )
            }
        case .contactUsClick:
            switch type {
            case .longSessionContinuousHard:
                self.trackEvent(
                    eventDetails :  .contact_us,
                    eventAction  :  .click,
                    eventLocation:  .hard_interceptor,
                    eventType    :  .gambling_controls_play_breaks_clicks
                )
            case .longSession24Hard:
                self.trackEvent(
                    eventDetails :  .contact_us,
                    eventAction  :  .click,
                    eventLocation:  .hard_interceptor_lsl24,
                    eventType    :  .gambling_controls_play_breaks_clicks
                )

            default: break
                
            }
        }
    }
}

//MARK: - Core Tracking Methods
extension PlayBreakView {
    func trackEvent(
        eventDetails: EpcotEventDetails,
        eventAction: EpcotEventAction,
        eventPosition: EpcotEventPosition? = nil,
        eventLocation: EpcotEventLocation,
        eventType: EventType
    ) {
        
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent : EpcotEventCategory.gamblingControls.rawValue,
                                     actionEvent   : eventAction.rawValue,
                                     labelEvent    : EpcotEventLabel.time_management_play_breaks.rawValue,
                                     locationEvent : eventLocation.rawValue,
                                     eventDetails  : eventDetails.rawValue,
                                     positionEvent : eventPosition?.rawValue ?? "",
                                     productType   : EpcotEventProductType.casino.rawValue,
                                     userID        : EntainContext.user?.accountId ?? "",
                                     appInfo       : EpcotEventAppInfo.casinow.rawValue,
                                     screenName    : "lobby")
            let event = TrackerEvent(type: eventType, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
}
