//
//  PlayBreakViewCSSModel.swift
//  EpcotLobby
//
//  Created by Naresh Banavath on 08/04/24.
//

import Foundation
import Utility
import SwiftUI

struct PlayBreakViewCSSModel {
    
    init() {
}
    private var playBreakViewCSS: PlayBreakViewCSS {
        return EpcotLobbyManager.shared?.css.playBreakViewCSS ?? DefaultPlayBreakViewCSS()
    }

    /// - Background Colors
    
    var overlayBgColor: Color { /// Bg of whole container view
        Color(self.playBreakViewCSS.overlayBgColor ?? .white)
    }
    
    var contentViewBgColor : Color {
        Color(self.playBreakViewCSS.contentBgColor ?? .white)
    }
    
    var lslContentViewBGColor: Color {
        Color(self.playBreakViewCSS.lslContentViewBGColor ?? .white)
    }
    
    /// - titles & description

    var titleFont: Font {
        Font(playBreakViewCSS.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var titleColor: Color {
        Color(playBreakViewCSS.title?.color ?? .black)
    }
    
    var lslCloseButtonColor: Color {
        Color(playBreakViewCSS.lslCloseButtonColor ?? .white)
    }
    
    var titleHeaderBgColor : Color {
        Color(playBreakViewCSS.titleHeaderBgColor ?? .black)
    }
    
    var descriptionFont: Font {
        Font(playBreakViewCSS.description?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var descriptionUIFont: UIFont {
        playBreakViewCSS.description?.font ?? UIFont.systemFont(ofSize: 14)
    }
    
    var descriptionColor: Color {
        Color(playBreakViewCSS.description?.color ?? .black)
    }
    
    /// - Buttons

    var moreInfoButtonTextColor: Color {
        Color(self.playBreakViewCSS.moreInfoButton?.title?.color ?? .black)
    }
    
    var moreInfoButtonTextFont: Font {
        Font(playBreakViewCSS.moreInfoButton?.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var okButtonTextColor : Color {
        Color(self.playBreakViewCSS.okButton?.title?.color ?? .white)
    }
    
    var lslButtonTextColor: Color {
        Color(self.playBreakViewCSS.lslButtonTextColor ?? .white)
    }
    
    var okButtonTextFont : Font {
        Font(playBreakViewCSS.okButton?.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var okButtonBgColor : Color {
        Color(self.playBreakViewCSS.okButton?.normal ?? .white)
    }
    
    var okButtonCornerRadius : CGFloat {
        CGFloat(self.playBreakViewCSS.okButtonCornerRadius ?? 8.0)
    }
    
    var hardInterceptorMoreInfoButtonBgColor: Color {
        Color(self.playBreakViewCSS.hardInterceptorMoreInfo?.normal ?? .blue)
    }
    
    var hardInterceptorMoreInfoButtonTextColor: Color {
        Color(self.playBreakViewCSS.hardInterceptorMoreInfo?.title?.color ?? .black)
    }
    
    var hardInterceptorMoreInfoButtonTextFont: Font {
        Font(self.playBreakViewCSS.hardInterceptorMoreInfo?.title?.font ?? UIFont.systemFont(ofSize: 12))
    }
    
    var playBreakViewContentFontName: String {
        self.playBreakViewCSS.fontName ?? "PrimaryRegularFont"
    }
    
    var playBreakViewContentFontSize: CGFloat {
        self.playBreakViewCSS.fontSize ?? 14.0
    }
}

