//
//  EpcotLobbyViewController+FavoriteToast.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 04/04/23.
//

import UIKit
import SwiftUI

extension EpcotLobbyViewController {

    // MARK: - Setup Toast
    func setupFavoriteToastView(viewModel: FavoriteToastViewModel) {
        let viewCSS = EpcotLobbyManager.shared?.css.favoriteToasterViewCSS
        var css = DefaultFavoriteToasterViewCSS(css: viewCSS)
        guard self.toastFavoriteView == nil else { return }
        self.toastFavoriteView = FavoriteToasterView(viewModel: viewModel, css: css) {
            if let items = self.subNavigationItems?[.categories],
               let category = items.first(where: { $0.parameters?.id == kLmcFavourites }) {
                self.updateCategorySelection(with: category)
            }
            self.hideFavoriteToastView()
        }
        let favoriteToastViewController = UIHostingController(rootView: self.toastFavoriteView)
        if let toastView = favoriteToastViewController.view {
            let screenWidth = UIDevice.screenSize.width
            let width = UIDevice.isIPad() ? screenWidth * 0.5 : (screenWidth - 32)
            toastView.frame = CGRect(origin: .zero, size: CGSize(width: width, height: 64))
            toastView.layer.cornerRadius = css.viewCornerRadius
            toastView.layer.masksToBounds = false
            favoriteToastView.addSubview(toastView)
        }
        favoriteToastView.backgroundColor = .clear
        favoriteToastView.dropShadow(color: css.shadowColor,
                                     offSet: CGSize(width: 0, height: 4),
                                     shadowRadius: 5)
        view.bringSubviewToFront(favoriteToastView)
    }

    // MARK: - Display Toast
    func displayFavoriteToastView(state: FavouriteState) {
        guard self.searchController == nil, self.casinoSearchController == nil else { return }
        if let count = feedViewModel?.favouriteGames?.count {
            if count == 1, state == .selected {
                showFavoriteToastView()
            } else {
                hideFavoriteToastView()
            }
        }
    }
    
    private func showFavoriteToastView() {
        createTimer()
        favoriteToastViewBottom.constant = 22.0
        animateToastView()
    }

    @objc func hideFavoriteToastView() {
        destroyTimer()
        DispatchQueue.main.async {
            self.favoriteToastViewBottom.constant = -200.0
            self.animateToastView()
        }
    }
    
    private func animateToastView() {
        UIView.animate(withDuration: 0.2,
                       delay: 0,
                       options: .curveEaseIn) {
            self.view.layoutIfNeeded()
        }
    }

    // MARK: - Hide Toast on Delay
    private func createTimer() {
        let timeout = favoriteToastConfig?.favoriteToastTimeout ?? 5
        favoriteToastTimer = DispatchTimer(
            interval: TimeInterval(timeout),
            handler: hideFavoriteToastView
        )
    }

    private func destroyTimer() {
        favoriteToastTimer?.cancel()
    }
}
