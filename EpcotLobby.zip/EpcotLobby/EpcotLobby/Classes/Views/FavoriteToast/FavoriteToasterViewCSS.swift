//
//  FavoriteToasterViewCSS.swift
//  EpcotLobby
//
//  Created by Bandana Choudhury on 06/04/23.
//

import Foundation
import UIKit
import SwiftUI

struct DefaultFavoriteToasterViewCSS {
    
    let backgroundColor : UIColor
    let viewCornerRadius : CGFloat
    let shadowColor: UIColor
    let titleColor: UIColor
    let titleFont: UIFont
    let titleAttributedColor: UIColor
    let titleAttributedFont: UIFont
    let seeBtnFont: Font
    let seeBtnTitleColor: Color
    let seeBtnBackgroundColor: UIColor
    
    init(css: FavoriteToasterViewCSS?) {
        backgroundColor = css?.backgroundColor ?? .hexStringToUIColor(hex: "333333")
        viewCornerRadius = css?.viewCornerRadius ?? 16
        shadowColor = css?.shadowColor ?? UIColor(red: 0/255, green: 0/255, blue: 0/255, alpha: 0.12)
        titleColor = css?.title?.color ?? .hexStringToUIColor(hex: "C1C1C1")
        titleFont = css?.title?.font ?? .systemFont(ofSize: 16, weight: .bold)
        titleAttributedColor = css?.titleAttributed?.color ?? .hexStringToUIColor(hex: "FFFFFF")
        titleAttributedFont = css?.titleAttributed?.font ?? .systemFont(ofSize: 16, weight: .bold)
        seeBtnFont = Font(css?.seeBtn?.title?.font ?? .systemFont(ofSize: 16, weight: .bold)) ?? .subheadline
        seeBtnTitleColor = Color(css?.seeBtn?.title?.color ?? .hexStringToUIColor(hex: "C1C1C1"))
        seeBtnBackgroundColor = css?.seeBtn?.normal ?? .clear
    }
}
