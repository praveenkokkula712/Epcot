//
//  FavoriteToasterView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 03/04/23.
//

import SwiftUI
import Kingfisher
import Utility

struct FavoriteToasterView: View {
    @StateObject var viewModel = FavoriteToastViewModel()
    @State var size: CGSize = .zero
    var css: DefaultFavoriteToasterViewCSS
    var onSeeAllButtonTap: () -> Void
   
    var body: some View {
        GeometryReader { proxy in
            let isTruncated = isGameTextTruncated(
                gameName: viewModel.name,
                gameContent: viewModel.message,
                width: proxy.size.width
            )
            ZStack {
                RoundedRectangle(cornerRadius: css.viewCornerRadius)
                    .fill(Color(css.backgroundColor))
                HStack {
                    KFImage.url(viewModel.url)
                        .placeholder {
                            PlaceHolderImage()
                        }
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 48, height: 48)
                        .cornerRadius(16)
                        .padding(.trailing, 12)
                        .padding(.leading, 8)
                        .shadow(
                            color: Color(css.shadowColor),
                            radius: css.viewCornerRadius, x: 0, y: 0
                        )
                    Group {
                        (isTruncated ? Text("\(viewModel.name.prefix(8))" + "...") : Text(viewModel.name))
                            .font(Font(css.titleAttributedFont))
                            .foregroundColor(Color(css.titleAttributedColor))
                        +
                        Text(" \(viewModel.message)")
                            .font(Font(css.titleFont))
                            .foregroundColor(Color(css.titleColor))
                    }
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                    .padding([.trailing, .vertical], 8)
                    .saveSize(in: $size)
                    Spacer()
                    if viewModel.isCTAEnabled {
                        Button(action: onSeeAllButtonTap) {
                            Text(Localize.seeAll)
                                .font(css.seeBtnFont)
                                .textCase(.uppercase)
                                .foregroundColor(css.seeBtnTitleColor)
                        }
                        .padding(.trailing, 16)
                    }
                }
            }
            .frame(height: 64)
        }
    }
    
    func isGameTextTruncated(gameName: String, gameContent: String, width: CGFloat) -> Bool {
        let message = NSMutableAttributedString(string: "\(gameName) ")
        message.addAttributes([.font: css.titleFont],
                              range: NSMakeRange(0, message.length))
        let contentAttributedString = NSAttributedString(string: gameContent,
                                                         attributes: [.font: css.titleAttributedFont])
        message.append(contentAttributedString)
        let remainWidth: CGFloat = viewModel.isCTAEnabled ? 137 : 80
        let height = message.height(constraintedWidth: width - 32 - remainWidth)
        return height > 45
    }
}

struct FavoriteToasterView_Previews: PreviewProvider {
    static var previews: some View {
        FavoriteToasterView(css: DefaultFavoriteToasterViewCSS(css: nil)) {}
    }
}
