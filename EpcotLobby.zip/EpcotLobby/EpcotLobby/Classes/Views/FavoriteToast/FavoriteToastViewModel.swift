//
//  FavoriteToastViewModel.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 04/04/23.
//

import Foundation

class FavoriteToastViewModel: ObservableObject {
    @Published var name = ""
    @Published var message = ""
    @Published var url: URL?
    @Published var isCTAEnabled = true

    func update(gameInfo: ImmersiveGameInfo? = nil, enableCTA: Bool = true) {
        name = gameInfo?.gameInfo.gameMetadata.name ?? ""
        message = Localize.favoriteToastMessage.isEmpty ? "was added to your favourite games" : Localize.favoriteToastMessage
        url = URL(string: gameInfo?.imagePath ?? "")
        isCTAEnabled = enableCTA
    }
}
