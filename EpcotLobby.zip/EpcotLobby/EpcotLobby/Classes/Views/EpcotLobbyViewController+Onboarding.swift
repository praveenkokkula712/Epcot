//
//  EpcotLobbyViewController+Onboarding.swift
//  EpcotLobby
//
//  Created by Rajani Bhimanadham on 24/04/23.
//
import SwiftUI
import TrackerClient
import Utility

extension EpcotLobbyViewController {
    
    var isSeeAllVisibile: Bool {
        self.immersiveGamesCollectionViewController?.scrollToIndex(isScrollNeeded: false).0 ?? false
    }
    
    var isJacpotFusionInfoAvailable: Bool {
        self.immersiveGamesCollectionViewController?.scrollToIndex(of:.jackpotFusionInfo, isScrollNeeded: false).0 ?? false
    }
    
    func showOnBoardingWelcomeScreenIfNeeded() {
        guard let userJourneys = UserOnboardingViewModel.shared?.newUserOnboardingJourneys, userJourneys.enableNewUserJourney else { return }
        
        
        ///chcek whether is any webview is presented
        guard let isWebViewVisible = (EpcotLobbyManager.shared?.datasource?.isWebViewVisisble), !isWebViewVisible else {
            EpcotLobbyAccessor.addObserver(observer: self, selector: #selector(didClosewebView), notification: .didClosedWebView)
            return
        }
        EpcotLobbyAccessor.removeObserver(observer: self, notification: .didClosedWebView)
        /// check userJourneyWelcomeAction whether user clicked on getStarted or skip or close, if yes then show close or skip onboarding journeys
        let userAction = UserDefaults.userJourneyWelcomeAction
        if userAction != 0 {
            UserOnboardingViewModel.shared?.setupData(isSeeAllAvailable: isSeeAllVisibile, isJacpotFusionInfoAvailable: isJacpotFusionInfoAvailable)
            return
        }
        /// check user logged in count to show onbording journey after clicking on getstarted, skip, and close
        let userLoggedInCount = UserDefaults.userLoggedInCount
        if userAction == 0 || userLoggedInCount == 1 || (userLoggedInCount % userJourneys.showAfterNumberofLogins == 0) {
            guard welcomeScreen == nil else { return }
            welcomeScreen = UIHostingController(rootView: UserOnboardingWelcomeView(clickAction: { [weak self] action in
                guard let self = self else { return }
                let presenter = AlertPresenter(vc: self.welcomeScreen ?? UIViewController())
                AlertCoordinator.removeView(presenter) {
                    var eventDetails: EpcotEventDetails?
                    switch action {
                    case .started:
                        UserDefaults.userJourneyWelcomeAction = 1
                        UserOnboardingViewModel.shared?.setupData(isSeeAllAvailable: self.isSeeAllVisibile, isJacpotFusionInfoAvailable: self.isJacpotFusionInfoAvailable)
                        eventDetails = .get_started
                    case .skip:
                        UserDefaults.userJourneyWelcomeAction = 2
                        eventDetails = .skip_for_now
                    case .close:
                        UserDefaults.userJourneyWelcomeAction = 3
                        eventDetails = .close
                    default: break
                    }
                    if let eventDetails {
                        self.trackEventsForWelcomeScreen(eventDetails: eventDetails.rawValue)
                    }}
            }))
            guard let topVC = EpcotLobbyManager.shared?.delegate?.lobbyViewController ??  UIApplication.mainWindow.rootViewController else { return }
            welcomeScreen?.view.frame = topVC.view.frame ?? self.view.frame
            welcomeScreen?.view.backgroundColor = UIColor.clear
            welcomeScreen?.modalPresentationStyle = .overFullScreen
            welcomeScreen?.modalPresentationCapturesStatusBarAppearance = true
            if let welcomeScreen = welcomeScreen {
                UserDefaults.isJourneyClosed = false
                UserOnboardingViewModel.shared?.index = -1
                let presenter = AlertPresenter(vc: welcomeScreen)
                AlertCoordinator.showView(presenter)
                UserOnboardingViewModel.shared?.hidePopTipViewIfAny()
                self.trackEventsForWelcomeScreen(eventDetails: GtmLogConstants.GeneralConstants.notApplicable.rawValue,
                                                 isLoad: true)
            }
        }
    }
    
    @objc func didClosewebView() {
        self.presentOverLays()
    }
}

extension EpcotLobbyViewController: UserOnboardingProtocol {
    func subscribeTo(subject: EpcotLobby.UserOnboardingPassthroughSubject) {
        pagingInfoToken = subject
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: { model in
                self.bottomSearchContainerView.removeRippleAnimation()
                guard !(EpcotLobbyManager.shared?.datasource?.isWebViewVisisble ?? false) else {
                    return
                }
                switch model.type {
                case .search:
                    let frame = self.bottomSearchContainerView.globalFrameFromLobbyView
                    let result = UserOnboardingViewModel.shared?.show(with: frame,
                                                         model: model) ?? false
                    if result {
                        let rippleEfffectColor = EpcotLobbyManager.shared?.css.onboardingViewCSS?.journeyViewCSS.overlayBorderColor ?? UIColor.hexStringToUIColor(hex: "#FFCC00")
                        let cornerRadius = self.bottomSearchContainerView.layer.cornerRadius
                        self.bottomSearchContainerView.addRippleAnimation(color: rippleEfffectColor,
                                                                          cornerRadius: cornerRadius)
                    }
                case .seeAll:
                    if self.immersiveGamesCollectionViewController?.isSeeAllViewAvailableForOnboarding ?? false {
                        var isSeeAllIndexAvailable = self.immersiveGamesCollectionViewController?.scrollToIndex()
                        let isSeeAllAvailable = isSeeAllIndexAvailable?.0 ?? false
                        let seeAllIndex = isSeeAllIndexAvailable?.1 ?? 0
                        let queueSleepTime =  isSeeAllAvailable ? 0.0 : (0.5 * Double(seeAllIndex))
                        DispatchQueue.main.asyncAfter(deadline: .now() + queueSleepTime) {
                            if let frame = self.immersiveGamesCollectionViewController?.onboardingSeeAllFrame {
                                UserOnboardingViewModel.shared?.show(with: frame,
                                                                     model: model)
                            }
                        }
                    }
                case .jackpotFusionInfo:
                    if self.immersiveGamesCollectionViewController?.isJackpotFusionInfoAvailable ?? false {
                        var isjackpotFusionIndexAvailable = self.immersiveGamesCollectionViewController?.scrollToIndex(of: .jackpotFusionInfo)
                        let isjackpotFusionAvailable = isjackpotFusionIndexAvailable?.0 ?? false
                        let jackpotFusionIndex = isjackpotFusionIndexAvailable?.1 ?? 0
                        let queueSleepTime =  isjackpotFusionAvailable ? 0.0 : (0.5 * Double(jackpotFusionIndex))
                        DispatchQueue.main.asyncAfter(deadline: .now() + queueSleepTime) {
                            if let frame = self.immersiveGamesCollectionViewController?.onboardingJackpotFusionInfoFramme {
                                UserOnboardingViewModel.shared?.show(with: frame,
                                                                     model: model)
                            }
                        }
                    }
                case .category:
                    let frame = self.categoryContentView.globalFrameFromLobbyView
                    UserOnboardingViewModel.shared?.show(with: frame,
                                                         model: model)
                default: break
                }
            })
    }
}

extension EpcotLobbyViewController {
    var onboardingSearchController: UIViewController? {
        self.casinoSearchController
    }
    
    var isOnboardingSeeAllViewAvailable: Bool {
        self.immersiveGamesCollectionViewController?.isSeeAllViewAvailableForOnboarding ?? false
    }
    
    var onboardingSeeMoreViewController: UIViewController? {
        self.immersiveGamesCollectionViewController?.onboardingSeeMoreViewController
    }
}

extension EpcotLobbyAccessor:Notifier {
    
    public enum Notification: String {
        case didClosedWebView
    }
}
