//
//  EpcotLobbyViewController+PlayBreak.swift
//  ConfigModule
//
//  Created by Praveen Kokkula on 08/04/24.
//

import Foundation
import SwiftUI
import Utility
import CasinoAPI

extension EpcotLobbyViewController {
    
    func removePlaybreakIfNeeded() {
        if playBreakScreen != nil {
            let presenter = AlertPresenter(vc: self.playBreakScreen ?? UIViewController())
            AlertCoordinator.removeView(presenter)
            self.playBreakScreen = nil
        }
    }
    
    func showPlayBreakView(with type: PlayBreakType, duration: String, completion: ((PlaybreakAction) -> Void)? = nil) {
        self.removePlaybreakIfNeeded()
        
        let viewModel = ARCRtmsViewModel()
        switch type {
        case .gracePeriod:
            viewModel.arcModel = POSAPI.shared?.arcRtmsGracePeriod
        case .playBreakStarted:
            viewModel.arcModel = POSAPI.shared?.arcRtmsPlayBreak
        case .longSessionContinuous:
            viewModel.arcModel = POSAPI.shared?.arcRtmsLSLPlayBreak
        case .longSession24:
            viewModel.arcModel = POSAPI.shared?.arcRtmsLSL24T1PlayBreak
        case .longSession24Hard:
            viewModel.arcModel = POSAPI.shared?.arcRtmsLSL24PlayBreak
        case .longSessionContinuousHard:
            viewModel.arcModel = POSAPI.shared?.arcRtmsLSLContinuousPlayBreak
        }
        
        playBreakScreen = UIHostingController(rootView: PlayBreakView(viewModel: viewModel, duration: duration, type: type, clickAction: { action in
            let presenter = AlertPresenter(vc: self.playBreakScreen ?? UIViewController())
            AlertCoordinator.removeView(presenter)
            completion?(action)
            self.playBreakScreen = nil
        }))
        guard let topVC = EpcotLobbyManager.shared?.delegate?.lobbyViewController ?? UIApplication.shared.keyWindow?.rootViewController else { return }
        playBreakScreen?.view.frame = topVC.view.frame ?? self.view.frame
        playBreakScreen?.view.backgroundColor = UIColor.clear
        playBreakScreen?.modalPresentationStyle = .overFullScreen
        playBreakScreen?.modalPresentationCapturesStatusBarAppearance = true
        if let playBreakScreen {
            let presenter = AlertPresenter(vc: playBreakScreen)
            AlertCoordinator.showView(presenter)
        }
    }
}
