//
//  EngagementToolsID.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 26/08/24.
//

import Foundation

struct EngagementToolsID {
    
    private init() { }

    static let PAGE_CONTROL = "Engagement_Tools_Indicator"

    static let FREE_TAG = "Engagement_Tools_Free_Tag"
    static let TITLE = "Engagement_Tools_Title"
    static let OFFER_EXPIRY = "Engagement_Tools_Spin_Expiry"
    static let CTA = "Engagement_Tools_CTA_Button"
    static let BACKGROUND_IMAGE = "Engagement_Tools_Background_Image"
}
