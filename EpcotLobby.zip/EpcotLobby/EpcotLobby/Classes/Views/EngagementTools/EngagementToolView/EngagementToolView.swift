//
//  EngagementToolView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 26/08/24.
//

import SwiftUI
import Kingfisher
import Utility

struct EngagementToolView: View {
    
    // MARK: Properties
    @ObservedObject private var viewModel: EngagementToolViewModel
    private let styles = EngagementToolViewCSS()
    
    // MARK: Init
    init(viewModel: EngagementToolViewModel) {
        self.viewModel = viewModel
    }
    
    // MARK: Body
    var body: some View {
        HStack(spacing: 0.0) {
            VStack(alignment: .leading, spacing: 0.0) {
                if !viewModel.isFreeSpin {
                    // FREE BADGE
                    HStack(alignment: .center, spacing: 4.0) {
                        Text(viewModel.freeBadgeTitle)
                            .font(styles.freeBadgeFont)
                            .foregroundColor(styles.freeBadgeColor)
                    }
                    .padding(.horizontal, 10.0)
                    .padding(.vertical, 5.0)
                    .background(styles.freeBadgeBackgroundColor)
                    .cornerRadius(styles.freeBadgeCornerRadius)
                    .accessibilityIdentifier(EngagementToolsID.FREE_TAG)
                    .allowsHitTesting(false)
                }

                // TITLE
                Text(viewModel.title)
                    .font(styles.titleFont)
                    .foregroundColor(styles.titleColor)
                    .padding(.top, viewModel.isFreeSpin ? 8.0 : 12.0)
                    .accessibilityIdentifier(EngagementToolsID.TITLE)
                    .allowsHitTesting(false)

                // EXPIRY
                Text(viewModel.offerExpiry)
                    .font(styles.expiryFont)
                    .foregroundColor(styles.expiryColor)
                    .frame(alignment: .topLeading)
                    .padding(.top, 4.0)
                    .accessibilityIdentifier(EngagementToolsID.OFFER_EXPIRY)
                    .allowsHitTesting(false)
            }
            
            Spacer(minLength: 16.0)

            Button {
                viewModel.onCTATap()
            } label: {
                ZStack {
                    KFImage(URL(string: viewModel.ctaImage))
                        .placeholder {
                            PlaceHolderImage()
                                .clipShape(Circle())
                                .frame(width: styles.ctaSize, height: styles.ctaSize)
                        }
                        .resizable()
                        .clipShape(Circle())
                        .frame(width: styles.ctaSize, height: styles.ctaSize)

                    // SPINS LEFT
                    Text(viewModel.availableSpins)
                        .font(styles.spinsLeftFont)
                        .foregroundColor(styles.spinsLeftColor)
                }
            }
            .allowsHitTesting(true)
            .accessibilityIdentifier(EngagementToolsID.CTA)
        }
        .frame(height: styles.height)
        .padding(styles.padding)
        .background(
            KFImage(URL(string: viewModel.backgroundImage))
                .placeholder {
                    PlaceHolderImage()
                        .frame(height: styles.height)
                        .cornerRadius(styles.cornerRadius)
                }
                .resizable()
                .frame(height: styles.height)
                .clipped()
                .overlay {
                    Rectangle()
                        .foregroundColor(.clear)
                        .background(gradientMask)
                }
                .cornerRadius(styles.cornerRadius)
                .allowsHitTesting(false)
                .accessibilityIdentifier(EngagementToolsID.BACKGROUND_IMAGE)
        )
        .cornerRadius(styles.cornerRadius)
    }
}

extension EngagementToolView {
    private var gradientMask: some ShapeStyle {
        LinearGradient(
            stops: [
                Gradient.Stop(
                    color: styles.backgroundGradientFirstColor,
                    location: 0.00
                ),
                Gradient.Stop(
                    color: styles.backgroundGradientSecondColor,
                    location: 1.00
                ),
            ],
            startPoint: UnitPoint(x: 0.96, y: 0.5),
            endPoint: UnitPoint(x: 0.28, y: 0.53)
        )
    }

    // TODO: Engagement Tools - Use for One-Arm Bandit Tool type
    private var largeGradientMask: some ShapeStyle {
        LinearGradient(
            stops: [
                Gradient.Stop(
                    color: styles.backgroundGradientFirstColor,
                    location: 0.00
                ),
                Gradient.Stop(
                    color: styles.backgroundGradientSecondColor,
                    location: 1.00
                ),
            ],
            startPoint: UnitPoint(x: 0.96, y: 0.5),
            endPoint: UnitPoint(x: -0.32, y: 0.5)
        )
    }
}

// MARK: - Preview
struct EngagementToolView_Previews: PreviewProvider {
    static var previews: some View {
        EngagementToolView(
            viewModel: EngagementToolViewModel(
                engagementTool: EngagementTool(
                    type: .freeSpins
                ),
                onEngagementToolTap: { }
            )
        )
    }
}

