//
//  EngagementToolViewModel.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 26/08/24.
//

import Foundation
import Combine
import CasinoAPI

class EngagementToolViewModel: ObservableObject {

    // MARK: Properties
    @Published private var spinExpiry = ""

    private let engagementTool: EngagementTool
    private let onEngagementToolTap: () -> Void
    private var promoExpiryTimer: FreeSpinsTimer?

    // MARK: Init
    init(
        engagementTool: EngagementTool,
        onEngagementToolTap: @escaping () -> Void
    ) {
        self.engagementTool = engagementTool
        self.onEngagementToolTap = onEngagementToolTap
        self.initializeFreeSpinTimer()
    }

    private func initializeFreeSpinTimer() {
        let timeStamp: Int?

        switch engagementTool.type {
        case .freeSpins:
            timeStamp = engagementTool.freeSpin?.expiryDate
        case .plinko, .pinBall:
            timeStamp = nil // TO BE SET
        case .spinTheWheel, .pickABox, .coinFlip, .oneArmedBandit:
            timeStamp = engagementTool.promoEngagementTool?.playerStatus?.expiryTime
        default:
            ETLogger.debug("🚧 New engagement tool is found in the site-core template! 🚧")
        }

        self.promoExpiryTimer = FreeSpinsTimer(
            expiryDate: timeStamp,
            onUpdate: { [weak self] expiry in
                guard let self else { return }
                DispatchQueue.main.async {
                    self.spinExpiry = expiry
                }
            }
        )
    }

    // MARK: View's data
    var isFreeSpin: Bool {
        engagementTool.type == .freeSpins
    }

    var freeBadgeTitle: String {
        engagementTool.toolData?.badgeTitle ?? ""
    }

    var title: String {
        switch engagementTool.type {
        case .freeSpins:
            var text = engagementTool.toolData?.contentText
            text = text?.replacingOccurrences(
                of: "$",
                with: "\n\(availableSpins)"
            )
            return text ?? ""
        default:
            return engagementTool.toolData?.title ?? ""
        }
    }

    var offerExpiry: String {
        guard let expiryText = engagementTool.toolData?.offerExpiringIn else {
            return ""
        }
        return expiryText + spinExpiry
    }

    var availableSpins: String {
        switch engagementTool.type {
        case .freeSpins:
            let count = engagementTool.freeSpin?.availableCount ?? 0
            return "\(count)"
        case .plinko, .pinBall:
            // TODO: Engagement Tools - Update this once API is given
            return "0"
        case .spinTheWheel, .pickABox, .coinFlip, .oneArmedBandit:
            let count = engagementTool.promoEngagementTool?.playerStatus?.availableSpins ?? 0
            return "\(count)"
        default:
            ETLogger.debug("🚧 New engagement tool is found in the site-core template! 🚧")
        }
    }

    var ctaImage: String {
        engagementTool.toolData?.buttonBackgroundImage ?? ""
    }

    var backgroundImage: String {
        engagementTool.toolData?.widgetBackgroundImage ?? ""
    }

    func onCTATap() {
        onEngagementToolTap()
    }
}
