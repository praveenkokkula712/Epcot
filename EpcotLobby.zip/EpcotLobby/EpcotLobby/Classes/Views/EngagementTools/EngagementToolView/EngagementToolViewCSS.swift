//
//  EngagementToolViewCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 26/08/24.
//

import Foundation
import SwiftUI
import Utility

struct EngagementToolViewCSS {
    
    // MARK: Properties
    let freeBadgeFont: Font
    let freeBadgeColor: Color
    let freeBadgeBackgroundColor: Color
    let freeBadgeCornerRadius: CGFloat
    let titleFont: Font
    let titleColor: Color
    let expiryFont: Font
    let expiryColor: Color
    let spinsLeftFont: Font
    let spinsLeftColor: Color
    let backgroundGradientFirstColor: Color
    let backgroundGradientSecondColor: Color
    let ctaSize: CGFloat
    let height: CGFloat
    let cornerRadius: CGFloat
    let padding: CGFloat

    // MARK: Init
    init(engagementToolsCSS: EngagementToolsCSS? = nil) {
        let css = engagementToolsCSS ?? Self.lobbyCSS?.engagementToolsCSS
        self.freeBadgeFont = Font(css?.freeBadgeText?.font ?? Self.freeBadgeFont)
        self.freeBadgeColor = Color(css?.freeBadgeText?.color ?? Self.freeBadgeColor)
        self.freeBadgeBackgroundColor = Color(css?.freeBadgeBackgroundColor ?? Self.freeBadgeBackgroundColor)
        self.freeBadgeCornerRadius = css?.freeBadgeCornerRadius ?? Self.freeBadgeCornerRadius
        self.titleFont = Font(css?.titleText?.font ?? Self.titleFont)
        self.titleColor = Color(css?.titleText?.color ?? Self.titleColor)
        self.expiryFont = Font(css?.expiryText?.font ?? Self.expiryFont)
        self.expiryColor = Color(css?.expiryText?.color ?? Self.expiryColor)
        self.spinsLeftFont = Font(css?.spinsLeftText?.font ?? Self.spinsLeftFont)
        self.spinsLeftColor = Color(css?.spinsLeftText?.color ?? Self.spinsLeftColor)
        self.backgroundGradientFirstColor = Color(css?.backgroundGradientFirstColor ?? Self.backgroundGradientFirstColor)
        self.backgroundGradientSecondColor = Color(css?.backgroundGradientSecondColor ?? Self.backgroundGradientSecondColor)
        self.ctaSize = css?.ctaSize ?? Self.ctaSize
        self.height = css?.height ?? Self.height
        self.cornerRadius = css?.cornerRadius ?? Self.cornerRadius
        self.padding = css?.padding ?? Self.padding
    }
}

// MARK: - Helper
extension EngagementToolViewCSS: LobbyStylable { }

extension EngagementToolViewCSS {
    private static var freeBadgeFont: UIFont {
        UIFont(name: "GT America", size: 11) ?? .systemFont(ofSize: 11, weight: .regular)
    }
    
    static var freeBadgeColor: UIColor {
        UIColor(hex: "#050505")
    }
    
    static var freeBadgeBackgroundColor: UIColor {
        UIColor(hex: "#C0A971")
    }

    static var freeBadgeCornerRadius: CGFloat { 6.0 }
    
    static var titleFont: UIFont {
        UIFont(name: "GT America Bold", size: 17) ??
            .systemFont(ofSize: 17, weight: .bold)
    }
    
    static var titleColor: UIColor {
        UIColor(hex: "#FFFFFF")
    }
    
    static var expiryFont: UIFont {
        UIFont(name: "GT America", size: 11) ??
            .systemFont(ofSize: 11, weight: .regular)
    }
    
    static var expiryColor: UIColor {
        UIColor(hex: "#C3C4C7")
    }

    static var spinsLeftFont: UIFont {
        UIFont(name: "GT America Bold", size: 17) ??
            .systemFont(ofSize: 17, weight: .bold)
    }

    static var spinsLeftColor: UIColor {
        UIColor(hex: "#FFFFFF")
    }
    
    static var backgroundGradientFirstColor: UIColor {
        UIColor(hex: "#050505").withAlphaComponent(0.7)
    }

    static var backgroundGradientSecondColor: UIColor {
        UIColor(hex: "#050505").withAlphaComponent(0.0)
    }
    
    static var ctaSize: CGFloat { 72.0 }
    
    static var height: CGFloat { 100.0 }

    static var cornerRadius: CGFloat { 14.0 }

    static var padding: CGFloat { 14.0 }
}
