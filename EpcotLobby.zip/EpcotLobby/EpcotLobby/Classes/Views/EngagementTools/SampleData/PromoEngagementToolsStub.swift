//
//  PromoEngagementToolsStub.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 17/09/24.
//

import Foundation
import CasinoAPI

struct PromoEngagementToolsStub {
    private(set) var promoEngagementTools = [PromoEngagementTool]()

    init() {
        promoEngagementTools = loadPromoEngagementTools(
            from: "PromoEngagementTools"
        ) ?? []
    }

    private func loadPromoEngagementTools<T: Codable>(from file: String) -> [T]? {
        if let url = kEpcotBundle.url(forResource: file, withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                let jsonData = try decoder.decode([T].self, from: data)
                return jsonData
            } catch {
                print("error:\(error)")
            }
        }
        return nil
    }
}
