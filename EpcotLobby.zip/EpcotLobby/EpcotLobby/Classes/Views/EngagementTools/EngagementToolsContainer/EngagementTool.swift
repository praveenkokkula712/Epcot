//
//  EngagementTool.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 26/08/24.
//

import Foundation
import CasinoAPI
import ConfigModule

struct EngagementTool: Identifiable {

    // MARK: Properties
    var id = UUID()
    var type: ToolType
    var freeSpin: FreeSpin?
    var promoEngagementTool: PromoEngagementTool?
    var toolData: LobbyEngagementTools?

    // MARK: Init
    init(
        type: ToolType,
        freeSpin: FreeSpin? = nil,
        promoEngagementTool: PromoEngagementTool? = nil,
        toolData: LobbyEngagementTools? = nil
    ) {
        self.type = type
        self.freeSpin = freeSpin
        self.promoEngagementTool = promoEngagementTool
        self.toolData = toolData
    }
}

extension EngagementTool: Hashable {
    static func == (lhs: EngagementTool, rhs: EngagementTool) -> Bool {
        return lhs.type == rhs.type
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(type)
    }
}

// MARK: - Engagement Tool Type

extension EngagementTool {
    
    // ToolType `case` must be equal to `key` of `EngagementToolsOrder` in DynaCon.
    enum ToolType: String {
        // P-API tools
        case plinko
        case pinBall
        
        // CRM Promo Tools
        case spinTheWheel
        case pickABox
        case coinFlip
        case oneArmedBandit

        // Prominent Free Spins
        case freeSpins

        var config: EngagementToolsOrder? {
            let posConfig = DynaconAPIConfiguration.shared?.posAppConfig
            let toolsOrder = posConfig?.odrAws?.engagementToolsOrderConfig?.engagementToolsOrder
            return toolsOrder?.first { $0.key == self.rawValue }
        }
    }
}
