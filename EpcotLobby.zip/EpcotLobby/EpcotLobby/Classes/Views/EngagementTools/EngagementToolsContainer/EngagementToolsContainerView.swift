//
//  EngagementToolsContainerView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 26/08/24.
//

import SwiftUI
import Utility

struct EngagementToolsContainerView: View {

    // MARK: Properties
    @ObservedObject private var container: EngagementToolsContainer
    @State private var index = 0
    private let pageControlStyles = FreeSpinsPageControlViewCSS()
    private let toolsStyles = EngagementToolViewCSS()

    // MARK: Init
    init(container: EngagementToolsContainer) {
        self.container = container
    }

    // MARK: Body
    var body: some View {
        VStack(alignment: .leading, spacing: 0.0) {
            
            // Engagement Tools UI
            if container.isScrollable {
                RightSidedCarouselView(
                    width: width,
                    spacing: 0,
                    items: container.engagementTools,
                    getScrollIndex: { self.index = $0 }
                ) { tool in
                    self.configureEngagementView(tool: tool)
                        .padding(.leading, viewLeading)
                }
                .frame(height: toolsStyles.height)

                // Page Control
                FreeSpinPageControl(
                    numberOfPages: container.pageCount,
                    currentPage: index,
                    dotsColor: UIColor(pageControlStyles.dotsColor),
                    selectedDotColor: UIColor(pageControlStyles.selectedDotColor)
                )
                .accessibilityValue("\(index + 1)/\(container.pageCount)")
                .accessibilityIdentifier(EngagementToolsID.PAGE_CONTROL)
            } else if let tool = container.engagementTools.first {
                self.configureEngagementView(tool: tool)
                    .padding(.horizontal, viewLeading)
                    .padding(.bottom, viewBottom)
            } else {
                EmptyView()
            }
        }
        .frame(height: height)
    }
    
    // MARK: Design Constants
    private var viewLeading: CGFloat { 12.0 }
    private var viewBottom: CGFloat { 24.0 }
    private var height: CGFloat { container.isScrollable ? 136.0 : 124.0 }
    private var width: CGFloat { 295.0 }
    
    // MARK: Helper
    // TODO: Engagement Tools - Handle the view configuration later.
    @ViewBuilder
    private func configureEngagementView(
        tool: EngagementTool
    ) -> some View {
        var gameNames = [String]()
        if let id = tool.freeSpin?.id {
            gameNames = self.container.gameNames(for: id)
        }
        let viewModel = EngagementToolViewModel(engagementTool: tool) {
            self.container.onSpinButtonTap(tool, gameNames)
        }
        return EngagementToolView(viewModel: viewModel)
    }
}

// MARK: - Preview
struct EngagementToolsContainerView_Previews: PreviewProvider {
    static let prominentFreeSpins = FreeSpinsStub().prominentFreeSpins
    static let freeSpinDetails = FreeSpinsStub().freeSpinDetails
    
    static var previews: some View {
        if let prominentFreeSpins, let freeSpinDetails {
            let container = EngagementToolsContainer(
                freeSpins: prominentFreeSpins,
                freeSpinsDetails: freeSpinDetails
            ) { _, _ in }
            EngagementToolsContainerView(container: container)
        }
        EmptyView()
    }
}
