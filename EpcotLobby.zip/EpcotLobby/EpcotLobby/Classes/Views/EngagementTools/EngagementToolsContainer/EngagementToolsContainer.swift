//
//  EngagementToolsContainer.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 26/08/24.
//

import Foundation
import CasinoAPI
import ConfigModule

class EngagementToolsContainer: ObservableObject {

    // MARK: Properties
    @Published var engagementTools = [EngagementTool]()
    private var freeSpins = [FreeSpin]()
    private let prominentFreeSpins: ProminentFreeSpins
    private let freeSpinsDetails: ProminentFreeSpinDetails
    let texts: FreeSpinsConfigurationTexts?
    let backgroundImage: String
    let ctaImage: String
    private var promoEngagementTools = [EngagementTool.ToolType: [PromoEngagementTool]]()
    private let toolsData: [LobbyEngagementTools]
    // TODO: Engagement Tools - pAPI array should be passed in init()
    let onSpinButtonTap: ((EngagementTool, [String]) -> Void) //tool, gameNames
    private var rewardGameNames = [Int: [String]]() // Reward ID: Game Variant Names

    // MARK: Init
    init(
        freeSpins: ProminentFreeSpins,
        freeSpinsDetails: ProminentFreeSpinDetails,
        texts: FreeSpinsConfigurationTexts? = nil,
        backgroundImage: String = "",
        ctaImage: String = "",
        promoEngagementTools: [EngagementTool.ToolType: [PromoEngagementTool]] = [:],
        toolsData: [LobbyEngagementTools] = [],
        onSpinButtonTap: @escaping (EngagementTool, [String]) -> Void
    ) {
        self.prominentFreeSpins = freeSpins
        self.freeSpinsDetails = freeSpinsDetails
        if let rewards = freeSpinsDetails.rewardDetails {
            self.freeSpins = rewards
        }
        self.texts = texts
        self.backgroundImage = backgroundImage
        self.ctaImage = ctaImage
        self.promoEngagementTools = promoEngagementTools
        self.toolsData = toolsData
        self.onSpinButtonTap = onSpinButtonTap
        self.makeEngagementTools()
        self.mapFreeSpinsGameNames()
    }

    // MARK: View's properties
    var pageCount: Int { engagementTools.count }

    var isScrollable: Bool { pageCount > 1 }

    private func makeEngagementTools() {
        let followOrderInDynaCon = toolOrderConfig?.followOrderInDynaCon ?? false

        if followOrderInDynaCon {
            let toolsOrder = toolOrderConfig?.engagementToolsOrder ?? []
            let toolTypes = toolsOrder.map {
                EngagementTool.ToolType(rawValue: $0.key ?? "")
            }
            createEngagementTools(with: toolTypes)
        } else {
            // TODO: Engagement Tools - Match the `promoType` key in the Sitecore with `EngagementTool.ToolType` raw value.
            // TODO: If the raw value is changed, we have to update it in DynaCon.
            let toolTypes = toolsData.map {
                EngagementTool.ToolType(rawValue: $0.key?.lowercased() ?? "")
            }
            createEngagementTools(with: toolTypes)
        }
    }
    
    private func createEngagementTools(with toolTypes: [EngagementTool.ToolType?]) {
        for case let toolType? in toolTypes {
            var tools = [EngagementTool]()
            
            // TODO: Engagement Tools - Match the `promoType` key in the Sitecore with `EngagementTool.ToolType` raw value.
            // TODO: If the raw value is changed, we have to update it in DynaCon.
            let toolData = toolsData.first {
                $0.key?.lowercased() == toolType.config?.sitecoreContentKey
            }

            switch toolType {
            case .freeSpins:
                tools = self.freeSpins.map {
                    EngagementTool(type: .freeSpins, freeSpin: $0, toolData: toolData)
                }
            case .plinko, .pinBall:
                // TODO: Engagement Tools - Generate Engagement Tools using the pAPI response.
                break
            case .spinTheWheel, .pickABox, .coinFlip, .oneArmedBandit:
                let promoTools = self.promoEngagementTools[toolType] ?? []
                tools = promoTools.map {
                    return EngagementTool(
                        type: toolType,
                        promoEngagementTool: $0,
                        toolData: toolData
                    )
                }
            default:
                ETLogger.debug("🚧 New engagement tool is found in the site-core template! 🚧")
            }
            engagementTools.append(contentsOf: tools)
        }
    }

    // MARK: Free spins associated games
    private func mapFreeSpinsGameNames() {
        for gameDetails in prominentFreeSpins.gameDetails ?? [:] {
            let gameName = gameDetails.key
            let rewardIDs = gameDetails.value.rewardIDS ?? []
            rewardIDs.forEach { id in
                var gameNames = rewardGameNames[id] ?? []
                gameNames.append(gameName)
                self.rewardGameNames[id] = gameNames
            }
        }
    }
    
    func gameNames(for rewardID: Int) -> [String] {
        rewardGameNames[rewardID] ?? []
    }
    
    // MARK: Helper
    private var toolOrderConfig: EngagementToolsOrderConfig? {
        DynaconAPIConfiguration.shared?.posAppConfig?
            .odrAws?.engagementToolsOrderConfig
    }
}
