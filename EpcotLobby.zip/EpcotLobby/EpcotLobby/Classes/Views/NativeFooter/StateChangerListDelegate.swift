//
//  StateChangerListDelegate.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 21/05/23.
//

import Foundation

public protocol StateChangerListDelegate: AnyObject {
    func updateStateView(selectedState: String?)
}
