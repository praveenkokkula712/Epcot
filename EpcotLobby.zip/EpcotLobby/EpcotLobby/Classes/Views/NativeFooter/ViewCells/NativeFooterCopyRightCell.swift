//
//  NativeFooterCopyRightCell.swift
//  Utility
//
//  Created by Gostu Bhargavi on 15/12/22.
//

import UIKit
import Combine
import CasinoAPI

class NativeFooterCopyRightCell: EpcotBaseCollectionViewCell {
    
    @IBOutlet private weak var copyRightLabel: UILabel!
    @IBOutlet private weak var timerLabel: UILabel!
    @IBOutlet private weak var versionLabel: UILabel!

    private var pagingInfoToken: AnyCancellable?

    var contentModel: FooterCopyRightModel? {
        didSet {
            self.updateContent(model: contentModel)
        }
    }
    
    // Initialization view from NIB
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = .clear
        self.updateCss()
    }
    
    private func updateCss() {
        let copyRightCSS = EpcotLobbyManager.shared?.css.nativeFooterViewCSS?.copyRight
        self.timerLabel?.textColor = copyRightCSS?.color ?? .lightGray
        self.timerLabel?.font = copyRightCSS?.font ?? UIFont.systemFont(ofSize: 14)
        self.timerLabel?.backgroundColor = copyRightCSS?.backgroundColor ?? .clear
        self.copyRightLabel?.textColor = copyRightCSS?.color ?? .lightGray
        self.copyRightLabel?.font = copyRightCSS?.font ?? UIFont.systemFont(ofSize: 14)
        self.copyRightLabel?.backgroundColor = copyRightCSS?.backgroundColor ?? .clear
        self.copyRightLabel?.lineBreakMode = .byWordWrapping
        self.versionLabel?.textColor = copyRightCSS?.color ?? .lightGray
        self.versionLabel?.font = copyRightCSS?.font ?? UIFont.systemFont(ofSize: 14)
        self.versionLabel?.backgroundColor = copyRightCSS?.backgroundColor ?? .clear
    }
    
    
    func subscribeTo(subject: PassthroughSubject<Void, Never>) {
        pagingInfoToken = subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                if self?.contentModel?.timerEnabled ?? false {
                    self?.updateTimer()
                }
            }
    }
    
    func updateTimer() {
        let timeFormatter = DateFormatter()
        timeFormatter.timeStyle = .medium
        self.timerLabel?.text = String(format: "current_time".localized, timeFormatter.string(from: Date()))
    }
    
    private func updateContent(model: FooterCopyRightModel?) {
        let timerEnabled = model?.timerEnabled ?? false
        self.timerLabel.isHidden = !timerEnabled
        if timerEnabled {
            self.updateTimer()
        }
        self.copyRightLabel.textAlignment = timerEnabled ? .right : .left
        let currentyear = Calendar.current.component(.year, from: Date())
        self.copyRightLabel?.text = model?.textContent?.replacingOccurrences(of: "{year}", with: "\(currentyear)")

        let displayVersion = model?.showVersion ?? false
        self.versionLabel.isHidden = !displayVersion
        if displayVersion {
            self.updateVersion(textAlignment: model?.versionTextAlignment ?? "1")
        }
    }
    
    //MARK: Displaying version
    private func updateVersion(textAlignment: String) {
        if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String,
           let buildVersion = Bundle.main.infoDictionary?["CFBundleVersion"] {
            self.versionLabel.text = "\(version) (\(buildVersion))"
            self.versionLabel.textAlignment = textAlignment.versionTextAlignment
        }
    }
}

extension String {
    var versionTextAlignment: NSTextAlignment {
        switch self {
        case "2": return .center
        case "3": return .right
        default: return .left
        }
    }
}
