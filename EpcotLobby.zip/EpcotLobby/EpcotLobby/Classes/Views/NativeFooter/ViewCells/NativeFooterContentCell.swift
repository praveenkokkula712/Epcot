//
//  NativeFooterContentCell.swift
//  CasinoAPI
//
//  Created by Gostu Bhargavi on 15/12/22.
//

import UIKit
import CasinoAPI
import Utility

class NativeFooterContentCell: EpcotBaseCollectionViewCell {
    
    @IBOutlet private weak var contentTextView: UITextView!
    
    var contentModel: FooterContentModel? {
        didSet {
            self.updateContent(model: contentModel)
        }
    }
    
    // Initialization view from NIB
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = .clear
        self.contentTextView.backgroundColor = .clear
    }
    
    private func updateContent(model: FooterContentModel?) {
        let contentCss = EpcotLobbyManager.shared?.css.nativeFooterViewCSS?.content
        let text = model?.textContent
        
        let attrs = [NSAttributedString.Key.foregroundColor: contentCss?.color ?? .lightGray,
                     NSAttributedString.Key.font : contentCss?.font ?? UIFont.systemFont(ofSize: 14)]
        
        if let text = model?.attributedContent {
            text.addAttributes(attrs, range: NSRange(location: 0, length: text.length))
            self.contentTextView?.attributedText = text
        }
    }
}

extension NativeFooterContentCell: UITextViewDelegate {
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        let nativeFooterItem = NativeFooterItem(type: .content,
                                                referenceLink: URL.absoluteString,
                                                nativeActionCategory: contentModel?.nativeActionCategory,
                                                selectedState: nil)
        EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .footer(nativeFooterItem), buttonType: nil)
        return false
    }
    
    func textViewDidChangeSelection(_ textView: UITextView) {
        if !NSEqualRanges(textView.selectedRange, NSMakeRange(0, 0)) {
            textView.selectedRange = NSMakeRange(0, 0)
        }
    }
}
