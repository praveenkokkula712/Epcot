//
//  NativeFooterLogoCell.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 13/12/22.
//

import UIKit
import CasinoAPI
import Utility

class NativeFooterLogoCell: EpcotBaseCollectionViewCell {
    
    @IBOutlet private weak var logoImageView: UIImageView!
    @IBOutlet private weak var imageViewWidth: NSLayoutConstraint!
    @IBOutlet private weak var imageViewHeight: NSLayoutConstraint!
    
    var contentModel: FooterLogoContentModel? {
        didSet {
            self.updateContent(model: contentModel)
        }
    }

    // Initialization view from NIB
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = .clear
    }
        
    private func updateContent(model: FooterLogoContentModel?) {
        guard let imgLink = model?.logoUrl, let imageURL = URL(string: imgLink)  else { return }
        self.logoImageView.kf.setImage(with: imageURL)
        let width = model?.size.width ?? 40
        self.imageViewWidth.constant = width == 0 ? 40 : width
        let height = model?.size.height ?? 40
        self.imageViewHeight.constant = height == 0 ? 40 : height
   }
    
}
