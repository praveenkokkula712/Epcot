//
//  NativeFooterBaseCell.swift
//  EpcotLobby
//
//  Created by Gostu Bhargavi on 07/12/22.
//

import UIKit
import CasinoAPI

class NativeFooterBaseCell: EpcotBaseCollectionViewCell {
    
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var containerView: UIView!

    var contentModel: FooterAboutUsModel? {
        didSet {
            self.updateContent(model: contentModel)
        }
    }
    
    var seoModel: FooterSeoLinksModel? {
        didSet {
            self.updateSeoContent(model: seoModel)
        }
    }
    
    // Initialization view from NIB
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = .clear
        self.updateCss()
    }
    
    private func updateCss() {
        let aboutUsCss = EpcotLobbyManager.shared?.css.nativeFooterViewCSS?.aboutUs
        self.titleLabel.font = aboutUsCss?.item?.font ?? UIFont.systemFont(ofSize: 16)
        self.titleLabel.textColor = aboutUsCss?.item?.color ?? .white
    }
    
    private func updateContent(model: FooterAboutUsModel?) {
        self.titleLabel.text = model?.title
    }
    
    private func updateSeoContent(model: FooterSeoLinksModel?) {
        self.titleLabel.text = model?.title
    }
}
