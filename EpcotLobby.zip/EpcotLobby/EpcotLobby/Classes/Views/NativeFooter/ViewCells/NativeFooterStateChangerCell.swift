//
//  NativeFooterStateChangerCell.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 20/12/22.
//

import UIKit
import Combine

protocol NativeFooterStateChangerDelegate: AnyObject {
    func openStateChangeView(with cell: NativeFooterStateChangerCell)
}

class NativeFooterStateChangerCell: UICollectionViewCell {
    
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var stateSelectionBtn: UIButton!
    @IBOutlet private weak var viewStateSelection: UIView!
    @IBOutlet private weak var iconStateSelection: UILabel!
    @IBOutlet private weak var loginDurationLabel: UILabel!
    
    @IBOutlet private weak var stateSelectionBtnCenterX: NSLayoutConstraint?
    
    weak var delegate: NativeFooterStateChangerDelegate?
    private var stateInfo: AnyCancellable?
    private var pagingInfoToken: AnyCancellable?
    
    private var loggedInTime: Date?
    var stateSwitcherModel: FooterStateSwitcherModel? {
        didSet {
            DispatchQueue.main.async { [weak self] in
                self?.updateUI(hideStateSwitcher: self?.stateSwitcherModel?.hideStateSwitcher ?? false,
                               hideTimer: self?.stateSwitcherModel?.hideTimer ?? true)
            }
        }
    }
    
    private var css: NativeFooterCSS? {
        return EpcotLobbyManager.shared?.css.nativeFooterViewCSS
    }
    
    var selectedState: String? {
        didSet {
            self.stateSelectionBtn?.setTitle(selectedState, for: .normal)
        }
    }
        
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.setupView()
        self.updateCss()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.pagingInfoToken?.cancel()
        self.pagingInfoToken = nil
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.viewStateSelection.getRoundedCorners(OfRadius: self.viewStateSelection.frame.size.height/2)
    }
    
    private func setupView() {
        let stateSelectionTapGestures = UITapGestureRecognizer(target: self, action: #selector(selectStateAction))
        self.viewStateSelection.addGestureRecognizer(stateSelectionTapGestures)
        
        self.loginDurationLabel.text = ""
    }
    
    private func updateCss() {
        self.backgroundColor = self.css?.seolinks?.backgroundColor
        
        self.titleLabel?.textColor = self.css?.stateView?.title?.color ?? .lightGray
        self.titleLabel?.text = "state_switch_title".localized
        self.titleLabel?.font = self.css?.seolinks?.header?.font ?? UIFont.boldSystemFont(ofSize: 18)
        
        self.stateSelectionBtn.setTitleColor(self.css?.stateView?.stateChangerBtn?.color ?? .lightGray, for: .normal)
        self.stateSelectionBtn?.titleLabel?.textColor = self.css?.stateView?.stateChangerBtn?.color ?? .lightGray
        self.stateSelectionBtn?.titleLabel?.font = self.css?.stateView?.stateChangerBtn?.font ?? UIFont.systemFont(ofSize: 14)
        
        self.iconStateSelection?.textColor = self.css?.stateView?.stateSwitcherDropDownColor ?? UIColor.hexStringToUIColor(hex: "#79BFFF")
        
        self.viewStateSelection?.layer.borderColor = self.css?.stateView?.stateChangeBtnBorderColor?.cgColor ?? UIColor.gray.cgColor
        self.viewStateSelection?.layer.borderWidth = 1
    }
}

extension NativeFooterStateChangerCell {
    func subscribeTo(subject: PassthroughSubject<Date?, Never>) {
        pagingInfoToken = subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] logInTime in
                self?.loggedInTime = logInTime
                self?.updateTimerLabel()
            }
    }
            
    @objc func selectStateAction() {
        if let button = self.stateSelectionBtn {
            let instantInteraction = InteractionType.overLay40.interaction
            self.viewStateSelection.tapAnimation(type: instantInteraction) {
                self.selectedStateAction(button)
            }
        }
    }
    
    @objc func selectedStateAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if sender.isSelected {
            self.delegate?.openStateChangeView(with: self)
        }
        self.updateSelectionIcon()
    }
        
    func updateStateChangeView(selected: Bool = false) {
        self.stateSelectionBtn?.isSelected = selected
        self.updateSelectionIcon()
    }
    
    private func updateSelectionIcon() {
        var iconName = (self.stateSelectionBtn?.isSelected ?? false) ? "icon-glyph_up" : "icon-glyph_down"
        if let icon = EpcotLobbyManager.shared?.datasource?.didRequestForIconVariant(with: iconName, fontSize: EpcotLobbyManager.shared?.css.footerDownArrowIconFontSize ?? 14.0) {
            self.iconStateSelection?.text = icon.icon
            self.iconStateSelection?.font = icon.font
            self.stateSelectionBtnCenterX?.constant = -icon.font.pointSize/2
        }
        let color: UIColor = self.stateSelectionBtn?.isSelected == true ? self.css?.stateView?.stateChangeBtnSelectedBackgroundColor ?? .clear : .clear
        self.viewStateSelection?.backgroundColor = color
    }
    
    private func updateUI(hideStateSwitcher: Bool,
                          hideTimer: Bool) {
        DispatchQueue.main.async { [weak self] in
            //StateSwitchView Configuration
            self?.titleLabel?.isHidden = hideStateSwitcher
            self?.viewStateSelection?.isHidden = hideStateSwitcher
            //TimerView Configuration
            self?.loginDurationLabel?.isHidden = hideTimer
        }
    }
}

extension NativeFooterStateChangerCell {

    private func updateTimerLabel() {
        let sessionTime = self.getLoginSessionTime().timeString
        self.setLoginText(text1: self.stateSwitcherModel?.timerTitle ?? "",
                          text2: "\(String(describing: sessionTime))")
    }
     
    private func getLoginSessionTime() -> Int {
        var timeInSeconds: Int = 0
        if let loggedTime = loggedInTime {
            timeInSeconds = Int(Date().timeIntervalSince(loggedTime))
        }
        return timeInSeconds
    }
    
    private func setLoginText(text1: String,
                              text2: String) {
        let attributedText = self.getAttributedString(string1: text1,
                                                      font1: self.css?.seolinks?.header?.font ?? UIFont.boldSystemFont(ofSize: 18),
                                                      color1: self.css?.footerTitleColor ?? UIColor.hexStringToUIColor(hex: "#FFFFFF"),
                                                      string2: text2,
                                                      font2: self.css?.seolinks?.header?.font ?? UIFont.systemFont(ofSize: 16),
                                                      color2: self.css?.footerTimerTextColor ?? UIColor.hexStringToUIColor(hex: "#FFFFFF"))
        self.loginDurationLabel?.attributedText = attributedText
    }
    
    private func getAttributedString(string1: String,
                                     font1: UIFont,
                                     color1: UIColor,
                                     string2: String,
                                     font2: UIFont,
                                     color2: UIColor) -> NSMutableAttributedString {
        
        let attributes1 = [NSAttributedString.Key.font: font1, NSAttributedString.Key.foregroundColor: color1]
        let atttributeString1 = NSMutableAttributedString.init(string: string1, attributes: attributes1)
        
        let attributes2 = [NSAttributedString.Key.font: font2, NSAttributedString.Key.foregroundColor: color2]
        let atttributeString2 = NSMutableAttributedString(string: string2, attributes: attributes2)
        atttributeString1.append(NSAttributedString(string: "\n"))
        atttributeString1.append(atttributeString2)
        
        return atttributeString1
    }
}

extension Int {
    var timeString: String {
        let hours = self / 3600
        let minutes = self / 60 % 60
        let seconds = self % 60
        
        if hours > 0 {
            return String(format:"%02i:%02i:%02i", hours, minutes, seconds)
        }
        else {
            return String(format:"%02i:%02i", minutes, seconds)
        }
    }
}

extension NativeFooterStateChangerCell {
    
    func subscribeTo(subject: PassthroughSubject<Bool, Never>) {
        stateInfo = subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] value in
                self?.updateStateChangeView(selected: value)
            }
    }
}
