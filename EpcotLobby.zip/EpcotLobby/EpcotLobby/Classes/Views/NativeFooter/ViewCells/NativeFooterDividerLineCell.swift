//
//  NativeFooterDividerLineCell.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 22/12/22.
//

import UIKit

class NativeFooterDividerLineCell: EpcotBaseCollectionViewCell {

    @IBOutlet private weak var labelLine: UILabel!

    private var css: NativeFooterCSS? {
        return EpcotLobbyManager.shared?.css.nativeFooterViewCSS
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.setUpCss()
    }

    private func setUpCss() {
        self.backgroundColor = self.css?.seolinks?.backgroundColor ?? .clear
        self.labelLine.backgroundColor = self.css?.lineColor ?? .clear
    }
}
