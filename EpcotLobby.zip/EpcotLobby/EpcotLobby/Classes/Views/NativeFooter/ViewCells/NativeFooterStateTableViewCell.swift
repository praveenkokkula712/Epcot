//
//  FooterStateTableViewCell.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 20/12/22.
//

import UIKit

class NativeFooterStateTableViewCell: UITableViewCell {
    
    enum Constants {
        static let nibName = "NativeFooterStateTableViewCell"
    }
    
    @IBOutlet private weak var viewState: UIView!
    @IBOutlet private weak var labelState: UILabel!
    @IBOutlet private weak var iconState: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.updateCss()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    private var css: NativeFooterCSS? {
        EpcotLobbyManager.shared?.css.nativeFooterViewCSS
    }
    
    private func updateCss() {
        self.labelState.textColor = self.css?.stateView?.stateListTitleColor ?? .black
        self.labelState.font = self.css?.seolinks?.item?.font ?? UIFont.systemFont(ofSize: 13)
        self.iconState.textColor = self.css?.stateView?.stateSwitcherRadioButtonColor ?? UIColor.hexStringToUIColor(hex: "#475EEC")
    }
    
    func setStateName(_ stateName: String, with selectedState: String?) {
        self.labelState.text = stateName
        let imageName = (stateName == selectedState) ? kStateIconSelected : kStateIconUnSelected
        if let iconName = EpcotLobbyManager.shared?.datasource?.didRequestForIconVariant(with: imageName, fontSize: EpcotLobbyManager.shared?.css.footerRadioButtonIconFontSize ?? 14.0) {
            self.iconState.text = iconName.icon
            self.iconState.font = iconName.font
        }
        self.viewState.backgroundColor = (stateName == selectedState) ? .clear : self.css?.stateView?.stateListBgColor
        self.viewState.getRoundedCorners(OfRadius: 4.0)
    }    
}
