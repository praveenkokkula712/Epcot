//
//  StateSwitchConfigs.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 21/05/23.
//

import Foundation

public struct StateSwitchConfigs {
    var selectedState: String?
    var states: [String]?
    var xPosition: CGFloat = 10
    var yPosition: CGFloat = 0
    var switcherPositionY: CGFloat = 0
    var listHeight: CGFloat = 0
    
    public init(selectedState: String? = nil,
                  states: [String]? = nil,
                  xPosition: CGFloat = 10,
                  yPosition: CGFloat = 0,
                  switcherPositionY: CGFloat = 0) {
        self.selectedState = selectedState
        self.states = states
        self.xPosition = xPosition
        self.yPosition = yPosition
        self.switcherPositionY = switcherPositionY
    }
}
