//
//  NativeFooterStateChangerViewController.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 19/05/23.
//

import UIKit

public class NativeFooterStateChangerViewController: EpcotBaseViewController {
    
    @IBOutlet weak var listTableView: UITableView!
    weak var delegate: StateChangerListDelegate?
    private var switcherConfigs: StateSwitchConfigs?
    public static let listViewWidth: CGFloat = 150
    
    private var currentOrientation = UIInterfaceOrientationMask.portrait
    
    public override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return currentOrientation
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.setupTableView()
    }

    public static func showOn(presentingController: UIViewController,
                              delegate: StateChangerListDelegate?,
                              configs: StateSwitchConfigs) {
        let controller = NativeFooterStateChangerViewController.loadFromNib()
        controller.modalPresentationStyle = .overFullScreen
        controller.modalPresentationCapturesStatusBarAppearance = true
        controller.delegate = delegate
        let orientation = UIDevice.currentOrientation
        controller.currentOrientation = orientation == .portrait ? UIInterfaceOrientationMask.portrait : UIInterfaceOrientationMask.landscape
        let count = configs.states?.count ?? 0
        var stateChangerHeight = (count)*(38+8) //rowheight, row spacing
        stateChangerHeight += 16 //top, bottom padding
        
        var yPos = configs.yPosition
        let stateChangerListHeight = CGFloat(stateChangerHeight ?? 0)
        if ((yPos+stateChangerListHeight) - presentingController.view.frame.size.height) > 0 {
            ///state switcher header height
            yPos = configs.switcherPositionY - stateChangerListHeight + 30
        }
        var switcherConfigs = StateSwitchConfigs()
        switcherConfigs.selectedState = configs.selectedState
        switcherConfigs.states = configs.states
        switcherConfigs.xPosition = configs.xPosition
        switcherConfigs.yPosition = yPos
        switcherConfigs.listHeight = CGFloat(stateChangerHeight)
        controller.switcherConfigs = switcherConfigs
        presentingController.present(controller, animated: false)
    }
    
    @IBAction func didTappedOutside(_ sender: Any) {
        self.listTableView.removeViewWithAnimation()
        self.delegate?.updateStateView(selectedState: nil)
        self.dismiss(animated: false)
    }
    
    private func setupTableView() {
        self.listTableView.registerNibCells(withCells: NativeFooterStateTableViewCell.Constants.nibName,
                                            bundle: Bundle(for: NativeFooterStateTableViewCell.self))
        self.listTableView.separatorStyle = .none
        self.listTableView.rowHeight = 38.0 + 8.0
        let header = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: 8))
        header.backgroundColor = .clear
        self.listTableView.tableHeaderView = header
        self.listTableView.getRoundedCorners(OfRadius: 6.0)
        self.listTableView.delegate = self
        self.listTableView.dataSource = self
        self.setupTableViewConstraints()
        self.listTableView.reloadData()
    }
    
    private func setupTableViewConstraints() {
        self.listTableView.translatesAutoresizingMaskIntoConstraints = false
        self.listTableView.topAnchor.constraint(equalTo: self.view.topAnchor,
                                                constant: switcherConfigs?.yPosition ?? 0).isActive = true
        self.listTableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor,
                                                    constant: switcherConfigs?.xPosition ?? 0).isActive = true
        self.listTableView.widthAnchor.constraint(equalToConstant: Self.listViewWidth).isActive = true
        self.listTableView.heightAnchor.constraint(equalToConstant: switcherConfigs?.listHeight ?? 100).isActive = true
    }
}

extension NativeFooterStateChangerViewController: UITableViewDataSource {
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.switcherConfigs?.states?.count ?? 0
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: NativeFooterStateTableViewCell.Constants.nibName) as? NativeFooterStateTableViewCell else {
            return UITableViewCell()
        }
        guard let _stateName = self.switcherConfigs?.states?[indexPath.row] else { return cell }
        cell.setStateName(_stateName, with: self.switcherConfigs?.selectedState)
        return cell
    }
}

extension NativeFooterStateChangerViewController: UITableViewDelegate {
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) {
            let instantInteraction = InteractionType.overLay40.interaction
            cell.tapAnimation(type: instantInteraction) {
                let stateSelected = self.switcherConfigs?.states?[indexPath.row]
                ETLogger.debug("Selected state \(String(describing: stateSelected))")
                
                self.delegate?.updateStateView(selectedState: stateSelected)
                self.listTableView.removeViewWithAnimation()
                self.dismiss(animated: false)
            }
        }
    }
    
}
