//
//  NativeFooterBaseReusableView.swift
//  AFNetworking
//
//  Created by Gostu Bhargavi on 16/12/22.
//

import Foundation

class NativeFooterBaseReusableView: EpcotBaseHeaderView {
    
    override func configureView() {
        let css = EpcotLobbyManager.shared?.css.nativeFooterViewCSS?.aboutUs
        self.titleLabel.textColor = css?.header?.color ?? .white
        self.titleLabel.font = css?.header?.font
    }
}
