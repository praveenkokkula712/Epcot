//
//  GamePremiereOverlay.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 24/04/24.
//

import SwiftUI
import Kingfisher
import CasinoAPI
import Utility
import GSPlayer
import ConfigModule
import TrackerClient
import SDWebImageSwiftUI

struct GamePremiereOverlay: View {
    
    @ObservedObject var viewModel: GamePremiereOverlayViewModel
    let gamePremiereCSS = GamePremiereViewCSS()
    @State private var showMoreInfo = false
    @State private var cleanUpPlayerView = false
    @State private var contentHeight: CGFloat = 0.0
    @State private var isVideoLoaded: Bool = false
    @State var size: CGSize = .zero
    
    var fullScreenAction : ((VideoPlayerView)->())?
    @State var playerView : VideoPlayerView = VideoPlayerView()
    
    var body: some View {
        
        ZStack(alignment: .top) {
            GeometryReader { geometry in
                
                if let gifUrl = viewModel.content?.overlayAnimationImage {
                    WebImage(url: URL(string: gifUrl), options: [.progressiveLoad, .highPriority])
                        .onFailure { _ in
                            KFImage(URL(string: gifUrl.replacingOccurrences(of: ".gif", with: ".jpg")))
                                .placeholder {
                                    PlaceHolderImage()
                                }
                                .resizable()
                                .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.animation)
                        }
                        .resizable()
                        .indicator(.activity)
                        .frame(width: geometry.size.width,
                               height: geometry.size.height)
                        .transition(.fade)
                        .scaledToFill()
                        .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.animation)
                }
                
                ScrollView(showsIndicators: false) {
                    
                    // Close Icon
                    HStack {
                        Spacer()
                        HapticsButton {
                            Image(uiImage: viewModel.closeImage)
                                .colorMultiply(gamePremiereCSS.closeIconColor)
                                .frame(width: 24, height: 24)
                        } action: {
                            self.cleanUpPlayerView = true
                            viewModel.cancelScheduledBlock()
                            viewModel.trackEvent(eventType: .game_premiere_click,
                                                 actionEvent: .click,
                                                 eventDetails: .game_premiere_animation_close)
                            viewModel.closeAction?()
                            viewModel.storePromoId()
                        }
                        .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.closeIcon)
                    }
                    .padding(.top, 69)
                    .padding(.bottom, 30)
                    .padding(.trailing, 23)
                    
                    if viewModel.showOverlay {
                        
                        VStack(spacing: 0) {
                            
                            // subTitle1
                            if let subTitle1 = viewModel.content?.subTitle1 {
                                Text(subTitle1)
                                    .font(gamePremiereCSS.subTitle1Font)
                                    .foregroundColor(gamePremiereCSS.subTitle1Color)
                                    .multilineTextAlignment(.center)
                                    .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.subTitleOne)
                            }
                            
                            // subtitle2
                            if let subTitle2 = viewModel.content?.subTitle2 {
                                Text(subTitle2)
                                    .font(gamePremiereCSS.subTitle2Font)
                                    .foregroundColor(gamePremiereCSS.subTitle2Color)
                                    .multilineTextAlignment(.center)
                                    .padding(.bottom, 32)
                                    .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.subTitleTwo)
                            }
                            
                            let borderWidth = 2 * gamePremiereCSS.borderWidth
                            let imageWidth = UIDevice.isIPad() ? (UIDevice.isLandscape ? (geometry.size.height * 0.5 - borderWidth) : (geometry.size.width * 0.5 - borderWidth)) : geometry.size.width - (46 + borderWidth)
                            
                            // it can be staticImage or promoVideo
                            PromoMediaView(viewModel: viewModel,
                                           width: imageWidth,
                                           cleanUpPlayerView: $cleanUpPlayerView,
                                           playerView: $playerView,
                                           fullScreenAction: fullScreenAction,
                                           isVideoLoaded: $isVideoLoaded
                            )
                            
                            // promotionalContent includes steps and buttons
                            promotionalContent
                            
                            if let moreInfoContent = viewModel.content?.moreInfoContent, let moreInfoText = viewModel.content?.moreInfoText, let lessInfoText = viewModel.content?.lessInfoText {
                                Divider()
                                    .background(gamePremiereCSS.dividerColor)
                                    .frame(height: 1)
                                
                                // moreInfoText and button
                                HStack {
                                    Text(showMoreInfo ? lessInfoText : moreInfoText)
                                        .font(gamePremiereCSS.moreInfoFont)
                                        .foregroundColor(gamePremiereCSS.moreInfoTextColor)
                                        .padding(.leading, 4)
                                        .accessibilityIdentifier(showMoreInfo ? GamePremiereAccessibilityIdentifiers.lessInfo :GamePremiereAccessibilityIdentifiers.moreInfo)
                                    
                                    Spacer()
                                    HapticsButton {
                                        Image(uiImage: viewModel.arrow)
                                            .colorMultiply(gamePremiereCSS.dropDownIconColor)
                                            .scaleEffect(x: 1, y: showMoreInfo ? -1 : 1)
                                            .frame(width: 16, height: 16)
                                            .padding(.trailing, 4)
                                    } action: {
                                        viewModel.storePromoId()
                                        showMoreInfo.toggle()
                                        viewModel.trackEvent(eventType: .game_premiere_click,
                                                             actionEvent: .click,
                                                             eventDetails: .more_info)
                                    }
                                    .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.dropDownIcon)
                                }
                                .padding([.top, .bottom], 12)
                                
                                Divider()
                                    .background(gamePremiereCSS.dividerColor)
                                    .frame(height: 1)
                            }
                            
                            // shows moreInfo content when user clicks on button(arrow)
                            if showMoreInfo {
                                VStack {
                                    withAnimation {
                                        AttributedTextWebView(htmlContent: viewModel.content?.moreInfoContent ?? "",
                                                              height: $contentHeight,
                                                              fontName: gamePremiereCSS.moreInfoContentFontName,
                                                              fontSize: gamePremiereCSS.moreInfoContentFontSize,
                                                              textColor: gamePremiereCSS.moreInfoContenttextColor) { urlString in
                                            self.viewModel.clickAction(with: urlString)
                                        }
                                        .frame(height: contentHeight)
                                        .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.moreInfoContent)
                                    }
                                }
                                .padding(.top, 12)
                                
                                Divider()
                                    .background(gamePremiereCSS.dividerColor)
                                    .frame(height: 1)
                                
                                if let viewFullDetails = viewModel.content?.viewFullDetails?.title, let viewDetailsActionUrl = viewModel.content?.viewFullDetails?.link {
                                    HapticsButton {
                                        Text(viewFullDetails)
                                            .font(gamePremiereCSS.viewDetailsFont)
                                            .foregroundColor(gamePremiereCSS.viewDetailsTextColor)
                                            .underline(true, color: gamePremiereCSS.viewDetailsUnderlineColor)
                                        
                                        Spacer()
                                    } action: {
                                        viewModel.storePromoId()
                                        self.cleanUpPlayerView = true
                                        viewModel.clickAction(with: viewDetailsActionUrl)
                                        viewModel.trackEvent(eventType: .game_premiere_click,
                                                             actionEvent: .click,
                                                             eventDetails: .more_info)
                                    }
                                    .padding(.top, 14)
                                    .padding(.bottom, 40)
                                    .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.viewDetailsCTA)
                                }
                            }
                        }
                        .frame(width: UIDevice.isIPad() ? (UIDevice.current.orientation.isLandscape ? geometry.size.height * 0.5 : geometry.size.width * 0.5) : geometry.size.width - 46)
                    }
                }
                .background(viewModel.showOverlay ?
                            LinearGradient(
                                stops: [
                                    Gradient.Stop(color: gamePremiereCSS.gradientBgColor1, location: 0.00),
                                    Gradient.Stop(color: gamePremiereCSS.gradientBgColor2, location: UIDevice.isIPad() ? (UIDevice.current.orientation.isLandscape ? 0.50 : 0.40) : 0.50),
                                    Gradient.Stop(color: gamePremiereCSS.gradientBgColor3, location: 1.00),
                                ],
                                startPoint: UnitPoint(x: 0.5, y: 0),
                                endPoint: UnitPoint(x: 0.5, y: 1)
                            ) : nil)
                
                // to show OptedIn toaster when user clicks on optIn Button
                if viewModel.showOptedInToaster {
                    if let optedinText = viewModel.content?.optedinText {
                        
                        HStack {
                            
                            if UIDevice.isIPad() {
                                Spacer()
                            }
                            
                            OptedInToaster(viewModel: viewModel, optedInText: optedinText)
                                .frame(width: UIDevice.isIPad() ? (UIDevice.current.orientation.isLandscape ? geometry.size.height * 0.5 : geometry.size.width * 0.5) : geometry.size.width - 8)
                                .padding(.top, 55)
                                .padding([.trailing, .leading] , UIDevice.isIPad() ? 0 : 4)
                            
                            if UIDevice.isIPad() {
                                Spacer()
                            }
                            
                        }
                    }
                }
            }
        }
        .edgesIgnoringSafeArea(.all)
        .onAppear {
            viewModel.trackEvent()
            viewModel.scheduleBlockforAnimation()
        }
    }
}


extension GamePremiereOverlay {
    
    @ViewBuilder
    var promotionalContent: some View {
        VStack(spacing: 0) {
            if let mainTitle = viewModel.content?.mainTitle {
                Text(mainTitle)
                    .font(gamePremiereCSS.mainTitleFont)
                    .foregroundColor(gamePremiereCSS.mainTitleColor)
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 40)
                    .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.mainTitle)
            }
            
            VStack(alignment: .leading, spacing: 0) {
                VStack(alignment: .leading, spacing: 0) {
                    if let steps = viewModel.content?.steps {
                        // Steps title
                        if let stepsTitle = viewModel.content?.stepsTitle {
                            Text(stepsTitle)
                                .font(gamePremiereCSS.stepsTitleFont)
                                .foregroundColor(gamePremiereCSS.stepsTitleColor)
                                .padding(.bottom, 12)
                                .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.stepsTitle)
                        }
                        
                        StepsView(steps: steps)
                    }
                }
                .padding(.bottom, 24)
                
                // Additional Info
                if let additionalInfo = viewModel.content?.additionalInfo {
                    Text(additionalInfo)
                        .font(gamePremiereCSS.additionalInfoFont)
                        .foregroundColor(gamePremiereCSS.additionalInfoTextColor)
                        .padding(.bottom, 24)
                        .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.additionalInfo)
                }
                
                // OptIn and playnow Buttons
                if viewModel.isOptInAvailable || viewModel.isplayNowTextAndCtaAvailable {
                    HStack(spacing: 10) {
                       
                        if viewModel.isOptInAvailable {
                            Button(action: {
                                viewModel.buttonBgColorTransition()
                                viewModel.storePromoId()
                                Task {
                                    await viewModel.updateOptInStatus()
                                }
                            }, label: {
                                HStack(spacing: 3) {
                                    if viewModel.stopButtonColorsTransition {
                                        withAnimation {
                                            Image(uiImage: viewModel.optedInIcon)
                                                .frame(width: 12, height: 12)
                                                .padding(.top, 2)
                                        }
                                        withAnimation {
                                            Text(viewModel.optedInText)
                                        }
                                    } else {
                                        Text(viewModel.optInText)
                                    }
                                }
                                .frame(maxWidth: .infinity, minHeight: 32)
                                .applyGradientBgColors(backgroundColors: viewModel.optInButtonTransitionColors ?? [.clear],
                                                       font: viewModel.optinGradientFont,
                                                       textColor: viewModel.optinGradientTextColor,
                                                       cornerRadius: gamePremiereCSS.buttonCornerRadius
                                )
                                .overlay(
                                    RoundedRectangle(cornerRadius: gamePremiereCSS.buttonCornerRadius)
                                        .stroke(gamePremiereCSS.buttonBorderColor, lineWidth: gamePremiereCSS.buttonBorderWidth)
                                )
                            })
                            .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.optInButton)
                            .disabled(viewModel.isOptedIn)
                        }
                        
                        if viewModel.isplayNowTextAndCtaAvailable {
                            Button(action: {
                                self.cleanUpPlayerView = true
                                viewModel.clickAction(with: viewModel.playNowActionUrl)
                                viewModel.storePromoId()
                            }, label: {
                                HStack {
                                    Text(viewModel.playNowText)
                                }
                                .frame(maxWidth: .infinity, minHeight: 32)
                                .applyGradientBgColors(backgroundColors: viewModel.playNowButtonTransitionColors ?? [.clear],
                                                       font: viewModel.playNowGradientFont,
                                                       textColor: viewModel.playNowGradientTextColor,
                                                       cornerRadius:  gamePremiereCSS.buttonCornerRadius
                                )
                                .overlay(
                                    RoundedRectangle(cornerRadius: gamePremiereCSS.buttonCornerRadius)
                                        .stroke(gamePremiereCSS.buttonBorderColor, lineWidth: gamePremiereCSS.buttonBorderWidth)
                                )
                            })
                            .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.playNowButton)
                        }
                    }
                }
            }
            .padding(.horizontal, 4)
        }
        .padding(.bottom, 32)
    }
}
