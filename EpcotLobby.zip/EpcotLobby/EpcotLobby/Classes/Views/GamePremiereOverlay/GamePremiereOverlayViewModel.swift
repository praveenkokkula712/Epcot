//
//  GamePremiereOverlayViewModel.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 06/06/24.
//

import Foundation
import CasinoAPI
import TrackerClient
import SwiftUI
import ConfigModule
import Combine

@MainActor
class GamePremiereOverlayViewModel: ObservableObject {
    
    var content: GamePremiere?
    var closeAction: (() -> Void)?
    var gamePremiereCSS: GamePremiereViewCSS? = GamePremiereViewCSS()
    var gradientColors: [[Color]]?
    var scheduledBlock: DispatchWorkItem?
    
    @Published var showOverlay = false
    @Published var showOptedInToaster: Bool = false
    @Published var isOptedIn = false
    @Published var stopButtonColorsTransition: Bool = false
    @Published var playPromoVideo: Bool = false
    @Published var colorIndex = 0
    
    private var timer: Publishers.Autoconnect<Timer.TimerPublisher>?
    private var subscription: AnyCancellable?
    
    static let optedIn = "OPTED_IN"
    static let offered = "OFFERED"
    
    init(content: GamePremiere? = nil, closeAction: @escaping () -> Void = { }) {
        self.content = content
        self.closeAction = closeAction
        self.gradientColors = GamePremiereButtonGradientColors.getGradientColors(className: BWGamePremiereCSS, key: "optInButtonGradientColors")
    }
    
    deinit {
        ETLogger.debug("Deinit")
    }
    
    func clean() {
        self.content = nil
        self.closeAction = nil
        self.gamePremiereCSS = nil
        self.gradientColors = nil
        self.scheduledBlock = nil
        self.timer = nil
        self.subscription = nil
    }
    
    // Triggered when opt-in button is clicked
    func updateOptInStatus() async {
        guard let id = content?.sourceId,  let sourceType = content?.sourceType else {
            return
        }
        if let result = try? await OptInStatusService().updateOptInStatus(id: id, sourceType: sourceType) as? OptInServiceModel,
           result.status == GamePremiereOverlayViewModel.optedIn {
            self.isOptedIn = true
            if isToasterEnabled {
                self.showOptedInToaster = true
                DispatchQueue.main.asyncAfter(deadline: .now() + self.optedInToasterDisplayDuration) {
                    self.showOptedInToaster = false
                }
            }
            return
        }
        self.timer?.upstream.connect().cancel()
        self.timer = nil
        self.stopButtonColorsTransition = false
        self.colorIndex = 0
    }
        
    var isPromotionAvailable: Bool {
        get async throws {
            guard let id = content?.sourceId,
                  let type = content?.sourceType else {
                return false
            }
            guard !self.isPromoDisplayed(with: id) else {
                return false
            }
            if type == .staticType {
                return true
            }
            if let response = try? await OptInStatusService().getOptInStatus(for: id, sourceType: type) as? OptInServiceModel {
                return response.status == GamePremiereOverlayViewModel.offered
            }
            return false
        }
    }
    
    // Triggered when playNow button/view Details is clicked
    func clickAction(with url: String) {
        cancelScheduledBlock()
        EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .teaserVideos(url), buttonType: nil)
        let eventDetails: EpcotEventDetails? = !optInActionUrl.isEmpty ? .opt_in : (!playNowActionUrl.isEmpty ? .play_now : nil)
        if let details = eventDetails {
            self.trackEvent(eventType: .game_premiere_click,
                            actionEvent: .click,
                            eventDetails: details)
        }
        closeAction?()
    }
    
    func trackEvent(eventType: EventType = .game_premiere_load,
                    actionEvent: EpcotEventAction = .load,
                    eventDetails: EpcotEventDetails = .game_premiere_animation_load) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.game_premiere.rawValue,
                                     actionEvent: actionEvent.rawValue,
                                     labelEvent: EpcotEventLabel.game_premiere.rawValue,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: eventDetails.rawValue,
                                     positionEvent: self.content?.mainTitle ?? "")
            let event = TrackerEvent(type: eventType, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
    
    func scheduleBlockforAnimation() {
        let scheduledBlock = DispatchWorkItem(block: {
            DispatchQueue.main.async {
                self.showOverlay = true
            }
        })
        self.scheduledBlock = scheduledBlock
        
        DispatchQueue.main.asyncAfter(deadline: .now() + self.animationDuration, execute: scheduledBlock)
    }
    
    func cancelScheduledBlock() {
        scheduledBlock?.cancel()
        scheduledBlock = nil
    }
    
    func isPromoDisplayed(with id: String) -> Bool {
        let storedId = UserDefaults.gamePremiereId
        guard !storedId.isEmpty else { return false }
        return storedId == id
    }
    
    func storePromoId() {
        if let sourceId = content?.sourceId {
            UserDefaults.gamePremiereId = sourceId
        }
    }
}

//MARK: related to optin and PlayNow buttons color transitions
extension GamePremiereOverlayViewModel {
    
    var playNowButtonTransitionColors: [Color]? {
        let playNowButtonTransitionColors = self.gradientColors?.reversed().compactMap({$0})
        return isOptInAvailable ? playNowButtonTransitionColors?[colorIndex] : playNowButtonTransitionColors?.last
    }
    
    var optInButtonTransitionColors: [Color]? {
        gradientColors?[colorIndex]
    }
    
    // for buttons transition
    func buttonBgColorTransition() {
        if let gradientColorsArrayCount = self.gradientColors?.count, gradientColorsArrayCount > 0 {
            timer = Timer.publish(every: TimeInterval(0.05), on: .main, in: .common)
                .autoconnect()
            subscription = timer?
                .sink { [weak self] _ in
                    guard let self else { return }
                    withAnimation(.easeInOut) {
                        self.colorIndex += 1
                        
                        if self.colorIndex == gradientColorsArrayCount - 1 {
                            self.stopButtonColorsTransition = true
                            self.timer?.upstream.connect().cancel()
                            self.timer = nil
                        }
                    }
                }
        }
    }
}

//MARK: UI content And theming
extension GamePremiereOverlayViewModel {
    var playNowText: String {
        return content?.playNowText ?? ""
    }
    
    var playNowActionUrl: String {
        return content?.playNowCta ?? ""
    }
    
    var optInText: String {
        return content?.optinText ?? ""
    }
    
    var optedInText: String {
        return content?.optedinText ?? ""
    }
    
    var optInActionUrl: String {
        return content?.optInCta ?? ""
    }
    
    var isOptinCtaAvailable: Bool {
        return !optInActionUrl.isEmpty
    }
    
    var isOptInAvailable: Bool {
        return (!optInText.isEmpty && !optedInText.isEmpty) && (self.content?.sourceType != .staticType)
    }
    
    var isplayNowTextAndCtaAvailable: Bool {
        return !playNowText.isEmpty && !playNowActionUrl.isEmpty
    }
    
    var imageUrl: String {
        return content?.staticPromoImage ?? ""
    }
    
    var videoUrl: String {
        return content?.promoVideo ?? ""
    }
    
    var videoEnabled: Bool {
        return !videoUrl.isEmpty && content?.enableVideo == true
    }
    
    var isValidUrl: Bool {
        return !imageUrl.isEmpty || videoEnabled
    }
    
    var playNowGradientFont: Font {
        (isOptInAvailable ? stopButtonColorsTransition ? gamePremiereCSS?.optInButtonTextFont : gamePremiereCSS?.playNowButtonTextFont : gamePremiereCSS?.optInButtonTextFont) ?? .body
    }
    
    var optinGradientFont: Font {
        (stopButtonColorsTransition ? gamePremiereCSS?.playNowButtonTextFont : gamePremiereCSS?.optInButtonTextFont) ?? .body
    }
    
    var playNowGradientTextColor: Color {
        (isOptInAvailable ? stopButtonColorsTransition ? gamePremiereCSS?.optInButtonTextColor : gamePremiereCSS?.playNowButtonTextColor : gamePremiereCSS?.optInButtonTextColor) ?? .clear
    }
    
    var optinGradientTextColor: Color {
        (stopButtonColorsTransition ? gamePremiereCSS?.playNowButtonTextColor : gamePremiereCSS?.optInButtonTextColor) ?? .clear
    }
}

//MARK: Icons
extension GamePremiereOverlayViewModel {
    var closeImage: UIImage {
        .init(named: "Close", in: kEpcotBundle, with: nil) ?? UIImage()
    }
    
    var arrow: UIImage {
        .init(named: "Arrow", in: kEpcotBundle, with: nil) ?? UIImage()
    }
    
    var optedInIcon: UIImage {
        .init(named: "NotificationIcon", in: kEpcotBundle, with: nil) ?? UIImage()
    }
}

    
//MARK: Helper
extension GamePremiereOverlayViewModel {
    
    var isEpcotFeatureEnabled: Bool {
        return EpcotLobbyManager.shared?.css.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false
    }
    
    var isToasterEnabled: Bool {
        return DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.gamePremiereConfigurations?.isToasterEnabled ?? false
    }
    
    var animationDuration: Double {
        return DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.gamePremiereConfigurations?.animationDuration ?? 2.0
    }
    
    var optedInToasterDisplayDuration: Double {
        return DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.gamePremiereConfigurations?.optedInToasterDisplayDuration ?? 4.0
    }
}
