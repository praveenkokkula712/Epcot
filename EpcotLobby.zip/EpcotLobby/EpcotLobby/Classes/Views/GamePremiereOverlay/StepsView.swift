//
//  StepsView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 24/04/24.
//

import SwiftUI
import Utility

struct StepsView: View {
    var steps: [String]
    let gamePremiereCSS = GamePremiereViewCSS()
    
    var body: some View {
        ForEach(steps.indices, id: \.self) { index in
            HStack(alignment: .top) {
                VStack(spacing: 0) {
                    if index != steps.count - 1 {
                        CircleWithStepNumber(stepNumber: index + 1)
                            .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.steps + "\(index + 1)")
                        Rectangle()
                            .fill(gamePremiereCSS.verticalLineColor)
                            .frame(width: 2)
                            .padding([.top, .bottom], 2)
                    } else {
                        if self.isSvgImage, let offersIconUrl {
                            VStack {
                                SVGImageView(url:offersIconUrl,
                                             size: CGSize(width: 16, height: 16))
                                .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.offerIcon)
                            }
                            .frame(width: 16, height: 16, alignment: .center)
                        } else {
                            Text(self.offersIcon)
                                .font(self.offersIconFont)
                                .foregroundColor(self.offersIconColor)
                                .minimumScaleFactor(0.5)
                                .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.offerIcon)
                        }
                    }
                }
                .frame(width: 20)
                Text(steps[index])
                    .font(gamePremiereCSS.stepsFont)
                    .foregroundColor(gamePremiereCSS.stepsTextColor)
                    .padding(.bottom, 8)
            }
        }
    }
}


extension StepsView {
    private var gamePremiereCss: GamePremiereCSS? {
        EpcotLobbyManager.shared?.css.gamePremiereCSS
    }
    
    private var offersIconVariant: IconVariant? {
        let iconName = gamePremiereCss?.offersIconName ?? "promotions-i-2"
        let iconVariant = EpcotLobbyManager.shared?.datasource?.didRequestForIconVariant(with: iconName ?? "", fontSize: gamePremiereCss?.offersIconSize ?? 16.0)
        return iconVariant
    }
    
    var isSvgImage: Bool {
        self.gamePremiereCss?.offersIconName?.contains(".svg") ?? false
    }
    
    var offersIcon: String {
        offersIconVariant?.icon ?? ""
    }
    
    var offersIconUrl: URL? {
        URL(string: gamePremiereCss?.offersIconName ?? "")
    }
    
    var offersIconFont: Font {
        Font(offersIconVariant?.font ?? .systemFont(ofSize: 12))
    }
    
    var offersIconColor: Color {
        let textColor = gamePremiereCss?.offersIconColor
        return Color(textColor ?? .black)
    }
}
