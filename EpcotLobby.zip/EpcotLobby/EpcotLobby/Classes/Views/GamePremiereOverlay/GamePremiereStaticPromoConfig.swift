//
//  GamePremiereStaticPromoConfig.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 28/06/24.
//

import Foundation

struct GamePremiereStaticPromoConfig: Codable {
    var storyId: String?
    var date: Date?
   
    init(storyId: String? = nil, date: Date? = nil) {
       self.storyId = storyId
       self.date = date
   }
}
