//
//  PromoMediaView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 30/04/24.
//

import SwiftUI
import Kingfisher
import CasinoAPI
import GSPlayer

struct PromoMediaView: View {
    
    @ObservedObject var viewModel: GamePremiereOverlayViewModel
    let content = POSAPI.shared?.gamePremiereModel
    var width: CGFloat
    @Binding var cleanUpPlayerView: Bool
    @State var isPlaying: Bool = false
    @State var isAudioMuted: Bool = false
    @State var isVideoEndTimeReached: Bool = false
    let styles = GamePremiereViewCSS()
    @Binding var playerView : VideoPlayerView
    var fullScreenAction : ((VideoPlayerView) -> ())?
    @Binding var isVideoLoaded : Bool
    var body: some View {
        
        if viewModel.isValidUrl {
            
            ZStack {
                /// StripesView
                stripeView
                
                /// MediaView and Control Buttons
                ZStack {
                    HStack {
                        if viewModel.videoEnabled, let videoUrl = URL(string: viewModel.videoUrl) {
                            ZStack {
                                PromoVideoPlay(videoURL: videoUrl,
                                               cleanUpPlayerView: $cleanUpPlayerView,
                                               isPlaying: $isPlaying,
                                               isAudioMuted: $isAudioMuted,
                                               playerView: $playerView,
                                               isVideoLoaded: $isVideoLoaded,
                                               isVideoEndTimeReached: $isVideoEndTimeReached
                                )
                                .frame(width: width, height: 169)
                                .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.promovideo)
                                if !self.isPlaying && playerView.playProgress == 0 {
                                    staticPromoImageView
                                }
                            }
                        } else {
                            staticPromoImageView
                        }
                    }
                    .cornerRadius(styles.borderRadius)
                    
                    
                    VStack(alignment: .leading) {
                        HStack {
                            // sticker on promoImage
                            if !self.isPlaying && playerView.playProgress == 0 {
                                if let sticker = viewModel.content?.sticker {
                                    Text(sticker)
                                        .font(styles.stickerTitleFont)
                                        .foregroundColor(styles.stickerTitleColor)
                                        .padding([.top, .bottom], 4)
                                        .padding(.horizontal, 6)
                                        .background(styles.stickerViewBgColor1)
                                        .background(styles.stickerViewBgColor2)
                                        .cornerRadius(styles.stickerViewCornerRadius)
                                        .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.sticker)
                                }
                            }
                            
                            Spacer()
                            
                            // speakerIcon on promovideo
                            if isVideoLoaded {
                                
                                HapticsButton {
                                    Image(systemName: isAudioMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                                        .foregroundColor(styles.speakerIconColor)
                                        .frame(width: 32, height: 24)
                                } action: {
                                    self.isAudioMuted.toggle()
                                }
                                .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.speakerIcon)
                            }
                        }
                        
                        Spacer()
                        
                        
                        if viewModel.videoEnabled && isVideoLoaded {
                            
                            HStack {
                                // play Icon on promovideo
                                HapticsButton {
                                    Image(uiImage: isPlaying ? pauseButton : playButton)
                                        .colorMultiply(styles.speakerIconColor)
                                        .frame(width: 32, height: 24)
                                } action: {
                                    viewModel.storePromoId()
                                    self.isPlaying.toggle()
                                    if self.isVideoEndTimeReached {
                                        self.playerView.replay(resetCount: true)
                                    }
                                    self.isVideoEndTimeReached = false
                                }
                                .padding(.leading, 1)
                                .accessibilityIdentifier(isPlaying ? GamePremiereAccessibilityIdentifiers.pauseIcon : GamePremiereAccessibilityIdentifiers.playIcon)
                                
                                Spacer()
                                
                                if styles.isVideoFullScreenEnabled && self.isPlaying {
                                    /// FullScreen Button
                                    HapticsButton {
                                        Image(systemName: "viewfinder")
                                            .font(.title2)
                                            .foregroundStyle(styles.speakerIconColor)
                                            .frame(width: 32, height: 24)
                                    } action: {
                                        fullScreenAction?(playerView)
                                    }
                                    .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.fullScreenIcon)
                                }
                            }
                        }
                    }
                    .padding([.leading, .trailing], 9 + styles.borderWidth)
                    .padding(.top, 7 + styles.borderWidth)
                    .padding(.bottom, 10 + styles.borderWidth)
                }
            }
            .padding(.bottom, 24)
        }
    }
                                

    
    
    var stripeView : some View {
        Stripes(
            config: .init(
                background: styles.borderBackgroundColor,
                foreground: styles.borderForegroundColor,
                degrees: styles.borderStripesAngle,
                barWidth: styles.borderBarWidth,
                barSpacing: styles.borderBarSpacing
            )
        )
        .cornerRadius(styles.borderRadius)
        .frame(width: width + 2*(styles.borderWidth), height: 169 + 2*(styles.borderWidth))
        .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.borderStripes)
    }
    
    var staticPromoImageView : some View {
        KFImage(URL(string: viewModel.imageUrl))
            .resizable()
            .placeholder { PlaceHolderImage() }
            .frame(width: width, height: 169)
            .accessibilityIdentifier(GamePremiereAccessibilityIdentifiers.promoImage)
    }
}

extension PromoMediaView {
    
    private var playButton: UIImage {
        .init(named: "PlayButton", in: kEpcotBundle, with: nil) ?? UIImage()
    }
    
    private var pauseButton: UIImage {
        .init(named: "PauseButton", in: kEpcotBundle, with: nil) ?? UIImage()
    }
}
