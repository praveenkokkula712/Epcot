//
//  PromoVideoPlay.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 26/04/24.
//

import Foundation
import SwiftUI
import GSPlayer

struct PromoVideoPlay: UIViewRepresentable {
    var videoURL: URL
    @Binding var cleanUpPlayerView: Bool
    @Binding var isPlaying: Bool
    @Binding var isAudioMuted: Bool
    @Binding var playerView : VideoPlayerView
    @Binding var isVideoLoaded: Bool
    @Binding var isVideoEndTimeReached: Bool
    
    func makeUIView(context: Context) -> VideoPlayerView {
        playerView.play(for: videoURL)
        playerView.isAutoReplay = false
        playerView.contentMode = .scaleToFill
        playerView.playToEndTime =  {
            self.isPlaying = false
            self.isVideoEndTimeReached = true
        }
        return playerView
    }
    
    func updateUIView(_ uiView: VideoPlayerView, context: Context) {
        if isPlaying && !self.isVideoEndTimeReached {
            if uiView.state != .playing {
                uiView.play(for: videoURL)
            }
        } else {
            if uiView.state == .playing {
                uiView.pause(reason: .userInteraction)
            }
        }
        uiView.isMuted = isAudioMuted
        
        if cleanUpPlayerView {
            uiView.destroy()
        }
        
        uiView.stateDidChanged = { state in
            if uiView.player?.currentItem?.status == .readyToPlay {
                if !isVideoLoaded {
                    DispatchQueue.main.async {
                        isVideoLoaded = true
                        if uiView.state == .playing {
                            uiView.pause()
                            isPlaying = false
                        }
                    }
                }
            }
        }
    }
}
