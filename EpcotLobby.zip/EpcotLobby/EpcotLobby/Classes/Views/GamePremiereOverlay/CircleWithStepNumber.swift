//
//  CircleWithStepNumber.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 25/04/24.
//

import SwiftUI

struct CircleWithStepNumber: View {
    
    var stepNumber: Int
    let gamePremiereCSS = GamePremiereViewCSS()
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(gamePremiereCSS.circleColor ,lineWidth: 1)
                .frame(width: 16, height: 16)
            Text("\(stepNumber)")
                .foregroundColor(gamePremiereCSS.stepNumberColor)
                .font(gamePremiereCSS.stepNumberFont)
        }
    }
}
