//
//  VideoFullScreenViewController.swift
//  EpcotLobby
//
//  Created by Naresh Banavath on 10/05/24.
//
import UIKit
import GSPlayer
import Utility

class VideoFullScreenViewController: UIViewController {
    
    var closeButton: UIButton!
    var fullscreenPlayerView: VideoFullscreenPlayerView!
    var gamePremiereCSS = GamePremiereViewCSS()
    var onClose : ((Bool)->())?
    
    init() {
        let button = UIButton()
        button.setImage(.init(named: kClose, in: kEpcotBundle, with: nil)?.withRenderingMode(.alwaysTemplate) ?? UIImage(), for: .normal)
        button.tintColor = gamePremiereCSS.closeIconColor.uiColor
        self.closeButton = button
        self.fullscreenPlayerView = VideoFullscreenPlayerView(frame: .zero)
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var transitioner: VideoFullscreenTransitioner = {
        loadViewIfNeeded()
        let transition = VideoFullscreenTransitioner()
        transition.fullscreenControls = [closeButton]
        transition.fullscreenPlayerView = fullscreenPlayerView
        transition.fullscreenVideoGravity = .resizeAspect
        return transition
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .black
        fullscreenPlayerView.frame = view.frame
        self.fullscreenPlayerView.configure(on: self.view)
        self.view.addSubview(closeButton)
        closeButton.addTarget(self, action: #selector(closeButtonTapped), for: .touchUpInside)
        
        /// CloseButton Constraints
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            closeButton.widthAnchor.constraint(equalToConstant: 50),
            closeButton.heightAnchor.constraint(equalToConstant: 50),
            closeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            closeButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20)
        ])
    }
    
    @objc func closeButtonTapped(_ sender : UIButton){
        Haptics.play(.light)
        onClose?(true)
        dismiss(animated: true)
    }
}
