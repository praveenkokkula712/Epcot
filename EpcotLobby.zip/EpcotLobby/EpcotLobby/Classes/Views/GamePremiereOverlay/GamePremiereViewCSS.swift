//
//  GamePremiereViewCSS.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 03/05/24.
//

import Foundation
import SwiftUI
import Utility

struct GamePremiereViewCSS {
    
    // MARK: Properties
    let backgroundColor: Color
    let gradientBgColor1: Color
    let gradientBgColor2: Color
    let gradientBgColor3: Color
    let closeIconColor: Color
    let subTitle1Color: Color
    let subTitle1Font: Font
    let subTitle2Color: Color
    let subTitle2Font: Font
    let stickerViewBgColor1: Color
    let stickerViewBgColor2: Color
    let stickerTitleColor: Color
    let stickerTitleFont: Font
    let stickerViewCornerRadius: CGFloat
    let mainTitleColor: Color
    let mainTitleFont: Font
    let stepsTitleColor: Color
    let stepsTitleFont: Font
    let circleColor: Color
    let stepNumberColor: Color
    let stepNumberFont: Font
    let stepsTextColor: Color
    let stepsFont: Font
    let verticalLineColor: Color
    let additionalInfoTextColor: Color
    let additionalInfoFont: Font
    let moreInfoTextColor: Color
    let moreInfoFont: Font
    let moreInfoContentBgColor: UIColor
    let moreInfoContenttextColor: UIColor
    let moreInfoContentFontName: String
    let moreInfoContentFontSize: CGFloat
    let dropDownIconColor: Color
    let dividerColor: Color
    let viewDetailsTextColor: Color
    let viewDetailsFont: Font
    let viewDetailsUnderlineColor: Color
    let optInButtonBgColor: Color
    let optInButtonTextColor: Color
    let optInButtonTextFont: Font
    let playNowButtonBgColor: Color
    let playNowButtonTextColor: Color
    let playNowButtonTextFont: Font
    let buttonBorderColor: Color
    let buttonBorderWidth: CGFloat
    let buttonCornerRadius: CGFloat
    let optedInToasterBgColor: Color
    let barColor: Color
    let toasterBarWidth: CGFloat
    let optedInTextColor: Color
    let optedInTextFont: Font
    let optedInToasterCornerRadius: CGFloat
    let speakerIconColor : Color
    
    let borderWidth: CGFloat
    let borderRadius: CGFloat
    let borderBackgroundColor: Color
    let borderForegroundColor: Color
    let borderStripesAngle: Double
    let borderBarWidth: CGFloat
    let borderBarSpacing: CGFloat
    let isVideoFullScreenEnabled : Bool
    
    // MARK: Init
    init(gamePremiereCSS: GamePremiereCSS? = nil) {
        let css = gamePremiereCSS ?? Self.lobbyCSS?.gamePremiereCSS
        backgroundColor = Color(css?.overlayBackGroundColor ?? Self.defaultOverlayBgColor)
        gradientBgColor1 = Color(css?.overlayGradientBgColor1 ?? Self.defaultOverlayBgColor1)
        gradientBgColor2 = Color(css?.overlayGradientBgColor2 ?? Self.defaultOverlayBgColor2)
        gradientBgColor3 = Color(css?.overlayGradientBgColor3 ?? Self.defaultOverlayBgColor3)
        closeIconColor = Color(css?.closeIconColor ?? Self.defaultTextColor)
        subTitle1Color = Color(css?.subTitle1Css?.color ?? Self.defaultTextColor)
        subTitle1Font = Font(css?.subTitle1Css?.font ?? Self.defaultSubTitle1Font)
        subTitle2Color = Color(css?.subTitle2Css?.color ?? Self.defaultTextColor)
        subTitle2Font = Font(css?.subTitle2Css?.font ?? Self.defaultSubTitle2Font)
        stickerViewBgColor1 =  Color(css?.stickerViewBgColor1 ?? Self.defaultStickerBgColor1)
        stickerViewBgColor2 = Color(css?.stickerViewBgColor2 ?? Self.defaultStickerBgColor2)
        stickerTitleColor = Color(css?.stickerTitleCss?.color ?? Self.defaultOptInButtonTextColor)
        stickerTitleFont = Font(css?.stickerTitleCss?.font ?? Self.defaultStepsFont)
        stickerViewCornerRadius = css?.stickerViewCornerRadius ?? 4
        mainTitleColor = Color(css?.mainTitleCss?.color ?? Self.defaultTextColor)
        mainTitleFont = Font(css?.mainTitleCss?.font ?? Self.defaultMainTitleFont)
        stepsTitleColor = Color(css?.stepsTitleCss?.color ?? Self.defaultTextColor)
        stepsTitleFont = Font(css?.stepsTitleCss?.font ?? Self.defaultStepsTitleFont)
        circleColor = Color(css?.stepCircleColor ?? Self.defaultTextColor)
        stepNumberColor = Color(css?.stepNumberCss?.color ?? Self.defaultTextColor)
        stepNumberFont = Font(css?.stepNumberCss?.font ?? Self.defaultStepsFont)
        stepsTextColor = Color(css?.stepsTextCss?.color ?? Self.defaultTextColor)
        stepsFont = Font(css?.stepsTextCss?.font ?? Self.defaultStepsFont)
        verticalLineColor = Color(css?.stepsVerticalLineColor ?? Self.defaultTextColor)
        additionalInfoTextColor = Color(css?.additionalInfoCss?.color ?? Self.defaultTextColor)
        additionalInfoFont = Font(css?.additionalInfoCss?.font ?? Self.defaultStepsFont)
        moreInfoTextColor = Color(css?.moreInfoTextCss?.color ?? Self.defaultTextColor)
        moreInfoFont = Font(css?.moreInfoTextCss?.font ?? Self.defaultStepsFont)
        moreInfoContentBgColor = css?.moreInfoContentBgColor ?? Self.defaultOverlayBgColor
        moreInfoContenttextColor = css?.moreInfoContentTextColor ?? Self.defaultMoreInfoContenttextColor
        moreInfoContentFontName = css?.moreInfoContentFontName ?? "PrimaryRegularFont"
        moreInfoContentFontSize = css?.moreInfoContentFontSize ?? 14.0
        dropDownIconColor = Color(css?.moreInfoDownArrowColor ?? Self.defaultDropDownIconColor)
        dividerColor = Color(css?.dividerColor ?? Self.defaultDividerColor)
        viewDetailsTextColor = Color(css?.viewFullDetailsTextCss?.color ?? Self.defaultDropDownIconColor)
        viewDetailsFont = Font(css?.viewFullDetailsTextCss?.font ?? Self.defaultStepsFont)
        viewDetailsUnderlineColor = Color(css?.viewFullDetailsUnderLineColor ?? Self.defaultDropDownIconColor)
        
        optInButtonBgColor = Color(css?.optInButton?.normal ?? Self.defaultOptinButtonBgColor)
        optInButtonTextColor = Color(css?.optInButton?.title?.color ?? Self.defaultTextColor)
        optInButtonTextFont = Font(css?.optInButton?.title?.font ?? Self.defaultStepsFont)
        
        playNowButtonBgColor = Color(css?.playNowButton?.selected ?? Self.defaultPlayNowButtonBgColor)
        playNowButtonTextColor = Color(css?.playNowButton?.title?.color ?? Self.defaultTextColor)
        playNowButtonTextFont = Font(css?.playNowButton?.title?.font ?? Self.defaultStepsFont)
        
        buttonBorderColor = Color(css?.buttonBorderColor ?? Self.defaultTextColor)
        buttonBorderWidth = css?.buttonBorderWidth ?? 1
        buttonCornerRadius = css?.buttonCornerRadius ?? 16
        
        optedInToasterBgColor = Color(css?.optedInToasterBgColor ?? Self.defaultTextColor)
        optedInToasterCornerRadius = css?.optedInToasterCornerRadius ?? 6
        barColor = Color(css?.toasterBarColor ?? Self.defaultToasterBarColor)
        toasterBarWidth = css?.toasterBarWidth ?? 6
        optedInTextColor = Color(css?.optedInTextCss?.color ?? Self.defaultOptInButtonTextColor)
        optedInTextFont = Font(css?.optedInTextCss?.font ?? Self.defaultStepsFont)
        speakerIconColor = Color(css?.speakerIconColor ?? Self.defaultSpeakerIconColor)
        
        borderWidth = css?.borderWidth ?? Self.defaultBorderWidth
        borderRadius = css?.borderRadius ?? Self.defaultBorderWidth
        borderBackgroundColor = Color (css?.borderBackgroundColor ?? Self.defaultBorderBackgroundColor)
        borderForegroundColor = Color(css?.borderForegroundColor ?? Self.defaultBorderForegroundColor)
        borderStripesAngle = css?.borderStripesAngle ?? Self.defaultBorderStripesAngle
        borderBarWidth = css?.borderBarWidth ?? Self.defaultBorderBarWidth
        borderBarSpacing = css?.borderBarSpacing ?? Self.defaultBorderBarSpacing
        isVideoFullScreenEnabled  = css?.isVideoFullScreenEnabled?.bool ?? false
        
    }
}


// MARK: - Helper
extension GamePremiereViewCSS: LobbyStylable {}

extension GamePremiereViewCSS {
    private static var defaultOverlayBgColor: UIColor { .convertFrom(hex: "#00201A") }
    private static var defaultOverlayBgColor1: UIColor { .convertFrom(hex: "#012F26", alpha: 0.8) }
    private static var defaultOverlayBgColor2: UIColor { .convertFrom(hex: "#00201A") }
    private static var defaultOverlayBgColor3: UIColor { .convertFrom(hex: "#001713") }
    private static var defaultTextColor: UIColor { .convertFrom(hex: "#ffffff") }
    private static var defaultStickerBgColor1: UIColor { .convertFrom(hex: "#D6BC68", alpha: 0.3) }
    private static var defaultStickerBgColor2: UIColor { .convertFrom(hex: "#ffffff") }
    private static var defaultOptInButtonTextColor: UIColor { .convertFrom(hex: "#050505") }
    private static var defaultSubTitle1Font: UIFont {
        .systemFont(ofSize: 18, weight: .regular)
    }
    private static var defaultSubTitle2Font: UIFont {
        .systemFont(ofSize: 30, weight: .bold)
    }
    private static var defaultMainTitleFont: UIFont {
        .systemFont(ofSize: 17, weight: .bold)
    }
    private static var defaultStepsTitleFont: UIFont {
        .systemFont(ofSize: 14, weight: .semibold)
    }
    private static var defaultStepsFont: UIFont {
        .systemFont(ofSize: 12, weight: .regular)
    }
    private static var defaultDropDownIconColor: UIColor { .convertFrom(hex: "#79BFFF") }
    private static var defaultDividerColor: UIColor { .convertFrom(hex: "#DCDFE4") }
    private static var defaultToasterBarColor: UIColor { .convertFrom(hex: "#61BA2B") }
    private static var defaultOptedInTextColor: UIColor { .convertFrom(hex: "#050505") }
    
    private static var defaultSpeakerIconColor: UIColor { .white }
    
    private static var defaultBorderWidth: CGFloat { 10.0 }
    
    private static var defaultBorderBackgroundColor: UIColor { .convertFrom(hex: "#D8BE6E")}
    
    private static var defaultBorderForegroundColor: UIColor { .convertFrom(hex: "#655124", alpha: 0.4)}
    
    private static var defaultBorderStripesAngle: CGFloat { 45.0 }
    
    private static var defaultBorderBarWidth: CGFloat { 6.0 }
     
    private static var defaultBorderBarSpacing: CGFloat { 6.0 }
    
    private static var defaultPlayNowButtonBgColor: UIColor { .clear }
    
    private static var defaultOptinButtonBgColor: UIColor { .convertFrom(hex: "#E9D193") }
    
    private static var defaultMoreInfoContenttextColor: UIColor { .convertFrom(hex: "#ffffff") }
    
}

