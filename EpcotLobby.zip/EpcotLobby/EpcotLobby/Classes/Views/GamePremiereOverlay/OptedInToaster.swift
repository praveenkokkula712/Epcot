//
//  OptedInToaster.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 24/04/24.
//

import SwiftUI
import ConfigModule

struct OptedInToaster: View {
    
    @ObservedObject var viewModel: GamePremiereOverlayViewModel
    var optedInText: String
    let gamePremiereCSS = GamePremiereViewCSS()
    
    var body: some View {
        HStack(alignment: .center) {
            VStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(gamePremiereCSS.barColor)
                    .frame(width: gamePremiereCSS.toasterBarWidth, height: 25)
                    .padding(.leading, 8)
                    .padding([.top, .bottom], 2)
            }
            Text(optedInText)
                .font(gamePremiereCSS.optedInTextFont)
                .foregroundColor(gamePremiereCSS.optedInTextColor)
            
            Spacer()
            
            Image(uiImage: optedInIcon)
                .frame(width: 12, height: 12)
                .padding(.trailing, 12)
            
        }
        .frame(height: 49)
        .background(gamePremiereCSS.optedInToasterBgColor)
        .cornerRadius(gamePremiereCSS.optedInToasterCornerRadius)
    }
}


extension OptedInToaster {
    private var optedInIcon: UIImage {
        .init(named: "NotificationIcon", in: kEpcotBundle, with: nil) ?? UIImage()
    }
}
