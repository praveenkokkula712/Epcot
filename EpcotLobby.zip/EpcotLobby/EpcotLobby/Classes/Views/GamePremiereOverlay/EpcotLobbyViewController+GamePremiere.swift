//
//  EpcotLobbyViewController+GamePremiere.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 06/05/24.
//

import Foundation
import SwiftUI
import Utility
import GSPlayer
import CasinoAPI

extension EpcotLobbyViewController {
    
    @MainActor func presentGamePremiereView(onClose: @escaping (() -> Void)) {
        Task {
            guard self.gamePremiereViewController == nil else { return }
            let gamePremiereViewModel = GamePremiereOverlayViewModel(content: POSAPI.shared?.gamePremiereModel, closeAction: {
                onClose()
            })
            let gamePremiereOverlay = GamePremiereOverlay(
                viewModel: gamePremiereViewModel,
                fullScreenAction: {[weak self] playerView in
                    let vc = VideoFullScreenViewController()
                    vc.modalPresentationStyle = .overFullScreen
                    vc.transitioner.playerView = playerView
                    vc.transitioningDelegate = vc.transitioner
                    EpcotLobbyManager.shared?.delegate?.didFullScreenEnabled(with: true)
                    vc.onClose = { _ in
                        EpcotLobbyManager.shared?.delegate?.didFullScreenEnabled(with: false)
                    }
                    self?.gamePremiereViewController?.present(vc, animated: true)
                })
            self.gamePremiereViewController = UIHostingController(rootView: gamePremiereOverlay)
            let status = try await gamePremiereViewModel.isPromotionAvailable ?? false
            guard status else {
                onClose()
                return
            }
            self.gamePremiereViewController?.presentWithAnimation()
            if let gamePremiereViewController = self.gamePremiereViewController {
                let presenter = AlertPresenter(vc: gamePremiereViewController)
                AlertCoordinator.showView(presenter)
            }
        }
    }
}
