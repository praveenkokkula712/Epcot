//
//  OnBoardingView+Tracker.swift
//  EpcotLobby
//
//  Created by Santhosh Kodadi on 08/05/23.
//

import TrackerClient
import Utility

extension EpcotLobbyViewController {
    func trackEventsForWelcomeScreen(eventDetails: String,
                                     isLoad: Bool = false) {
        UserOnboardingViewModel.shared?.trackEvent(actionEvent: isLoad ? .load : .click,
                                                   eventLabel: EpcotEventLabel.welcome.rawValue,
                                                   eventDetails: eventDetails,
                                                   eventPosition: EpcotEventPosition.onboaridng_welcome.rawValue)
    }
}
