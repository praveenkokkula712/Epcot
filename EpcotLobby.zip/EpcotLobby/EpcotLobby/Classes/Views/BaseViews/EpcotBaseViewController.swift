//
//  EpcotBaseViewController.swift
//  EpcotLobby
//
//  Created by Challa Venkata Narasimha Karthik on 11/04/22.
//

import Foundation

public class EpcotBaseViewController: UIViewController {
    
    public override var preferredStatusBarStyle: UIStatusBarStyle {
        get {
            if let info = Bundle.main.infoDictionary,
               let statusBar = info[kUiStatusBarStyle] as? String {
                return statusBar == kUiStatusBarStyleLightContent ? .lightContent : .default
            }
            return .default
        }
    }
    
    var shimmerGradients: ShimmerGradients {
        EpcotLobbyManager.shared?.css.epcotLobbyCSS?.shimmerGradients ?? ShimmerGradients()
    }
    
    var favoriteToastConfig: FavoriteToastConfig? {
        EpcotLobbyManager.shared?.datasource?.favoriteToastConfig
    }
    
    var favoriteToastTimer: DispatchTimer?
}
