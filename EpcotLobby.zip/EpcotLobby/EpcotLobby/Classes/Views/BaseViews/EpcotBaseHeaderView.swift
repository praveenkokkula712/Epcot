//
//  EpcotBaseHeaderView.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 25/04/22.
//

import Foundation

class EpcotBaseHeaderView: UICollectionReusableView {
    
    static let identifier = CellIdentifier.epcotHeaderView
    
    let titleLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.configureTitleLabel()
        self.configureView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureTitleLabel() {
        self.addSubview(self.titleLabel)
        self.titleLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([self.titleLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 0),
                                     self.titleLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: 0),
                                     self.titleLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0)])
    }
    
        //Override this method for setting the font and Text color
    func configureView() {
        
    }
}
