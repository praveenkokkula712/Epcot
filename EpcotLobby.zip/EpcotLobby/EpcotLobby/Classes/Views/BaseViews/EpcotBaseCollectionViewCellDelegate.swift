//
//  EpcotBaseCollectionViewCellDelegate.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 10/06/23.
//

import Foundation

protocol EpcotBaseCollectionViewCellDelegate: AnyObject {
    func didTappedOn(favourites cell: EpcotBaseCollectionViewCell, gameVariant: String, state: Bool)
}
