//
//  EpcotBaseCollectionViewCell.swift
//  EpcotLobby
//
//  Created by Praveen Kokkula on 25/04/22.
//

import Foundation


class EpcotBaseCollectionViewCell: UICollectionViewCell {

    weak var favouritesDelegate: EpcotBaseCollectionViewCellDelegate?

        //Shimmer changes
    
    var shimmerGradients: ShimmerGradients {
        EpcotLobbyManager.shared?.css.epcotLobbyCSS?.shimmerGradients ?? ShimmerGradients()
    }
    
    private var shimmerLayer: CALayer?
    
    func showLoading() {
        shimmerLayer = CAGradientLayer.applyShimmerGradient(with: shimmerGradients, on: self.contentView)
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        shimmerLayer?.removeFromSuperlayer()
        favouritesDelegate = nil
    }
}
