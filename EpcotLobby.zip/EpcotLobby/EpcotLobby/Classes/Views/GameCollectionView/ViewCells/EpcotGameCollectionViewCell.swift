//
//  GameCollectionViewCell.swift
//  LobbyGrid
//
//  Created by Praveen Kokkula on 16/06/20.
//  Copyright © 2020 Praveen Kokkula. All rights reserved.
//

import UIKit
import Combine
import Utility
import CasinoAPI
import SVGKit
import SDWebImage
import SDWebImageSVGKitPlugin
import ConfigModule

class EpcotGameCollectionViewCell: EpcotBaseCollectionViewCell {
    
    @IBOutlet private weak var priceHolderView: UIView!
    @IBOutlet private weak var imageViewGameDownloaded: UIImageView!
    @IBOutlet private weak var priceLabel: UILabel!
    @IBOutlet private weak var gameImage: UIImageView!
    @IBOutlet private weak var priceImage: UIImageView!
    @IBOutlet private weak var viewOpaque: UIView!
    @IBOutlet private weak var favouriteButton: FavouritesButton!
    @IBOutlet private weak var stickerLabel: StickerLabel!
    @IBOutlet private weak var jackpotStackView: UIStackView!

    @IBOutlet private weak var priceRangeView: UIView!
    @IBOutlet private weak var priceRangeOpaqueView: UIView!
    @IBOutlet private weak var priceRangeLabel: UILabel!

    @IBOutlet private weak var viewFooter: UIView!
    @IBOutlet private weak var footerOpaqueView: UIView!
    @IBOutlet private weak var footerTitleLabel: UILabel!
    @IBOutlet private weak var footerStackView: UIStackView!

    private var gameVariant: String?
    
    private var isJackpotGame: Bool = false
    
    private let epcotCss = EpcotLobbyManager.shared?.css
    private var pagingInfoToken = Set<AnyCancellable>()
    private var cellCornerRadius: CGFloat {
        self.epcotCss?.lobbyCornerRadius ?? kLobbyCornerRadius
    }
    
    deinit {
        self.clearSubscribers()
    }
    
    private var gameTileImageUrl: String = "" {
        didSet {
            self.gameImage.loadImage(withUrl: gameTileImageUrl)
        }
    }
    
    private var sticker: String? {
        didSet {
            self.stickerLabel.updateContent(with: sticker)
        }
    }
    
    private var jackpotAmount: String? {
        didSet {
            self.updateAmount(amount: jackpotAmount)
        }
    }
    
    private var liveData: LiveCasinoFeed? {
        didSet {
            self.updateLiveFeedUI()
        }
    }
    
    private var isGameDownloaded: Bool = false {
        didSet {
            self.imageViewGameDownloaded.isHidden = !isGameDownloaded
        }
    }
    
    var isFavouriteGame: FavouriteState = .unselected {
        didSet {
            self.favouriteButton.isFavouriteSelected = isFavouriteGame
        }
    }
    
    private var fireIconImageUrl: String = "" {
        didSet {
            if fireIconImageUrl.isSVG, let url = URL(string: fireIconImageUrl) {
                self.priceImage.sd_setImage(with: url)
            } else {
                self.priceImage.loadImage(withUrl: fireIconImageUrl)
            }
        }
    }
    
    private var textAllignmentForJackpot: JackpotTitleAlignment {
        EpcotLobbyManager.shared?.datasource?.textAllignmentForJackpot ?? .left
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.updateView()
        self.addAccessibilityIdentifiers()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        self.updateShadow(cornerRadius: 0)
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.clearSubscribers()
    }
    
    func clearSubscribers() {
        self.pagingInfoToken.forEach { cancellable in
            cancellable.cancel()
        }
        self.pagingInfoToken.removeAll()
    }
    
    private func updateView() {
        self.gameImage.getRoundedCorners(OfRadius: cellCornerRadius)
        self.priceHolderView.getRoundedCorners(OfRadius: cellCornerRadius)
        self.priceHolderView.clipsToBounds = false
        self.priceHolderView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        self.priceHolderView.backgroundColor = self.epcotCss?.epcotLobbyCSS?.jackpotViewBackgroundColor ?? UIColor.white
        let layerColor =  self.epcotCss?.epcotLobbyCSS?.jackpotViewLayerBackgroundColor ?? UIColor(red: 0.02, green: 0.02, blue: 0.02, alpha: 0.4)
        self.priceHolderView.layer.backgroundColor = layerColor.cgColor
        self.dropShadowEffect(cornerRadius: cellCornerRadius)
        self.priceImage.isHidden = false
        let jpView = self.epcotCss?.gridView?.jpView
        self.viewOpaque.backgroundColor = jpView?.jpBGColor
        self.priceLabel.font = jpView?.priceAmount?.font
        self.priceLabel.textColor = jpView?.priceAmount?.color
        self.jackpotStackView.alignment = textAllignmentForJackpot.alignment
        self.favouriteButton.isFavouriteSelected = isFavouriteGame

        self.priceRangeView.getRoundedCorners(OfRadius: cellCornerRadius)
        self.priceRangeView.clipsToBounds = false
        self.priceRangeView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        self.priceRangeView.backgroundColor = self.epcotCss?.epcotLobbyCSS?.liveFeedCSS?.viewBackgroundColor ?? UIColor.clear
        let liveFeedLayerColor =  self.epcotCss?.epcotLobbyCSS?.liveFeedCSS?.viewLayerBackgroundColor ?? .clear
        self.priceRangeView.layer.backgroundColor = liveFeedLayerColor.cgColor
        self.footerOpaqueView.backgroundColor = self.epcotCss?.epcotLobbyCSS?.liveFeedCSS?.viewOpaqueColor
    }
    
    func configureCell(with info: ImmersiveGameInfo, isJackpotGame: Bool = false, sticker:String? = nil) {
        self.gameTileImageUrl = info.imagePath
        self.isJackpotGame = isJackpotGame
        self.sticker = sticker
        self.isFavouriteGame = info.gameInfo.isFavouriteGame.favouriteState
        self.gameVariant = info.gameInfo.gameVariantName
        self.isGameDownloaded = info.gameInfo.localGameDownLoadState
        if info.gameInfo.isHotJackpotGame {
            self.fireIconImageUrl = info.fireIconImagePath
        }
        self.priceImage.isHidden = !info.gameInfo.isHotJackpotGame
        
        if let liveInfo = info.gameInfo.liveFeedData {
            self.liveData = liveInfo
            self.jackpotAmount = nil
        } else {
            self.liveData = nil
            if let jpPrice = info.gameInfo.jpPrice,
                !isJackpotGame {
                self.jackpotAmount = jpPrice
            } else {
                self.jackpotAmount = nil
            }
        }
    }
    
    func stopDownloadingTask() {
        self.gameImage.kf.cancelDownloadTask()
    }
    
    @IBAction func didClickOnFavouriteButton(sender: FavouritesButton) {
        sender.tapAnimation {[weak self] in
            guard let self = self else { return }
            sender.isSelected = !sender.isSelected
            self.favouriteButton.isFavouriteSelected = sender.isSelected ? .selected : .unselected
            self.favouritesDelegate?.didTappedOn(favourites: self,
                                                 gameVariant: self.gameVariant ?? "",
                                                 state: sender.isSelected)
        }
        Haptics.play(.light)
    }
}

    //MARK: - Configure methods.
extension EpcotGameCollectionViewCell {

    func subscribeTo(subject: PassthroughSubject<[String: String]?, Never>) {
        subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] values in
                guard let self else { return }
                guard self.liveData == nil else { return }
                guard !self.isJackpotGame else { return }
                guard let values = values else {
                    guard let amount = self.jackpotAmount?.jackpotCounterAmount else { return }
                    self.jackpotAmount = amount
                    return
                }
                if let gameVariantName = self.gameVariant,
                   let jpPrice = values[gameVariantName] {
                    self.jackpotAmount = jpPrice
                }
            }
            .store(in: &pagingInfoToken)
    }
    
        /// this method will invoked when amout is updaing from jackpot
    private func updateAmount(amount: String?) {
        if let _amount = amount {
            self.priceHolderView.isHidden = false
            self.priceLabel.text = _amount
        } else {
            self.priceHolderView.isHidden = true
        }
    }
}

//MARK: Adding Accessibility Identifiers
extension EpcotGameCollectionViewCell {
    private func addAccessibilityIdentifiers() {
        priceHolderView.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_priceHolderView.rawValue
        imageViewGameDownloaded.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_imageViewGameDownloaded.rawValue
        priceLabel.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_priceLabel.rawValue
        gameImage.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_gameImage.rawValue
        priceImage.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_priceImage.rawValue
        viewOpaque.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_viewOpaque.rawValue
        favouriteButton.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_favouriteButton.rawValue
        stickerLabel.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_stickerLabel.rawValue
        priceRangeLabel.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_priceRangeLabel.rawValue
        footerTitleLabel.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_footerTitleLabel.rawValue
        footerOpaqueView.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_footerOpaqueView.rawValue
        footerStackView.accessibilityIdentifier = AccessibilityIdentifiers.epcotGameCell_footerStackView.rawValue
        
    }
}

extension EpcotGameCollectionViewCell {
    
    private var liveCasinoAPIContent: LiveCasinoAPIContent? {
        POSAPI.shared?.liveCasinoAPIContent
    }
    
    func subscribeToLiveFeed(subject: PassthroughSubject<[String: LiveCasinoFeed]?, Never>) {
        subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] values in
                guard let self else { return }
                guard let values = values else {
                    return
                }
                if let gameVariantName = self.gameVariant,
                   let liveFeed = values[gameVariantName] {
                    self.jackpotAmount = nil
                    self.liveData = liveFeed
                }
            }
            .store(in: &pagingInfoToken)
    }
    
    /// this method will invoked when Live Feed is updated
    private func updateLiveFeedUI() {
        guard let liveData = self.liveData else {
            self.priceRangeViews(hidden: true)
            self.liveFeedViews(hidden: true)
            return
        }
        
        if let minAmount = self.liveData?.minAmount, sticker?.isEmpty == true {
            self.priceRangeViews(hidden: false)
            self.priceRangeLabel.text = minAmount
        } else {
            self.priceRangeViews(hidden: true)
        }
        
        let seating = self.liveData?.seatingArrangement ?? []
        let lastResults = self.liveData?.lastResults ?? []
        
        if !seating.isEmpty || !lastResults.isEmpty {
            self.liveFeedViews(hidden: false)
            let liveCasinoAPIContent = POSAPI.shared?.liveCasinoAPIContent
            if !seating.isEmpty {
                //removing all subviews
                self.footerStackView.removeAllSubViews()
                self.footerTitleLabel.text = self.liveData?.seatsText ?? "Available seats"
                self.footerTitleLabel.textColor = UIColor.hexStringToUIColor(hex: liveCasinoAPIContent?.availableSeatsColor ?? "#FFFFFF")
                self.footerTitleLabel.font =  self.epcotCss?.epcotLobbyCSS?.liveFeedCSS?.availableSeatsTextFont
                self.insertLiveFeed(data: seating, isIcon: true)
            }
            if !lastResults.isEmpty {
                //removing all subviews
                self.footerStackView.removeAllSubViews()
                self.footerTitleLabel.text = liveCasinoAPIContent?.lastResults ?? "Last results"
                self.footerTitleLabel.textColor = UIColor.hexStringToUIColor(hex: liveCasinoAPIContent?.lastResultsColor ?? "#FFFFFF")
                self.footerTitleLabel.font = self.epcotCss?.epcotLobbyCSS?.liveFeedCSS?.lastResultsTextFont
                self.insertLiveFeed(data: lastResults)
            }
        } else {
            self.liveFeedViews(hidden: true)
        }
    }
    
    private func priceRangeViews(hidden: Bool) {
        priceRangeView.isHidden = hidden
        priceRangeOpaqueView.isHidden = hidden
        priceRangeLabel.isHidden = hidden
    }
    
    private func liveFeedViews(hidden: Bool) {
        self.viewFooter.isHidden = hidden
        self.footerOpaqueView.isHidden = hidden
        self.footerTitleLabel.isHidden = hidden
        self.footerStackView.isHidden = hidden
        self.footerTitleLabel.text = ""
    }
    

    private func insertLiveFeed(data: [LiveCasinoFeedResult], isIcon: Bool = false) {
        data.forEach { result in
            let label = UILabel()
            if isIcon {
                let icon = EpcotLobbyManager.shared?.datasource?.didRequestForIconVariant(with: "avatar", fontSize: self.epcotCss?.epcotLobbyCSS?.liveFeedCSS?.availableSeatsAvatarSize ?? 8.0)
                label.text = icon?.icon
                label.font = icon?.font
            } else {
                label.text = result.value
                label.font = self.epcotCss?.epcotLobbyCSS?.liveFeedCSS?.lastResultsValuesFont
            }
            label.textColor = result.color
            self.footerStackView.addArrangedSubview(label)
        }
    }
}
