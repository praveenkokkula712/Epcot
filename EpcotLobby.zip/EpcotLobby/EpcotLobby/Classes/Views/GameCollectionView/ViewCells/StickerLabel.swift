//
//  StickerLabel.swift
//  EpcotLobby
//
//  Created by Rajani Bhimanadham on 15/05/23.
//

import Foundation
import UIKit
import Utility

class StickerLabel:PaddingLabel {
   
    override func awakeFromNib() {
        super.awakeFromNib()
        self.updateCss()
    }
    
    private func updateCss() {
        let stickerCSS = EpcotLobbyManager.shared?.css.stickerCSS ?? DefaultStickerCSS()
        self.contentInset = UIEdgeInsets(top: 1.5, left: 3, bottom: 1.5, right: 3)
        self.textAlignment = .center
        self.backgroundColor = stickerCSS.backgroundColor
        self.font = stickerCSS.title?.font
        self.textColor = stickerCSS.title?.color
        self.layer.cornerRadius = stickerCSS.cornerRadius ?? 4.0
        self.clipsToBounds = true
        self.layer.masksToBounds = true
    }
    
    /// this method will update the sticker type on the game tile
    /// - Parameter sticker: sticker value
    func updateContent(with sticker:String?) {
        if let sticker, !sticker.isEmpty {
            self.isHidden = false
            self.text = sticker
        } else {
            self.isHidden = true
        }
    }
}
