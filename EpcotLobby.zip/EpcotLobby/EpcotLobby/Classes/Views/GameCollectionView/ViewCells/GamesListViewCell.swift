//
//  LobbyListCollectionViewCell.swift
//  CasinoLobby
//
//  Created by Praveen Kokkula on 01/02/22.
//

import UIKit
import CasinoAPI
import Combine
import ConfigModule

class GamesListViewCell: EpcotBaseCollectionViewCell {
    
    //MARK: -  IBOutlet connections
    @IBOutlet private weak var gameBlurImageView: UIImageView!
    @IBOutlet private weak var gameSquareImageView: UIImageView!
    @IBOutlet private weak var gameImageContainerView: UIView!
    @IBOutlet private weak var buttonGameDownload: UIButton!
    @IBOutlet weak var favouriteButton: FavouritesButton!
    @IBOutlet private weak var labelGameTitle: UILabel!
    @IBOutlet private weak var labelJackpotAmount: UILabel!
    @IBOutlet private weak var gameNameWidthConstraint: NSLayoutConstraint!
    @IBOutlet private weak var stackViewTrailingConstraint: NSLayoutConstraint!
    @IBOutlet private weak var stackViewLeadingConstraintWithPlayButton: NSLayoutConstraint!
    @IBOutlet private weak var stickerLabel: StickerLabel!

    deinit {
        self.pagingInfoToken?.cancel()
        self.pagingInfoToken = nil
    }
    
    //MARK: - file private constants
    fileprivate let gameButtonborderWidth: CGFloat = 2.0
    private var pagingInfoToken: AnyCancellable?
    
    private var cellCornerRadius: CGFloat {
        EpcotLobbyManager.shared?.css.imageCornerRadius ?? kGameImageCornerRadius
    }
    
    private var cellCSS : LobbyGameCellCSS? {
        EpcotLobbyManager.shared?.css.gamesCell
    }
    
    //MARK: - Private observers
    private var urlBlurImageView: String = "" {
        didSet {
            self.gameBlurImageView.loadImage(withUrl: urlBlurImageView)
        }
    }
    
    private var urlSquareImageView: String = "" {
        didSet {
            self.gameSquareImageView.loadImage(withUrl: urlSquareImageView)
        }
    }
    
    private var isGameDownLoaded: Bool = false {
        didSet {
            self.updateDownloadButtonContent()
        }
    }
    
    private var gameTitle: String = "" {
        didSet {
            self.labelGameTitle.text = gameTitle
        }
    }
    
    private var jackpotAmount: String? {
        didSet {
            self.updateJackpotAmount(with: jackpotAmount)
        }
    }
    
    var isFavouriteGame: FavouriteState = .unselected {
        didSet {
            self.favouriteButton.isFavouriteSelected = isFavouriteGame
        }
    }
    
    private var gameVariant: String?

    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupContentView()
        self.addAccessibilityIdentifiers()  
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.updateShadow(cornerRadius: 0)
    }
    
    private func setupContentView() {
        self.gameSquareImageView.getRoundedCorners(OfRadius: cellCornerRadius)
        self.gameImageContainerView.dropShadow(color: .black, offSet: CGSize(width: 0, height: 3))
        self.dropShadowEffect(cornerRadius: cellCornerRadius)
        self.buttonGameDownload.getRoundedCorners(OfRadius: EpcotLobbyManager.shared?.css.buttonCornerRadius ?? kButtonCornerRadius)
        let blurEffect = UIBlurEffect(style: .dark)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = self.gameBlurImageView.frame
        blurEffectView.alpha = 0.5
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.gameBlurImageView.addSubview(blurEffectView)
        
        let cellCSS = EpcotLobbyManager.shared?.css.gamesCell
        self.labelGameTitle.textColor = cellCSS?.gameTitle?.color
        self.labelGameTitle.font = cellCSS?.gameTitle?.font
        self.labelJackpotAmount.textColor = cellCSS?.gameTitle?.color
        self.labelJackpotAmount.font = cellCSS?.priceTag?.font
    }
    
    private func updateJackpotAmount(with amount: String?) {
        if let amount = amount {
            self.labelJackpotAmount.isHidden = false
            self.labelJackpotAmount.text = amount
        } else {
            self.labelJackpotAmount.isHidden = true
        }
    }
    
    private func updateDownloadButtonContent() {
        let css = EpcotLobbyManager.shared?.css.epcotLobbyCSS?.immersiveCSS
        self.buttonGameDownload.getRoundedCorners(OfRadius: css?.downloadIconCornerRdius ?? 4.0)
        self.buttonGameDownload.layer.borderWidth = gameButtonborderWidth
        self.buttonGameDownload.setTitleColor(cellCSS?.playButton?.title?.color, for: .normal)
        if isGameDownLoaded {
            self.buttonGameDownload.titleEdgeInsets = UIEdgeInsets(top: 7, left: 20, bottom: 7, right: 20)
            self.buttonGameDownload.setTitle(Localize.kPlay, for: .normal)
            self.buttonGameDownload.setImage(nil, for: .normal)
            self.buttonGameDownload.backgroundColor = cellCSS?.playButton?.normal
            self.buttonGameDownload.layer.borderColor = UIColor.clear.cgColor
            self.buttonGameDownload.titleLabel?.font =  cellCSS?.downloadButton?.title?.font
            NSLayoutConstraint.deactivate([self.stackViewTrailingConstraint])
            NSLayoutConstraint.activate([self.gameNameWidthConstraint,self.stackViewLeadingConstraintWithPlayButton])
            self.layoutIfNeeded()
            self.buttonGameDownload.isHidden = false
            if CasinoCSS.lobby?.epcotLobbyCSS?.isEpcotFeatureEnabled ?? false {
                self.buttonGameDownload.applyEpcotGradientBgColor()
            }
        } else {
            self.buttonGameDownload.layer.borderColor = cellCSS?.downloadButtonBorderColor?.cgColor
            let isHtmlGamesEnabled = DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.liveCasinoLMTConfig?.isHTMLGamesEnabled ?? false
            if ImmersiveInstance.shared.isEnabled || isHtmlGamesEnabled {
                self.buttonGameDownload.setTitle("", for: .normal)
                let downloadIcon = UIImage(named: kDownloadIcon,
                                           in: Bundle(for: GamesListViewCell.self),
                                           with: .none)
                self.buttonGameDownload.setImage(downloadIcon, for: .normal)
                self.buttonGameDownload.backgroundColor = css?.downloadIconBGColor
                self.buttonGameDownload.layer.borderWidth = 0.0
                NSLayoutConstraint.deactivate([self.gameNameWidthConstraint,self.stackViewLeadingConstraintWithPlayButton])
                NSLayoutConstraint.activate([self.stackViewTrailingConstraint])
                self.layoutIfNeeded()
                self.buttonGameDownload.isHidden = true
            } else {
                self.buttonGameDownload.titleEdgeInsets = UIEdgeInsets(top: 7, left: 12, bottom: 7, right: 12)
                NSLayoutConstraint.deactivate([self.stackViewTrailingConstraint])
                NSLayoutConstraint.activate([self.gameNameWidthConstraint,self.stackViewLeadingConstraintWithPlayButton])
                self.layoutIfNeeded()
                self.buttonGameDownload.setTitle(Localize.kDownload, for: .normal)
                self.buttonGameDownload.titleLabel?.font = cellCSS?.downloadButton?.title?.font
                self.buttonGameDownload.setTitleColor(cellCSS?.downloadButton?.title?.color, for: .normal)
                self.buttonGameDownload.backgroundColor = .clear
            }
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.pagingInfoToken?.cancel()
        self.pagingInfoToken = nil
        NSLayoutConstraint.deactivate([self.gameNameWidthConstraint,
                                       self.stackViewLeadingConstraintWithPlayButton,
                                       self.stackViewTrailingConstraint])
    }
    
    func subscribeTo(subject: PassthroughSubject<[String: String]?, Never>) {
        pagingInfoToken = subject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] values in
                guard let values = values else {
                    guard let amount = self?.jackpotAmount?.jackpotCounterAmount else { return }
                    self?.jackpotAmount = amount
                    return
                }
                if let gameVariantName = self?.gameVariant,
                   let jpPrice = values[gameVariantName] {
                    self?.jackpotAmount = jpPrice
                }
            }
    }
    
    func configureCell(with immersiveInfo: ImmersiveGameInfo?, isJackpotGame: Bool = false, blurImagePath: String?, sticker:String? = nil) {
        guard let info = immersiveInfo else { return }
        self.urlBlurImageView = blurImagePath ?? "\(info.gameInfo.imagePath)/" + "ios" + "/\(info.gameInfo.gameVariantName).jpg"
        self.urlSquareImageView = info.imagePath
        if let name = info.gameInfo.gameMetadata.name {
            self.gameTitle = name
        }
        if !isJackpotGame {
            self.jackpotAmount = info.gameInfo.jpPrice
        } else {
            self.jackpotAmount = nil
        }
        self.isGameDownLoaded = info.gameInfo.localGameDownLoadState
        self.isFavouriteGame = info.gameInfo.isFavouriteGame.favouriteState
        self.gameVariant = info.gameInfo.gameVariantName
        self.stickerLabel.updateContent(with: sticker)
    }
    
    @IBAction func didClickOnFavouriteButton(sender: FavouritesButton) {
        sender.tapAnimation {[weak self] in
            guard let self = self else { return }
            sender.isSelected = !sender.isSelected
            self.favouriteButton.isFavouriteSelected = sender.isSelected ? .selected : .unselected
            self.favouritesDelegate?.didTappedOn(favourites: self,
                                                 gameVariant: self.gameVariant ?? "",
                                                 state: sender.isSelected)
        }
        Haptics.play(.light)
    }
}

extension Bool {
    var favouriteState: FavouriteState {
        self ? .selected : .unselected
    }
}

//MARK: Adding Accessibility Identifiers
extension GamesListViewCell {
    private func addAccessibilityIdentifiers() {
        gameBlurImageView.accessibilityIdentifier = AccessibilityIdentifiers.gamelistView_gameBlurImageView.rawValue
        gameSquareImageView.accessibilityIdentifier = AccessibilityIdentifiers.gamelistView_gameSquareImageView.rawValue
        gameImageContainerView.accessibilityIdentifier = AccessibilityIdentifiers.gamelistView_gameImageContainerView.rawValue
        buttonGameDownload.accessibilityIdentifier = AccessibilityIdentifiers.gamelistView_buttonGameDownload.rawValue
        favouriteButton.accessibilityIdentifier = AccessibilityIdentifiers.gamelistView_favouriteButton.rawValue
        labelGameTitle.accessibilityIdentifier = AccessibilityIdentifiers.gamelistView_labelGameTitle.rawValue
        labelJackpotAmount.accessibilityIdentifier = AccessibilityIdentifiers.gamelistView_labelJackpotAmount.rawValue
        stickerLabel.accessibilityIdentifier = AccessibilityIdentifiers.gamelistView_stickerLabel.rawValue
    }
}
