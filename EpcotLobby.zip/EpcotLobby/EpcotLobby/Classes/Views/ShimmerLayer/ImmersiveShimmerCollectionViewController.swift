//
//  ImmersiveShimmerCollection.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 29/11/22.
//

import Foundation
import UIKit

enum ImmersiveShimmerSectionType: Int, CaseIterable {
    case category, horizontalGrid, verticalImmersiveGrid, verticalGrid
    
    func createSection() -> NSCollectionLayoutSection {
        switch self {
        case .category: return ImmersiveLobbyShimmerLayoutSection.shimmerCategoryLayout()
        case .horizontalGrid: return ImmersiveLobbyShimmerLayoutSection.shimmerHorizontalGridLayout()
        case .verticalImmersiveGrid: return ImmersiveLobbyShimmerLayoutSection.shimmerVerticalImmersiveGrid()
        case .verticalGrid: return ImmersiveLobbyShimmerLayoutSection.shimmerVerticalGrid()
        }
    }
}

enum ImmersiveShimmerItem: Hashable {
    case loading(UUID)
    
    static func loadingItems(with type: ImmersiveShimmerSectionType) -> [ImmersiveShimmerItem] {
        var count = 0
        switch type {
        case .category: count = 1
        case .horizontalGrid: count = UIDevice.isIPad() ? 10 : 5
        case .verticalImmersiveGrid: count = UIDevice.isIPad() ? 18 : 9
        case .verticalGrid: count = UIDevice.isIPad() ? 20 : 10
        }
        return Array(repeatingExpression: ImmersiveShimmerItem.loading(UUID()), count: count)
    }
}

class ImmersiveShimmerCollectionViewController: UICollectionViewController {
    
    private var diffDatasource: ImmersiveShimmerDatasource?
    private var snapShot: ImmersiveShimmerSnapshot?
    
    private var css: ShimmerViewCSS? {
        EpcotLobbyManager.shared?.css.shimmerViewCSS
    }
    
    /// Create a Collection view layout by setting up CollectionViewCompositional Layout
    /// - Returns: UICollectionVIew
    private var compositionalLayout: UICollectionViewLayout {
        let layout = UICollectionViewCompositionalLayout { (sectionIndex: Int,
                                                            layoutEnvironment: NSCollectionLayoutEnvironment) -> NSCollectionLayoutSection? in
            guard let sectionIdentifiers = self.snapShot?.sectionIdentifiers else {
                return CustomLayoutSection.inAppAdsLayoutSection()
            }
            let section = sectionIdentifiers[sectionIndex].createSection()
            return section
        }
        return layout
    }
    
    //MARK: - Initialisation methods.
    /// Convenience init declaration
    required convenience init?(coder: NSCoder) {
        self.init(coder: coder)
    }
    
    /// Convenience delcaration for collection view initialization.
    convenience init() {
        self.init(collectionViewLayout: UICollectionViewFlowLayout())
    }
        
    //MARK: - View controller life cycle methods.
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupCollectionView()
        self.configureDatasource()
        self.setupViewCSS()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.snapShot = nil
        self.diffDatasource = nil
        self.collectionView = nil
    }
    
    //MARK: - Collection View setup and data update methods.
    /// Setup collection View will update the collection view layout info and sets the required delegate and data source information.
    private func setupCollectionView() {
        self.collectionView.setupDefaultConfiguration()
        self.collectionView.register(ShimmerCollectionViewCell.self,
                                     forCellWithReuseIdentifier: CellIdentifier.shimmerCell)
        self.collectionView.register(ImmersiveShimmerHeader.self,
                                     forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                                     withReuseIdentifier: CellIdentifier.shimmerCell)
        self.collectionView.collectionViewLayout = self.compositionalLayout
        self.collectionView.isUserInteractionEnabled = false
        self.collectionView.backgroundColor = self.css?.backgroundColor ?? .black
    }
    
    /// Configure Diffable DataSource
    private func configureDatasource() {
        guard self.collectionView != nil else { return }
        diffDatasource = ImmersiveShimmerDatasource(collectionView: self.collectionView, cellProvider: { collectionView, indexPath, itemIdentifier in
            self.cell(collectionView: collectionView, indexPath: indexPath, item: itemIdentifier)
        })
        self.diffDatasource?.supplementaryViewProvider =  { collectionView, elementKind, indexPath in
            self.supplementaryView(collectionView: collectionView, indexPath: indexPath, kind: elementKind)
        }
        self.applySnapShot()
    }
    
    private func setupViewCSS() {
        self.view.backgroundColor = css?.backgroundColor ?? .black
        self.collectionView.backgroundColor = css?.backgroundColor ?? .black
    }
    
    /// Confiure CollectionView cells based on the existing state
    /// - Parameters:
    ///   - collectionView: UICollectionView
    ///   - indexPath: IndexPath from DataSource
    ///   - item: Item
    /// - Returns: UICollectionViewCell
    private func cell(collectionView: UICollectionView,
                      indexPath: IndexPath,
                      item: ImmersiveShimmerItem) -> UICollectionViewCell? {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.shimmerCell, for: indexPath) as? ShimmerCollectionViewCell
        let section: ImmersiveShimmerSectionType = self.snapShot?.sectionIdentifiers[indexPath.section] ?? .category
        cell?.showImmersiveLoading(with: section)
        return cell
    }
    
    private func supplementaryView(collectionView: UICollectionView,
                                   indexPath: IndexPath,
                                   kind: String) -> UICollectionReusableView? {
        if kind == UICollectionView.elementKindSectionHeader {
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: CellIdentifier.shimmerCell, for: indexPath) as? ImmersiveShimmerHeader
            headerView?.showShimmerView()
            return headerView
        } else {
            return nil
        }
    }
    
    /// Apply SnapShot based on the DiaffableDatasource changes
    private func applySnapShot() {
        guard self.collectionView != nil else { return }
        snapShot = ImmersiveShimmerSnapshot()
        snapShot?.appendSections([.category, .horizontalGrid, .verticalImmersiveGrid, .verticalGrid])
        snapShot?.appendItems(ImmersiveShimmerItem.loadingItems(with: .category), toSection: .category)
        snapShot?.appendItems(ImmersiveShimmerItem.loadingItems(with: .horizontalGrid), toSection: .horizontalGrid)
        snapShot?.appendItems(ImmersiveShimmerItem.loadingItems(with: .verticalImmersiveGrid), toSection: .verticalImmersiveGrid)
        snapShot?.appendItems(ImmersiveShimmerItem.loadingItems(with: .verticalGrid), toSection: .verticalGrid)
        
        guard let snapShot = snapShot else { return }
        diffDatasource?.apply(snapShot, animatingDifferences: true, completion: {[weak self] in
            guard let self = self, self.collectionView != nil else {return}
            self.collectionView.setContentOffset(.zero, animated: false)
        })
    }
}
