//
//  Cell.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 23/11/22.
//

import Foundation
import UIKit

class ShimmerCollectionViewCell: UICollectionViewCell {
    
    private var shimmerLayer: CALayer?
    private var shimmerFooterLayer: CALayer?

    private var categoryView: UIView?
    private var footerView: UIView?

    private var isImmersive = false
    
    private var css: ShimmerViewCSS? {
        EpcotLobbyManager.shared?.css.shimmerViewCSS
    }
    private var shimmerGradients: ShimmerGradients {
        self.css?.gradients ?? ShimmerGradients()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        shimmerLayer?.removeFromSuperlayer()
        shimmerFooterLayer?.removeFromSuperlayer()
    }
    
    func showLoading(with type: EpcotShimmerSectionType) {
        self.layoutIfNeeded()
        self.layer.masksToBounds = true
        self.isImmersive = false
        self.getRoundedCorners(OfRadius: css?.cornerRadius ?? 6.0)
        
        switch type {
        case .teasers, .preBannerGames:
            self.getRoundedCorners(OfRadius: EpcotLobbyManager.shared?.css.lobbyCornerRadius ?? kLobbyCornerRadius)
            self.showLoading()
        case .categories:
            self.shimmerForCategory()
        }
    }
    
    func showImmersiveLoading(with type: ImmersiveShimmerSectionType) {
        self.layoutIfNeeded()
        self.layer.masksToBounds = true
        self.isImmersive = true
        self.getRoundedCorners(OfRadius: type == .category ? 0.0 : (css?.cornerRadius ?? 8.0))
        
        switch type {
        default:
            self.showLoading()
        }
    }
}

extension ShimmerCollectionViewCell {
    
    private func showLoading() {
        self.shimmerLayer?.removeFromSuperlayer()
        self.shimmerLayer = CAGradientLayer.applyShimmerGradient(with: shimmerGradients, on: self)
    }
        
    private func shimmerForCategory() {
        self.getRoundedCorners(OfRadius: self.frame.size.height/2)
        self.categoryView?.removeFromSuperview()
        self.shimmerLayer?.removeFromSuperlayer()
        self.categoryView = UIView()
        if let view = self.categoryView {
            view.translatesAutoresizingMaskIntoConstraints = false
            self.addSubview(view)
            NSLayoutConstraint.activate([
                view.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 0.25),
                view.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 0.5),
                view.centerXAnchor.constraint(equalTo: self.centerXAnchor, constant: 0),
                view.centerYAnchor.constraint(equalTo: self.centerYAnchor, constant: 0),
            ])
            view.getRoundedCorners(OfRadius: self.frame.size.height/8)
            self.shimmerLayer = CAGradientLayer.applyShimmerGradient(with: shimmerGradients, on: view)
        }
        self.layer.borderColor = (self.css?.borderColor ?? .gray).cgColor
        self.layer.borderWidth = 1.0
        self.categoryView?.backgroundColor = self.css?.borderColor ?? .clear
    }
}
