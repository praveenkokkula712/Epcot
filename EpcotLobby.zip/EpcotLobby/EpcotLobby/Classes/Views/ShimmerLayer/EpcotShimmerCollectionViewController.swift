//
//  EpcotShimmerCollectionViewController.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 23/11/22.
//

import Foundation
import UIKit

enum EpcotShimmerSectionType: Int, CaseIterable {
    case categories ,teasers, preBannerGames
    
    func createSection() -> NSCollectionLayoutSection {
        switch self {
        case .categories: return EpcotLobbyShimmerLayoutSection.categoryPillLayoutSection()
        case .teasers: return EpcotLobbyShimmerLayoutSection.carouselTeasersLayoutSection()
        case .preBannerGames: return EpcotLobbyShimmerLayoutSection.gamesLayoutSection()
        }
    }
}

enum EpcotShimmerItem: Hashable {
    case loading(UUID)
    
    static func loadingItems(with type: EpcotShimmerSectionType) -> [EpcotShimmerItem] {
        var count = 0
        switch type {
        case .categories, .teasers: count = 10
        case .preBannerGames: count = 3
        }
        return Array(repeatingExpression: EpcotShimmerItem.loading(UUID()), count: count)
    }
}

class EpcotShimmerCollectionViewController: UICollectionViewController {
    
    private var diffDatasource: EpcotShimmerDatasource?
    private var snapShot: EpcotShimmerSnapshot?
    
    private var css: ShimmerViewCSS? {
        EpcotLobbyManager.shared?.css.shimmerViewCSS
    }
    
    /// Create a Collection view layout by setting up CollectionViewCompositional Layout
    /// - Returns: UICollectionVIew
    private var compositionalLayout: UICollectionViewLayout {
        let layout = UICollectionViewCompositionalLayout { (sectionIndex: Int,
                                                            layoutEnvironment: NSCollectionLayoutEnvironment) -> NSCollectionLayoutSection? in
            guard let sectionIdentifiers = self.snapShot?.sectionIdentifiers else {
                return CustomLayoutSection.inAppAdsLayoutSection()
            }
            let section = sectionIdentifiers[sectionIndex].createSection()
            return section
        }
        return layout
    }
    
    //MARK: - Initialisation methods.
    /// Convenience init declaration
    required convenience init?(coder: NSCoder) {
        self.init(coder: coder)
    }
    
    /// Convenience delcaration for collection view initialization.
    convenience init() {
        self.init(collectionViewLayout: UICollectionViewFlowLayout())
    }
        
    //MARK: - View controller life cycle methods.
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupCollectionView()
        self.configureDatasource()
        self.setupViewCSS()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.snapShot = nil
        self.diffDatasource = nil
        self.collectionView = nil
    }
    
    //MARK: - Collection View setup and data update methods.
    /// Setup collection View will update the collection view layout info and sets the required delegate and data source information.
    private func setupCollectionView() {
        self.collectionView.setupDefaultConfiguration()
        self.collectionView.register(ShimmerCollectionViewCell.self,
                                     forCellWithReuseIdentifier: CellIdentifier.shimmerCell)
        self.collectionView.collectionViewLayout = self.compositionalLayout
        self.collectionView.isUserInteractionEnabled = false
        self.collectionView.backgroundColor = self.css?.backgroundColor ?? .black
    }
    
    /// Configure Diffable DataSource
    private func configureDatasource() {
        guard self.collectionView != nil else { return }
        diffDatasource = EpcotShimmerDatasource(collectionView: self.collectionView, cellProvider: { collectionView, indexPath, itemIdentifier in
            self.cell(collectionView: collectionView, indexPath: indexPath, item: itemIdentifier)
        })
        self.applySnapShot()
    }
    
    private func setupViewCSS() {
        self.view.backgroundColor = css?.backgroundColor ?? .black
        self.collectionView.backgroundColor = css?.backgroundColor ?? .black
    }
    
    /// Confiure CollectionView cells based on the existing state
    /// - Parameters:
    ///   - collectionView: UICollectionView
    ///   - indexPath: IndexPath from DataSource
    ///   - item: Item
    /// - Returns: UICollectionViewCell
    private func cell(collectionView: UICollectionView,
              indexPath: IndexPath,
              item: EpcotShimmerItem) -> UICollectionViewCell? {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.shimmerCell, for: indexPath) as? ShimmerCollectionViewCell
        let section: EpcotShimmerSectionType = self.snapShot?.sectionIdentifiers[indexPath.section] ?? .categories
        cell?.showLoading(with: section)
        return cell
    }
    
    /// Apply SnapShot based on the DiaffableDatasource changes
    private func applySnapShot() {
        guard self.collectionView != nil else { return }
        snapShot = EpcotShimmerSnapshot()
        snapShot?.appendSections([.categories, .teasers, .preBannerGames])
        snapShot?.appendItems(EpcotShimmerItem.loadingItems(with: .categories), toSection: .categories)
        snapShot?.appendItems(EpcotShimmerItem.loadingItems(with: .teasers), toSection: .teasers)
        snapShot?.appendItems(EpcotShimmerItem.loadingItems(with: .preBannerGames), toSection: .preBannerGames)
        
        guard let snapShot = snapShot else { return }
        diffDatasource?.apply(snapShot, animatingDifferences: true, completion: {[weak self] in
            guard let self = self, self.collectionView != nil else {return}
            self.collectionView.setContentOffset(.zero, animated: false)
        })
    }
}
