//
//  ImmersiveShimmerHeader.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 29/11/22.
//

import Foundation

class ImmersiveShimmerHeader: UICollectionReusableView {
    
    private var shimmerView: UIView?
    private var shimmerLayer: CALayer?
    
    private var css: ShimmerViewCSS? {
        EpcotLobbyManager.shared?.css.shimmerViewCSS
    }
    private var shimmerGradients: ShimmerGradients {
        self.css?.gradients ?? ShimmerGradients()
    }

    func showShimmerView() {
        self.shimmerView = UIView()
        if let view = self.shimmerView {
            view.translatesAutoresizingMaskIntoConstraints = false
            self.addSubview(view)
            NSLayoutConstraint.activate([
                view.heightAnchor.constraint(equalToConstant: kShimmerTitleHeight),
                view.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 0.35),
                view.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 0),
                view.centerYAnchor.constraint(equalTo: self.centerYAnchor, constant: 0),
            ])
            view.getRoundedCorners(OfRadius: kShimmerTitleHeight/2)
            shimmerLayer = CAGradientLayer.applyShimmerGradient(with: shimmerGradients, on: view)
        }
        self.shimmerView?.backgroundColor = self.css?.borderColor ?? .clear
    }
}
