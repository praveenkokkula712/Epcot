//
//  BingoWidgetAccessID.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 07/06/24.
//

import Foundation

struct BingoWidgetAccessID {
    static let HEADER_TITLE = "BingoWidget_Header_Title"
    static let SEE_ALL = "BingoWidget_SeeAll_Button"

    static let RIBBON = "BingoWidget_Ribbon"
    static let IMAGE = "BingoWidget_Image"
    static let TIMER = "BingoWidget_Timer"
    static let GAME_FEATURE_BADGE = "BingoWidget_GameFeatureBadge"
    static let FAVORITE = "BingoWidget_FavoriteButton"
    static let INFO = "BingoWidget_InfoButton"
    static let ROOM_NAME = "BingoWidget_RoomName"
    static let COMBINED_ROOMS = "BingoWidget_CombinedRooms"
    static let JACKPOT_AMOUNT = "BingoWidget_JackpotAmount"
    static let LINK = "BingoWidget_Link"
    static let PLAYERS = "BingoWidget_Players"
    static let TICKET_PRICE = "BingoWidget_TicketPrice"
    static let WINNINGS = "BingoWidget_Winnings"
    static let PROGRESS_BAR = "BingoWidget_ProgressBar"

    static let INFO_ROOM_TITLE = "BingoWidget_InfoRoomTitle"
    static let INFO_ROOM_DETAILS = "BingoWidget_InfoRoomDetails"
    static let INFO_CLOSE = "BingoWidget_InfoClose"
    static let INFO_FAVORITE = "BingoWidget_InfoFavorite"
    static let PREBUY = "BingoWidget_PreBuy"
    static let PLAY = "BingoWidget_Play"
}
