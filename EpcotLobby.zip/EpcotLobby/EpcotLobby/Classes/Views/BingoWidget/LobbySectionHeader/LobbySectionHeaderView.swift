//
//  LobbySectionHeaderView.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 05/01/24.
//

import SwiftUI
import Utility

struct LobbySectionHeaderView: View {
    let title: String
    let ctaTitle: String
    let onCTA: () -> Void
    private let styles = LobbySectionHeaderCSS()

    var body: some View {
        HStack(spacing: 0) {
            Text(title)
                .font(styles.titleFont)
                .foregroundColor(styles.titleColor)
                .padding(.leading, 16.0)
                .accessibilityIdentifier(BingoWidgetAccessID.HEADER_TITLE)

            Spacer()

            ScalableButton(action: onCTA) {
                Text(ctaTitle)
                    .font(styles.ctaFont)
                    .foregroundColor(styles.ctaColor)
            }
            .padding(.horizontal, 16.0)
            .accessibilityIdentifier(BingoWidgetAccessID.SEE_ALL)
        }
        .frame(height: styles.height)
    }
}

struct LobbySectionHeaderView_Previews: PreviewProvider {
    static var previews: some View {
        LobbySectionHeaderView(
            title: "Bingo Rooms",
            ctaTitle: "See All",
            onCTA: { }
        )
    }
}
