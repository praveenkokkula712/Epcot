//
//  LobbySectionHeaderCSS.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 08/01/24.
//

import Foundation
import SwiftUI
import Utility

class LobbySectionHeaderCSS {
    let height: Double
    let titleColor: Color
    let titleFont: Font
    let ctaColor: Color
    let ctaFont: Font

    init(bingoCss: BingoWidgetCSS? = nil) {
        let css = bingoCss ?? Self.lobbyCSS?.bingoWidgetViewCss
        height = Self.defalutHeight
        titleColor = Color(css?.widgetHeaderTextCss.color ?? Self.defalutTitleColor)
        titleFont = Font(css?.widgetHeaderTextCss.font ?? .systemFont(ofSize: 16)) ?? Self.defalutTitleFont
        ctaColor = Color(css?.widgetHeaderSeeAllCss.color ?? Self.defalutCTAColor)
        ctaFont = Font(css?.widgetHeaderSeeAllCss.font ?? .systemFont(ofSize: 12)) ?? Self.defalutCTAFont
    }
}

extension LobbySectionHeaderCSS: LobbyStylable { }

// MARK: Default Values
extension LobbySectionHeaderCSS {
    private static var defalutHeight: Double { 35.0 }
    private static var defalutTitleColor: UIColor { .init(red: 0.03, green: 0.17, blue: 0.65, alpha: 1) } // #082BA6
    private static var defalutTitleFont: Font { .custom("Poppins-Bold", size: 16) }
    private static var defalutCTAColor: UIColor { .init(red: 0.03, green: 0.17, blue: 0.65, alpha: 1) } // #082BA6
    private static var defalutCTAFont: Font { .custom("Poppins-Bold", size: 12) }
}

