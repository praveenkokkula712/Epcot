//
//  WidgetButton.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 29/12/23.
//

import SwiftUI
import Utility

struct WidgetButton: View {
    enum WidgetButtonType {
        case primary
        case outline
    }

    private let type: WidgetButtonType
    private let text: String
    private let textColor: Color
    private let highlightTextColor: Color
    private let backgroundColor: Color
    private let highlightBackgroundColor: Color
    private let action: () -> Void
    private let strokeColor: Color
    private let buttonFont: Font
    private let styles = BingoWidgetViewCSS()

    init(
        type: WidgetButtonType = .primary,
        text: String,
        textColor: Color,
        highlightTextColor: Color,
        backgroundColor: Color = .clear,
        highlightBackgroundColor: Color = .clear,
        buttonFont: Font,
        action: @escaping () -> Void
    ) {
        self.type = type
        self.text = text
        self.textColor = textColor
        self.highlightTextColor = highlightTextColor
        self.backgroundColor = type == .primary ? backgroundColor : .clear
        self.highlightBackgroundColor = highlightBackgroundColor
        self.strokeColor = type == .primary ? backgroundColor : textColor
        self.action = action
        self.buttonFont = buttonFont
    }

    var body: some View {
        Button(action: action) {
            HStack {
                Spacer()
                Text(text.uppercased())
                    .font(buttonFont)
                Spacer()
            }
            .padding(.vertical, 8.0)
            .overlay(
                RoundedRectangle(cornerRadius: CGFloat(styles.widgetButtonCornerRadius))
                    .stroke(strokeColor, lineWidth: styles.widgetButtonBorderWidth)
            )
        }
        .buttonStyle(
            HighlightStyle(
                color: backgroundColor,
                highlightColor: highlightBackgroundColor,
                textColor: textColor,
                textHighlightColor: highlightTextColor,
                cornerRadius: CGFloat(styles.widgetButtonCornerRadius)
            )
        )
    }
}

// MARK: - Scale with Animation
struct HighlightStyle: ButtonStyle {
    let color: Color
    let highlightColor: Color
    let textColor: Color
    let textHighlightColor: Color
    let cornerRadius: CGFloat

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .contentShape(RoundedRectangle(cornerRadius: cornerRadius))
            .foregroundColor(
                configuration.isPressed ? textHighlightColor : textColor
            )
            .background(
                configuration.isPressed ? highlightColor : color
            )
            .animation(
                .easeOut(duration: 0.2),
                value: configuration.isPressed
            )
            .cornerRadius(cornerRadius)
    }
}

// MARK: - Preview
struct WidgetButton_Previews: PreviewProvider {
    static var previews: some View {
        Rectangle()
            .foregroundColor(Color.gray)
            .overlay(
                VStack {
                    WidgetButton(
                        text: "Button",
                        textColor: .white,
                        highlightTextColor: .white,
                        backgroundColor: Color(red: 1, green: 0.21, blue: 0.54),
                        buttonFont: Font(UIFont(name: "Poppins", size: 10) ?? .systemFont(ofSize: 10, weight: .bold))
                    ) { } // #FE368A
                    
                    WidgetButton(
                        type: .outline,
                        text: "Button",
                        textColor: .white,
                        highlightTextColor: .white,
                        buttonFont: Font(UIFont(name: "Poppins", size: 10) ?? .systemFont(ofSize: 10, weight: .bold))
                    ) { }
                    
                    WidgetButton(
                        type: .outline,
                        text: "Button",
                        textColor: Color(red: 0.03, green: 0.17, blue: 0.65),
                        highlightTextColor: .white,
                        buttonFont: Font(UIFont(name: "Poppins", size: 10) ?? .systemFont(ofSize: 10, weight: .bold))
                    ) { } // #082BA6
                }
                    .frame(width: 160)
                    .padding(.horizontal, 16.0)
            )
    }
}
// MARK: - Helper
extension WidgetButton: LobbyStylable { }

extension WidgetButton {
    private static var textFont:  UIFont {
        UIFont(name: "Poppins", size: 10) ??
            .systemFont(ofSize: 10, weight: .bold)
    }
}
