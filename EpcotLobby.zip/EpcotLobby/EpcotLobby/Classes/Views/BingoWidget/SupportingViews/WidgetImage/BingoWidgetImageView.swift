//
//  BingoWidgetImageView.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 01/01/24.
//

import SwiftUI
import Kingfisher

struct BingoWidgetImageView: View {
    
    // MARK: - Properties
    private let url: String
    private let styles: BingoWidgetViewCSS

    // MARK: - Init
    init(url: String, styles: BingoWidgetViewCSS) {
        self.url = url
        self.styles = styles
    }

    // MARK: - Body
    var body: some View {
        KFImage(URL(string: url))
            .placeholder {
                PlaceHolderImage()
                    .frame(width: size.width, height: size.height)
                    .cornerRadius(size.width / 2)
            }
            .resizable()
            .scaledToFill()
            .frame(width: size.width, height: size.height)
            .cornerRadius(size.width / 2)
            .accessibilityIdentifier(BingoWidgetAccessID.IMAGE)
    }
    
    // MARK: - Design Constants
    private var size: CGSize { styles.imageSize }
}

// MARK: - Preview
struct BingoWidgetImageView_Previews: PreviewProvider {
    static var previews: some View {
        BingoWidgetImageView(url: "", styles: BingoWidgetViewCSS())
    }
}
