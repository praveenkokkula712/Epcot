//
//  WidgetJackpotAmountView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 01/02/24.
//

import SwiftUI

struct WidgetJackpotAmountView: View {

    // MARK: - Properties
    @ObservedObject private var viewModel: WidgetJackpotAmountViewModel
    private let type: WidgetLabel.WidgetLabelType

    // MARK: - Init
    init(amounts: [String], type: WidgetLabel.WidgetLabelType) {
        self.type = type
        viewModel = WidgetJackpotAmountViewModel(items: amounts)
    }

    // MARK: - Body
    var body: some View {
        VStack {
            contentText(viewModel.item)
                .contentTransition(.opacity)
                .transaction { t in
                    t.animation = .smooth
                }
        }
        .accessibilityIdentifier(BingoWidgetAccessID.JACKPOT_AMOUNT)
    }

    // MARK: - Helper
    @ViewBuilder
    private func contentText(_ text: String) -> some View {
        Text(text)
            .font(type.font)
            .foregroundColor(type.textColor(updateTimerColor: false))
            .lineLimit(1)
            .opacity(viewModel.animateOpacity ? 0.2 : 1.0)
            .animation(.linear, value: viewModel.animateOpacity)
            .onAppear {
                viewModel.startItemChangeTimer()
                viewModel.startOpacityTimer()
            }
    }
}

struct WidgetJackpotAmountView_Previews: PreviewProvider {
    static var previews: some View {
        WidgetJackpotAmountView(amounts: ["100", "200"], type: .jackpotAmount)
    }
}
