//
//  WidgetLabelCSS.swift
//  EpcotLobby
//
//  Created by Bandaru Priyanka on 05/01/24.
//

import Foundation
import SwiftUI
import Utility

struct WidgetLabelCSS {
    
    // MARK: Properties
    var timerFont: Font
    let updatedTimerTextFont: Font
    let jackpotAmountFont: Font
    let timerTextColor: Color
    let updatedTimerTextColor: Color
    let jackpotAmountTextColor: Color
    let playerCountColor: Color
    let playerCountFont: Font
    let cardPriceColor: Color
    let cardPriceFont: Font
    let combinedRoomsCardPriceFont: Font
    let winningPriceColor: Color
    let winningPriceFont: Font
    let combinedRoomsWinningPriceFont: Font
    let timerSpace: Float
    let jackpotAmountSpace: Float
    let iconDetailsSpace: Float
    let timerIconSize: CGFloat
    let jackpotAmountIconSize: CGFloat
    let detailsIconSize: CGFloat
    let timerIconColor: Color
    let updatedTimerIconColor: Color
    let jackpotIconColor: Color
    let playerIconColor: Color
    let cardIconColor: Color
    let winningIconColor: Color
    let availableRoomsTextColor: Color
    let availableRoomsTextFont: Font
    
    // MARK: Init
    init(bingoCss: BingoWidgetCSS? = nil) {
        let css = bingoCss ?? Self.lobbyCSS?.bingoWidgetViewCss
        timerTextColor = Color(css?.timerCss?.textCSS.color ?? Self.defaultTimerTextColor )
        updatedTimerTextColor = Color(css?.timerCss?.updatedtimerCSS.color ?? Self.defaultTimerTextColor )
        timerFont = Font(css?.timerCss?.textCSS.font ?? Self.defaultTimerFont)
        updatedTimerTextFont = Font(css?.timerCss?.updatedtimerCSS.font ?? Self.defaultTimerFont)
        timerIconColor = Color(css?.timerCss?.timerIconColor ?? Self.defaultTimerTextColor )
        updatedTimerIconColor = Color(css?.timerCss?.updatedTimerIconColor ?? Self.defaultTimerTextColor )
        timerIconSize = css?.timerCss?.timerIconSize ?? Self.defaultTimerIconSize
        timerSpace = Self.defaultTimerSpace
        
        jackpotAmountTextColor = Color(css?.widgetAmountTextCss.color ?? Self.defaultJackpotAmountTextColor )
        jackpotAmountFont = Font(css?.widgetAmountTextCss.font ?? Self.defaultJackpotAmountFont)
        jackpotAmountIconSize = css?.jackpotIconSize ?? Self.defaultJackpotAmountIconSize
        jackpotAmountSpace = Self.defaultJackpotAmountSpace
        jackpotIconColor = Color(css?.jackpotIconColor ?? Self.defaultJackpotAmountTextColor )
        
        playerCountColor = Color(css?.playerDetails?.iconTextCSS.color ?? Self.defaultIconDetailsColor )
        playerCountFont = Font(css?.playerDetails?.iconTextCSS.font ?? Self.defaultIconDetailsFont)
        playerIconColor = Color(css?.playerDetails?.iconColor ?? Self.defaultIconDetailsColor )
        
        cardPriceColor = Color(css?.cardDetails?.iconTextCSS.color ?? Self.defaultIconDetailsColor )
        cardPriceFont = Font(css?.cardDetails?.iconTextCSS.font ?? Self.defaultIconDetailsFont)
        combinedRoomsCardPriceFont = Font(css?.cardDetails?.combinedRoomsFont ?? Self.defaultIconDetailsFont)
        cardIconColor = Color(css?.cardDetails?.iconColor ?? Self.defaultIconDetailsColor )
        
        winningPriceColor = Color(css?.winDetails?.iconTextCSS.color ?? Self.defaultIconDetailsColor )
        winningPriceFont = Font(css?.winDetails?.iconTextCSS.font ?? Self.defaultIconDetailsFont)
        winningIconColor = Color(css?.winDetails?.iconColor ?? Self.defaultIconDetailsColor )
        combinedRoomsWinningPriceFont = Font(css?.winDetails?.combinedRoomsFont ?? Self.defaultIconDetailsFont)
        
        detailsIconSize = css?.detailsIconSize ?? Self.defaultDetailsIconSize
        iconDetailsSpace = Self.defaultIconDetailsSpace
        
        availableRoomsTextColor = Color(css?.combinedRoomsText?.color ?? Self.defaultCombinedRoomsTextColor )
        availableRoomsTextFont = Font(css?.combinedRoomsText?.font ?? Self.defaultCombinedRoomsTextFont)
        
    }
}

// MARK: - Helper
extension WidgetLabelCSS: LobbyStylable { }

extension WidgetLabelCSS {
    
    private static var defaultTimerFont: UIFont {
        UIFont(name: "Poppins-SemiBold", size: 9) ??
            .systemFont(ofSize: 9, weight: .semibold)
    }
    private static var defaultJackpotAmountFont: UIFont {
        UIFont(name: "Roboto-Bold", size: 16) ??
            .systemFont(ofSize: 16, weight: .bold)
    }
    private static var defaultIconDetailsFont: UIFont {
        UIFont(name: "Poppins-SemiBold", size: 14) ??
            .systemFont(ofSize: 14, weight: .semibold)
    }
    
    private static var defaultTimerTextColor = 
    UIColor(red: 0.26, green: 0.31, blue: 0.53, alpha: 1)// #424E86
    private static var defaultJackpotAmountTextColor = UIColor(red: 1, green: 0.89, blue: 0.19, alpha: 0.3) //#FFE330
    private static var defaultCombinedRoomsTextColor = UIColor(red: 1, green: 0.89, blue: 0.19, alpha: 0.3) //#FFE330
    private static var defaultCombinedRoomsTextFont: UIFont {
        UIFont(name: "Roboto-Bold", size: 16) ??
            .systemFont(ofSize: 16, weight: .bold)
    }
    private static var defaultIconDetailsColor = UIColor.white
    
    private static var defaultTimerSpace: Float { 4.0 }
    private static var defaultJackpotAmountSpace: Float { 8.0 }
    private static var defaultIconDetailsSpace: Float { 2.0 }
    
    private static var defaultTimerIconSize: CGFloat { 10.0 }
    private static var defaultJackpotAmountIconSize: CGFloat { 20.0 }
    private static var defaultDetailsIconSize: CGFloat { 20.0 }

}
