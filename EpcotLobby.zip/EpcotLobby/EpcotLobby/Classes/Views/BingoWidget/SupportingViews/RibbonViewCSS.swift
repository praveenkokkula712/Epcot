//
//  RibbonViewCSS.swift
//  EpcotLobby
//
//  Created by Bandaru Priyanka on 04/01/24.
//

import Foundation
import SwiftUI
import Utility

struct RibbonViewCSS {
    
    // MARK: Properties
    let intersection: Double
    let cornerRadius: Double
    let ribbonColor: Color
    let ribbonCutColor: Color
    let ribbonSize: CGSize
    let textColor: Color
    let textFont: Font

    // MARK: Init
    init(bingoCss: BingoWidgetCSS? = nil) {
        let styles = bingoCss ?? Self.lobbyCSS?.bingoWidgetViewCss
        intersection = Self.defaultIntersection
        cornerRadius = Self.defaultCornerRadius
        ribbonColor = Color(styles?.ribbonViewBackgroundColor ?? Self.defaultRibbonColor )
        ribbonCutColor = Self.defaultRibbonCutColor
        ribbonSize = Self.defaultRibbonSize
        textColor = Color(styles?.ribbonTitleCSS.color ?? Self.defaultTextColor )
        textFont = Font(styles?.ribbonTitleCSS.font ?? Self.defaultTextFont)
    }
}

// MARK: - Helper
extension RibbonViewCSS: LobbyStylable { }

extension RibbonViewCSS {
    
    private static var defaultIntersection: Double { 1.0 }
    private static var defaultCornerRadius: Double { 8.0 }
    private static var defaultRibbonColor = UIColor (red: 10/255, green: 54/255, blue: 181/255, alpha: 1) // #0A36B5
    private static var defaultRibbonCutColor: Color { .white }
    private static var defaultRibbonSize: CGSize { CGSize(width: 7.0, height: 13.0) }
    private static var defaultTextColor: UIColor { .white }
    private static var defaultTextFont: UIFont {
        UIFont(name: "Poppins-Bold", size: 8) ??
            .systemFont(ofSize: 8, weight: .medium)
    }
}

