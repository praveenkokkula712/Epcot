//
//  WidgetJackpotAmountViewModel.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 01/02/24.
//

import Foundation
import Combine
import ConfigModule

class WidgetJackpotAmountViewModel: ObservableObject {

    // MARK: - Properties
    @Published var item: String = ""
    @Published var animateOpacity = false
    private var index = 0
    private var items = [String]()
    private var tickInterval: Double {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.bingoWidget?.jackpotAmountBlinkTime ?? 0.0
    }
    private var itemChangeTimer: Publishers.Autoconnect<Timer.TimerPublisher>?
    private var opacityTimer: Publishers.Autoconnect<Timer.TimerPublisher>?
    private var itemChageSubscription: AnyCancellable?
    private var opacitySubscription: AnyCancellable?

    // MARK: - Init
    init(items: [String]) {
        self.items = items
        if !items.isEmpty { item = items[0] }
    }

    // MARK: - Timers
    func startItemChangeTimer() {
        guard items.count > 1 else { return }
        itemChangeTimer = Timer.publish(every: tickInterval * 2, on: .main, in: .common)
            .autoconnect()
        itemChageSubscription = itemChangeTimer?
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in
                guard let self else { return }
                if items.count == index + 1 {
                    index = 0
                } else {
                    index = index + 1
                }
                item = items[index]
            }
    }
    
    func startOpacityTimer() {
        guard items.count > 1 else { return }
        opacityTimer = Timer.publish(every: tickInterval, on: .main, in: .common)
            .autoconnect()
        opacitySubscription = opacityTimer?
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in
                guard let self else { return }
                self.animateOpacity.toggle()
            }
    }
}
