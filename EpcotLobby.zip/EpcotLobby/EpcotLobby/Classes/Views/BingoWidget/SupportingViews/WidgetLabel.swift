//
//  WidgetLabel.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 01/01/24.
//

import SwiftUI
import Utility
struct WidgetLabel: View {
    private let type: WidgetLabelType
    private let text: String
    private let iconContent: IconVariant?
    private let jackpotPrices: [String]
    private let updateTimerColor: Bool

    enum WidgetLabelType {
        case timer
        case jackpotAmount
        case users
        case cardPrice(Bool)
        case winnings(Bool)
        case combinedRooms
    }

    init(
        type: WidgetLabelType,
        text: String,
        jackpotPrices: [String] = [],
        iconContent: IconVariant?,
        updateTimerColor: Bool = false
    ) {
        self.type = type
        self.text = text
        self.jackpotPrices = jackpotPrices
        self.iconContent = iconContent
        self.updateTimerColor = updateTimerColor
    }

    var body: some View {
        HStack(spacing: type.spacing) {
            if let icon = iconContent?.icon, let font = iconContent?.font {
                Text(icon)
                    .font(Font(font))
                    .foregroundColor(type.iconColor(updateTimerColor: updateTimerColor))
                    .minimumScaleFactor(0.5)
            }

            switch type {
            case .timer:
                ZStack {
                    placeHolder
                    
                    contentText
                        .contentTransition(.numericText())
                        .transaction { t in
                            t.animation = .smooth
                        }
                }
            case .jackpotAmount:
                WidgetJackpotAmountView(amounts: jackpotPrices, type: type)
            case .users, .cardPrice(_), .winnings(_), .combinedRooms:
                contentText
            }
        }
        .accessibilityElement(children: .combine)
    }
    
    // MARK: - Helper
    @ViewBuilder
    private var contentText: some View {
        Text(text)
            .font(type.font)
            .foregroundColor(type.textColor(updateTimerColor: updateTimerColor))
            .lineLimit(2)
            .minimumScaleFactor(0.5)
    }

    @ViewBuilder
    private var placeHolder: some View {
        let components = text.components(separatedBy: ":")
        let output = components.map { _ in "00" }.joined(separator: ":")
        return Text(output)
            .opacity(0.0)
            .font(type.font)
    }
}

extension WidgetLabel.WidgetLabelType {
    private var styles: WidgetLabelCSS {
        WidgetLabelCSS()
    }

    var spacing: Double {
        switch self {
        case .timer: return Double(styles.timerSpace)
        case .jackpotAmount: return Double(styles.jackpotAmountSpace)
        case .users, .cardPrice, .winnings: return Double(styles.jackpotAmountSpace)
        default: return 0.0
        }
    }

    var imageName: BingoWidgetRoomViewModel.Icon {
        switch self {
        case .timer: return .clock
        case .jackpotAmount: return .jackpot
        case .users: return .players
        case .cardPrice: return .cardIcon
        case .winnings: return .winnings
        default: return .noIconAvailable
        }
    }
    
    var imageSize: Double {
        switch self {
        case .timer: return Double(styles.timerIconSize)
        case .jackpotAmount, .users, .cardPrice, .winnings: return Double(styles.detailsIconSize)
        default: return 0.0
        }
    }
    
    var font: Font {
        switch self {
        case .timer: 
            return styles.timerFont
        case .jackpotAmount:
            return styles.jackpotAmountFont
        case .users:
            return styles.playerCountFont
        case .cardPrice(let isCombinedRoom):
            return isCombinedRoom ? styles.combinedRoomsCardPriceFont : styles.cardPriceFont
        case .winnings(let isCombinedRoom):
            return isCombinedRoom ? styles.combinedRoomsWinningPriceFont : styles.winningPriceFont
        case .combinedRooms:
            return styles.availableRoomsTextFont
        }
    }
    
    func iconColor(updateTimerColor: Bool?) -> Color {
        switch self {
        case .timer:
            return updateTimerColor ?? false ? styles.updatedTimerIconColor : styles.timerIconColor
        case .jackpotAmount:
            return styles.jackpotIconColor
        case .users:
            return styles.playerIconColor
        case .cardPrice(_):
            return styles.cardIconColor
        case .winnings(_):
            return styles.winningIconColor
        default:
            return .clear
        }
    }
    
    func textColor(updateTimerColor: Bool?) -> Color {
        switch self {
        case .timer:
            return updateTimerColor ?? false ? styles.updatedTimerTextColor : styles.timerTextColor
        case .jackpotAmount:
            return styles.jackpotAmountTextColor
        case .users:
            return styles.playerCountColor
        case .cardPrice(_):
            return styles.cardPriceColor
        case .winnings(_):
            return styles.winningPriceColor
        case .combinedRooms:
            return styles.availableRoomsTextColor
        }
    }
}

struct WidgetLabel_Previews: PreviewProvider {
    static var previews: some View {
        if let gamesList = BingoWidgetsStub().gamesList?.first {
            let viewModel = BingoWidgetRoomViewModel(
                model: BingoWidgetRoom(
                    gameLists: [gamesList],
                    favouriteRoomIds: [],
                    roomImage: nil,
                    roomNames: BingoRoomNames(),
                    gameFeatureIcons: BingoRoomIcons(),
                    roomTexts: nil,
                    globalTexts: nil,
                    combinedRoomTexts: BingoRoomSEPTexts(),
                    combinedRooms: BingoWidgetCombinedRooms()
                ),
                roomIcons: BingoRoomIcons(), fetchBingoRooms: {}
            )
            
            VStack {
                WidgetLabel(type: .timer, text: "1:59", iconContent: nil)
                    .padding(2)
                    .background(Color.white)
                    .cornerRadius(12)
                WidgetLabel( type: .jackpotAmount, text: "£9,122.86", iconContent: nil)
                WidgetLabel(type: .users, text: "244", iconContent: nil)
                WidgetLabel(type: .cardPrice(false), text: "£0.81", iconContent: nil)
                WidgetLabel(type: .winnings(false), text: "£0.81", iconContent: nil)
            }
            .padding()
            .background(Color.blue)
        }
        else {
            EmptyView()
        }
    }
}
