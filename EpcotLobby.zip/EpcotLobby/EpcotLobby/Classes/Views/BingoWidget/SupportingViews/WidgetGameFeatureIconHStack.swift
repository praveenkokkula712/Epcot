//
//  WidgetImageHStack.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 01/01/24.
//

import SwiftUI
import Utility

struct WidgetGameFeatureIconHStack: View {
    
    // MARK: Properties
    private let icons: [(icon: String, font: UIFont, color: UIColor)]
    private let disable: Bool
    private let accessibilityIdentifiers: [String]
    private let onIconTap: (Int) -> Void

    // MARK: - Init
    init(
        icons: [(icon: String, font: UIFont, color: UIColor)],
        disable: Bool = false,
        accessibilityIdentifiers: [String],
        onIconTap: @escaping (Int) -> Void = { _ in }
    ) {
        self.icons = icons
        self.disable = disable
        self.accessibilityIdentifiers = accessibilityIdentifiers
        self.onIconTap = onIconTap
    }

    // MARK: Body
    var body: some View {
        if icons.isEmpty {
            EmptyView()
        } else {
            HStack(spacing: 8.0) {
                ForEach(0..<icons.count) { index in
                    let iconContent = icons[index]
                    let accessID = accessibilityIdentifiers[index]
                    ScalableButton {
                        onIconTap(index)
                    } label: {
                        Text(iconContent.icon)
                            .font(Font(iconContent.font))
                            .foregroundColor(iconContent.color.swiftUIColor)
                        
                    }
                    .disabled(disable)
                    .accessibilityIdentifier(accessID)
                }
            }
        }
    }
}
// MARK: - Preview
struct WidgetGameFeatureIconHStack_Previews: PreviewProvider {
    static var previews: some View {
        WidgetGameFeatureIconHStack(
            icons: [
                ("bingo-extra-spin", .boldSystemFont(ofSize: 20), .white),
                ("bingo-icon-whack", .boldSystemFont(ofSize: 20), .white)
            ], 
            accessibilityIdentifiers: [
                BingoWidgetAccessID.FAVORITE,
                BingoWidgetAccessID.INFO
            ]
        )
    }
}
