//
//  RibbonView.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 29/12/23.
//

import SwiftUI

struct RibbonView: View {
    let title: String
    let styles = RibbonViewCSS()

    var body: some View {
        HStack(spacing: 0) {
            Ribbon(intersection: styles.intersection)
                .fill(styles.ribbonCutColor)
                .background(styles.ribbonColor)
                .frame(width: styles.ribbonSize.width, height: styles.ribbonSize.height)

            Rectangle()
                .fill(styles.ribbonColor)
                .cornerRadius(styles.cornerRadius, corners: .topRight)
                .frame(height: styles.ribbonSize.height)
                .overlay(
                    HStack {
                        Text(title)
                            .font(styles.textFont)
                            .foregroundColor(styles.textColor)
                            .padding(.leading, 8.0)
                        Spacer()
                    }
                )
        }
        .accessibilityLabel(title)
        .accessibilityIdentifier(BingoWidgetAccessID.RIBBON)
    }
}

private struct Ribbon: Shape {
    let intersection: CGFloat

    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.maxX - intersection, y: rect.midY))
        return path
    }
}

struct RibbonView_Previews: PreviewProvider {
    static var previews: some View {
        RibbonView(title: "Our Biggest Game Plays 2nd June!")
    }
}
