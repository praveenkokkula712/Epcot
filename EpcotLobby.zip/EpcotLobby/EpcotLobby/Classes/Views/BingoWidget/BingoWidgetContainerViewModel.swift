//
//  BingoWidgetContainerViewModel.swift
//  CasinoAPI
//
//  Created by Yemireddi Sateesh on 24/01/24.
//

import Foundation
import CasinoAPI
import ConfigModule

class BingoWidgetContainerViewModel {
    
    // MARK: - Properties
    let models: [GamesList]
    let favouriteRoomIds: [String]
    let roomImages: [BingoRoomImage]
    var bingoRooms = [BingoWidgetRoom]()
    let roomIcons: BingoRoomIcons
    let combinedRooms: BingoWidgetCombinedRooms
    let seeAllAction: () -> Void
    let fetchBingoRooms: () -> Void
    
    private let roomNames: BingoRoomNames
    private let gameFeatureIcons: BingoRoomIcons
    private let roomTexts: BingoRoomTexts
    private let globalTexts: BingoRoomTexts
    private let combinedRoomTexts: BingoRoomSEPTexts
    
    // MARK: - Init
    init(
        models: [GamesList],
        favouriteRoomIds: [String],
        roomImages: [BingoRoomImage],
        roomNames: BingoRoomNames,
        gameFeatureIcons: BingoRoomIcons,
        roomIcons: BingoRoomIcons,
        roomTexts: BingoRoomTexts,
        globalTexts: BingoRoomTexts,
        combinedRoomTexts: BingoRoomSEPTexts,
        combinedRooms: BingoWidgetCombinedRooms,
        seeAllAction: @escaping () -> Void,
        fetchBingoRooms: @escaping () -> Void
    ) {
        self.models = models
        self.favouriteRoomIds = favouriteRoomIds
        self.roomImages = roomImages
        self.roomNames = roomNames
        self.gameFeatureIcons = gameFeatureIcons
        self.roomIcons = roomIcons
        self.roomTexts = roomTexts
        self.globalTexts = globalTexts
        self.combinedRoomTexts = combinedRoomTexts
        self.combinedRooms = combinedRooms
        self.seeAllAction = seeAllAction
        self.fetchBingoRooms = fetchBingoRooms
        self.createBingoRooms()
    }

    func createBingoRooms() {
        var bingoVariants: [String] = []
        let combinedRoomNames: [String] = self.combinedRooms.names.compactMap({ $0.key })
        var notStartedRooms: [BingoWidgetRoom] = []
        var startedRooms: [BingoWidgetRoom] = []

        models.forEach { model in
            if let modelId = model.id, let roomImage = roomImages.first(where: { $0.id == modelId }) {
                
                var gameList: [GamesList] = []
                
                if let variant = model.bingoVariant,
                   !bingoVariants.contains(variant),
                   combinedRoomNames.contains(variant) ?? false {
                    //combined room
                    bingoVariants.append(variant)
                    let combinedModels = models.filter({ $0.bingoVariant == variant })
                    if !combinedModels.isEmpty {
                        gameList.append(contentsOf: combinedModels)
                    }
                } else {
                    gameList.append(model)
                }
                
                let room = BingoWidgetRoom(
                    gameLists: gameList,
                    favouriteRoomIds: favouriteRoomIds,
                    roomImage: roomImage,
                    roomNames: roomNames,
                    gameFeatureIcons: gameFeatureIcons,
                    roomTexts: roomTexts,
                    globalTexts: globalTexts,
                    combinedRoomTexts: combinedRoomTexts,
                    combinedRooms: combinedRooms
                )
                if room.isGameStarted {
                    startedRooms.append(room)
                } else {
                    notStartedRooms.append(room)
                }
            }
        }
        //moving all started rooms to last position
        notStartedRooms.append(contentsOf: startedRooms)
        bingoRooms = notStartedRooms
        bingoRooms = Array(bingoRooms.prefix(maximumNumberOfWidgets))
    }

    // MARK: - Helper
    var maximumNumberOfWidgets: Int {
        let numberOfWidgets = DynaconAPIConfiguration.shared?.posAppConfig?
            .odrAws?.bingoWidget?.maximumNumberOfWidgets ?? 0
        return min(models.count, numberOfWidgets)
    }
}
