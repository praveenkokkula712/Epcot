//
//  BingoWidgetRoomViewModel+Tracker.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 29/02/24.
//

import Foundation
import TrackerClient

extension BingoWidgetRoomViewModel {
    
    func trackEvent(for eventDetails: EpcotEventDetails) {
        DispatchQueue(label: kTrackEventQueue).async {
            let log = InteractionLog(categoryEvent: EpcotEventCategory.bingoWidget.rawValue,
                                     actionEvent: EpcotEventAction.click.rawValue,
                                     labelEvent: EpcotEventLabel.games.rawValue,
                                     locationEvent: EpcotEventLocation.lobby.rawValue,
                                     eventDetails: eventDetails.rawValue,
                                     positionEvent: self.title,
                                     userID: EntainContext.user?.accountId ?? "")
            let event = TrackerEvent(type: EventType.bingo_widget,
                                     log: log,
                                     tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}
