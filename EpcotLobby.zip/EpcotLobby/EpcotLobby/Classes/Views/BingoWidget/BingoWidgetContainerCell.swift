//
//  BingoWidgetContainerCell.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 29/12/23.
//

import UIKit

class BingoWidgetContainerCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
