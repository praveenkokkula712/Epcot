//
//  GameFeatureBadgeType.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 08/02/24.
//

import Foundation

enum GameFeatureBadgeType: String, RawRepresentable {
    case none = ""
    case beatChaser = "beat_the_chaser"
    case bonusCash = "bonus_cash"
    case bonusSpins = "bonus_spins"
    case bonusTickets = "bonus_tickets"
    case cashout = "cashout"
    case cashpot = "cashpot"
    case countryMiles = "country_miles"
    case deal = "deal_or_nodeal"
    case everyoneWins = "everyone_wins"
    case freeTickets = "free_tickets"
    case hotBall = "hot_ball"
    case jumpingPot = "jumping_pot"
    case liveStreaming = "live_streaming"
    case multiPrice = "multi_price"
    case physicalPrize = "physical_prize"
    case prizeDrop = "prize_drop"
    case prizeWheel = "prize_wheel"
    case rollOnPart = "roll_on_part"
    case royaleInsurance = "royale_insurance"
    case scratchCard = "scratch_card"
    case sessionBingo = "session_bingo"
    case sideBets = "side_bets"
    case slidingPot = "sliding_pot"
    case slingoExtraBall = "slingo_extra_ball"
    case slingoMultiStake = "slingo_multi_stake"
    case slotsRacePodium = "slots-race-podium"
    case superBooks = "SuperBooks"
    case superLinks = "Superlinks"
    case timedJackpot = "timed_jackpot"
    case whackABingo = "whack_a_bingo"
    case oneTG = "1togo"
    case twoTG = "2togo"
}

extension GameFeatureBadgeType {
    var attributes: GameFeatureBadgeAttributes {
        let styles = GameFeatureBadgeCSS()
        switch self {
        case .none:
            return .init(color: .clear, backgroundColor: .clear)
        case .beatChaser:
            return .init(
                color: styles.beatChaserColor,
                backgroundColor: styles.beatChaserBackgroundColor
            )
        case .bonusCash:
            return .init(
                color: styles.bonusCashColor,
                backgroundColor: styles.bonusCashBackgroundColor
            )
        case .bonusSpins:
            return .init(
                color: styles.bonusSpinsColor,
                backgroundColor: styles.bonusSpinsBackgroundColor
            )
        case .bonusTickets:
            return .init(
                color: styles.bonusTicketsColor,
                backgroundColor: styles.bonusTicketsBackgroundColor
            )
        case .cashout:
            return .init(
                color: styles.cashOutColor,
                backgroundColor: styles.cashOutBackgroundColor
            )
        case .cashpot:
            return .init(
                color: styles.cashPotColor,
                backgroundColor: styles.cashPotBackgroundColor
            )
        case .countryMiles:
            return .init(
                color: styles.countryMilesColor,
                backgroundColor: styles.countryMilesBackgroundColor
            )
        case .deal:
            return .init(
                color: styles.dealColor,
                backgroundColor: styles.dealBackgroundColor
            )
        case .everyoneWins:
            return .init(
                color: styles.everyOneWinsColor,
                backgroundColor: styles.everyOneWinsBackgroundColor
            )
        case .freeTickets:
            return .init(
                color: styles.freeTicketsColor,
                backgroundColor: styles.freeTicketsBackgroundColor
            )
        case .hotBall:
            return .init(
                color: styles.hotBallColor,
                backgroundColor: styles.hotBallBackgroundColor
            )
        case .jumpingPot:
            return .init(
                color: styles.jumpingPotColor,
                backgroundColor: styles.jumpingPotBackgroundColor
            )
        case .liveStreaming:
            return .init(
                color: styles.liveStreamingColor,
                backgroundColor: styles.liveStreamingBackgroundColor
            )
        case .multiPrice:
            return .init(
                color: styles.multiPriceColor,
                backgroundColor: styles.multiPriceBackgroundColor
            )
        case .physicalPrize:
            return .init(
                color: styles.physicalPrizeColor,
                backgroundColor: styles.physicalPrizeBackgroundColor
            )
        case .prizeDrop:
            return .init(
                color: styles.prizeDropColor,
                backgroundColor: styles.prizeDropBackgroundColor
            )
        case .prizeWheel:
            return .init(
                color: styles.prizeWheelColor,
                backgroundColor: styles.prizeWheelBackgroundColor,
                borderColor: styles.prizeWheelBorderColor,
                borderRadius: styles.prizeWheelBorderRadius,
                borderWidth: styles.prizeWheelBorderThickness
            )
        case .rollOnPart:
            return .init(
                color: styles.rollOnColor,
                backgroundColor: styles.rollOnBackgroundColor
            )
        case .royaleInsurance:
            return .init(
                color: styles.bingoInsuranceColor,
                backgroundColor: styles.bingoInsuranceBackgroundColor
            )
        case .scratchCard:
            return .init(
                color: styles.scratchCardColor,
                backgroundColor: styles.scratchCardBackgroundColor
            )
        case .sessionBingo:
            return .init(
                color: styles.sessionBingoColor,
                backgroundColor: styles.sessionBingoBackgroundColor
            )
        case .sideBets:
            return .init(
                color: styles.sideBetsColor,
                backgroundColor: styles.sideBetsBackgroundColor
            )
        case .slidingPot:
            return .init(
                color: styles.slidingPotColor,
                backgroundColor: styles.slidingPotBackgroundColor
            )
        case .slingoExtraBall:
            return .init(
                color: styles.extraSpinColor,
                color2: styles.extraSpinColor2,
                backgroundColor: styles.extraSpinBackgroundColor
            )
        case .slingoMultiStake:
            return .init(
                color: styles.multiPriceColor,
                backgroundColor: styles.multiPriceBackgroundColor
            )
        case .slotsRacePodium:
            return .init(
                color: styles.slotsRacePodiumColor,
                backgroundColor: styles.slotsRacePodiumBackgroundColor
            )
        case .superBooks:
            return .init(
                color: styles.superBooksColor,
                backgroundColor: styles.superBooksBackgroundColor
            )
        case .superLinks:
            return .init(
                color: styles.superLinkColor,
                backgroundColor: styles.superLinkBackgroundColor
            )
        case .timedJackpot:
            return .init(
                color: styles.timedJackpotColor,
                backgroundColor: styles.timedJackpotBackgroundColor
            )
        case .whackABingo:
            return .init(
                color: styles.whackBingoColor,
                backgroundColor: styles.whackBingoBackgroundColor
            )
        case .oneTG, .twoTG:
            return .init(
                color: styles.ntgColor,
                backgroundColor: styles.ntgBackgroundColor,
                transform: styles.ntgTransform
            )
        }
    }
}
