//
//  BingoWidgetRoom.swift
//  CasinoAPI
//
//  Created by Yemireddi Sateesh on 25/01/24.
//

import Foundation
import CasinoAPI
import ConfigModule

struct BingoWidgetRoom: Identifiable {
    
    // MARK: - Properties
    var id = ""

    // MARK: - Games List
    var gameLists: [GamesList] = []
    
    // GAME LIST PROPERITES FROM BLS API
    var isFavourited = false
    var cardPrice = 0.0
    var enablePreBuy = false
    var jackpotPrices = [Double]()
    var gameFeatureBadges = [GameFeatureBadge]()
    var name = ""
    var startInTime = 0
    var numbersOfPlayers = 0
    var winPrizeAmount = 0.0
    var bingoType = ""
    var lockRoom = false
    var currency = ""
    var showLinkIcon = false
    var lobbyInactive = false
    var insurance = false

    // ROOM IMAGE PROPERTIES FROM SITE-CORE
    var infoTitle = ""
    var infoDetails = ""
    var gameImageURL = ""
    var ribbonText = ""
    var errorMessageTitle = ""
    var errorMessageDetails = ""
    
    // STRINGS FROM SITECORE
    var preBuyButtonTitle = ""
    var playButtonTitle = ""
    var playingSoonText = ""
    var startedText = ""
    var roomsAvailableText = ""
    
    // COMBINED ROOM PROPERITES
    var isCombinedRoom = false
    var combinedRoomsCount = 0
    var cardPriceText = ""
    var winPrizeText = ""
    
    // MARK: - Init
    init(
        gameLists: [GamesList],
        favouriteRoomIds: [String],
        roomImage: BingoRoomImage?,
        roomNames: BingoRoomNames,
        gameFeatureIcons: BingoRoomIcons,
        roomTexts: BingoRoomTexts?,
        globalTexts: BingoRoomTexts?,
        combinedRoomTexts: BingoRoomSEPTexts,
        combinedRooms: BingoWidgetCombinedRooms
    ) {
        
        guard let gameList = gameLists.first else {
            return
        }
        
        self.id = gameList.id ?? ""
        self.gameLists = gameLists
        
        if self.gameLists.count > 1 {
            self.isCombinedRoom = true
            self.combinedRoomsCount = gameLists.count
            if let _ = EntainContext.user?.accountName {
                let list = self.gameLists.compactMap({ $0.id })
                let favouriteRoomIdsSet = Set(favouriteRoomIds)
                let listSet = Set(list)
                self.isFavourited = listSet.isSubset(of: favouriteRoomIdsSet)
            }
        } else {
            self.isFavourited = favouriteRoomIds.contains(self.id)
        }
        
        // TODO: Check with Bingo team for the commented and required properites.
        // Game list
        self.cardPrice = gameList.cardPriceInPlayerCurrency?.cash ?? 0
        self.enablePreBuy = gameList.prebuyEnabled ?? false
        if let jackportPrices = gameList.pjpsInPlayerCurrency {
            jackportPrices.forEach {
                if let price = $0.value?.cash {
                    self.jackpotPrices.append(price)
                }
            }
        }
        self.gameFeatureBadges = getGameFeatureBadges(
            keys: gameList.features,
            featureIcons: gameFeatureIcons
        )
        self.name = isCombinedRoom ? getText(from: gameList.bingoVariant, type: .roomName(combinedRooms)) : getName(roomId: roomImage?.id, roomNames: roomNames) ?? gameList.name ?? ""
        self.startInTime = gameList.status?.stateEndTime ?? 0
        self.numbersOfPlayers = gameLists.compactMap { $0.numberOfPlayers }.reduce(0, +)
        self.winPrizeAmount = gameList.potInPlayerCurrency?.cash ?? 0
        self.bingoType = gameList.bingoType ?? ""

        //      self.lockRoom = gameList.gameTags?.contains(<#T##other: Collection##Collection#>)
        self.currency = currentCurrency(gameList: gameList)
        self.showLinkIcon = gameList.features?.contains("linked_game") ?? false
        self.lobbyInactive = gameList.lobbyInactive ?? false
        self.insurance = gameList.insurance ?? false
        
        // Room image
        self.infoTitle = roomImage?.title ?? ""
        self.infoDetails = roomImage?.details ?? ""
        self.gameImageURL = isCombinedRoom ? getText(from: gameList.bingoVariant, type: .roomImageUrl(combinedRooms)) : roomImage?.imageURLString ?? ""
        self.ribbonText = roomImage?.label ?? ""
        self.errorMessageTitle = roomImage?.errorMessageTitle ?? ""
        
        // Room Texts
        self.playingSoonText = globalTexts?.playingSoon ?? ""
        self.startedText = globalTexts?.startedTimerNotation ?? ""
        self.roomsAvailableText = String.init(format: (globalTexts?.roomsAvailable ?? ""), "\(self.combinedRoomsCount)")
        self.preBuyButtonTitle = roomTexts?.preBuyButtonText ?? ""
        self.playButtonTitle = roomTexts?.playNowButtonText ?? ""
        
        // For CombinedRooms
        if isCombinedRoom {
            self.cardPriceText = getText(from: gameList.bingoVariant, type: .cardPrice(combinedRoomTexts))
            self.winPrizeText = getText(from: gameList.bingoVariant, type: .winPrize(combinedRoomTexts))
        }
    }
    
    // MARK: - Helper
    var ids: [String] {
        self.gameLists.compactMap({ $0.id })
    }
    
    var isGameStarted: Bool {
        let timeInterval = startInTime
        let date = Date(timeIntervalSince1970: TimeInterval(timeInterval))
        let result = Date().compare(date)
        
        guard timeInterval != 0 else {
            return true
        }
        guard result == .orderedAscending else {
            return true
        }
        return false
    }
    
    private func currentCurrency(gameList: GamesList) -> String {
        let symbolPair = DynaconAPIConfiguration.shared?
            .posAppConfig?
            .cashier?
            .currencySymbol
        let currency = gameList.currencies?.first?.split(separator: "_").last ?? ""
        return symbolPair?[String(currency)] ?? ""
    }
    
    private func getName(roomId: String?, roomNames: BingoRoomNames) -> String {
        guard let roomId else { return "" }
        return roomNames[roomId] ?? ""
    }
    
    private func getGameFeatureBadges(keys: [String]?, featureIcons: BingoRoomIcons?) -> [GameFeatureBadge] {
        var badges = [GameFeatureBadge]()
        keys?.forEach { key in
            var iconName = featureIcons?[key] ?? ""
            let type = GameFeatureBadgeType(rawValue: key) ?? .none
            if !iconName.isEmpty {
                badges.append(GameFeatureBadge(type: type, iconName: iconName))
            } else {
                if keys?.contains("ntogo") ?? false {
                    var tg = ""
                    if type == .oneTG { tg = "1" }
                    else if type == .twoTG { tg = "2" }
                    iconName = "bingo-\(tg)-tg"
                    if !tg.isEmpty {
                        badges.append(GameFeatureBadge(type: type, iconName: iconName))
                    }
                }
            }
        }
        return badges
    }
    
    private func getText(from variant: String?, type: BingoWidgetTextType) -> String {
        guard let variant else { return "" }
        switch type {
        case .roomName(let bingoWidgetCombinedRooms):
            return bingoWidgetCombinedRooms.names[variant] ?? ""
        case .roomImageUrl(let bingoWidgetCombinedRooms):
            return bingoWidgetCombinedRooms.images[variant] ?? ""
        case .cardPrice(let bingoRoomSEPTexts):
            let priceText = bingoRoomSEPTexts.priceText
            return bingoRoomSEPTexts[variant, priceText] ?? ""
        case .winPrize(let bingoRoomSEPTexts):
            let prizeText = bingoRoomSEPTexts.prizeText
            return bingoRoomSEPTexts[variant, prizeText] ?? ""
        }
    }
    
    enum BingoWidgetTextType {
        case roomName(BingoWidgetCombinedRooms)
        case roomImageUrl(BingoWidgetCombinedRooms)
        case cardPrice(BingoRoomSEPTexts)
        case winPrize(BingoRoomSEPTexts)
    }
}

extension BingoWidgetRoom {
    // MARK: Favourite
    mutating func updateFavourite() {
        self.isFavourited.toggle()
    }
}
