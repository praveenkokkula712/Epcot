//
//  BingoWidgetCSS.swift
//  EpcotLobby
//
//  Created by Bandaru Priyanka on 04/01/24.
//

import Foundation
import SwiftUI
import Utility

struct BingoWidgetViewCSS {
    
    // MARK: Properties
    let cardColor: Color
    let inactiveRoomColor: Color
    let cardSize: CGSize
    let cornerRadius: Float
    let ribbonSize: CGSize
    let timerBackgroundColor: Color
    let alertTimerBackgroundColor: Color
    let favoriteIconColor: Color
    let infoIconColor: Color
    let widgetTitleColor: Color
    let widgetTitleFont: Font
    let linkIconColor: Color
    let lineColor: Color
    let progressBarHeight: CGFloat
    let progressBarColor: Color
    let progressBarTrackColor: Color
    let primaryButtonColor: Color
    let primaryButtonHighlightTextColor: Color
    let primaryButtonHighlightColor: Color
    let secondaryButtonColor: Color
    let secondaryButtonHighlightTextColor: Color
    let secondaryButtonHighlightColor: Color
    let widgetButtonFont: Font
    let widgetButtonCornerRadius: CGFloat
    let widgetButtonBorderWidth: CGFloat
    let imageSize: CGSize
    let infoTitleColor: Color
    let infoTitleFont: Font
    let infoDescriptionColor: Color
    let infoDescriptionFont: Font
    let favoriteIconSize: Float
    let closeIconSize: Float
    let infoFavoriteIconColor: Color
    let closeIConColor: Color
    let infoCardColor: Color
    let infoAnimationDuration: Float
    let infoBlurRadius: Float
    let gameFeatureIconSize: Float
    
    // MARK: Init
    init(bingoCss: BingoWidgetCSS? = nil) {
        let css = bingoCss ?? Self.lobbyCSS?.bingoWidgetViewCss
        cardColor = Color(css?.backgroundColor ?? .white)
        inactiveRoomColor = Color(css?.inactiveBingoWidgetRoomColor ?? Self.defaultInactiveRoomColor)
        cornerRadius = Float(css?.widgetViewcornerRadius ?? Self.defaultCornerRadius)
        cardSize = Self.defaultCardSize
        ribbonSize = Self.defaultRibbonSize
        timerBackgroundColor = Color(css?.timerCss?.timerBackgroundColor ?? Self.defaultTimerColor)
        alertTimerBackgroundColor = Color(css?.timerCss?.alertTimerBackgroundColor ?? Self.defaultUpdatedTimerColor)
        favoriteIconColor = Color(css?.favoriteIconColor ?? Self.defaultFavoriteColor)
        infoIconColor = Color(css?.infoIconColor ?? Self.defaultInfoColor)
        widgetTitleColor = Color(css?.widgetTitleCss.color ?? .white )
        lineColor = Color(css?.dividerColor ??  Self.defaultLineColor)
        progressBarHeight = css?.widgetProgressBarHeight ?? Self.defaultProgressBarHeight
        progressBarColor = Color(css?.widgetProgressBarColor ?? Self.defaultProgressBarColor)
        progressBarTrackColor = Color(css?.widgetProgressBarTrackColor ?? Self.defaultProgressBarTrackColor)
        primaryButtonColor = Color(css?.preBuyWidgetCSS?.backgroundColor ?? Self.defaultPrimaryButtonColor)
        primaryButtonHighlightTextColor = Color(css?.preBuyWidgetCSS?.highlightTextColor ?? Self.defaultPrimaryButtonHighlightTextColor)
        primaryButtonHighlightColor = Color(css?.preBuyWidgetCSS?.highlightBackgroundColor ?? Self.defaultPrimaryButtonBackgroundColor)
        secondaryButtonColor = Color(css?.playWidgetCSS?.backgroundColor ?? Self.defaultSecondaryButtonColor)
        secondaryButtonHighlightTextColor = Color(css?.playWidgetCSS?.highlightTextColor ?? Self.defaultSecondaryButtonHighlightTextColor)
        secondaryButtonHighlightColor = Color(css?.playWidgetCSS?.highlightBackgroundColor ?? Self.defaultSecondaryButtonBackgroundColor)
        widgetTitleFont = Font(css?.widgetTitleCss.font ?? Self.defaultWidgetTitleFont)
        widgetButtonFont = Font(css?.preBuyWidgetCSS?.textCSS.font ?? Self.defaultWidgetButtonFont)
        widgetButtonCornerRadius = css?.preBuyWidgetCSS?.cornerRadius ?? Self.defaultButtonCornerRadius
        widgetButtonBorderWidth = css?.preBuyWidgetCSS?.borderWidth ?? Self.defaultButtonBorderWidth
        imageSize = Self.defaultImageSize
        linkIconColor = Color(css?.linkIconColor ?? Self.defaultLinkColor)
        infoTitleColor = Color(css?.infoTitleCss.color ?? Self.defaultPopupTextColor )
        infoTitleFont = Font(css?.infoTitleCss.font ?? Self.defaultInfoTitleFont)
        infoDescriptionColor = Color(css?.infoDescriptionCss.color ?? Self.defaultPopupTextColor )
        infoDescriptionFont = Font(css?.infoDescriptionCss.font ?? Self.defaultInfoDescriptionFont)
        favoriteIconSize = Float(css?.infoFavoriteIconSize ?? Self.defaultFavoriteIconSize)
        closeIconSize = Float(css?.infoCloseIconSize ?? Self.defaultCloseIconSize)
        infoFavoriteIconColor = Color(css?.infoFavoriteColor ?? Self.defaultPopupTextColor)
           closeIConColor = Color(css?.infoCloseColor ?? Self.defaultPopupTextColor)
        infoCardColor =  Color(css?.infoCardColor ?? Self.defaultInfoPopupCardColor)
        infoAnimationDuration = Float(css?.infoAnimationDuration ?? Self.defaultPopupAnimationDuration)
        infoBlurRadius = Float(css?.infoBlurRadius ?? Self.defaultPopupBlurRadius)
        gameFeatureIconSize = Float(Self.defaultGameFeatureIconSize)
    }
}

// MARK: - Helper
extension BingoWidgetViewCSS: LobbyStylable { }

extension BingoWidgetViewCSS {
    private static var defaultCornerRadius: Double { 8.0 }
    private static var defaultCardSize: CGSize { CGSize(width: 350, height: 200) }
    private static var defaultCardColor: Color { Color(red: 0, green: 104/255, blue: 242/255) } //#0068F2
    private static var defaultInactiveRoomColor: UIColor {
        UIColor.hexStringToUIColor(hex: "#6688FF", withAlpha: 0.7)
    }
    private static var defaultRibbonSize: CGSize { CGSize(width: 7.0, height: 13.0) }
    private static var defaultTimerColor: UIColor { .white }
    private static var defaultUpdatedTimerColor: UIColor { .red }
    private static var defaultFavoriteColor: UIColor { .white }
    private static var defaultInfoColor: UIColor { .white }
    private static var defaultWidgetTitleColor: Color { .white }
    private static var defaultWidgetTitleFont: UIFont {
        UIFont(name: "Poppins-Bold", size: 16) ??
            .systemFont(ofSize: 16, weight: .bold)
    }
    private static var defaultWidgetButtonFont: UIFont {
        UIFont(name: "Poppins", size: 10) ??
            .systemFont(ofSize: 10, weight: .bold)
    }
    private static var defaultLineColor = UIColor(red: 10/255, green: 54/255, blue: 181/255, alpha: 0.3)
    private static var defaultProgressBarHeight: Double { 3 }
    private static var defaultProgressBarColor = UIColor(red: 1, green: 0.89, blue: 0.19, alpha: 1)
    private static var defaultProgressBarTrackColor = UIColor.white
    private static var defaultPrimaryButtonColor = UIColor(red: 1, green: 0.21, blue: 0.54, alpha: 1)
    private static var defaultSecondaryButtonColor : UIColor { .white }
    private static var defaultButtonCornerRadius: Double { 4.0 }
    private static var defaultButtonBorderWidth: Double { 1.0 }
    private static var defaultImageSize: CGSize { CGSize(width: 100, height: 100) }
    private static var defaultLinkColor: UIColor { .white }
    private static var defaultInfoTitleFont: UIFont {
            UIFont(name: "Poppins", size: 10) ??
                .systemFont(ofSize: 10, weight: .bold)
        }
    private static var defaultInfoDescriptionFont: UIFont {
        UIFont(name: "Poppins", size: 12) ??
            .systemFont(ofSize: 12, weight: .regular)
    }
    private static var defaultPopupTextColor = UIColor(red: 0.031, green: 0.169, blue: 0.651, alpha: 1)
    private static var defaultFavoriteIconSize: Double { 20.0 }
    private static var defaultCloseIconSize: Double { 16.0 }
    private static var defaultInfoPopupCardColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0.8)
    private static var defaultPopupAnimationDuration: Double { 1.0 }
    private static var defaultPopupBlurRadius: Double { 5.0 }
    private static var defaultGameFeatureIconSize: Double { 16.0 }
    private static var defaultPrimaryButtonHighlightTextColor: UIColor { .convertFrom(hex: "#082BA6") }
    private static var defaultPrimaryButtonBackgroundColor : UIColor { .white }
    private static var defaultSecondaryButtonHighlightTextColor: UIColor { .white }
    private static var defaultSecondaryButtonBackgroundColor : UIColor { .convertFrom(hex: "#BE2867") }
}

