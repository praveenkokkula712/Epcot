//
//  GameFeatureBadge.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 08/02/24.
//

import Foundation
import Utility

struct GameFeatureBadge: Identifiable {
    
    // MARK: - Properties
    var id = UUID()
    private(set) var type: GameFeatureBadgeType
    private(set) var iconName: String
    private let styles = GameFeatureBadgeCSS()

    // MARK: - Init
    init(type: GameFeatureBadgeType, iconName: String) {
        self.type = type
        self.iconName = iconName
    }

    // MARK: - Functionality
    func getIcon(size: CGFloat) -> IconVariant? {
        let icon = EpcotLobbyManager.shared?
            .datasource?
            .didRequestForIconVariant(with: iconName, fontSize: size)
        return icon
    }

    func getBadgeIcon(size: CGFloat) -> IconVariant? {
        let icon = EpcotLobbyManager.shared?
            .datasource?
            .didRequestForIconVariant(with: "bingo-badge", fontSize: size)
        return icon
    }

    func getCheckBoxIcon(size: CGFloat) -> IconVariant? {
        let icon = EpcotLobbyManager.shared?
            .datasource?
            .didRequestForIconVariant(with: "bingo-checkbox-bg", fontSize: size)
        return icon
    }
}

extension GameFeatureBadge: Equatable {
    static func == (lhs: GameFeatureBadge, rhs: GameFeatureBadge) -> Bool {
        lhs.type == rhs.type
    }
}

extension GameFeatureBadge: Hashable {
    func hash(into hasher: inout Hasher) {
        hasher.combine(iconName)
        hasher.combine(type)
    }
}

