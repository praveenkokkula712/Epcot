//
//  GameFeatureBadgeAttributes.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 08/02/24.
//

import Foundation
import SwiftUI

struct GameFeatureBadgeAttributes {
    let color: Color
    let color2: Color?
    let backgroundColor: Color
    let size: CGFloat?
    let borderColor: Color?
    let borderRadius: CGFloat?
    let borderWidth: CGFloat?
    let transform: CGFloat?
    
    init(
        color: Color,
        color2: Color? = nil,
        backgroundColor: Color,
        size: CGFloat? = nil,
        borderColor: Color? = nil,
        borderRadius: CGFloat? = nil,
        borderWidth: CGFloat? = nil,
        transform: CGFloat? = nil
    ) {
        self.color = color
        self.color2 = color2
        self.backgroundColor = backgroundColor
        self.size = size
        self.borderColor = borderColor
        self.borderRadius = borderRadius
        self.borderWidth = borderWidth
        self.transform = transform
    }
}
