//
//  GameFeatureBadgeCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 09/02/24.
//

import Foundation
import SwiftUI

struct GameFeatureBadgeCSS {
    
    // MARK: Properties
    let badgeSize: CGFloat
    let backgroundBadgeSize: CGFloat
    let everyOneWinsColor: Color
    let everyOneWinsBackgroundColor: Color
    let hotBallColor: Color
    let hotBallBackgroundColor: Color
    let rollOnColor: Color
    let rollOnBackgroundColor: Color
    let cashOutColor: Color
    let cashOutBackgroundColor: Color
    let physicalPrizeColor: Color
    let physicalPrizeBackgroundColor: Color
    let multiPriceColor: Color
    let multiPriceBackgroundColor: Color
    let freeTicketsColor: Color
    let freeTicketsBackgroundColor: Color
    let cashPotColor: Color
    let cashPotBackgroundColor: Color
    let timedJackpotColor: Color
    let timedJackpotBackgroundColor: Color
    let dealColor: Color
    let dealBackgroundColor: Color
    let beatChaserColor: Color
    let beatChaserBackgroundColor: Color
    let scratchCardColor: Color
    let scratchCardBackgroundColor: Color
    let sessionBingoColor: Color
    let sessionBingoBackgroundColor: Color
    let superBooksColor: Color
    let superBooksBackgroundColor: Color
    let countryMilesColor: Color
    let countryMilesBackgroundColor: Color
    let countryMiles2Color: Color
    let countryMiles2BackgroundColor: Color
    let sideBetsColor: Color
    let sideBetsBackgroundColor: Color
    let liveStreamingColor: Color
    let liveStreamingBackgroundColor: Color
    let bonusSpinsColor: Color
    let bonusSpinsBackgroundColor: Color
    let bonusCashColor: Color
    let bonusCashBackgroundColor: Color
    let bonusTicketsColor: Color
    let bonusTicketsBackgroundColor: Color
    let slotsRacePodiumColor: Color
    let slotsRacePodiumBackgroundColor: Color
    let bingoInsuranceColor: Color
    let bingoInsuranceBackgroundColor: Color
    let slidingPotColor: Color
    let slidingPotBackgroundColor: Color
    let jumpingPotColor: Color
    let jumpingPotBackgroundColor: Color
    let superLinkColor: Color
    let superLinkBackgroundColor: Color
    let extraSpinColor: Color
    let extraSpinColor2: Color
    let extraSpinBackgroundColor: Color
    let whackBingoColor: Color
    let whackBingoBackgroundColor: Color
    let prizeDropColor: Color
    let prizeDropBackgroundColor: Color
    let prizeWheelColor: Color
    let prizeWheelBackgroundColor: Color
    let prizeWheelBorderColor: Color
    let prizeWheelBorderRadius: CGFloat
    let prizeWheelBorderThickness: CGFloat
    let ntgColor: Color
    let ntgBackgroundColor: Color
    let ntgTransform: CGFloat
    
    // MARK: Init
    init(bingoCss: BingoFeatureBadgesCSS? = nil) {
        let css = bingoCss ?? Self.lobbyCSS?.bingoWidgetViewCss?.featureBadgeCss
        badgeSize = css?.badgeSize ?? Self.badgeSizeDefault
        backgroundBadgeSize = css?.backgroundBadgeSize ?? Self.backgroundBadgeSizeDefault
        everyOneWinsColor = Color(css?.everyOneWinsColor ?? Self.everyOneWinsColorDefault)
        everyOneWinsBackgroundColor = Color(css?.everyOneWinsBackgroundColor ?? Self.everyOneWinsBackgroundColorDefault)
        hotBallColor = Color(css?.hotBallColor ?? Self.hotBallColorDefault)
        hotBallBackgroundColor = Color(css?.hotBallBackgroundColor ?? Self.hotBallBackgroundColorDefault)
        rollOnColor = Color(css?.rollOnColor ?? Self.rollOnColorDefault)
        rollOnBackgroundColor = Color(css?.rollOnBackgroundColor ?? Self.rollOnBackgroundColorDefault)
        cashOutColor = Color(css?.cashOutColor ?? Self.cashOutColorDefault)
        cashOutBackgroundColor = Color(css?.cashOutBackgroundColor ?? Self.cashOutBackgroundColorDefault)
        physicalPrizeColor = Color(css?.physicalPrizeColor ?? Self.physicalPrizeColorDefault)
        physicalPrizeBackgroundColor = Color(css?.physicalPrizeBackgroundColor ?? Self.physicalPrizeBackgroundColorDefault)
        multiPriceColor = Color(css?.multiPriceColor ?? Self.multiPriceColorDefault)
        multiPriceBackgroundColor = Color(css?.multiPriceBackgroundColor ?? Self.multiPriceBackgroundColorDefault)
        freeTicketsColor = Color(css?.freeTicketsColor ?? Self.freeTicketsColorDefault)
        freeTicketsBackgroundColor = Color(css?.freeTicketsBackgroundColor ?? Self.freeTicketsBackgroundColorDefault)
        cashPotColor = Color(css?.cashPotColor ?? Self.cashPotColorDefault)
        cashPotBackgroundColor = Color(css?.cashPotBackgroundColor ?? Self.cashPotBackgroundColorDefault)
        timedJackpotColor = Color(css?.timedJackpotColor ?? Self.timedJackpotColorDefault)
        timedJackpotBackgroundColor = Color(css?.timedJackpotBackgroundColor ?? Self.timedJackpotBackgroundColorDefault)
        dealColor = Color(css?.dealColor ?? Self.dealColorDefault)
        dealBackgroundColor = Color(css?.dealBackgroundColor ?? Self.dealBackgroundColorDefault)
        beatChaserColor = Color(css?.beatChaserColor ?? Self.beatChaserColorDefault)
        beatChaserBackgroundColor = Color(css?.beatChaserBackgroundColor ?? Self.beatChaserBackgroundColorDefault)
        scratchCardColor = Color(css?.scratchCardColor ?? Self.scratchCardColorDefault)
        scratchCardBackgroundColor = Color(css?.scratchCardBackgroundColor ?? Self.scratchCardBackgroundColorDefault)
        sessionBingoColor = Color(css?.sessionBingoColor ?? Self.sessionBingoColorDefault)
        sessionBingoBackgroundColor = Color(css?.sessionBingoBackgroundColor ?? Self.sessionBingoBackgroundColorDefault)
        superBooksColor = Color(css?.superBooksColor ?? Self.superBooksColorDefault)
        superBooksBackgroundColor = Color(css?.superBooksBackgroundColor ?? Self.superBooksBackgroundColorDefault)
        countryMilesColor = Color(css?.countryMilesColor ?? Self.countryMilesColorDefault)
        countryMilesBackgroundColor = Color(css?.countryMilesBackgroundColor ?? Self.countryMilesBackgroundColorDefault)
        countryMiles2Color = Color(css?.countryMiles2Color ?? Self.countryMiles2ColorDefault)
        countryMiles2BackgroundColor = Color(css?.countryMiles2BackgroundColor ?? Self.countryMiles2BackgroundColorDefault)
        sideBetsColor = Color(css?.sideBetsColor ?? Self.sideBetsColorDefault)
        sideBetsBackgroundColor = Color(css?.sideBetsBackgroundColor ?? Self.sideBetsBackgroundColorDefault)
        liveStreamingColor = Color(css?.liveStreamingColor ?? Self.liveStreamingColorDefault)
        liveStreamingBackgroundColor = Color(css?.liveStreamingBackgroundColor ?? Self.liveStreamingBackgroundColorDefault)
        bonusSpinsColor = Color(css?.bonusSpinsColor ?? Self.bonusSpinsColorDefault)
        bonusSpinsBackgroundColor = Color(css?.bonusSpinsBackgroundColor ?? Self.bonusSpinsBackgroundColorDefault)
        bonusCashColor = Color(css?.bonusCashColor ?? Self.bonusCashColorDefault)
        bonusCashBackgroundColor = Color(css?.bonusCashBackgroundColor ?? Self.bonusCashBackgroundColorDefault)
        bonusTicketsColor = Color(css?.bonusTicketsColor ?? Self.bonusTicketsColorDefault)
        bonusTicketsBackgroundColor = Color(css?.bonusTicketsBackgroundColor ?? Self.bonusTicketsBackgroundColorDefault)
        slotsRacePodiumColor = Color(css?.slotsRacePodiumColor ?? Self.slotsRacePodiumColorDefault)
        slotsRacePodiumBackgroundColor = Color(css?.slotsRacePodiumBackgroundColor ?? Self.slotsRacePodiumBackgroundColorDefault)
        bingoInsuranceColor = Color(css?.bingoInsuranceColor ?? Self.bingoInsuranceColorDefault)
        bingoInsuranceBackgroundColor = Color(css?.bingoInsuranceBackgroundColor ?? Self.bingoInsuranceBackgroundColorDefault)
        slidingPotColor = Color(css?.slidingPotColor ?? Self.slidingPotColorDefault)
        slidingPotBackgroundColor = Color(css?.slidingPotBackgroundColor ?? Self.slidingPotBackgroundColorDefault)
        jumpingPotColor = Color(css?.jumpingPotColor ?? Self.jumpingPotColorDefault)
        jumpingPotBackgroundColor = Color(css?.jumpingPotBackgroundColor ?? Self.jumpingPotBackgroundColorDefault)
        superLinkColor = Color(css?.superLinkColor ?? Self.superLinkColorDefault)
        superLinkBackgroundColor = Color(css?.superLinkBackgroundColor ?? Self.superLinkBackgroundColorDefault)
        extraSpinColor = Color(css?.extraSpinColor ?? Self.extraSpinColorDefault)
        extraSpinColor2 = Color(css?.extraSpinColor2 ?? Self.extraSpinColor2Default)
        extraSpinBackgroundColor = Color(css?.extraSpinBackgroundColor ?? Self.extraSpinBackgroundColorDefault)
        whackBingoColor = Color(css?.whackBingoColor ?? Self.whackBingoColorDefault)
        whackBingoBackgroundColor = Color(css?.whackBingoBackgroundColor ?? Self.whackBingoBackgroundColorDefault)
        prizeDropColor = Color(css?.prizeDropColor ?? Self.prizeDropColorDefault)
        prizeDropBackgroundColor = Color(css?.prizeDropBackgroundColor ?? Self.prizeDropBackgroundColorDefault)
        prizeWheelColor = Color(css?.prizeWheelColor ?? Self.prizeWheelColorDefault)
        prizeWheelBackgroundColor = Color(css?.prizeWheelBackgroundColor ?? Self.prizeWheelBackgroundColorDefault)
        prizeWheelBorderColor = Color(css?.prizeWheelBorderColor ?? Self.prizeWheelBorderColorDefault)
        prizeWheelBorderThickness = css?.prizeWheelBorderThickness ?? Self.prizeWheelBorderThicknessDefault
        prizeWheelBorderRadius = css?.prizeWheelBorderRadius ?? Self.prizeWheelBorderRadiusDefault
        ntgColor = Color(css?.ntgColor ?? Self.ntgColorDefault)
        ntgBackgroundColor = Color(css?.ntgBackgroundColor ?? Self.ntgBackgroundColorDefault)
        ntgTransform = css?.ntgTransform ?? Self.ntgTransformDefault
    }
}

// MARK: - Helper
extension GameFeatureBadgeCSS: LobbyStylable { }

extension GameFeatureBadgeCSS {
    private static var badgeSizeDefault: CGFloat { 20.0 }
    private static var backgroundBadgeSizeDefault: CGFloat { 20.0 }
    private static var everyOneWinsColorDefault: UIColor { .convertFrom(hex: "#41494e") }
    private static var everyOneWinsBackgroundColorDefault: UIColor { .convertFrom(hex: "#ffcd00") }
    private static var hotBallColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var hotBallBackgroundColorDefault: UIColor { .convertFrom(hex: "#ff6536") }
    private static var rollOnColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var rollOnBackgroundColorDefault: UIColor { .convertFrom(hex: "#017fff") }
    private static var cashOutColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var cashOutBackgroundColorDefault: UIColor { .convertFrom(hex: "#12a353") }
    private static var physicalPrizeColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var physicalPrizeBackgroundColorDefault: UIColor { .convertFrom(hex: "#2a44d4" ) }
    private static var multiPriceColorDefault: UIColor { .convertFrom(hex: "#f7b500") }
    private static var multiPriceBackgroundColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var freeTicketsColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var freeTicketsBackgroundColorDefault: UIColor { .convertFrom(hex: "#2db343") }
    private static var cashPotColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var cashPotBackgroundColorDefault: UIColor { .convertFrom(hex: "#d4af37") }
    private static var timedJackpotColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var timedJackpotBackgroundColorDefault: UIColor { .convertFrom(hex: "#57b4d3") }
    private static var dealColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var dealBackgroundColorDefault: UIColor { .convertFrom(hex: "#d4af37") }
    private static var beatChaserColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var beatChaserBackgroundColorDefault: UIColor { .convertFrom(hex: "#660506") }
    private static var scratchCardColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var scratchCardBackgroundColorDefault: UIColor { .convertFrom(hex: "#369946") }
    private static var sessionBingoColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var sessionBingoBackgroundColorDefault: UIColor { .convertFrom(hex: "#288ecd") }
    private static var superBooksColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var superBooksBackgroundColorDefault: UIColor { .convertFrom(hex: "#c609c6") }
    private static var countryMilesColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var countryMilesBackgroundColorDefault: UIColor { .convertFrom(hex: "#325107") }
    private static var countryMiles2ColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var countryMiles2BackgroundColorDefault: UIColor { .convertFrom(hex: "#edd029") }
    private static var sideBetsColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var sideBetsBackgroundColorDefault: UIColor { .convertFrom(hex: "#C7A00C") }
    private static var liveStreamingColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var liveStreamingBackgroundColorDefault: UIColor { .convertFrom(hex: "#9b59b6") }
    private static var bonusSpinsColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var bonusSpinsBackgroundColorDefault: UIColor { .convertFrom(hex: "#e67e22") }
    private static var bonusCashColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var bonusCashBackgroundColorDefault: UIColor { .convertFrom(hex: "#9857b2") }
    private static var bonusTicketsColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var bonusTicketsBackgroundColorDefault: UIColor { .convertFrom(hex: "#2db343") }
    private static var slotsRacePodiumColorDefault: UIColor { .convertFrom(hex: "#000000") }
    private static var slotsRacePodiumBackgroundColorDefault: UIColor { .convertFrom(hex: "#f7b500") }
    private static var bingoInsuranceColorDefault: UIColor { .convertFrom(hex: "#000000") }
    private static var bingoInsuranceBackgroundColorDefault: UIColor { .convertFrom(hex: "#f7b500") }
    private static var slidingPotColorDefault: UIColor { .convertFrom(hex: "#342891") }
    private static var slidingPotBackgroundColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var jumpingPotColorDefault: UIColor { .convertFrom(hex: "#342891") }
    private static var jumpingPotBackgroundColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var superLinkColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var superLinkBackgroundColorDefault: UIColor { .convertFrom(hex: "#FF1493") }
    private static var extraSpinColorDefault: UIColor { .convertFrom(hex: "#fff7ae") }
    private static var extraSpinColor2Default: UIColor { .convertFrom(hex: "#FFA800") }
    private static var extraSpinBackgroundColorDefault: UIColor { .convertFrom(hex: "#62001B") }
    private static var whackBingoColorDefault: UIColor { .convertFrom(hex: "#12a353") }
    private static var whackBingoBackgroundColorDefault: UIColor { .convertFrom(hex: "#ffffff") }
    private static var prizeDropColorDefault: UIColor { .convertFrom(hex: "#fd3689") }
    private static var prizeDropBackgroundColorDefault: UIColor { .convertFrom(hex: "#092ba6") }
    private static var prizeWheelColorDefault: UIColor { .convertFrom(hex: "#FCDE16") }
    private static var prizeWheelBackgroundColorDefault: UIColor { .convertFrom(hex: "#B93902") }
    private static var prizeWheelBorderColorDefault: UIColor { .convertFrom(hex: "#FCDE16") }
    private static var prizeWheelBorderThicknessDefault: CGFloat { 1.0 }
    private static var prizeWheelBorderRadiusDefault: CGFloat { 3.0 }
    private static var ntgColorDefault: UIColor { .convertFrom(hex: "#444444") }
    private static var ntgBackgroundColorDefault: UIColor { .convertFrom(hex: "#1dffbb") }
    private static var ntgTransformDefault: CGFloat { 345.0 }
}
