//
//  BingoWidgetContainerView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 29/12/23.
//

import SwiftUI
import CasinoAPI

struct BingoWidgetContainerView: View {
    
    // MARK: - Properties
    let baseViewModel: BingoWidgetContainerViewModel

    // MARK: - Body
    var body: some View {
        VStack(spacing: 8) {

            // Header
            LobbySectionHeaderView(
                title: "bingo_rooms".localized,
                ctaTitle: Localize.seeAll,
                onCTA: baseViewModel.seeAllAction
            )
            .padding(.top, 16)

            // Bingo Widgets
            ScrollView(.horizontal) {
                HStack {
                    ForEach(baseViewModel.bingoRooms) { model in
                        let viewModel = BingoWidgetRoomViewModel(
                            model: model,
                            roomIcons: baseViewModel.roomIcons, 
                            fetchBingoRooms: baseViewModel.fetchBingoRooms
                        )
                        BingoWidgetRoomView(viewModel: viewModel)
                    }
                }
                .padding(.horizontal, 8.0)
                .padding(.leading, 16)
            }
            .padding(.bottom, 16)
        }
        .frame(height: height)
    }
    
    // MARK: - Design Constants
    private var height: Double { 275.0 }
}
