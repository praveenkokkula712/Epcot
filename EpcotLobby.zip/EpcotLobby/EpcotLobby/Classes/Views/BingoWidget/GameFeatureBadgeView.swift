//
//  GameFeatureBadgeView.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 08/02/24.
//

import SwiftUI
import Utility

struct GameFeatureBadgeView: View {
    
    // MARK: - Properties
    private let iconSize: CGFloat
    private let badge: GameFeatureBadge

    // MARK: - Init
    init(badge: GameFeatureBadge, iconSize: CGFloat = 15) {
        self.badge = badge
        self.iconSize = iconSize
    }
    
    // MARK: - Body
    var body: some View {
        ZStack {
            if badge.type == .prizeDrop || badge.type == .prizeWheel {
                if let checkBoxContent {
                    Text(checkBoxContent.icon)
                        .font(Font(checkBoxContent.font))
                        .foregroundColor(badge.type.attributes.backgroundColor)
                        .iflet(badge.type.attributes.borderRadius) {
                            $0.overlay(
                                RoundedRectangle(cornerRadius: $1)
                                    .iflet(
                                        badge.type.attributes.borderColor,
                                        badge.type.attributes.borderWidth
                                    ) {
                                        $0.stroke(Color.yellow, lineWidth: $2)
                                    }
                            )
                        }
                }
            } else {
                if let badgeContent {
                    Text(badgeContent.icon)
                        .font(Font(badgeContent.font))
                        .foregroundColor(badge.type.attributes.backgroundColor)
                }
            }

            if let iconContent {
                Text(iconContent.icon)
                    .font(Font(iconContent.font))
                    .foregroundColor(badge.type.attributes.color)
                    .iflet(badge.type.attributes.color2) {
                        $0.foregroundLinearGradient(
                            colors: [badge.type.attributes.color, $1],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    }
                    .iflet(badge.type.attributes.transform) {
                        $0.rotation3DEffect(.degrees($1), axis: (x: 0, y: 0, z: 1))
                    }
            }
        }
        .accessibilityLabel(badge.type.rawValue)
        .accessibilityIdentifier(BingoWidgetAccessID.GAME_FEATURE_BADGE)
    }
    
    // MARK: - Helper
    private var iconContent: IconVariant? {
        var scaleFactor = 1.0
        if badge.type == .hotBall ||
            badge.type == .rollOnPart ||
            badge.type == .slingoMultiStake ||
            badge.type == .jumpingPot ||
            badge.type == .multiPrice ||
            badge.type == .slidingPot ||
            badge.type == .slingoExtraBall ||
            badge.type == .whackABingo {
            scaleFactor = 1.5
        } else if badge.type == .oneTG || badge.type == .twoTG {
            scaleFactor = 2.0
        }
        return badge.getIcon(size: iconSize * scaleFactor)
    }

    private var checkBoxContent: IconVariant? {
        badge.getCheckBoxIcon(size: iconSize + 5.0)
    }

    private var badgeContent: IconVariant? {
        badge.getBadgeIcon(size: iconSize + 10.0)
    }
}

// MARK: - Preview
struct GameFeatureBadgeView_Previews: PreviewProvider {
    static var previews: some View {
        GameFeatureBadgeView(
            badge: GameFeatureBadge(type: .beatChaser, iconName: "")
        )
    }
}

extension Text {
    public func foregroundLinearGradient(
        colors: [Color],
        startPoint: UnitPoint,
        endPoint: UnitPoint
    ) -> some View
    {
        self.overlay {
            LinearGradient(
                colors: colors,
                startPoint: startPoint,
                endPoint: endPoint
            )
            .mask(self)
        }
    }
}
