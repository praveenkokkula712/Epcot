//
//  BingoWidgetView.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 01/01/24.
//

import SwiftUI

struct BingoWidgetRoomView: View {
    
    // MARK: - Properties
    @ObservedObject private var viewModel: BingoWidgetRoomViewModel
    private let styles = BingoWidgetViewCSS()
    @State private var showPopup = false
    
    // MARK: - Init
    init(viewModel: BingoWidgetRoomViewModel) {
        self.viewModel = viewModel
    }
    
    // MARK: - Body
    var body: some View {
        
        VStack(spacing: 0.0) {
            
            VStack(spacing: 0.0) {
                
                // Ribbon
                if !viewModel.ribbonTitle.isEmpty {
                    RibbonView(title: viewModel.ribbonTitle)
                        .offset(x: -styles.ribbonSize.width / 2)
                        .frame(width: styles.cardSize.width + styles.ribbonSize.width)
                }
                
                ZStack {
                    VStack {
                        HStack(alignment: .top, spacing: 16.0) {
                            
                            // Widget Image
                            BingoWidgetImageView(url: viewModel.imageURLString, styles: styles)
                                .padding(.top, 12.0)
                            
                            VStack(alignment: .leading, spacing: 8.0) {
                                HStack(spacing: 8.0) {
                                    
                                    // Timer
                                    WidgetLabel(
                                        type: .timer,
                                        text: viewModel.gameStartInTime,
                                        iconContent: viewModel.getWidgetLabelIcon(type: .timer),
                                        updateTimerColor: viewModel.shouldUpdateTimerColor
                                    )
                                    .padding([.leading, .vertical], 3.0)
                                    .padding(.trailing, 5.0)
                                    .background(viewModel.shouldUpdateTimerColor ? styles.alertTimerBackgroundColor : styles.timerBackgroundColor)
                                    .clipShape(Capsule())
                                    .accessibilityLabel(viewModel.gameStartInTime)
                                    .accessibilityIdentifier(BingoWidgetAccessID.TIMER)
                                    
                                    // Game Feature icons
                                    if !viewModel.gameFeatureBadges.isEmpty {
                                        HStack(spacing: 8.0) {
                                            ForEach(viewModel.gameFeatureBadges) { badge in
                                                GameFeatureBadgeView(
                                                    badge: badge,
                                                    iconSize: CGFloat(styles.gameFeatureIconSize)
                                                )
                                            }
                                        }
                                    }
                                    Spacer()
                                    
                                    if !viewModel.favoriteInfoIconsContent.isEmpty {
                                        // Favourite && Info icons
                                        WidgetGameFeatureIconHStack(
                                            icons: viewModel.favoriteInfoIconsContent,
                                            accessibilityIdentifiers: [
                                                BingoWidgetAccessID.FAVORITE,
                                                BingoWidgetAccessID.INFO
                                            ]
                                        ) { index in
                                            //info action
                                            if index == 1 || !viewModel.showFavoriteIcon {
                                                withAnimation(.easeInOut(duration: CGFloat(styles.infoAnimationDuration))) {
                                                    showPopup.toggle()
                                                }
                                                viewModel.trackEvent(for: .info)
                                            } else {
                                                //favourite action
                                                viewModel.updateFavourite()
                                            }
                                        }
                                    }
                                }
                                .frame(maxHeight: 20)
                                
                                
                                // Title
                                Text(viewModel.title)
                                    .font(styles.widgetTitleFont)
                                    .foregroundColor(styles.widgetTitleColor)
                                    .accessibilityIdentifier(BingoWidgetAccessID.ROOM_NAME)

                                VStack {
                                    
                                    HStack(spacing: 8.0) {
                                        // Display the number of available rooms
                                        if viewModel.isCombinedRoom {
                                            WidgetLabel(
                                                type: .combinedRooms,
                                                text: viewModel.roomsAvailabelText,
                                                iconContent: nil
                                            )
                                            .accessibilityLabel(viewModel.roomsAvailabelText)
                                            .accessibilityIdentifier(BingoWidgetAccessID.COMBINED_ROOMS)
                                        } else if !viewModel.jackpotPrices.isEmpty {
                                            // Jackpot price
                                            WidgetLabel(
                                                type: .jackpotAmount,
                                                text: "",
                                                jackpotPrices: viewModel.jackpotPrices,
                                                iconContent: viewModel.getWidgetLabelIcon(type: .jackpotAmount)
                                            )
                                        }
                                        Spacer()
                                        
                                        // Link icon
                                        if let linkIcon = viewModel.getIcon(icon: .link, size: 20),
                                           viewModel.showLinkIcon {
                                            let coloredLinkIcon = (icon: linkIcon.icon, font: linkIcon.font, color: UIColor(styles.linkIconColor))
                                            WidgetGameFeatureIconHStack(
                                                icons: [coloredLinkIcon],
                                                disable: true,
                                                accessibilityIdentifiers: [BingoWidgetAccessID.LINK]
                                            )
                                        }
                                    }
                                    Spacer()
                                    
                                    Rectangle()
                                        .fill(styles.lineColor)
                                        .frame(height: 2.0)
                                }
                                
                                HStack {
                                    
                                    // Users Count
                                    WidgetLabel(
                                        type: .users,
                                        text: viewModel.usersCount,
                                        iconContent: viewModel.getWidgetLabelIcon(type: .users)
                                    )
                                    .accessibilityLabel(viewModel.usersCount)
                                    .accessibilityIdentifier(BingoWidgetAccessID.PLAYERS)
                                    Spacer()
                                    
                                    // Promotions
                                    WidgetLabel(
                                        type: .cardPrice(viewModel.isCombinedRoom),
                                        text: viewModel.isCombinedRoom ? viewModel.cardPriceText : viewModel.cardPrice,
                                        iconContent: viewModel.getWidgetLabelIcon(type: .cardPrice(viewModel.isCombinedRoom))
                                    )
                                    .if(viewModel.isCombinedRoom) { promotionsView in
                                        /// Promotions view and winnings view to align equally
                                        promotionsView.frame(minWidth: 0, maxWidth: .infinity)
                                    }
                                    .accessibilityLabel(viewModel.isCombinedRoom ? viewModel.cardPriceText : viewModel.cardPrice)
                                    .accessibilityIdentifier(BingoWidgetAccessID.TICKET_PRICE)
                                    
                                    Spacer()
                                    
                                    // Winnings
                                    WidgetLabel(
                                        type: .winnings(viewModel.isCombinedRoom),
                                        text: viewModel.isCombinedRoom ? viewModel.winningsText : viewModel.winnings,
                                        iconContent: viewModel.getWidgetLabelIcon(type: .winnings(viewModel.isCombinedRoom))
                                    )
                                    .if(viewModel.isCombinedRoom) { winningsView in
                                        /// Promotions view and winnings view to align equally
                                        winningsView.frame(minWidth: 0, maxWidth: .infinity)
                                    }
                                    .accessibilityLabel(viewModel.isCombinedRoom ? viewModel.winningsText : viewModel.winnings)
                                    .accessibilityIdentifier(BingoWidgetAccessID.WINNINGS)
                                }
                            }
                        }
                    }
                    .blur(radius: showPopup ? CGFloat(styles.infoBlurRadius) : 0)
                    .padding(.horizontal, 16.0)
                    .padding(.bottom, 8.0)
                    .padding(.top, !viewModel.ribbonTitle.isEmpty ? 3.0 : 16.0)
                    
                    if viewModel.lobbyInactive {
                        // This code adds a dimmed overlay on top of the room view if the lobby is inactive.
                        Text("")
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .background(viewModel.lobbyInactive ? styles.inactiveRoomColor : .clear )
                            .cornerRadius(!viewModel.ribbonTitle.isEmpty ? 0 : CGFloat(styles.cornerRadius),
                                          corners: [.topLeft, .topRight]
                            )

                    }
                    Spacer()
                }
            }
            .overlay {
                if showPopup {
                    InfoPopup(showInfoPopup: $showPopup, viewModel: viewModel)
                        .transition(.move(edge: .bottom))
                }
            }
            
            ZStack {
                
                BingoWidgetProgressBarView(
                    value: viewModel.progress,
                    totalValue: viewModel.progressBarStartTime
                )
                .frame(height: styles.progressBarHeight)
                .allowsHitTesting(false)
                
                if viewModel.lobbyInactive {
                    styles.inactiveRoomColor
                        .frame(height: styles.progressBarHeight)
                        .allowsHitTesting(false)
                }
            }
            
            ZStack {
                
                // This code adds a dimmed overlay on top of the room view if the lobby is inactive.
                Text("")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(viewModel.lobbyInactive ? styles.inactiveRoomColor : .clear)
                
                HStack(spacing: 16.0) {
                    
                    // Prebuy
                    if viewModel.showPreBuy {
                        WidgetButton(
                            type: .outline,
                            text: viewModel.prebuyText,
                            textColor: styles.primaryButtonColor,
                            highlightTextColor: styles.primaryButtonHighlightTextColor,
                            backgroundColor: styles.primaryButtonColor,
                            highlightBackgroundColor: styles.primaryButtonHighlightColor,
                            buttonFont: styles.widgetButtonFont,
                            action: viewModel.preBuyAction
                        )
                        .frame(maxWidth: 160)
                        .accessibilityIdentifier(BingoWidgetAccessID.PREBUY)
                    }
                    
                    if !viewModel.showPreBuy {
                        Spacer()
                    }
                    
                    // Buy
                    WidgetButton(
                        text: viewModel.buyText,
                        textColor: styles.primaryButtonColor,
                        highlightTextColor: styles.secondaryButtonHighlightTextColor,
                        backgroundColor: styles.secondaryButtonColor,
                        highlightBackgroundColor: styles.secondaryButtonHighlightColor,
                        buttonFont: styles.widgetButtonFont,
                        action: viewModel.playAction
                    )
                    .frame(maxWidth: 160)
                    .disabled(viewModel.lobbyInactive)
                    .opacity(viewModel.lobbyInactive ? 0.7 : 1.0)
                    .accessibilityIdentifier(BingoWidgetAccessID.PLAY)

                    if !viewModel.showPreBuy {
                        Spacer()
                    }
                    
                }
                .padding(8.0)
                .frame(height: 48)
                .layoutPriority(1.0)
                .background(viewModel.lobbyInactive ? .clear : styles.cardColor)
            }
            .cornerRadius(CGFloat(styles.cornerRadius), corners: [.bottomLeft, .bottomRight])
        }
        .background(
            RoundedRectangle(cornerRadius: CGFloat(styles.cornerRadius))
                .fill(styles.cardColor)
                .frame(width: styles.cardSize.width, height: styles.cardSize.height)
        )
        .frame(width: styles.cardSize.width, height: styles.cardSize.height)
    }
}

// MARK: - Preview
struct BingoWidgetRoomView_Previews: PreviewProvider {
    static var previews: some View {
        let stub = BingoWidgetsStub()
        return ScrollView(.horizontal) {
            HStack {
                ForEach(stub.models) { model in
                    let viewModel = BingoWidgetRoomViewModel(
                        model: model,
                        roomIcons: BingoRoomIcons(),
                        fetchBingoRooms: {}
                    )
                    BingoWidgetRoomView(viewModel: viewModel)
                }
            }
            .padding(.horizontal, 8.0)
        }
    }
}
