//
//  BingoWidgetViewModel.swift
//  SampleDemo
//
//  Created by Yemireddi Sateesh on 02/01/24.
//

import Foundation
import CasinoAPI
import Combine
import ConfigModule
import Utility
import TrackerClient

class BingoWidgetRoomViewModel: ObservableObject {
    
    // MARK: - Properties
    @Published var gameStartInTime = ""
    @Published var gameAboutToStart: Bool = false
    @Published var startProgress: Bool = false
    @Published var progress = 0.0
    private let progressIncrement = 1.0
    var progressBarStartTime: Int {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.bingoWidget?.progressBarStartTime ?? 0
    }
    var roomStartInTimeAlertInterval: Int {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.bingoWidget?.roomStartInTimeAlertInterval ?? 0
    }
    @Published var shouldUpdateTimerColor: Bool = false
    private var fetchBingoRooms: () -> Void
    private var model: BingoWidgetRoom
    private let roomIcons: BingoRoomIcons
    private var timer: Publishers.Autoconnect<Timer.TimerPublisher>?
    private var tickInterval: TimeInterval = 1.0
    private var stopTicking = false
    private var subscription: AnyCancellable?
    private let styles = BingoWidgetViewCSS()
    
    // MARK: - Init
    init(model: BingoWidgetRoom,
         roomIcons: BingoRoomIcons,
         fetchBingoRooms: @escaping () -> Void) {
        self.model = model
        self.roomIcons = roomIcons
        self.fetchBingoRooms = fetchBingoRooms
        gameStartInTime = formatStartInTime()
        if !model.insurance {
            self.startTimer()
        }
    }
    
    // MARK: - UI Content
    var ribbonTitle: String { model.ribbonText }
    var title: String { model.name }
    var jackpotPrices: [String] {
        model.jackpotPrices.map { "\(model.currency)\($0.roundToTwoDigits)" }
    }
    var infoTitle : String { model.infoTitle }
    var infoDescription : String { model.infoDetails }
    var usersCount: String { "\(model.numbersOfPlayers)" }
    var cardPrice: String { "\(model.currency)\(model.cardPrice)" }
    var winnings: String { "\(model.currency)\(model.winPrizeAmount)" }
    var gameFeatureBadges: [GameFeatureBadge] { Array(model.gameFeatureBadges.prefix(2)) }
    var imageURLString: String { model.gameImageURL }
    var lobbyInactive: Bool { model.lobbyInactive }
    
    var showPreBuy: Bool { model.enablePreBuy }
    var prebuyText: String { model.preBuyButtonTitle }
    var buyText: String { model.playButtonTitle }
    
    var isCombinedRoom: Bool { model.isCombinedRoom }
    var combinedRoomCount: Int { model.combinedRoomsCount }
    var roomsAvailabelText: String { model.roomsAvailableText }
    var winningsText: String { model.winPrizeText }
    var cardPriceText: String { model.cardPriceText }
    
    private var odrAws: AppConfigurationODRAWS? {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws
    }
    
    private var isLoggedIn: Bool {
        guard let _ = EntainContext.user?.accountName else { return false }
        return true
    }
    
    // MARK: - Play Action
    func playAction() {
        guard self.isLoggedIn else {
            self.openLoginPage { [weak self] loggedIn in
                if loggedIn {
                    self?.playAction()
                }
            }
            return
        }
        if let url = odrAws?.bingoWidgetDNS?.playURL {
            let playURL = url.replacingOccurrences(of: "{ROOM_ID}", with: model.id)
            EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .bingoRoom("\(playURL)"), buttonType: nil)
        }
        self.trackEvent(for: .play)
    }
    
    // MARK: - PRE Buy Action
    func preBuyAction() {
        guard self.isLoggedIn else {
            self.openLoginPage { [weak self] loggedIn in
                if loggedIn {
                    self?.preBuyAction()
                }
            }
            return
        }
        if let url = odrAws?.bingoWidgetDNS?.prebuyURL {
            var playURL = url.replacingOccurrences(of: "{ROOM_ID}", with: model.id)
            playURL = playURL.replacingOccurrences(of: "{DATE}", with: Date.currentddMMYYYY)
            EpcotLobbyManager.shared?.delegate?.didClickWeblink(with: .bingoRoom("\(playURL)"), buttonType: nil)
        }
        self.trackEvent(for: .preBuy)
    }
}

// MARK: - Icons
extension BingoWidgetRoomViewModel {
    enum Icon: String {
        case clock = "verification-pending" // - Not there in site-core
        case favoriteOutline = "favIcon"
        case favorite = "bingo-heart" // - Not there in site-core
        case info = "info" // - Not there in site-core
        case jackpot = "bingo-star" // - Not there in site-core
        case link = "linkedIcon"
        case players = "cappedPlayerIcon"
        case cardIcon = "priceIcon"
        case winnings = "winPrizeIcon"
        case close = "close-small"
        case noIconAvailable
        
        fileprivate func getIcon(size: CGFloat, roomIcons: BingoRoomIcons) -> IconVariant? {
            let iconName = roomIcons[rawValue] ?? rawValue
            return BingoWidgetRoomViewModel.getIcon(name: iconName, size: size)
        }
    }
    
    var showFavoriteIcon: Bool { bingoWidgetConfig?.showFavouriteIcon ?? false }
    var showInfoIcon: Bool { bingoWidgetConfig?.showInfoIcon ?? false }
    var showLinkIcon: Bool { model.showLinkIcon }
    
    func getIcon(
        icon: BingoWidgetRoomViewModel.Icon,
        size: CGFloat
    ) -> IconVariant? {
        icon.getIcon(size: size, roomIcons: roomIcons)
    }
    
    func getWidgetLabelIcon(
        type: WidgetLabel.WidgetLabelType
    ) -> IconVariant? {
        type.imageName.getIcon(size: type.imageSize, roomIcons: roomIcons)
    }
    
    var favoriteInfoIconsContent: [(icon: String, font: UIFont, color: UIColor)] {
        let favoriteIcon = Icon.favorite.getIcon(size: 20, roomIcons: roomIcons)
        let unfavoriteIcon = Icon.favoriteOutline.getIcon(size: 20, roomIcons: roomIcons)
        let infoIcon = Icon.info.getIcon(size: 20, roomIcons: roomIcons)
        var icons = [(icon: String, font: UIFont, color: UIColor)]()
        
        let heartIcon = self.model.isFavourited ? favoriteIcon : unfavoriteIcon
        
        if showFavoriteIcon && showInfoIcon {
            if let favorite = heartIcon {
                icons.append((favorite.icon, favorite.font, UIColor(styles.favoriteIconColor)))
            }
            if let info = infoIcon {
                icons.append((info.icon, info.font, UIColor(styles.infoIconColor)))
            }
        } else if showFavoriteIcon {
            if let favorite = heartIcon {
                icons.append((favorite.icon, favorite.font, UIColor(styles.favoriteIconColor)))
            }
        } else if showInfoIcon {
            if let info = infoIcon {
                icons.append((info.icon, info.font, UIColor(styles.infoIconColor)))
            }
        }
        return icons
    }
    
    var favoriteCloseIconsContent: [(icon: String, font: UIFont, color: UIColor)] {
        let favoriteIcon = Icon.favorite.getIcon(size: 20, roomIcons: roomIcons)
        let unfavoriteIcon = Icon.favoriteOutline.getIcon(size: 20, roomIcons: roomIcons)
        let closeIcon = Icon.close.getIcon(size: 20, roomIcons: roomIcons)
        var icons = [(icon: String, font: UIFont, color: UIColor)]()
        
        let heartIcon = self.model.isFavourited ? favoriteIcon : unfavoriteIcon
        
        if showFavoriteIcon {
            if let favorite = heartIcon {
                icons.append((favorite.icon, favorite.font, UIColor(styles.infoFavoriteIconColor)))
            }
        }
        if let info = closeIcon {
            icons.append((info.icon, info.font, UIColor(styles.closeIConColor)))
        }
        return icons
    }
}

// MARK: - Room Start-in Timer
extension BingoWidgetRoomViewModel {
    private func startTimer() {
        timer = Timer.publish(every: tickInterval, on: .main, in: .common)
            .autoconnect()
        subscription = timer?
            .sink { [weak self] _ in
                guard let self else { return }
                self.gameStartInTime = self.formatStartInTime()
                if stopTicking { stopTimer() }
            }
    }
    
    private func stopTimer() {
        timer?.upstream.connect().cancel()
        timer = nil
    }
    
    private func formatStartInTime() -> String {
        let timeInterval = model.startInTime
        stopTicking = false
        gameAboutToStart = false
        
        let date = Date(timeIntervalSince1970: TimeInterval(timeInterval))
        let result = Date().compare(date)
        
        guard model.insurance == false else {
            self.shouldUpdateTimerColor = true
            return model.playingSoonText
        }
        
        guard timeInterval != 0 else {
            return model.startedText
        }
        
        guard result == .orderedAscending else {
            stopTicking = true
            gameAboutToStart = true
            return model.startedText
        }
        
        let timeComponents = date.time(from: Date())
        let days = timeComponents.day ?? 0
        let hours = timeComponents.hour ?? 0
        let minutes = timeComponents.minute ?? 0
        let seconds = timeComponents.second ?? 0
        
        if days > 0 {
            return "\(days.leadingZero):\(hours.leadingZero):\(minutes.leadingZero):\(seconds.leadingZero)"
        } else if hours > 0 {
            return "\(hours.leadingZero):\(minutes.leadingZero):\(seconds.leadingZero)"
        } else if minutes > 0 || seconds >= 0 {
            let totalSeconds = minutes * 60 + seconds
            updateTimerColor(seconds: totalSeconds)
            updateProgress(seconds: totalSeconds)
            
            if minutes > 0 {
                return "\(minutes.leadingZero):\(seconds.leadingZero)"
            } else {
                if seconds == 0 {
                    self.fetchBingoRooms()
                }
                return "\(seconds.leadingZero)"
            }
        }
        return ""
    }
    
    private func updateProgress(seconds: Int) {
        if seconds <= progressBarStartTime && progress <= Double(progressBarStartTime) {
            if seconds == 0 {
                progress = 0.0
            } else if progress == 0.0 {
                progress = Double(progressBarStartTime - (seconds-1))
            } else {
                progress = Double(progressBarStartTime - seconds) + progressIncrement
            }
        }
    }
    
    private func updateTimerColor(seconds: Int) {
        if seconds < roomStartInTimeAlertInterval {
            self.shouldUpdateTimerColor = true
        }
    }
}

// MARK: - Helper
extension BingoWidgetRoomViewModel {
    static private func getIcon(
        name: String,
        size: CGFloat
    ) -> IconVariant? {
        let icon = EpcotLobbyManager.shared?
            .datasource?
            .didRequestForIconVariant(with: name, fontSize: size)
        return icon
    }
    
    private var bingoWidgetConfig: BingoWidget? {
        DynaconAPIConfiguration.shared?.posAppConfig?.odrAws?.bingoWidget
    }
    
    private func openLoginPage(completion: ((Bool) -> Void)? = nil) {
        EpcotLobbyManager.shared?.delegate?.didRequestLogin(completionHandler: completion)
    }
}

// MARK: Favourite
extension BingoWidgetRoomViewModel {
    func updateFavourite() {
        guard self.isLoggedIn else {
            self.openLoginPage { [weak self] loggedIn in
                if loggedIn {
                    self?.updateFavourite()
                }
            }
            return
        }
        guard let route = DynaconAPIConfiguration.shared?.posAppConfig?.services?.bingoWidgetRoute else { return }
        let bingoRouter = BingoWidgetFavouriteService(route: route)
        Task {
            do {
                let favouriteResult = try await bingoRouter.update(rooms: self.model.ids, status: !self.model.isFavourited).get()
                if let success = favouriteResult as? Bool, success {
                    self.model.updateFavourite()
                }
            }
            catch {
                ETLogger.debug(error.localizedDescription)
            }
        }
        if self.model.isFavourited {
            self.trackEvent(for: .unfavourite)
        } else {
            self.trackEvent(for: .favourite)
        }
    }
}
