//
//  BingoWidgetsStub.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 10/01/24.
//

import Foundation
import CasinoAPI

struct BingoWidgetsStub {
    var models = [BingoWidgetRoom]()

    init() {
        let gamesList = self.loadJson()
        gamesList?.forEach { list in
            let model = BingoWidgetRoom(
                gameLists: [list],
                favouriteRoomIds: [],
                roomImage: nil,
                roomNames: BingoRoomNames(),
                gameFeatureIcons: BingoRoomIcons(),
                roomTexts: nil,
                globalTexts: nil, 
                combinedRoomTexts: BingoRoomSEPTexts(),
                combinedRooms: BingoWidgetCombinedRooms()
            )
            models.append(model)
        }
    }
    
    private func loadJson() -> [GamesList]? {
        if let url = kEpcotBundle.url(forResource: "BingoWidgetsData", withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                let jsonData = try decoder.decode(BingoLobbyModel.self, from: data)
                return jsonData.result?.gamesList
            } catch {
                print("error:\(error)")
            }
        }
        return nil
    }

    var gamesList: [GamesList]? { loadJson() }
}
