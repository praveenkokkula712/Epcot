//
//  InfoPopupView.swift
//  EpcotLobby
//
//  Created by Bandaru Priyanka on 18/01/24.
//

import SwiftUI

struct InfoPopup: View {
    @Binding var showInfoPopup: Bool
    @ObservedObject var viewModel: BingoWidgetRoomViewModel
    private let styles = BingoWidgetViewCSS()
   
    var body: some View {
        VStack(spacing: 8) {
            
            HStack(alignment: .center, spacing: 16) {
                
                // Title
                Text(viewModel.infoTitle)
                    .font(styles.infoTitleFont)
                    .foregroundColor(styles.infoTitleColor)
                    .frame(maxWidth: .infinity, alignment: .topLeading)
                    .accessibilityIdentifier(BingoWidgetAccessID.INFO_ROOM_TITLE)
                
                // Favourite && Close icon
                WidgetGameFeatureIconHStack(
                    icons: viewModel.favoriteCloseIconsContent,
                    accessibilityIdentifiers: [
                        BingoWidgetAccessID.INFO_FAVORITE,
                        BingoWidgetAccessID.INFO_CLOSE
                    ]
                ) { index in
                    if index == 1 || !viewModel.showFavoriteIcon {
                        withAnimation(.easeInOut(duration: CGFloat(styles.infoAnimationDuration))) {
                            showInfoPopup.toggle()
                        }
                     } else {
                         //favourite action
                         viewModel.updateFavourite()
                     }
                }
            }
            .padding(.top, 8)
            
            // Description
            Text(viewModel.infoDescription)
                .font(styles.infoDescriptionFont)
                .foregroundColor(styles.infoDescriptionColor)
                .frame(maxWidth: .infinity, alignment: .leading)
                .accessibilityIdentifier(BingoWidgetAccessID.INFO_ROOM_DETAILS)

            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.top, 16)
        .background(
            Rectangle()
                .fill(styles.infoCardColor)
            .cornerRadius(CGFloat(styles.cornerRadius), corners: [.topLeft, .topRight])
        )
    }
}
