//
//  BingoWidgetProgressBarView.swift
//  EpcotLobby
//
//  Created by Sindhuja Vedire on 01/02/24.
//

import SwiftUI

struct BingoWidgetProgressBarView: View {
    private var value: Double
    private var totalValue: Int
    private var completionSpeed = 1.0
    private let styles = BingoWidgetViewCSS()
    
    init(value: Double, totalValue: Int) {
        self.value = value
        self.totalValue = totalValue
    }
    
    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .trailing) {
                progressBar(proxy: proxy)
                    .transition(.opacity)
                    .zIndex(1)
                fillProgressBar(proxy: proxy)
                    .transition(.opacity)
                    .zIndex(2)
            }
            .accessibilityElement(children: .contain)
            .accessibilityLabel("\(value) of \(totalValue)")
            .accessibilityIdentifier(BingoWidgetAccessID.PROGRESS_BAR)
        }
    }
    
    @ViewBuilder
    func progressBar(proxy: GeometryProxy) -> some View {
        Rectangle()
            .frame(width: proxy.size.width, height: proxy.size.height)
            .foregroundColor(styles.progressBarColor)
    }
    
    @ViewBuilder
    func fillProgressBar(proxy: GeometryProxy) -> some View {
        Rectangle()
            .frame(
                width: CGFloat(value / Double(totalValue)) * proxy.size.width,
                height: proxy.size.height
            )
            .foregroundColor(styles.progressBarTrackColor)
            .animation(value == 0.0 ? nil : .linear(duration: completionSpeed))
    }
}

struct BingoWidgetProgressBarView_Previews: PreviewProvider {
    static var previews: some View {
        BingoWidgetProgressBarView(value: 0.0, totalValue: 0)
    }
}
