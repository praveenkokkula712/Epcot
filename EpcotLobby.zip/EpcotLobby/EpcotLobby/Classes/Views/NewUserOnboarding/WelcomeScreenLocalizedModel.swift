//
//  WelcomeScreenLocalizedModel.swift
//  EpcotLobby
//
//  Created by Rajani Bhimanadham on 12/07/23.
//

import Foundation

class WelcomeScreenLocalizedModel: ObservableObject {
    @Published var title: String
    @Published var description: String
    @Published var getStarted: String
    @Published var skip: String
    
    init(title: String = "Welcome!", description: String = "Let's get started with a quick tour through our main features", getStarted: String = "Get Started", skip: String = "Skip for Now") {
        self.title = title
        self.description = description
        self.getStarted = getStarted
        self.skip = skip
    }
    
    func updateLocalizeStrings() {
        self.title = Localize.onboardingWelcomeScreenTitle
        self.description = Localize.onboardingWelcomeScreenDescription
        self.getStarted = Localize.onboardingWelcomeScreenGetStartedTitle
        self.skip = Localize.onboardingWelcomeScreenSkipNowTitle
    }
}
