//
//  OnboardingJourneyCSSModel.swift
//  EpcotLobby
//
//  Created by Rajani Bhimanadham on 26/04/23.
//

import Foundation
import Utility
import SwiftUI

struct OnboardingJourneyCSSModel {
    init() {
        
    }
    private var onboardingJourneyViewCSS: OnbordingJourneyViewCSS {
        return EpcotLobbyManager.shared?.css.onboardingViewCSS?.journeyViewCSS ?? DefaultOnboardingViewCss().journeyViewCSS
    }

    var titleFont: Font {
        Font(onboardingJourneyViewCSS.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var titleColor: Color {
        Color(onboardingJourneyViewCSS.title?.color ?? .black)
    }
    
    var descriptionFont: Font {
        Font(onboardingJourneyViewCSS.description?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var descriptionColor: Color {
        Color(onboardingJourneyViewCSS.description?.color ?? .black)
    }
    
    var closeButtonTextColor: Color {
        Color(self.onboardingJourneyViewCSS.closeButton?.title?.color ?? .white)
    }
        
    var backButtonTextColor: Color {
        Color(onboardingJourneyViewCSS.backBtn?.title?.color ?? .black)
    }
    
    var backButtonBGColor: Color {
        Color(onboardingJourneyViewCSS.backBtn?.selected ?? .black)
    }
    
    var backButtonTextFont: Font {
        Font(self.onboardingJourneyViewCSS.backBtn?.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var nextButtonTextColor: Color {
        Color(onboardingJourneyViewCSS.nextBtn?.title?.color ?? .black)
    }
    
    var nextButtonBGColor: Color {
        Color(onboardingJourneyViewCSS.nextBtn?.selected ?? .black)
    }
    
    var nextButtonTextFont: Font {
        Font(self.onboardingJourneyViewCSS.nextBtn?.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var journeyCountFount: Font {
        Font(onboardingJourneyViewCSS.journeyCount?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var journeyCountTextColor: Color {
        Color(onboardingJourneyViewCSS.journeyCount?.color ?? .black)
    }
    
    var journeyScreenBgColor: Color {
        Color(onboardingJourneyViewCSS.backgroundColor ?? .black)
    }
    
    var cornerRadius: CGFloat {
        4.0
    }
    
    var dividerColor: Color {
        Color(onboardingJourneyViewCSS.dividerColor ?? .black)
    }
    
    var overlayBorderColor: Color  {
        Color(onboardingJourneyViewCSS.overlayBorderColor ?? .black)
    }
}
