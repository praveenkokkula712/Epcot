//
//  CustomTextView.swift
//  EpcotLobby
//
//  Created by Rajani Bhimanadham on 05/05/23.
//

import SwiftUI

struct CustomTextView: View {
    var title : String
    var journeyViewCSS = OnboardingJourneyCSSModel()
    var body: some View {
        Text(title)
            .foregroundColor(journeyViewCSS.nextButtonTextColor)
            .font(journeyViewCSS.nextButtonTextFont)
            .background(journeyViewCSS.nextButtonBGColor)
    }
}
struct CustomTextView_Previews: PreviewProvider {
    static var previews: some View {
        CustomTextView(title: Localize.onboardingJourneyNextButtonTitle )
    }
}
