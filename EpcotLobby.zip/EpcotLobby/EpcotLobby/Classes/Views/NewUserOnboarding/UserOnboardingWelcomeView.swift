//
//  UserOnboardingWelcomeView.swift
//  EpcotLobby
//
//  Created by Rajani Bhimanadham on 04/04/23.
//

import SwiftUI

struct UserOnboardingWelcomeView: View {
    @StateObject var localizedModel:WelcomeScreenLocalizedModel = WelcomeScreenLocalizedModel(title: Localize.onboardingWelcomeScreenTitle, description: Localize.onboardingWelcomeScreenDescription, getStarted: Localize.onboardingWelcomeScreenGetStartedTitle, skip: Localize.onboardingWelcomeScreenSkipNowTitle)
    var clickAction: ((UserOnboardingWelcomeAction) -> ())?
    var welcomeScreenCSS = WelcomeScreenCSSModel()
    var screenWidth : CGFloat {
        UIDevice.isIPad() ? 0.35 : 0.60
    }
    var body: some View {
        ZStack {
            welcomeScreenCSS.overlayBgColor
                GeometryReader { proxy in
                    VStack {
                        HStack {
                            Spacer()
                            Button {
                                self.clickAction?(.close)
                            } label: {
                                Image(kCloseWhite,
                                      bundle: Bundle(for: EpcotLobbyViewController.self))
                                .colorMultiply(welcomeScreenCSS.closeButtonTextColor)
                                .frame(width: 10, height: 10)
                            }
                            .padding(.trailing, 24)
                            .padding(.top, 24)
                        }
                        
                        Text(localizedModel.title)
                            .foregroundColor(welcomeScreenCSS.titleColor)
                            .font(welcomeScreenCSS.titleFont)
                            .padding(.horizontal, 24)
                            .padding(.bottom, 4)
                            .padding(.top, 6)
                        
                        Text(localizedModel.description)
                            .foregroundColor(welcomeScreenCSS.descriptionColor)
                            .font(welcomeScreenCSS.descriptionFont)
                            .padding(.horizontal, 24)
                            .multilineTextAlignment(.center)
                        
                        VStack {
                            Button {
                                self.clickAction?(.started)
                            } label: {
                                Text(localizedModel.getStarted)
                                    .foregroundColor(welcomeScreenCSS.getStartedTitleColor)
                                    .font(welcomeScreenCSS.getStartedTitleFont)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical,12)
                                    .background(welcomeScreenCSS.getStartedBtnBgColor)
                                    .cornerRadius(welcomeScreenCSS.getStartedBtnCornerRadius)
                                    .frame(height: 32)
                            }
                            Button {
                                self.clickAction?(.skip)
                            } label: {
                                Text(localizedModel.skip)
                                    .foregroundColor(welcomeScreenCSS.skipNowTitleColor)
                                    .font(welcomeScreenCSS.skipNowTitleFont)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical,12)
                                    .background(welcomeScreenCSS.skipNowBgColor)
                                    .cornerRadius(welcomeScreenCSS.skipNowBtnCornerRadius)
                                    .frame(height: 48)
                            }
                        }
                        .padding(.top, 32)
                        .padding(.bottom, 8)
                        .padding(.horizontal, 24)
                    }
                    .background(welcomeScreenCSS.welcomeScreenBgColor)
                    .cornerRadius(welcomeScreenCSS.cornerRadius)
                    .position(x:proxy.size.width/2, y: proxy.size.height/2)
                    .frame(width: proxy.size.width*screenWidth)
                }
        }
        .edgesIgnoringSafeArea(.all)
    }
}

struct WelcomeScreenView_Previews: PreviewProvider {
    static var previews: some View {
        UserOnboardingWelcomeView(clickAction: nil)
    }
}

