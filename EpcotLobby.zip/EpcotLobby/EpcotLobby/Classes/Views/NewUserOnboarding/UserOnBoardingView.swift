//
//  UserOnBoardingView.swift
//
//  Created by Rajani Bhimanadham on 29/03/23.
//

import SwiftUI
import CasinoAPI
import Utility

let kPadding = 12.0
struct UserOnBoardingView: View {
    let journey: UserOnboardingJourney
    ///page start from 1
    let currentPage: Int
    let numberOfPages: Int
    var clickAction: ((UserOnboardingViewAction) -> ())?
    var journeyViewCSS = OnboardingJourneyCSSModel()
    
    var body: some View {
        ZStack {
            VStack {
                HStack {
                    Text(journey.title?.localized ?? "Account")
                        .frame(alignment: .leading)
                        .foregroundColor(journeyViewCSS.titleColor)
                        .font(journeyViewCSS.titleFont)
                        .padding(.leading, kPadding)
                    Spacer()
                    
                    Button {
                        self.clickAction?(.close)
                    } label: {
                        Image(kCloseWhite,bundle: Bundle(for: EpcotLobbyViewController.self))
                            .colorMultiply(journeyViewCSS.closeButtonTextColor)
                    }
                    .padding(.trailing, kPadding)
                }
                .padding(.top, kPadding)
                
                HStack {
                    Text(journey.description?.localized ?? "You can access account related info")
                        .foregroundColor(journeyViewCSS.descriptionColor)
                        .font(journeyViewCSS.descriptionFont)
                    Spacer(minLength: 0)
                }
                .padding(.leading, kPadding)
                .padding(.top, 8)
                .padding(.bottom, 16)
                
                VStack(spacing: kPadding) {
                    journeyViewCSS.dividerColor
                        .frame(height: 1)
                    HStack(alignment: .center) {
                        ///as page start from 1, current page should be grater than 1 to display back option
                        if currentPage > 1, numberOfPages > 1 {
                            Button {
                                self.clickAction?(.back)
                            } label: {
                                Text(Localize.onboardingJourneyBackButtonTitle)
                                    .foregroundColor(journeyViewCSS.backButtonTextColor)
                                    .font(journeyViewCSS.backButtonTextFont)
                                    .background(journeyViewCSS.backButtonBGColor)
                            }
                        }
                        Spacer()
                        
                        Text("\(currentPage) / \(numberOfPages)")
                            .foregroundColor(journeyViewCSS.journeyCountTextColor)
                            .font(journeyViewCSS.journeyCountFount)
                        Spacer()
                        
                        if numberOfPages > currentPage {
                            Button {
                                self.clickAction?(.next)
                            } label: {
                                CustomTextView(title: Localize.onboardingJourneyNextButtonTitle )
                            }
                            
                        } else if numberOfPages == currentPage {
                            Button {
                                self.clickAction?(.done)
                            } label: {
                                CustomTextView(title: Localize.onboardingJourneyDoneButtonTitle )
                            }
                        }
                    }
                    .frame(height: 14)
                    .padding(.horizontal, kPadding)
                    .padding(.bottom, 8)
                }
                .frame(height: 35)
             }
            .background(journeyViewCSS.journeyScreenBgColor)
        }
        .frame(maxWidth: 200)
        .edgesIgnoringSafeArea(.all)
    }
}

struct UserOnBoardingView_Previews: PreviewProvider {
    static var previews: some View {
        let json: [String: Any] = ["title": "account",
                                   "description": "account_description",
                                   "isPreLogin": false,
                                   "isPostLogin": true,
                                   "isVisited": false,
                                   "showAfterClose": false,
                                   "showAfterSkip": false,
                                   "tipDirection": "down"]
        if let userJourney = try? json.data()?.jsonDecoder(UserOnboardingJourney.self).get() {
            UserOnBoardingView(journey: userJourney,
                               currentPage: 1,
                               numberOfPages: 1,
                               clickAction: nil
            )
        } else {
            EmptyView()
        }
    }
}
