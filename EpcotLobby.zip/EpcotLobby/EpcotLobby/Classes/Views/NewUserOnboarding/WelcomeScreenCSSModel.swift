//
//  WelcomeScreenCSSModel.swift
//  EpcotLobby
//
//  Created by Rajani Bhimanadham on 26/04/23.
//

import Foundation
import Utility
import SwiftUI

struct WelcomeScreenCSSModel {
    init() {
        
    }
    private var onboardingViewCSS: OnbordingWelcomeScreenCSS {
        return EpcotLobbyManager.shared?.css.onboardingViewCSS?.welcomeScreenCSS ?? DefaultOnboardingViewCss().welcomeScreenCSS
    }

    var titleFont: Font {
        Font(onboardingViewCSS.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var titleColor: Color {
        Color(onboardingViewCSS.title?.color ?? .black)
    }
    
    var descriptionFont: Font {
        Font(onboardingViewCSS.description?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var descriptionColor: Color {
        Color(onboardingViewCSS.description?.color ?? .black)
    }
    
    var closeButtonTextColor: Color {
        Color(self.onboardingViewCSS.closeButton?.title?.color ?? .white)
    }
    
    var overlayBgColor: Color {
        Color(self.onboardingViewCSS.overlayBgColor ?? .white)
    }
    
    var getStartedTitleColor: Color {
        Color(onboardingViewCSS.getStartedButton?.title?.color ?? .black)
    }
    
    var getStartedBtnBgColor: Color {
        Color(onboardingViewCSS.getStartedButton?.selected ?? .black)
    }
    
    var getStartedTitleFont: Font {
        Font(self.onboardingViewCSS.getStartedButton?.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var skipNowTitleColor: Color {
        Color(onboardingViewCSS.skipButton?.title?.color ?? .black)
    }
    
    var skipNowBgColor: Color {
        Color(onboardingViewCSS.skipButton?.selected ?? .black)
    }
    
    var skipNowTitleFont: Font {
        Font(self.onboardingViewCSS.skipButton?.title?.font ?? UIFont.systemFont(ofSize: 14))
    }
    
    var welcomeScreenBgColor: Color {
        Color(onboardingViewCSS.backgroundColor ?? .black)
    }
    
    var cornerRadius: CGFloat {
        CGFloat(self.onboardingViewCSS.cornerRadius ?? 8.0)
    }
    
    var getStartedBtnCornerRadius: CGFloat {
        CGFloat(self.onboardingViewCSS.getStartedButtonCornerRadius ?? 8.0)
    }
    
    var skipNowBtnCornerRadius: CGFloat {
        CGFloat(self.onboardingViewCSS.skipButtonCornerRadius ?? 8.0)
    }
}
