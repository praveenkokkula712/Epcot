//
//  File.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 02/05/24.
//

import UIKit
import SwiftUI
import CasinoAPI

extension EpcotLobbyViewController {
    func presentFreeSpinsOverlayView(with freeSpin: FreeSpin?,
                                     gameNames: [String],
                                     onGameTap: ((Game) -> Void)? = nil) {
        let viewModel = FreeSpinsOverlayViewModel(
            feedDatasource: self,
            freeSpin: freeSpin,
            gameNames: gameNames,
            onGameTap: onGameTap
        ) { [weak self] in
            self?.freeSpinsOverlayController?.dismiss(animated: true)
            self?.freeSpinsOverlayController = nil
        }
        
        let freeSpinsOverlay = FreeSpinsOverlayView(viewModel: viewModel)
        self.freeSpinsOverlayController = UIHostingController(rootView: freeSpinsOverlay)
        self.freeSpinsOverlayController?.modalPresentationStyle = .overFullScreen
        self.freeSpinsOverlayController?.modalPresentationCapturesStatusBarAppearance = true
        self.freeSpinsOverlayController?.view.layer.speed = 0.75
        self.freeSpinsOverlayController?.view.backgroundColor = .black.withAlphaComponent(0.5)
        if let freeSpinsOverlayController,
            let topController = UIApplication.mainWindow.rootViewController {
            topController.present(freeSpinsOverlayController, animated: true)
        }
    }
}
