//
//  FreeSpinsStub.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 22/04/24.
//

import Foundation
import CasinoAPI

struct FreeSpinsStub {
    private(set) var prominentFreeSpins: ProminentFreeSpins?
    private(set) var freeSpinDetails: ProminentFreeSpinDetails?
    private(set) var freeSpins = [FreeSpin]()

    init() {
        prominentFreeSpins = loadFreeSpins(from: "ProminentFreeSpinsData")
        freeSpinDetails = loadFreeSpins(from: "ProminentFreeSpinsDetails")
        freeSpins = freeSpinDetails?.rewardDetails ?? []
    }

    private func loadFreeSpins<T: Codable>(from file: String) -> T? {
        if let url = kEpcotBundle.url(forResource: file, withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                let jsonData = try decoder.decode(T.self, from: data)
                return jsonData
            } catch {
                print("error:\(error)")
            }
        }
        return nil
    }
}
