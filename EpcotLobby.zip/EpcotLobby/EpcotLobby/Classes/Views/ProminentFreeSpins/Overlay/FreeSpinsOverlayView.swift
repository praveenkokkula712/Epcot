//
//  FreeSpinsOverlayView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 02/05/24.
//

import SwiftUI
import Kingfisher
import Utility
import TrackerClient

struct FreeSpinsOverlayView: View {
    @ObservedObject var viewModel: FreeSpinsOverlayViewModel
    private let css = FreeSpinsOverlayCss()
    
    var body: some View {
        ZStack(alignment: .bottom) {
            Color.clear
                .contentShape(Rectangle())
                .ignoresSafeArea()
                .onTapGesture(perform: viewModel.onClose)

            VStack(spacing: 0) {
                //Header
                HStack(alignment: .bottom) {
                    VStack(alignment: .leading) {
                        Text(viewModel.headerText)
                            .foregroundColor(css.headerTitleColor)
                            .font(css.headerTitleFont)
                            .accessibilityIdentifier(ProminentFreeSpinsAccessID.BONUS_SPINS)

                        Text(viewModel.spinExpiryTime)
                            .foregroundColor(css.headerSubTitleColor)
                            .font(css.headerSubTitleFont)
                            .accessibilityValue(viewModel.spinExpiry)
                            .accessibilityIdentifier(ProminentFreeSpinsAccessID.OFFER_EXPIRY)
                    }
                    .padding(.top, 12)
                    .padding(.bottom, 4)
                    Spacer ()
                    Button {
                        viewModel.onClose()
                        self.trackEvent(eventDetails: EpcotEventDetails.close.rawValue,
                                        eventAction: EpcotEventAction.click.rawValue,
                                        eventLabel: viewModel.headerText)
                    } label: {
                        Text(viewModel.closeText)
                            .foregroundColor(css.headerButtonTitleColor)
                            .font(css.headerButtonTitleFont)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .frame(height: 32)
                            .overlay {
                                RoundedRectangle(cornerRadius: css.headerButtonCornerRadius)
                                    .stroke(css.headerButtonBorderColor, lineWidth: css.headerButtonBorderWidth)
                            }
                    }
                    .padding(.bottom, 7)
                    .accessibilityIdentifier(ProminentFreeSpinsAccessID.CLOSE)
                }
                .padding(.horizontal, 16)
                .background(
                    css.headerBgColor
                        .cornerRadius(css.overlayCornerRadius, corners: [.topLeft, .topRight])
                )
                
                VStack(spacing: 0) {
                    //Winnings Section
                    HStack {
                        //Image
                        if let url = viewModel.currentWinningsImage {
                            KFImage(URL(string: url))
                                .placeholder {
                                    PlaceHolderImage()
                                        .frame(width: 46, height: 46)
                                        .cornerRadius(css.winningsImageCornerRadius, corners: .allCorners)
                                }
                                .resizable()
                                .frame(width: 46, height: 46)
                                .cornerRadius(css.winningsImageCornerRadius)
                                .accessibilityIdentifier(ProminentFreeSpinsAccessID.CTA_IMAGE)
                        }
                        
                        VStack(spacing: 0) {
                            //winnings
                            HStack {
                                Text(viewModel.currentWinningsText)
                                    .foregroundColor(css.winningsTitleColor)
                                    .font(css.winningsTitleFont)
                                    .accessibilityIdentifier(ProminentFreeSpinsAccessID.CURRENT_WINNINGS_TITLE)

                                Spacer()

                                Text(viewModel.winAmount)
                                    .foregroundColor(css.winningsAmountTitleColor)
                                    .font(css.winningsAmountTitleFont)
                                    .accessibilityIdentifier(ProminentFreeSpinsAccessID.CURRENT_WINNINGS)
                            }
                            .padding(.bottom, 8.0)
                            
                            //Progress
                            FreeSpinsProgressBarView(
                                value: viewModel.usedSpins,
                                totalValue: viewModel.totalSpins
                            )
                            .frame(height: 6.0)
                            
                            //spins
                            HStack {
                                Text(viewModel.completedSpinsText)
                                    .foregroundColor(css.totalSpinsTitleColor)
                                    .font(css.totalSpinsTitleFont)
                                    .accessibilityValue("\(viewModel.usedSpins)/\(viewModel.totalSpins)")
                                    .accessibilityIdentifier(ProminentFreeSpinsAccessID.USED_SPINS)

                                Spacer()

                                Text(viewModel.remainingSpins)
                                    .foregroundColor(css.spinsLeftTitleColor)
                                    .font(css.spinsLeftTitleFont)
                                    .accessibilityValue("\(viewModel.availableSpins)")
                                    .accessibilityIdentifier(ProminentFreeSpinsAccessID.REMAINING_SPINS)
                            }
                            .padding(.top, 4.0)
                        }
                    }
                    .padding(.top, 10.0)
                    
                    //Games
                    if !viewModel.gameNames.isEmpty {
                        FreeSpinsOverlayGamesView(
                            viewModel: FreeSpinsOverlayGamesViewModel(
                                feedDatasource: viewModel.feedDatasource,
                                gameNames: viewModel.gameNames,
                                onGameTap: viewModel.onGameTap
                            )
                        )
                        .padding(.top, 12.0)
                    }
                    
                    //Divider
                    Divider()
                        .frame(height: 1)
                        .background(css.footerDividerColor)
                        .padding(.top, 16)
                        .padding(.bottom, 4)
                    
                    //CTA
                    HStack {
                        Button {
                            viewModel.onCTAClick()
                            self.trackEvent(eventDetails: viewModel.ctaText,
                                            eventAction: EpcotEventAction.click.rawValue,
                                            eventLabel: viewModel.headerText)
                        } label: {
                            Text(viewModel.ctaText)
                                .foregroundColor(css.ctaTitleColor)
                                .font(css.ctaTitleFont)
                                .underline(true, color: css.ctaTitleColor)
                                .padding(8)
                                .offset(x: -8)
                        }
                        .accessibilityIdentifier(ProminentFreeSpinsAccessID.MORE_DETAILS)

                        Spacer()
                    }
                }
                .padding(.horizontal, 16)
                .background(css.overlayBgColor)
            }
        }
        .onAppear {
            self.trackEvent(eventDetails: EpcotEventDetails.free_spins_screen_load.rawValue,
                            eventAction: EpcotEventAction.click.rawValue,
                            eventLabel: viewModel.headerText)
        }
    }
}

struct FreeSpinsOverlayView_Previews: PreviewProvider {
    static var previews: some View {
        FreeSpinsOverlayView(
            viewModel: FreeSpinsOverlayViewModel(
                gameNames: [],
                onClose: { }
            )
        )
    }
}
