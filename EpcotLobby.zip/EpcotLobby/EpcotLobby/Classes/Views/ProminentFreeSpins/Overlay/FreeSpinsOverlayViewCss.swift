//
//  FreeSpinsOverlayViewCss.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 02/05/24.
//

import SwiftUI
import Utility

struct FreeSpinsOverlayCss {
    // MARK: Properties
    var overlayBgColor: Color
    var overlayCornerRadius: CGFloat

    var headerBgColor: Color
    var headerTitleColor: Color
    var headerTitleFont: Font
    var headerSubTitleColor: Color
    var headerSubTitleFont: Font
    var headerButtonTitleColor: Color
    var headerButtonTitleFont: Font
    var headerButtonCornerRadius: CGFloat
    var headerButtonBorderColor: Color
    var headerButtonBorderWidth: CGFloat

    var winningsImageCornerRadius: CGFloat
    var winningsTitleColor: Color
    var winningsTitleFont: Font
    var winningsAmountTitleColor: Color
    var winningsAmountTitleFont: Font
    
    var spinsProgressBgColor: Color
    var spinsProgressFillColor: Color
    
    var totalSpinsTitleColor: Color
    var totalSpinsTitleFont: Font
    var spinsLeftTitleColor: Color
    var spinsLeftTitleFont: Font

    var eligibleGamesTitleColor: Color
    var eligibleGamesTitleFont: Font
    
    var footerDividerColor: Color
    
    var ctaTitleColor: Color
    var ctaTitleFont: Font

    // MARK: Init
    init() {
        let css: FreeSpinsOverlayCSS? = Self.lobbyCSS?.freeSpinsCSS?.overlayCSS
        self.overlayBgColor = (css?.backgroundColor ?? Self.defaultOverlayBgColor).swiftUIColor
        self.overlayCornerRadius = css?.overlayCornerRadius ?? Self.defaultOverlayCornerRadius
        
        self.headerBgColor = (css?.headerBgColor ?? Self.defaultHeaderBgColor).swiftUIColor
        self.headerTitleColor  = (css?.headerTitle?.color ?? Self.defaultHeaderTitleColor).swiftUIColor
        self.headerTitleFont = Font(css?.headerTitle?.font ?? Self.defaultHeaderTitleFont)
        self.headerSubTitleColor = (css?.headerSubTitle?.color ?? Self.defaultHeaderSubTitleColor).swiftUIColor
        self.headerSubTitleFont = Font(css?.headerSubTitle?.font ?? Self.defaultHeaderSubTitleFont)
        self.headerButtonTitleColor = (css?.headerButton?.title?.color ?? Self.defaultHeaderButtonTitleColor).swiftUIColor
        self.headerButtonTitleFont = Font(css?.headerButton?.title?.font ?? Self.defaultHeaderButtonTitleFont)
        self.headerButtonCornerRadius = css?.headerButtonCornerRadius ?? Self.defaultHeaderButtonCornerRadius
        self.headerButtonBorderColor = (css?.headerButtonBorderColor ?? Self.defaultHeaderButtonBorderColor).swiftUIColor
        self.headerButtonBorderWidth = css?.headerButtonBorderWidth ?? Self.defaultHeaderButtonBorderWidth
        
        self.winningsImageCornerRadius = css?.winningsImageCornerRadius ?? Self.defaultWinningsImageCornerRadius
        self.winningsTitleColor = (css?.winningsTitle?.color ?? Self.defaultWinningsTitleColor).swiftUIColor
        self.winningsTitleFont = Font(css?.winningsTitle?.font ?? Self.defaultWinningsTitleFont)
        self.winningsAmountTitleColor = (css?.winningsAmountTitle?.color ?? Self.defaultWinningsAmountTitleColor).swiftUIColor
        self.winningsAmountTitleFont = Font(css?.winningsAmountTitle?.font ?? Self.defaultWinningsAmountTitleFont)
        
        self.spinsProgressBgColor = (css?.spinsProgressBgColor ?? Self.defaultSpinsProgressBgColor).swiftUIColor
        self.spinsProgressFillColor = (css?.spinsProgressFillColor ?? Self.defaultSpinsProgressFillColor).swiftUIColor
        
        self.totalSpinsTitleColor = (css?.totalSpinsTitle?.color ?? Self.defaultTotalSpinsTitleColor).swiftUIColor
        self.totalSpinsTitleFont = Font(css?.totalSpinsTitle?.font ?? Self.defaultTotalSpinsTitleFont)
        self.spinsLeftTitleColor = (css?.totalSpinsTitle?.color ?? Self.defaultTotalSpinsTitleColor).swiftUIColor
        self.spinsLeftTitleFont = Font(css?.spinsLeftTitle?.font ?? Self.defaultTotalSpinsTitleFont)

        self.eligibleGamesTitleColor = (css?.eligibleGamesTitle?.color ?? Self.defaultEligibleGamesTitleColor).swiftUIColor
        self.eligibleGamesTitleFont = Font(css?.eligibleGamesTitle?.font ?? Self.defaultEligibleGamesTitleFont)
        
        self.footerDividerColor = (css?.footerDividerColor ?? Self.defaultFooterDividerColor).swiftUIColor
        
        self.ctaTitleColor = (css?.ctaTitle?.title?.color ?? Self.defaultCTATitleColor).swiftUIColor
        self.ctaTitleFont = Font(css?.ctaTitle?.title?.font ?? Self.defaultCTATitleFont)
    }
}

// MARK: - Helper
extension FreeSpinsOverlayCss: LobbyStylable { }

extension FreeSpinsOverlayCss {
    private static var defaultOverlayBgColor: UIColor { UIColor.hexStringToUIColor(hex: "#FFFFFF") }
    private static var defaultOverlayCornerRadius: CGFloat { 16.0 }

    private static var defaultHeaderBgColor: UIColor { UIColor.hexStringToUIColor(hex: "#F3F4F5") }
    private static var defaultHeaderTitleColor: UIColor { UIColor.hexStringToUIColor(hex: "#050505") }
    private static var defaultHeaderTitleFont: UIFont { .boldSystemFont(ofSize: 17) }
    private static var defaultHeaderSubTitleColor: UIColor { UIColor.hexStringToUIColor(hex: "#ED2A2A") }
    private static var defaultHeaderSubTitleFont: UIFont { .systemFont(ofSize: 11) }
    private static var defaultHeaderButtonTitleColor: UIColor { UIColor.hexStringToUIColor(hex: "#050505") }
    private static var defaultHeaderButtonTitleFont: UIFont { .systemFont(ofSize: 13) }
    private static var defaultHeaderButtonCornerRadius: CGFloat { 16.0 }
    private static var defaultHeaderButtonBorderColor: UIColor { UIColor.hexStringToUIColor(hex: "#303030", withAlpha: 0.28) }
    private static var defaultHeaderButtonBorderWidth: CGFloat { 1 }

    private static var defaultWinningsImageCornerRadius: CGFloat { 12.0 }
    private static var defaultWinningsTitleColor: UIColor { UIColor.hexStringToUIColor(hex: "#050505") }
    private static var defaultWinningsTitleFont: UIFont { .systemFont(ofSize: 13) }
    private static var defaultWinningsAmountTitleColor: UIColor { UIColor.hexStringToUIColor(hex: "#050505") }
    private static var defaultWinningsAmountTitleFont: UIFont { .boldSystemFont(ofSize: 17) }
    
    private static var defaultSpinsProgressBgColor: UIColor { UIColor.hexStringToUIColor(hex: "#050505", withAlpha: 0.28) }
    private static var defaultSpinsProgressFillColor: UIColor { UIColor.hexStringToUIColor(hex: "#C0A971") }
    
    private static var defaultTotalSpinsTitleColor: UIColor { UIColor.hexStringToUIColor(hex: "#63656A") }
    private static var defaultTotalSpinsTitleFont: UIFont { .systemFont(ofSize: 11) }
    private static var defaultSpinsLeftTitleColor: UIColor { UIColor.hexStringToUIColor(hex: "#050505") }
    private static var defaultSpinsLeftTitleFont: UIFont { .systemFont(ofSize: 11) }

    private static var defaultEligibleGamesTitleColor: UIColor { UIColor.hexStringToUIColor(hex: "#050505") }
    private static var defaultEligibleGamesTitleFont: UIFont { .systemFont(ofSize: 14) }
    
    private static var defaultFooterDividerColor: UIColor { UIColor.hexStringToUIColor(hex: "#C1C1C1") }
    
    private static var defaultCTATitleColor: UIColor { UIColor.hexStringToUIColor(hex: "#475EEC") }
    private static var defaultCTATitleFont: UIFont { .systemFont(ofSize: 12) }
}
