//
//  FreeSpinsOverlayViewModel.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 02/05/24.
//

import Foundation
import ConfigModule

class FreeSpinsOverlayViewModel: ObservableObject {
    
    // MARK: Properties
    private(set) var feedDatasource: LobbyFeedDataSource?
    private(set) var freeSpin: FreeSpin?
    private(set) var gameNames: [String]
    private(set) var onGameTap: ((Game) -> Void)?
    private(set) var onClose: () -> Void
    private var freeSpinsTimer: FreeSpinsTimer?
    @Published var spinExpiry: String = ""
    
    // MARK: Init
    init(
        feedDatasource: LobbyFeedDataSource? = nil,
        freeSpin: FreeSpin? = nil,
        gameNames: [String],
        onGameTap: ((Game) -> Void)? = nil,
        onClose: @escaping () -> Void
    ) {
        self.feedDatasource = feedDatasource
        self.freeSpin = freeSpin
        self.gameNames = gameNames
        self.onGameTap = onGameTap
        self.onClose = onClose
        self.initializeFreeSpinTimer()
    }
}

// MARK: - UI Configuration
extension FreeSpinsOverlayViewModel {
    
    // MARK: Header
    var headerText: String { configTexts?.mainTitle ?? "Bonus Spins" }
    var closeText: String { configTexts?.close ?? "Close" }

    private func initializeFreeSpinTimer() {
        self.freeSpinsTimer = FreeSpinsTimer(
            expiryDate: freeSpin?.expiryDate,
            onUpdate: { [weak self] expiry in
                guard let self else { return }
                DispatchQueue.main.async {
                    self.spinExpiry = expiry
                }
            }
        )
    }

    var spinExpiryTime: String {
        if let expiryText = configTexts?.offerExpiringIn {
            return expiryText + spinExpiry
        }
        return ""
    }

    // MARK: Winning & Spins
    var currentWinningsText: String { configTexts?.currentWinnings ?? "Current Winnings" }

    var winAmount: String {
        let symbolPair = DynaconAPIConfiguration.shared?
            .posAppConfig?
            .cashier?
            .currencySymbol
        let currency = symbolPair?[(freeSpin?.currency ?? "")] ?? ""
        let amount = String(format: "%.2f", Double(freeSpin?.winAmount ?? "0") ?? 0)
        return currency + amount
    }

    var totalSpins: Int { freeSpin?.totalCount ?? 0 }

    var availableSpins: Int { freeSpin?.availableCount ?? 0 }

    var usedSpins: Int {
        return totalSpins - availableSpins
    }

    var completedSpinsText: String {
        let spinsCount = "\(usedSpins)/\(totalSpins)"
        let spinsText = "\(configTexts?.spinsUsed ?? "spin(s)")"
     
        return "\(spinsCount) \(spinsText)"
    }

    var remainingSpins: String {
        let text = configTexts?.spinsLeft ?? "spins left"
        return "\(availableSpins) \(text)"
    }
    
    // MARK: CTA
    var ctaText: String { configTexts?.viewDetailsText ?? "View Full Details" }
    
    func onCTAClick() {
        onClose()

        let posAppConfig = DynaconAPIConfiguration.shared?.posAppConfig
        let freeSpinsDetails = posAppConfig?.services?.prominentFreeSpinsDetails

        if let id = freeSpin?.id,
            let baseURL = freeSpinsDetails?.baseURL,
            let path = freeSpinsDetails?.freeSpinDetailsPath {
            var urlString = baseURL + path
            urlString = urlString.replacingOccurrences(of: "{FREE_SPIN_ID}", with: "\(id)")
            EpcotLobbyManager.shared?.delegate?.didClickWeblink(
                with: .freeSpinsDetails(urlString),
                buttonType: nil
            )
        }
    }
}

//MARK: - Helper
extension FreeSpinsOverlayViewModel {
    var configTexts: FreeSpinsConfigurationTexts? {
        POSAPI.shared?.freeSpinsWidgetConfigurationTexts
    }
    
    var currentWinningsImage: String? {
        POSAPI.shared?.freeSpinsWidgetCtaBackgroundImage
    }
}
