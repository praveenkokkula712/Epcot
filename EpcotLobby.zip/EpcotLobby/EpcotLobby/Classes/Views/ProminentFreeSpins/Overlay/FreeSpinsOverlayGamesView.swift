//
//  FreeSpinsOverlayGamesView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 02/05/24.
//

import SwiftUI
import Utility

struct FreeSpinsOverlayGamesView: View {
    @ObservedObject var viewModel: FreeSpinsOverlayGamesViewModel
    private let css = FreeSpinsOverlayCss()

    var body: some View {
        VStack(spacing: 20.0) {
            //title
            HStack {
                Text(viewModel.configTexts?.eligibleGames ?? "Eligible Game(s)")
                    .foregroundColor(css.eligibleGamesTitleColor)
                    .font(css.eligibleGamesTitleFont)
                    .padding(.vertical, 8)
                    .accessibilityIdentifier(ProminentFreeSpinsAccessID.ELIGIBLE_GAMES)
                Spacer()
            }
            
            //games
            ScrollView(.vertical, showsIndicators: false) {
                LazyVGrid(columns: columns) {
                    ForEach(viewModel.freeSpinGames, id: \.game.uuid) { game in
                        GameTileView(
                            game: game,
                            isFromSearch: false
                        )
                    }
                }
            }
            .frame(height: gridHeight)
            .padding(.bottom, 8)
        }
    }

    private var columns: [GridItem] {
        .init(repeating: GridItem(.fixed(GameTileImageSize)), count: columnsCount)
    }
    
    private var columnsCount: Int {
        return UIDevice.isIPad() ? 5 : 3
    }
    
    private var gridHeight: CGFloat {
        let gamesCount = viewModel.freeSpinGames.count
        let columnsCount = columnsCount
        var gridHeight = GameTileImageSize //single row
        if gamesCount > columnsCount {
            //2 rows
            gridHeight = (2*GameTileImageSize) + 12
        }
        if gamesCount > (2*columnsCount) {
            //multiple rows
            gridHeight = 2.6*GameTileImageSize
        }
        return gridHeight
    }
    
}


struct FreeSpinsOverlayGamesView_Previews: PreviewProvider {
    static var previews: some View {
        FreeSpinsOverlayGamesView(
            viewModel: FreeSpinsOverlayGamesViewModel(
                feedDatasource: nil,
                onGameTap: { _ in }
            )
        )
    }
}
