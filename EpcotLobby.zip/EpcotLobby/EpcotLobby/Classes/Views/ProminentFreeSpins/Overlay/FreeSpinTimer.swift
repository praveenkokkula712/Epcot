//
//  FreeSpinTimer.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 08/05/24.
//

import Foundation
import Combine

class FreeSpinsTimer {
    private var timer: Publishers.Autoconnect<Timer.TimerPublisher>?
    private var subscription: AnyCancellable?
    private let expiryDate: Int?
    private let onUpdate: ((String) -> Void)?
    
    init(expiryDate: Int? = nil,
         onUpdate: ((String) -> Void)? = nil) {
        self.expiryDate = expiryDate
        self.onUpdate = onUpdate
        self.updateSpinExpiryTime()
    }
}

//Expiry Time Update
extension FreeSpinsTimer {
    private func updateSpinExpiryTime() {
        if let expiryTime = getFormattedExpiryTime() {
            self.onUpdate?(expiryTime)
        }
    }

    // MARK: Expiry time update
    private func startTimer(interval: Int) {
        timer = Timer.publish(every: TimeInterval(interval), on: .main, in: .common)
            .autoconnect()
        subscription = timer?
            .sink { [weak self] _ in
                guard let self else { return }
                self.updateSpinExpiryTime()
            }
    }

    private func stopTimer() {
        timer?.upstream.connect().cancel()
        timer = nil
    }
    
    private func getFormattedExpiryTime() -> String? {
        guard let timeInterval = expiryDate else { return nil }
        let date = Date(timeIntervalSince1970: TimeInterval(timeInterval))
        let timeComponents = date.time(from: Date())
        let days = timeComponents.day ?? 0
        let hours = timeComponents.hour ?? 0
        let minutes = timeComponents.minute ?? 0
        let seconds = timeComponents.second ?? 0
    
        let daysString = "Days".localized
        let dayString = "Day".localized
        let hoursString = "limits_hours".localized
        let hourString = "limits_hour".localized
        let minutesString = "MinutesShort".localized
        let minuteString = "MinuteShort".localized
        let secondsString = "SecondsShort".localized
        let secondString = "SecondShort".localized
        
        if days > 0 {
            return days > 1 ? "\(days) \(daysString)" : "\(days) \(dayString)"
        } else if hours > 0 && hours <= 24 {
            startTimer(interval: hours > 1 ? TimerPeriod.hour.rawValue : TimerPeriod.minute.rawValue)
            if hours > 1 {
                return minutes > 0 ? "\(hours) \(hoursString) \(minutes) \(minutesString)" : "\(hours) \(hoursString)"
            } else {
                return minutes > 0 ? "\(hours) \(hourString) \(minutes) \(minutesString)" : "\(hours) \(hourString)"
            }
        } else if minutes > 0 && minutes <= 60 {
            let period = minutes > 1 ? TimerPeriod.minute : TimerPeriod.second
            startTimer(interval:  period.rawValue)
            return minutes > 1 ? "\(minutes) \(minutesString)" : "\(minutes) \(minuteString)"
        } else if seconds > 0 && seconds <= 60 {
            startTimer(interval: TimerPeriod.second.rawValue)
            return seconds > 1 ? "\(seconds) \(secondsString)" : "\(seconds) \(secondString)"
        }
        stopTimer()
        return ""
    }
}

fileprivate enum TimerPeriod: Int {
    case hour = 3600
    case minute = 60
    case second = 1
}
