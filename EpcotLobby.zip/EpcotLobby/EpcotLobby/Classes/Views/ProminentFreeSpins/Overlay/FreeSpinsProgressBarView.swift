//
//  FreeSpinsProgressBarView.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 03/05/24.
//

import SwiftUI

struct FreeSpinsProgressBarView: View {
    
    // MARK: - Properties
    private var value: CGFloat
    private var totalValue: CGFloat
    let css = FreeSpinsOverlayCss()
    
    // MARK: - Init
    init(
        value: Int,
        totalValue: Int
    ) {
        self.value = CGFloat(integerLiteral: value)
        self.totalValue = CGFloat(integerLiteral: totalValue)
    }
    
    var body: some View {
        GeometryReader { proxy in
            progressBar(proxy: proxy)
                .overlay(alignment: .leading) {
                    progressFillBar(proxy: proxy)
                }
        }
    }
    
    @ViewBuilder
    private func progressBar(proxy: GeometryProxy) -> some View {
        Rectangle()
            .frame(width: proxy.size.width, height: proxy.size.height)
            .foregroundColor(css.spinsProgressBgColor)
            .cornerRadius(proxy.size.height / 2)
    }
    
    @ViewBuilder
    private func progressFillBar(proxy: GeometryProxy) -> some View {
        Rectangle()
            .frame(
                width: min(
                    self.value / self.totalValue * proxy.size.width,
                    proxy.size.width
                ),
                height: proxy.size.height
            )
            .foregroundColor(css.spinsProgressFillColor)
            .cornerRadius(proxy.size.height / 2)
    }
}

struct FreeSpinsProgressBarView_Previews: PreviewProvider {
    static var previews: some View {
        FreeSpinsProgressBarView(value: 20, totalValue: 25)
    }
}
