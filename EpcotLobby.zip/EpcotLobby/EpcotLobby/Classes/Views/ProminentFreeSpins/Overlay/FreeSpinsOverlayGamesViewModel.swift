//
//  OverlayGamesViewModel.swift
//  EpcotLobby
//
//  Created by Sreekanth Reddy Tadi on 02/05/24.
//

import Foundation
import Combine
import CasinoAPI

class FreeSpinsOverlayGamesViewModel: ObservableObject {
    
    // MARK: Properties
    let feedDatasource: LobbyFeedDataSource?
    private(set) var immersiveInfo: ((Game) -> ImmersiveGameInfo?)?
    private(set) var blurImagePath: ((Game) -> String?)?
    private(set) var onFavoriteGameTap: ((Game) -> Void)?
    private(set) var sticker: ((Game) -> String?)?
    private(set) var onGameTap: ((Game) -> Void)?
    
    private var subscriber: AnyCancellable?
    private var jackpotTimer: DispatchTimer?
    private(set) var gameTilePublisher = GameTilePublisher()
    private(set) var gamesViewModel: SearchSectionGamesViewModel?
    
    @Published private(set) var freeSpinGames = [GameTile]()
    
    // MARK: Init
    init(feedDatasource: LobbyFeedDataSource? = nil,
         gameNames: [String]? = nil,
         onGameTap: ((Game) -> Void)? = nil) {
        self.feedDatasource = feedDatasource
        self.onGameTap = onGameTap
        self.cofigureBlurImagePath()
        self.configureImmersiveInfo()
        self.cofigureSticker()
        self.configureFavorite()
        self.subscribeToRefresh()
        self.configureGames(with: gameNames)
        self.startJackpotTimer()
    }
    
    // MARK: Subscriptions
    private func subscribeToRefresh() {
        self.subscriber = self.feedDatasource?.feedViewModel?.refreshLobby
            .subscribe(on: DispatchQueue.main)
            .sink { [weak self] shouldRefresh in
                guard let self else { return }
                if shouldRefresh {
                    self.stopJackpotTimer()
                    self.startJackpotTimer()
                } else {
                    //No need to call this method, if 'sholudRefresh' is true, because it atomatically updates the view
                    self.refreshJackporPrices()
                }
            }
    }
    
    // MARK: Helper
    var feedViewModel: FeedViewModel? {
        self.feedDatasource?.feedViewModel
    }
    
    var configTexts: FreeSpinsConfigurationTexts? {
        POSAPI.shared?.freeSpinsWidgetConfigurationTexts
    }
    
    var gamesLayoutStack: ContainerStack {
        guard UIDevice.isIPad() else {
            if freeSpinGames.count > 3 {
                return .double
            }
            return .single
        }
        return .single
    }
}

//MARK: - GameInfo
extension FreeSpinsOverlayGamesViewModel {
    private func cofigureBlurImagePath() {
        self.blurImagePath = { [weak self] game in
            guard let gameVariant = game.game else { return nil }
            return self?.feedViewModel?.getListCellBlurImagePath(for: gameVariant)
        }
    }
    
    private func cofigureSticker() {
        self.sticker = { [weak self] game in
            guard let gameVariant = game.sticker else { return nil }
            return self?.feedViewModel?.getCategoryName(for: gameVariant)
        }
    }
    
    private func configureImmersiveInfo() {
        self.immersiveInfo = { [weak self] game in
            guard let gameVariant = game.game else { return nil }
            return self?.feedViewModel?.getImmersiveInfo(for: gameVariant,
                                                         with: "\(LayoutType.freeSpinsWidget.rawValue)")
        }
    }
}

extension FreeSpinsOverlayGamesViewModel {
    private func configureFavorite() {
        self.onFavoriteGameTap = { [weak self] game in
            guard let gameVariant = game.game else { return }
            //Fetch local game info
            let gameFav = self?.immersiveInfo?(game)?.gameInfo.isFavouriteGame ?? false
            self?.updateFavorite(selected: !gameFav,
                                 for: gameVariant)
        }
    }
    
    private func updateFavorite(selected: Bool, for game: String) {
        
        //Updating local Feed
        self.feedViewModel?.updateFavouriteStateInFeed(with: selected,
                                                       for: game)
        //API
        Task {
            _ = try await self.feedViewModel?.updateFavouriteState(with: selected,
                                                                   for: game)
            let favoriteGames = self.feedDatasource?.feedViewModel?.favouriteGames?
                .reduce(into: [String: Bool](), { partialResult, favGame in
                    if let name = favGame.game {
                        partialResult[name] = true
                    }
                })
            //updating favorites through subscriber after API is completed
            let favorites = GameTileReceiver(favorite: favoriteGames)
            self.gameTilePublisher.send(favorites)
        }
    }
}

//MARK: - Jackpot
extension FreeSpinsOverlayGamesViewModel {
    private func startJackpotTimer() {
        guard  self.jackpotTimer == nil else { return }
        let randomInterval = Double.random(in: 1...6)
        self.jackpotTimer =  DispatchTimer(interval: randomInterval, handler: self.refreshJackpot)
    }
    
    func stopJackpotTimer() {
        guard self.jackpotTimer != nil else { return }
        self.jackpotTimer?.cancel()
        self.jackpotTimer = nil
    }
    
    private func refreshJackpot() {
        self.stopJackpotTimer()
        ///counter jackpot time update
        self.gameTilePublisher.send(nil)
        self.startJackpotTimer()
    }
    
    private func refreshJackporPrices () {
        if let jpPrices = self.feedViewModel?.getAllJackpotAmounts() {
            let jackpots = GameTileReceiver(jackpot: jpPrices)
            gameTilePublisher.send(jackpots)
        }
    }
}

//MARK: - configure Games
extension FreeSpinsOverlayGamesViewModel {
    func configureGames(with gameNames: [String]? = nil) {
        self.freeSpinGames.removeAll()
        guard let gameNames else {
            return
        }
        self.freeSpinGames = gameNames.map { gameName in
            let game = Game(game: gameName)
            return GameTile(
                game: game,
                sticker: sticker?(game),
                blurImagePath: blurImagePath?(game),
                immersiveInfo: immersiveInfo?(game),
                publisher: gameTilePublisher,
                onTap: { [weak self] gameTile in
                    self?.onGameTap?(gameTile.game)
                },
                onFavoriteTap: { [weak self] gameTile in
                    self?.onFavoriteGameTap?(gameTile.game)
                }
            )
        }
    }
}
