//
//  FreeSpinsButton.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 05/06/24.
//

import SwiftUI
import Utility
import TrackerClient

struct FreeSpinsButton: View {
    
    // MARK: Properties
    private var viewModel: FreeSpinViewModel
    private let styles = FreeSpinViewCSS()

    // MARK: Init
    init(viewModel: FreeSpinViewModel) {
        self.viewModel = viewModel
    }

    // MARK: Body
    var body: some View {
        Button {
            viewModel.trackEvent(eventDetails: EpcotEventDetails.free_spins_click.rawValue,
                                 eventAction: EpcotEventAction.click.rawValue,
                                 eventLabel: viewModel.texts?.mainTitle ?? EpcotEventLabel.free_spins.rawValue)
            viewModel.onFreeSpinTap()
        } label: {
            Text(viewModel.texts?.ctaText ?? "")
                .font(styles.spinTextFont)
                .padding(.vertical, 10.0)
                .padding(.horizontal, 22.0)
                .foregroundStyle(styles.spinTextColor)
                .clipShape(Capsule())
        }
        .buttonStyle(
            ButtonHighlightStyle(
                spinButtonTopColor: styles.spinButtonTopColor,
                spinButtonBottomColor: styles.spinButtonBottomColor,
                spinButtonBackgroundColor: styles.spinButtonBackgroundColor
            )
        )
    }
}

// MARK: - Buuton highlight with Animation
private struct ButtonHighlightStyle: ButtonStyle {
    let spinButtonTopColor: Color
    let spinButtonBottomColor: Color
    let spinButtonBackgroundColor: Color

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background(configuration.isPressed ? highlightGradient : gradient)
            .clipShape(Capsule())
            .animation(
                .easeOut(duration: 0.2),
                value: configuration.isPressed
            )
    }

    private var gradient: LinearGradient {
        LinearGradient(
            stops: [
                Gradient.Stop(color: spinButtonTopColor, location: 0.00),
                Gradient.Stop(color: spinButtonBottomColor, location: 1.00),
            ],
            startPoint: UnitPoint(x: -0.43, y: -0.41),
            endPoint: UnitPoint(x: 0.95, y: 0.72)
        )
    }

    private var highlightGradient: LinearGradient {
        LinearGradient(
            colors: [spinButtonBackgroundColor],
            startPoint: .leading,
            endPoint: .trailing
        )
    }
}
