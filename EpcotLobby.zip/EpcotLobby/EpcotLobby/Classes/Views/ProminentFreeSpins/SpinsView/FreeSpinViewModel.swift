//
//  FreeSpinViewModel.swift
//  InfiniteCarousalView
//
//  Created by Yemireddi Sateesh on 18/04/24.
//

import Foundation
import CasinoAPI
import Utility

typealias FreeSpin = ProminentFreeSpinDetail

class FreeSpinViewModel: ObservableObject {

    // MARK: Properties
    @Published var spinExpiry = ""

    private let freeSpin: FreeSpin
    let texts: FreeSpinsConfigurationTexts?
    let backgroundImage: String
    let onFreeSpinTap: () -> Void
    private var freeSpinsTimer: FreeSpinsTimer?

    // MARK: Init
    init(
        freeSpin: FreeSpin,
        texts: FreeSpinsConfigurationTexts? = nil,
        backgroundImage: String = "",
        onFreeSpinTap: @escaping () -> Void = {}
    ) {
        self.freeSpin = freeSpin
        self.texts = texts
        self.backgroundImage = backgroundImage
        self.onFreeSpinTap = onFreeSpinTap
        self.initializeFreeSpinTimer()
    }
    
    private func initializeFreeSpinTimer() {
        self.freeSpinsTimer = FreeSpinsTimer(
            expiryDate: freeSpin.expiryDate,
            onUpdate: { [weak self] expiry in
                guard let self else { return }
                DispatchQueue.main.async {
                    self.spinExpiry = expiry
                }
            }
        )
    }
    
    // MARK: UI Configuration
    var remainingSpins: String {
        if let text = texts?.spinsLeft, !spinsLeft.isEmpty {
            return "\(spinsLeft) \(text)!"
        }
        return ""
    }

    var spinsLeft: String {
        if let count = freeSpin.availableCount {
            return "\(count)"
        }
        return ""
    }

    var spinExpiryTime: String {
        if let expiryText = texts?.offerExpiringIn {
            return expiryText + spinExpiry
        }
        return ""
    }
}

// MARK: - Helper
extension FreeSpinViewModel {
    func getRefreshIcon(size: CGFloat) -> IconVariant? {
        let icon = EpcotLobbyManager.shared?
            .datasource?
            .didRequestForIconVariant(with: "refresh", fontSize: size)
        return icon
    }
}
