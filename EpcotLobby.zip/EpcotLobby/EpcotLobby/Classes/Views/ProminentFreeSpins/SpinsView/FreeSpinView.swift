//
//  FreeSpinView.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 18/04/24.
//

import SwiftUI
import Kingfisher
import Utility
import TrackerClient

struct FreeSpinView: View {
    
    // MARK: Properties
    @ObservedObject private var viewModel: FreeSpinViewModel
    private let styles = FreeSpinViewCSS()
    
    // MARK: Init
    init(viewModel: FreeSpinViewModel) {
        self.viewModel = viewModel
    }
    
    // MARK: Body
    var body: some View {
        HStack(spacing: 0.0) {
            VStack(alignment: .leading, spacing: 5.0) {
                Text(viewModel.remainingSpins)
                    .font(styles.remainingSpinsTextFont)
                    .foregroundColor(styles.remainingSpinsTextColor)
                    .lineLimit(2)
                    .accessibilityValue(viewModel.spinsLeft)
                    .accessibilityIdentifier(ProminentFreeSpinsAccessID.SPINS_LEFT)
                
                Text(viewModel.spinExpiryTime)
                    .font(styles.expiryTextFont)
                    .foregroundColor(styles.expiryTextColor)
                    .lineLimit(1)
                    .accessibilityValue(viewModel.spinExpiry)
                    .accessibilityIdentifier(ProminentFreeSpinsAccessID.OFFER_EXPIRY)
            }
            .padding(.leading, 14.0)
            .allowsHitTesting(false)
            
            Spacer(minLength: 8.0)
                .allowsHitTesting(false)
            
            FreeSpinsButton(viewModel: viewModel)
                .padding(.trailing, 14.0)
                .allowsHitTesting(true)
                .accessibilityIdentifier(ProminentFreeSpinsAccessID.SPIN)
        }
        .padding(10.0)
        .frame(height: styles.height)
        .background(
            KFImage(URL(string: viewModel.backgroundImage))
                .placeholder {
                    PlaceHolderImage()
                        .frame(height: styles.height)
                }
                .resizable()
                .frame(height: styles.height)
                .clipped()
                .overlay(gradientMask)
                .allowsHitTesting(false)
                .accessibilityIdentifier(ProminentFreeSpinsAccessID.BACKGROUND_IMAGE)
        )
        .cornerRadius(styles.cornerRadius)
        .onAppear {
            viewModel.trackEvent(eventDetails: EpcotEventDetails.free_spins_load.rawValue,
                                 eventAction: EpcotEventAction.load.rawValue,
                                 eventLabel: viewModel.texts?.mainTitle ?? EpcotEventLabel.free_spins.rawValue)
        }
    }
}

extension FreeSpinView {
    private var gradientMask: some ShapeStyle {
        LinearGradient(
            stops: [
                Gradient.Stop(color: styles.gradientLeftColor, location: 0.00),
                Gradient.Stop(color: styles.gradientMiddleColor, location: 0.51),
                Gradient.Stop(color: styles.gradientRightColor, location: 1.00),
            ],
            startPoint: UnitPoint(x: 1.11, y: 0.5),
            endPoint: UnitPoint(x: -0.07, y: 0.5)
        )
        .opacity(styles.gradientOpacity)
    }
}

// MARK: - Preview

struct FreeSpinView_Previews: PreviewProvider {
    static let freeSpin = FreeSpinsStub().freeSpins.first
    static var previews: some View {
        if let freeSpin {
            FreeSpinView(viewModel: FreeSpinViewModel(freeSpin: freeSpin))
        }
        EmptyView()
    }
}
