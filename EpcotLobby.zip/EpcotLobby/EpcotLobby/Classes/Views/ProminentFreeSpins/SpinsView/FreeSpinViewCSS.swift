//
//  FreeSpinViewCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 02/05/24.
//

import Foundation
import SwiftUI
import Utility

struct FreeSpinViewCSS {
    var remainingSpinsTextFont: Font
    var remainingSpinsTextColor: Color
    var expiryTextFont: Font
    var expiryTextColor: Color
    var spinTextFont: Font
    var spinTextColor: Color
    var spinButtonTopColor: Color
    var spinButtonBottomColor: Color
    var spinButtonBackgroundColor: Color
    var backgroundColor: Color
    var cornerRadius: CGFloat
    var height: CGFloat
    var gradientLeftColor: Color
    var gradientMiddleColor: Color
    var gradientRightColor: Color
    var gradientOpacity: CGFloat

    init(freeSpinsCSS: FreeSpinsCSS? = nil) {
        let css = freeSpinsCSS ?? Self.lobbyCSS?.freeSpinsCSS
        self.remainingSpinsTextFont = Font(css?.remainingSpinsText?.font ?? Self.remainingSpinsTextFont)
        self.remainingSpinsTextColor = Color(css?.remainingSpinsText?.color ?? Self.remainingSpinsTextColor)
        self.expiryTextFont = Font(css?.expiryText?.font ?? Self.expiryTextFont)
        self.expiryTextColor = Color(css?.expiryText?.color ?? Self.expiryTextColor)
        self.spinTextFont = Font(css?.spinText?.font ?? Self.spinTextFont)
        self.spinTextColor = Color(css?.spinText?.color ?? Self.spinTextColor)
        self.spinButtonTopColor = Color(css?.spinButtonTopColor ?? Self.spinButtonTopColor)
        self.spinButtonBottomColor = Color(css?.spinButtonBottomColor ?? Self.spinButtonBottomColor)
        self.spinButtonBackgroundColor = Color(css?.spinButtonBackgroundColor ?? Self.spinButtonBackgroundColor)
        self.backgroundColor = Color(css?.backgroundColor ?? Self.backgroundColor)
        self.cornerRadius = css?.cornerRadius ?? Self.cornerRadius
        self.height = css?.height ?? Self.height
        self.gradientLeftColor = Color(css?.gradientLeftColor ?? Self.gradientLeftColor)
        self.gradientMiddleColor = Color(css?.gradientMiddleColor ?? Self.gradientMiddleColor)
        self.gradientRightColor = Color(css?.gradientRightColor ?? Self.gradientRightColor)
        self.gradientOpacity = css?.gradientOpacity ?? Self.gradientOpacity
    }
}

// MARK: - Helper
extension FreeSpinViewCSS: LobbyStylable { }

extension FreeSpinViewCSS {
    private static var remainingSpinsTextFont: UIFont {
        UIFont(name: "Roboto-Bold", size: 16) ?? // Poppins - SemiBold (16)
        .systemFont(ofSize: 16, weight: .bold)
    }
    private static var remainingSpinsTextColor: UIColor { .black } 
    private static var expiryTextFont: UIFont {
        UIFont(name: "Roboto-Regular", size: 10) ?? // Poppins - Medium (10)
        .systemFont(ofSize: 10, weight: .bold)
    }
    private static var expiryTextColor: UIColor { .black }
    private static var spinTextFont: UIFont {
        UIFont(name: "Roboto-Bold", size: 10) ?? // Kanit - medium (10)
        .systemFont(ofSize: 16, weight: .bold)
    }
    private static var spinTextColor: UIColor { .white }
    private static var spinButtonTopColor: UIColor { UIColor(hex: "#E9D193") }
    private static var spinButtonBottomColor: UIColor { UIColor(hex: "#D4B962") }
    private static var spinButtonBackgroundColor: UIColor { UIColor(hex: "#C0A971") }
    private static var backgroundColor: UIColor { .white }
    private static var cornerRadius: CGFloat { 14.0 }
    private static var height: CGFloat { 100.0 }
    private static var gradientLeftColor: UIColor { UIColor(hex: "#070607") }
    private static var gradientMiddleColor: UIColor { UIColor(hex: "#070607CC") }
    private static var gradientRightColor: UIColor { UIColor(hex: "#060506") }
    private static var gradientOpacity: CGFloat { 0.95 }
}
