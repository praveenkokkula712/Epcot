//
//  FreeSpinPageControl.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 08/05/24.
//

import SwiftUI

struct FreeSpinPageControl: UIViewRepresentable {
    let numberOfPages: Int
    let currentPage: Int
    let dotsColor: UIColor
    let selectedDotColor: UIColor
    
    func makeUIView(context: Context) -> PageControlView {
        var pageControl = PageControlView()
        pageControl.numberOfPages = numberOfPages
        pageControl.drawer = ScaleDrawer(
            dotsColor: dotsColor, 
            selectedColor: selectedDotColor
        )
        pageControl.setPage(0)
        return pageControl
    }
    
    func updateUIView(_ uiView: PageControlView, context: Context) {
        uiView.numberOfPages = numberOfPages
        uiView.setPage(currentPage)
    }
}
