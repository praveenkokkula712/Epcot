//
//  FreeSpinsPageControlViewCSS.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 08/05/24.
//

import Foundation
import SwiftUI

struct FreeSpinsPageControlViewCSS {
    let dotsColor: Color
    let selectedDotColor: Color

    init(freeSpinsCSS: FreeSpinsPageControlCSS? = nil) {
        let css = freeSpinsCSS ?? Self.lobbyCSS?.freeSpinsCSS?.pageControlCSS
        self.dotsColor = Color(css?.dotsColor ?? Self.dotsColor)
        self.selectedDotColor = Color(css?.selectedDotColor ?? Self.selectedDotColor)
    }
}

// MARK: - Helper
extension FreeSpinsPageControlViewCSS: LobbyStylable { }

extension FreeSpinsPageControlViewCSS {
    private static var dotsColor: UIColor { .gray }
    private static var selectedDotColor: UIColor { .black }
}
