//
//  FreeSpinsOverlayView+TrackEvents.swift
//  EpcotLobby
//
//  Created by Santhosh Kodadi on 07/06/24.
//

import Utility
import TrackerClient

// MARK: Tracking Events
extension FreeSpinsOverlayView {
    internal func trackEvent(eventDetails: String = EpcotEventDetails.free_spins_screen_load.rawValue,
                             eventAction: String = EpcotEventAction.load.rawValue,
                             eventLabel: String = EpcotEventLabel.free_spins.rawValue) {
        DispatchQueue(label: kTrackEventQueue).async {
            
            let log = InteractionLog(categoryEvent: EpcotEventCategory.promotions.rawValue,
                                     actionEvent:eventAction,
                                     labelEvent: eventLabel,
                                     locationEvent: ScreenName.casino.rawValue,
                                     eventDetails: eventDetails,
                                     positionEvent: GtmLogConstants.GeneralConstants.notApplicable.rawValue,
                                     productType: EpcotEventProductType.casino.rawValue,
                                     appInfo: EpcotEventAppInfo.casinow.rawValue)
            let event = TrackerEvent(type: EventType.promo_hub_events, log: log, tracker: .gtm)
            Tracker.postNotification(object: self, userInfo: [kEvent: event])
        }
    }
}
