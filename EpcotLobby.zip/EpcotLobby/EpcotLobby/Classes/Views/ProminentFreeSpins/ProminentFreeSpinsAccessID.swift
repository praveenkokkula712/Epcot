//
//  ProminentFreeSpinsAccessID.swift
//  EpcotLobby
//
//  Created by Yemireddi Sateesh on 10/06/24.
//

import Foundation

struct ProminentFreeSpinsAccessID {
    static let PAGE_CONTROL = "PFS_Spin_Indicator"

    static let BACKGROUND_IMAGE = "PFS_Background_Image"
    static let SPINS_LEFT = "PFS_Remaining_Spins"
    static let OFFER_EXPIRY = "PFS_Spin_Expiry"
    static let SPIN = "PFS_Spin_Button"

    static let BONUS_SPINS = "PFS_Bonus_Spins"
    static let CLOSE = "PFS_Close_Button"
    static let CTA_IMAGE = "PFS_CTA_Image"
    static let CURRENT_WINNINGS_TITLE = "PFS_Current_Winnings_Title"
    static let CURRENT_WINNINGS = "PFS_Current_Winnings"
    static let USED_SPINS = "PFS_Spins_Used"
    static let REMAINING_SPINS = "PFS_Spins_Left"
    static let ELIGIBLE_GAMES = "PFS_Eligible_Games"

    static let MORE_DETAILS = "PFS_View_Details_Button"
}
