//
//  FreeSpinsContainer.swift
//  InfiniteCarousalView
//
//  Created by Yemireddi Sateesh on 18/04/24.
//

import Foundation

class FreeSpinsContainer: ObservableObject {

    // MARK: Properties
    @Published var freeSpins = [FreeSpin]()
    private let prominentFreeSpins: ProminentFreeSpins
    private let freeSpinsDetails: ProminentFreeSpinDetails
    let texts: FreeSpinsConfigurationTexts?
    let backgroundImage: String
    let ctaImage: String
    let onClick: ((FreeSpin, [String]) -> Void) //freeSpin, gameNames
    private var rewardGameNames = [Int: [String]]() // Reward ID: Game Variant Names

    // MARK: Init
    init(
        freeSpins: ProminentFreeSpins,
        freeSpinsDetails: ProminentFreeSpinDetails,
        texts: FreeSpinsConfigurationTexts? = nil,
        backgroundImage: String = "",
        ctaImage: String = "",
        onFreeSpinClick: @escaping ((FreeSpin, [String]) -> Void)
    ) {
        self.prominentFreeSpins = freeSpins
        self.freeSpinsDetails = freeSpinsDetails
        if let rewards = freeSpinsDetails.rewardDetails {
            self.freeSpins = rewards
        }
        self.texts = texts
        self.backgroundImage = backgroundImage
        self.ctaImage = ctaImage
        self.onClick = onFreeSpinClick
        self.mapFreeSpinsGameNames()
    }

    // MARK: View's properties
    var pageCount: Int { freeSpins.count }

    var isScrollable: Bool { pageCount > 1 }

    // MARK: Free spins associated games
    func mapFreeSpinsGameNames() {
        for gameDetails in prominentFreeSpins.gameDetails ?? [:] {
            let gameName = gameDetails.key
            let rewardIDs = gameDetails.value.rewardIDS ?? []
            rewardIDs.forEach { id in
                var gameNames = rewardGameNames[id] ?? []
                gameNames.append(gameName)
                self.rewardGameNames[id] = gameNames
            }
        }
    }
    
    func gameNames(for rewardID: Int) -> [String] {
        rewardGameNames[rewardID] ?? []
    }
}
