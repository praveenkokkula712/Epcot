//
//  FreeSpinsContainerView.swift
//  InfiniteCarousalView
//
//  Created by Yemireddi Sateesh on 18/04/24.
//

import SwiftUI
import Utility

struct FreeSpinsContainerView: View {

    // MARK: Properties
    @ObservedObject private var container: FreeSpinsContainer
    @State private var index = 0
    private let pageContorlStyles = FreeSpinsPageControlViewCSS()
    private let freeSpinsStyles = FreeSpinViewCSS()

    // MARK: Init
    init(container: FreeSpinsContainer) {
        self.container = container
    }

    // MARK: Body
    var body: some View {
        VStack(alignment: .leading, spacing: 0.0) {
            
            // Free Spins UI
            if container.isScrollable {
                RightSidedCarouselView(
                    width: width,
                    spacing: 0,
                    items: container.freeSpins,
                    getScrollIndex: { self.index = $0 }
                ) { freeSpin in
                    self.configureFreeSpinView(freeSpin: freeSpin)
                        .padding(.leading, freeSpinLeading)
                }
                .frame(height: freeSpinsStyles.height)
            } else {
                if let freeSpin = container.freeSpins.first {
                    self.configureFreeSpinView(freeSpin: freeSpin)
                        .padding(.horizontal, freeSpinLeading)
                        .padding(.bottom, freeSpinBottom)
                }
            }

            // Page Control
            if container.isScrollable {
                FreeSpinPageControl(
                    numberOfPages: container.pageCount,
                    currentPage: index,
                    dotsColor: UIColor(pageContorlStyles.dotsColor),
                    selectedDotColor: UIColor(pageContorlStyles.selectedDotColor)
                )
                .accessibilityValue("\(index + 1)/\(container.pageCount)")
                .accessibilityIdentifier(ProminentFreeSpinsAccessID.PAGE_CONTROL)
            }
        }
        .frame(height: height)
    }
    
    // MARK: Design Constants
    private var freeSpinLeading: CGFloat { 12.0 }
    private var freeSpinBottom: CGFloat { 24.0 }
    private var height: CGFloat { container.isScrollable ? 136.0 : 124.0 }
    private var width: CGFloat { 295.0 }
    
    // MARK: Helper
    @ViewBuilder
    func configureFreeSpinView(freeSpin: FreeSpin) -> some View {
        let viewModel = FreeSpinViewModel(
            freeSpin: freeSpin,
            texts: container.texts,
            backgroundImage: container.backgroundImage
        ) {
            self.container.onClick(
                freeSpin,
                self.container.gameNames(for: freeSpin.id ?? 0)
            )
        }
        FreeSpinView(viewModel: viewModel)
    }
}

// MARK: - Preview
struct FreeSpinsContainerView_Previews: PreviewProvider {
    static let prominentFreeSpins = FreeSpinsStub().prominentFreeSpins
    static let freeSpinDetails = FreeSpinsStub().freeSpinDetails
    
    static var previews: some View {
        if let prominentFreeSpins, let freeSpinDetails {
            let container = FreeSpinsContainer(
                freeSpins: prominentFreeSpins,
                freeSpinsDetails: freeSpinDetails,
                texts: nil
            ) { _, _ in }
            FreeSpinsContainerView(container: container)
        }
        EmptyView()
    }
}
